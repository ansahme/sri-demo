---
name: process-os-file-viewer
description: >-
  Launch a visual viewer for BPMN, DMN, or Form files in the browser. Without an
  argument, opens a project-wide sidebar browser for all .bpmn, .dmn, and .form
  files grouped by folder.
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
Launch the Camunda file viewer to visually inspect BPMN processes, DMN decision tables, and Camunda Forms.

$ARGUMENTS

## Directory mode (no argument)

Opens a project-wide sidebar browser that recursively scans the project for all `.bpmn`, `.dmn`, and `.form` files and groups them by folder. Includes BPMN review comments.

## Single-file mode (file argument given)

Auto-detects file type from extension (`.bpmn`, `.dmn`, `.form`) and loads the right viewer (bpmn-js, dmn-js, or form-js).

## Step 1: Start the viewer

For **directory mode** (no file argument):
```bash
node ".github/skills/process-os-file-viewer/scripts/start-bpmn-viewer.cjs"
```

For **single-file mode** (file argument given):
```bash
node ".github/skills/process-os-file-viewer/scripts/start-bpmn-viewer.cjs" --file "<file>"
```

The script prints a JSON line on success:
```json
{"type":"server-started","port":PORT,"url":"http://localhost:PORT","pid_file":"..."}
```

Parse the `url` field and tell the user:
```
Viewer running at http://localhost:PORT — open in your browser.
```

If directory mode: also list the folders found (e.g. `process-transformation/`, `camunda-artifacts/`) so the user knows what to expect in the sidebar.

If the script returns `"type":"already-running"`: tell the user a viewer session is already open and they must stop it first, then retry:

```
A viewer is already running. Stop it with /process-os-file-viewer stop, then run this command again.
```

Do not proceed further.

## Stop variant

If the user runs `/process-os-file-viewer stop`:

```bash
node ".github/skills/process-os-file-viewer/scripts/stop-bpmn-viewer.cjs"
```
