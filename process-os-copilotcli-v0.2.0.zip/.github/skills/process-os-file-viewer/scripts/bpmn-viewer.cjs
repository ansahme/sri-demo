#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';
/**
 * Local BPMN/DMN/Form review server.
 *
 * Directory mode (default):
 *   PROJECT_DIR=/path/to/project node bpmn-viewer.cjs
 *   VIEWER_PORT=3001 PROJECT_DIR=... node bpmn-viewer.cjs
 *   Recursively scans the project for .bpmn/.dmn/.form files and serves a
 *   sidebar viewer grouped by folder.
 *
 * Single-file mode:
 *   node bpmn-viewer.cjs <file.bpmn|file.dmn|file.form>
 *   Auto-detects file type and loads the right viewer (bpmn-js, dmn-js, form-js).
 */

const http = require('http');
const fs   = require('fs');
const path = require('path');

const viewerAssets = require(path.join(__dirname, 'viewer-assets.cjs'));
const { naturalCompare } = require(path.join(__dirname, 'natural-order.cjs'));

// Every project path in this server derives from PROJECT_DIR, falling back to the
// cwd — the launcher sets both to the same directory, but a direct invocation may
// not, and the viewer libraries live beside the project's other files.
const PROJECT_DIR = process.env.PROJECT_DIR || process.cwd();

// The viewer bundles are ordinary declared dependencies, served by this server
// rather than fetched from a CDN. Absent, every preview renders a blank canvas
// with nothing but a console error, so refuse to start instead.
// The directory is resolved once and reused: the message then names the directory
// that was really searched, and every request serves from the one validated here.
const viewerNodeModules = viewerAssets.nodeModulesDir(PROJECT_DIR);
const missingViewerPackages = viewerAssets.missingPackages(viewerNodeModules);
if (missingViewerPackages.length > 0) {
  console.error(
    'Viewer libraries missing from ' + viewerNodeModules + ': ' + missingViewerPackages.join(', ') +
    '. Run `c8 os install` (or `c8 os update`).'
  );
  process.exit(2);
}

const singleFile = process.argv[2];

// ── Single-file mode ──────────────────────────────────────────────────────────

if (singleFile) {
  const filePath = path.resolve(singleFile);
  if (!fs.existsSync(filePath)) {
    console.error(`File not found: ${filePath}`);
    process.exit(1);
  }

  const ext = path.extname(filePath).toLowerCase();
  const typeMap = { '.bpmn': 'bpmn', '.dmn': 'dmn', '.form': 'form' };
  const fileType = typeMap[ext];
  if (!fileType) {
    console.error(`Unsupported file type: ${ext} (expected .bpmn, .dmn, or .form)`);
    process.exit(1);
  }

  const singleFileHtml = () => `<!DOCTYPE html>
<html>
<head>
  <title>Camunda Viewer</title>
  ${viewerAssets.assetTags([fileType])}
  <style>
    body { margin: 0; font-family: sans-serif; }
    #canvas { width: 100vw; height: calc(100vh - 40px); }
    #toolbar { height: 40px; display: flex; align-items: center; padding: 0 12px; background: #f5f5f5; border-bottom: 1px solid #ddd; }
    #toolbar span { margin-left: 12px; color: #666; font-size: 13px; }
    button { margin-right: 8px; padding: 4px 12px; cursor: pointer; }
    #canvas .fjs-container { max-width: 800px; margin: 24px auto; }
  </style>
</head>
<body>
  <div id="toolbar">
    <button onclick="load()">Reload</button>
    <button id="fitBtn" onclick="fitViewport()">Fit</button>
    <span id="filename"></span>
  </div>
  <div id="canvas"></div>
  <script>
    var viewer = null;
    var fileType = null;

    async function init() {
      var meta = await (await fetch('/type')).json();
      fileType = meta.type;
      document.getElementById('filename').textContent = meta.name;
      document.title = meta.type.toUpperCase() + ' Viewer';

      if (fileType === 'form') document.getElementById('fitBtn').style.display = 'none';

      load();
    }

    async function load() {
      var res = await fetch('/file');
      var content = await res.text();
      var container = document.getElementById('canvas');

      if (fileType === 'bpmn') {
        if (!viewer) viewer = new BpmnJS({ container: container });
        await viewer.importXML(content);
        fitViewport();
      } else if (fileType === 'dmn') {
        if (!viewer) viewer = new DmnJS({ container: container });
        await viewer.importXML(content);
        try {
          var av = viewer.getActiveView();
          if (av && av.type === 'drd') viewer.getActiveViewer().get('canvas').zoom('fit-viewport');
        } catch (e) {}
      } else if (fileType === 'form') {
        container.innerHTML = '';
        viewer = new FormViewer.Form({ container: container });
        await viewer.importSchema(JSON.parse(content));
      }
    }

    function fitViewport() {
      if (!viewer) return;
      try {
        if (fileType === 'bpmn') viewer.get('canvas').zoom('fit-viewport');
        else if (fileType === 'dmn') viewer.getActiveViewer().get('canvas').zoom('fit-viewport');
      } catch (e) {}
    }

    init();
  </script>
</body>
</html>`;

  const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://localhost');

    if (viewerAssets.serveAsset(url.pathname, res, viewerNodeModules)) return;

    if (url.pathname === '/type') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ type: fileType, name: singleFile }));
      return;
    }

    if (url.pathname === '/file') {
      try {
        const content = fs.readFileSync(filePath, 'utf8');
        const contentType = fileType === 'form' ? 'application/json' : 'application/xml';
        res.writeHead(200, { 'Content-Type': contentType });
        res.end(content);
      } catch { res.writeHead(404); res.end('Not found'); }
      return;
    }

    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(singleFileHtml());
  });

  const PORT = parseInt(process.env.VIEWER_PORT || '3333', 10);
  const pidFile = path.join(PROJECT_DIR, '.camunda', 'bpmn-viewer.pid');

  server.listen(PORT, '127.0.0.1', () => {
    const port = server.address().port;
    console.log(JSON.stringify({ type: 'server-started', port, url: `http://localhost:${port}`, pid_file: pidFile }));
    try {
      fs.mkdirSync(path.join(PROJECT_DIR, '.camunda'), { recursive: true });
      fs.writeFileSync(pidFile, String(process.pid));
    } catch {}
  });

  process.on('SIGTERM', () => {
    try { fs.unlinkSync(pidFile); } catch {}
    process.exit(0);
  });

  return;
}

// ── Directory mode ────────────────────────────────────────────────────────────

const PORT        = parseInt(process.env.VIEWER_PORT || '0', 10);
const COMMENTS_FILE = path.join(PROJECT_DIR, '.camunda', 'review-comments.json');

const SKIP_DIRS = new Set(['node_modules', '.git', 'evals']);
const TYPE_MAP  = { '.bpmn': 'bpmn', '.dmn': 'dmn', '.form': 'form' };

function scanProject(dir, relBase) {
  const result = [];
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); }
  catch { return result; }
  for (const entry of entries) {
    if (SKIP_DIRS.has(entry.name) || entry.name.startsWith('.')) continue;
    const fullPath = path.join(dir, entry.name);
    const relPath  = relBase ? relBase + '/' + entry.name : entry.name;
    if (entry.isDirectory()) {
      result.push(...scanProject(fullPath, relPath));
    } else if (entry.isFile()) {
      const ext  = path.extname(entry.name).toLowerCase();
      const type = TYPE_MAP[ext];
      if (type) result.push({ path: relPath, name: entry.name, dir: relBase || '', type });
    }
  }
  return result;
}

function groupedFiles() {
  const all    = scanProject(PROJECT_DIR, '');
  const groups = {};
  for (const f of all) {
    const key = f.dir || '(root)';
    if (!groups[key]) groups[key] = [];
    groups[key].push(f);
  }
  return Object.entries(groups)
    .sort(([a], [b]) => naturalCompare(a, b))
    .map(([dir, files]) => ({ dir, files: files.sort((a, b) => a.name.localeCompare(b.name)) }));
}

function safeFilePath(relPath) {
  if (!relPath) return null;
  const ext = path.extname(relPath).toLowerCase();
  if (!TYPE_MAP[ext]) return null;
  const abs = path.resolve(PROJECT_DIR, relPath);
  if (!abs.startsWith(PROJECT_DIR + path.sep)) return null;
  return abs;
}

function readComments() {
  try { return JSON.parse(fs.readFileSync(COMMENTS_FILE, 'utf8')); }
  catch { return {}; }
}

function writeComments(data) {
  try {
    fs.mkdirSync(path.dirname(COMMENTS_FILE), { recursive: true });
    fs.writeFileSync(COMMENTS_FILE, JSON.stringify(data, null, 2));
  } catch {}
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', d => { body += d; });
    req.on('end', () => { try { resolve(JSON.parse(body)); } catch { reject(new Error('bad json')); } });
    req.on('error', reject);
  });
}

function html() {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Camunda Viewer</title>
${viewerAssets.assetTags(['bpmn', 'dmn', 'form'])}
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0f1117;color:#e2e8f0;font-family:system-ui,sans-serif;display:flex;height:100vh;overflow:hidden}
#sidebar{width:240px;background:#1a1f2e;border-right:1px solid #2d3748;display:flex;flex-direction:column;flex-shrink:0}
#sidebar h2{padding:14px 16px;border-bottom:1px solid #2d3748;font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:#718096;font-weight:400}
#file-list{flex:1;overflow-y:auto;padding:6px 0}
.dir-header{padding:8px 14px 4px;font-size:11px;color:#4a5568;text-transform:uppercase;letter-spacing:.06em;font-weight:600;margin-top:6px;border-top:1px solid #1e2535}
.dir-header:first-child{margin-top:0;border-top:none}
.file-item{padding:6px 14px 6px 22px;font-size:13px;cursor:pointer;color:#a0aec0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;border-left:3px solid transparent;display:flex;align-items:center;gap:5px}
.file-item:hover{background:#2d3748;color:#e2e8f0}
.file-item.active{background:#2c5282;color:#90cdf4;border-left-color:#4299e1}
.file-item.overview{color:#68d391;font-style:italic}
.type-tag{font-size:10px;padding:1px 4px;border-radius:3px;background:#2d3748;color:#718096;flex-shrink:0;font-style:normal}
.file-item.active .type-tag{background:#1a3a5c;color:#63b3ed}
#main{flex:1;display:flex;flex-direction:column;position:relative;overflow:hidden}
#toolbar{padding:8px 14px;background:#1a1f2e;border-bottom:1px solid #2d3748;font-size:13px;color:#718096;display:flex;align-items:center;gap:10px;flex-shrink:0}
#toolbar span{color:#e2e8f0;font-weight:500}
#toolbar-actions{margin-left:auto;display:flex;gap:6px}
#toolbar button{padding:4px 10px;background:#2d3748;border:1px solid #4a5568;border-radius:4px;color:#a0aec0;font-size:12px;cursor:pointer}
#toolbar button:hover{background:#4a5568;color:#e2e8f0}
#canvas{flex:1;background:#fff;overflow:auto}
#canvas .fjs-container{max-width:800px;margin:24px auto}
#comment-panel{
  position:absolute;right:0;top:0;bottom:0;width:300px;
  background:#1a1f2e;border-left:1px solid #2d3748;
  display:none;flex-direction:column;z-index:10;
}
#comment-panel.open{display:flex}
#cp-header{
  padding:10px 14px;border-bottom:1px solid #2d3748;
  font-size:12px;font-weight:600;color:#90cdf4;
  display:flex;align-items:center;justify-content:space-between;flex-shrink:0;
}
#cp-element-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;margin-right:8px}
#cp-header button{background:none;border:none;color:#718096;font-size:18px;cursor:pointer;line-height:1;padding:0;flex-shrink:0}
#cp-header button:hover{color:#e2e8f0}
#comment-list{flex:1;overflow-y:auto;padding:10px 14px;display:flex;flex-direction:column;gap:8px}
.comment-item{background:#0f1117;border-radius:6px;padding:8px 10px;border:1px solid #2d3748}
.comment-item.resolved{opacity:0.4}
.comment-text{font-size:13px;color:#e2e8f0;line-height:1.45;word-break:break-word;margin-bottom:6px}
.comment-actions{display:flex;justify-content:flex-end}
.resolve-btn{font-size:11px;padding:2px 8px;background:#2d3748;border:1px solid #4a5568;border-radius:3px;color:#68d391;cursor:pointer}
.resolve-btn:hover{background:#4a5568}
.resolved .resolve-btn{color:#4a5568;cursor:default}
.no-comments{font-size:13px;color:#4a5568;font-style:italic;text-align:center;padding:20px 0}
#cp-input{padding:12px 14px;border-top:1px solid #2d3748;display:flex;flex-direction:column;gap:8px;flex-shrink:0}
#cp-input textarea{
  background:#0f1117;border:1px solid #4a5568;border-radius:4px;
  color:#e2e8f0;font-size:13px;padding:8px;resize:vertical;min-height:72px;
  font-family:inherit;line-height:1.4;
}
#cp-input textarea:focus{outline:none;border-color:#4299e1}
#cp-input button{
  padding:7px 12px;background:#2b6cb0;border:none;border-radius:4px;
  color:#e2e8f0;font-size:13px;cursor:pointer;font-weight:500;
}
#cp-input button:hover{background:#3182ce}
.review-badge{
  width:14px;height:14px;background:#f6e05e;border-radius:50%;
  border:2px solid #b7791f;pointer-events:none;
  box-shadow:0 0 5px rgba(246,224,94,.7);
}
</style>
</head>
<body>
<div id="sidebar">
  <h2>Project Files</h2>
  <div id="file-list"></div>
</div>
<div id="main">
  <div id="toolbar">
    <span id="label">Select a file</span>
    <div id="toolbar-actions">
      <button id="fitBtn" onclick="fit()">Fit view</button>
    </div>
  </div>
  <div id="canvas"></div>
  <div id="comment-panel">
    <div id="cp-header">
      <span id="cp-element-label">Element</span>
      <button onclick="closePanel()" title="Close">&times;</button>
    </div>
    <div id="comment-list"></div>
    <div id="cp-input">
      <textarea id="cp-text" placeholder="Write a review comment…"></textarea>
      <button onclick="addComment()">Add review comment</button>
    </div>
  </div>
</div>
<script>
var viewer = null;
var currentType = null;
var currentPath = null;
var currentElementId = null;
var fileComments = {};

function fit() {
  if (!viewer || !currentType) return;
  try {
    if (currentType === 'bpmn') viewer.get('canvas').zoom('fit-viewport');
    else if (currentType === 'dmn') viewer.getActiveViewer().get('canvas').zoom('fit-viewport');
  } catch(e) {}
}

function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

/* ── Comment panel ────────────────────────────────────────────── */

function setSelectionOverlay(elementId) {
  if (currentType !== 'bpmn' || !viewer) return;
  try {
    var overlays = viewer.get('overlays');
    overlays.remove({ type: 'review-selection' });
    if (!elementId) return;
    var el = viewer.get('elementRegistry').get(elementId);
    if (!el || !el.width || !el.height) return;
    var pad = 6;
    var type = el.type || '';
    var base = 'border:2px solid #4299e1;box-shadow:0 0 0 2px rgba(66,153,225,0.25);pointer-events:none;box-sizing:border-box;';
    var div = document.createElement('div');
    var pos;
    if (type.indexOf('Event') !== -1) {
      div.style.cssText = 'width:' + (el.width + pad*2) + 'px;height:' + (el.height + pad*2) + 'px;border-radius:50%;' + base;
      pos = { top: -pad, left: -pad };
    } else if (type.indexOf('Gateway') !== -1) {
      var halfDiag = el.width / 2 + pad;
      var side = Math.round(halfDiag * Math.sqrt(2));
      var offset = Math.round(el.width / 2 - side / 2);
      div.style.cssText = 'width:' + side + 'px;height:' + side + 'px;transform:rotate(45deg);' + base;
      pos = { top: offset, left: offset };
    } else {
      div.style.cssText = 'width:' + (el.width + pad*2) + 'px;height:' + (el.height + pad*2) + 'px;border-radius:10px;' + base;
      pos = { top: -pad, left: -pad };
    }
    overlays.add(elementId, 'review-selection', { position: pos, html: div });
  } catch(e) {}
}

function closePanel() {
  setSelectionOverlay(null);
  document.getElementById('comment-panel').classList.remove('open');
  currentElementId = null;
}

function openPanel(elementId, elementName) {
  setSelectionOverlay(elementId);
  currentElementId = elementId;
  document.getElementById('cp-element-label').textContent = elementName || elementId;
  document.getElementById('cp-text').value = '';
  renderCommentList();
  document.getElementById('comment-panel').classList.add('open');
}

function renderCommentList() {
  var list = document.getElementById('comment-list');
  var comments = fileComments[currentElementId] || [];
  list.innerHTML = '';
  if (comments.length === 0) {
    list.innerHTML = '<div class="no-comments">No comments yet</div>';
    return;
  }
  comments.forEach(function(c, idx) {
    var item = document.createElement('div');
    item.className = 'comment-item' + (c.resolved ? ' resolved' : '');
    item.innerHTML =
      '<div class="comment-text">' + esc(c.comment) + '</div>' +
      '<div class="comment-actions">' +
        '<button class="resolve-btn"' + (c.resolved ? ' disabled' : '') +
        ' onclick="resolveComment(' + idx + ')">' +
        (c.resolved ? 'Resolved' : 'Resolve') +
        '</button>' +
      '</div>';
    list.appendChild(item);
  });
}

function addComment() {
  var text = document.getElementById('cp-text').value.trim();
  if (!text || !currentPath || !currentElementId) return;
  fetch('/comments', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ file: currentPath, elementId: currentElementId, comment: text })
  }).then(function() {
    document.getElementById('cp-text').value = '';
    return refreshComments();
  });
}

function resolveComment(idx) {
  if (!currentPath || !currentElementId) return;
  fetch('/comments/resolve', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ file: currentPath, elementId: currentElementId, index: idx })
  }).then(refreshComments);
}

function refreshComments() {
  return loadComments(currentPath).then(function() {
    if (currentType === 'bpmn') updateOverlays();
    if (currentElementId) renderCommentList();
  });
}

function loadComments(filePath) {
  return fetch('/comments?file=' + encodeURIComponent(filePath))
    .then(function(r) { return r.json(); })
    .then(function(data) { fileComments = data; });
}

function updateOverlays() {
  if (currentType !== 'bpmn' || !viewer) return;
  try {
    var overlays = viewer.get('overlays');
    overlays.clear();
    Object.keys(fileComments).forEach(function(elId) {
      var hasUnresolved = (fileComments[elId] || []).some(function(c) { return !c.resolved; });
      if (!hasUnresolved) return;
      try {
        var badge = document.createElement('div');
        badge.className = 'review-badge';
        overlays.add(elId, 'review', { position: { top: -8, right: -8 }, html: badge });
      } catch(e) {}
    });
  } catch(e) {}
}

/* ── Viewer management ────────────────────────────────────────── */

function createViewer(type) {
  var container = document.getElementById('canvas');
  container.innerHTML = '';
  if (type === 'bpmn') {
    viewer = new BpmnJS({ container: container });
    viewer.get('eventBus').on('element.click', function(event) {
      var el = event.element;
      if (!el) return;
      if (el.type === 'bpmn:Process') { closePanel(); return; }
      if (!el.id || el.type === 'label') return;
      var name = (el.businessObject && el.businessObject.name) || el.id;
      openPanel(el.id, name);
    });
  } else if (type === 'dmn') {
    viewer = new DmnJS({ container: container });
  } else if (type === 'form') {
    viewer = new FormViewer.Form({ container: container });
  }
  currentType = type;
}

/* ── File loading ─────────────────────────────────────────────── */

async function load(filePath, fileType) {
  closePanel();
  document.querySelectorAll('.file-item').forEach(function(el) {
    el.classList.toggle('active', el.dataset.path === filePath);
  });
  document.getElementById('label').textContent = filePath;
  currentPath = filePath;
  fileComments = {};

  document.getElementById('fitBtn').style.display = fileType === 'form' ? 'none' : '';

  var cp = document.getElementById('comment-panel');
  if (fileType !== 'bpmn') {
    cp.classList.remove('open');
    cp.style.display = 'none';
  } else {
    cp.style.display = '';
  }

  if (currentType !== fileType) {
    if (viewer) { try { viewer.destroy && viewer.destroy(); } catch {} viewer = null; }
    createViewer(fileType);
  }

  try {
    var res = await fetch('/file?path=' + encodeURIComponent(filePath));
    if (!res.ok) throw new Error('HTTP ' + res.status);
    var content = await res.text();

    if (fileType === 'bpmn') {
      await viewer.importXML(content);
      viewer.get('canvas').zoom('fit-viewport');
      await loadComments(filePath);
      updateOverlays();
    } else if (fileType === 'dmn') {
      await viewer.importXML(content);
      try {
        var av = viewer.getActiveView();
        if (av && av.type === 'drd') viewer.getActiveViewer().get('canvas').zoom('fit-viewport');
      } catch(e) {}
    } else if (fileType === 'form') {
      await viewer.importSchema(JSON.parse(content));
    }
  } catch(err) {
    document.getElementById('label').textContent = filePath + ' — load error (see console)';
    console.error(err);
  }
}

/* ── Sidebar ──────────────────────────────────────────────────── */

fetch('/list').then(function(r) { return r.json(); }).then(function(groups) {
  var list = document.getElementById('file-list');
  var firstFile = null;

  groups.forEach(function(group) {
    var header = document.createElement('div');
    header.className = 'dir-header';
    header.textContent = group.dir ? group.dir + '/' : '/';
    list.appendChild(header);

    group.files.forEach(function(f) {
      var baseName = f.name.replace(/\\.(bpmn|dmn|form)$/, '');
      var isOverview = /^00-/.test(baseName) || baseName === 'overview';

      var el = document.createElement('div');
      el.className = 'file-item' + (isOverview ? ' overview' : '');
      el.dataset.path = f.path;
      el.title = f.path;

      if (f.type !== 'bpmn') {
        var tag = document.createElement('span');
        tag.className = 'type-tag';
        tag.textContent = f.type;
        el.appendChild(tag);
      }
      el.appendChild(document.createTextNode(baseName));

      el.onclick = function() { load(f.path, f.type); };
      list.appendChild(el);
      if (!firstFile) firstFile = f;
    });
  });

  if (firstFile) load(firstFile.path, firstFile.type);
});
</script>
</body>
</html>`;
}

/* ── HTTP server ──────────────────────────────────────────────── */

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');

  if (viewerAssets.serveAsset(url.pathname, res, viewerNodeModules)) return;

  if (url.pathname === '/list') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(groupedFiles()));
    return;
  }

  if (url.pathname === '/file') {
    const relPath = url.searchParams.get('path') || '';
    const absPath = safeFilePath(relPath);
    if (!absPath) { res.writeHead(400); res.end('Bad request'); return; }
    try {
      const content = fs.readFileSync(absPath, 'utf8');
      const ext = path.extname(relPath).toLowerCase();
      const ct  = ext === '.form' ? 'application/json' : 'application/xml';
      res.writeHead(200, { 'Content-Type': ct });
      res.end(content);
    } catch { res.writeHead(404); res.end('Not found'); }
    return;
  }

  if (url.pathname === '/comments' && req.method === 'GET') {
    const file = url.searchParams.get('file') || '';
    const all  = readComments();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(all[file] || {}));
    return;
  }

  if (url.pathname === '/comments' && req.method === 'POST') {
    try {
      const { file, elementId, comment } = await parseBody(req);
      if (!file || !elementId || typeof comment !== 'string' || !comment.trim()) {
        res.writeHead(400); res.end('Bad request'); return;
      }
      const all = readComments();
      if (!all[file]) all[file] = {};
      if (!all[file][elementId]) all[file][elementId] = [];
      all[file][elementId].push({ comment: comment.trim(), resolved: false });
      writeComments(all);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true }));
    } catch { res.writeHead(400); res.end('Bad request'); }
    return;
  }

  if (url.pathname === '/comments/resolve' && req.method === 'POST') {
    try {
      const { file, elementId, index } = await parseBody(req);
      if (!file || !elementId || typeof index !== 'number') {
        res.writeHead(400); res.end('Bad request'); return;
      }
      const all   = readComments();
      const entry = all[file] && all[file][elementId] && all[file][elementId][index];
      if (!entry) { res.writeHead(404); res.end('Not found'); return; }
      all[file][elementId][index].resolved = true;
      writeComments(all);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true }));
    } catch { res.writeHead(400); res.end('Bad request'); }
    return;
  }

  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(html());
});

server.listen(PORT, '127.0.0.1', () => {
  const port    = server.address().port;
  const pidFile = path.join(PROJECT_DIR, '.camunda', 'bpmn-viewer.pid');
  console.log(JSON.stringify({ type: 'server-started', port, url: `http://localhost:${port}`, pid_file: pidFile }));
  try {
    fs.mkdirSync(path.join(PROJECT_DIR, '.camunda'), { recursive: true });
    fs.writeFileSync(pidFile, String(process.pid));
  } catch {}
});

process.on('SIGTERM', () => {
  try { fs.unlinkSync(path.join(PROJECT_DIR, '.camunda', 'bpmn-viewer.pid')); } catch {}
  process.exit(0);
});
