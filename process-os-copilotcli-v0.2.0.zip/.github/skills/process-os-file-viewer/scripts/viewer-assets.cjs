/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';
// The bpmn-js / dmn-js / form-js browser bundles the preview skills render with.
//
// These are declared dependencies in the root package.json and are installed
// into `.camunda/node_modules` by the c8 os plugin, exactly like every other
// skill runtime dep. They are resolved from there and served from the skill's
// own localhost server (or copied into a generated package) — never fetched from
// a CDN, so ProcessOS needs no third-party host on a customer allowlist and the
// versions travel in package-lock.json with npm's own integrity hashes.
//
// The `.production.min.js` builds are self-contained: each one inlines the
// diagram-js / preact / feelin tree it was compiled from, so serving the single
// file is enough — nothing resolves further imports at run time.

const fs = require('fs');
const path = require('path');

/** Packages a `/vendor/...` request is allowed to reach, and nothing else. */
const PACKAGES = ['bpmn-js', 'dmn-js', '@bpmn-io/form-js'];

/**
 * Files each viewer needs, as `<package>/<path within the package>`.
 *
 * Both diagram viewers list bpmn-js's `diagram-js.css`. It carries the `.djs-*`
 * foundations — connections, bendpoints, drag cursors — that `dmn-js-drd.css`
 * assumes rather than defines, so a page showing only a DMN file needs it just as
 * much as a BPMN one; `assetUrls` emits it once when both groups are requested.
 * dmn-js ships its own copy built from an older diagram-js, and the two differ
 * only by rules bpmn-js adds (modeller popup tabs, absent from a navigated viewer)
 * plus five property tweaks — so taking one avoids two stylesheets fighting over
 * the same selectors where a BPMN and a DMN file share a document.
 */
const ASSETS = {
  bpmn: {
    scripts: ['bpmn-js/dist/bpmn-navigated-viewer.production.min.js'],
    styles: ['bpmn-js/dist/assets/diagram-js.css', 'bpmn-js/dist/assets/bpmn-js.css'],
  },
  dmn: {
    scripts: ['dmn-js/dist/dmn-navigated-viewer.production.min.js'],
    // dmn-font/css/dmn.css pulls its font files with `url('../font/dmn.woff')`,
    // relative to itself — which resolves under the same `/vendor/dmn-js/...`
    // prefix, so the font needs no entry of its own here.
    styles: [
      'bpmn-js/dist/assets/diagram-js.css',
      'dmn-js/dist/assets/dmn-js-shared.css',
      'dmn-js/dist/assets/dmn-js-drd.css',
      'dmn-js/dist/assets/dmn-js-decision-table.css',
      'dmn-js/dist/assets/dmn-js-decision-table-controls.css',
      'dmn-js/dist/assets/dmn-js-literal-expression.css',
      'dmn-js/dist/assets/dmn-font/css/dmn.css',
    ],
  },
  form: {
    scripts: ['@bpmn-io/form-js/dist/form-viewer.umd.js'],
    styles: ['@bpmn-io/form-js/dist/assets/form-js.css'],
  },
};

const CONTENT_TYPES = {
  // The LICENSE files have no extension; path.extname reports '' for them.
  '': 'text/plain; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.eot': 'application/vnd.ms-fontobject',
  '.svg': 'image/svg+xml',
};

/** URL prefix the viewer servers mount these files under. */
const VENDOR_PREFIX = '/vendor/';

/**
 * The license file every viewer package ships at its own root.
 *
 * The license file is the authoritative text named by each package's manifest, and
 * the bpmn.io terms it carries require the notice to travel with any copy of a
 * bundle. It is resolved and served exactly like a script or a stylesheet so both
 * consumers get it from the same table, rather than one of them reaching into
 * node_modules on its own.
 */
const LICENSE_FILE = 'LICENSE';

/**
 * The `node_modules` holding the viewer packages, resolved against a project
 * root (the cwd, unless a caller names one).
 *
 * `.camunda/node_modules` is where the c8 os plugin installs them and so is
 * tried first; a project-root `node_modules` is the fallback that makes this
 * work in the ProcessOS repo itself. Returns the preferred candidate when
 * neither exists, so the caller's own "run c8 os install" check reports the
 * path a user should be looking at.
 */
function nodeModulesDir(cwd = process.cwd()) {
  const candidates = [
    path.join(cwd, '.camunda', 'node_modules'),
    path.join(cwd, 'node_modules'),
  ];
  return candidates.find((dir) => fs.existsSync(dir)) || candidates[0];
}

/**
 * The packages the named viewers need, in {@link PACKAGES} order.
 *
 * Derived from the asset table rather than listed again, so it stays true as
 * assets move between packages — `dmn` needs bpmn-js as well as dmn-js, because
 * it takes `diagram-js.css` from there.
 */
function packagesFor(kinds) {
  const needed = new Set();
  for (const kind of kinds) {
    const group = ASSETS[kind];
    if (!group) throw new Error(`unknown viewer: ${kind}`);
    for (const id of [...group.styles, ...group.scripts]) {
      needed.add(PACKAGES.find((pkg) => id === pkg || id.startsWith(`${pkg}/`)));
    }
  }
  return PACKAGES.filter((pkg) => needed.has(pkg));
}

/**
 * The packages that are not installed — every viewer package, or only the ones
 * the named viewers need.
 *
 * A caller that renders one viewer passes its kinds, so it neither stats
 * packages it will never read nor refuses to run over one it does not need.
 */
function missingPackages(nmDir = nodeModulesDir(), kinds) {
  const packages = kinds ? packagesFor(kinds) : PACKAGES;
  return packages.filter((pkg) => !fs.existsSync(path.join(nmDir, pkg, 'dist')));
}

/**
 * Absolute path of one `<package>/<path>` asset id.
 *
 * Throws on an id that escapes its package or names a package outside
 * {@link PACKAGES} — this resolves untrusted request paths, so containment is
 * checked on the resolved path rather than by inspecting the id for `..`.
 */
function resolveAsset(assetId, nmDir = nodeModulesDir()) {
  const pkg = PACKAGES.find((p) => assetId === p || assetId.startsWith(`${p}/`));
  if (!pkg) throw new Error(`not a viewer asset package: ${assetId}`);

  const pkgRoot = path.resolve(nmDir, pkg);
  const abs = path.resolve(pkgRoot, assetId.slice(pkg.length + 1));
  if (abs !== pkgRoot && !abs.startsWith(pkgRoot + path.sep)) {
    throw new Error(`asset path escapes ${pkg}: ${assetId}`);
  }
  // Only the prebuilt bundles and the package's own LICENSE are servable —
  // never its sources or its package.json.
  const servable =
    abs.startsWith(path.join(pkgRoot, 'dist') + path.sep) ||
    abs === path.join(pkgRoot, LICENSE_FILE);
  if (!servable) {
    throw new Error(`asset path is neither dist/ nor ${LICENSE_FILE}: ${assetId}`);
  }
  return abs;
}

/** The `<script>`/`<link>` URLs for the named viewers, in load order. */
function assetUrls(kinds) {
  const styles = [];
  const scripts = [];
  for (const kind of kinds) {
    const group = ASSETS[kind];
    if (!group) throw new Error(`unknown viewer: ${kind}`);
    for (const id of group.styles) if (!styles.includes(id)) styles.push(id);
    for (const id of group.scripts) if (!scripts.includes(id)) scripts.push(id);
  }
  return {
    styles: styles.map((id) => VENDOR_PREFIX + id),
    scripts: scripts.map((id) => VENDOR_PREFIX + id),
  };
}

/** The `<link>`/`<script>` tags for the named viewers, ready to inline. */
function assetTags(kinds) {
  const { styles, scripts } = assetUrls(kinds);
  return [
    ...styles.map((u) => `<link rel="stylesheet" href="${u}">`),
    ...scripts.map((u) => `<script src="${u}"></script>`),
  ].join('\n');
}

/**
 * Answer a `/vendor/...` request from `.camunda/node_modules`.
 *
 * Returns false when the path is not a vendor request, so a server can fall
 * through to its own routes. A vendor request that resolves nowhere is answered
 * 404 here rather than handed back, so a typo cannot fall through to another
 * route that happens to match.
 */
function serveAsset(pathname, res, nmDir = nodeModulesDir()) {
  if (!pathname.startsWith(VENDOR_PREFIX)) return false;

  let abs;
  try {
    abs = resolveAsset(decodeURIComponent(pathname.slice(VENDOR_PREFIX.length)), nmDir);
  } catch {
    res.writeHead(404);
    res.end('Not found');
    return true;
  }

  try {
    const body = fs.readFileSync(abs);
    res.writeHead(200, {
      'Content-Type': CONTENT_TYPES[path.extname(abs).toLowerCase()] || 'application/octet-stream',
      'Content-Length': body.length,
    });
    res.end(body);
  } catch {
    res.writeHead(404);
    res.end('Not found');
  }
  return true;
}

/**
 * Copy the named viewers' files into `destDir`, flattened to their basenames,
 * and return those basenames split into styles and scripts.
 *
 * `writeFile(dest, buffer)` overrides how each file is written, so a caller that
 * routes all of its output through one writer keeps doing so.
 *
 * This is the offline path: a generated package carries its own copy of the
 * viewer so it opens with no network at all. Flattening is safe only because no
 * copied file resolves a relative sibling — which is why the `dmn` group, whose
 * CSS pulls a font directory, must not be copied this way.
 *
 * Every copied bundle brings its package's LICENSE with it, under the name
 * {@link licenseFileName} gives it, and the returned `licenses` entries carry
 * what a THIRD-PARTY-NOTICES file needs to name them. A bundle is a substantial
 * portion of the software and the package travels to a third party, so the
 * notice is not the caller's to remember.
 */
function copyAssets(kinds, destDir, { nmDir = nodeModulesDir(), writeFile } = {}) {
  for (const kind of kinds) {
    if (kind === 'dmn') {
      throw new Error('the dmn viewer assets cannot be flattened: its CSS resolves a relative font directory');
    }
  }
  const write = writeFile || ((dest, data) => fs.writeFileSync(dest, data));
  const { styles, scripts } = assetUrls(kinds);
  const copy = (url) => {
    const abs = resolveAsset(url.slice(VENDOR_PREFIX.length), nmDir);
    const base = path.basename(abs);
    write(path.join(destDir, base), fs.readFileSync(abs));
    return base;
  };
  const licenses = packageNotices(kinds, nmDir);
  for (const notice of licenses) {
    write(path.join(destDir, notice.file), fs.readFileSync(resolveAsset(notice.assetId, nmDir)));
  }
  return { styles: styles.map(copy), scripts: scripts.map(copy), licenses };
}

/**
 * The flattened filename one package's LICENSE is copied out under.
 *
 * Every package ships the file as plain `LICENSE`, so copying three of them
 * into one directory needs the package name in the filename or they overwrite
 * each other silently.
 */
function licenseFileName(pkg) {
  return `LICENSE-${pkg.replace(/^@/, '').replace(/\//g, '-')}`;
}

/**
 * Name, version, license declaration and LICENSE asset of every package the
 * named viewers read, in {@link PACKAGES} order.
 *
 * The version and the declaration are read from the installed package.json
 * rather than listed here, so a dependency bump cannot leave a notice claiming
 * a version that is no longer what ships.
 */
function packageNotices(kinds, nmDir = nodeModulesDir()) {
  return packagesFor(kinds).map((pkg) => {
    const manifest = JSON.parse(fs.readFileSync(path.join(nmDir, pkg, 'package.json'), 'utf8'));
    return {
      package: pkg,
      version: manifest.version,
      license: manifest.license,
      assetId: `${pkg}/${LICENSE_FILE}`,
      file: licenseFileName(pkg),
    };
  });
}

/**
 * The THIRD-PARTY-NOTICES text for the given {@link packageNotices} entries.
 *
 * Written for a reader outside Camunda opening an unzipped package: it names
 * each package and points at the license file copied alongside it, under
 * `licenseDir` — the package-relative directory the caller copied them into —
 * because `SEE LICENSE IN LICENSE` is not something a reader can look up.
 */
function renderThirdPartyNotices(notices, { licenseDir = '' } = {}) {
  const lines = [
    'THIRD-PARTY NOTICES',
    '',
    'This package embeds the following third-party software. Each one is',
    'distributed under the license in the named file, reproduced verbatim from',
    'the package as installed.',
    '',
  ];
  for (const notice of notices) {
    lines.push(`${notice.package} ${notice.version}`);
    lines.push(`  license declared as: ${notice.license}`);
    lines.push(`  license text: ${licenseDir ? `${licenseDir}/` : ''}${notice.file}`);
    lines.push('');
  }
  return lines.join('\n');
}

module.exports = {
  ASSETS,
  CONTENT_TYPES,
  LICENSE_FILE,
  PACKAGES,
  VENDOR_PREFIX,
  assetTags,
  assetUrls,
  copyAssets,
  licenseFileName,
  missingPackages,
  nodeModulesDir,
  packageNotices,
  packagesFor,
  renderThirdPartyNotices,
  resolveAsset,
  serveAsset,
};
