#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Stop the BPMN viewer server started by start-bpmn-viewer.cjs.
//
// Usage:
//   node "scripts/stop-bpmn-viewer.cjs" [--project-dir <dir>]
//
// Exits 0 whether or not a viewer was running, so it is safe to call
// unconditionally during cleanup.

const path = require('path');
const { parseArgs, stop, pidFilePath } = require(
  path.join(__dirname, 'detached-server.cjs'),
);

const { projectDir } = parseArgs(process.argv.slice(2));

process.exitCode = stop({
  pidFile: pidFilePath(projectDir, 'bpmn-viewer.pid'),
  label: 'BPMN viewer',
});
