#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Start the BPMN viewer server, detached, and wait until it is ready.
//
// Usage:
//   node "scripts/start-bpmn-viewer.cjs" [--project-dir <dir>] [--file <path>]
//
// Prints the server's `server-started` JSON (with the URL) on stdout, or an
// `already-running` / `error` JSON on stderr. Exit 0 when the viewer is up,
// 1 when it failed to start.

const path = require('path');
const { parseArgs, start, pidFilePath } = require(
  path.join(__dirname, 'detached-server.cjs'),
);

const { projectDir, file } = parseArgs(process.argv.slice(2));

start({
  serverEntry: path.join(__dirname, 'bpmn-viewer.cjs'),
  // The viewer takes the file to open as a positional argument.
  serverArgs: file ? [file] : [],
  pidFile: pidFilePath(projectDir, 'bpmn-viewer.pid'),
  projectDir,
  // Port 0 lets the OS pick a free port; the server reports which one it got.
  env: { VIEWER_PORT: '0' },
  label: 'BPMN viewer',
}).then((code) => {
  process.exitCode = code;
});
