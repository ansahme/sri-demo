---
name: process-os-governance-start
description: >-
  Start a ProcessOS governance run. Configures the Camunda cluster connection
  when none exists (local / SaaS / self-managed), finds active governance
  process instances, and either attaches to one or deploys the governance
  artifacts and creates a new one. Use as the first command of an engagement,
  and to re-enter one on a machine that has no instance recorded yet.
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
Read [the c8ctl guide](references/c8ctl.md) for the full c8ctl command reference.

Parse skill arguments:
- `--reconnect` → reconfigure the cluster connection even when one is already recorded. Without it,
  an existing connection is used as-is.

---

## EXEC: Phase 0 — Read Governance State

```bash
node ".github/skills/process-os-governance-start/scripts/make-dir.cjs" .camunda
node ".github/skills/process-os-governance-start/scripts/governance-state.cjs" read
```

`make-dir` runs first because `governance-state.cjs` locates the project root by looking for a
`.camunda/` directory and exits `2` when there is none. `read` itself tolerates a missing
`governance.json` and returns every key as `null`, so no separate existence probe is needed.

Extract `cluster`, `c8ctl-profile`, `project-name`, and `instance-key` from the JSON output and use
them throughout this skill.

Print the status table before asking anything:

```text
Governance Start

  Cluster connection  ✓ local (profile: local)
  Instance key        ? none recorded
  Project name        ✓ acme-invoice-processing

Recommended next action: look for an active governance process instance.
```

Use `✓` for a recorded value, `?` for `null`. State the recommended next action the route below
actually takes — "configure the cluster connection" when heading to Phase 1a, "look for an active
governance process instance" when heading to Phase 2. Then route:

- `cluster` and `c8ctl-profile` both non-null, and `--reconnect` not given → **Phase 2**.
- Otherwise → **Phase 1a**.

---

## GATE: Phase 1a — Confirm Re-connection

_Only when `cluster` is already non-null — that is, `--reconnect` was given._

Show the current state and ask the user to confirm:

```
A governance connection is already configured:

  cluster:       <cluster>
  c8ctl-profile: <c8ctl-profile>
  instance-key:  <instance-key>   (— if not set)

Re-connecting will overwrite all governance state. Continue? (yes/no)
```

If the user answers **no**: stop here.

If the user answers **yes**, remove the file and continue to Phase 1b:

```bash
node ".github/skills/process-os-governance-start/scripts/remove-path.cjs" .camunda/governance.json
```

**Discard every value read in Phase 0 at this point** — `cluster`, `c8ctl-profile`, `project-name`,
and `instance-key` are all gone from state and none of them may be carried forward. Treat
`project-name` in particular as unset: reusing the old one silently skips Phase 4a, which both names
the new instance after the previous run and leaves `project-name` null in the rebuilt state file.
`process-os-governance-job-activation` builds its job type from that value, so a null there means no
job ever activates.

---

## AI: Phase 1b — Choose Cluster Type

Ask the user:

```
Which cluster type do you want to connect to?

  1. local          — C8 Run via c8ctl (no credentials needed)
  2. saas           — Camunda SaaS (interactive credential setup via c8ctl)
  3. self-managed   — Self-managed Camunda cluster (interactive credential setup via c8ctl)
```

Wait for the user's answer before proceeding. Accept `1`, `2`, `3`, or the words `local`, `saas`,
`self-managed`.

- **local** → Phase 1c
- **saas** or **self-managed** → Phase 1d

---

## EXEC: Phase 1c — Verify a Local Cluster

_Only when the user chose **local**._

Run the local-cluster check described in [Local Cluster Check](#execgate-local-cluster-check) below. When
the cluster is running, continue to Phase 1f with `cluster = local` and `c8ctl-profile = local`.

---

## GATE: Phase 1d — Connect a SaaS or Self-Managed Cluster

_Only when the user chose **saas** or **self-managed**._

Read [the SaaS connection reference](references/saas-connection.md) and follow it. It adds the
c8ctl profile (credentials stay inside c8ctl) and validates it against the cluster, then returns
here with `cluster` and `c8ctl-profile` resolved.

If it stops without a valid connection, stop here too — do not write state.

Otherwise continue to Phase 1f.

---

## EXEC: Phase 1f — Write Connection State

```bash
node ".github/skills/process-os-governance-start/scripts/governance-state.cjs" set cluster=<cluster> c8ctl-profile=<profile>
```

Substitute `<cluster>` and `<profile>` with the values resolved in Phase 1c or 1d. Continue to
Phase 2.

---

## EXEC: Phase 2 — Find Candidate Instances

```bash
c8ctl --json search pi --state ACTIVE --processDefinitionId process-os-governance --profile <c8ctl-profile>
```

Parse the JSON response into a list of instances. Each entry has at least `processInstanceKey` and
`startDate`.

Reconcile with the `instance-key` read in Phase 0: when it is non-null but absent from the query
results, it points at an instance that is no longer active. Drop it from the candidate list and say
so — do not offer it.

If the query cannot reach the cluster, print the c8ctl error and stop:

```
Could not reach the cluster using profile "<c8ctl-profile>".
c8ctl error: <error output>

Re-run with --reconnect to reconfigure the cluster connection.
```

Route: one or more candidates → **Phase 3**. None → **Phase 4a**.

---

## AI: Phase 3 — Attach or Create

**A choice.** Offer three kinds of option, and keep all three whichever way you present them —
a numbered text prompt and a native multiple-choice control are both fine:

1. One option per candidate instance, labelled with its `processInstanceKey` and `startDate`.
2. Start a new instance instead.
3. Cancel.

```
Active process-os-governance instances:

  1. key: <processInstanceKey>   started: <startDate>
  2. key: <processInstanceKey>   started: <startDate>
  …

  n. Start a new instance instead
  c. Cancel

Enter a number, "n", or "c":
```

Never drop an option to make the question fit a smaller control. With a single candidate the
temptation is a yes/no prompt — that silently removes both "start a new instance" and "cancel", and
is the exact failure this shape exists to prevent.

- A number → **Phase 5** with the chosen `processInstanceKey`
- `n` → **Phase 4a**
- `c` → stop here without writing state

---

## AI: Phase 4a — Collect the Project Name

If `project-name` is null in governance state, ask for it.

**Decide how to ask before asking: plain prose, never a tool-driven choice/selection control.** This
question has no preset options — none exist to offer. Reaching for a structured multiple-choice
mechanism here, including one still active from an earlier phase such as Phase 1b or Phase 3, fails
validation for having no valid options before the user ever sees the question, surfacing a tool
error the user should never see. State the prompt as ordinary conversational text and read the
free-text reply directly:

```
Enter the project name (e.g. "acme-invoice-processing"). This value becomes part of every governance job type Zeebe activates for this project (e.g. `acme-invoice-processing_process-os-job`).
```

Re-ask if the answer contains a double quote — it would corrupt the `--variables` JSON in Phase 4f.

Once known, write it to governance state:

```bash
node ".github/skills/process-os-governance-start/scripts/governance-state.cjs" set "project-name=<project-name>"
```

Keep the `key=value` pair inside double quotes. A project name with a space is otherwise split into
extra argv entries, and `governance-state.cjs` rejects them with `Unexpected argument(s)` (exit 1)
rather than writing anything.

Skip this step if already set.

---

## EXEC: Phase 4b — Check the Local Cluster

_Only when `c8ctl-profile` is `local`._

Run the local-cluster check described in [Local Cluster Check](#execgate-local-cluster-check) below, then
continue to Phase 4c.

---

## EXEC: Phase 4c — Compare the Deployed Definition

```bash
node ".github/skills/process-os-governance-start/scripts/governance-drift.cjs" --profile <c8ctl-profile>
```

Omit `--profile` when no profile is configured. The script prints one JSON object on stdout —
`state`, `version`, `processDefinitionKey`, `reason` — and its exit code carries the same verdict:

| Exit | `state` | Meaning |
|------|---------|---------|
| `0` | `match` | The deployed BPMN equals this bundle's. |
| `4` | `drift` | A definition is deployed and its BPMN differs. |
| `3` | `absent` | No definition carries the id `process-os-governance`. |
| `2` | `unknown` | The comparison could not be made — c8ctl did not launch, the XML could not be fetched, or the payload shape was not recognised. |
| `5` | `query-failed` | The search query itself failed; the cluster was not reached. |

On `query-failed`, print `reason` and stop — re-run with `--reconnect` to reconfigure the
connection. Every other state continues to Phase 4d.

Never read `unknown` as `match`. A comparison that did not run is no evidence the models agree.

The comparison covers `process-os-governance.bpmn` only. A changed form is invisible to it, which is
one more reason the deploy is offered in every state.

---

## GATE: Phase 4d — Offer the Deploy

A deployed definition can predate this bundle's governance artifacts, and an instance created from
it runs that older model for its whole lifetime. So the deploy is offered in every state; Phase 4c's
verdict decides the wording and the recommendation, never the control flow.

Show what a deploy would publish:

```bash
node ".github/skills/process-os-governance-start/scripts/deploy-governance-artifacts.cjs" --profile <c8ctl-profile> --dry-run
```

Then ask, opening with the line for the state:

| State | Opening line | Recommend |
|-------|--------------|-----------|
| `absent` | `No process-os-governance definition is deployed on this cluster.` | deploy |
| `drift` | `Version <N> is deployed, and it differs from the governance BPMN in this ProcessOS bundle.` | deploy |
| `match` | `Version <N> is deployed, and its BPMN matches this ProcessOS bundle.` | skip |
| `unknown` | `Version <N> is deployed, but it could not be compared with this bundle: <reason>` | deploy |

```
<opening line>

Deploying publishes the governance artifacts of this ProcessOS bundle:

<dry-run output>

Camunda creates a new version only when a resource's content changed, so
deploying unchanged artifacts leaves the version number alone.

Recommended: <deploy | skip>. Deploy? (yes/no)
```

Route on the answer:

- **yes** → **Phase 4e**.
- **no**, and the state is not `absent` → **Phase 4f**. Say which version the instance will run, and
  on `drift` that it does not carry this bundle's changes.
- **no**, and the state is `absent` → stop here. An instance needs a definition.

---

## EXEC: Phase 4e — Deploy Governance Artifacts

```bash
node ".github/skills/process-os-governance-start/scripts/deploy-governance-artifacts.cjs" --profile <c8ctl-profile>
```

Exit `0` is a successful deploy. Exit `2` means c8ctl produced no deploy verdict at all — it could
not be launched, or a signal killed it mid-run; report that as a failure to run, not as a failed
deploy. Any other exit code is c8ctl's own.

If deployment fails for any reason, print the error and stop — do not create an instance.

---

## GATE: Phase 4f — Confirm Instance Creation

```bash
c8ctl --json create pi --id process-os-governance --variables '{"projectName":"<project-name>"}' --profile <c8ctl-profile> --dry-run
```

Substitute `<project-name>` with the value resolved in Phase 0 or 4a. Present the dry-run output
and ask for confirmation:

```
The following process instance will be created:

<dry-run output>

Proceed? (yes/no)
```

If **no**: stop here without creating an instance. If **yes**: continue to Phase 4g.

---

## EXEC: Phase 4g — Start the Process Instance

```bash
c8ctl --json create pi --id process-os-governance --variables '{"projectName":"<project-name>"}' --profile <c8ctl-profile>
node ".github/skills/process-os-governance-start/scripts/governance-state.cjs" set instance-key=<processInstanceKey>
```

Run the first command, and if it fails, print the error and stop. On success parse
`processInstanceKey` from the JSON response and substitute it into the second command.

Continue to Phase 6, reporting the instance as **created**.

---

## EXEC: Phase 5 — Attach to the Chosen Instance

Fetch `projectName` from the chosen instance and write both values to governance state:

```bash
c8ctl --json search variables --processInstanceKey <processInstanceKey> --name projectName --profile <c8ctl-profile>
node ".github/skills/process-os-governance-start/scripts/governance-state.cjs" set instance-key=<processInstanceKey> "project-name=<projectName>"
```

`<projectName>` comes off a live process instance, so its content is not under this skill's control
— keep the pair double-quoted so a name containing spaces is one argv entry rather than
`Unexpected argument(s)` (exit 1).

Continue to Phase 6, reporting the instance as **attached**.

---

## AI: Phase 6 — Report

Print:

```
Governance run ready.

  cluster:      <cluster> (profile: <c8ctl-profile>)
  process:      process-os-governance
  instance key: <processInstanceKey>   (created | attached)
  project name: <project-name>

Run /process-os-governance-job-activation to work the next job.
```

---

## EXEC/GATE: Local Cluster Check

Used by Phase 1c and Phase 4b.

```bash
c8ctl --json cluster status
```

The cluster is running when the JSON contains a non-null `version` field or `state` equal to
`running`, or when the plain-text output contains the word "running".

If it is **not running**, ask the user:

```
No local cluster detected. Start it now?

  1. Yes — start it for me
  2. No — I'll start it myself (run: c8ctl cluster start)
```

- **Yes** → run `c8ctl --json cluster start`, wait for it to complete, then re-check.
- **No** → stop and wait for the user to say they are done, then re-check.

Return to the calling phase once the cluster is running.
