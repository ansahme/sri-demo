#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Deploy the governance BPMN/form artifacts bundled alongside this skill.
//
// Usage:
//   node "scripts/deploy-governance-artifacts.cjs" [--profile <name>] [--dry-run]
//
// Every argument is forwarded verbatim to `c8ctl deploy`, so any flag c8ctl
// accepts works here.
//
// Exit codes: c8ctl's own exit code, or 2 when c8ctl produced no deploy verdict
// at all — it could not be launched, or a signal killed it mid-run. A caller
// must be able to tell those from a deploy that ran and failed, because a spawn
// that never finished is not a failed deploy.
//
// c8ctl goes through runShellCli, not a bare spawnSync: on Windows it exists
// only as c8ctl.cmd/.ps1, which spawnSync cannot exec, so a bare spawn reports
// ENOENT on a machine where `c8ctl --version` works fine. runShellCli applies a
// shell on Windows only, and settles "is it on PATH" with findOnPath first, so
// not-installed stays distinguishable from a shell's own failure exit.

const path = require('path');
const { runShellCli } =
  require(path.join(__dirname, 'resolve-node-cli.cjs'));

const ARTIFACTS_DIR = path.join(__dirname, '..', 'camunda-artifacts', 'governance');

/**
 * Map a CliRunResult to this script's exit code and stderr lines.
 *
 * Both no-verdict cases exit 2, but they are not the same failure and must not
 * claim to be: a signal killed a c8ctl that really did start, so the "is it
 * installed?" hint belongs only on the launch-failure branch.
 *
 * @param {{launched: boolean, error?: Error, status: number | null, signal?: string | null}} result
 * @returns {{code: number, messages: string[]}}
 */
function classify(result) {
  if (!result.launched && result.signal) {
    return {
      code: 2,
      messages: [
        `deploy-governance-artifacts: c8ctl was terminated by signal ${result.signal} — the deploy did not complete.`,
      ],
    };
  }
  if (!result.launched) {
    return {
      code: 2,
      messages: [
        `deploy-governance-artifacts: could not run c8ctl — ${result.error ? result.error.message : 'it did not start'}`,
        'Install c8ctl and ensure it is on PATH, then re-run.',
      ],
    };
  }
  return { code: result.status, messages: [] };
}

if (require.main === module) {
  const args = ['--json', 'deploy', ARTIFACTS_DIR, ...process.argv.slice(2)];

  // stdio is inherited rather than captured: c8ctl writes progress lines to
  // stderr even on success, so capturing and inspecting them would misread a
  // healthy deploy as a failure. The exit code is the only success signal.
  const { code, messages } = classify(runShellCli('c8ctl', args, { stdio: 'inherit' }));

  for (const message of messages) process.stderr.write(`${message}\n`);
  process.exitCode = code;
}

module.exports = { classify, ARTIFACTS_DIR };
