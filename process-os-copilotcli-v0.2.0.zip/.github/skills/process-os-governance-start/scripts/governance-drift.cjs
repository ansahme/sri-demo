#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Compare the governance process definition deployed on a cluster against the
// BPMN bundled alongside this skill.
//
// Usage:
//   node "scripts/governance-drift.cjs" [--profile <name>]
//
// One JSON object on stdout, always:
//   {"state": "...", "version": <number|null>, "processDefinitionKey": "<key>|null",
//    "reason": "<human-readable>"}
//
// Exit codes, one per state:
//   0  match         the deployed BPMN equals the bundled BPMN
//   4  drift         a definition is deployed and its BPMN differs
//   3  absent        no definition carries this id
//   2  unknown       the comparison could not be made (c8ctl did not launch, the
//                    XML could not be fetched, or no output shape was recognised)
//   5  query-failed  the search query itself failed — the cluster was not reached
//
// "unknown" is never folded into "match": a comparison that did not run is no
// evidence the models agree, and a caller that reads it as agreement skips a
// deploy it should have offered. "query-failed" stays separate from "unknown"
// because it means the cluster answered nothing at all, which is a reason to
// stop rather than to carry on with a weaker recommendation.
//
// c8ctl goes through runShellCli, not a bare spawnSync: on Windows it exists
// only as c8ctl.cmd/.ps1, which spawnSync cannot exec, so a bare spawn reports
// ENOENT on a machine where `c8ctl --version` works fine.
//
// The child's streams are captured separately and only stdout is parsed. c8ctl
// narrates progress on stderr even on success, so a merged capture puts those
// lines in front of the JSON.

const fs = require('node:fs');
const path = require('node:path');
const { runShellCli } =
  require(path.join(__dirname, 'resolve-node-cli.cjs'));
const { stripBOM } = require(path.join(__dirname, 'strip-bom.cjs'));

const PROCESS_DEFINITION_ID = 'process-os-governance';
const LOCAL_BPMN = path.join(
  __dirname, '..', 'camunda-artifacts', 'governance', 'process-os-governance.bpmn');

const EXIT = { MATCH: 0, UNKNOWN: 2, ABSENT: 3, DRIFT: 4, QUERY_FAILED: 5 };
const STATE_EXIT = {
  match: EXIT.MATCH,
  unknown: EXIT.UNKNOWN,
  absent: EXIT.ABSENT,
  drift: EXIT.DRIFT,
  'query-failed': EXIT.QUERY_FAILED,
};

/**
 * Pull the process-definition records out of a c8ctl `--json search pd` payload.
 *
 * The payload is accepted in any of the shapes c8ctl emits — a bare array, an
 * envelope carrying `items`, or one JSON document per line — because the shape
 * is c8ctl's to change and a wrong guess here would read as "nothing deployed".
 * An unrecognised shape returns null rather than an empty list for that reason.
 *
 * @param {string} stdout Raw stdout of the search call.
 * @returns {Array<Object>|null} The records, or null when no shape matched.
 */
function parseDefinitions(stdout) {
  const text = stripBOM(stdout || '').trim();
  if (!text) return null;

  const documents = [];
  try {
    documents.push(JSON.parse(text));
  } catch {
    for (const line of text.split('\n')) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      try {
        documents.push(JSON.parse(trimmed));
      } catch {
        return null;
      }
    }
  }
  if (documents.length === 0) return null;

  const records = [];
  let recognised = false;
  for (const document of documents) {
    const list = recordList(document);
    if (list === null) continue;
    recognised = true;
    records.push(...list);
  }
  return recognised ? records : null;
}

/**
 * The definition records one parsed JSON document stands for.
 *
 * @param {unknown} document One parsed JSON document.
 * @returns {Array<Object>|null} Its records, or null when it carries none.
 */
function recordList(document) {
  if (Array.isArray(document)) return document.filter(isDefinitionRecord);
  if (!document || typeof document !== 'object') return null;
  for (const key of ['items', 'processDefinitions', 'results']) {
    if (Array.isArray(document[key])) return document[key].filter(isDefinitionRecord);
  }
  if (document.result && typeof document.result === 'object') return recordList(document.result);
  if (isDefinitionRecord(document)) return [document];
  return null;
}

// c8ctl's --json records carry the display column labels it prints in table
// mode ("Key", "Version"), not the API's camelCase field names. Both spellings
// are read so neither a relabelled column nor a raw API payload reads as
// "nothing deployed".
const KEY_FIELDS = ['processDefinitionKey', 'Key', 'key'];
const VERSION_FIELDS = ['version', 'Version'];
const PROCESS_ID_FIELDS = ['processDefinitionId', 'Process ID', 'processId'];

/**
 * The first value a record carries under any of the given field names.
 *
 * @param {Object} record A definition record.
 * @param {string[]} names The accepted spellings, most specific first.
 * @returns {unknown} The value, or undefined when the record carries none.
 */
function field(record, names) {
  for (const name of names) {
    if (record[name] !== undefined) return record[name];
  }
  return undefined;
}

/**
 * The version a record states, as a number.
 *
 * @param {Object} record A definition record.
 * @returns {number|null} The version, or null when it is absent or unparsable.
 */
function recordVersion(record) {
  const value = Number(field(record, VERSION_FIELDS));
  return Number.isFinite(value) ? value : null;
}

/**
 * The definition key a record states.
 *
 * @param {Object} record A definition record.
 * @returns {string|null} The key, or null when the record carries none.
 */
function recordKey(record) {
  const value = field(record, KEY_FIELDS);
  return value === undefined || value === null ? null : String(value);
}

/**
 * Whether a value looks like a process-definition record for the governance
 * process rather than one of c8ctl's status lines.
 *
 * A record naming a different process is dropped, so a search whose filter was
 * ignored cannot be compared against the wrong model.
 *
 * @param {unknown} value A parsed JSON value.
 * @returns {boolean} True when it carries a definition key or a version.
 */
function isDefinitionRecord(value) {
  if (!value || typeof value !== 'object') return false;
  const processId = field(value, PROCESS_ID_FIELDS);
  if (processId !== undefined && String(processId) !== PROCESS_DEFINITION_ID) return false;
  return field(value, KEY_FIELDS) !== undefined || field(value, VERSION_FIELDS) !== undefined;
}

/**
 * The highest-versioned record in a list.
 *
 * @param {Array<Object>} records Definition records.
 * @returns {Object|null} The latest record, or null when the list is empty.
 */
function latest(records) {
  let best = null;
  let bestVersion = null;
  for (const record of records) {
    const version = recordVersion(record);
    if (version === null) continue;
    if (best === null || version > bestVersion) {
      best = record;
      bestVersion = version;
    }
  }
  return best || records[0] || null;
}

/**
 * Pull the BPMN XML out of a c8ctl `--json get pd <key> --xml` payload.
 *
 * @param {string} stdout Raw stdout of the fetch call.
 * @returns {string|null} The XML, or null when no shape matched.
 */
function extractXml(stdout) {
  const text = stripBOM(stdout || '').trim();
  if (!text) return null;
  if (text.startsWith('<')) return text;

  const documents = [];
  try {
    documents.push(JSON.parse(text));
  } catch {
    for (const line of text.split('\n')) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      try {
        documents.push(JSON.parse(trimmed));
      } catch {
        return null;
      }
    }
  }
  for (const document of documents) {
    if (typeof document === 'string' && document.trim().startsWith('<')) return document;
    if (!document || typeof document !== 'object') continue;
    for (const key of ['xml', 'bpmnXml', 'resource', 'processDefinitionXml', 'resourceXml']) {
      if (typeof document[key] === 'string' && document[key].trim().startsWith('<')) {
        return document[key];
      }
    }
  }
  return null;
}

/**
 * Normalise BPMN XML for comparison.
 *
 * Only line endings and surrounding whitespace are normalised. Anything more
 * aggressive would hide a real difference, and the cost of an over-strict
 * comparison is only an offered deploy that Camunda then turns into a no-op.
 *
 * @param {string} xml BPMN XML.
 * @returns {string} The comparable form.
 */
function normalizeXml(xml) {
  return stripBOM(xml)
    .replace(/\r\n/g, '\n')
    .split('\n')
    .map((line) => line.replace(/[ \t]+$/, ''))
    .join('\n')
    .trim();
}

/**
 * Build the result an exit code and a stdout line are derived from.
 *
 * @param {'match'|'drift'|'absent'|'unknown'|'query-failed'} state The verdict.
 * @param {string} reason One sentence a user can act on.
 * @param {{version?: number|null, processDefinitionKey?: string|null}} [details] Deployed identity.
 * @returns {{state: string, version: number|null, processDefinitionKey: string|null, reason: string}}
 */
function verdict(state, reason, details = {}) {
  return {
    state,
    version: details.version ?? null,
    processDefinitionKey: details.processDefinitionKey ?? null,
    reason,
  };
}

/**
 * Run one c8ctl call with both streams captured.
 *
 * @param {string[]} args Arguments after the command name.
 * @param {string|undefined} profile The c8ctl profile, when one is configured.
 * @param {typeof runShellCli} [run] Injected for tests.
 * @returns {{launched: boolean, status: number|null, error?: Error, signal: string|null, stdout: string, stderr: string}}
 */
function callC8ctl(args, profile, run = runShellCli) {
  const full = ['--json', ...args];
  if (profile) full.push('--profile', profile);
  const result = run('c8ctl', full, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
  return { ...result, stdout: result.stdout || '', stderr: result.stderr || '' };
}

/**
 * Compare the deployed definition against the bundled BPMN.
 *
 * @param {{profile?: string, localXml: string, run?: typeof runShellCli}} options Inputs.
 * @returns {{state: string, version: number|null, processDefinitionKey: string|null, reason: string}}
 */
function detect({ profile, localXml, run }) {
  const search = callC8ctl(
    ['search', 'pd', '--processDefinitionId', PROCESS_DEFINITION_ID], profile, run);

  if (!search.launched) {
    const detail = search.signal
      ? `c8ctl was terminated by signal ${search.signal}`
      : `could not run c8ctl — ${search.error ? search.error.message : 'it did not start'}`;
    return verdict('unknown', `${detail}; the deployed definition was never read.`);
  }
  if (search.status !== 0) {
    return verdict('query-failed',
      `c8ctl could not search process definitions (exit ${search.status}): ${firstLine(search.stderr)}`);
  }

  const records = parseDefinitions(search.stdout);
  if (records === null) {
    return verdict('unknown',
      'c8ctl returned a search payload in an unrecognised shape; the deployed definition was never read.');
  }
  if (records.length === 0) {
    return verdict('absent', `No ${PROCESS_DEFINITION_ID} definition is deployed on this cluster.`);
  }

  const record = latest(records);
  const version = recordVersion(record);
  const key = recordKey(record);
  const identity = { version, processDefinitionKey: key };

  if (!key) {
    return verdict('unknown',
      'The deployed definition carries no definition key, so its BPMN could not be fetched.',
      identity);
  }

  const fetch = callC8ctl(['get', 'pd', key, '--xml'], profile, run);
  if (!fetch.launched || fetch.status !== 0) {
    return verdict('unknown',
      `The deployed BPMN could not be fetched: ${firstLine(fetch.stderr) || 'c8ctl produced no verdict'}.`,
      identity);
  }

  const deployedXml = extractXml(fetch.stdout);
  if (deployedXml === null) {
    return verdict('unknown',
      'c8ctl returned no BPMN XML for the deployed definition, so it could not be compared.',
      identity);
  }

  if (normalizeXml(deployedXml) === normalizeXml(localXml)) {
    return verdict('match',
      `Version ${version ?? '?'} matches the governance BPMN in this ProcessOS bundle.`, identity);
  }
  return verdict('drift',
    `Version ${version ?? '?'} differs from the governance BPMN in this ProcessOS bundle.`, identity);
}

/**
 * The first non-empty line of a captured stream.
 *
 * @param {string} text Captured stderr.
 * @returns {string} One line, or an empty string.
 */
function firstLine(text) {
  for (const line of String(text || '').split('\n')) {
    if (line.trim()) return line.trim();
  }
  return '';
}

/**
 * Read `--profile <name>` out of argv.
 *
 * @param {string[]} argv Arguments after the script path.
 * @returns {{profile: string|undefined}} The parsed options.
 */
function parseArgs(argv) {
  const index = argv.indexOf('--profile');
  return { profile: index === -1 ? undefined : argv[index + 1] };
}

if (require.main === module) {
  const { profile } = parseArgs(process.argv.slice(2));
  let result;
  try {
    result = detect({ profile, localXml: fs.readFileSync(LOCAL_BPMN, 'utf8') });
  } catch (error) {
    result = verdict('unknown', `Could not read the bundled governance BPMN — ${error.message}`);
  }
  process.stdout.write(`${JSON.stringify(result)}\n`);
  process.exitCode = STATE_EXIT[result.state];
}

module.exports = {
  detect,
  parseDefinitions,
  extractXml,
  normalizeXml,
  latest,
  recordVersion,
  recordKey,
  parseArgs,
  verdict,
  EXIT,
  STATE_EXIT,
  LOCAL_BPMN,
  PROCESS_DEFINITION_ID,
};
