# SaaS / self-managed cluster connection

Adds a `c8ctl` profile for a remote Camunda cluster and validates it against that cluster.

Resolves two values:

- `cluster` — `saas` or `self-managed`, whichever the user chose.
- `c8ctl-profile` — the profile name.

---

## GATE: Step 1 — Add a c8ctl Profile

Ask the user for a profile name — **a free-text answer, not a choice**, so ask in plain prose:

```
Enter a name for this c8ctl profile (e.g. "my-saas-cluster"):
```

Check whether the profile exists already:

```bash
c8ctl --json list profiles
```

If it does not exist, tell the user to run the interactive command themselves by prefixing it with
`!` or running it outside of this session:

```
Run this command to create the profile (the ! prefix executes it in this session):

  ! c8ctl add profile <name> --baseUrl=<cluster-url> --clientId=<client-id> --clientSecret=<client-secret>

Credentials stay inside c8ctl — they are never written to governance state or a .env file.

Type "done" when the setup is complete.
```

Wait for the user to confirm before continuing to Step 2.

---

## EXEC: Step 2 — Validate the Profile

```bash
c8ctl --json get topology --profile <name>
```

`--profile` is the highest-priority override in c8ctl's resolution order, so this validates the
named profile without `c8ctl use profile <name>` — which would switch the user's active profile
globally as a side effect of a check.

The connection is valid when the exit code is `0` and the JSON response contains a `brokers` array
or a `clusterSize` field. Judge the outcome on the exit code alone — c8ctl writes progress to
stderr on success, so stderr output is not a failure signal.

If **invalid**, print the error and stop. Neither value is resolved, and nothing may be recorded:

```
Could not connect using profile "<name>".
c8ctl error: <error output>

Check your credentials and re-run:
  ! c8ctl add profile <name> --baseUrl=<cluster-url> --clientId=<client-id> --clientSecret=<client-secret>
```

If **valid**, both values above are resolved. This part is done — return to the parent context and
continue there.
