---
name: process-os-branding-initialization
description: >-
  Configure the coding agent status line (Claude Code, Copilot CLI) to show
  ProcessOS lifecycle phase info for this project — single source of truth for
  all statusLine writes. Called by process-os-project-initialization; can also
  be run directly when the user asks to add, change or remove the ProcessOS
  status line.
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
# /process-os-branding-initialization

Configure the coding agent status line to show ProcessOS lifecycle phase info for this project.

Detection and file writes both live in scripts. This file only relays what they print and asks the
one question they cannot answer: what the user wants done with a status line they configured
themselves.

The automatic case — a project with no status line yet — needs no skill at all: a caller runs
`node ".github/skills/process-os-branding-initialization/scripts/auto-statusline.cjs"` as one bash step, and
only comes here when that exits `10` because the user has a status line of their own.

**`--agent`** — every command below reports the agent it resolved. That resolution reads an
environment marker, which an agent that sets neither reads as `claude-code`. If the reported agent
is wrong, the user re-invokes this skill with `--agent <id>`; append that flag verbatim to every
command below when they do.

## EXEC: Step 1 — Plan

```bash
node ".github/skills/process-os-branding-initialization/scripts/plan-statusline.cjs"
```

Print the plan's `message` verbatim, then follow its `action`:

| `action` | Do this |
|----------|---------|
| `stop` | Nothing further. The message says why. |
| `apply` | Skip to **Step 3** with the id in `apply`. |
| `ask` | Go to **Step 2**. |

## GATE: Step 2 — Ask

Reached only when `action` is `ask`. This is the user's own status line: do not infer an answer and
do not default to an option.

Print `question.prompt` verbatim and wait. Look the answer up in `question.answers` — it maps each
letter to the id Step 3 takes.

## EXEC: Step 3 — Apply

```bash
node ".github/skills/process-os-branding-initialization/scripts/apply-statusline.cjs" <id>
```

Print its output verbatim. That is the report; nothing needs to be added to it.

Exit `2` means the id did not come from `apply` or `question.answers` (or `--agent` named an agent
that does not exist); exit `3` means `extend` was chosen with nothing left to extend; exit `4` means
there is no project here and exit `5` that the settings file is unreadable, both of which Step 1
stops on. All four are bugs in the wiring above — re-run Step 1 rather than guessing an id.

## AI: Step 4 — Report

State that there is no next action — the status line updates on its own as the lifecycle advances.
