#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Carry out one status line choice end to end, so SKILL.md never sequences
// file writes itself.
//
// Usage: node scripts/apply-statusline.cjs <choice> [--agent claude-code|copilot-cli]
//
//   process-os   ProcessOS phase info only
//   extend       the same, plus the output of the command that was configured
//                before (recorded in state.md, which the script reads back)
//   keep         leave the configured status line alone, record the choice
//   none         configure nothing, record the choice so the skill stops asking
//   cancel       change nothing at all
//
// Exit codes:
//   0  applied
//   2  unknown choice, or unknown --agent value
//   3  `extend` with no command to extend
//   4  no ProcessOS project here
//   5  the agent settings file could not be read

const fs = require('fs');
const path = require('path');

const { detect } = require('./plan-statusline.cjs');
const {
  AGENT_IDS,
  readSettings,
  writeSettings,
  recordBranding,
  clearStatusLine,
  statePath,
} = require('./statusline-store.cjs');

const SOURCE_PATH = path.join(__dirname, 'statusline.js');

const EXIT = { OK: 0, USAGE: 2, NOTHING_TO_EXTEND: 3, NO_PROJECT: 4, UNREADABLE_SETTINGS: 5 };
const CHOICES = ['process-os', 'extend', 'keep', 'none', 'cancel'];

/**
 * @param {object} target Resolved status line target.
 */
function writeScript(target) {
  fs.mkdirSync(path.dirname(target.scriptPath), { recursive: true });
  fs.copyFileSync(SOURCE_PATH, target.scriptPath);
}

/**
 * @param {object} target Resolved status line target.
 */
function writeSetting(target) {
  const config = readSettings(target.settingsPath);
  config.statusLine = { type: 'command', command: target.command };
  // Copilot CLI hides the custom status line when the user turned that footer
  // item off; the whole point of this step is to show it.
  if (target.agent === 'copilot-cli') config.footer = { ...config.footer, showCustom: true };
  writeSettings(target.settingsPath, config);
}

/**
 * @param {object} target Resolved status line target.
 * @returns {string} The line naming the agent this ran against, so a wrong
 *   env-var guess is visible in the report rather than only in the settings
 *   file it wrote.
 */
function agentLine(target) {
  return `  agent: ${target.agent} (${target.scope} scope)`;
}

/**
 * @param {object} target Resolved status line target.
 * @returns {string} The shared "here is what changed" report body.
 */
function fileReport(target) {
  return [
    agentLine(target),
    `  ${target.settingsPath}`,
    `    ← statusLine → ${target.command}`,
    '  .camunda/statusline.js   ← status line script',
    '  .camunda/state.md        ← ## Branding preference recorded',
  ].join('\n');
}

/**
 * @param {string} choice One of `CHOICES`.
 * @param {{agent?: string}} [options]
 * @returns {string} Report to print for the user.
 */
function apply(choice, options = {}) {
  // The branding preference has nowhere to live without it, and a status line
  // configured here would report a project that does not exist.
  if (!fs.existsSync(statePath())) {
    process.stderr.write('no .camunda/state.md here: run /process-os-project-initialization first\n');
    process.exit(EXIT.NO_PROJECT);
  }

  const state = detect(options);
  const { target } = state;

  if (choice === 'cancel') return 'No changes made.';

  // Every remaining choice rewrites that file; guessing at its contents would
  // discard whatever the user has in there.
  if (state.kind === 'unreadable') {
    process.stderr.write(`cannot read ${target.settingsPath}: ${state.error}\n`);
    process.exit(EXIT.UNREADABLE_SETTINGS);
  }

  // Detection above already captured what was configured; from here the old
  // configuration is undone before the new one goes in.
  clearStatusLine();

  if (choice === 'keep' || choice === 'none') {
    recordBranding([['statusLine', choice === 'keep' ? 'keep-global' : 'none']]);
    const kept =
      choice === 'keep'
        ? 'Your own status line is what shows; ProcessOS adds nothing to it.'
        : `No ProcessOS status line. ${target.settingsPath} carries none from this skill.`;
    return [
      `Status line preference recorded (${choice === 'keep' ? 'keep-global' : 'none'}).`,
      '',
      agentLine(target),
      '  .camunda/state.md        ← ## Branding preference recorded',
      '',
      `${kept} Run /process-os-branding-initialization to change this.`,
    ].join('\n');
  }

  // Not just a foreign command being displaced now: on a re-run ours is already
  // configured, and the ## Branding table holds the only surviving copy of what
  // it displaced. Re-recording it is what keeps `keep` able to restore it.
  const replaced = state.extendable;

  if (choice === 'extend') {
    if (!state.extendable) {
      process.stderr.write('nothing to extend: no status line command is configured\n');
      process.exit(EXIT.NOTHING_TO_EXTEND);
    }
    recordBranding([
      ['statusLine', 'extend'],
      ['statusLine.globalCommand', state.extendable],
    ]);
    writeScript(target);
    writeSetting(target);
    return [
      'Status line configured (extend).',
      '',
      fileReport(target),
      '',
      `The previous command (${state.extendable}) is recorded in .camunda/state.md and its`,
      'output is appended to the status line. If you change it later, re-run',
      '/process-os-branding-initialization to refresh the record.',
    ].join('\n');
  }

  recordBranding(replaced ? [['statusLine', 'process-os'], ['statusLine.globalCommand', replaced]] : [['statusLine', 'process-os']]);
  writeScript(target);
  writeSetting(target);
  const lines = ['Status line configured.', '', fileReport(target), ''];
  if (replaced) lines.push(`Replaced: ${replaced} (restored if you re-run this skill and choose Keep).`, '');
  lines.push(
    'The status line will show lifecycle phase, model, context usage, session tokens',
    'and spend after your next interaction.',
  );
  return lines.join('\n');
}

module.exports = { EXIT, apply };

if (require.main === module) {
  const args = process.argv.slice(2);
  const flag = args.indexOf('--agent');
  const agent = flag === -1 ? undefined : args.splice(flag, 2)[1];
  const choice = args[0];
  if (!CHOICES.includes(choice) || (agent !== undefined && !AGENT_IDS.includes(agent))) {
    process.stderr.write(`usage: apply-statusline.cjs <${CHOICES.join('|')}> [--agent <${AGENT_IDS.join('|')}>]\n`);
    process.exit(EXIT.USAGE);
  }
  process.stdout.write(`${apply(choice, { agent })}\n`);
}
