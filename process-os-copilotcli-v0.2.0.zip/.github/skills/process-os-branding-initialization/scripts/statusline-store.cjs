#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Everything this skill persists, and where. Two stores:
//
//   the agent's settings file   the `statusLine` key itself
//   .camunda/state.md           the `## Branding` table recording the choice
//
// Claude Code takes a project-scoped `statusLine` in `.claude/settings.json`.
// Copilot CLI only honours `statusLine` in its user-level settings file
// (`COPILOT_HOME`, else `~/.copilot`); repository settings under
// `.github/copilot/settings.json` accept a closed list of keys that does not
// include `statusLine`, and drop the rest silently.
//
// Both agents run the command with the session's working directory as its cwd,
// so the command is one project-relative constant: it resolves to whichever
// project the session is in, and a user-scoped setting therefore still renders
// per project. A directory with no `.camunda/statusline.js` produces a blank
// status line, which is what a project without ProcessOS should show.

const fs = require('fs');
const os = require('os');
const path = require('path');

// Every ProcessOS status line runs this, whichever agent and scope configured
// it. Relative on purpose - see the note above.
const COMMAND = 'node .camunda/statusline.js';

const AGENTS = [
  { envVar: 'CLAUDECODE', agent: 'claude-code' },
  { envVar: 'COPILOT_CLI', agent: 'copilot-cli' },
];

const AGENT_IDS = AGENTS.map(a => a.agent);

// Resolved per call, not at load: a caller may change the working directory
// between requiring this module and using it.
const statePath = () => path.join(process.cwd(), '.camunda', 'state.md');

/* -------------------------------------------------------------------------- */
/* The agent settings file                                                    */
/* -------------------------------------------------------------------------- */

/**
 * @returns {string} Agent id; `claude-code` when no marker is set.
 */
function detectAgent() {
  return AGENTS.find(a => process.env[a.envVar])?.agent ?? 'claude-code';
}

/**
 * @param {{agent?: string}} [options] `agent` overrides env-var detection, which
 *   is a guess: an agent that sets neither marker reads as `claude-code`.
 * @returns {{agent: string, scope: string, settingsPath: string, globalSettingsPath: string, scriptPath: string, command: string}}
 */
function resolveTarget(options = {}) {
  const cwd = process.cwd();
  const homedir = os.homedir();

  const agent = options.agent ?? detectAgent();
  const scriptPath = path.join(cwd, '.camunda', 'statusline.js');

  if (agent === 'copilot-cli') {
    const copilotHome = process.env.COPILOT_HOME?.trim()
      ? process.env.COPILOT_HOME
      : path.join(homedir, '.copilot');
    const settingsPath = path.join(copilotHome, 'settings.json');
    return {
      agent,
      scope: 'user',
      settingsPath,
      globalSettingsPath: settingsPath,
      scriptPath,
      command: COMMAND,
    };
  }

  return {
    agent,
    scope: 'project',
    settingsPath: path.join(cwd, '.claude', 'settings.json'),
    globalSettingsPath: path.join(homedir, '.claude', 'settings.json'),
    scriptPath,
    command: COMMAND,
  };
}

/**
 * @param {unknown} command A configured `statusLine.command`.
 * @returns {boolean} Whether it runs a ProcessOS status line script. The
 *   absolute form is what earlier versions of this skill wrote at user scope;
 *   it still has to be recognised so a reconfigure replaces it.
 */
function isProcessOSCommand(command) {
  return typeof command === 'string' && /\.camunda[\\/]statusline\.js/.test(command);
}

/**
 * @param {string} settingsPath Settings file to read.
 * @returns {object} Parsed settings; `{}` when the file does not exist.
 * @throws {Error} When the file exists but is not valid JSON.
 */
function readSettings(settingsPath) {
  let content;
  try {
    content = fs.readFileSync(settingsPath, 'utf8');
  } catch (err) {
    if (err.code === 'ENOENT') return {};
    throw err;
  }
  try {
    return JSON.parse(content);
  } catch (err) {
    throw new Error(`${settingsPath} is not valid JSON: ${err.message}`);
  }
}

/**
 * @param {string} settingsPath Settings file to write.
 * @param {object} config Full settings object.
 */
function writeSettings(settingsPath, config) {
  fs.mkdirSync(path.dirname(settingsPath), { recursive: true });
  fs.writeFileSync(settingsPath, `${JSON.stringify(config, null, 2)}\n`);
}

/* -------------------------------------------------------------------------- */
/* The `## Branding` table in .camunda/state.md                               */
/* -------------------------------------------------------------------------- */

/**
 * @param {string} value Raw cell value.
 * @returns {string} Value with `|` escaped for a markdown table cell.
 */
function escapeCell(value) {
  // Escaping the escape character keeps the mapping reversible on its own terms
  // rather than only in combination with the exact row regex the reader uses.
  return value.replace(/[\\|]/g, character => `\\${character}`);
}

/**
 * @param {string} existing Current state.md content.
 * @param {[string, string][]} rows Key/value pairs to render as table rows.
 * @returns {string} content with the `## Branding` section appended.
 */
function appendBrandingSection(existing, rows) {
  const tableRows = rows.map(([key, value]) => `| ${key} | ${escapeCell(value)} |`).join('\n');
  const section = `\n## Branding\n\n| Key | Value |\n|-----|-------|\n${tableRows}\n`;
  return `${existing.trimEnd()}\n${section}`;
}

/**
 * @param {string} content Full state.md content.
 * @returns {string} content with any `## Branding` section removed.
 */
function removeBrandingSection(content) {
  return content.replace(/\n## Branding\n[\s\S]*?(?=\n## |\s*$)/, '').trimEnd() + '\n';
}

/**
 * @param {string} content Current state.md content.
 * @param {string} key Row key to look up in the `## Branding` table.
 * @returns {string|null} The recorded value, unescaped; `null` when absent.
 */
function readBrandingValue(content, key) {
  const section = content.split(/^## Branding$/m)[1];
  if (section === undefined) return null;
  const body = section.split(/^## /m)[0];
  const row = body
    .split('\n')
    .map(line => line.match(/^\| (.+?) \| (.*) \|\s*$/))
    .find(match => match && match[1] === key);
  return row ? row[2].replace(/\\([\\|])/g, (_, character) => character) : null;
}

/**
 * Replace the recorded preference, so re-recording never stacks a second
 * `## Branding` section.
 *
 * @param {[string, string][]} rows Key/value pairs for the table.
 */
function recordBranding(rows) {
  const existing = removeBrandingSection(fs.readFileSync(statePath(), 'utf8'));
  fs.writeFileSync(statePath(), appendBrandingSection(existing, rows));
}

/**
 * @param {string} key Row key to look up.
 * @returns {string|null} The value recorded in `.camunda/state.md`, if any.
 */
function readRecordedValue(key) {
  let content;
  try {
    content = fs.readFileSync(statePath(), 'utf8');
  } catch (err) {
    if (err.code === 'ENOENT') return null;
    throw err;
  }
  return readBrandingValue(content, key);
}

/* -------------------------------------------------------------------------- */
/* Undoing a configuration                                                    */
/* -------------------------------------------------------------------------- */

/**
 * Undo whatever this skill configured: restore (or drop) the `statusLine` key
 * and delete `.camunda/statusline.js`.
 *
 * A status line this skill did not write is left alone at either scope — the
 * user settings file is shared with every other session, and a project
 * settings file may still carry a command the user put there themselves.
 */
function clearStatusLine() {
  const target = resolveTarget();
  const config = readSettings(target.settingsPath);

  if (config.statusLine && isProcessOSCommand(config.statusLine.command)) {
    const recorded = readRecordedValue('statusLine.globalCommand');
    if (recorded && !isProcessOSCommand(recorded)) {
      config.statusLine = { type: 'command', command: recorded };
    } else {
      delete config.statusLine;
    }
    writeSettings(target.settingsPath, config);
  }

  fs.rmSync(target.scriptPath, { force: true });
}

module.exports = {
  AGENT_IDS,
  resolveTarget,
  isProcessOSCommand,
  readSettings,
  writeSettings,
  readBrandingValue,
  recordBranding,
  clearStatusLine,
  statePath,
};
