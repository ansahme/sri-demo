#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Decide what this skill should do, in one deterministic pass, so SKILL.md
// carries no detection logic of its own.
//
// Usage: node scripts/plan-statusline.cjs [--agent claude-code|copilot-cli]
//
// Prints one JSON object on stdout and exits 0. The caller prints `message`
// verbatim and then follows `action`:
//   stop    nothing to do
//   apply   run `apply-statusline.cjs <apply>`
//   ask     put `question.prompt` to the user, look their answer up in
//           `question.answers`, run `apply-statusline.cjs <answer>`
//
// The `auto` option is for `auto-statusline.cjs`: it turns a decision that
// would only re-confirm an existing configuration into `stop`. It never
// suppresses a first-time question about the user's own status line.

const fs = require('fs');

const {
  AGENT_IDS,
  resolveTarget,
  isProcessOSCommand,
  readSettings,
  readBrandingValue,
  statePath,
} = require('./statusline-store.cjs');

const OPTION_TEXT = {
  extend: cmd => `Extend      — prepend [ProcessOS] phase info, keep \`${cmd}\` appended`,
  'process-os': () => 'ProcessOS   — show ProcessOS phase info only',
  keep: () => 'Keep        — leave the existing status line as-is, no ProcessOS info added',
  none: () => 'None        — no ProcessOS status line, and stop asking',
  cancel: () => 'Cancel      — leave everything as it is',
};

/**
 * @param {string} settingsPath Settings file to read a command from.
 * @returns {{command: string, error: null}|{command: null, error: string}}
 */
function readCommand(settingsPath) {
  try {
    return { command: readSettings(settingsPath).statusLine?.command ?? '', error: null };
  } catch (err) {
    return { command: null, error: err.message };
  }
}

/**
 * Work out what is configured now and which command, if any, could be wrapped
 * by the Extend option.
 *
 * @param {{agent?: string}} [options]
 * @returns {{target: object, recorded: string|null, configured: string, kind: string,
 *   extendable: string|null, error: string|null}}
 */
function detect(options = {}) {
  const target = resolveTarget({ agent: options.agent });
  const state = fs.existsSync(statePath()) ? fs.readFileSync(statePath(), 'utf8') : null;
  const recorded = state === null ? null : readBrandingValue(state, 'statusLine');
  const recordedGlobal = state === null ? null : readBrandingValue(state, 'statusLine.globalCommand');

  const own = readCommand(target.settingsPath);
  const global = target.globalSettingsPath === target.settingsPath ? own : readCommand(target.globalSettingsPath);
  const error = own.error ?? global.error;
  if (error) {
    return { target, recorded, configured: '', kind: 'unreadable', extendable: null, error };
  }

  const configured = own.command;
  const kind = configured === '' ? 'none' : isProcessOSCommand(configured) ? 'ours' : 'foreign';

  // Once this skill has written its own command, the line it displaced is only
  // recoverable from the `## Branding` table.
  let extendable = null;
  if (kind === 'foreign') extendable = configured;
  else if (recordedGlobal && !isProcessOSCommand(recordedGlobal)) extendable = recordedGlobal;
  else if (global.command && !isProcessOSCommand(global.command)) extendable = global.command;

  return { target, recorded, configured, kind, extendable, error: null };
}

/**
 * @param {string} prompt Lead-in line shown above the options.
 * @param {string[]} ids Option ids, in display order.
 * @param {string|null} extendable Command shown in the Extend option's text.
 * @returns {{prompt: string, answers: Record<string, string>}}
 */
function buildQuestion(prompt, ids, extendable) {
  const letters = ['a', 'b', 'c', 'd'];
  const answers = {};
  const lines = ids.map((id, i) => {
    answers[letters[i]] = id;
    return `[${letters[i]}] ${OPTION_TEXT[id](extendable)}`;
  });
  return { prompt: `${prompt}\n\n${lines.join('\n')}`, answers };
}

/**
 * @param {{auto?: boolean, agent?: string}} [options]
 * @returns {{action: string, message: string, apply?: string, question?: object, target?: object}}
 */
function decide(options = {}) {
  const auto = options.auto === true;

  if (!fs.existsSync(statePath())) {
    return {
      action: 'stop',
      message: 'No process project initialized here. Run `/process-os-project-initialization` first.',
    };
  }

  const state = detect(options);
  const { target, recorded, kind, extendable } = state;

  if (kind === 'unreadable') {
    return {
      action: 'stop',
      message: `Could not read the agent settings: ${state.error}\nFix ${target.settingsPath}, then run this skill again.`,
      target,
    };
  }

  const scopeNote =
    target.scope === 'user'
      ? `\n\n${target.settingsPath} is your own settings file, shared by every ${target.agent} session. The command written there is project-relative, so it shows this project's phase here and nothing in a directory without ProcessOS.`
      : '';

  // A status line the user configured themselves, wherever it lives. `--auto`
  // does not skip this: overriding it silently is the one thing this skill
  // must never do.
  if (kind === 'foreign' || (kind === 'none' && !recorded && extendable)) {
    const where = kind === 'foreign' ? target.settingsPath : target.globalSettingsPath;
    const preface = recorded ? `Status line already configured as \`${recorded}\`.\n` : '';
    return {
      action: 'ask',
      message: `${preface}An existing status line is configured in ${where}:\n\n  ${extendable}\n\nConfigurations set through other mechanisms (e.g. a global CLAUDE.md) cannot be detected.${scopeNote}`,
      question: buildQuestion(
        'How would you like to proceed?',
        recorded ? ['extend', 'process-os', 'keep', 'cancel'] : ['extend', 'process-os', 'keep'],
        extendable,
      ),
      target,
    };
  }

  if (recorded) {
    if (auto) {
      return {
        action: 'stop',
        message: `Status line already configured (preference: ${recorded}). No changes made.`,
        target,
      };
    }
    return {
      action: 'ask',
      message: `Status line already configured as \`${recorded}\`.${scopeNote}`,
      // Without a command of the user's own to fall back to, "keep" would
      // mean keeping ProcessOS - the way out is to remove it, which is "none".
      question: buildQuestion(
        'How would you like to reconfigure it?',
        extendable ? ['extend', 'process-os', 'keep', 'cancel'] : ['process-os', 'none', 'cancel'],
        extendable,
      ),
      target,
    };
  }

  return {
    action: 'apply',
    message: `No status line configured in ${target.settingsPath}.${scopeNote}`,
    apply: 'process-os',
    target,
  };
}

/**
 * @param {{auto?: boolean, agent?: string}} [options]
 * @returns {{action: string, message: string, apply?: string, question?: object, target?: object}}
 */
function plan(options = {}) {
  const result = decide(options);
  if (!result.target) return result;
  const { agent, scope } = result.target;
  const other = AGENT_IDS.find(id => id !== agent);
  return {
    ...result,
    message: `Agent: ${agent} (${scope} scope). Re-run with --agent ${other} if that is wrong.\n\n${result.message}`,
  };
}

module.exports = { detect, plan };

if (require.main === module) {
  const args = process.argv.slice(2);
  const agent = args[args.indexOf('--agent') + 1];
  if (args.includes('--agent') && !AGENT_IDS.includes(agent)) {
    process.stderr.write(`usage: plan-statusline.cjs [--agent <${AGENT_IDS.join('|')}>]\n`);
    process.exit(2);
  }
  process.stdout.write(`${JSON.stringify(plan({ agent: args.includes('--agent') ? agent : undefined }), null, 2)}\n`);
}
