/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

const fs = require('fs');
const { execSync } = require('child_process');

const stdin = (() => {
  try { return fs.readFileSync(0, 'utf8').replace(/^\uFEFF/, ''); } catch (e) { return ''; }
})();

let d = {};
try { d = JSON.parse(stdin); } catch (e) {}

const RESET = '\x1b[0m';
const DIM = '\x1b[2;37m';
const GREEN = '\x1b[92m';
const YELLOW = '\x1b[93m';
const RED = '\x1b[91m';

const fmtTok = n => n >= 1e6 ? (n / 1e6).toFixed(1) + 'm'
  : n >= 1000 ? Math.round(n / 1000) + 'k'
  : String(n);

const parts = ['[ProcessOS]'];

let state = null;
try {
  state = fs.readFileSync('.camunda/state.md', 'utf8');
  const ip = state.match(/\| ([a-z-]+) \| 🔄 In Progress \|/);
  const nx = state.match(/\| ([a-z-]+) \| ⏳ Next \|/);
  parts.push(ip ? '🔄 ' + ip[1] : nx ? '⏳ ' + nx[1] : '✅ all done');
} catch (e) {
  parts.push('status: Not initialized');
}

if (d.model && d.model.display_name) parts.push(d.model.display_name);

const cw = d.context_window || {};
const usedPct = cw.current_context_used_percentage != null ? cw.current_context_used_percentage : cw.used_percentage;
const windowSize = cw.displayed_context_limit > 0 ? cw.displayed_context_limit : cw.context_window_size;
if (usedPct != null) {
  const pct = Math.round(usedPct);
  const color = pct > 75 ? RED : pct > 49 ? YELLOW : GREEN;
  const filled = Math.min(5, Math.floor(pct / 20));
  const bar = color + '█'.repeat(filled) + RESET + DIM + '░'.repeat(5 - filled) + RESET;
  const size = windowSize > 0 ? '/' + fmtTok(windowSize) : '';
  parts.push('ctx ' + bar + ' ' + color + pct + '%' + RESET + size);
}

const sess = [];
if (cw.total_input_tokens != null && cw.total_output_tokens != null) {
  sess.push(fmtTok(cw.total_input_tokens + cw.total_output_tokens) + ' tok');
}
if (d.cost && d.cost.total_cost_usd != null) {
  sess.push('$' + d.cost.total_cost_usd.toFixed(2));
} else if (d.ai_used && d.ai_used.formatted) {
  sess.push(d.ai_used.formatted + ' AIC');
}
if (sess.length) parts.push(sess.join(' · '));

// The `## Branding` table the phase segment already read also records whether
// the user asked to keep their own status line appended, and which command
// produces it.
const branding = key => {
  const section = state.split(/^## Branding$/m)[1];
  if (section === undefined) return null;
  const row = section
    .split(/^## /m)[0]
    .split('\n')
    .map(line => line.match(/^\| (.+?) \| (.*) \|\s*$/))
    .find(match => match && match[1] === key);
  return row ? row[2].replace(/\\([\\|])/g, (_, character) => character) : null;
};

if (state !== null && branding('statusLine') === 'extend') {
  const wrapped = branding('statusLine.globalCommand');
  if (wrapped) {
    try {
      const out = execSync(wrapped, { encoding: 'utf8', input: stdin, stdio: ['pipe', 'pipe', 'ignore'] }).trim();
      if (out) parts.push(out);
    } catch (e) {}
  }
}

process.stdout.write(parts.join(' | '));
