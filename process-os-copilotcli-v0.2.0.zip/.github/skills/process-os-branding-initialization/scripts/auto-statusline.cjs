#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// The non-interactive half of this skill, callable from another skill as one
// bash step: install the status line when that needs no human input, and say
// so plainly when it does.
//
// Usage: node scripts/auto-statusline.cjs [--agent claude-code|copilot-cli]
//
// Exit codes:
//   0   settled - configured now, or already configured, or nothing to do
//   2   unknown --agent value
//   10  only the user can settle it; stdout says why
//
// A plan `stop` exits 0 even when it reports a problem (an unreadable settings
// file, no project here): none of its reasons are fixable without the user,
// the message naming the reason is on stdout, and a status line that could not
// be configured must not abort the caller's own run.

const { plan } = require('./plan-statusline.cjs');
const { apply } = require('./apply-statusline.cjs');
const { AGENT_IDS } = require('./statusline-store.cjs');

const EXIT = { OK: 0, USAGE: 2, NEEDS_USER: 10 };

/**
 * @param {{agent?: string}} [options]
 * @returns {{exit: number, out: string}}
 */
function auto(options = {}) {
  const result = plan({ ...options, auto: true });

  if (result.action === 'ask') {
    return {
      exit: EXIT.NEEDS_USER,
      out: `${result.message}\n\nRun /process-os-branding-initialization to decide what to do with it.`,
    };
  }
  if (result.action === 'stop') return { exit: EXIT.OK, out: result.message };
  return { exit: EXIT.OK, out: apply(result.apply, options) };
}

module.exports = { EXIT, auto };

if (require.main === module) {
  const args = process.argv.slice(2);
  const flag = args.indexOf('--agent');
  const agent = flag === -1 ? undefined : args[flag + 1];
  if (flag !== -1 && !AGENT_IDS.includes(agent)) {
    process.stderr.write(`usage: auto-statusline.cjs [--agent <${AGENT_IDS.join('|')}>]\n`);
    process.exit(EXIT.USAGE);
  }
  const { exit, out } = auto({ agent });
  process.stdout.write(`${out}\n`);
  process.exit(exit);
}
