/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

import { writeFileSync } from 'node:fs';

/*
 * This generator creates a complex gateway.
 * Alpha layout does not support the gateway.
 * Bpmnkit has no complex-gateway builder method.
 * The generator adds the semantic gateway data directly.
 * Layout tests use the fixture to check bpmnkit fallback.
 */

const output = process.argv[2] ?? 'complex-gateway-fallback.bpmn';
const bpmnkitImport = process.env.BPMNKIT_IMPORT;

if (!bpmnkitImport) {
  throw new Error('Set BPMNKIT_IMPORT before running complex-gateway-fallback.bpmn.gen.mjs');
}

const { Bpmn } = await import(bpmnkitImport);
const builder = Bpmn.createProcess('ComplexGatewayFallback')
  .name('Complex gateway fallback')
  .startEvent('StartEvent_1')
  .task('Task_Review', { name: 'Review' })
  .endEvent('EndEvent_1')
  .executable(false)
  .executionPlatformVersion('8.9.0');

// Sequence-flow ids are derived from the flow's endpoints by bpmnkit when the
// model is built, so this only re-points the task's outgoing flow at the
// gateway — naming the flows here would not survive the build.
const taskToEnd = builder.sequenceFlows.find(flow => flow.sourceRef === 'Task_Review');
taskToEnd.targetRef = 'Gateway_Complex';
builder.flowElements.splice(builder.flowElements.findIndex(element => element.id === 'EndEvent_1'), 0, {
  id: 'Gateway_Complex',
  type: 'complexGateway',
  incoming: [],
  outgoing: [],
  extensionElements: [],
  unknownAttributes: {},
});
builder.sequenceFlows.push({
  id: 'Flow_Complex_End',
  sourceRef: 'Gateway_Complex',
  targetRef: 'EndEvent_1',
  extensionElements: [],
  unknownAttributes: {},
});

const defs = builder.withAutoLayout().build();
writeFileSync(output, Bpmn.export(defs));
