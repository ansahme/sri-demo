/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

import { writeFileSync } from 'node:fs';

/*
 * This generator creates a supported bpmn-auto-layout-v2-alpha fixture.
 * It contains a timer boundary event and four gateway types.
 * The gateways are parallel, inclusive, event-based, and exclusive.
 * Layout tests use the fixture to check success with no fallback.
 */

const output = process.argv[2] ?? 'boundary-gateway-happy.bpmn';
const bpmnkitImport = process.env.BPMNKIT_IMPORT;

if (!bpmnkitImport) {
  throw new Error('Set BPMNKIT_IMPORT before running boundary-gateway-happy.bpmn.gen.mjs');
}

const { Bpmn } = await import(bpmnkitImport);
const builder = Bpmn.createProcess('BoundaryGatewayHappy')
  .name('Boundary and gateway bpmn-auto-layout-v2-alpha path')
  .startEvent('StartEvent_1')
  .userTask('Task_Review', { name: 'Review request' })
  .boundaryEvent('BoundaryEvent_Reminder', {
    attachedTo: 'Task_Review',
    name: 'Review reminder',
    timerDuration: 'PT1H',
    cancelActivity: false,
  })
  .endEvent('EndEvent_Reminder')
  .element('Task_Review')
  .parallelGateway('Gateway_ParallelSplit')
  .branch('direct', branch => branch.connectTo('Gateway_ParallelJoin'))
  .branch('review', branch => branch
    .task('Task_ParallelReview', { name: 'Review in parallel' })
    .connectTo('Gateway_ParallelJoin'))
  .parallelGateway('Gateway_ParallelJoin')
  .inclusiveGateway('Gateway_InclusiveSplit')
  .branch('direct', branch => branch.defaultFlow().connectTo('Gateway_InclusiveJoin'))
  .branch('check', branch => branch
    .condition('= needsExtraCheck = true')
    .task('Task_ExtraCheck', { name: 'Perform extra check' })
    .connectTo('Gateway_InclusiveJoin'))
  .inclusiveGateway('Gateway_InclusiveJoin')
  .eventBasedGateway('Gateway_EventBased')
  .branch('message', branch => branch
    .intermediateCatchEvent('IntermediateCatchEvent_Continue', {
      name: 'Continue received',
      messageName: 'continue-review',
    })
    .connectTo('Gateway_EventJoin'))
  .branch('timer', branch => branch
    .intermediateCatchEvent('IntermediateCatchEvent_Timeout', {
      name: 'Review timed out',
      timerDuration: 'PT10M',
    })
    .connectTo('Gateway_EventJoin'))
  .exclusiveGateway('Gateway_EventJoin')
  .endEvent('EndEvent_Completed')
  .executable(false)
  .executionPlatformVersion('8.9.0');

const defs = process.env.BPMN_LAYOUT === 'bpmnkit'
  ? builder.withAutoLayout().build()
  : builder.build();

writeFileSync(output, Bpmn.export(defs));
