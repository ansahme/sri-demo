/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

import { writeFileSync } from 'node:fs';

/*
 * This generator creates a compensation association fixture.
 * The boundary event points to a compensation handler.
 * Layout tests use the fixture to record missing association-edge DI.
 */

const output = process.argv[2] ?? 'compensation-association-gap.bpmn';
const bpmnkitImport = process.env.BPMNKIT_IMPORT;

if (!bpmnkitImport) {
  throw new Error('Set BPMNKIT_IMPORT before running compensation-association-gap.bpmn.gen.mjs');
}

const { Bpmn } = await import(bpmnkitImport);
const builder = Bpmn.createProcess('CompensationAssociationGap')
  .name('Compensation association gap')
  .startEvent('StartEvent_1')
  .serviceTask('Task_Service', { name: 'Run service work', taskType: 'run-service' })
  .withBoundary('BoundaryEvent_Compensate', { compensation: true, name: 'Compensate service work' }, handler =>
    handler.task('Task_UndoService', { name: 'Undo service work', isForCompensation: true }))
  .endEvent('EndEvent_1')
  .executable(false)
  .executionPlatformVersion('8.9.0');

const defs = process.env.BPMN_LAYOUT === 'bpmnkit'
  ? builder.withAutoLayout().build()
  : builder.build();

writeFileSync(output, Bpmn.export(defs));
