/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

import { writeFileSync } from 'node:fs';

/*
 * This generator creates a nested annotation fixture.
 * It attaches annotations to two elements in an event subprocess.
 * Layout tests use the fixture to check association-edge DI.
 */

const output = process.argv[2] ?? 'event-subprocess-annotation-repro.bpmn';
const bpmnkitImport = process.env.BPMNKIT_IMPORT;

if (!bpmnkitImport) {
  throw new Error('Set BPMNKIT_IMPORT=file:///path/to/bpmnkit/index.js before running event-subprocess-annotation-repro.bpmn.gen.mjs');
}

const { Bpmn } = await import(bpmnkitImport);

const builder = Bpmn.createProcess('EventSubProcessAnnotationRepro')
  .name('Event subprocess annotation reproduction')
  .eventSubProcess('EventSubProcess_Housekeeping', builder => builder
    .startEvent('StartEvent_TimerTick', {
      name: 'After 1 hour',
      timerDuration: 'PT1H',
      isInterrupting: false,
    })
    .endEvent('EndEvent_HousekeepingDone', { name: 'Housekeeping done' }))
  .annotate('StartEvent_TimerTick', 'Timer start annotation')
  .annotate('EndEvent_HousekeepingDone', 'Timer end annotation')
  .executable(false)
  .executionPlatformVersion('8.9.0');

const defs = process.env.BPMN_LAYOUT === 'bpmnkit'
  ? builder.withAutoLayout().build()
  : builder.build();

writeFileSync(output, Bpmn.export(defs));
