#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Report whether a directory holds files matching each given glob, portably.
//
// Replaces the `ls <dir>/*.bpmn >/dev/null 2>&1 && echo "has bpmn"` idiom skills
// used to decide what a directory contains. That spelling needs `&&` and relies
// on the shell expanding the glob — PowerShell 5.1 has neither, so a native
// Windows agent had to improvise a translation every time. It is also silently
// wrong when a glob matches a directory rather than a file, which `ls` reports as
// a hit.
//
// Usage:
//   node "dir-contains.cjs" <dir> <pattern>...
//
// Patterns are single-segment globs resolved against <dir> — `*.bpmn`,
// `process-*.md`, or a bare filename. Only regular files count as a match.
//
// Prints one line per pattern, in the order given:
//   MATCH     *.bpmn      3
//   NO MATCH  *.md        0
//
// A <dir> that does not exist prints one `NO DIR <dir>` line instead of
// per-pattern verdicts, so "the directory is missing" stays distinguishable from
// "the directory is there and holds nothing" — a caller that has to create it
// otherwise cannot tell.
//
// Always exits 0 when it produced a verdict: absent is an answer, not an error.
// Exits 2 only on a usage error.

const fs = require('fs');
const { resolvePattern } = require('./snapshot.cjs');

const EXIT = { OK: 0, USAGE: 2 };

const USAGE = 'usage: dir-contains.cjs <dir> <pattern>...\n';

/**
 * Count the regular files in `dir` matching each pattern.
 *
 * @param {string} dir Directory to look in.
 * @param {string[]} patterns Single-segment globs.
 * @returns {{pattern: string, count: number}[]} One entry per pattern, in order.
 */
function countMatches(dir, patterns) {
  return patterns.map((pattern) => ({
    pattern,
    // resolvePattern already filters to regular files and tolerates a missing
    // directory, so a pattern that matches nothing is a plain empty list.
    count: resolvePattern(dir, pattern).length,
  }));
}

/**
 * Whether `dir` exists as a directory.
 *
 * @param {string} dir
 * @returns {boolean}
 */
function isDir(dir) {
  try {
    return fs.statSync(dir).isDirectory();
  } catch {
    return false;
  }
}

/**
 * Format one verdict line. Padded so a multi-pattern report stays aligned.
 *
 * @param {string} pattern Pattern as the caller wrote it.
 * @param {number} count Matching regular files.
 * @returns {string} Line without its trailing newline.
 */
function formatLine(pattern, count) {
  return `${(count > 0 ? 'MATCH' : 'NO MATCH').padEnd(10)}${pattern.padEnd(20)}${count}`;
}

/**
 * Build the full report for one invocation.
 *
 * @param {string} dir Directory to look in.
 * @param {string[]} patterns Single-segment globs.
 * @returns {string[]} Lines to print, without trailing newlines.
 */
function report(dir, patterns) {
  if (!isDir(dir)) return [`${'NO DIR'.padEnd(10)}${dir}`];
  return countMatches(dir, patterns).map(({ pattern, count }) => formatLine(pattern, count));
}

module.exports = { EXIT, countMatches, formatLine, isDir, report };

if (require.main === module) {
  const [dir, ...patterns] = process.argv.slice(2);
  if (!dir || patterns.length === 0) {
    process.stderr.write(USAGE);
    process.exit(EXIT.USAGE);
  }
  process.stdout.write(`${report(dir, patterns).join('\n')}\n`);
}
