#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Resolve the project-relative import specifier a phase's `.gen.mjs` uses to import
// `@bpmnkit/core`, relative to OUTPUT_DIR (where the .gen.mjs is written) -- see
// references/bpmnkit.md's "Import by a project-relative path" convention.
//
// Replaces an inline `node -e "…"` one-liner in SKILL.md — branching logic (does the entry
// exist? which way does the relative path point? does it need a leading `./`?) belongs in a
// file where it can be read, tested and traced.
//
// Usage:
//   node "scripts/resolve-bpmnkit-import.cjs" <OUTPUT_DIR>
//
// stdout, exactly one line the caller captures:
//   BPMNKIT_IMPORT=../../.camunda/node_modules/@bpmnkit/core/dist/index.js
//   BPMNKIT_IMPORT=                                   (bpmnkit not installed)
//
// Always exits 0 on a resolved OUTPUT_DIR -- an empty value is a valid answer rather than an
// error. In practice it cannot reach a caller: SKILL.md's `require-runtime-deps.cjs` gate stops
// the run before dispatch when `@bpmnkit/core` is absent, and there is no hand-authored-XML
// fallback. Exits 2 on a usage error (missing OUTPUT_DIR argument).

const fs = require('fs');
const path = require('path');

const BPMNKIT_ENTRY_SEGMENTS = ['.camunda', 'node_modules', '@bpmnkit', 'core', 'dist', 'index.js'];

/**
 * @param {string} outputDir OUTPUT_DIR -- the directory the .gen.mjs will be written into
 *   (project-relative or absolute; resolved against `cwd`).
 * @param {string} [cwd] Project root. Defaults to the process WD.
 * @returns {string} A forward-slash relative import specifier (always starting with `.`), or
 *   `''` if `@bpmnkit/core`'s pinned entry isn't installed.
 */
function resolveBpmnkitImport(outputDir, cwd = process.cwd()) {
  const entry = path.resolve(cwd, ...BPMNKIT_ENTRY_SEGMENTS);
  if (!fs.existsSync(entry)) return '';
  const rel = path.relative(path.resolve(cwd, outputDir), entry).split(path.sep).join('/');
  return rel.startsWith('./') || rel.startsWith('../') ? rel : `./${rel}`;
}

module.exports = { BPMNKIT_ENTRY_SEGMENTS, resolveBpmnkitImport };

if (require.main === module) {
  const outputDir = process.argv[2];
  if (!outputDir) {
    process.stderr.write('usage: resolve-bpmnkit-import.cjs <OUTPUT_DIR>\n');
    process.exit(2);
  }
  process.stdout.write(`BPMNKIT_IMPORT=${resolveBpmnkitImport(outputDir)}\n`);
}
