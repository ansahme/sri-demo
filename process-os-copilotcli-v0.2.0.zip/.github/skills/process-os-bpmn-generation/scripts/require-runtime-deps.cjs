#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Gate: `@bpmnkit/core` must already be installed under `.camunda/node_modules`
// before this skill dispatches into update / edit / generate mode.
//
// The skill never installs it. Runtime deps are provisioned centrally by
// `c8 os install` / `c8 os update`, the one step that deterministically runs
// before any skill: skills install nothing and keep only a cheap ensure-check.
//
// bpmnlint is deliberately *not* gated here: `process-os-bpmn-linting` falls back
// to `npx --yes bpmnlint`, so a missing binary costs wall-clock, not correctness.
//
// Usage:
//   node "scripts/require-runtime-deps.cjs"
//
// Exit codes:
//   0  dependency present, nothing written to either stream
//   1  dependency missing; the recovery message is on stderr
//
// Nothing is created before this passes — no OUTPUT_DIR, no snapshot, no timing
// dir — so a blocked run leaves the project exactly as it found it.

const fs = require('fs');
const path = require('path');

const REQUIRED_PACKAGE = path.join('@bpmnkit', 'core');
const NODE_MODULES_SEGMENTS = ['.camunda', 'node_modules'];

/**
 * @param {string} [cwd] Project root. Defaults to the process WD.
 * @returns {boolean} Whether `@bpmnkit/core` is installed centrally.
 */
function hasRuntimeDeps(cwd = process.cwd()) {
  return fs.existsSync(path.join(cwd, ...NODE_MODULES_SEGMENTS, REQUIRED_PACKAGE));
}

module.exports = { NODE_MODULES_SEGMENTS, REQUIRED_PACKAGE, hasRuntimeDeps };

if (require.main === module) {
  if (!hasRuntimeDeps()) {
    process.stderr.write(
      'ProcessOS runtime dep missing: @bpmnkit/core at .camunda/node_modules. ' +
        'Run `c8 os update` — or `c8 os install <target>` (e.g. claudecode) if ProcessOS is not installed here.\n' +
        'Nothing was generated.\n'
    );
    process.exit(1);
  }
}
