#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

/**
 * Scaffold BPMN DI with bpmnkit, then refine it with bpmn-io layout.
 *
 * The default path generates bpmnkit's baseline DI, then lets bpmn-io own
 * final geometry. If bpmn-io layout or its DI check fails, the generator
 * restores the bpmnkit baseline and runs bpmnkit-specific cleanup passes.
 * If the bpmnkit scaffold cannot be generated, the raw generator output gets
 * one direct bpmn-io attempt instead.
 *
 * Usage:
 *   node layout-bpmn.cjs <generator.mjs> <output.bpmn>
 */

const path = require('node:path');
const fs = require('node:fs');
const { runNodeCli } =
  require(path.join(__dirname, 'resolve-node-cli.cjs'));

// This shared script is copied next to this file when the skill is bundled.
const AUTO_LAYOUT_SCRIPT = path.join(__dirname, 'bpmn-auto-layout.cjs');
const DI_CHECK_SCRIPT = path.join(__dirname, 'bpmn-di-check.cjs');
const NODE_PLACEMENT_SCRIPT = path.join(__dirname, 'bpmn-node-placement.cjs');
const EDGE_CLEANUP_SCRIPT = path.join(__dirname, 'bpmn-edge-cleanup.cjs');

function writeChildError(result) {
  if (result.stderr) process.stderr.write(String(result.stderr));
}

function runNode(script, args, options, runner) {
  const result = runNodeCli(script, args, {
    ...options,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe']
  }, runner);
  if (result.stdout) process.stdout.write(String(result.stdout));

  if (result.error || result.status === null) {
    const detail = result.error ? result.error.message : `status=${result.status}`;
    writeChildError(result);
    process.stderr.write(`layout-bpmn: ${path.basename(script)} did not launch: ${detail}\n`);
    return { ok: false, code: 2, launched: false };
  }

  if (result.status !== 0) writeChildError(result);

  return {
    ok: result.status === 0,
    code: result.status,
    launched: true
  };
}

function writeUsageError() {
  process.stderr.write('Usage: layout-bpmn.cjs <generator.mjs> <output.bpmn>\n');
}

function runBpmnIoLayout({
  output,
  projectRoot,
  primaryEnv,
  scripts,
  runner
}) {
  const bpmnIoLayout = runNode(scripts.autoLayout, [output], {
    cwd: projectRoot,
    env: primaryEnv
  }, runner);
  if (!bpmnIoLayout.ok) return bpmnIoLayout;

  return runNode(scripts.diCheck, [output], {
    cwd: projectRoot,
    env: primaryEnv
  }, runner);
}

function runLayout({
  generator,
  output,
  projectRoot = process.cwd(),
  scripts = {
    autoLayout: AUTO_LAYOUT_SCRIPT,
    diCheck: DI_CHECK_SCRIPT,
    nodePlacement: NODE_PLACEMENT_SCRIPT,
    edgeCleanup: EDGE_CLEANUP_SCRIPT
  },
  runner
}) {
  const primaryEnv = { ...process.env };
  delete primaryEnv.BPMN_LAYOUT;

  const bpmnkitEnv = {
    ...primaryEnv,
    BPMN_LAYOUT: 'bpmnkit'
  };
  const bpmnkitScaffold = runNode(generator, [], {
    cwd: projectRoot,
    env: bpmnkitEnv
  }, runner);

  if (!bpmnkitScaffold.ok) {
    process.stderr.write('layout-bpmn: bpmnkit scaffold failed; retrying raw bpmn-io layout\n');
    const rawGeneration = runNode(generator, [], {
      cwd: projectRoot,
      env: primaryEnv
    }, runner);
    if (!rawGeneration.ok) return rawGeneration.code;

    const rawBpmnIo = runBpmnIoLayout({
      output,
      projectRoot,
      primaryEnv,
      scripts,
      runner
    });
    if (rawBpmnIo.ok) {
      console.log(`layout-bpmn: ${path.basename(output)} — raw bpmn-io layout complete`);
      return 0;
    }
    return rawBpmnIo.code;
  }

  const bpmnIoResult = runBpmnIoLayout({
    output,
    projectRoot,
    primaryEnv,
    scripts,
    runner
  });
  if (bpmnIoResult.ok) {
    console.log(`layout-bpmn: ${path.basename(output)} — bpmnkit scaffold + bpmn-io layout complete`);
    return 0;
  }

  const fallbackSteps = [
    { script: generator, args: [] },
    { script: scripts.diCheck, args: [output] },
    { script: scripts.nodePlacement, args: [output] },
    { script: scripts.edgeCleanup, args: [output] },
    { script: scripts.diCheck, args: [output] }
  ];
  for (const step of fallbackSteps) {
    const result = runNode(step.script, step.args, {
      cwd: projectRoot,
      env: bpmnkitEnv
    }, runner);
    if (!result.ok) return result.code;
  }

  console.log(`layout-bpmn: ${path.basename(output)} — bpmnkit fallback complete`);
  return 0;
}

function main() {
  const [generatorArg, outputArg] = process.argv.slice(2);
  if (!generatorArg || !outputArg) {
    writeUsageError();
    return 2;
  }

  const projectRoot = process.cwd();
  const generator = path.resolve(projectRoot, generatorArg);
  if (!fs.existsSync(generator) || !fs.statSync(generator).isFile()) {
    process.stderr.write(`Generator not found: ${generatorArg}\n`);
    return 2;
  }
  return runLayout({
    generator,
    output: path.resolve(projectRoot, outputArg),
    projectRoot
  });
}

if (require.main === module) process.exitCode = main();

module.exports = { main, runLayout, runNode };
