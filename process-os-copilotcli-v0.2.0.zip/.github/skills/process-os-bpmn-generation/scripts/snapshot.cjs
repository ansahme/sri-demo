#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Compute and save versioned snapshot directories under `<dir>/.snapshots/`.
//
// Replaces the repeated shell ritual skills used to version bpmn-generation and
// artifact-generation output, e.g.:
//   NEXT=$(ls -d <dir>/.snapshots/v*/ 2>/dev/null | wc -l | tr -d ' ')
//   NEXT=$((NEXT + 1))
//   mkdir -p "<dir>/.snapshots/v$NEXT"
//   cp <dir>/*.bpmn "<dir>/.snapshots/v$NEXT/" 2>/dev/null || true
// Every line above is its own PowerShell 5.1 parse error (`NAME=value`,
// `$(( ))`, `mkdir -p`).
//
// Usage:
//   node "snapshot.cjs" next <dir> [--suffix <suffix>]
//   node "snapshot.cjs" save <dir> [<path>...] [--suffix <suffix>] [--exclude <name>...]
//
// `next` only computes and prints the next version label — no directory is
// created. Use it when a later step (e.g. naming a versioned timing dir) needs
// the label before there is anything to snapshot yet; recomputing later with
// `save` is safe as long as nothing else wrote a new `.snapshots/` entry in the
// meantime (every caller of this script is single-threaded).
//
// `save` computes the same label, then:
//   - with no <path> args: creates `<dir>/.snapshots/<label>/` and copies every
//     top-level entry of <dir> into it except `.snapshots` itself (recursive
//     copy) — always creates the directory, even if <dir> is otherwise empty.
//   - with one or more <path> args: the FIRST is the trigger — if it matches
//     nothing, nothing is created and nothing is printed (mirrors the `if ls
//     <dir>/*.bpmn …; then …; fi` guard some callers used to skip snapshotting
//     an empty output dir). Once triggered, every pattern's matches (including
//     ones that match nothing, e.g. an optional `PROCESSES.md`) are copied.
//     A pattern is either a bare name/glob (`*.bpmn`, `PROCESSES.md`) resolved
//     against <dir>, or an explicit path (contains a `/` or `\` or is absolute)
//     resolved as given — so a caller can snapshot one exact file without a
//     shell `dirname`/`basename` step. A glob matches files only, one
//     directory level deep.
//
// `--exclude <name>` is repeatable and names a TOP-LEVEL entry of <dir> to leave
// out of the copy — build output and dependency trees that live inside the
// snapshotted directory (`node_modules`, `dist`, `target`). Omitting the flag
// leaves the copy semantics unchanged.
//
// <dir> may itself be an existing file (e.g. the `--target` of bpmn-generation
// update mode) — its directory becomes the snapshot root, so callers never
// need a separate `dirname` step either.
//
// Prints the version label (bare, nothing else) to stdout when a snapshot was
// created. Silent, exit 0, when the trigger pattern matched nothing. Exit 2 on
// a usage error only.

const fs = require('fs');
const path = require('path');

/**
 * Resolve the directory that owns `.snapshots/` for a given target.
 *
 * @param {string} dirOrFile A directory path, or an existing file whose
 *   directory should be used instead — so callers never need a shell `dirname`.
 * @returns {string}
 */
function resolveBaseDir(dirOrFile) {
  try {
    if (fs.statSync(dirOrFile).isFile()) return path.dirname(dirOrFile);
  } catch {
    // Doesn't exist (yet) — treat the argument as the directory itself.
  }
  return dirOrFile;
}

/**
 * Count existing versioned snapshot dirs and return the next version label.
 *
 * Faithful port of the shell idiom this replaces (count `<dir>/.snapshots/v*`
 * directories via `ls -d … | wc -l`) — counts directories whose name starts
 * with `v`, regardless of what follows. Not a max+1: matches
 * the original count-based behavior exactly, including its quirks.
 *
 * @param {string} baseDir
 * @param {string} [suffix] Appended after the version number, e.g. `-wL-dM`.
 * @returns {string} e.g. `v3`, `v3-wL-dM`.
 */
function nextVersion(baseDir, suffix = '') {
  const snapshotsDir = path.join(baseDir, '.snapshots');
  let count = 0;
  try {
    count = fs.readdirSync(snapshotsDir, { withFileTypes: true })
      .filter((e) => e.isDirectory() && e.name.startsWith('v'))
      .length;
  } catch {
    count = 0;
  }
  return `v${count + 1}${suffix}`;
}

/**
 * Convert a single-segment glob (`*.bpmn`, `PROCESSES.md`) to a RegExp.
 *
 * @param {string} pattern
 * @returns {RegExp}
 */
function globToRegExp(pattern) {
  const escaped = pattern.split('*').map((s) => s.replace(/[.+?^${}()|[\]\\]/g, '\\$&')).join('.*');
  return new RegExp(`^${escaped}$`);
}

/**
 * Whether `p` exists and is a regular file — never throws. A dangling
 * symlink (or a file removed between `readdirSync` and this check) reports
 * `false` instead of raising, mirroring the original shell ritual's
 * `2>/dev/null || true` tolerance for exactly that race.
 *
 * @param {string} p
 * @returns {boolean}
 */
function isRealFile(p) {
  try {
    return fs.statSync(p).isFile();
  } catch {
    return false;
  }
}

/**
 * Resolve one caller-supplied pattern to a list of existing file paths.
 *
 * A pattern containing a path separator (or absolute) is an explicit path,
 * checked as-is. A bare name/glob is resolved against `baseDir`.
 *
 * @param {string} baseDir
 * @param {string} pattern
 * @returns {string[]} Paths in the same style the pattern was given in
 *   (explicit paths are returned as-is; bare names are joined onto baseDir).
 */
function resolvePattern(baseDir, pattern) {
  if (path.isAbsolute(pattern) || pattern.includes('/') || pattern.includes('\\')) {
    return isRealFile(pattern) ? [pattern] : [];
  }
  let entries;
  try {
    entries = fs.readdirSync(baseDir);
  } catch {
    return [];
  }
  const re = globToRegExp(pattern);
  return entries
    .filter((e) => re.test(e))
    .map((e) => path.join(baseDir, e))
    .filter(isRealFile);
}

/**
 * The `fs.symlinkSync` type to recreate a link with, matching what it
 * already points at. `junction` on Windows for a directory target: an
 * ordinary symlink there needs Developer Mode or elevation, a junction does
 * not, and Node reports a junction as a symbolic link through `lstat` either
 * way. POSIX ignores the type argument entirely, so `'file'` there is
 * harmless even when the target is a directory.
 *
 * @param {string} src The symlink itself (used to resolve a relative target).
 * @param {string} target Raw `readlinkSync` value.
 * @returns {'file'|'dir'|'junction'}
 */
function symlinkTypeFor(src, target) {
  if (process.platform !== 'win32') return 'file';
  try {
    const resolved = path.isAbsolute(target) ? target : path.resolve(path.dirname(src), target);
    return fs.statSync(resolved).isDirectory() ? 'junction' : 'file';
  } catch {
    // Dangling link — target doesn't exist (yet). Windows can't create a
    // junction to a nonexistent path either, so 'file' is the only option.
    return 'file';
  }
}

/**
 * Recursively copy a file or directory (mirrors `cp -R`).
 *
 * Uses `lstatSync`, not `statSync` — a symlink is recreated as a symlink,
 * never followed into its target. Following it would let a symlinked
 * directory anywhere under the snapshot root copy content from outside the
 * intended tree.
 *
 * @param {string} src
 * @param {string} dest
 */
function copyRecursive(src, dest) {
  const stat = fs.lstatSync(src);
  if (stat.isSymbolicLink()) {
    const target = fs.readlinkSync(src);
    fs.symlinkSync(target, dest, symlinkTypeFor(src, target));
  } else if (stat.isDirectory()) {
    fs.mkdirSync(dest, { recursive: true });
    for (const entry of fs.readdirSync(src)) {
      copyRecursive(path.join(src, entry), path.join(dest, entry));
    }
  } else {
    fs.copyFileSync(src, dest);
  }
}

/**
 * Create `<baseDir>/.snapshots/<version>/` and copy into it. See file header
 * for the no-patterns vs patterns-given contract.
 *
 * @param {string} dirOrFile
 * @param {string[]} patterns
 * @param {string} [suffix]
 * @param {string[]} [excludes] Top-level entry names to leave out of the copy.
 * @returns {string|null} The version label written, or null when the trigger
 *   pattern matched nothing (so nothing was created).
 */
function save(dirOrFile, patterns, suffix = '', excludes = []) {
  const baseDir = resolveBaseDir(dirOrFile);
  const version = nextVersion(baseDir, suffix);
  const snapDir = path.join(baseDir, '.snapshots', version);
  const skip = new Set(excludes);

  if (patterns.length === 0) {
    fs.mkdirSync(snapDir, { recursive: true });
    let entries = [];
    try {
      entries = fs.readdirSync(baseDir);
    } catch {
      entries = [];
    }
    for (const entry of entries) {
      if (entry === '.snapshots') continue;
      if (skip.has(entry)) continue;
      copyRecursive(path.join(baseDir, entry), path.join(snapDir, entry));
    }
    return version;
  }

  const trigger = resolvePattern(baseDir, patterns[0]);
  if (trigger.length === 0) return null;

  const matches = patterns.flatMap((p, i) => (i === 0 ? trigger : resolvePattern(baseDir, p)));
  fs.mkdirSync(snapDir, { recursive: true });
  for (const m of matches) {
    if (skip.has(path.basename(m))) continue;
    try {
      fs.copyFileSync(m, path.join(snapDir, path.basename(m)));
    } catch {
      // Best-effort, matching the original `cp … 2>/dev/null || true` —
      // one unreadable/removed-mid-run file shouldn't fail the whole snapshot.
    }
  }
  return version;
}

/**
 * @param {string[]} argv Arguments after the script name.
 * @returns {{cmd: string|undefined, dir: string|undefined, patterns: string[], suffix: string, excludes: string[], error?: string}}
 *   `error` is set, and the other fields are incomplete, when a flag is
 *   missing its value — a trailing `--suffix`/`--exclude` with nothing after it,
 *   rather than the next real argument being silently swallowed.
 */
function parseArgs(argv) {
  const [cmd, dir, ...rest] = argv;
  let suffix = '';
  const patterns = [];
  const excludes = [];
  for (let i = 0; i < rest.length; i++) {
    if (rest[i] === '--suffix') {
      if (i + 1 >= rest.length) return { cmd, dir, patterns, suffix, excludes, error: 'missing --suffix value' };
      suffix = rest[++i];
    } else if (rest[i] === '--exclude') {
      if (i + 1 >= rest.length) return { cmd, dir, patterns, suffix, excludes, error: 'missing --exclude value' };
      excludes.push(rest[++i]);
    } else {
      patterns.push(rest[i]);
    }
  }
  return { cmd, dir, patterns, suffix, excludes };
}

module.exports = {
  resolveBaseDir,
  nextVersion,
  globToRegExp,
  isRealFile,
  resolvePattern,
  symlinkTypeFor,
  copyRecursive,
  save,
  parseArgs,
};

if (require.main === module) {
  const { cmd, dir, patterns, suffix, excludes, error } = parseArgs(process.argv.slice(2));
  if (error || !dir || (cmd !== 'next' && cmd !== 'save')) {
    process.stderr.write('usage: snapshot.cjs {next|save} <dir> [<path>...] [--suffix <suffix>] [--exclude <name>...]\n');
    process.exit(2);
  }
  if (cmd === 'next') {
    process.stdout.write(`${nextVersion(resolveBaseDir(dir), suffix)}\n`);
  } else {
    const version = save(dir, patterns, suffix, excludes);
    if (version) process.stdout.write(`${version}\n`);
  }
}
