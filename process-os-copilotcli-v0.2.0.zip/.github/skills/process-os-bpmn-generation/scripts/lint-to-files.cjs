#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Lint each BPMN in a directory to its own report file, printing one status line
// per file.
//
// Replaces the bash ritual this skill repeated three times:
//
//   mkdir -p .camunda/.lint
//   for f in OUTPUT_DIR/*.bpmn; do
//     b=$(basename "$f" .bpmn)
//     node .../validate.cjs "$f" > ".camunda/.lint/$b.txt" 2>&1
//     echo "$b EXIT:$?"
//   done
//
// Every construct in it — `mkdir -p`, `$( )` assignment, `for f in <glob>`, `$?`
// — is a parse error or a wrong answer in native PowerShell 5.1.
//
// The per-file redirect is the point, not an implementation detail: a broken XL
// BPMN can emit lint output larger than the harness's ~25 KB stdout buffer,
// which returns `parser aborted (timeout, resource limit, or over-length)`
// instead of the diagnostics. Only the short `EXIT:` summary reaches stdout; the
// caller Reads the report files it names.
//
// Usage:
//   node "scripts/lint-to-files.cjs" [--report-dir <dir>] <dir> [<pattern>...]
//
//   <pattern>...     Single-segment globs resolved against <dir>. Default `*.bpmn`.
//   --report-dir     Where reports land. Default `.camunda/.lint`.
//
// stdout, one line per file, plus a report at <report-dir>/<basename>.txt:
//   process-01 EXIT:0
//   process-02 EXIT:1
//
// Exit codes:
//   0  every file linted clean
//   1  at least one file has lint findings
//   2  usage error, no file matched, or bpmnlint could not be started for some
//      file — in every one of those cases the files were NOT all linted, so this
//      must never be read as clean

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const { resolvePattern } = require(path.join(__dirname, 'snapshot.cjs'));

const EXIT = { CLEAN: 0, FINDINGS: 1, DID_NOT_RUN: 2 };

const DEFAULT_REPORT_DIR = path.join('.camunda', '.lint');
const DEFAULT_PATTERN = '*.bpmn';

const USAGE =
  'usage: lint-to-files.cjs [--report-dir <dir>] <dir> [<pattern>...]\n';

/**
 * Absolute path to process-os-bpmn-linting's validator.
 *
 * Resolved the way lint-hook.cjs resolves it: three levels up from this
 * `scripts/` dir is the directory holding the `skills/` subtree — the repo root
 * in source, `.claude/` (or the equivalent per agent platform) once installed.
 *
 * @returns {string}
 */
function validatorPath() {
  return path.join(
    path.resolve(__dirname, '..', '..', '..'),
    'skills/process-os-bpmn-linting/scripts/validate.cjs'
  );
}

/**
 * Parse argv into options.
 *
 * @param {string[]} argv Arguments after the script path.
 * @returns {{dir: string, patterns: string[], reportDir: string}}
 * @throws {Error} On an unknown flag, a flag with no value, or a missing <dir>.
 */
function parseArgs(argv) {
  let reportDir = DEFAULT_REPORT_DIR;
  const positional = [];
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--report-dir') {
      // A flag whose value is missing would otherwise swallow the next real
      // argument — the directory to lint — and report "no file matched".
      const value = argv[++i];
      if (value === undefined) throw new Error(`${arg} requires a value`);
      reportDir = value;
    } else if (arg.startsWith('--')) {
      throw new Error(`unknown flag: ${arg}`);
    } else {
      positional.push(arg);
    }
  }
  const [dir, ...patterns] = positional;
  if (!dir) throw new Error('a directory to lint is required');
  return {
    dir,
    patterns: patterns.length ? patterns : [DEFAULT_PATTERN],
    reportDir,
  };
}

/**
 * Every file matching any pattern, de-duplicated, in a stable order.
 *
 * Overlapping patterns are normal at the call sites (`process-*.bpmn` and
 * `edge-*.bpmn` cannot overlap, but `*.bpmn` plus a bare name can), and linting
 * the same file twice would print two contradictory-looking status lines for it.
 *
 * @param {string} dir Directory to look in.
 * @param {string[]} patterns Single-segment globs.
 * @returns {string[]} Paths, sorted.
 */
function collectFiles(dir, patterns) {
  const seen = new Set();
  for (const pattern of patterns) {
    for (const file of resolvePattern(dir, pattern)) seen.add(file);
  }
  return [...seen].sort();
}

/**
 * Lint one file into its own report.
 *
 * @param {string} file BPMN to lint.
 * @param {object} opts
 * @param {string} opts.reportDir Directory the report is written to.
 * @param {string} opts.validator Absolute path to validate.cjs.
 * @param {typeof spawnSync} [opts.run] Injectable runner, for tests.
 * @returns {{basename: string, status: number, launched: boolean}}
 */
function lintOne(file, { reportDir, validator, run = spawnSync }) {
  const basename = path.basename(file, '.bpmn');
  const args = [validator, file];

  // Combine both streams into the report, as the shell's `> file 2>&1` did:
  // bpmnlint writes findings to stdout but the wrapper's own diagnostics to
  // stderr, and dropping either loses half the reason a file is non-clean.
  const result = run(process.execPath, args, { encoding: 'utf8' });
  const output = `${result.stdout || ''}${result.stderr || ''}`;
  const reportPath = path.join(reportDir, `${basename}.txt`);

  // A validator that never started reports status null. That is neither clean
  // nor findings — folded into either it becomes a lint that silently passes.
  const launched = !result.error && result.status !== null;
  fs.writeFileSync(
    reportPath,
    launched
      ? output
      : `LINT DID NOT RUN for ${file}\n${result.error ? result.error.message : 'validator produced no exit status'}\n${output}`
  );
  return { basename, status: launched ? result.status : EXIT.DID_NOT_RUN, launched };
}

/**
 * Lint every matching file in `dir`.
 *
 * @param {ReturnType<typeof parseArgs>} options
 * @param {object} [deps]
 * @param {typeof spawnSync} [deps.run] Injectable runner, for tests.
 * @param {string} [deps.validator] Override the resolved validator path, for tests.
 * @returns {{lines: string[], exitCode: number}}
 */
function lintToFiles(options, deps = {}) {
  const { dir, patterns, reportDir } = options;
  const validator = deps.validator || validatorPath();
  const files = collectFiles(dir, patterns);
  if (files.length === 0) {
    // "Nothing matched" is not "everything is clean": the caller asked for these
    // files to be linted and they were not.
    return {
      lines: [`no file matching ${patterns.join(' ')} in ${dir} — nothing was linted`],
      exitCode: EXIT.DID_NOT_RUN,
    };
  }
  fs.mkdirSync(reportDir, { recursive: true });

  const lines = [];
  let exitCode = EXIT.CLEAN;
  for (const file of files) {
    const { basename, status, launched } = lintOne(file, {
      reportDir,
      validator,
      run: deps.run,
    });
    lines.push(`${basename} EXIT:${status}${launched ? '' : ' (lint did not run)'}`);
    // DID_NOT_RUN outranks FINDINGS: a run where some file was never linted must
    // not be reported as the milder "we linted everything and found problems".
    if (!launched || status === EXIT.DID_NOT_RUN) exitCode = EXIT.DID_NOT_RUN;
    else if (status !== EXIT.CLEAN && exitCode === EXIT.CLEAN) exitCode = EXIT.FINDINGS;
  }
  return { lines, exitCode };
}

module.exports = { EXIT, collectFiles, lintOne, lintToFiles, parseArgs, validatorPath };

if (require.main === module) {
  let options;
  try {
    options = parseArgs(process.argv.slice(2));
  } catch (err) {
    process.stderr.write(`lint-to-files.cjs: ${err.message}\n${USAGE}`);
    process.exit(EXIT.DID_NOT_RUN);
  }
  const { lines, exitCode } = lintToFiles(options);
  process.stdout.write(`${lines.join('\n')}\n`);
  process.exit(exitCode);
}
