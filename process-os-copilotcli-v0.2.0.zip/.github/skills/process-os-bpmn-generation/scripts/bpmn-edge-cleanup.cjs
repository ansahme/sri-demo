/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';
// bpmn-edge-cleanup.cjs <file.bpmn> — post-layout DI cleanup that minimises edge bends.
// 1. Collapse collinear/redundant waypoints (always; purely cosmetic, safe).
// 2. Re-route "staircase" edges (>=6 waypoints after collapse) through ONE clear
//    horizontal channel instead of bumping each intervening node — but only when the
//    re-routed orthogonal path crosses no element shape (else keep the collapsed original).
// Idempotent. Mutates the file in place. Orthogonal-preserving.

const fs = require('node:fs');

const file = process.argv[2];
if (!file) { console.error('Usage: bpmn-edge-cleanup.cjs <file.bpmn>'); process.exit(2); }
let xml = fs.readFileSync(file, 'utf8');

// ---- parse shapes (element bounds) ----
const shapes = {};
for (const m of xml.matchAll(/<bpmndi:BPMNShape\b[^>]*\bbpmnElement="([^"]+)"[^>]*>\s*<dc:Bounds x="([-\d.]+)" y="([-\d.]+)" width="([-\d.]+)" height="([-\d.]+)"/g)) {
  shapes[m[1]] = { x: +m[2], y: +m[3], w: +m[4], h: +m[5] };
}
// ---- sequenceFlow src/tgt ----
const flow = {};
for (const m of xml.matchAll(/<bpmn:sequenceFlow id="([^"]+)"[^>]*\bsourceRef="([^"]+)"[^>]*\btargetRef="([^"]+)"/g)) {
  flow[m[1]] = { s: m[2], t: m[3] };
}

const MARGIN = 8;          // clearance around shapes
const STAIR = 6;           // waypoint count that flags a staircase
function rectHit(ax1, ay1, ax2, ay2, r) {           // orthogonal segment vs rect (inflated)
  const x1 = Math.min(ax1, ax2), x2 = Math.max(ax1, ax2);
  const y1 = Math.min(ay1, ay2), y2 = Math.max(ay1, ay2);
  return x1 <= r.x + r.w + MARGIN && x2 >= r.x - MARGIN &&
         y1 <= r.y + r.h + MARGIN && y2 >= r.y - MARGIN;
}
function pathClear(wps, exclude) {
  for (let i = 1; i < wps.length; i++) {
    for (const [id, r] of Object.entries(shapes)) {
      if (exclude.has(id)) continue;
      if (rectHit(wps[i - 1][0], wps[i - 1][1], wps[i][0], wps[i][1], r)) return false;
    }
  }
  return true;
}
function collapse(wps) {                              // drop redundant collinear midpoints
  const out = [wps[0]];
  for (let i = 1; i < wps.length - 1; i++) {
    const a = out[out.length - 1], b = wps[i], c = wps[i + 1];
    const collinear = (Math.abs(a[0] - b[0]) < 1 && Math.abs(b[0] - c[0]) < 1) ||
                      (Math.abs(a[1] - b[1]) < 1 && Math.abs(b[1] - c[1]) < 1);
    if (!collinear) out.push(b);
  }
  out.push(wps[wps.length - 1]);
  // also drop a zero-length duplicate
  return out.filter((p, i) => i === 0 || Math.abs(p[0] - out[i - 1][0]) > 0.5 || Math.abs(p[1] - out[i - 1][1]) > 0.5);
}
function orthogonalize(wps, src, tgt) {            // split diagonal segments into clean L's
  const excl = new Set(Object.keys(shapes).filter(id => shapes[id] === src || shapes[id] === tgt));
  const out = [wps[0]];
  for (let i = 1; i < wps.length; i++) {
    const a = out[out.length - 1], b = wps[i];
    if (Math.abs(a[0] - b[0]) > 0.5 && Math.abs(a[1] - b[1]) > 0.5) {        // diagonal
      const h = [b[0], a[1]];                                                // horizontal-then-vertical corner
      const v = [a[0], b[1]];                                                // vertical-then-horizontal corner
      const clr = (c) => pathClear([a, c, b], excl);
      if (clr(h)) out.push(h);
      else if (clr(v)) out.push(v);
      else out.push(h);                                                      // fallback: still orthogonalise (better than diagonal)
    }
    out.push(b);
  }
  return out;
}
function reroute(wps, src, tgt) {
  if (!src || !tgt) return wps;
  const sCx = src.x + src.w / 2, tCx = tgt.x + tgt.w / 2;
  const interior = wps.slice(1, -1).map(p => p[1]);
  if (!interior.length) return wps;
  const above = Math.min(...interior), below = Math.max(...interior);
  // pick the channel the router already used and that sits beyond the node band
  const cands = [];
  if (above < src.y && above < tgt.y) cands.push({ y: above, sEdge: src.y, tEdge: tgt.y });               // route over the top
  if (below > src.y + src.h && below > tgt.y + tgt.h) cands.push({ y: below, sEdge: src.y + src.h, tEdge: tgt.y + tgt.h }); // under the bottom
  for (const c of cands) {
    const cand = [[sCx, c.sEdge], [sCx, c.y], [tCx, c.y], [tCx, c.tEdge]];
    if (pathClear(cand, new Set([])) === false) {
      // allow the path to touch src/tgt themselves
      if (!pathClear(cand, new Set(Object.keys(shapes).filter(id => shapes[id] === src || shapes[id] === tgt)))) continue;
    }
    return cand;
  }
  return wps;
}

let collapsed = 0, rerouted = 0;
xml = xml.replace(/(<bpmndi:BPMNEdge\b[^>]*\bbpmnElement="([^"]+)"[^>]*>)([\s\S]*?)(<\/bpmndi:BPMNEdge>)/g,
  (full, open, elId, body, close) => {
    const wpRe = /<di:waypoint x="([-\d.]+)" y="([-\d.]+)"\s*\/>/g;
    let wps = [...body.matchAll(wpRe)].map(w => [+w[1], +w[2]]);
    if (wps.length < 2) return full;
    const before = JSON.stringify(wps);
    const f = flow[elId];
    const src = f && shapes[f.s], tgt = f && shapes[f.t];
    wps = orthogonalize(collapse(wps), src, tgt);     // de-skew first
    if (wps.length >= STAIR) {                         // then de-bend staircases
      const rr = reroute(wps, src, tgt);
      if (rr !== wps && rr.length < wps.length) { wps = rr; rerouted++; }
    }
    wps = collapse(wps);
    if (JSON.stringify(wps) !== before) collapsed++;
    const wpXml = wps.map(p => `        <di:waypoint x="${p[0]}" y="${p[1]}" />`).join('\n');
    // preserve any <bpmndi:BPMNLabel> after waypoints
    const label = (body.match(/<bpmndi:BPMNLabel[\s\S]*?<\/bpmndi:BPMNLabel>|<bpmndi:BPMNLabel\s*\/>/) || [''])[0];
    return `${open}\n${wpXml}${label ? '\n        ' + label : ''}\n      ${close}`;
  });

fs.writeFileSync(file, xml);
console.log(`edge-cleanup: ${file.split('/').pop()} — ${collapsed} edges simplified, ${rerouted} staircases re-routed`);
