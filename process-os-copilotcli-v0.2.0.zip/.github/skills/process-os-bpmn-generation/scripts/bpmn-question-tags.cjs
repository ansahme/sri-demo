#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Materialize review-question metadata into generated BPMN, deterministically.
//
// Reads <dir>/question-targets.json (the contract the review UI binds question cards to
// elements with) and, for every element id it names:
//   1. injects  <bpmn:documentation>[<SEVERITY>] (qN)</bpmn:documentation>  as that element's
//      first child, across every *.bpmn in <dir>;
//   2. re-emits <dir>/annotations.md from the resulting tags.
//
// The exact inverse of process-os-review-answer-application's mark-resolved.cjs, which flips
// tags to [RESOLVED] once answers land. Both share extractTagRows/renderAnnotations from here,
// so the two passes cannot drift on the element-type list or the table format.
//
// Also reads <dir>/confirm-targets.json when present — `[{ "elementId", "step" }]`, one entry per
// element that carries no review question but still needs a human to confirm its disposition — and
// injects a bare <bpmn:documentation>[CONFIRM]</bpmn:documentation> on each. Bare tags carry no qN,
// so they reach neither annotations.md nor mark-resolved; the file exists so that the same re-run
// that restores the (qN) tags after a regeneration restores these too. When a question also names
// the element, the question's tag wins: it is the one a review can resolve.
//
// Idempotent and commutative with mark-resolved: a tag is *replaced* when it already holds a
// [SEVERITY] (qN) or bare [CONFIRM] value, so re-running after answers land simply restores
// whatever the two files now say. Prose documentation (e.g. an ad-hoc tool description) is never
// clobbered — it is reported as a conflict instead.
//
// Edits the BPMN as text rather than through bpmnkit. The model path would be semantically safe
// (applyBpmnOperations preserves annotations and template bindings; the older compactify round-trip
// does not), but exporting re-serializes the whole document: a no-op pass over a discovery pendant
// rewrites most of its lines. This injector runs repeatedly over files humans read and review, so it
// replaces the tag and leaves every other byte alone.
//
// Output: a human summary, or JSON with --json.
// Exit: 0 clean; 1 some target unresolved or in conflict; 2 invalid input.
// Usage:
//   node bpmn-question-tags.cjs [--dir <dir>] [--title "<annotations heading>"] [--json]

'use strict';

const fs = require('fs');
const path = require('path');

const SEVERITIES = ['OPEN', 'RISK', 'CONFIRM', 'CONFLICT', 'RESOLVED'];

// Every element type the ProcessOS toolchain can put in a generated BPMN and a question can bind
// to. Deliberately wider than the nine types mark-resolved.cjs used to hard-code: 00-overview.bpmn
// is built from bpmnkit `.task()` calls, and phase BPMNs carry boundary events, sub-processes and
// ad-hoc sub-processes — all of which were silently dropped from annotations.md before.
const TAGGABLE_TYPES = [
  'task',
  'userTask',
  'serviceTask',
  'scriptTask',
  'manualTask',
  'businessRuleTask',
  'sendTask',
  'receiveTask',
  'callActivity',
  'subProcess',
  'adHocSubProcess',
  'exclusiveGateway',
  'parallelGateway',
  'inclusiveGateway',
  'eventBasedGateway',
  'startEvent',
  'endEvent',
  'intermediateCatchEvent',
  'intermediateThrowEvent',
  'boundaryEvent',
];

const DEFAULT_TITLE = '# AS-IS BPMN Annotations Index';
const TAG_RE = /^\[(OPEN|RISK|CONFIRM|CONFLICT|RESOLVED)\] \((q\d+)\)$/;
const BARE_CONFIRM = '[CONFIRM]';

// Documentation this script wrote and may therefore rewrite. Anything else is prose it must keep.
function ownedByInjector(text) {
  return TAG_RE.test(text) || text === BARE_CONFIRM;
}

// Open tag of any taggable element. Group 1 = type, 2 = attributes, 3 = "/" when self-closing.
// Attributes are matched as a blob and parsed separately so attribute *order* never matters —
// `c8ctl element-template apply` prepends zeebe:modelerTemplate to bound elements. `>` cannot
// appear raw inside a BPMN attribute value (it is escaped as &gt;), so [^>]* is safe here.
const OPEN_TAG_RE = new RegExp(`<bpmn:(${TAGGABLE_TYPES.join('|')})((?:\\s[^>]*?)?)(/?)>`, 'g');

function attr(attrs, name) {
  const m = attrs.match(new RegExp(`\\s${name}="([^"]*)"`));
  return m ? m[1] : undefined;
}

function parseArgs(argv) {
  const o = { dir: 'process-discovery', title: DEFAULT_TITLE, json: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--dir') o.dir = argv[++i];
    else if (a === '--title') o.title = argv[++i];
    else if (a === '--json') o.json = true;
    else if (a === '--help' || a === '-h') o.help = true;
    else return { ...o, error: `unknown option: ${a}` };
  }
  if (o.title !== undefined && o.title !== null && !String(o.title).startsWith('#')) {
    o.title = `# ${o.title}`;
  }
  return o;
}

function listBpmn(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs
    .readdirSync(dir)
    .filter((f) => f.endsWith('.bpmn'))
    .sort()
    .map((f) => path.join(dir, f));
}

// Validate question-targets.json into a Map<elementId, "[SEV] (qN)">, or throw on bad input.
//
// Several questions may name the same element — the review UI binds a question card to any number
// of elements and an element to any number of cards. A `<bpmn:documentation>` child holds one
// `[SEVERITY] (qN)` value, though, so only the lowest-numbered question materializes as that
// element's tag; the rest are returned in `shared` for the caller to report. Rejecting the input
// instead would refuse a shape the UI and the question selector both accept.
function tagsByElement(targets) {
  if (!Array.isArray(targets)) throw new Error('question-targets.json must be a JSON array');
  const byElement = new Map();
  const shared = [];
  const qnum = (id) => parseInt(id.slice(1), 10);
  for (const entry of targets) {
    if (!entry || typeof entry !== 'object') throw new Error('question-targets.json entries must be objects');
    if (!/^q\d+$/.test(entry.id || '')) throw new Error(`invalid question id ${JSON.stringify(entry.id)} — expected qN`);
    if (!SEVERITIES.includes(entry.severity)) {
      throw new Error(`invalid severity ${JSON.stringify(entry.severity)} for ${entry.id} — expected one of ${SEVERITIES.join(', ')}`);
    }
    const candidate = { qid: entry.id, severity: entry.severity, tag: `[${entry.severity}] (${entry.id})` };
    for (const elementId of entry.targets?.bpmn ?? []) {
      const existing = byElement.get(elementId);
      if (existing && existing.qid !== candidate.qid) {
        const [keep, drop] =
          qnum(existing.qid) <= qnum(candidate.qid) ? [existing, candidate] : [candidate, existing];
        shared.push({ elementId, tagged: keep.qid, alsoBound: drop.qid });
        byElement.set(elementId, keep);
        continue;
      }
      byElement.set(elementId, candidate);
    }
  }
  return { byElement, shared };
}

// Add confirm-targets.json's elements to `byElement` as bare [CONFIRM] targets, or throw on bad
// input. An element a question already names keeps the question's tag and is returned in
// `superseded`: both claim the one documentation child, and only the question can be resolved.
function addConfirmTargets(entries, byElement) {
  if (!Array.isArray(entries)) throw new Error('confirm-targets.json must be a JSON array');
  const superseded = [];
  for (const entry of entries) {
    if (!entry || typeof entry !== 'object') throw new Error('confirm-targets.json entries must be objects');
    if (typeof entry.elementId !== 'string' || entry.elementId.trim() === '') {
      throw new Error(`confirm-targets.json entry needs a non-empty elementId: ${JSON.stringify(entry)}`);
    }
    const question = byElement.get(entry.elementId);
    if (question && !question.bare) {
      superseded.push({ elementId: entry.elementId, tagged: question.qid });
      continue;
    }
    byElement.set(entry.elementId, { bare: true, tag: BARE_CONFIRM });
  }
  return superseded;
}

// Inject/replace the documentation tag on every targeted element across `bpmns`.
function injectTags(bpmns, byElement) {
  const tagged = new Set();
  const conflicts = [];
  const filesTouched = new Set();
  let tagsWritten = 0;
  let bareWritten = 0;

  for (const file of bpmns) {
    const xml = fs.readFileSync(file, 'utf8');
    let out = '';
    let cursor = 0;
    OPEN_TAG_RE.lastIndex = 0;
    let m;
    while ((m = OPEN_TAG_RE.exec(xml)) !== null) {
      const [full, type, attrs, selfClosing] = m;
      const id = attr(attrs, 'id');
      const want = id ? byElement.get(id) : undefined;
      if (!want) continue;

      const indent = (xml.slice(0, m.index).match(/\n([ \t]*)$/) || ['', '    '])[1];
      const docEl = `<bpmn:documentation>${want.tag}</bpmn:documentation>`;
      const after = xml.slice(m.index + full.length);

      // An existing documentation child is replaced only when this script wrote it — a question
      // tag or a bare [CONFIRM]; prose (an ad-hoc tool description, a start-event input contract)
      // is left alone.
      const existing = selfClosing ? null : after.match(/^(\s*)<bpmn:documentation>([\s\S]*?)<\/bpmn:documentation>/);
      if (existing && !ownedByInjector(existing[2].trim())) {
        conflicts.push({ file, elementId: id, existing: existing[2].trim().slice(0, 80) });
        continue;
      }

      out += xml.slice(cursor, m.index);
      if (selfClosing) {
        // `<x a="1" />` captures the space before the slash — drop it so the opened tag is clean.
        out += `<bpmn:${type}${attrs.replace(/\s+$/, '')}>\n${indent}  ${docEl}\n${indent}</bpmn:${type}>`;
        cursor = m.index + full.length;
      } else {
        out += `${full}\n${indent}  ${docEl}`;
        cursor = m.index + full.length + (existing ? existing[0].length : 0);
      }
      tagged.add(id);
      tagsWritten++;
      if (want.bare) bareWritten++;
    }
    if (cursor === 0) continue;
    out += xml.slice(cursor);
    fs.writeFileSync(file, out);
    filesTouched.add(file);
  }

  const unresolved = [...byElement.keys()].filter((id) => !tagged.has(id) && !conflicts.some((c) => c.elementId === id));
  return { tagsWritten, bareWritten, filesTouched, unresolved, conflicts };
}

// Collect one row per [SEVERITY] (qN) tag found across `bpmns`, ordered by question number.
function extractTagRows(bpmns, summaries = {}) {
  const rows = [];
  for (const file of bpmns) {
    const xml = fs.readFileSync(file, 'utf8');
    OPEN_TAG_RE.lastIndex = 0;
    let m;
    while ((m = OPEN_TAG_RE.exec(xml)) !== null) {
      const [full, , attrs, selfClosing] = m;
      if (selfClosing) continue;
      const doc = xml.slice(m.index + full.length).match(/^\s*<bpmn:documentation>([\s\S]*?)<\/bpmn:documentation>/);
      if (!doc) continue;
      const tag = doc[1].trim().match(TAG_RE);
      if (!tag) continue;
      rows.push({
        qid: tag[2],
        severity: tag[1],
        elementId: attr(attrs, 'id') || '',
        elementName: attr(attrs, 'name') || '',
        question: summaries[tag[2]] || '',
      });
    }
  }
  rows.sort((a, b) => parseInt(a.qid.slice(1), 10) - parseInt(b.qid.slice(1), 10) || a.elementId.localeCompare(b.elementId));
  return rows;
}

function renderAnnotations(rows, title = DEFAULT_TITLE) {
  return (
    [
      title,
      '',
      'Each row corresponds to a `<bpmn:documentation>[SEVERITY] (qN)</bpmn:documentation>` tag.',
      '',
      '| Q#  | Severity   | Element ID | Element Name | Question |',
      '|-----|------------|------------|--------------|----------|',
      ...rows.map((r) => `| ${r.qid} | [${r.severity}] | ${r.elementId} | ${r.elementName} | ${r.question} |`),
    ].join('\n') + '\n'
  );
}

// The heading an existing annotations.md already uses, so a later pass never rewrites it.
function existingTitle(dir, fallback = DEFAULT_TITLE) {
  const file = path.join(dir, 'annotations.md');
  if (!fs.existsSync(file)) return fallback;
  const first = fs.readFileSync(file, 'utf8').split('\n')[0];
  return /^#\s+\S/.test(first) ? first : fallback;
}

function writeAnnotations(dir, bpmns, summaries, title, filesTouched) {
  const out = path.join(dir, 'annotations.md');
  fs.writeFileSync(out, renderAnnotations(extractTagRows(bpmns, summaries), title));
  filesTouched.add(out);
}

function applyQuestionTags(dir, { title = DEFAULT_TITLE } = {}) {
  const targetsPath = path.join(dir, 'question-targets.json');
  if (!fs.existsSync(targetsPath)) {
    throw new Error(`missing ${targetsPath} — write it first (one entry per ### Q<N> heading in review-questions.md)`);
  }
  let targets;
  try {
    targets = JSON.parse(fs.readFileSync(targetsPath, 'utf8'));
  } catch (e) {
    throw new Error(`${targetsPath} is not valid JSON: ${e.message}`);
  }
  const { byElement, shared } = tagsByElement(targets);

  // Absent means no element needs a bare [CONFIRM]; present but unreadable is bad input, and must
  // fail before any .bpmn is touched rather than tag half the set.
  const confirmPath = path.join(dir, 'confirm-targets.json');
  let confirmTargets = [];
  if (fs.existsSync(confirmPath)) {
    try {
      confirmTargets = JSON.parse(fs.readFileSync(confirmPath, 'utf8'));
    } catch (e) {
      throw new Error(`${confirmPath} is not valid JSON: ${e.message}`);
    }
  }
  const superseded = addConfirmTargets(confirmTargets, byElement);

  const bpmns = listBpmn(dir);
  if (bpmns.length === 0) throw new Error(`no *.bpmn in ${dir} — generate the BPMN before tagging it`);

  const { tagsWritten, bareWritten, filesTouched, unresolved, conflicts } = injectTags(bpmns, byElement);
  const summaries = Object.fromEntries(targets.map((t) => [t.id, t.summary || '']));
  writeAnnotations(dir, bpmns, summaries, title, filesTouched);

  return {
    dir,
    bpmnFiles: bpmns.length,
    questions: targets.length,
    elementsTargeted: byElement.size,
    confirmTargets: confirmTargets.length,
    tagsWritten,
    bareWritten,
    unresolved,
    conflicts,
    shared,
    superseded,
    filesTouched: [...filesTouched],
  };
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) {
    process.stdout.write(
      'Usage: node bpmn-question-tags.cjs [--dir <dir>] [--title "<annotations heading>"] [--json]\n' +
        'Injects [SEVERITY] (qN) documentation tags from <dir>/question-targets.json, and bare [CONFIRM]\n' +
        'tags from <dir>/confirm-targets.json when present, into <dir>/*.bpmn, then re-emits\n' +
        '<dir>/annotations.md. Exit 1 if a target is unresolved or in conflict; 2 on invalid input.\n'
    );
    process.exit(0);
  }
  if (opts.error) {
    process.stderr.write(`bpmn-question-tags: ${opts.error}\n`);
    process.exit(2);
  }

  let result;
  try {
    result = applyQuestionTags(opts.dir, { title: opts.title });
  } catch (e) {
    process.stderr.write(`bpmn-question-tags: ${e.message}\n`);
    process.exit(2);
  }

  if (opts.json) {
    process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  } else {
    process.stdout.write(
      `Tagged ${result.tagsWritten} element(s) for ${result.questions} question(s)` +
        (result.confirmTargets ? ` and ${result.confirmTargets} confirm target(s)` : '') +
        ` across ${result.bpmnFiles} BPMN file(s); ${result.filesTouched.length} file(s) touched.\n`
    );
    for (const id of result.unresolved) {
      process.stderr.write(`  unresolved: no taggable element "${id}" in any ${result.dir}/*.bpmn\n`);
    }
    for (const c of result.conflicts) {
      process.stderr.write(`  conflict: ${c.elementId} already documents prose, left untouched: "${c.existing}"\n`);
    }
    for (const s of result.shared) {
      process.stdout.write(
        `  shared: ${s.elementId} is bound to ${s.tagged} and ${s.alsoBound}; tagged ${s.tagged} (one tag per element)\n`
      );
    }
    for (const s of result.superseded) {
      process.stdout.write(
        `  superseded: ${s.elementId} is a confirm target and bound to ${s.tagged}; tagged ${s.tagged} (a question outranks a bare [CONFIRM])\n`
      );
    }
  }
  process.exit(result.unresolved.length || result.conflicts.length ? 1 : 0);
}

if (require.main === module) main();

module.exports = {
  applyQuestionTags,
  extractTagRows,
  renderAnnotations,
  existingTitle,
  listBpmn,
  parseArgs,
  DEFAULT_TITLE,
  BARE_CONFIRM,
  SEVERITIES,
  TAGGABLE_TYPES,
};
