/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// PostToolUse(Bash) hook. The PostToolUse matcher only matches the tool NAME
// ("Bash"), not the command text. Two-layer narrowing:
//   1. Each registered handler carries an `if` holding a single Bash permission
//      rule (no OR), which the harness evaluates against the actual command, so
//      node is spawned ONLY for a command that matches.
//   2. This script then narrows precisely: it exits 0 instantly unless the
//      command ran a bpmnkit generator (`*.bpmn.gen.mjs`), a `c8ctl
//      element-template apply ... <file>.bpmn`, or an AI Agent post-apply patch
//      (`*.bpmn.ai-agent.mjs`), and lints exactly the produced/modified .bpmn
//      file(s) — no directory mtime scan.
//
// DETERMINISM: this hook calls the bpmnlint CLI and the validate.cjs SCRIPT
// directly — never the process-os-bpmn-linting / process-os-camunda-compatibility-check
// *skills* (those are LLM-driven wrappers). Same input -> same output, no model in the loop.
//
// PORTABILITY: bpmnlint is run by spawning its JS entrypoint with process.execPath,
// never by exec'ing the extensionless .bin/bpmnlint shim, which cannot be exec'd on
// Windows. A launch failure is its own outcome (LintNotRunError -> a
// "LINT DID NOT RUN" block -> exit 2); swallowed instead, it would leave the BPMN
// unlinted with the hook exiting 0.
//
// Both modes are linted; profile per file by isExecutable:
//   isExecutable="false" (or absent) -> structural: bpmnlint binary with the
//        process-os-bpmn-linting .bpmnlintrc (bpmnlint:recommended + plugin:process-os/recommended).
//        NOT c8ctl: `c8ctl bpmn lint` ERRORS on isExecutable="false"
//        ("Property <isExecutable> must have value of <true>") — it only lints
//        executable processes, so it cannot lint strategic BPMN. (verified)
//   isExecutable="true"              -> compat: process-os-camunda-compatibility-check/scripts/validate.cjs
//        (--version CAMUNDA_COMPAT_VERSION: bpmnlint:recommended + camunda-cloud + process-os,
//         a true superset of structural — one run covers everything).
// Exits 2 with findings on stderr (surfaced to the agent); exits 0 when clean
// or when the command is unrelated. See Claude Code hooks docs.

const fs = require('node:fs');
const path = require('node:path');
const { resolveNodeCliEntry, runNodeCli, runShellCli } =
  require(path.join(__dirname, 'resolve-node-cli.cjs'));
const { stripBOM } = require(path.join(__dirname, 'strip-bom.cjs'));

/**
 * Thrown when the linter could not be started at all — as opposed to running and
 * reporting problems. Callers must surface this, never treat it as "clean".
 */
class LintNotRunError extends Error {
  /** @param {string} message Why the linter never ran. */
  constructor(message) {
    super(message);
    this.name = 'LintNotRunError';
  }
}

/**
 * @typedef {'structural' | 'compat'} LintProfile
 */

/**
 * @typedef {'8.8' | '8.9' | '8.10'} CamundaCompatVersion
 */

/**
 * @callback LintRunner
 * @param {string} cmd Executable. `process.execPath` means "args[0] is a JS entry".
 * @param {string[]} args
 * @param {Object.<string, string | undefined>} [extraEnv]
 * @returns {string} Empty string when clean; combined stdout/stderr when the
 *   linter ran and reported problems.
 * @throws {LintNotRunError} When the linter could not be started at all.
 */

/**
 * Supported Camunda versions for executable BPMN compatibility lint.
 *
 * @enum {string}
 */
const CAMUNDA_COMPAT_VERSION = Object.freeze({
  V8_8: '8.8',
  V8_9: '8.9',
  V8_10: '8.10',
});

const CAMUNDA_COMPAT_VERSIONS = new Set(Object.values(CAMUNDA_COMPAT_VERSION));

/**
 * Default Camunda version for executable BPMN compatibility lint.
 *
 * @type {CamundaCompatVersion}
 */
const DEFAULT_CAMUNDA_COMPAT_VERSION = CAMUNDA_COMPAT_VERSION.V8_9;

/**
 * Selects the lint profile from the BPMN process executable flag.
 *
 * @param {string} xml BPMN XML content.
 * @returns {LintProfile} Compat for executable BPMN; structural otherwise.
 */
function profileFor(xml) {
  const m = xml.match(/<bpmn:process\b[^>]*\bisExecutable="(true|false)"/);
  return m && m[1] === 'true' ? 'compat' : 'structural';
}

/**
 * Extracts the .bpmn target(s) this command produced or modified.
 *
 * @param {string} cmd Bash command from the PostToolUse event.
 * @returns {string[]} BPMN paths for generator, template-apply, or AI Agent patch runs; [] otherwise.
 */
function targetsFromCommand(cmd) {
  if (!cmd) return [];
  const out = new Set();
  // 1. bpmnkit generator: `node "<OUTPUT>.bpmn.gen.mjs"` -> "<OUTPUT>.bpmn"
  for (const m of cmd.matchAll(/([^\s'"]+\.bpmn)\.gen\.mjs/g)) out.add(m[1]);
  // 2. AI Agent post-apply patch: `node "<OUTPUT>.bpmn.ai-agent.mjs"` -> "<OUTPUT>.bpmn"
  for (const m of cmd.matchAll(/([^\s'"]+\.bpmn)\.ai-agent\.mjs/g)) out.add(m[1]);
  // 3. connector apply: lint the .bpmn arg only on an element-template apply
  if (/element-template\s+apply\b/.test(cmd)) {
    for (const m of cmd.matchAll(/([^\s'"]+\.bpmn)\b/g)) out.add(m[1]);
  }
  return [...out];
}

/**
 * @returns {string} Absolute path to the directory containing the `skills/` subtree.
 *   In the source repo: the repo root (skills/ is at repo-root/skills/).
 *   When installed:     the .claude/ dir (skills/ is at .claude/skills/).
 */
function skillsRoot() {
  return path.resolve(__dirname, '..', '..', '..');
}

/**
 * @param {string} version Camunda version to check.
 * @returns {boolean} Whether this hook can run compat lint for the version.
 */
function isCamundaCompatVersion(version) {
  return CAMUNDA_COMPAT_VERSIONS.has(version);
}

/**
 * Lints one BPMN file with the profile implied by its executable flag.
 *
 * @param {string} file BPMN file path.
 * @param {string} plugin Absolute path to the plugin root.
 * @param {CamundaCompatVersion} [camundaVersion=DEFAULT_CAMUNDA_COMPAT_VERSION] Camunda version passed to compat lint.
 * @param {LintRunner} [runner=run] Injectable command runner for tests.
 * @returns {string} Empty string when clean; lint output when findings or command errors occur.
 */
function lintFile(file, plugin, camundaVersion = DEFAULT_CAMUNDA_COMPAT_VERSION, runner = run) {
  const xml = fs.readFileSync(file, 'utf8');
  if (profileFor(xml) === 'compat') {
    if (!isCamundaCompatVersion(camundaVersion)) {
      throw new RangeError(`Unsupported Camunda compat version: ${camundaVersion}`);
    }
    // process-os-camunda-compatibility-check: superset of structural (recommended + camunda-cloud +
    // process-os). One run covers everything for executable files.
    const validate = path.join(plugin, 'skills/process-os-camunda-compatibility-check/scripts/validate.cjs');
    return runner(process.execPath, [validate, '--version', camundaVersion, file]);
  }
  // structural: process-os-bpmn-linting config (recommended + process-os custom rules).
  const nodePath = path.join(plugin, 'skills/process-os-bpmn-linting/plugins');
  const rc = path.join(plugin, 'skills/process-os-bpmn-linting/.bpmnlintrc');
  // .bpmnlintrc is not shipped (process-os-bpmn-linting/validate.cjs writes it inline on
  // first use, so the skill ships no dotfile that would be dropped during
  // packaging — see that script). This hook calls bpmnlint directly and
  // never invokes validate.cjs (see DETERMINISM above), so it cannot rely on
  // that write having already happened earlier in the session — write the
  // identical config here too if it's still missing, so the very first
  // bpmnkit-generator call in a fresh session doesn't fail lint on a missing
  // config file.
  if (!fs.existsSync(rc)) {
    fs.writeFileSync(
      rc,
      JSON.stringify({ extends: ['bpmnlint:recommended', 'plugin:process-os/recommended'] }, null, 2) + '\n',
    );
  }
  // Spawn bpmnlint's JS entry, never the .bin shim (unrunnable on Windows).
  const entry = resolveNodeCliEntry('bpmnlint', {
    searchPaths: [path.join(process.cwd(), '.camunda'), process.cwd()],
  });
  const cmd = entry ? process.execPath : 'npx';
  const args = entry
    ? [entry, '--config', rc, file]
    : ['--yes', 'bpmnlint', '--config', rc, file];
  return runner(cmd, args, { NODE_PATH: nodePath });
}

/**
 * @param {string} cmd Executable to run. `process.execPath` means args[0] is a JS entry.
 * @param {string[]} args Command arguments.
 * @param {Object.<string, string | undefined>} [extraEnv] Environment overrides.
 * @returns {string} Empty string on success; combined stdout/stderr when the linter
 *   ran and reported problems.
 * @throws {LintNotRunError} When the child could not be started.
 */
function run(cmd, args, extraEnv) {
  const opts = { encoding: 'utf8', env: { ...process.env, ...extraEnv } };
  const r = cmd === process.execPath
    ? runNodeCli(args[0], args.slice(1), opts)
    : runShellCli(cmd, args, opts);
  if (!r.launched) {
    throw new LintNotRunError(`${cmd} could not be started: ${r.error && r.error.message}`);
  }
  if (r.status === 0) return '';
  return (r.stdout || '') + (r.stderr || '');
}

/**
 * Join per-file findings into one block, bounded so hook stderr never blows the harness's
 * ~25KB Bash buffer (an unbounded dump returns "parser aborted" instead of the findings).
 * @param {string[]} problems Per-file findings blocks.
 * @param {number} [max] Max characters before truncation.
 * @returns {string} The joined findings, truncated with a pointer if over `max`.
 */
function capFindings(problems, max = 12000) {
  const body = problems.join('\n\n');
  if (body.length <= max) return body;
  return body.slice(0, max) +
    `\n\n…[truncated at ${max} chars — ${problems.length} file(s) with findings; ` +
    'lint the file directly for the full report]';
}

function main() {
  let event = {};
  try { event = JSON.parse(stripBOM(fs.readFileSync(0, 'utf8')) || '{}'); } catch { /* ignore */ }
  const cwd = event.cwd || process.cwd();
  const cmd = (event.tool_input && event.tool_input.command) || '';
  const targets = targetsFromCommand(cmd)
    .map((t) => (path.isAbsolute(t) ? t : path.join(cwd, t)))
    .filter((p) => fs.existsSync(p));
  if (targets.length === 0) process.exit(0);
  const plugin = skillsRoot();
  const problems = [];
  for (const f of targets) {
    const rel = path.relative(cwd, f);
    let out;
    try {
      out = lintFile(f, plugin).trim();
    } catch (e) {
      if (!(e instanceof LintNotRunError)) throw e;
      // Reported unconditionally — NOT filtered through the findings regex below.
      // "The linter never ran" must never be indistinguishable from "clean".
      problems.push(`# ${rel}\nLINT DID NOT RUN: ${e.message}\n` +
        'This BPMN was NOT validated. Run `c8 os install` (or `c8 os update`) and re-run the generator.');
      continue;
    }
    if (out && /error|warning|✖/i.test(out)) problems.push(`# ${rel}\n${out}`);
  }
  if (problems.length === 0) process.exit(0);
  process.stderr.write(
    'BPMN lint findings (fix the bpmnkit .gen.mjs script or the element-template apply call, then re-run):\n\n' +
      capFindings(problems) + '\n');
  process.exit(2);
}

if (require.main === module) main();
module.exports = { CAMUNDA_COMPAT_VERSION, DEFAULT_CAMUNDA_COMPAT_VERSION, LintNotRunError, capFindings, isCamundaCompatVersion, lintFile, profileFor, targetsFromCommand };
