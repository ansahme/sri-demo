/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';
// bpmn-di-check.cjs <file.bpmn> — assert the diagram DI is COMPLETE; exit non-zero if not.
//
// Guards the bpmn-io primary layout path. The layout engine supports
// collaborations, artifacts, groups, message flows, and associations, but it
// can still throw or produce incomplete DI. This check makes any incomplete
// primary output fail so the bpmnkit fallback fires.
//
// Rule: every sequenceFlow, messageFlow, and association needs a BPMNEdge. Their endpoints,
// plus participants, groups, and text annotations, need BPMNShapes. Lanes are intentionally
// ignored — Camunda has no runtime lane support and neither layout engine emits lane DI reliably.

const fs = require('node:fs');
const file = process.argv[2];
if (!file) { console.error('usage: bpmn-di-check.cjs <file.bpmn>'); process.exit(2); }
const xml = fs.readFileSync(file, 'utf8');

const shapeFor = new Set();
for (const m of xml.matchAll(/<bpmndi:BPMNShape\b[^>]*\bbpmnElement="([^"]+)"/g)) shapeFor.add(m[1]);
const edgeFor = new Set();
for (const m of xml.matchAll(/<bpmndi:BPMNEdge\b[^>]*\bbpmnElement="([^"]+)"/g)) edgeFor.add(m[1]);
const laneIds = new Set();
for (const m of xml.matchAll(/<bpmn:lane\b[^>]*\bid="([^"]+)"/g)) laneIds.add(m[1]);

const missingEdges = [], missingShapes = new Set();
for (const m of xml.matchAll(/<bpmn:(?:participant|group|textAnnotation)\b[^>]*\bid="([^"]+)"/g)) {
  if (!shapeFor.has(m[1])) missingShapes.add(m[1]);
}
for (const m of xml.matchAll(/<bpmn:(?:sequenceFlow|messageFlow|association)\b[^>]*>/g)) {
  const id = /\bid="([^"]+)"/.exec(m[0])?.[1];
  if (!id) continue;
  if (!edgeFor.has(id)) missingEdges.push(id);
  for (const attribute of ['sourceRef', 'targetRef']) {
    const ref = new RegExp(`\\b${attribute}="([^"]+)"`).exec(m[0])?.[1];
    if (ref && !laneIds.has(ref) && !shapeFor.has(ref)) missingShapes.add(ref);
  }
}

const problems = missingEdges.length + missingShapes.size;
if (problems) {
  const name = file.split('/').pop();
  console.error(`di-check: ${name} — INCOMPLETE DI: ${missingShapes.size} shape(s), ${missingEdges.length} edge(s) missing`);
  if (missingShapes.size) console.error(`  no shape: ${[...missingShapes].slice(0, 8).join(', ')}${missingShapes.size > 8 ? ' …' : ''}`);
  if (missingEdges.length) console.error(`  no edge:  ${missingEdges.slice(0, 8).join(', ')}${missingEdges.length > 8 ? ' …' : ''}`);
  process.exit(1);
}
console.log(`di-check: ${file.split('/').pop()} — DI complete`);
