#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Check that a generated AI Agent BPMN still declares every tool the connector
// can discover, after `c8ctl element-template apply` has bound the container.
//
// The connector discovers a tool by it being a root node — an activity inside
// the ad-hoc sub-process with no incoming sequence flow. Three ways that breaks,
// each of which leaves a file that lints clean and deploys:
//
//   - A sequence flow attaches to a tool, so it carries a `bpmn:incoming` and is
//     a sub-flow step rather than a tool.
//   - A tool has no DI shape, so it is invisible in Modeler.
//   - The container lost `isExpanded`, so its children do not render inside it.
//
// Usage:
//   node "ai-agent-tool-check.cjs" <file.bpmn> [--expect-tools <n>]
//
// Prints one verdict line to stdout, then one detail line per count. Explanations
// go to stderr, so the stdout verdict token is safe to capture:
//   PASS     exit 0
//   FAIL     exit 1  — a stated expectation does not hold; the detail lines say which
//   (none)   exit 2  — bad input; nothing was checked

const fs = require('fs');

const EXIT = { OK: 0, FAIL: 1, USAGE: 2 };

/**
 * Count the tool-related shapes in an exported AI Agent diagram.
 *
 * Counts over the raw XML rather than a parsed model: the file is read after
 * `c8ctl element-template apply` has rewritten it, and the question here is what
 * the connector will see in the deployed bytes.
 *
 * @param {string} xml Exported BPMN XML.
 * @returns {{tools: number, toolDI: number, isExpanded: number, chainedTools: number}}
 */
function countToolShapes(xml) {
  const count = (re) => (String(xml).match(re) || []).length;
  return {
    tools: count(/<bpmn:serviceTask[^>]*\bid="Tool_/g),
    toolDI: count(/\bbpmnElement="Tool_/g),
    isExpanded: count(/\bisExpanded="true"/g),
    chainedTools: count(/<bpmn:sequenceFlow[^>]*\b(?:sourceRef|targetRef)="Tool_/g),
  };
}

/**
 * Turn counts into a verdict.
 *
 * `expectTools` is the number of tools the `.gen.mjs` declared. Left null, the
 * tool count is reported but not asserted — internal consistency (a DI shape per
 * tool) is still checked, since that holds whatever the declared number is.
 *
 * @param {ReturnType<typeof countToolShapes>} counts
 * @param {number|null} expectTools Declared tool count, or null to not assert it.
 * @returns {{ok: boolean, problems: string[]}}
 */
function evaluate(counts, expectTools) {
  const problems = [];

  if (counts.tools === 0) {
    problems.push('no Tool_* service tasks found — is this an AI Agent diagram?');
  }
  if (expectTools !== null && counts.tools !== expectTools) {
    problems.push(`declared ${expectTools} tools, found ${counts.tools}`);
  }
  if (counts.toolDI !== counts.tools) {
    problems.push(`${counts.tools} tools but ${counts.toolDI} tool DI shapes — a tool has no shape`);
  }
  if (counts.isExpanded !== 1) {
    problems.push(
      `isExpanded="true" appears ${counts.isExpanded} times, expected once on the container`,
    );
  }
  if (counts.chainedTools !== 0) {
    problems.push(
      `${counts.chainedTools} sequence flow(s) attach to a tool — a tool with an incoming flow ` +
        'is a sub-flow step, not a tool',
    );
  }

  return { ok: problems.length === 0, problems };
}

/**
 * @param {string[]} argv Arguments after the script name.
 * @returns {{file: string, expectTools: number|null}|null} null on a usage error.
 */
function parseArgs(argv) {
  let file = null;
  let expectTools = null;

  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--expect-tools') {
      const raw = argv[++i];
      // A flag-shaped token is the next option, never this option's value.
      if (raw === undefined || raw.startsWith('--')) return null;
      if (!/^\d+$/.test(raw)) return null;
      expectTools = Number(raw);
    } else if (a.startsWith('--')) {
      return null;
    } else if (file === null) {
      file = a;
    } else {
      return null;
    }
  }

  return file === null ? null : { file, expectTools };
}

/**
 * Read and check one diagram.
 *
 * A file that is absent or unreadable is a usage error, not a failed check: it
 * means nothing was verified, which must not read as "the tools are chained".
 *
 * @param {string} file Path to the .bpmn.
 * @param {number|null} expectTools Declared tool count, or null.
 * @returns {{exitCode: number, lines: string[], reason?: string}}
 */
function check(file, expectTools) {
  let xml;
  try {
    xml = fs.readFileSync(file, 'utf8');
  } catch (err) {
    return { exitCode: EXIT.USAGE, lines: [], reason: `cannot read ${file}: ${err.message}` };
  }

  const counts = countToolShapes(xml);
  const { ok, problems } = evaluate(counts, expectTools);

  const lines = [
    ok ? 'PASS' : 'FAIL',
    `tools ${counts.tools}`,
    `toolDI ${counts.toolDI}`,
    `isExpanded ${counts.isExpanded}`,
    `chainedTools ${counts.chainedTools}`,
  ];

  return {
    exitCode: ok ? EXIT.OK : EXIT.FAIL,
    lines,
    reason: ok ? undefined : problems.join('; '),
  };
}

module.exports = { EXIT, countToolShapes, evaluate, parseArgs, check };

if (require.main === module) {
  const parsed = parseArgs(process.argv.slice(2));
  if (!parsed) {
    process.stderr.write(
      'usage: ai-agent-tool-check.cjs <file.bpmn> [--expect-tools <n>]\n',
    );
    process.exit(EXIT.USAGE);
  }
  const result = check(parsed.file, parsed.expectTools);
  if (result.reason) process.stderr.write(`ai-agent-tool-check: ${result.reason}\n`);
  if (result.lines.length) process.stdout.write(`${result.lines.join('\n')}\n`);
  process.exit(result.exitCode);
}
