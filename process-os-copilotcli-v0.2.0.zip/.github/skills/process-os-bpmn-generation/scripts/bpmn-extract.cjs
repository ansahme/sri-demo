#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Extract a BPMN file's structure without reading the file into the agent's
// context. A connector-bound `.bpmn` runs 1.5-3x over the Read tool's ~25 KB
// cap — element + DI bulk, not icons: stripping every `zeebe:modelerTemplateIcon`
// from the worst file in the repo's own corpus still leaves it 2.3x over. So the
// only workable rule is extract-don't-dump, and this is the extractor.
//
// Emits, per file: the process definition, every flow node (id / name / type,
// plus job type, form key, hand-authored `bpmn:documentation` text, the
// `zeebe:userTask` flag and a call activity's `calledElement` target process id
// — covering both the `zeebe:calledElement` extension (strategic-mode diagrams
// keep it too, as their one Zeebe extension) and the bare BPMN2.0 `calledElement`
// attribute, which stays a supported fallback for a diagram carrying no Zeebe
// extensions at all), the process variables read and written by io
// mappings and gateway conditions, and the branch conditions themselves.
// Events additionally carry their event-definition kind (`error`, `timer`,
// `message`, …), a boundary event its host activity (`attachedToRef`), and an
// error event the `errorCode` its `errorRef` resolves to on the root
// `<bpmn:error>` — a test asserting a thrown BPMN error needs the code, and
// the type alone cannot tell an error boundary from a timer one.
// `--topology` additionally emits every sequence flow's id/sourceRef/targetRef
// so a caller can reconstruct flow order without ever reading the XML — opt-in
// because its size scales with edge count, not element count, and the repo's
// own worst-case corpus only fits the read cap without it. Icon data URLs are
// never emitted.
//
// Zero dependencies (Node built-ins only) so it runs before `c8 os install` and
// needs no NODE_PATH. Directory arguments are expanded in-process — a caller
// must not rely on shell globbing, which PowerShell does not do for native
// commands.
//
// Usage:
//   node bpmn-extract.cjs <file-or-dir> [...] [--names] [--topology] [--exclude <basename>]
//
// Output: a JSON report on stdout. Exit 0 on success; exit 2 on bad inputs
// (missing path, a directory with no `.bpmn` files, a dangling/missing
// `--exclude` value, a malformed `--max-bytes`, or a file that isn't
// well-formed XML — an unclosed element collapses "present but broken" into a
// plausible-looking empty report otherwise); exit 3 when the report exceeds
// the read cap.

const fs = require('fs');
const path = require('path');

// Flow nodes worth reporting. Sequence flows, associations, text annotations,
// data objects, lanes and all DI live outside this set — they are the bulk this
// script exists to leave behind.
const FLOW_NODES = new Set([
  'task',
  'userTask',
  'serviceTask',
  'sendTask',
  'receiveTask',
  'manualTask',
  'scriptTask',
  'businessRuleTask',
  'callActivity',
  'subProcess',
  'adHocSubProcess',
  'transaction',
  'exclusiveGateway',
  'parallelGateway',
  'inclusiveGateway',
  'eventBasedGateway',
  'complexGateway',
  'startEvent',
  'endEvent',
  'intermediateCatchEvent',
  'intermediateThrowEvent',
  'boundaryEvent',
]);

// Local names collide across namespaces (`bpmn:userTask` vs `zeebe:userTask`),
// so a flow node is only a flow node when its prefix is not one of these.
const FOREIGN_PREFIXES = new Set([
  'zeebe',
  'bpmndi',
  'di',
  'dc',
  'xsi',
  'camunda',
  'modeler',
  'conversion',
]);

// FEEL keywords and literals — never process variables.
const FEEL_RESERVED = new Set([
  'and',
  'between',
  'else',
  'every',
  'external',
  'false',
  'for',
  'function',
  'if',
  'in',
  'instance',
  'not',
  'null',
  'of',
  'or',
  'return',
  'satisfies',
  'some',
  'then',
  'true',
]);

const TAG_RE = /<(\/?)([A-Za-z_][\w.:-]*)((?:[^>"']|"[^"]*"|'[^']*')*)(\/)?>/g;
const ATTR_RE = /([A-Za-z_][\w.:-]*)\s*=\s*"([^"]*)"|([A-Za-z_][\w.:-]*)\s*=\s*'([^']*)'/g;

// `<bpmn:errorEventDefinition …>` -> kind `error`, attributes in group 2. The
// namespace group carries its own colon and the kind is lazy: with an
// optional `[\w.-]*` prefix instead, an unprefixed `<errorEventDefinition>`
// backtracks to a prefix of `erro` and reports the kind as `r`.
const EVENT_DEFINITION_RE = /<(?:[\w.-]+:)?(\w+?)EventDefinition\b([^>]*)>/;

// A numeric character reference outside the valid codepoint range or in the
// surrogate range (0xD800-0xDFFF) is left as raw entity text, the same way
// `&nbsp;` and every other unhandled named entity already are: a visible
// `&#1114112;` in the report beats a silently substituted character, and
// `String.fromCodePoint` throws above 0x10FFFF.
function charRef(raw, codePoint) {
  return Number.isInteger(codePoint) &&
    codePoint >= 0 &&
    codePoint <= 0x10ffff &&
    !(codePoint >= 0xd800 && codePoint <= 0xdfff)
    ? String.fromCodePoint(codePoint)
    : raw;
}

function decodeEntities(s) {
  return s
    .replace(/&#(\d+);/g, (m, d) => charRef(m, Number(d)))
    .replace(/&#x([0-9a-fA-F]+);/g, (m, h) => charRef(m, parseInt(h, 16)))
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&');
}

function attrs(raw) {
  const out = {};
  for (const m of raw.matchAll(ATTR_RE)) {
    const key = m[1] !== undefined ? m[1] : m[3];
    const val = m[1] !== undefined ? m[2] : m[4];
    out[key] = decodeEntities(val);
  }
  return out;
}

const localName = (qname) => {
  const i = qname.indexOf(':');
  return i === -1 ? qname : qname.slice(i + 1);
};
const prefixOf = (qname) => {
  const i = qname.indexOf(':');
  return i === -1 ? '' : qname.slice(0, i);
};

// A flow node worth reporting: in FLOW_NODES and not shadowed by a
// foreign-namespace element of the same local name (`zeebe:userTask` etc.).
const isFlowNode = (qname) => FLOW_NODES.has(localName(qname)) && !FOREIGN_PREFIXES.has(prefixOf(qname));

// A container (subProcess/adHocSubProcess/transaction) can itself carry
// extension markers (e.g. an AI Agent Sub-process's own zeebe:taskDefinition)
// AND contain nested flow nodes with their own markers of the same kind. Cap
// the nearest enclosing flow-node ancestor's own-content boundary at the
// first nested flow-node tag, so the two never get scanned as one blob.
function markNestedBoundary(open, idx) {
  for (let i = open.length - 1; i >= 0; i--) {
    if (isFlowNode(open[i].qname)) {
      if (open[i].ownInnerEnd == null) open[i].ownInnerEnd = idx;
      break;
    }
  }
}

// Walk the tag stream once, yielding every element with its attributes, the
// raw XML between its open and close tags (empty for self-closing elements,
// `inner`), and that same span truncated before any nested flow node
// (`ownInner` — identical to `inner` when there is none). Handles same-name
// nesting (a subProcess inside a subProcess) via a stack.
function* elementsOf(xml) {
  const open = [];
  TAG_RE.lastIndex = 0;
  for (const m of xml.matchAll(TAG_RE)) {
    const [full, closing, qname] = m;
    if (qname.startsWith('!') || qname.startsWith('?')) continue;
    // The attribute group swallows the `/` of a self-closing tag, so recover it
    // from the tail rather than from the (never-matching) capture group.
    const selfClosing = m[4] || /\/\s*$/.test(m[3]);
    const rawAttrs = selfClosing ? m[3].replace(/\/\s*$/, '') : m[3];
    if (closing) {
      for (let i = open.length - 1; i >= 0; i--) {
        if (open[i].qname === qname) {
          const el = open.splice(i)[0];
          const inner = xml.slice(el.innerStart, m.index);
          const ownInner = el.ownInnerEnd == null ? inner : xml.slice(el.innerStart, el.ownInnerEnd);
          yield { ...el, inner, ownInner };
          break;
        }
      }
      continue;
    }
    if (isFlowNode(qname)) markNestedBoundary(open, m.index);
    if (selfClosing) {
      yield { qname, attrs: attrs(rawAttrs), inner: '', ownInner: '' };
      continue;
    }
    open.push({ qname, attrs: attrs(rawAttrs), innerStart: m.index + full.length, ownInnerEnd: null });
  }
  // Every opened element must have closed by end of document — a well-formed
  // XML invariant this scanner otherwise never checks. Without it, an unclosed
  // <bpmn:process> (or any element) just leaves its yield un-emitted, so the
  // caller gets a plausible-looking partial report instead of a failure.
  if (open.length > 0) {
    const err = new Error(
      `not well-formed XML — unclosed element(s): ${open.map((o) => `<${o.qname}>`).join(', ')}`,
    );
    err.exitCode = 2;
    throw err;
  }
}

// Identifiers referenced by a FEEL expression: top-level path segments only
// (`clientProfile.country` -> clientProfile), minus string literals, function
// names and reserved words.
function feelIdentifiers(expression) {
  const body = decodeEntities(expression)
    .replace(/^=/, '')
    .replace(/"(?:[^"\\]|\\.)*"/g, ' ')
    .replace(/'(?:[^'\\]|\\.)*'/g, ' ');
  const found = new Set();
  for (const m of body.matchAll(/[A-Za-z_][A-Za-z0-9_]*/g)) {
    const before = body.slice(0, m.index).trimEnd();
    if (before.endsWith('.')) continue; // path segment, not a root variable
    const after = body.slice(m.index + m[0].length).trimStart();
    if (after.startsWith('(')) continue; // function call
    if (after.startsWith(':')) continue; // context-entry key, e.g. `{ status: "ESCALATED" }`
    if (FEEL_RESERVED.has(m[0])) continue;
    found.add(m[0]);
  }
  return found;
}

function extractFile(file) {
  // CDATA is unwrapped and entity-escaped, not stripped: conditionExpression
  // text can be CDATA-wrapped (Camunda 7 style) and is extracted below — a
  // blanket strip would silently discard that expression instead of parsing it.
  const xml = fs
    .readFileSync(file, 'utf8')
    .replace(/<!--[\s\S]*?-->/g, '')
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, (_, text) =>
      text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'),
    );

  let proc = null;
  const elements = [];
  const conditions = [];
  const sequenceFlows = [];
  const read = new Set();
  const written = new Set();
  // Root `<bpmn:error>` id -> errorCode, and the emitted nodes still waiting on
  // one. Resolution is deferred to the end of the walk so declaration order is
  // irrelevant — a `<bpmn:error>` may appear before or after the elements
  // that reference it via `errorRef`.
  const errorCodes = new Map();
  const pendingErrorRefs = [];

  const noteFeel = (expr) => {
    if (!expr || !expr.trimStart().startsWith('=')) return;
    for (const id of feelIdentifiers(expr)) read.add(id);
  };

  try {
    for (const el of elementsOf(xml)) {
      const local = localName(el.qname);
      const prefix = prefixOf(el.qname);
      const foreign = FOREIGN_PREFIXES.has(prefix);

      if (local === 'process' && !foreign && !proc) {
        proc = {
          id: el.attrs.id || null,
          name: el.attrs.name || null,
          executable: el.attrs.isExecutable === 'true',
        };
        continue;
      }

      if (local === 'input' || local === 'output') {
        if (prefix === 'zeebe') {
          noteFeel(el.attrs.source);
          if (local === 'output' && el.attrs.target) {
            written.add(el.attrs.target.split('.')[0]);
          }
        }
        continue;
      }

      if (local === 'sequenceFlow' && !foreign) {
        // Every flow's topology, not just conditioned ones — a caller needs
        // the full graph to walk `elements` in execution order, which this
        // scanner's own emission order (XML close-tag order) does not give.
        sequenceFlows.push({
          id: el.attrs.id || null,
          sourceRef: el.attrs.sourceRef || null,
          targetRef: el.attrs.targetRef || null,
        });
        const cond = /<[\w.-]*:?conditionExpression[^>]*>([\s\S]*?)<\/[\w.-]*:?conditionExpression>/.exec(
          el.inner,
        );
        if (cond) {
          const expression = decodeEntities(cond[1].trim());
          const entry = { flow: el.attrs.id || null, expression };
          if (el.attrs.name) entry.name = el.attrs.name;
          conditions.push(entry);
          noteFeel(expression);
        }
        continue;
      }

      // A root `<bpmn:error>` is the only place the errorCode a test has to
      // throw is written; the boundary event carries just an errorRef.
      if (local === 'error' && !foreign) {
        if (el.attrs.id && el.attrs.errorCode) errorCodes.set(el.attrs.id, el.attrs.errorCode);
        continue;
      }

      if (!isFlowNode(el.qname)) continue;

      const node = { type: local, id: el.attrs.id || null };
      if (el.attrs.name) node.name = el.attrs.name;
      // A boundary event has no incoming sequence flow, so its host activity is
      // not recoverable from `sequenceFlows` — it only exists as this attribute.
      if (el.attrs.attachedToRef) node.attachedToRef = el.attrs.attachedToRef;
      // `type` alone says `boundaryEvent`/`endEvent`, which does not separate an
      // error boundary from a timer or message one.
      const eventDef = EVENT_DEFINITION_RE.exec(el.ownInner);
      if (eventDef) {
        node.eventDefinition = eventDef[1];
        const errorRef = attrs(eventDef[2]).errorRef;
        if (errorRef) pendingErrorRefs.push({ node, errorRef });
      }
      if (/<[\w.-]*:?userTask\b[^>]*\/?>/.test(el.ownInner)) node.zeebeUserTask = true;
      // Matched via attrs() (handles both quote styles and entity decoding)
      // rather than a second ad hoc regex: a naive `\bformKey="..."` alternation
      // for single quotes would still greedily match a decoy attribute like
      // `data-type="x"` ahead of the real `type="y"` in the same tag.
      const form = /<[\w.-]*:?formDefinition\b([^>]*)>/.exec(el.ownInner);
      if (form) {
        const formKey = attrs(form[1]).formKey;
        if (formKey !== undefined) node.formKey = formKey;
      }
      const job = /<[\w.-]*:?taskDefinition\b([^>]*)>/.exec(el.ownInner);
      if (job) {
        const jobType = attrs(job[1]).type;
        if (jobType !== undefined) node.jobType = jobType;
      }
      if (el.attrs['zeebe:modelerTemplate']) node.template = el.attrs['zeebe:modelerTemplate'];
      // The zeebe extension is the executable form; strategic-mode diagrams
      // keep it too, as their one Zeebe extension. The bare BPMN2.0
      // `calledElement` attribute stays a supported fallback for a diagram
      // carrying no Zeebe extensions at all. The two
      // shouldn't coexist on a deployable process, but the extension wins if
      // they somehow do — it's the one Zeebe actually executes. Its *presence*
      // decides that, not its value: an extension whose processId is missing or
      // empty still means Zeebe calls nothing, so falling through to the bare
      // attribute there would report a target the engine never uses.
      const called = /<[\w.-]*:?calledElement\b([^>]*)>/.exec(el.ownInner);
      const calledElement = called ? attrs(called[1]).processId : el.attrs.calledElement;
      if (calledElement) node.calledElement = calledElement;
      // bpmn:documentation is a direct child, so it is inside ownInner even for
      // a container (a subProcess's own note vs. a nested child's own note stay
      // apart, same as formKey/jobType above).
      const doc = /<[\w.-]*:?documentation\b[^>]*>([\s\S]*?)<\/[\w.-]*:?documentation>/.exec(el.ownInner);
      if (doc) {
        const text = decodeEntities(doc[1].trim());
        if (text) node.documentation = text;
      }
      elements.push(node);
    }
  } catch (e) {
    if (e.exitCode) e.message = `${path.relative(process.cwd(), file) || file}: ${e.message}`;
    throw e;
  }

  // An errorRef that resolves to no declared code stays unreported: in Zeebe an
  // error catch event without a code catches any error, so inventing one from
  // the boundary event's name is the exact mismatch a generated test then
  // asserts against.
  for (const { node, errorRef } of pendingErrorRefs) {
    const code = errorCodes.get(errorRef);
    if (code !== undefined) node.errorCode = code;
  }

  return {
    path: path.relative(process.cwd(), file) || file,
    // The file's own size on disk, not `xml.length` after this function's
    // comment-strip/CDATA-rewrite — either transformation can move the two
    // substantially apart, and a caller reading this to gauge the source
    // BPMN's size needs the real figure.
    bytes: fs.statSync(file).size,
    process: proc,
    elements,
    variables: { read: [...read].sort(), written: [...written].sort() },
    conditions,
    sequenceFlows,
  };
}

// A path is either a `.bpmn` file or a directory of them. Directories are read
// non-recursively, so `.snapshots/` and other nested dirs are left alone.
function resolveInputs(inputs, exclude) {
  const skip = new Set(exclude);
  const files = [];
  for (const input of inputs) {
    if (!fs.existsSync(input)) {
      const err = new Error(`no such path: ${input}`);
      err.exitCode = 2;
      throw err;
    }
    if (fs.statSync(input).isDirectory()) {
      const found = fs
        .readdirSync(input)
        .filter((f) => f.endsWith('.bpmn'))
        .sort()
        .map((f) => path.join(input, f))
        .filter((f) => fs.statSync(f).isFile());
      if (found.length === 0) {
        const err = new Error(`no .bpmn files in ${input}`);
        err.exitCode = 2;
        throw err;
      }
      files.push(...found);
    } else {
      files.push(input);
    }
  }
  // One filter pass over the combined list, applied once all inputs are
  // resolved — not per-directory — so an excluded-empty directory doesn't
  // abort a call where another input still supplies files. The emptiness
  // check afterward closes the gap this filter otherwise leaves open: a
  // directory (or a directly-named file) whose only `.bpmn` files are all
  // excluded used to pass the check above, then get silently emptied here,
  // returning success on nothing rather than the exit-2 this collapses to.
  const result = files.filter((f) => !skip.has(path.basename(f)));
  if (result.length === 0) {
    const err = new Error(
      skip.size === 0 ? 'no .bpmn files to extract' : 'no .bpmn files remain after applying --exclude',
    );
    err.exitCode = 2;
    throw err;
  }
  return result;
}

// `--names`: the lighter projection — id / name / type per flow node, dropping
// connector binding, io mappings, branch conditions, documentation text and
// sequence-flow topology. Every element is still listed (an unnamed join
// gateway keeps its id); only the *fields* thin out, so no caller loses an id
// it used to see. A whole directory of discovery BPMN fits the Read cap in
// this mode but not in full.
function toNames(file) {
  return {
    path: file.path,
    bytes: file.bytes,
    process: file.process,
    elements: file.elements.map((e) => {
      const out = { type: e.type, id: e.id };
      if (e.name) out.name = e.name;
      return out;
    }),
  };
}

function extract(inputs, { exclude = [], names = false, topology = false } = {}) {
  let files = resolveInputs(inputs, exclude).map(extractFile);
  // `sequenceFlows` is opt-in even in full mode: it is the one field whose
  // size scales with the diagram's edge count rather than its element count,
  // and bundling it into every full-mode call pushes the repo's own 8-file
  // transformation-tier corpus over the read cap. A caller that needs flow
  // topology asks for it explicitly and is prepared for exit 3.
  if (!topology) files = files.map(({ sequenceFlows, ...rest }) => rest);
  if (names) files = files.map(toNames);
  return {
    schema: 'bpmn-extract/1',
    mode: names ? 'names' : 'full',
    files,
    // Counted after projection: totals must describe what was emitted, or a
    // complete report reads like a truncated one.
    totals: {
      files: files.length,
      elements: files.reduce((n, f) => n + f.elements.length, 0),
      bytes: files.reduce((n, f) => n + f.bytes, 0),
    },
  };
}

// What the caller actually reads. Compact, not pretty-printed: indentation adds
// ~50% to a report whose entire job is to stay under a read cap.
const render = (report) => JSON.stringify(report);

// `Number('')` is `0`, not `NaN` — a bare `.trim() !== ''` guard is required or
// a dangling `--max-bytes=` would parse as the documented "disable the check"
// value instead of the usage error a missing value actually is.
const parseMaxBytes = (raw) => {
  const n = typeof raw === 'string' && raw.trim() !== '' ? Number(raw) : NaN;
  if (!Number.isFinite(n) || n < 0) {
    process.stderr.write(
      `bpmn-extract: --max-bytes needs a non-negative number, got ${JSON.stringify(raw)}\n`,
    );
    process.exit(2);
  }
  return n;
};

// A dangling `--exclude` (last argv token) or an empty `--exclude=` is a
// usage error, not a request to exclude nothing — an empty basename never
// matches a real file, so either form would otherwise silently no-op.
// Also reject a value that looks like another flag (`--exclude --names`):
// without this, `--exclude` swallows the next flag as its "basename" (which
// then matches nothing) and that flag is silently never parsed at all —
// `--max-bytes` gets this same protection only incidentally, because a flag
// string fails its `Number()` parse.
const parseExclude = (raw) => {
  if (!raw || raw.startsWith('--')) {
    process.stderr.write('bpmn-extract: --exclude needs a value\n');
    process.exit(2);
  }
  return raw;
};

module.exports = { extract, extractFile, feelIdentifiers, render, MAX_BYTES: 25_000 };

if (require.main === module) {
  const argv = process.argv.slice(2);
  const inputs = [];
  const exclude = [];
  let names = false;
  let topology = false;
  let maxBytes = module.exports.MAX_BYTES;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--exclude') exclude.push(parseExclude(argv[++i]));
    else if (a.startsWith('--exclude=')) exclude.push(parseExclude(a.slice('--exclude='.length)));
    else if (a === '--names') names = true;
    else if (a === '--topology') topology = true;
    else if (a === '--max-bytes') maxBytes = parseMaxBytes(argv[++i]);
    else if (a.startsWith('--max-bytes=')) maxBytes = parseMaxBytes(a.slice('--max-bytes='.length));
    else inputs.push(a);
  }
  if (inputs.length === 0) {
    process.stderr.write(
      'bpmn-extract: usage: node bpmn-extract.cjs <file-or-dir> [...] ' +
        '[--names] [--topology] [--exclude <basename>] [--max-bytes <n>]\n',
    );
    process.exit(2);
  }
  try {
    const out = render(extract(inputs, { exclude, names, topology }));
    if (maxBytes > 0) {
      // Never truncate silently: a clipped report reads like a complete one.
      // Count real UTF-8 bytes, not `.length` (UTF-16 code units) — the cap is
      // a byte cap, and non-ASCII content (CJK, accented Latin) makes the two
      // diverge, which would let an over-cap report through unflagged.
      const outBytes = Buffer.byteLength(out, 'utf8');
      if (outBytes > maxBytes) {
        const remedy = names
          ? 'pass fewer files — one file at a time is always bounded'
          : topology
            ? 'drop --topology, re-run with --names, or pass fewer files'
            : 're-run with --names for a lighter projection, or pass fewer files';
        process.stderr.write(
          `bpmn-extract: report is ${outBytes} B, over the ${maxBytes} B read cap — ` +
            `${remedy} (--max-bytes 0 disables this check).\n`,
        );
        process.exit(3);
      }
    }
    process.stdout.write(out + '\n');
  } catch (e) {
    process.stderr.write(`bpmn-extract: ${e.message}\n`);
    process.exit(e.exitCode || 1);
  }
}
