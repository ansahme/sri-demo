#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

/**
 * BPMN auto-layout — generic element + edge layout.
 *
 * Wraps the upstream `bpmn-auto-layout` library
 * (https://github.com/bpmn-io/bpmn-auto-layout) to regenerate the BPMN DI
 * section: positions BPMN elements and routes their connections.
 *
 * The bpmn-io layout engine supports processes and collaborations, including
 * message flows, groups, artifacts, annotations, and association routing.
 *
 * Usage:
 *   node bpmn-auto-layout.cjs <file.bpmn>
 *
 * Resolves `bpmn-auto-layout` from the project's .camunda/node_modules
 * (installed by `c8 os install`) with a project-scoped resolver. The caller
 * needs no `NODE_PATH=…` prefix, which does not parse in native PowerShell 5.1.
 * The working directory is not modified.
 */

const fs = require('node:fs');
const path = require('node:path');
const { createRequire } = require('node:module');

const PKG_NAME = 'bpmn-auto-layout';

const file = process.argv[2];
if (!file) {
  console.error('Usage: bpmn-auto-layout.cjs <file.bpmn>');
  process.exit(2);
}
if (!fs.existsSync(file)) {
  console.error(`File not found: ${file}`);
  process.exit(2);
}

const NM_DIR = path.join(process.cwd(), '.camunda', 'node_modules');
if (!fs.existsSync(path.join(NM_DIR, PKG_NAME))) {
  process.stderr.write('ProcessOS runtime dep missing: bpmn-auto-layout at .camunda/node_modules. Run `c8 os update` — or `c8 os install <target>` (e.g. claudecode) if ProcessOS is not installed here.\n');
  process.exit(2);
}

(async () => {
  // Resolve from .camunda rather than the caller's global module paths. This
  // also honors package exports, which direct package-directory requires skip.
  const projectRequire = createRequire(path.join(process.cwd(), '.camunda', 'package.json'));
  const { layoutProcess } = projectRequire(PKG_NAME);
  const xml = fs.readFileSync(file, 'utf8');
  const { xml: layoutedXml, warnings } = await layoutProcess(xml);
  fs.writeFileSync(file, layoutedXml);
  for (const warning of warnings ?? []) {
    process.stdout.write(`${JSON.stringify({
      code: warning.code,
      elementId: warning.elementId,
      message: warning.message,
      relatedElementIds: warning.relatedElementIds
    })}\n`);
  }
  console.log(`bpmn-auto-layout: ${path.basename(file)} — element & edge layout regenerated`);
})().catch(err => {
  console.error(`bpmn-auto-layout: ${path.basename(file)} — failed: ${err.message}`);
  process.exit(1);
});
