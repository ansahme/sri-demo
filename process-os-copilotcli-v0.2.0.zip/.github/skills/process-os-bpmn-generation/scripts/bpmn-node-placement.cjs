/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';
// bpmn-node-placement.cjs <file.bpmn> — fix backward-placed convergence subgraphs.
// bpmnkit's withAutoLayout sometimes dumps a boundary-event error-handler subgraph into a
// detached band LEFT of the sources that feed it, forcing backward (right->left) arrows.
// Detect a node placed left of ALL its incoming sources, identify its CLOSED downstream
// subgraph (nodes whose only external input is that node), and translate the whole subgraph
// right so its entry sits at/right of the rightmost source. Validate no overlap; else abort.
// Edges touching moved nodes are reset to a straight orthogonal stub (run edge-cleanup after).

const fs = require('node:fs');
const file = process.argv[2];
if (!file) { console.error('usage: bpmn-node-placement.cjs <file.bpmn>'); process.exit(2); }
let xml = fs.readFileSync(file, 'utf8');

const isNode = {};
for (const m of xml.matchAll(/<bpmn:(\w+) id="([^"]+)"/g)) isNode[m[2]] = m[1];
const shapes = {};
for (const m of xml.matchAll(/<bpmndi:BPMNShape\b[^>]*bpmnElement="([^"]+)"[^>]*>\s*<dc:Bounds x="([-\d.]+)" y="([-\d.]+)" width="([-\d.]+)" height="([-\d.]+)"/g))
  shapes[m[1]] = { x: +m[2], y: +m[3], w: +m[4], h: +m[5] };
const out = {}, inc = {};
for (const m of xml.matchAll(/<bpmn:sequenceFlow id="([^"]+)"[^>]*sourceRef="([^"]+)"[^>]*targetRef="([^"]+)"/g)) {
  (out[m[2]] = out[m[2]] || []).push(m[3]); (inc[m[3]] = inc[m[3]] || []).push(m[2]);
}
// Boundary events attach to a host via attachedToRef (NOT a sequenceFlow), so they never appear
// in out/inc. When a host activity is relocated they — and the handler subgraph hanging off them —
// must travel with it, or their DI shapes strand ~dx px away from the host (broken diagram).
// Map host -> [boundary ids] so forwardClosure can pull them (and, via their real out-edges,
// their handlers) into the moved subgraph.
const boundaryOf = {};
for (const m of xml.matchAll(/<bpmn:boundaryEvent\b([^>]*)>/g)) {
  const id = (m[1].match(/\bid="([^"]+)"/) || [])[1];
  const host = (m[1].match(/\battachedToRef="([^"]+)"/) || [])[1];
  if (id && host) (boundaryOf[host] = boundaryOf[host] || []).push(id);
}
// node ids only (exclude annotations/edges)
const nodeIds = Object.keys(shapes).filter(id => isNode[id] && isNode[id] !== 'textAnnotation');
const GAP = 0;

function forwardClosure(start) {                 // forward-reachable; abort if not "closed"
  const C = new Set([start]); const stack = [start];
  while (stack.length) {
    const n = stack.pop();
    for (const t of (out[n] || [])) if (!C.has(t)) { C.add(t); stack.push(t); }
    // pull attached boundary events of n; their own out-edges then pull the handler subgraph
    for (const b of (boundaryOf[n] || [])) if (!C.has(b)) { C.add(b); stack.push(b); }
  }
  // closed test: every member except `start` must have ALL incoming from inside C
  // (boundary events have no sequenceFlow incoming — their host is already in C by construction)
  for (const d of C) {
    if (d === start) continue;
    for (const s of (inc[d] || [])) if (!C.has(s)) return null;   // external forward input -> not closed
  }
  return C;
}
function overlaps(a, b, margin) {
  return a.x < b.x + b.w + margin && a.x + a.w + margin > b.x &&
         a.y < b.y + b.h + margin && a.y + a.h + margin > b.y;
}

const moves = {};                                // id -> {dx}
for (const N of nodeIds) {
  const srcs = (inc[N] || []).map(s => shapes[s]).filter(Boolean);
  if (!srcs.length) continue;
  const rightmost = Math.max(...srcs.map(s => s.x + s.w));
  if (rightmost <= shapes[N].x + shapes[N].w) continue;          // not backward
  const C = forwardClosure(N);
  if (!C || C.size > 12) continue;                               // not closed, or too big to be an error-handler
  // don't move if the subgraph contains the start event
  if ([...C].some(id => isNode[id] === 'startEvent')) continue;
  const dx = rightmost - shapes[N].x + GAP;
  // validate: translated C clears all non-C nodes
  let ok = true;
  for (const c of C) {
    const t = { x: shapes[c].x + dx, y: shapes[c].y, w: shapes[c].w, h: shapes[c].h };
    for (const o of nodeIds) { if (C.has(o)) continue; if (overlaps(t, shapes[o], 10)) { ok = false; break; } }
    if (!ok) break;
  }
  if (!ok) continue;
  for (const c of C) moves[c] = dx;
}

const movedIds = new Set(Object.keys(moves));
if (!movedIds.size) { console.log(`node-placement: ${file.split('/').pop()} — nothing to move`); process.exit(0); }

// 1) shift shapes of moved nodes
xml = xml.replace(/(<bpmndi:BPMNShape\b[^>]*bpmnElement="([^"]+)"[^>]*>\s*<dc:Bounds x=")([-\d.]+)(")/g,
  (full, pre, id, x, post) => movedIds.has(id) ? pre + (+x + moves[id]) + post : full);

// 2) move text-annotation shapes + associations whose element target moved (keep them with the node)
//    (annotations associate via <bpmn:association sourceRef=ELEMENT targetRef=ANNOTATION>)
const annMove = {};
for (const m of xml.matchAll(/<bpmn:association id="[^"]+"[^>]*sourceRef="([^"]+)"[^>]*targetRef="([^"]+)"/g))
  if (movedIds.has(m[1])) annMove[m[2]] = moves[m[1]];
xml = xml.replace(/(<bpmndi:BPMNShape\b[^>]*bpmnElement="([^"]+)"[^>]*>\s*<dc:Bounds x=")([-\d.]+)(")/g,
  (full, pre, id, x, post) => annMove[id] != null ? pre + (+x + annMove[id]) + post : full);

// 3) reset DI of every edge touching a moved node to a straight orthogonal stub. The
//    endpoints DOCK ON THE SHAPE BOUNDARY (the edge mid-point of the side facing the other
//    node), never the centre — a centre-docked waypoint draws an arrow emerging from inside
//    the box. edge-cleanup.cjs run afterwards refines/orthogonalises.
const newShape = id => movedIds.has(id) ? { ...shapes[id], x: shapes[id].x + moves[id] } : shapes[id];
function dock(b, toward) {                       // boundary point on the side of b facing `toward`
  const cx = b.x + b.w / 2, cy = b.y + b.h / 2;
  const dx = toward[0] - cx, dy = toward[1] - cy;
  return Math.abs(dx) >= Math.abs(dy)
    ? [dx >= 0 ? b.x + b.w : b.x, cy]            // right / left edge mid
    : [cx, dy >= 0 ? b.y + b.h : b.y];           // bottom / top  edge mid
}
const centre = b => [b.x + b.w / 2, b.y + b.h / 2];
const flowST = {};
for (const m of xml.matchAll(/<bpmn:sequenceFlow id="([^"]+)"[^>]*sourceRef="([^"]+)"[^>]*targetRef="([^"]+)"/g)) flowST[m[1]] = { s: m[2], t: m[3] };
for (const m of xml.matchAll(/<bpmn:association id="([^"]+)"[^>]*sourceRef="([^"]+)"[^>]*targetRef="([^"]+)"/g)) flowST[m[1]] = { s: m[2], t: m[3], assoc: true };
xml = xml.replace(/(<bpmndi:BPMNEdge\b[^>]*bpmnElement="([^"]+)"[^>]*>)([\s\S]*?)(<\/bpmndi:BPMNEdge>)/g,
  (full, open, elId, body, close) => {
    const f = flowST[elId]; if (!f || (!movedIds.has(f.s) && !movedIds.has(f.t))) return full;
    const sb = newShape(f.s), tb = newShape(f.t);
    const s = dock(sb, centre(tb)), t = dock(tb, centre(sb));     // dock on facing boundaries
    const mid = [t[0], s[1]];                                    // simple L; edge-cleanup will finish it
    const pts = (Math.abs(s[0] - t[0]) < 1 || Math.abs(s[1] - t[1]) < 1) ? [s, t] : [s, mid, t];
    const label = (body.match(/<bpmndi:BPMNLabel[\s\S]*?<\/bpmndi:BPMNLabel>|<bpmndi:BPMNLabel\s*\/>/) || [''])[0];
    return `${open}\n${pts.map(p => `        <di:waypoint x="${p[0]}" y="${p[1]}" />`).join('\n')}${label ? '\n        ' + label : ''}\n      ${close}`;
  });

fs.writeFileSync(file, xml);
console.log(`node-placement: ${file.split('/').pop()} — relocated ${movedIds.size} node(s): ${[...movedIds].join(', ')}`);
