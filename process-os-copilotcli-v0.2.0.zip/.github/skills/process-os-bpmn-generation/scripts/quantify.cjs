#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Deterministic width/depth counter for /process-os-bpmn-generation quantification —
// the "A — counting" stage of skills/process-os-bpmn-generation/quantification.md, which invokes
// this script instead of having the agent hand-count.
//
// It counts the discovery-format markers (`### ` steps, `[XOR]`/`[ExclusiveGateway]`,
// `[CallActivity]`), so the skill sizes over process-discovery/ — where those markers
// exist — NOT process-tobe/, whose process-optimize `## Step`/`[GATEWAY-UPDATED]`
// format scores 0 here (the format mismatch this counter sidesteps).
//
// Gateway markers also match inline bold callouts (`**Gateway GW1:**`) — a second,
// equally real discovery-writer convention (alongside the bracket-tag one) for
// naming a decision point inside a task's sub-bullets rather than as its own
// heading. Missing this undercounts gateways to 0, which previously misclassified
// a genuinely branchy (5-decision) process as a narrower width than its content
// supports.
//
// Replaces hand-counting by the agent — which proved non-deterministic (same
// fixture scored width avg 9.83→M on one run and 14.7→L on another, and the
// agent also misapplied its own threshold table). A real script makes A a single,
// reproducible number so the report + memory.md entry are stable.
//
// Width (over process-NN-*.md, excluding process-00-e2e.md):
//   per-file score = #(`### ` headings)
//                  + 2 × #(gateway markers: `[XOR]` | `[ExclusiveGateway]`
//                          | `[AND-Gateway]` | `[ParallelGateway]`
//                          | `[AND-Split]` | `[AND-Join]` | `**Gateway ...**`)
//                  + 1 × #(`[CallActivity]` markers)
//   width_score = avg(per-file score);  buckets 0-8 S / 9-18 M / 19-30 L / 31+ XL
//
// Depth (over the whole .md set):
//   depth_score = #processes + 2×#subprocesses + #edges
//               + (3 if process-00-e2e.md exists else 0)
//               + (#file_mentions / 8)
//   file_mentions = occurrences (no dedup) of any non-catalog input file's
//                   basename appearing in any source file (excluding self).
//   buckets 0-10 S / 11-18 M / 19-28 L / 29+ XL
//
// Scores are floored before bucketing, so a fractional score sits in the bucket
// of its integer part (e.g. depth 10.75 → 10 → S, matching the calibration).
//
// Usage:   node skills/process-os-bpmn-generation/scripts/quantify.cjs <inputDir>
// Output:  JSON on stdout (see SHAPE below) on exit 0.
//
//   { "width": { "size": "M", "score": 9.83, "rawScore": 9.83,
//                "avgSteps": 7.5, "avgGateways": 1.17, "avgCalls": 0,
//                "fileCount": 6, "perFile": [{ "file","steps","gateways","calls","score" }] },
//     "depth": { "size": "S", "score": 10.75, "rawScore": 10.75,
//                "processes": 6, "subprocesses": 0, "edges": 4,
//                "e2e": false, "mentions": 6 } }
//
// Exit codes:
//   0  success — JSON printed to stdout.
//   2  usage error — missing <inputDir>, or <inputDir> does not exist or is not
//      a directory.
//   3  <inputDir> exists but holds no process/subprocess/edge/e2e document to
//      count — a directory that exists but has nothing to quantify is a
//      caller error (e.g. a bare phase directory that only holds
//      `iteration-*/` subdirectories, not documents directly), not a
//      legitimate zero score. Nothing is printed to stdout.

'use strict';

const fs = require('fs');
const path = require('path');

const EXIT = { OK: 0, USAGE: 2, EMPTY: 3 };

const INPUT_DIR = process.argv[2];
if (!INPUT_DIR) {
  process.stderr.write('usage: quantify.cjs <inputDir>\n');
  process.exit(EXIT.USAGE);
}
if (!fs.existsSync(INPUT_DIR) || !fs.statSync(INPUT_DIR).isDirectory()) {
  process.stderr.write(`not a directory: ${INPUT_DIR}\n`);
  process.exit(EXIT.USAGE);
}

// Catalog files excluded from cross-mention counting (not process content).
const SKIP_LIST = new Set([
  '00-index.md',
  'meta-conventions.md',
  'participants-and-systems.md',
  'data-objects.md',
  'gap-analysis.md',
  'as-is-process.md',
  'improvements-ai-automation.md',
  'implementation-roadmap.md',
  'metrics.md',
  '00-holistic-assessment.md',
  'manual-steps.md',
]);

const E2E_FILE = 'process-00-e2e.md';
const isProcessFile = (f) => /^process-\d+-.*\.md$/.test(f) && f !== E2E_FILE;
const isSubprocessFile = (f) => /^subprocess-.*\.md$/.test(f);
const isEdgeFile = (f) => /^edge-.*\.md$/.test(f);

const mdFiles = fs
  .readdirSync(INPUT_DIR)
  .filter((f) => f.endsWith('.md'))
  .sort();

// Count non-overlapping occurrences of a fixed (non-regex) needle.
function countOccurrences(haystack, needle) {
  if (!needle) return 0;
  let n = 0;
  let i = haystack.indexOf(needle);
  while (i !== -1) {
    n += 1;
    i = haystack.indexOf(needle, i + needle.length);
  }
  return n;
}

function bucket(score, thresholds) {
  // thresholds: [[maxInclusive, size], ...] last entry is the open-ended top.
  const s = Math.floor(score);
  for (const [max, size] of thresholds) {
    if (max === null || s <= max) return size;
  }
  return thresholds[thresholds.length - 1][1];
}

// ---- Width ----------------------------------------------------------------
const WIDTH_BUCKETS = [
  [8, 'S'],
  [18, 'M'],
  [30, 'L'],
  [null, 'XL'],
];
const STEP_RE = /^#{3} /gm;
const GATEWAY_RE =
  /\[XOR\]|\[ExclusiveGateway\]|\[AND-Gateway\]|\[ParallelGateway\]|\[AND-Split\]|\[AND-Join\]|\*\*Gateway\b[^*]*\*\*/g;
const CALL_RE = /\[CallActivity\]/g;

const perFile = [];
for (const f of mdFiles) {
  if (!isProcessFile(f)) continue;
  const text = fs.readFileSync(path.join(INPUT_DIR, f), 'utf8');
  const steps = (text.match(STEP_RE) || []).length;
  const gateways = (text.match(GATEWAY_RE) || []).length;
  const calls = (text.match(CALL_RE) || []).length;
  perFile.push({ file: f, steps, gateways, calls, score: steps + 2 * gateways + calls });
}

const widthScore = perFile.length
  ? perFile.reduce((a, p) => a + p.score, 0) / perFile.length
  : 0;
const avg = (sel) =>
  perFile.length ? perFile.reduce((a, p) => a + sel(p), 0) / perFile.length : 0;

const width = {
  size: bucket(widthScore, WIDTH_BUCKETS),
  score: Number(widthScore.toFixed(2)),
  rawScore: widthScore,
  avgSteps: Number(avg((p) => p.steps).toFixed(2)),
  avgGateways: Number(avg((p) => p.gateways).toFixed(2)),
  avgCalls: Number(avg((p) => p.calls).toFixed(2)),
  fileCount: perFile.length,
  perFile,
};

// ---- Depth ----------------------------------------------------------------
const DEPTH_BUCKETS = [
  [10, 'S'],
  [18, 'M'],
  [28, 'L'],
  [null, 'XL'],
];

const processes = mdFiles.filter(isProcessFile);
const subprocesses = mdFiles.filter(isSubprocessFile);
const edges = mdFiles.filter(isEdgeFile);
const e2e = mdFiles.includes(E2E_FILE);

if (processes.length === 0 && subprocesses.length === 0 && edges.length === 0 && !e2e) {
  process.stderr.write(
    `no process/subprocess/edge/e2e document found under ${INPUT_DIR}; nothing to quantify\n`,
  );
  process.exit(EXIT.EMPTY);
}

// Cross-mention count: for each source file, count occurrences of every *other*
// non-catalog file's basename (sans .md). No dedup — repeated mentions all count.
const mentionTargets = mdFiles
  .filter((f) => !SKIP_LIST.has(f))
  .map((f) => ({ file: f, base: f.replace(/\.md$/, '') }));

let mentions = 0;
for (const src of mdFiles) {
  const text = fs.readFileSync(path.join(INPUT_DIR, src), 'utf8');
  for (const t of mentionTargets) {
    if (t.file === src) continue;
    mentions += countOccurrences(text, t.base);
  }
}

const depthScore =
  processes.length + 2 * subprocesses.length + edges.length + (e2e ? 3 : 0) + mentions / 8;

const depth = {
  size: bucket(depthScore, DEPTH_BUCKETS),
  score: Number(depthScore.toFixed(2)),
  rawScore: depthScore,
  processes: processes.length,
  subprocesses: subprocesses.length,
  edges: edges.length,
  e2e,
  mentions,
};

process.stdout.write(JSON.stringify({ width, depth }, null, 2) + '\n');
