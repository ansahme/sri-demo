# bpmnkit recipes

Patterns for the `@bpmnkit/core` authoring path used by `generate-phase.md` (requires
**`@bpmnkit/core` ≥ 0.0.25**). Every phase BPMN is produced by **writing a small `.mjs`
script and running it with `node`** — never by hand-writing XML or DI. `generate-phase.md`
Step 3 carries the canonical worked script (width=L, strategic); this file is the recipe
companion: gateways, events, the post-export fixes this skill still requires, and editing an
existing file.

## How this skill runs bpmnkit (conventions — read first)

These differ from a generic bpmnkit scratch project; follow them exactly:

- **Build every element through the `@bpmnkit/core` builder chain** — `.task()`,
  `.serviceTask()`, `.exclusiveGateway()`, `.annotate()`, `Bpmn.export(defs)`, etc. Never write
  your own helper (`buildTask(...)`, `addSequenceFlow(...)`, or similar) that assembles XML,
  moddle objects, or DI itself. If the builder has no method for a shape, use the documented
  **Post-export fixes** below instead of writing one.

- **Import by a project-relative path, not an absolute one.** `@bpmnkit/core` is ESM-only, so
  `NODE_PATH` does **not** resolve it for `import`. `BPMNKIT_IMPORT` is a relative specifier
  from `OUTPUT_DIR` to the pinned entry, resolved once by the orchestrator and passed down —
  paste it verbatim:

  ```javascript
  import { Bpmn } from "<BPMNKIT_IMPORT>";
  // e.g. "../../.camunda/node_modules/@bpmnkit/core/dist/index.js"
  ```

  This lets the `.gen.mjs` live next to `OUTPUT_BPMN` (the lint hook relies on that) and
  still resolve the package. Run with a plain `node <script>.mjs` — **no `NODE_PATH`**.

  Never rebuild `BPMNKIT_IMPORT` yourself from an absolute path or a `file://` URL — those bake
  in this machine's checkout location and stop resolving once the `.gen.mjs` is committed and
  re-run from a different clone, OS, or CI.

- **Every other path you embed in the generator** — the `writeFileSync` target — is the
  forward-slash, project-relative path the orchestrator gave you (`OUTPUT_BPMN`). Never paste
  a host absolute path into a JS string literal, for the escape reason above.

- **Write the script to `<OUTPUT_BPMN>.gen.mjs`** (next to the output) and keep it — the
  orchestrator's centralized lint gate may route findings back and re-run it. The script is
  **kept permanently** alongside `OUTPUT_BPMN`, never deleted: it is the bpmnkit source
  that produced the diagram, and stays available for any future regeneration.

- **Annotations are builder calls.** Use `.annotate("<element id>", "<text>")` (by exact
  element id) in the builder chain. The bpmnkit scaffold and the bpmn-io layout engine
  lay out annotation shapes and association edges. The builder call is the same — you just
  declare the annotation.

- **Layout is NOT chosen in the `.gen.mjs`.** The generator ends with a `BPMN_LAYOUT` toggle
  (`process.env.BPMN_LAYOUT === "bpmnkit" ? builder.withAutoLayout().build() : builder.build()`)
  and the **run command** drives layout: bpmnkit's `.withAutoLayout()` creates the DI scaffold,
  then bpmn-io (`bpmn-auto-layout.cjs`) produces final geometry. Run
  `node ".github/skills/process-os-bpmn-generation/scripts/layout-bpmn.cjs" "<OUTPUT_BPMN>.gen.mjs" "<OUTPUT_BPMN>"` — do not hand-roll a
  single `node <gen>.mjs` run (it would ship an incomplete or unrefined diagram).

## Builder-native (no workaround needed on ≥ 0.0.25)

These were post-export hacks on 0.0.23 and are now first-class builder features:

- **Abstract task:** `.task(id, {name})` → plain `<bpmn:task>`, no Zeebe.
- **Platform version:** `.executionPlatformVersion("8.9.0")` → no version-bump regex.
- **Named event refs:** `signalName` / `messageName` / `escalationCode` / `errorCode` on an
  event auto-emit the root `<bpmn:signal/message/error/escalation>` and resolve the ref.
- **Compensation:** `.withBoundary(id, {compensation:true}, h => h.task("Undo",{name:"…",isForCompensation:true}))`
  + a compensation throw — emits `compensateEventDefinition`, `isForCompensation`, and the
  association (not a sequence flow).
- **Event sub-process:** `.eventSubProcess(id, b => b.startEvent("s",{timerDuration:"PT1H",isInterrupting:false}).endEvent(…))`
  → `<bpmn:subProcess triggeredByEvent="true">`, correct `isInterrupting`, no illegal flow.
  Run the standard layout orchestrator. It first creates the bpmnkit scaffold, which keeps the
  event-subprocess shape expanded and preserves annotation associations. It then runs bpmn-io for
  final geometry.
- **Event-based gateway** convergence to an explicit join gateway no longer types the join
  as an `eventBasedGateway`.

**Branch termination gotcha (still applies on 0.0.25):** when a gateway's branches each end
at their **own terminal** end event, terminate them **inline** —
`.branch("no", b => b.condition("…").endEvent("EndEvent_X", { name: "…" }))`. Do **not**
`.branch(...).connectTo("EndEvent_X")` to a trailing `.endEvent("EndEvent_X")` declaration:
bpmnkit reads the divergent branches as needing to re-converge and fabricates a spurious
join gateway plus an illegal outgoing flow on the first end event. (Converging branches to a
**shared** downstream node — a join gateway or a common task — via `.connectTo(...)` is fine;
only separate per-branch terminals need inline termination.)

## Minimal end-to-end runnable script

A complete `<OUTPUT_BPMN>.gen.mjs` you can adapt. Strategic mode shown (`.executable(false)`
+ strip Zeebe); for automatable, see "Post-export fixes" below.

```javascript
import { Bpmn } from "<BPMNKIT_IMPORT>";
import { writeFileSync } from "node:fs";

const builder = Bpmn.createProcess("Process01QuotingProcess")
  .name("Quoting")                                   // emits name= on <bpmn:process>
  .startEvent("StartEvent_QuoteRequested", { name: "Quote requested" })
  .userTask("Task_PrepareQuote", { name: "Prepare quote" })
  .exclusiveGateway("Gateway_QuoteApproved", { name: "Quote approved?" })
  .branch("yes", b => b.defaultFlow().endEvent("EndEvent_QuoteSent", { name: "Quote sent" }))
  .branch("no",  b => b.condition("= approved = false").endEvent("EndEvent_QuoteRejected", { name: "Quote rejected" }))
  .annotate("StartEvent_QuoteRequested", "Triggered by: Customer portal")
  .annotate("Task_PrepareQuote", "Manual: Sales rep fills pricing tool; manager approval before sending")
  .annotate("EndEvent_QuoteSent", "Follow-up: notify finance; create order")
  .executable(false)                                 // automatable → true
  .executionPlatformVersion("8.9.0");
// Layout chosen by the run command via BPMN_LAYOUT (bpmnkit scaffold → bpmn-io final layout):
const defs = process.env.BPMN_LAYOUT === "bpmnkit" ? builder.withAutoLayout().build() : builder.build();

let xml = Bpmn.export(defs);
xml = xml.replace(/\s*<bpmn:extensionElements>([\s\S]*?)<\/bpmn:extensionElements>/g,
  (block, inner) => {
    const called = inner.match(/<zeebe:calledElement\b[^>]*\/>/);
    return called ? `<bpmn:extensionElements>${called[0]}</bpmn:extensionElements>` : "";
  }); // strategic only: the "Post-export fixes" strip
writeFileSync("<OUTPUT_BPMN>", xml);
console.log("written");
```

Run with the **layout orchestrator** from `generate-phase.md` (bpmnkit scaffold → bpmn-io
final layout, or bpmnkit recovery → node-placement → edge-cleanup) — not a bare
`node <gen>.mjs`.

> **`.executable(false)` vs `true`:** bpmnkit **omits** the `isExecutable` attribute when
> false (BPMN's default is non-executable) and serializes it only when `true`. So strategic
> files carry **no** `isExecutable` attribute — that is correct and Camunda-8-compatible; the
> lint hook treats absent-or-false as structural and only `true` as compat (executable).

## Post-export fixes (only the Zeebe cases remain)

Apply with string replacement on the exported XML **before** `writeFileSync`:

1. **strategic only** — strip every `<bpmn:extensionElements>…</bpmn:extensionElements>`
   block except a call activity's `zeebe:calledElement`, which survives on its own: it is the link
   from a call activity to the process it calls, structural rather than executional.
   `.serviceTask({taskType})` unavoidably emits a `<zeebe:taskDefinition>`; stripping yields a
   plain non-executable task that lints clean. The `xmlns:zeebe` declaration is harmless and may
   remain. (For a strategic *abstract* step, prefer `.task()` — it emits no Zeebe, so nothing to
   strip.)
   ```javascript
   xml = xml.replace(/\s*<bpmn:extensionElements>([\s\S]*?)<\/bpmn:extensionElements>/g,
     (block, inner) => {
       const called = inner.match(/<zeebe:calledElement\b[^>]*\/>/);
       return called ? `<bpmn:extensionElements>${called[0]}</bpmn:extensionElements>` : "";
     });
   ```
2. **automatable only** — inject the Zeebe user-task marker on every user task (skip ones
   that already carry a `formDefinition` from a connector apply):
   ```javascript
   xml = xml.replace(/<bpmn:userTask id="(Task_[^"]+)"([^>]*)>/g,
     '<bpmn:userTask id="$1"$2>\n        <bpmn:extensionElements><zeebe:userTask /></bpmn:extensionElements>');
   ```

## Exclusive gateway (XOR)

```javascript
.exclusiveGateway("Gateway_AmountCheck", { name: "Amount exceeds limit?" })
.branch("high", b => b.condition("= amount > 1000")
  .userTask("Task_ApproveManually", { name: "Approve manually" })
  .connectTo("Gateway_Join"))
.branch("standard", b => b.defaultFlow()
  .serviceTask("Task_AutoApprove", { name: "Auto-approve", taskType: "auto-approval" })
  .connectTo("Gateway_Join"))
.exclusiveGateway("Gateway_Join", { name: "" })   // joining gateway — no label
```

FEEL condition prefix `=` is required — `b.condition("= amount > 1000")`, not
`"amount > 1000"`. Write `>` as-is in the JS string; bpmnkit escapes it to `&gt;` in the
XML. One default branch per gateway (`.defaultFlow()`); the conditioned branch carries the
FEEL test.

**Branch sub-builder (as of 0.8.0).** The `b` sub-builder inside a `.branch(name, b => …)`
lambda now supports attaching a boundary event (`b.userTask(...).boundaryEvent(...)`) and
nesting another gateway's branches (`b.exclusiveGateway("G2").branch(...)`) directly — both
build and export correctly. The flattened style above (converging with `.connectTo(...)`
instead of nesting) still works and stays valid for multi-gateway phases; prefer it when it
keeps the script easier to read, but nesting is no longer a hard requirement.

## Parallel gateway (AND)

Emit only when the input marks concurrency explicitly (`**Parallel group:**` or an
`[AND-Gateway]`/`[ParallelGateway]` split+join marker):

```javascript
.parallelGateway("ParallelGateway_Split_1", { name: "" })
.branch("notify", b => b.userTask("Task_NotifyCustomer", { name: "Notify customer" }).connectTo("ParallelGateway_Join_1"))
.branch("log",    b => b.serviceTask("Task_LogAudit", { name: "Log audit entry", taskType: "audit" }).connectTo("ParallelGateway_Join_1"))
.parallelGateway("ParallelGateway_Join_1", { name: "" })
```

## Timer boundary event

```javascript
.userTask("Task_Review", { name: "Review request" })
.boundaryEvent("BoundaryEvent_Timeout", {
  attachedTo: "Task_Review",
  name: "5-day timeout",
  timerDuration: "P5D",         // ISO 8601
  cancelActivity: true,
})
.userTask("Task_Escalate", { name: "Escalate to manager" })
.endEvent("EndEvent_Escalated", { name: "Request escalated" })
.element("Task_Review")          // return the cursor to the main path
.endEvent("EndEvent_Done", { name: "Request reviewed" })
```

`.element(id)` moves the builder cursor back to a prior element so the main path can
continue after a branch or boundary flow.

## Abstract task

For an abstract/undefined step (e.g. an overview phase box), use `.task(id, {name})` — it
emits a plain `<bpmn:task>` with no Zeebe, laid out by whichever layout engine runs, like any node:

```javascript
.task("Task_Phase01", { name: "Validate order" })
```

## Editing an existing BPMN (operations API)

For structural edits that must preserve existing element coordinates, parse →
`applyBpmnOperations` → export, rather than rebuilding. References are stable element IDs:

```javascript
import { Bpmn, applyBpmnOperations, applyAutoLayout } from "<BPMNKIT_IMPORT>";
import { readFileSync, writeFileSync } from "node:fs";

const defs = Bpmn.parse(readFileSync("<OUTPUT_BPMN>", "utf-8"));
// Splice "Notify" between Task_W and EndEvent_E: drop the old connector, add node + two flows.
const we = defs.processes[0].sequenceFlows.find(f => f.sourceRef === "Task_W" && f.targetRef === "EndEvent_E");
const result = applyBpmnOperations(defs, [
  { op: "delete_flow", id: we.id },
  { op: "insert", element: { id: "Task_Notify", type: "serviceTask", name: "Notify", jobType: "notify" }, after: "Task_W" },
  { op: "add_flow", from: "Task_W", to: "Task_Notify" },
  { op: "add_flow", from: "Task_Notify", to: "EndEvent_E" },
]);
// Required when an operation inserts a node: applyBpmnOperations edits the model only, so an
// inserted element reaches the file with no DI and is invisible in Modeler.
writeFileSync("<OUTPUT_BPMN>", Bpmn.export(applyAutoLayout(result.definitions)));
```

`insert ... after` only **positions** the node in document order — it does not rewire
flows. Delete the old connector and add the two new flows yourself, or lint catches the
fake-join + implicit-start.

`applyBpmnOperations` touches the model, never the diagram, so an inserted node has no
`<bpmndi:BPMNShape>` until `applyAutoLayout` runs — skip it and the element is in the XML and
absent from the canvas. That pass keeps the coordinates of elements it does not have to move; an
insert displaces what follows it (splicing a node after `Task_W` leaves `Task_W` where it was and
shifts `EndEvent_E` right to make room).

Operations: `rename` / `update` / `insert` / `delete` / `add_flow` / `delete_flow` /
`redirect_flow`.

`applyBpmnOperations` reports an unresolved id rather than skipping it, and throws by default, so
a patch with a misspelled id fails instead of reporting success and changing nothing. Read
`result.problems` when you pass the non-throwing option.

**Never edit through the older `compactify` → `applyOperations` → `expand` round-trip.** That
projection models no `textAnnotation` or `association`, so both are dropped with their DI — an
empty operation list is enough — and a bound element loses its `zeebe:modelerTemplate` attributes,
`zeebe:ioMapping` entries and `retries`, silently undoing `c8ctl element-template apply`.
`applyBpmnOperations` touches only what an operation names and keeps the rest.

Either way the export re-serializes the whole document, so expect a whole-file diff even from a
one-element edit. Where that matters — a file a human reads and reviews line by line — edit the
`.gen.mjs` and re-run, or replace the text directly.

## Auto-layout caveat

`.withAutoLayout()` (builder) and `Bpmn.autoLayout(xml)` (standalone) both **regenerate
every coordinate from scratch**, discarding any manual layout. Use them when building a
new process or repairing a missing diagram — never when editing a file whose layout must
be kept (use the operations API above, which lays out only new nodes).
