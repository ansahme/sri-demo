# AI Agent Ad-Hoc Sub-Process in Camunda BPMN

This document is the **build guide** for emitting a Camunda 8 `bpmn:adHocSubProcess` with the
AI Agent connector — read it **only once the decision rule in `automatable-modeling.md` has
resolved to an ad-hoc sub-process** (a single bounded model call is a plain `serviceTask` and
does not need this doc). `process-os-bpmn-generation` owns BPMN generation: use bpmnkit for the
container and `c8ctl element-template apply` for the connector. Do not hand-author template
attributes or Camunda 7 extensions.

---

## When to Use an Ad-Hoc Sub-Process (Decision Rules)

Emit a `bpmn:adHocSubProcess` with the AI Agent connector when any of these are true:

1. The step requires **dynamic tool selection** — choice of what to do next depends on context that cannot be captured in a finite set of gateway conditions.
2. The step involves **reasoning over natural language** — summarization, classification, extraction, validation against fuzzy criteria, or generating text.
3. The step explicitly mentions an **AI agent**, **LLM**, or **agentic** behavior.
4. The step describes **non-deterministic behavior** — "the system decides which actions to take based on the situation."
5. **Multiple API calls with decision logic between them** — the agent decides which endpoints to call, in what order, based on responses. This is the canonical Camunda pattern for multi-step API orchestration. It is NOT only for "fuzzy AI tasks": use it any time 2+ APIs must be called with conditional follow-up.

**Do NOT use** an ad-hoc sub-process when:
- The step is a single deterministic API call with known parameters → use a service task.
- The decision is rule-based with known variables → use an exclusive gateway or DMN.

---

## Structural Rules (Hard Constraints)

Violating any of these produces invalid, undeployable BPMN.

1. The `bpmn:adHocSubProcess` **MUST** contain at least one tool activity as a **child XML element** (nested inside). An empty subprocess cannot be deployed.
2. The `bpmn:adHocSubProcess` **MUST NOT** contain `bpmn:startEvent` or `bpmn:endEvent` elements.
3. **Tool = root node.** An activity is a tool if and only if it has **no incoming sequence flows**. Activities with incoming sequence flows are part of a sub-flow, not tools.
4. The `bpmn:adHocSubProcess` itself **MUST** have `bpmn:incoming` and `bpmn:outgoing` sequence flows connecting it to the parent process.
5. The `zeebe:taskDefinition` type **MUST** be exactly `io.camunda.agenticai:aiagent-job-worker:1`.
6. The `zeebe:adHoc` element **MUST** be present inside `bpmn:extensionElements`.
7. Each tool that returns data to the LLM **MUST** write to `toolCallResult` via `zeebe:taskHeaders` with `resultVariable` and optionally `resultExpression`.
8. Tool `bpmn:documentation` is the tool description the LLM reads to decide whether to call it. Always write a clear description.

> **CRITICAL: Tools are child XML elements of `bpmn:adHocSubProcess` — they go INSIDE the subprocess, before the closing tag `</bpmn:adHocSubProcess>`.** Do NOT place tool service tasks as siblings of the subprocess in the parent process. Declaring them inside the `.adHocSubProcess()` content callback (step 1 below) is what guarantees this — the builder cannot nest them anywhere else.

---

## Generation Workflow — bpmnkit, c8ctl, then Tools

Every automatable BPMN is Camunda 8 BPMN. Generate the container **and its tools** with bpmnkit —
one `.gen.mjs`, laid out by `.withAutoLayout()` — then bind the engine-compatible AI Agent Element
Template with `c8ctl`, which preserves that subtree. No XML or DI is authored by hand at any point.
The template owns `zeebe:modelerTemplate`, its version, icon, `zeebe:taskDefinition`,
`zeebe:adHoc`, `zeebe:ioMapping`, output mapping, and task headers. Never reproduce any of those
fields in a string template.

The current ProcessOS target is Camunda 8.9+. Use the latest AI Agent template version that is avialable via `c8ctl`. Do not upgrade the template version independently of the
configured Camunda engine version and the compatibility lint target.

### 1. Generate the container *and its tools* with bpmnkit

The generated `.bpmn.gen.mjs` builds the subprocess **and every `Tool_*` activity inside it**, so
auto-layout produces the nested DI. It must set `.executable(true)` and
`.executionPlatformVersion()` in accordance with the AI Agent Element Template available in
`c8ctl`, and it must not write any `zeebe:` template extensions itself.

The connector discovers a tool by it being a **root node** — an activity inside the container with
no incoming sequence flow. `buildAiAgentSubProcess()` builds a content callback that adds each tool
as a root node, sets its documentation from the spec's `description`, and turns its `params` into
`fromAi()` input mappings, so use it rather than populating the callback by hand. However the tools
are declared, the post-apply check below fails any tool a sequence flow attaches to.

`adHocSubProcess(id, content, options)` takes the **content callback second** — a two-argument
`adHocSubProcess(id, {name})` call throws `subProcess() requires a content callback function`.

```javascript
import { Bpmn, buildAiAgentSubProcess } from "<BPMNKIT_IMPORT>";

// One entry per Tool_* activity. `description` is the tool's LLM-facing text; `params` become
// fromAi() input mappings (see "How to Model Tools" below).
const TOOLS = [
  {
    id: "Tool_<Action>",
    description: "<what the model reads to decide whether to call this tool>",
    serviceTask: {
      name: "<Action>",
      taskType: "io.camunda:http-json:1",
      retries: "3",
      ioMapping: { inputs: [/* static connector inputs: method, url, authentication.type, … */] },
      taskHeaders: { /* … */ },
    },
    params: [{ name: "<param>", description: "<shown to the model>", target: "<ioMapping target>" }],
  },
];

// Only `agent.content` is used. The container's connector properties are bound by c8ctl in step 2,
// so `agent.options` is discarded and the model/prompt arguments below never reach the XML — they
// are required by the signature, not by this diagram. Passing `agent.options` instead would write
// the template-owned zeebe:taskDefinition and provider inputs that step 2 must own.
const agent = buildAiAgentSubProcess({
  id: "AIAgent_<TaskID>",
  model: { provider: "anthropic", inputs: {} },
  systemPrompt: "",
  userPrompt: "",
  tools: TOOLS,
});

const builder = Bpmn.createProcess("<ProcessId>")
  .startEvent("Start_<TaskID>")
  .adHocSubProcess("AIAgent_<TaskID>", agent.content, { name: "<Agent Name>" })
  .endEvent("End_<TaskID>")
  .executable(true)
  .executionPlatformVersion("8.9.0");

const defs = builder.withAutoLayout().build();
```

No post-build patching: the tools come out as root nodes with their documentation already set, and
`.withAutoLayout()` gives the container `isExpanded="true"` with bounds enclosing every tool shape.

> **Never edit a bound AI Agent BPMN through the `compactify` → `applyOperations` → `expand`
> round-trip.** It does not preserve the container: `zeebe:modelerTemplate`,
> `zeebe:modelerTemplateVersion`, the `zeebe:ioMapping` inputs holding the provider and prompt
> bindings, and the task definition's `retries` are all gone afterwards. That silently undoes
> `c8ctl element-template apply` — the file still deploys, and the agent runs without the
> configuration the template wrote. An empty operation list is enough; the loss is in `compactify`.
>
> `applyBpmnOperations` keeps the whole binding and is the supported edit path. For this file
> prefer regenerating from the `.gen.mjs` and re-applying the template anyway: the export
> re-serializes the document, so an edit here arrives as a whole-file diff either way.

**Lay this file out with `BPMN_LAYOUT=bpmnkit`, not the bpmn-io primary.** `bpmn-auto-layout.cjs`
gives the container plain `100x80` task bounds with no `isExpanded` and scatters the nested tool
shapes *outside* it — and `bpmn-di-check.cjs` still reports "DI complete", so the automatic
fallback never fires and the broken diagram ships silently. bpmnkit's `.withAutoLayout()` emits
`isExpanded="true"` with bounds enclosing every child, and both cleanup passes
(`bpmn-node-placement.cjs`, `bpmn-edge-cleanup.cjs`) leave that geometry untouched.

Never hand-compute `dc:Bounds` for the container or its tools — auto-layout owns all of it.

As with every other connector, regenerating or re-running layout **after** binding overwrites the
template binding, so bind only once the layout command has finished.

### 2. Bind the C8 AI Agent template after layout

Set the connector properties through `c8ctl`; do not splice an `extensionElements` block. Use
the canonical property names from `c8ctl element-template get-properties` for the selected
template version.

```bash
c8ctl element-template apply -i io.camunda.connectors.agenticai.aiagent.jobworker.v1@{{templateVersion}} \
  AIAgent_{{TaskID}} <OUTPUT_BPMN> \
  --set provider.type=anthropic \
  --set 'provider.anthropic.authentication.apiKey={{secrets.ANTHROPIC_API_KEY}}' \
  --set provider.anthropic.model.model={{modelId}} \
  --set 'data.systemPrompt.prompt=={{systemPromptExpression}}' \
  --set 'data.userPrompt.prompt=={{userPromptVariable}}' \
  --set data.memory.storage.type=in-process \
  --set data.memory.contextWindowSize=20 \
  --set data.limits.maxModelCalls=10 \
  --set data.events.behavior=WAIT_FOR_TOOL_CALL_RESULTS \
  --set data.response.format.type=text \
  --set data.response.format.parseJson=false \
  --set data.response.includeAssistantMessage=false \
  --set data.response.includeAgentContext=false
```

For a provider other than Anthropic, first set `provider.type`, then use that provider's
property names from `get-properties`. Use the `=` prefix in `--set` for every process-variable
reference or FEEL expression. The `apply` command emits the template icon and all template-owned
Camunda 8 extensions.

### 3. Verify the binding preserved the tool subtree

`c8ctl element-template apply` only edits the bound element's own semantic + Zeebe extensions. It
**preserves** the `Tool_*` children step 1 declared, their `bpmn:documentation`, their DI shapes, and
the container's `isExpanded` bounds — verified on the AI Agent template v7. So there is no post-apply
tool patch: never re-insert tool XML by hand, and never replace or modify the bound subprocess's
`bpmn:extensionElements`, template attributes, incoming/outgoing flows, or template-owned mappings
and headers.

Confirm after `apply`, before moving on:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/ai-agent-tool-check.cjs" "<OUTPUT_BPMN>" --expect-tools <N>
```

Exit `0` prints `PASS`. Exit `1` prints `FAIL` plus the counts, and names the broken expectation on
stderr — a non-zero `chainedTools` means a sequence flow attaches to a tool, which demotes it from a
root node to a sub-flow step. Remove whatever connects it in the `.gen.mjs`, regenerate, then
re-apply the template. Exit `2` is bad input: nothing was checked, so do not read it as a pass.

The `zeebe:` shapes below document what each tool's builder options must produce (`ioMapping`,
`taskHeaders`, `taskDefinition`), so you can read a generated file and check it. They are **not** XML
to author: emit them from the `.gen.mjs` builder options in step 1.

```xml
<!-- What the .gen.mjs builder options produce for a tool inside AIAgent_{{TaskID}}. -->
<!-- Tool 1: Read/lookup operation -->
  <bpmn:serviceTask id="Tool_{{FirstAction}}" name="{{First tool name}}">
    <bpmn:documentation>{{Describe when and why the LLM should call this tool.
      This text becomes the tool description shown to the LLM. Be specific.}}</bpmn:documentation>
    <bpmn:extensionElements>
      <zeebe:taskDefinition type="io.camunda:http-json:1" retries="3" />
      <zeebe:ioMapping>
        <zeebe:input source="GET" target="method" />
        <zeebe:input source="={{baseUrl}}/{{endpoint}}/{{=fromAi(toolCall.id, &quot;The record ID to look up&quot;, &quot;string&quot;)}}"
          target="url" />
      </zeebe:ioMapping>
      <zeebe:taskHeaders>
        <zeebe:header key="resultVariable" value="toolCallResult" />
        <zeebe:header key="resultExpression" value="={ &quot;data&quot;: body }" />
      </zeebe:taskHeaders>
    </bpmn:extensionElements>
  </bpmn:serviceTask>

  <!-- Tool 2: Write/update operation -->
  <bpmn:serviceTask id="Tool_{{SecondAction}}" name="{{Second tool name}}">
    <bpmn:documentation>{{Describe when and why the LLM should call this tool.}}</bpmn:documentation>
    <bpmn:extensionElements>
      <zeebe:taskDefinition type="io.camunda:http-json:1" retries="3" />
      <zeebe:ioMapping>
        <zeebe:input source="POST" target="method" />
        <zeebe:input source="={{baseUrl}}/{{endpoint}}" target="url" />
        <zeebe:input source="=fromAi(toolCall.payload, &quot;The data payload to send&quot;, &quot;string&quot;)"
          target="body" />
      </zeebe:ioMapping>
      <zeebe:taskHeaders>
        <zeebe:header key="resultVariable" value="toolCallResult" />
        <zeebe:header key="resultExpression" value="" />
      </zeebe:taskHeaders>
    </bpmn:extensionElements>
  </bpmn:serviceTask>

<!-- Add more Tool_* service tasks here as needed, each with no bpmn:incoming element. -->
```

### 4. Validate the final BPMN as Camunda 8

The template `apply` is a BPMN mutation, so validate after it. Both checks must pass with zero
errors before the BPMN is considered generated:

```bash
c8ctl bpmn lint <OUTPUT_BPMN>
node .github/skills/process-os-camunda-compatibility-check/scripts/validate.cjs --version 8.9 <OUTPUT_BPMN>
```

(`validate.cjs` resolves `NODE_PATH` for the bpmnlint child process it spawns internally — no caller-side environment setup needed; see the "Setup" note in `process-os-artifact-generation/SKILL.md`.)

Do not emit Camunda 7 `camunda:` extensions, `${...}` expressions, Java delegates, execution
listeners, or external-task configuration anywhere in an automatable BPMN. Use Zeebe extensions
and FEEL expressions only.

---

## DI Layout for the Ad-Hoc Sub-Process

**Auto-layout owns every coordinate. Never hand-compute `dc:Bounds` for the container or its tools.**
Because the tools are declared inside the `.adHocSubProcess()` content callback (step 1), bpmnkit's
`.withAutoLayout()` emits the container as `isExpanded="true"` with bounds that enclose every child
shape, and grows those bounds with the tool count.

The two requirements to *verify*, not to author:

- The container shape carries `isExpanded="true"`.
- Every `Tool_*` shape's bounds fall inside the container's bounds.

Both hold on the `BPMN_LAYOUT=bpmnkit` path — which is mandatory here, per step 1: the bpmn-io
primary gives the container plain `100x80` bounds with no `isExpanded` and places the tool shapes
outside it, and `bpmn-di-check.cjs` does not catch it.

---

## How to Model Tools Inside the Ad-Hoc Sub-Process

### Rule: A tool is any activity with NO incoming sequence flows

Tools must appear as child XML elements of the subprocess. No `bpmn:incoming` element = tool (LLM can invoke it). Having a `bpmn:incoming` element = part of a sub-flow (not a tool).

### Tool with `fromAi()` Parameters

When a tool needs input parameters from the LLM, use `fromAi()` in input mappings:

```xml
<bpmn:serviceTask id="Tool_SearchRecords" name="Search records">
  <bpmn:documentation>Searches for records matching a query string.
    Call this when you need to find existing records by name or attribute.</bpmn:documentation>
  <bpmn:extensionElements>
    <zeebe:taskDefinition type="io.camunda:http-json:1" retries="3" />
    <zeebe:ioMapping>
      <zeebe:input source="GET" target="method" />
      <zeebe:input source="=baseUrl + &quot;/records?q=&quot; + fromAi(toolCall.query, &quot;Search query string&quot;, &quot;string&quot;)"
        target="url" />
    </zeebe:ioMapping>
    <zeebe:taskHeaders>
      <zeebe:header key="resultVariable" value="toolCallResult" />
      <zeebe:header key="resultExpression" value="={ &quot;records&quot;: body.items }" />
    </zeebe:taskHeaders>
  </bpmn:extensionElements>
</bpmn:serviceTask>
```

### Tool with `toolCallResult` via Result Expression (REST connector pattern)

For tools using the HTTP connector, always set `resultVariable` and `resultExpression` as task headers. The result expression shapes the API response before it is sent back to the LLM:

```xml
<zeebe:taskHeaders>
  <zeebe:header key="resultVariable" value="toolCallResult" />
  <zeebe:header key="resultExpression" value="={ &quot;status&quot;: response.statusCode, &quot;body&quot;: body }" />
</zeebe:taskHeaders>
```

For tools that only perform side effects (send notification, trigger event) and don't need to return data, set an empty `resultExpression`:

```xml
<zeebe:taskHeaders>
  <zeebe:header key="resultVariable" value="toolCallResult" />
  <zeebe:header key="resultExpression" value="" />
</zeebe:taskHeaders>
```

### Tool using a Script Task (for data transformation or in-process logic)

Script tasks are valid tools. Use `zeebe:script` with `resultVariable="toolCallResult"`:

```xml
<bpmn:scriptTask id="Tool_TransformData" name="Transform data">
  <bpmn:documentation>Transforms and validates the input data.
    Call this to normalize a data structure before writing it to a system.</bpmn:documentation>
  <bpmn:extensionElements>
    <zeebe:script expression="={ &quot;normalized&quot;: fromAi(toolCall.input, &quot;The raw input to transform&quot;, &quot;string&quot;).trim() }"
      resultVariable="toolCallResult" />
  </bpmn:extensionElements>
</bpmn:scriptTask>
```

### Key rules for `fromAi()`
- First argument: `toolCall.<parameterName>` — the last segment becomes the parameter name the LLM sees.
- Second argument (description): shown to the LLM to help it understand what value to provide. Always include.
- Third argument (type): `"string"` (default), `"number"`, `"boolean"`.
- The **element ID** is the tool name the LLM sees — use a clear, descriptive ID.
- The **`bpmn:documentation`** becomes the tool description the LLM reads to decide whether to call the tool. Always write one.

### Tool with a Sub-Flow (Human-in-the-Loop Pattern)

A root-node tool can trigger a deterministic sub-flow by having outgoing sequence flows to downstream activities:

```xml
<!-- ROOT NODE = TOOL (no incoming flow, has outgoing flow to start sub-flow) -->
<bpmn:serviceTask id="Tool_GenerateReport" name="Generate report">
  <bpmn:documentation>Generates a report for review. Call when analysis is complete.</bpmn:documentation>
  <bpmn:extensionElements>
    <zeebe:taskDefinition type="generate-report" retries="3" />
    <zeebe:taskHeaders>
      <zeebe:header key="resultVariable" value="toolCallResult" />
      <zeebe:header key="resultExpression" value="" />
    </zeebe:taskHeaders>
  </bpmn:extensionElements>
  <bpmn:outgoing>Flow_ToReview</bpmn:outgoing>
</bpmn:serviceTask>

<!-- NOT A TOOL: has incoming flow — executes automatically after Tool_GenerateReport -->
<bpmn:userTask id="Task_ReviewReport" name="Review report">
  <bpmn:incoming>Flow_ToReview</bpmn:incoming>
  <bpmn:outgoing>Flow_ToGateway</bpmn:outgoing>
</bpmn:userTask>

<bpmn:sequenceFlow id="Flow_ToReview"
  sourceRef="Tool_GenerateReport" targetRef="Task_ReviewReport" />
```

**Why this works:** The LLM sees only `Tool_GenerateReport` as a tool (root node). When it invokes it, the downstream sub-flow (review → gateway → etc.) executes deterministically.

---

## How the Ad-Hoc Sub-Process Fits in the Parent Process

The ad-hoc sub-process connects to the parent process via normal sequence flows:

```xml
<bpmn:process id="MainProcess" isExecutable="true">
  <bpmn:startEvent id="StartEvent_1" name="Request received">
    <bpmn:outgoing>Flow_1</bpmn:outgoing>
  </bpmn:startEvent>

  <bpmn:sequenceFlow id="Flow_1" sourceRef="StartEvent_1" targetRef="AIAgent_ReviewAndUpdate" />

  <!-- AI Agent ad-hoc sub-process. The .gen.mjs built the container AND its nested tools;
       c8ctl then applied the template-owned C8 extensions and icon, preserving both. -->
  <bpmn:adHocSubProcess id="AIAgent_ReviewAndUpdate" name="Review and update records">
    <bpmn:incoming>Flow_1</bpmn:incoming>
    <bpmn:outgoing>Flow_2</bpmn:outgoing>

    <!-- Tool activities nested here — child elements of this subprocess -->
    <bpmn:serviceTask id="Tool_LookupRecord" name="Look up record">
      <!-- ... -->
    </bpmn:serviceTask>
    <bpmn:serviceTask id="Tool_UpdateStatus" name="Update status">
      <!-- ... -->
    </bpmn:serviceTask>
  </bpmn:adHocSubProcess>

  <bpmn:sequenceFlow id="Flow_2" sourceRef="AIAgent_ReviewAndUpdate" targetRef="Task_Finalize" />

  <bpmn:task id="Task_Finalize" name="Finalize">
    <bpmn:incoming>Flow_2</bpmn:incoming>
    <bpmn:outgoing>Flow_End</bpmn:outgoing>
  </bpmn:task>

  <bpmn:endEvent id="EndEvent_1">
    <bpmn:incoming>Flow_End</bpmn:incoming>
  </bpmn:endEvent>
</bpmn:process>
```

---

## Configuration Properties Reference

These are template-owned `zeebe:input` targets. Set them through `c8ctl element-template apply
--set`, not by hand-authoring the subprocess's `zeebe:ioMapping`. The selected template version's
`get-properties` output is authoritative.

| Target | Required | Value / Type | Purpose |
|---|---|---|---|
| `provider.type` | Yes | `"anthropic"`, `"openai"`, `"azure-openai"`, `"bedrock"`, `"vertex-ai"` | LLM provider |
| `provider.{type}.authentication.apiKey` | Yes | Secret reference | Auth credential |
| `provider.{type}.model.model` | Yes | Model ID string | Which model to use |
| `data.systemPrompt.prompt` | Yes | FEEL string expression | Agent behavior definition |
| `data.userPrompt.prompt` | Yes | FEEL expression referencing a process variable | Runtime input |
| `agentContext` | No | Variable reference or empty | Multi-turn conversation state |
| `data.memory.storage.type` | No | `"in-process"` | Memory persistence |
| `data.memory.contextWindowSize` | No | FEEL number (e.g. `=20`) | Max messages retained |
| `data.limits.maxModelCalls` | Yes | FEEL number (e.g. `=10`) | Max LLM round-trips (safety limit) |
| `data.events.behavior` | Yes | `"WAIT_FOR_TOOL_CALL_RESULTS"` | Wait for tools before next call |
| `data.response.format.type` | No | `"text"` or `"json"` | Response format |
| `data.response.format.parseJson` | No | `=false` / `=true` | Parse response as JSON |
| `data.response.includeAssistantMessage` | No | `=false` / `=true` | Include raw LLM message |
| `data.response.includeAgentContext` | No | `=false` / `=true` | Return context in output |

**Output mapping:** Always include `<zeebe:output source="=agent" target="agent" />` to write the agent result to a process variable.

---

## The `zeebe:adHoc` Output Collection

The AI Agent Element Template writes this required extension inside the subprocess's
`bpmn:extensionElements`. Do not hand-author or replace it. It wires tool results back to the
agent connector:

```xml
<zeebe:adHoc outputCollection="toolCallResults"
  outputElement="={
    id: toolCall._meta.id,
    name: toolCall._meta.name,
    content: toolCallResult
  }" />
```

- `outputCollection`: Collects all tool results from one iteration into a list.
- `outputElement`: FEEL expression mapping each individual tool's output.
- `toolCall._meta.id` / `toolCall._meta.name`: Runtime metadata injected by the engine.
- `toolCallResult`: The variable each tool MUST set to return data to the LLM.

---

## `fromAi()` Function Reference

Declares that a parameter value will be provided by the LLM at runtime.

| Signature | Example |
|---|---|
| `fromAi(value)` | `fromAi(toolCall.query)` |
| `fromAi(value, description)` | `fromAi(toolCall.query, "Search term")` |
| `fromAi(value, description, type)` | `fromAi(toolCall.count, "Number of items", "number")` |
| `fromAi(value, description, type, schema)` | `fromAi(toolCall.status, "Status", "string", { enum: ["active", "inactive"] })` |
| `fromAi(value, description, type, schema, options)` | `fromAi(value: toolCall.filter, options: { required: false })` |

**Rules:**
- `value` is always `toolCall.<paramName>` — the last segment becomes the parameter name the LLM sees.
- `description` is shown to the LLM to help it understand what to provide. Always include it.
- `type` defaults to `"string"`. Use `"number"`, `"boolean"`, or `"string"` with a `schema` for enums.
- Parameters are required by default. Use `options: { required: false }` for optional ones.

---

## Summary: Emitting an AI Agent in Generated BPMN

When you identify a step that needs an AI agent:

1. Generate the `bpmn:adHocSubProcess` container and its tool activities with bpmnkit
   (`buildAiAgentSubProcess()`) in an executable Camunda 8 BPMN.
2. After layout, bind `io.camunda.connectors.agenticai.aiagent.jobworker.v1@7` with
  `c8ctl element-template apply`, setting connector properties with `--set`.
3. The tool activities are children of the bound `bpmn:adHocSubProcess`, declared in step 1 and
  preserved by the template apply — never XML patched in afterwards. This is non-negotiable — an
  empty subprocess cannot be deployed.
4. For each tool:
   - No `bpmn:incoming` element (root node = tool).
   - A clear `bpmn:documentation` element (the LLM reads this to decide when to call the tool).
   - `fromAi()` in input mappings for any parameters the LLM must provide.
   - `zeebe:taskHeaders` with `resultVariable: "toolCallResult"` (and optionally `resultExpression`) to return data to the LLM.
5. Connect the ad-hoc sub-process to the parent process with normal `bpmn:incoming` / `bpmn:outgoing` sequence flows.
6. Never author the DI: `.withAutoLayout()` on the `BPMN_LAYOUT=bpmnkit` path emits `isExpanded="true"` with bounds enclosing every tool shape. Verify it did, do not compute it.
7. Run `c8ctl bpmn lint` and the ProcessOS Camunda 8 compatibility check after the template apply; fix every error before continuing.

---

## Sources

- [Agentic Orchestration Overview](https://docs.camunda.io/docs/components/agentic-orchestration/agentic-orchestration-overview/)
- [AI Agents Concepts](https://docs.camunda.io/docs/components/agentic-orchestration/ai-agents/)
- [Getting Started Guide](https://docs.camunda.io/docs/guides/getting-started-agentic-orchestration/)
- [AI Agent Connector](https://docs.camunda.io/docs/components/connectors/out-of-the-box-connectors/agentic-ai-aiagent/)
- [AI Agent Sub-process Implementation](https://docs.camunda.io/docs/components/connectors/out-of-the-box-connectors/agentic-ai-aiagent-subprocess/)
- [Tool Definitions](https://docs.camunda.io/docs/components/connectors/out-of-the-box-connectors/agentic-ai-aiagent-tool-definitions/)
- [Ad-Hoc Sub-Processes](https://docs.camunda.io/docs/components/modeler/bpmn/ad-hoc-subprocesses/)
- [`fromAi()` Function Reference](https://docs.camunda.io/docs/components/modeler/feel/builtin-functions/feel-built-in-functions-miscellaneous/#fromaivalue)
