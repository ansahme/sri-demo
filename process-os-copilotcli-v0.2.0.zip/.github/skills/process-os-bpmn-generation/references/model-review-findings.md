# BPMN Findings Library — what model reviewers flag

Distilled from Camunda Consulting's Model Review playbook (internal handbook; findings collected
across real customer model reviews). Each finding carries the **occurrence rate** observed across
past reviews — the high-occurrence findings are what a professional reviewer would flag first in
generated BPMN, so treat those as hard requirements.

How to use this file:

- **When generating BPMN:** do not produce these findings. Prioritize by occurrence — R1 (gateway
  standard pattern, 100%), R2 (happy-path alignment, 90%), V1 (implicit merges, 60%) are
  near-certain review flags.
- **When updating existing BPMN:** report matches by finding ID (`V…`/`C…`/`R…`/`F…`) —
  **correctness** findings are defects to fix, **violations** should be fixed unless deliberate,
  **readability**/**refactoring** findings are proposals for the process owner.
- Several violations are already enforced mechanically by `process-os-bpmn-linting`
  (V1/V2 ≈ `fake-join`, V3 ≈ `no-implicit-split`, V4 ≈ `conditional-flows`,
  C1 ≈ `superfluous-termination`) — the rest are review-level knowledge the linter cannot see, and
  candidates for future custom lint rules. F10 is a partial exception: `bpmnlint:recommended`'s
  built-in `no-inclusive-gateway` rule mechanically flags the *presence* of any `InclusiveGateway`
  (cruder than F10 — it can't tell a genuine any-subset case from a disguised parallel split), so it
  still warns even when F10's carve-out applies and the gateway should be kept.

## Best-practice violations

| # | Finding | Occurrence | Fix |
|---|---------|-----------|-----|
| V1 | Two or more sequence flows merge implicitly into a task or intermediate event | 60% | Insert a merging exclusive gateway. Implicit merges read like synchronizing joins, hide unintended token generation after parallel splits, and become invisible over distance |
| V2 | Sequence flows merge into a *splitting* gateway | 40% | Separate join gateway before the split — never mix joining and splitting logic in one gateway |
| V3 | Two or more sequence flows exit a task or event | rare | Explicit splitting gateway. Undeclared parallelism is hard to spot; synchronizing it needs a parallel gateway anyway |
| V4 | Conditional flows used | 10% | Replace with an explicit gateway — readers don't recognize conditional flows as inclusive-OR semantics |
| V5 | Generic error handling via event sub-process | 20% | Delete it. BPMN errors are *business* reactions; technical errors that need no business reaction should raise incidents, not interrupt instances generically |
| V6 | Small-scale technical retry modeled in BPMN | 10% | Delete it. Configure `retries` on `zeebe:taskDefinition`; final failure raises an incident |

## Correctness risks

| # | Finding | Occurrence | Fix |
|---|---------|-----------|-----|
| C1 | Terminate end event in a scope with no parallel processing | 10% | Remove — it is redundant and misleads readers into thinking it terminates higher scopes (it never does). Frequent in event sub-processes where the interrupting start already provides the behavior |
| C2 | Terminate end event in a multi-instance sub-process intended to cancel all instances | 5% | It does NOT cancel sibling instances. Throw an error/escalation caught by an interrupting boundary event or event sub-process instead |
| C3 | Parallel-join deadlock: fewer tokens can reach the synchronizing gateway than it has incoming flows | <5% | Flag for the process owner — never silently "fix". Deadlock patterns must be redesigned even when technical configuration claims to prevent them |
| C4 | Loop-back into the flow *before* a parallel split | <5% | Each loop iteration re-spawns all parallel branches → token accumulation on user tasks or duplicate execution. Keep loops inside one branch or after the join |
| C5 | Tight loop around an intermediate timer event | 5% | Short wait durations × many instances = severe performance risk. Add a timeout boundary (embedded sub-process + timer event sub-process) and flag the polling design |

## Readability

| # | Finding | Occurrence | Fix |
|---|---------|-----------|-----|
| R1 | Gateway outgoing flows don't follow the standard pattern | 100% | Main/default flow goes straight right; every other branch goes down, then 90° right, at equal vertical distances |
| R2 | No consistent horizontally-aligned happy path from start to end event | 90% | Per scope (including embedded sub-processes), align one consistent left-to-right sequence — and make it the happy path |
| R3 | Boundary events attached to the top of tasks | 30% | Attach to the bottom. More than two boundary events → consider an event sub-process or wrap in an embedded sub-process |
| R4 | Boundary events on top of embedded sub-processes | 20% | Attach to the sides below the in/out sequence flows (best) or the bottom, aligned to where in the flow they can trigger |
| R5 | Flows merge into an end event so its label can't sit below it | 30% | Re-route waypoints or add a merging exclusive gateway — event labels always sit below the event |
| R6 | Stacked exclusive gateways evaluating the same variable | ~10% | Consolidate into one gateway with 3+ outgoing flows |
| R7 | Flows merging directly after a start event, or into a looping event-based gateway | ~10% | Acceptable — flag only when long sequence flows are involved (then add a merging gateway) |

## Refactoring potential

| # | Finding | Occurrence | Fix |
|---|---------|-----------|-----|
| F1 | Long left-to-right sequence flow spanning the diagram | 60% | In preference order: extract an embedded sub-process (gains an end event), extract a call activity, duplicate low-significance trailing elements, or (last resort) a forward link-event pair |
| F2 | Mid/long right-to-left sequence flow (usually gateway loop-backs) | 50% | Link-event pair — use with less hesitation than forward links: it preserves reading direction and lets the gateway keep the standard pattern. Keep paired link events on the same y-coordinate |
| F3 | Replicated sub-processes not extracted | 15% | Extract to a separate BPMN file invoked via call activity; scope variables with explicit in/output mapping |
| F4 | Near-duplicate BPMN files for the same functionality | 10% | One dynamic model: FEEL-driven task types and condition expressions instead of copies |
| F5 | Replicated intermediate message catch events for error cases | 10% | Interrupting boundary events or an event sub-process — reduces catch-event count; note the behavioral difference (event sub-process fires whenever a token is in scope) |
| F6 | Long flows converging at the same later location | 10% | Strong sub-process signal: an embedded sub-process replaces them with (error) end events; extract via call activity where business intelligence per sub-process matters |
| F7 | Large-scale retry behavior modeled inline | 10% | Embedded sub-process + interrupting error/escalation boundary events |
| F8 | Many link throw events targeting one link catch | 5% | Enforce one-to-one link pairs, labels naming both ends — many-to-one is hidden implicit modeling |
| F9 | Same boundary event replicated on multiple call activities | 5% | Move it into the called process as an event sub-process |
| F10 | Inclusive-OR gateway where *every* outgoing branch is static/always-true (behaviorally identical to a parallel split), or with only two outgoing flows | 5% | Replace with parallel + exclusive gateway combination. Judge the split as a whole, not branch-by-branch: a mix of always-true "core" branches plus one or more genuinely conditional branches is a legitimate any-subset case (e.g. optional suborder types — the base order always ships, insurance/gift-wrap are data-dependent add-ons) and should be kept, even though some individual branches remain static |
| F11 | Sequential FEEL script tasks computing one result | ~5% | One script task with a FEEL context block — later entries reuse earlier ones (`{step1: …, step2: …, result: …}.result`) |
| F12 | Business reactions to errors invisible in the model | 5% | Make them explicit BPMN error events: service task throws → boundary/event-sub-process catches, or an exclusive gateway routes to an error end event |
| F13 | Nested multi-instance sub-processes where the outer is pass-through | 5% | Collapse into one using FEEL `flatten()` on the nested collection |

## Variable-handling recommendations

Apply when emitting Zeebe extensions (io-mappings, script tasks, call activities, multi-instance):

- **Orchestration variables only.** Only variables needed for routing belong in the process;
  business-intelligence data goes to Optimize via the External Variable Ingestion API.
- **Scope explicitly.** Input/output mappings on sub-processes and activities confine variables to
  their proper scope; call activities create an isolated scope — avoid propagate-all in either
  direction, map only what each side needs.
- **Localize in multi-instance.** Define per-instance variables as local via input mapping; never
  hand each instance the full input collection — only its own element.
- **Example data.** Encourage example data on elements (enables FEEL variable suggestions and the
  Data Outline plugin's scope verification).
