# Connectors (automatable mode only)

Strategic mode never binds connectors. In automatable mode, bind a service task (or
event element) to a Camunda connector via `c8ctl element-template apply` — c8ctl writes
all six attributes (`zeebe:modelerTemplate`, version, **icon**, `taskDefinition`, full
`ioMapping`, `taskHeaders`). The agent never reads the connector-bloated file, so there
is no icon/token-cap problem.

## Prerequisites

- `c8ctl` installed (already a process-os dependency).
- One-time OOTB catalog sync: `c8ctl element-template sync`.

## Discover → inspect → apply

```bash
# 1. Discover the template id (do not guess ids):
c8ctl element-template search "REST" --engine-version 8.9.0
# 2. Inspect settable properties:
c8ctl element-template get-properties io.camunda.connectors.HttpJson.v2 url method
# 3. Apply to the element the bpmnkit script created (by element id), in place:
c8ctl element-template apply -i io.camunda.connectors.HttpJson.v2 Task_FetchUser <OUTPUT_BPMN> \
  --set method=GET --set url='="https://api.example.com"'
```

### `--set` value rules (FEEL vs literal — verified, c8ctl v3.2.0)

`--set` matches the **canonical name** from `get-properties` (the bold left column). The dim
`[id: …]` alias is **not** accepted (`--set <bracketed-id>=…` → `Unknown property`). Whether
c8ctl auto-prepends a FEEL `=` depends on the property's **FEEL mode**:

- **`feel=required`** (e.g. `resultExpression`, `errorExpression`): `--set key=x` auto-prepends → `=x`.
- **`feel=optional` / static / Dropdown / number / boolean** (e.g. `url`, `body`, `data.modelId`,
  `method`): the value is written **VERBATIM, no `=`**. ⚠ So `--set url=case_id` writes the
  **literal string** `case_id`, not a reference to variable `case_id` — a silent false-green
  (lint won't catch it).

**Universal safe rule — write the `=` yourself for any variable ref or FEEL expression.** It
produces a single-`=` value and is idempotent on `feel=required` (no doubling), so it is
correct on every property without checking its mode:

| Intent | `--set` arg (shell-quoted) | Resulting `source=` |
|---|---|---|
| reference process var `case_id` | `--set 'to==case_id'` | `=case_id` |
| FEEL expression / context | `--set 'body=={a: amount}'` | `={a: amount}` |
| static string literal (URL, enum) | `--set url=https://api.example.com` | `https://api.example.com` |
| secret ref | `--set 'authentication.username={{secrets.X}}'` | `{{secrets.X}}` |
| number / boolean | `--set storeResponse=true` | `true` |

(Literals/enums and `{{secrets.X}}` take no `=`; process-var refs like `=customerEmail` take it.)

**Choice / condition groups** (e.g. Bedrock `action` = invokeModel vs converse): set the
**gating** property FIRST in the same `apply` (`--set action=invokeModel …`); properties
shared across groups (`data.modelId`) collapse to one canonical key and apply regardless. A
property whose group condition isn't met is dropped with `⚠ Property "X" was set but not
applied (unmet condition)` — treat that warning as a bug to fix (wrong/missing gating prop),
not noise.

Run `apply` as a **separate Bash step, after the entire layout orchestrator has
finished** (see `generate-phase.md` — bpmnkit scaffold + bpmn-io layout + DI check, or bpmnkit
recovery + node-placement + edge-cleanup) and **before** the lint hook's final pass (the hook re-lints
on the apply's Bash call too). Do **not** apply before or inside that command: its first step
`node <gen>.mjs` rebuilds the file from a connector-less builder and overwrites the binding
(the bpmnkit-fallback branch re-runs `<gen>.mjs`, so even a mid-command apply is lost).
`apply` edits only the element's semantic + Zeebe extensions, so it **preserves** the DI the
layout command produced. **Fix-loop:** re-running the layout command wipes all bindings —
re-apply every connector after each re-run. `apply` owns the whole `ioMapping` — put any
downstream output extraction on a separate element.

## When to bind

Bind only when the phase file marks a step `[Connector:<id>]` or clearly names a known
integration (REST, Slack, Kafka, email, …). Otherwise leave an abstract `serviceTask`
with a `taskType` + `Implementation:` annotation. Genuinely unknown → `❓` annotation.

### Vendor name → generic OOTB connector

A phase file often names a **vendor or a project-specific connector instance** that has no
template of its own in the catalog (`c8ctl element-template search` returns nothing). Bind the
**generic OOTB connector for that integration class**, not a per-vendor template — most
SaaS/email/HTTP integrations resolve this way:

| Phase names… | Bind (generic OOTB) |
|---|---|
| Gmail / G-Suite / any mailbox (outbound send) | `io.camunda.connectors.email.v1` (SMTP) |
| Gmail / IMAP inbound (poll/trigger) | `io.camunda.connectors.inbound.EmailReceive.v1` / `…EmailMessageStart.v1` |
| a named REST/HTTP service or webhook | `io.camunda.connectors.HttpJson.v2` |

Annotate the substitution on the element (`Implementation: Gmail via generic Email connector`)
so the vendor intent isn't lost. Keep the `=`-prefix convention when binding it: literals/enums
and `{{secrets.X}}` refs take **no** `=`; process-variable refs like `=customerEmail` take the `=`.
If the catalog genuinely has no connector for the integration class, leave an abstract
`serviceTask` + `taskType` + `Implementation:` note rather than forcing a wrong template.
