# Sub-Skill: Update an existing BPMN from edited Markdown (update mode)

Update mode surgically re-derives **one** existing BPMN file from its changed Markdown
source by **editing the retained `<target>.bpmn.gen.mjs` generator script and re-running
it** — never by hand-editing the `.bpmn`, and never a full-directory fan-out. It is the
mechanism `/process-os-process-discovery`'s BPMN-regen phase uses to keep a `.bpmn` pendant
in sync with its edited `.md` source of truth.

This relies on the generator script being kept next to its output (see SKILL.md
"Keep the generator scripts"). If it is absent, update mode cannot run — fall back to a full
generate.

## Invocation

```
process-os-bpmn-generation --target <file.bpmn> --from <file.md>[,<file2.md>,...]
```

- `--target <file.bpmn>` — required, **exactly one**. The existing BPMN to update in place.
- `--from <md>[,<md>...]` — required, **one or more** (comma-separated). The changed/staged
  Markdown authoring source(s) that drive the update. One `.md` for a phase pendant (same
  basename); **multiple** for an aggregate diagram — e.g. `00-overview.bpmn` re-derived from
  every changed `process-NN-*.md`.

Markdown stays the single source of truth; the diagram is regenerated to match it.

## EXEC: Step 0 — Parse & validate

1. Parse `--target` (exactly one) and `--from` (split on `,`, ≥1). More than one `--target`
   → error and stop.
2. `--target` must exist and end in `.bpmn`; each `--from` must exist and end in `.md`. Any
   miss → print which path failed and stop.
3. The generator must exist next to the target:
   ```bash
   node ".github/skills/process-os-bpmn-generation/scripts/path-exists.cjs" "<target>.gen.mjs"
   ```
   If `NOT FOUND` → output exactly:
   `No generator <target>.gen.mjs found. Update mode needs the retained bpmnkit source — run a full 'process-os-bpmn-generation' for this directory first.`
   and stop.
4. Resolve `BPMNKIT_IMPORT` the way the standard flow does (SKILL.md Setup step 2b-kit — a
   project-relative import specifier from `<target>`'s own directory to `@bpmnkit/core`'s
   pinned entry). The `.gen.mjs` imports bpmnkit by that specifier; if it no longer resolves,
   re-point only the import line to the current `BPMNKIT_IMPORT` before running (do not
   otherwise reformat the script). A generator written before this convention may carry a bare
   absolute path or a machine-specific `file://` URL — replace it with the current relative
   `BPMNKIT_IMPORT` regardless of which form it currently has.

## EXEC: Step 1 — Snapshot the target

Pre-snapshot before mutating (same generic mechanism as the other modes), scoped to the
target's directory. Under `--no-snapshot`, skip this step:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/snapshot.cjs" save "<target>" "<target>" "<target>.gen.mjs" PROCESSES.md
```

`<target>` is passed twice deliberately: once as the **directory** argument (the script resolves `.snapshots/` from the directory of the path it is handed — nothing has to strip the filename first), once as the first **copy pattern** — the trigger that decides whether anything gets snapshotted at all, and one of the files actually copied. Prints the created version bare (e.g. `v2`).

## Step 2 — Read the sources (required reading)

Read, in this order:

1. Each `--from` `.md` — the **new source of truth** for what the diagram must show.
2. `<target>.gen.mjs` — the builder script that produced the current diagram. This is the
   **authoritative source of element ids and structure**; reuse those ids so unchanged
   elements keep their coordinates.
3. `<target>` (the BPMN) — **do not slurp the whole file.** Read its **`git diff HEAD`** to
   see what changed since the last commit — diff against `HEAD` rather than the worktree
   alone, because a caller (e.g. a later `/process-os-process-transformation` iteration folding
   in a reviewer's edits) may already have **staged** changes to the target, and a plain `git diff` shows nothing for staged
   content; item 2 already gives you the ids and structure. Only if the diff is dangling /
   lacks context, read the relevant region of the file — and then read it **safely** (see
   *Reading a BPMN safely* below), never as one unbounded Read.
4. `references/bpmnkit.md` — builder conventions (annotations, the branch-termination
   gotcha, the run command).

### Reading a BPMN safely (≤ ~25 KB Read limit)

A full BPMN can exceed the Read tool's ~25 KB limit — a connector-bound one by 1.5–3×.
Never single-Read a large `.bpmn`. In order of preference:

1. **Extract, don't dump** — process id, flow nodes, io-mapping variables and branch
   conditions as JSON (`--names` for names only):
   ```bash
   node ".github/skills/process-os-bpmn-generation/scripts/bpmn-extract.cjs" "<target>"
   ```
   Exit `2` → bad input (missing path, no `.bpmn` files, a dangling `--exclude`, or a malformed `--max-bytes`) — report stderr and stop. Exit `3` → the report is over the cap — re-run with `--names` or fewer files.
2. **Diff, not dump** — the change is usually all you need (against `HEAD`, so staged
   changes stay visible). When the changed attribute *is* a `zeebe:modelerTemplateIcon`,
   the diff carries the whole base64 blob — fall back to 1:
   ```bash
   git diff HEAD -- "<target>"
   ```
3. **Bounded ranges** — if you must read raw XML, read it in line ranges (the Read tool's
   range / offset-limit), not the whole file at once. An icon attribute sits on a single
   line, so one line can still be ~6 KB.

**Determine MODE from the existing script — do not re-prompt:** if `<target>.gen.mjs` calls
`.executable(true)` → `automatable`; otherwise → `strategic`. Preserve it. If the change adds
elements whose altitude/extensions must be right, also read the matching modeling guide
(`references/strategic-modeling.md` or `references/automatable-modeling.md`).

## AI: Step 3 — Edit the generator to match the new Markdown

Reconcile the builder chain in `<target>.gen.mjs` to the `--from` Markdown — a **surgical
delta, not a rebuild**:

- **Add** builder calls for new steps / gateways / events / annotations the `.md` now
  describes; **rename** where the `.md` renamed; **remove** calls for content the `.md`
  dropped.
- **Preserve the ids of unchanged elements verbatim** — unchanged ids keep their existing DI
  coordinates through the re-run; only renamed/added elements get auto-placed. Do not churn
  an id that did not need to change (it needlessly relayouts that element).
- Keep the script scaffolding intact: the project-relative bpmnkit import, `.executable(...)`,
  `.executionPlatformVersion(...)`, the `BPMN_LAYOUT` toggle, and the post-export fixes.
- Honor the width/annotation policy already embodied in the script; follow `bpmnkit.md`
  (builder-native features, the **branch-termination gotcha**) and the naming conventions in
  `generate-phase.md` ("Naming conventions").
- For a **multi-`--from`** aggregate target (`00-overview.bpmn`), update the overview's
  representation of each changed phase from its `.md`; leave unchanged phases alone.

Never edit the `.bpmn` directly at any point.

## EXEC: Step 4 — Re-run the generator

Run the **layout orchestrator** from `generate-phase.md` → "Step 3: Write and run the bpmnkit
script", substituting `<OUTPUT_BPMN>` = your `--target`. It rebuilds the `.bpmn` with bpmnkit
scaffold DI and bpmn-io final geometry; the restored bpmnkit baseline runs node-placement then
edge-cleanup only if bpmn-io fails. Do not use a bare `node <gen>.mjs` — it ships an incomplete
or unrefined file.

**If `<DIR>/question-targets.json` exists, the re-run just dropped that file's review-question
tags** — the generator does not carry `<bpmn:documentation>` — along with any bare `[CONFIRM]` tags
listed in `<DIR>/confirm-targets.json`. Restore both (idempotent; it also re-emits
`annotations.md`):

```bash
node ".github/skills/process-os-bpmn-generation/scripts/bpmn-question-tags.cjs" --dir <DIR>
```

## EXEC: Step 5 — Lint (fix via the script)

Lint the regenerated target; redirect per file (never capture lint inline — a large/broken
BPMN can exceed the Bash-stdout buffer):

```bash
node ".github/skills/process-os-bpmn-generation/scripts/lint-to-files.cjs" "<target-dir>" "<target-name>.bpmn"
```

`<target-dir>` is the directory holding `--target`, `<target-name>` its base name without the
extension. It writes the report to `.camunda/.lint/<target-name>.txt` and prints one
`<target-name> EXIT:<code>` line. Exit `2` means the target was **not** linted; never read it as
clean.

Read `.camunda/.lint/<target-name>.txt` on a non-zero exit. Fix every **error** with the fix-loop unit
from `generate-phase.md` (edit `<target>.gen.mjs` → re-run the Step 4 command → re-lint);
never hand-edit the BPMN. Warnings are non-blocking.

## EXEC: Step 6 — Refresh PROCESSES.md (if present)

If `<DIR>/PROCESSES.md` exists, regenerate **only the target's entry** per SKILL.md
"AI: Generate Documentation" (source = the updated `.bpmn`), leaving other entries untouched.

## EXEC: Step 7 — Snapshot, audit, state, memory

Post-snapshot (same mechanism as Step 1, over the now-updated files — the version number advances automatically). Under `--no-snapshot`, skip this step too:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/snapshot.cjs" save "<target>" "<target>" "<target>.gen.mjs" PROCESSES.md
```

Then:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/append-audit.cjs" "process-os-bpmn-generation (update)" "Updated <target> from <from-list>"
```

Add a `## BPMN Decisions` bullet in `.camunda/memory.md` noting the target, the
`--from` sources, and what changed. `process-os-bpmn-generation` owns no `.camunda/state.md`
lifecycle row — the invoking lifecycle skill records its own phase state. Keep
`<target>.gen.mjs` in place — never delete it.

## EXEC: Step 8 — Output

```
Update-mode regeneration complete.

Updated: <target>
  from:  <md1>[, <md2> ...]
  <target>.gen.mjs  ← edited + re-run (kept)
  PROCESSES.md      ← target entry refreshed (if present)

Linted clean. Snapshot: v<N>

Review:
  /process-os-file-viewer   ← open a local bpmn-js viewer
```

Under `--no-snapshot`, Steps 1 and 7 above never ran, so there is no `v<N>` — omit the
`Snapshot: v<N>` clause: the line reads `Linted clean.` alone.

Stop here — do not read the generate / edit sections of SKILL.md.

## Scope

Update mode **updates one existing target**. It does not create new pendants or delete
obsolete ones — the caller (e.g. `/process-os-process-discovery`, generating BPMN for the
iteration) decides those, routing new files to a full generate and deletions to an explicit
removal, asking the ProcessOS user first.
