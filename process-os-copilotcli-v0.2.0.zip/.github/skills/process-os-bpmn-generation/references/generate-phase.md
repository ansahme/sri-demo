# Sub-Skill: Generate Phase BPMN

You are generating one BPMN 2.0 file from a single phase markdown file **by writing a
small `@bpmnkit/core` script and running it** — never by hand-writing XML or DI.

Call the `@bpmnkit/core` fluent API directly for every element — `.task()`, `.serviceTask()`,
`.exclusiveGateway()`, `.annotate()`, `Bpmn.export(defs)`, and so on (see `references/bpmnkit.md`'s
worked script). Never write your own helper (`buildTask(id, name)`, `addSequenceFlow(from, to)`,
or similar) that assembles XML, moddle objects, or DI itself. If a shape has no builder method,
use `references/bpmnkit.md` → "Post-export fixes" instead of writing one.

## BPMN resource boundary

Every generated `.bpmn` resource contains exactly one top-level `bpmn:process`. Never
embed an independently executable called process in its caller's BPMN resource. A call
activity and its called process belong in separate BPMN resources. This invocation owns
only `OUTPUT_BPMN`: the orchestrator dispatches each `subprocess-*.md` source as its own
source/output pair, so never generate or modify a called child resource here.

The only multi-process exception is an explicit `bpmn:collaboration`: every root process
must be referenced by a `bpmn:participant` and the BPMN plane must belong to that
collaboration. A collaboration models participants; it is not a way to package a parent
and its called child together for deployment.

## Inputs (provided by the orchestrator)

- `PHASE_FILE` — e.g. `process-transformation/iteration-1/artifacts/process-01-quoting.md` (or
  `process-discovery/iteration-2/artifacts/process-01-quoting.md` for discovery —
  doc-set-agnostic)
- `REF_BPMN` — a same-basename `*.bpmn` to use as **supplementary reference**, or `"none"`
- `OUTPUT_BPMN` — e.g. `process-transformation/iteration-1/artifacts/process-01-quoting.bpmn`
- `MODE` — `strategic` | `automatable` (selects the modeling guide below)
- `WIDTH` — `s`, `m`, `l`, or `xl`. If empty/unset, derive it via the deterministic quantifier (dir-level) — see "Step 1a → Resolve WIDTH if unset".
- `WIDTH_SOURCE` — `explicit` or `auto`. Empty/unset means `auto` (a width this file derives itself is automatic).
- `BASENAME` — phase basename without extension (names the timing record)
- `BPMNKIT_IMPORT` — a project-relative import specifier from `OUTPUT_DIR` to the pinned
  `@bpmnkit/core` entry, pasted verbatim into the generator's `import`. Never rebuild
  it from an absolute path or a `file://` URL — see `references/bpmnkit.md`. Never empty
  (the orchestrator's deps gate stops the run instead); there is no hand-authored-XML fallback.
- `TIMING_DIR` — directory for the per-event timing record (e.g. `.camunda/timing/v5-wM-dM`). Every `timing.cjs` invocation MUST pass `--dir "<TIMING_DIR>"` (the Bash tool starts a fresh shell per call; an exported var would not survive).

## First: read the modeling guide for this mode

- `MODE=strategic` → read `references/strategic-modeling.md`.
- `MODE=automatable` → read `references/automatable-modeling.md`.

These set the altitude and which extensions are allowed. The element-mapping and
width rules below apply to both modes; the guide overrides on executability and connectors.

## Timing instrumentation

One canonical bash form, used everywhere:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/timing.cjs" --dir "<TIMING_DIR>" event "<BASENAME>" <event-name>
```

End-of-skill finalize:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/timing.cjs" --dir "<TIMING_DIR>" end "<BASENAME>"
```

The first `event` call seeds the start timestamp; subsequent calls append. **Emit on every path including failure** — partial records still aggregate.

**Event name vocabulary** (the aggregator counts these names exactly):

| Event | When |
|-------|------|
| `start` | Once, very first action — before reading `PHASE_FILE` |
| `mcp` | After every `search_camunda_knowledge_sources` call returns |
| `connector_resolved` | After each `c8ctl element-template apply` (automatable mode only) — see `connectors.md` |
| `http` | After each connector template HTTP fetch (cache-miss path only) (automatable mode only) |
| `script_run` | Once, immediately after the bpmnkit `node` script returns |
| `end` (via `end` subcommand) | Once, very last action |

Below, every step boundary just says "emit `<event-name>`" — substitute into the canonical form above.

## Step 1: Read the phase file

**Emit `start` first**, before any other action.

Read `PHASE_FILE`. Extract:

- **Process ID** → root `bpmn:process` ID when the source is `subprocess-*.md`; use the exact
  value in its `**Process ID:**` field so the parent call activity's `zeebe:calledElement`
  resolves this resource
- **Trigger** → start event name
- **Source system** → channel/system/actor that initiates (e.g. "Customer portal", "SAP", "Email", "Manual — Sales rep") → annotation on the start event
- **Steps in order** → tasks
- **Decision points** → exclusive gateways
- **End states / outcomes** → end events (one per terminal outcome)
- **Follow-up actions per end state** → downstream processes, notifications, handoffs, SLAs → annotation on the corresponding end event
- **Step details** → sub-bullets, notes, timing constraints, actor/system specifics, caveats → annotation for that element
- **Implementation details per element** → systems, APIs, data inputs/outputs, field mappings, integration points, technical constraints → annotation on every element (subject to width policy below)

**If `REF_BPMN` is not `"none"`**, read `references/phase-fallbacks.md`
("Using `REF_BPMN`") and follow it — the markdown stays authoritative, the diagram enriches.

## Camunda Docs

For any uncertain BPMN rule, element type, attribute, or constraint: call `search_camunda_knowledge_sources` (camunda-docs MCP). See `camunda-docs.md` for query examples and the HTTP fallback when MCP is unavailable. Don't rely on training data alone. **Emit `mcp`** after each call returns.

## Step 1a: Apply width-specific rendering rules

### Resolve WIDTH if unset

If `WIDTH` is empty, derive it the way the orchestrator does — **dir-level**, never per-file
(a per-file score drifts vs siblings; a transform-tier file scores 0→`s`). Re-run the
quantifier with quantification.md's completed-discovery-iteration preference and use the
printed token:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/iteration-dir.cjs" current process-discovery --complete --artifacts
```

Exit `0` → `<QUANT_INPUT>` is the printed path. Exit `3` → no completed discovery iteration
exists; `<QUANT_INPUT>` is the directory holding `<PHASE_FILE>`. Then quantify over it:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/quantify.cjs" "<QUANT_INPUT>" |
  node ".github/skills/process-os-bpmn-generation/scripts/strip-bom.cjs" |
  node -e "const j=JSON.parse(require('fs').readFileSync(0,'utf8'));process.stdout.write(j.width.size.toLowerCase())"
```

A width derived here is automatic: treat WIDTH_SOURCE as `auto`.

This section is the **authoritative annotation policy**. Step 2 below describes Implementation/Manual/Evaluates/etc. annotations with phrases like "always required" — those describe the **width=L baseline**. The table here overrides them per width.

### Rendering rules by width

**Only an explicit width reduces the diagram.** When WIDTH_SOURCE is `auto`, the **Element count
target**, **Gateway policy** and **Sub-bullet handling** rows use the L column for element count
and gateways and the XL column for sub-bullets — every documented step becomes its own element,
every `[XOR]` a gateway, and a sub-bullet describing distinct work its own task — whatever width
was computed. The computed width still selects the **Annotation policy** column and layout density.
Only an explicit S or M width may select or fold steps.

| Aspect | S | M | L | XL |
|--------|---|---|---|-----|
| **Element count target** | ~5 elements: start → 3–4 tasks → end | ~8–12 elements | every step → its own task | every step + sub-bullets that warrant it |
| **Gateway policy** | none unless decision is the entire point of the phase | major decisions only | every `[XOR]` → gateway | every gateway + business-rule tasks before XOR |
| **Annotation policy** | only `Triggered by:` (start) and `Follow-up:` (end). No `Implementation:`, `Manual:`, `❓`, `Evaluates:`. | `Implementation:` on user/service/abstract/business-rule tasks (NOT on regular gateways or events); `Evaluates: <field>` one-liner on every `<bpmn:exclusiveGateway>`; `Manual:` on user tasks; `Triggered by:` (start); `Follow-up:` (end); suppress `❓` | all annotation types incl. `❓` on every element | full annotations + verbose detail (field-level) |
| **Sub-bullet handling** | folded into parent task | folded into parent task | folded into parent task | promoted to own task where they describe distinct work |

Connector resolution applies at all widths.

### Width=S — selecting which 4–5 tasks survive

Applies only when WIDTH_SOURCE is `explicit`.

1. **Heuristic ranking** (deterministic shortlist):
   - Type weight: user task = 3, service task = 2, generic task = 1
   - Proximity to gateway: +1
   - Has `[GAP]` or `[MANUAL]` marker: +1
   - Sort steps descending; top 6 form the shortlist.

2. **Pass shortlist + full file content to LLM:**
   > "Here are the top-6 ranked steps from `<file>`. Generate 4–5 tasks that capture this phase's essence. Preserve element type: `[ServiceTask]` / `[CHANGED]` / system-only → `<bpmn:serviceTask>`; `[UserTask]` / `[ManualTask]` → `<bpmn:userTask>`; otherwise → `<bpmn:task>`. Connector resolution applies to all service tasks. You may overrule the shortlist if a different summarization is more faithful. Names: verb + object, sentence case."

3. The LLM may overrule the shortlist — synthesize task names rather than extract verbatim.

4. **End events:** at width=S, multi-end-state phases collapse to one generically-named end event (e.g. `Quote handled`).

### Width=XL — selecting which sub-bullets get promoted to tasks

Two rules, Y dominates:

- **Y. Marker-driven (always promote):** sub-bullets explicitly marked `[AUTO]`, `[ServiceTask]`, `[UserTask]`, etc. are always promoted.
- **X. Heuristic fill-in (promote if both):** unmarked sub-bullets are promoted only with verb-object pattern AND a system reference. "DealHub syncs OLI fields to SFDC" qualifies; "default 2 years" doesn't.

Width=XL also adds:
- A `<bpmn:businessRuleTask>` before any `<bpmn:exclusiveGateway>` whose decision data is not directly available (per Step 2b XOR data requirements).
- Verbose `Implementation:` annotations including field-level detail.

## Step 1b: Publish phase plan and todo list

After reading the phase file, before writing XML:

**1. Count elements identified in Step 1:** start events, tasks, gateways, end events, annotations, clarifications.

**2. Print phase overview:**

```
Phase: <Phase Title>
Input:  <PHASE_FILE>
Output: <OUTPUT_BPMN>
Elements: 1 start event · N tasks · M gateways · P end events
Annotations: Q elements will carry text annotations
Clarifications: R open questions flagged as ❓ annotations
```

**3. TodoWrite tracker** — `map` starts `in_progress` (Step 2 begins immediately):

```json
{
  "todos": [
    { "id": "map",    "content": "Map elements + read mode guide",        "status": "in_progress", "priority": "high" },
    { "id": "script", "content": "Write + run bpmnkit script",            "status": "todo",        "priority": "high" },
    { "id": "lint",   "content": "Resolve lint hook findings (fix script)","status": "todo",       "priority": "medium" }
  ]
}
```

After every step boundary below, advance the relevant todo via TodoRead/TodoWrite.

## Step 2: Map elements

Map each phase-file marker to a bpmnkit builder call (the BPMN element it produces is
shown for reference). bpmnkit has **no plain `.task()` method** — pick the closest
typed task: human/manual steps → `.userTask(id,{name})` (emits a plain `<bpmn:userTask>`,
no Zeebe); system/automated steps and generic-no-marker steps → `.serviceTask(id,{name,taskType})`;
an abstract/undefined step → `.task(id,{name})` (plain `<bpmn:task>`, no Zeebe).
Note `.serviceTask` always emits a `<zeebe:taskDefinition>` (taskType is required) — in
**strategic** mode the post-export step strips it (Step 3); in **automatable** mode it
stays. Other tasks: `.businessRuleTask`, `.scriptTask`, `.sendTask`, `.receiveTask`,
`.callActivity`, `.subProcess`/`.adHocSubProcess`. Exclusive gateway → `.exclusiveGateway`
+ `.branch(name, b => b.condition("=...")/.defaultFlow().connectTo(id))`; parallel →
`.parallelGateway` fork/join; start/end → `.startEvent`/`.endEvent`; boundary →
`.boundaryEvent(id,{attachedTo,...})`. Named event refs (`signalName`/`messageName`/
`escalationCode`/`errorCode` on events) emit their root `<bpmn:signal/message/error/escalation>`
declarations automatically. Compensation → `.withBoundary(id,{compensation:true},h=>…)` +
`isForCompensation:true` on the handler. Event sub-process → `.eventSubProcess(id, b=>
b.startEvent({timerDuration,isInterrupting:false})…)` → `<bpmn:subProcess triggeredByEvent>`.
Text annotations → `.annotate("<element id>", "<text>")` builder calls (Step 3).

| Phase file marker | BPMN element | XML tag |
|------------------|-------------|---------|
| `[UserTask]` or human actor | User Task | `<bpmn:userTask>` |
| `[ServiceTask]`, `[CHANGED]`, system-only | Service Task | `<bpmn:serviceTask>` |
| `[ManualTask]` or physical step | User Task | `<bpmn:userTask>` |
| `[Connector:<id>]` | Bound to Camunda Connector Element Template `<id>` | `<bpmn:serviceTask>` (or matching event element) with connector attributes |
| Generic step (no marker) | Abstract Task | `<bpmn:task>` |
| Decision / condition | Exclusive Gateway | `<bpmn:exclusiveGateway>` |
| Deriving/evaluating decision data before a gateway | Business Rule Task | `<bpmn:businessRuleTask>` |
| Phase trigger | Start Event | `<bpmn:startEvent>` |
| Normal terminal outcome | End Event | `<bpmn:endEvent>` |
| Exceptional terminal outcome (error, failure, timeout, cancellation) | Error End Event | `<bpmn:endEvent>` with `<bpmn:errorEventDefinition>` |
| Communication with a known receiver | Message Event | start/intermediate/end with `<bpmn:messageEventDefinition>` |
| Broadcast with no known receiver | Signal Event | start/intermediate/end with `<bpmn:signalEventDefinition>` |
| Async step (fire and wait for callback) | Message Send + Catch | `<bpmn:intermediateThrowEvent>` (msg) → `<bpmn:intermediateCatchEvent>` (msg) |
| Waiting for a point in time or duration | Timer Intermediate Catch | `<bpmn:intermediateCatchEvent>` with `<bpmn:timerEventDefinition>` |
| Waiting for whichever of several events | Event-based Gateway + catch events | `<bpmn:eventBasedGateway>` → one catch event per branch |
| Steps sharing `**Parallel group:**` value, **or** a `[AND-Gateway]` split+join pair (Parallel Split/Join; syn. `[ParallelGateway]`) | Parallel split → branches (steps or streams) → parallel join | `<bpmn:parallelGateway>` × 2 + tasks |
| Step detail / note / constraint | Text Annotation | `<bpmn:textAnnotation>` + `<bpmn:association>` |

### Verdict-derived markers — `**Recommendation:**` / `**Optimized type:**` (transformation-tier `.md` inputs)

A transformation iteration's phase `.md` files (written by `tier-verdicts-to-phase-docs.cjs` for
radical/moonshot, or directly by `phase-agent.md`/incremental synthesis) use a second marker shape
alongside the inline `[UserTask]`-style headings above: a `**Recommendation:** [MARKER]` /
`**Optimized type:** <type>` pair per step, plus disposition sub-bullets (`- Manual:`, `- Origin:`,
`- Confidence:`, `- Tools:`, `- Goal:`, `- API:`, `- Note:`). Map them like this:

| `**Recommendation:**` | `**Optimized type:**` | BPMN element | Notes |
|---|---|---|---|
| `[CHANGED]` | `ServiceTask` | Service Task | connector via `references/connectors.md` (automatable) if the `- API:` sub-bullet names one |
| `[CHANGED]` | `BusinessRuleTask` | Business Rule Task | `<bpmn:businessRuleTask>`; the `- DMN:` sub-bullet names the decision — carry it into the element's `Implementation:` annotation |
| `[CHANGED]` | `AI ServiceTask` | AI Agent ad-hoc sub-process | never a UserTask — see "AI Agent routing" below |
| `[CHANGED]` | `AI Co-Pilot` | AI Agent ad-hoc sub-process + confidence gateway + UserTask | see "AI Co-Pilot pattern" below |
| `[RETAINED]` | `UserTask` (or a baseline type, if unclassified) | `<bpmn:userTask>` (or the baseline type) | `Manual:` + `Origin: retained-as-is` from sub-bullets; unclassified steps also carry the `- ❓ Not in verdicts — confirm disposition` bullet as a `❓` annotation |
| `[NEW]` | `UserTask` | `<bpmn:userTask>` | `Manual:` + `Origin: new-by-transformation` from sub-bullets |
| `[REMOVED]` | `—` | no element | the step disappears from the flow; if its `- Note:` explains a variable pre-population or gateway fold-in, add that note as a `❓`-free annotation on the nearest surviving element, not a dangling comment |

Keep width policy intact for all of the above: the co-pilot subgraph and AI agents are emitted **at
every width** — they encode disposition (a human step was eliminated, or an agent now performs the
work), not level of detail. Width still governs how verbose the surrounding annotations are, per
Step 1a.

#### AI Co-Pilot pattern (`ai-copilot` verdict — ported verbatim from `bpmn-agent.md` Step 4)

One dedicated AI Agent ad-hoc sub-process **per** co-pilot UserTask — never share one agent across
multiple `ai-copilot` steps. Structure, in bpmnkit builder calls (flatten to the top level per
bpmnkit.md's branch-nesting limitation — do not nest the gateway inside a `.branch()` lambda):

```javascript
.adHocSubProcess("AIAgent_<TaskID>", agent.content, { name: "<Agent Name>" })
.exclusiveGateway("Gateway_<TaskID>_Confidence", { name: "" })
.branch("high", b => b.condition("= confidenceScore >= 0.8").connectTo("Gateway_<TaskID>_Join"))
.branch("low",  b => b.defaultFlow().userTask("UserTask_<TaskID>", { name: "<UserTask name>" }).connectTo("Gateway_<TaskID>_Join"))
.exclusiveGateway("Gateway_<TaskID>_Join", { name: "" })
```

- **High-confidence branch** (`condition("= confidenceScore >= <threshold>")`) goes straight to the
  join — this is the standard path that **bypasses** the UserTask.
- **Low-confidence branch** is the gateway's `.defaultFlow()` and routes through
  `.userTask("UserTask_<TaskID>", …)` before the join — this is the exception path.
- `<threshold>` is the step's `- Confidence:` sub-bullet, default `0.8` if absent. **Normalize
  before writing the FEEL condition**: the sub-bullet may read as a percentage (`80%`) or a bare
  fraction (`0.8`) — a percentage divides by 100 (`80%` → `0.8`). Writing `>= 80` instead of
  `>= 0.8` sends every case down the low-confidence branch.
- **`AIAgent_<TaskID>` is a `.adHocSubProcess(id, content, options)` builder call whose content
  callback comes from `buildAiAgentSubProcess()`**, so auto-layout produces the nested DI — no
  hand-written tool XML and no hand-computed `dc:Bounds`. Follow [the AI Agent generation
  workflow](ai-in-bpmn.md) for the tool specs, why only `agent.content` is used,
  and the `--set` properties. **Lay a phase containing an ad-hoc sub-process out with `BPMN_LAYOUT=bpmnkit`,
  not the bpmn-io primary** — bpmn-io mis-sizes the container and places the tool shapes outside it,
  and `bpmn-di-check.cjs` does not catch it. Then bind the AI Agent template with `c8ctl
  element-template apply`; it preserves the tool subtree and its DI, so there is no post-apply tool
  patch. Never hand-write or replace the AI Agent's template-owned `zeebe:adHoc`, `ioMapping`, task
  headers, task definition, template attributes, or icon. In strategic mode, do not apply the
  template; the bpmnkit subprocess shape remains but the strategic `<bpmn:extensionElements>` strip
  removes Zeebe wiring as it does for every other element.
- **`.annotate("UserTask_<TaskID>", …)`**: `Manual: <judgment reason> | AI assists: <what the
  preceding AIAgent_<TaskID> produced> | Origin: ai-copilot`. Draw the reason and the AI-assists
  text from the step's `- Manual:` sub-bullet and `- Confidence:` context.
- **Mandatory `.annotate("Gateway_<TaskID>_Confidence", …)`** — this is the *only* place in the
  diagram where a viewer can tell a human step was eliminated on the standard path. Four lines,
  exactly this shape:
  ```
  Replaces: [original as-is task name] ([task ID, if the caller supplied one])
  Standard path (confidenceScore >= 0.8): AI auto-completes — [UserTask name] bypassed
  Exception path (confidenceScore < 0.8): [UserTask name] — human reviews AI draft
  AI provides: [one-line summary of what the AI Agent produced]
  ```
  A flattened transformation-iteration phase-doc step has no separate task-ID field — its `## Step N:
  <name>` heading is the only identifier available, so `[original as-is task name]` and `[task
  ID]` collapse to the same string; drop the parenthetical rather than inventing an ID. Never skip
  this annotation, at any width.

#### AI Agent routing (`ai-agent` / `ai-orchestration` verdicts)

Route explicitly to the AI-Agent ad-hoc sub-process path (`ai-in-bpmn.md`), one sub-process per
task — **never** a UserTask, regardless of width. Populate it from the step's sub-bullets:

- **Tool activities** — one tool per entry in the `- Tools:` sub-bullet (comma-separated endpoint
  list). Each becomes a `Tool_<Action>` service task nested inside the sub-process per the
  `ai-in-bpmn.md` template (no `bpmn:incoming` element — tools are root nodes).
- **System prompt** — the `- Goal:` sub-bullet (or the `- AI task:` / `- AI orchestration:`
  sub-bullet when `- Goal:` is absent) becomes `data.systemPrompt.prompt`.
- **Hard constraint (`ai-in-bpmn.md`): a valid agent needs ≥1 tool.** If `- Tools:` is empty or
  reads "none specified", do **not** emit an empty sub-process (undeployable) — emit a `❓ No
  tools specified for this AI agent — confirm the API endpoints it should call` text annotation on
  the sub-process instead, and still build the surrounding flow so the gap is visible in the
  diagram rather than silently dropped. **This `❓` is exempt from Step 1a's width-conditional `❓`
  suppression at S/M** — the general annotation-verbosity policy governs advisory clarifications,
  but this one flags an undeployable sub-process (zero tools violates `ai-in-bpmn.md`'s hard
  constraint), not a documentation gap. Emit it at every width, same as the mandatory gateway
  annotation above.

#### `Origin:` annotation vocabulary

`retained-as-is` / `new-by-transformation` / `ai-copilot` are the three recognized `Origin:` values
carried on `<bpmn:userTask>` annotations, distinguishing why a UserTask exists in the generated
diagram:

| `Origin:` value | Meaning | Written by |
|---|---|---|
| `retained-as-is` | human step existed in the as-is process and was not automated | `[RETAINED]` steps (`legally-mandated` / `low-ai` / `retained` verdicts, and unclassified steps) |
| `new-by-transformation` | human step did **not** exist in the as-is process — introduced as an exception handler, error-path fallback, or similar | `[NEW]` steps |
| `ai-copilot` | human step was retained but an AI Agent now does most of the work — see the co-pilot pattern above | `ai-copilot` verdict |

The step's `- Origin:` sub-bullet is authoritative — carry it verbatim into the `.annotate(...)`
text (appended after the `Manual:` reason, and after `AI assists:` for the co-pilot case). Never
omit it: it is what lets a reviewer distinguish the proposal's "retained" count from the BPMN's
actual `<bpmn:userTask>` count.

### Annotation rules (width-conditional — see Step 1a table for the override)

**`Implementation:` annotation**

- **L / XL**: every element. If no detail, use `❓ Implementation details unknown — what system or mechanism handles this step?`.
- **M**: only on user/service/abstract/business-rule tasks. **Skip events.** Gateways instead get `Evaluates:` per Step 2b's XOR rule (separate annotation type, not `Implementation:`).
- **S**: skip entirely.

When emitted: `Implementation: <details>` (e.g. `Implementation: POST /orders API; requires order_id and customer_id; response stored in process variable order_status`). Draw from the phase file (sub-bullets, system references, fields, APIs, integration points, technical constraints).

**System names in annotations:** always use the business common name (`Salesforce`, `SAP S/4HANA`, `ServiceNow`). Never substitute `the CRM`, `the ERP`, `system A`, `the backend`. Genuinely unknown → `❓ [unknown system]`, never invent.

**Other contextual detail:** also annotate when the phase file gives detail beyond the name — sub-bullets, timing ("within 24h"), responsible team, caveats. Combine with Implementation when both apply.

**`Manual:` annotation on `<bpmn:userTask>`**

- **L / XL / M**: required on every user task. At L/XL, fall back to `❓ Why can this step not be automated?` if no clear reason; at M, omit rather than guess.
- **S**: skip.

Format: `Manual: <reason>` (e.g. `Manual: Requires manager sign-off per policy`). Specific reason — judgment, legal sign-off, physical action, customer interaction, exception handling.

**`Triggered by:` on start events** — required at all widths (when source known): `Triggered by: <SourceSystem>`. Source unknown → omit, don't guess.

**`Follow-up:` on end events** — required at all widths (when documented): `Follow-up: <action 1>; <action 2>; …`. Not documented → omit, don't guess.

### Connectors (automatable mode only)

If `MODE=automatable` and a service task represents a known integration, bind the connector
via `references/connectors.md`
(`c8ctl element-template apply -i <id> <ElementId> <OUTPUT_BPMN> --set ...`). Emit
`connector_resolved` after the apply. Strategic mode skips this entirely.

**Apply connectors as a SEPARATE Bash step, AFTER the whole layout orchestrator
completes** — never before it and never folded into it. The command's first step is
`node <gen>.mjs`, which rewrites `OUTPUT_BPMN` from a builder that has **no** connector
bindings, so any `apply` done earlier is overwritten (and the bpmnkit-fallback branch runs
`<gen>.mjs` a second time). `c8ctl apply` only edits the element's semantic + Zeebe
extensions; it preserves the DI the layout command produced. **In the fix-loop, every
re-run of the layout command wipes the bindings — re-apply all connectors afterward.** The
PostToolUse lint hook fires on the `*element-template*` token of the apply call, so it
re-lints the connector-bound file under the executable profile.

### Naming conventions

| Element | Pattern | Example |
|---------|---------|---------|
| Start event | Object + past participle (state) | `Quote requested`, `Invoice received` |
| End event (normal) | Business state reached | `Quote sent`, `Quote rejected`, `Invoice paid` |
| Error end event | Business failure state | `Quote processing failed`, `Payment error` |
| Task | Verb (infinitive) + Object | `Approve invoice`, `Send notification`, `Prepare quote` |
| Subprocess / Call Activity | Object + nominalized verb | `Invoice approval`, `Order processing` |
| Exclusive gateway | Closed question ending in `?` | `Quote approved?`, `Invoice valid?` |
| Outgoing branch (exclusive) | Direct answer to gateway question | `Yes` / `No`, `Approved` / `Rejected` |
| Joining gateway (exclusive) | No label | — |
| Parallel gateway (split or join) | No label | — |

**Gateway preference rule — never use complex gateways:**
Only use `<bpmn:exclusiveGateway>` and `<bpmn:parallelGateway>` (and `<bpmn:eventBasedGateway>` for wait states). Never use `<bpmn:complexGateway>`. Complex gateways are valid BPMN but are consistently misread by human reviewers — the activation condition is invisible in the diagram and requires reading the XML to understand. Any logic that a complex gateway would express can always be decomposed into a combination of exclusive and parallel gateways, which remain readable. If you find yourself reaching for a complex gateway, decompose the branching condition explicitly instead.

**Naming rules:**

- Sentence case (`Send quote to customer`, not `Send Quote To Customer`).
- **Business language only** — no system names, API names, technical verbs, class names, or implementation details in element names. Wrong: `POST invoice to SAP`, `Call CRM API`, `Update order_status flag`. Correct: `Send invoice`, `Retrieve customer data`, `Update order status`. Implementation details belong exclusively in the `Implementation:` annotation.
- No abbreviations unless explained inline.
- Avoid vague verbs: `Handle`, `Process`, `Manage`. Be specific.

Element **ids**: see "ID conventions" at the end of this file.

## Step 2b: Apply Camunda Modeling Best Practices

Read `references/modeling-best-practices.md` and follow it. That sub-skill covers:

- Best-practice checklist (readability, naming, IDs, happy-path beyond, situation patterns, flexibility, DMN hit policy)
- Logical correctness pre-flight (no temporal language in task names; no "wait for X or timeout" as a task; escalation interruption paths; no dead-end branches)
- Child process start/end events (none events)
- XOR gateway data requirements (width-conditional `Evaluates:` annotation)
- Signal vs message events
- Waiting states (timer + event-based gateway)
- Temporal language detection
- Time-based escalation with payment/response interruption
- Parallel gateways
- Async patterns (message send/catch)
- Error end events and boundary catch events
- Human task orchestration (multiple user tasks)
- Structural rules (remove unnecessary gateways, multiple in/out flows, gateway side assignment)
- Clarification annotations

If any check reveals a modeling issue, fix the planned model before proceeding to Step 3.

After Step 2 + Step 2b: TodoRead → set `script` `in_progress` → TodoWrite.

## Step 3: Write and run the bpmnkit script

For gateway/event/editing patterns, the post-export fixes, and a complete runnable
script beyond the width=L example below, read
`references/bpmnkit.md` (the recipe companion).

Write a script to `<OUTPUT_BPMN>.gen.mjs` (next to the output) and run it. The script:

1. Builds the flow with the fluent API in document order.
2. Attaches annotations with `.annotate("<exact element id>", "<text>")` — one per element
   that warrants one (per the width policy in Step 1a). Use the **exact element id** you
   gave the builder call.
3. Calls `.executable(false)` for `MODE=strategic`, `.executable(true)` for automatable.
4. `.executionPlatformVersion("8.9.0")`, then a `BPMN_LAYOUT` toggle for the final build:
   `process.env.BPMN_LAYOUT === "bpmnkit" ? builder.withAutoLayout().build() : builder.build()`.
   Layout itself is selected by the run command (bpmnkit's `.withAutoLayout()` scaffold, then
   bpmn-io), not here.
5. `Bpmn.export(defs)` → post-export fixes (next block, automatable/strategic only) → write `OUTPUT_BPMN`.

### Worked script

Use the copy-ready `<OUTPUT_BPMN>.gen.mjs` template in `bpmnkit.md` → **"Minimal end-to-end
runnable script"** (already required reading per the top of this step). It shows the exact
builder chain, the inline-`.endEvent()` branch idiom, the `.annotate(...)` calls, the
`.executable(false)`/`true` + `isExecutable` rule, the `BPMN_LAYOUT` toggle, and the strategic
Zeebe-strip — i.e. steps 1–5 above made concrete. Adapt names/ids to this phase; do not copy a
second full script in here.

Run the **layout orchestrator** (emit `script_run` after it returns):

```bash
node ".github/skills/process-os-bpmn-generation/scripts/layout-bpmn.cjs" "<OUTPUT_BPMN>.gen.mjs" "<OUTPUT_BPMN>"
```

How it reads (no `NODE_PATH` — bpmnkit is imported by project-relative path):

1. `node <gen>.mjs` first builds the bpmnkit `.withAutoLayout()` scaffold
   (`BPMN_LAYOUT=bpmnkit`).
2. **Final layout — bpmn-io:** `bpmn-auto-layout.cjs` refines the scaffold's semantic flow,
   collaboration, artifact, annotation, and edge geometry, then `bpmn-di-check.cjs`
   asserts DI is complete. The bpmn-io output is preserved as produced.
3. **Automatic recovery — bpmnkit:** if bpmn-io layout throws or the DI check rejects its
   output, the orchestrator restores the `.withAutoLayout()` scaffold, checks it, then applies
   `bpmn-node-placement.cjs` and `bpmn-edge-cleanup.cjs` in that order before a final DI check.
   An incomplete recovery fails rather than shipping silently.
4. **Scaffold failure contingency:** if bpmnkit cannot generate the initial scaffold, the
   orchestrator rebuilds without `BPMN_LAYOUT` and gives bpmn-io one direct attempt. A failure
   there is terminal because there is no usable bpmnkit baseline to repair.

The PostToolUse lint hook fires on the `*.bpmn.gen.mjs` token and lints the final
`OUTPUT_BPMN` regardless of which engine ran.

### Post-export fixes

On `@bpmnkit/core` ≥ 0.0.25 the only post-export string fixes are the two Zeebe cases
(automatable: inject `<zeebe:userTask />`; strategic: strip `<bpmn:extensionElements>`, keeping a call activity's `zeebe:calledElement`). The
exact regexes and rationale are in `bpmnkit.md` → **"Post-export fixes"** — apply them there
rather than duplicating them here. (Prefer `.task()` over `.serviceTask()` for a strategic
abstract step so there is nothing to strip.)

### Fixing lint problems — edit the script, not the XML

The PostToolUse lint hook (shipped with the bundle) lints `OUTPUT_BPMN` after the `node` run and
surfaces problems. **Fix them by editing `<OUTPUT_BPMN>.gen.mjs` and
re-running the full sequence**, never by hand-editing the BPMN.

**The fix-loop unit** (every iteration):

1. Edit `<OUTPUT_BPMN>.gen.mjs`.
2. Re-run the **same layout orchestrator** — it rewrites `OUTPUT_BPMN` from scratch,
   preserving bpmn-io output or applying the bpmnkit fallback cleanup:
   ```bash
   node ".github/skills/process-os-bpmn-generation/scripts/layout-bpmn.cjs" "<OUTPUT_BPMN>.gen.mjs" "<OUTPUT_BPMN>"
   ```
3. The PostToolUse lint hook re-lints automatically on that command — read its findings.

**Keep `.gen.mjs` — do not delete it.** The orchestrator's centralized lint gate may route
findings back to you to fix via this script, and it stays in `OUTPUT_DIR` permanently
alongside the `.bpmn` it produced — it is never deleted, before or after every file passes
(see Step 4).

After running the generator: TodoRead → set `map`, `script` `completed`; `lint`
`in_progress` → TodoWrite.

## Step 4: Lint (hook fast-path) — keep the generator script

**Linting via the PostToolUse hook is a fast-path, not a guarantee.** When active, the
hook lints `OUTPUT_BPMN` right after the generator run (and after any `c8ctl
element-template apply`), calling the lint binaries directly and profiling by
`isExecutable`: non-executable/strategic → structural bpmnlint (`bpmnlint:recommended` +
`plugin:process-os/recommended`); executable/automatable → `process-os-camunda-compatibility-check/scripts/validate.cjs`.

**But the hook does not fire in every context** — notably it may not fire for **subagent**
tool calls (which is how you are running), and it is absent when the plugin's hooks aren't
active for the session (dev/worktree/eval/CI, or a mid-session install/update). **So
seeing no findings does NOT mean your file is clean — do not declare it clean on hook
silence.** The orchestrator runs an authoritative centralized lint gate after all phase
subagents return and will route any missed findings back to you.

**If the hook DOES surface findings, resolve them with Step 3's fix-loop unit** — edit
`<OUTPUT_BPMN>.gen.mjs`, re-run the generator + cleanup chain (the hook re-lints
automatically). Never hand-edit the BPMN.

**Do NOT delete `<OUTPUT_BPMN>.gen.mjs`.** The centralized gate (SKILL.md "GATE:
Centralized lint") may route findings back to you, and the fix-loop needs the `.gen.mjs`
to still exist. It is kept permanently as the bpmnkit source for `OUTPUT_BPMN` — the
orchestrator never deletes it, even once the gate confirms every file is clean.

TodoRead → set `lint` `completed` → TodoWrite. (Leave the `.gen.mjs` in place.)

## Finalize timing

Last action of this skill — after lint reports clean and the todo list is updated:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/timing.cjs" --dir "<TIMING_DIR>" end "<BASENAME>"
```

Stamps `end_ms` / `duration_ms` and finalizes per-event counters in `<TIMING_DIR>/<BASENAME>.json`. The orchestrator's aggregation step in `SKILL.md` reads every closed record in that versioned directory.

## ID conventions

Ids passed to the bpmnkit builder calls (also the handle for `.annotate(…)`, `.element(…)`,
`attachedTo:`, `connectTo(…)`).

Process id: for `subprocess-*.md`, use the exact `**Process ID:**` from the source document.
For every other source, derive it from the filename → PascalCase + `Process` suffix (e.g.
`process-01-quoting.md` → `Process01QuotingProcess`).

### Element ID prefixes (PascalCase)

| Element | Prefix | Example |
|---------|--------|---------|
| Process | (no prefix, `Process` suffix) | `Process01QuotingProcess` |
| Start event | `StartEvent_` | `StartEvent_QuoteRequested` |
| Task / UserTask / ServiceTask | `Task_` | `Task_PrepareQuote` |
| Exclusive gateway | `Gateway_` | `Gateway_QuoteApproved` |
| Parallel gateway (split or join) | `ParallelGateway_` | `ParallelGateway_Split_1`, `ParallelGateway_Join_1` |
| End event | `EndEvent_` | `EndEvent_QuoteSent`, `EndEvent_QuoteRejected` |
| Conditional sequence flow | `SequenceFlow_` | `SequenceFlow_QuoteApprovedYes` |
| Unconditional sequence flow | `Flow_` | `Flow_StartToTask` |
| Text annotation | `TextAnnotation_` | `TextAnnotation_PrepareQuote` |
| Association | `Association_` | `Association_PrepareQuote` |

Shape DI ids are generated (`_di` suffix, e.g. `StartEvent_QuoteRequested_di`) — never author DI by hand.
