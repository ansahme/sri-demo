# Automatable modeling guide

Use when `MODE=automatable`. The output leans toward execution: it is intended as a
starting point an engineer can wire up on Camunda 8. Built with `.executable(true)`.

## What this mode adds over strategic

- **User tasks** are Camunda (Zeebe) user tasks: inject `<zeebe:userTask />` in the
  post-export step (bpmnkit omits it — see generate-phase.md "Post-export fixes").
  A linked form (`formId`) makes `<form>` a deliverable — flag it, don't invent it.
- **Service tasks backed by a known integration** → resolve a connector via
  `references/connectors.md` (`c8ctl element-template apply`). Otherwise leave an
  abstract `bpmn:serviceTask` with a `taskType` and an `Implementation:` annotation.
- **Gateway conditions** use FEEL with the `=` prefix on the bpmnkit `.condition()`
  call (e.g. `.condition("=approved")`); mark the happy path with `.defaultFlow()`.
- **Business-rule tasks** that evaluate a decision reference a DMN via the
  `decisionId` option (the `.dmn` becomes a deliverable — flag it).
- **AI steps — decide here; open `ai-in-bpmn.md` ONLY to *build* an ad-hoc sub-process.**
  Emit a `bpmn:adHocSubProcess` (AI Agent connector) only when the step needs **dynamic tool
  selection**, **2+ API calls with decision logic between them**, or explicit **agentic**
  behaviour. A **single bounded model call** (one extraction / classification / draft, fixed
  params) → a plain `bpmn:serviceTask` bound to the AI connector (e.g. Bedrock). A rule-based
  decision over known variables → exclusive gateway or DMN. Only when this rule resolves to an
  ad-hoc sub-process, read `ai-in-bpmn.md` for the build guide (hard constraints,
  XML template, tool/`fromAi()` modelling); otherwise skip it (it is ~5k tokens of
  construction detail you don't need for a service task).

## Still business-named

Element names stay business language even here — execution detail lives in Zeebe
extensions and annotations, never in names (same naming rules as generate-phase.md).

## Lint profile

Automatable files (`isExecutable=true`) are linted by `process-os-camunda-compatibility-check`
(Camunda 8.9: `bpmnlint:recommended` + camunda-cloud-8-9 compat + process-os custom
rules) via the PostToolUse hook — fix every **error** by editing the generator
script (or the `c8ctl element-template apply` call), then re-run; never hand-edit the XML.

**Expected (accepted) warnings — do NOT chase these to zero by inventing artifacts:**

- `UserTask must have one extension element of type <zeebe:FormDefinition>` — a form is a
  separate flagged deliverable (`flag it, don't invent it` above). A user task without a
  `formId` warns; that is correct generate output, not a defect.
- `Message … is unused` / `name is not unique` after a `c8ctl element-template apply` on a
  message **event/receive task** — the connector handler emits its own `<bpmn:message>` and
  may orphan the builder's. Cosmetic; the file still deploys. Leave it.

These are the only warnings you may ship. Every **error**, and every other warning, must be
fixed via the generator/apply, not accepted.
