# Strategic modeling guide

Use when `MODE=strategic`. The output is a **business-altitude** BPMN: a reader in
a process workshop understands it without engineering knowledge. It is valid
Camunda 8 BPMN (`modeler:executionPlatform="Camunda Cloud"`, version 8.9.0) but
**never executable** — `isExecutable=false`, and no Zeebe extensions beyond a call activity's
`zeebe:calledElement`.

## Hard rules

- Build with `.executable(false)` (bpmnkit then omits the `isExecutable` attribute
  entirely — correct; BPMN's default is non-executable).
- **No** `zeebe:*` elements in the output except a call activity's `zeebe:calledElement`.
  bpmnkit's `.serviceTask({taskType})`
  unavoidably emits a `<zeebe:taskDefinition>`, so generate-phase Step 3's post-export
  **strips every `<bpmn:extensionElements>` block except a call activity's
  `zeebe:calledElement`** — that is what keeps strategic output Zeebe-free (no
  `taskDefinition`, `ioMapping`, `userTask`, `formDefinition`,
  `calledDecision`, `modelerTemplate`, connectors, or AI-Agent ad-hoc subprocesses). The
  `xmlns:zeebe` namespace declaration may remain; it is harmless.
- **No connector resolution** — system steps are plain `<bpmn:serviceTask>` (after the
  strip), human steps plain `<bpmn:userTask>`, each with a business name and an
  `Implementation:`/`Manual:` annotation. bpmnkit has no plain `.task()` builder method,
  so a generic step uses `.serviceTask` (system-ish) or `.userTask` (human).
- Gateways: exclusive + parallel only (per the existing gateway-preference rule).

## Altitude rules (what makes it *strategic*)

- Element names are business outcomes, not system actions: "Approve invoice", not
  "POST /invoices". System/API/field detail goes **only** in annotations, never names.
- Every documented step keeps its own element — the width rules decide granularity, and
  strategic mode adds no folding of its own. Structural elements such as subprocesses, call
  activities, ad-hoc subprocesses, and boundary/event-subprocess constructs (cancellation,
  reminder, error + compensation, housekeeping) must still be modeled as their real BPMN
  element types — never flattened into a plain task with an annotation describing what it
  "would" be. Only the *execution* detail inside them (Zeebe wiring, connector config) is
  stripped; the structural shape is not.
- Annotations describe *what the business does and why*, not *how a system does it*:
  `Manual:`, `Triggered by:`, `Follow-up:`, and a business-phrased `Implementation:`
  (e.g. "Handled in Salesforce by the sales rep") — keep API/field specifics out.
- Use `❓` annotations for genuine open business questions, not missing tech detail.

## Annotation policy

Follow the width table in generate-phase.md Step 1a unchanged — strategic mode does
not alter *how many* annotations, only their *altitude* (business, not technical).
