# Phase generation — conditional fallbacks

Read this **only when** a trigger below applies. Keeping it out of `generate-phase.md` keeps
the normal generation path lean (it is read by every phase).

## Using `REF_BPMN` (only when `REF_BPMN != none`)

`REF_BPMN` is a same-basename `*.bpmn` sitting next to the `PHASE_FILE` markdown (the "both
kinds present" input case). It is **supplementary reference**, not the source of truth:

- Read it after the `PHASE_FILE`. Prefer its element **names** where they match the markdown,
  keep its **structure** and any **layout** worth preserving, and carry over detail it encodes
  that the markdown omits.
- The `PHASE_FILE` markdown remains authoritative for **what** the model contains — `REF_BPMN`
  enriches, it never overrides. If the diagram and the markdown disagree on which elements
  exist, the markdown wins.
- When editing toward the existing diagram, use the bpmnkit **operations API** (parse →
  `applyBpmnOperations` → export; see [the bpmnkit reference](references/bpmnkit.md)) so existing
  layout is preserved rather than regenerated. Not the `compactify` round-trip — it drops
  annotations and template bindings.

## Layout engines: bpmnkit scaffolds, bpmn-io finishes

The layout orchestrator in `generate-phase.md` first builds a **bpmnkit** DI scaffold
(`.withAutoLayout()`, via `BPMN_LAYOUT=bpmnkit`), then runs **bpmn-io**
(`bpmn-auto-layout.cjs`) to produce the final geometry. You normally do **not** need this doc
for layout — the command self-selects. This section records the *why* and the recovery cases.

**Why bpmnkit scaffolds first.** It establishes complete initial DI, including expanded
event-subprocess structure and annotation associations, before bpmn-io computes its final
geometry. This avoids bpmn-io's fresh-model collapse of an event subprocess whose child has a
parent-level annotation association.

**Why bpmn-io finishes.** On real branchy models, it produces cleaner final geometry than
bpmnkit alone: process-05 had 0 backward edges and about 30% fewer bends than bpmnkit's
standalone layout, which left 2 backward edges and 44 staircase-heavy bends. The bpmnkit
scaffold is therefore input to bpmn-io, not the normal final layout.

**Recovery paths.** If bpmn-io throws or `bpmn-di-check.cjs` rejects its output, the
orchestrator regenerates the bpmnkit scaffold, checks it, then applies
`bpmn-node-placement.cjs` and `bpmn-edge-cleanup.cjs` before checking the final result again.
Those cleanup passes address bpmnkit-only artifacts such as diagonals and backward convergence
subgraphs. If bpmnkit's initial scaffold cannot be generated, the orchestrator instead builds
without `BPMN_LAYOUT` and gives bpmn-io one direct attempt; a failure on that path is terminal
because no usable bpmnkit baseline exists to repair. The guard intentionally validates flow
nodes and sequence flows; it does not make lane-only DI a release blocker.

**Collaborations and call activities.** The bpmn-io layout engine is intended to preserve and lay out
collaboration participants, message flows, and child process planes. Keep the DI guard in the
standard command: any missing flow-node or sequence-flow DI routes bpmn-io to the restored
bpmnkit baseline, and the final guard prevents an incomplete recovery from shipping.
