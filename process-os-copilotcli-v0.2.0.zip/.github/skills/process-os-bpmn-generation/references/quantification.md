# Sub-Skill: Quantification (size control)

Two-axis sizing for the generated BPMN set:

- **width** (X): per-process complexity — how long and branchy a single BPMN is
- **depth** (Y): count + interconnectedness — how many BPMNs and how cross-linked

## CLI flags

| Flag | Controls | Values | Default |
|------|----------|--------|---------|
| `--size` | overall (auto-derived label) | `auto`, `s`, `m`, `l`, `xl` | `auto` |
| `--width` | per-process complexity (X) | `s`, `m`, `l`, `xl` | inherits from `--size` |
| `--depth` | count + interconnectedness (Y) | `s`, `m`, `l`, `xl` | inherits from `--size` |
| `--dry-run` | exit after report | `false`, `true` | `false` |

## Precedence

| Flags passed | Effect |
|--------------|--------|
| nothing | auto on both axes |
| `--size` only | both axes inherit |
| `--size` + `--width` | depth ← size, width explicit |
| `--size` + `--depth` | width ← size, depth explicit |
| `--width` + `--depth` (no `--size`) | both explicit; overall label recomputed |
| **`--size` + `--width` + `--depth`** | **error** — surface conflict, force re-decision |

CLI flag and `run.config.yaml` are both accepted; flag wins. The same
all-three-keys-error rule applies to the config.

```yaml
# run.config.yaml
size: auto       # auto | s | m | l | xl
# width: l       # optional axis override
# depth: l       # optional axis override
```

```bash
node ".github/skills/process-os-bpmn-generation/scripts/read-run-config.cjs" size
node ".github/skills/process-os-bpmn-generation/scripts/read-run-config.cjs" width
node ".github/skills/process-os-bpmn-generation/scripts/read-run-config.cjs" depth
```

`width` and `depth` exit 1 with no output when unset — that is "derive from `size`", not an error.

## Dry-run mode

When `--dry-run=true`, execute through 3b.e (compute and print the report), write a short-form memory + audit entry, exit. **No** BPMN generation, **no** snapshot dir, `state.md` NOT updated.

`.camunda/memory.md` entry:

```markdown
<!-- YYYY-MM-DD (dry-run) -->
- Quantification only — no BPMN generated
- Width A: <S|M|L|XL> (score N.N); B: <S|M|L|XL>; <agreed|surfaced>
- Depth A: <S|M|L|XL> (score N.N); B: <S|M|L|XL>; <agreed|surfaced>
- Resolved width=<S|M|L|XL>, depth=<S|M|L|XL>[ (automatic S)]
```

When B did not run, record `B: skipped`. Append ` (automatic S)` to the depth only when 3b.d2
normalized an automatic S to M, so the record reads `depth=M (automatic S)`; omit it otherwise.

`.camunda/audit.md` entry: `Dry-run quantification → w<W>/d<D>` (table format).

## Run-unattended mode (natural-language detection)

No `--run-unattended` flag. Detect intent by regex-sweeping the user's invocation message (only that message — not referenced files or earlier turns). Set `UNATTENDED=true` if any case-insensitive match:

`run unattended` / `run-unattended` · `don't ask` / `dont ask` / `no questions` / `skip questions` / `skip all prompts` · `just do it` / `just generate` / `just run` · `non-interactive` / `unattended` · `auto-confirm` / `auto confirm` / `confirm everything` · `proceed without asking` / `no prompts`

Ambiguous wording (e.g. "I don't want to wait") does NOT trigger.

When `UNATTENDED=true`, every interactive decision auto-resolves:

| Decision | Default | Run-unattended resolution |
|----------|---------|--------------------------|
| Final confirmation prompt | wait for `[y / abort / change ...]` | proceed immediately |
| A and B agree | lock | (same — no prompt) |
| 1 step apart, axis NOT near-boundary | surface, ask | **pick A** |
| ≥ 2 apart after one rerun, axis NOT near-boundary | surface `[a / b / manual]` | **pick A** |
| Any disagreement, axis IS near-boundary (3b.c) | surface, ask | **pick the larger of A/B** — with nobody present to catch a false-S collapse, err toward preserving fidelity, not toward the cheaper output |
| All-three-flags-error | surface, force re-decision | **still error and abort** |

## Resolution algorithm

```
3b.a. Parse --size / --width / --depth flags AND run.config.yaml keys.
      All three present → ERROR. Apply precedence: flag > config > auto.
3b.b. Run A (counting) via the script (see "A — counting" below) → width_a, depth_a.
3b.c. For each axis where user did NOT pass an explicit override
      AND (a_size != S OR that axis is near-boundary — see below)
      AND --dry-run is NOT set:
        dispatch B sub-agent in parallel. Compare A vs B.
      Under --dry-run, skip B entirely — A (the deterministic script) is
      authoritative for a size check; record `B: skipped`.
      Fast-path (small input): if there are <= 3 phase files total AND neither
      axis is near-boundary, skip B on BOTH axes — A's deterministic count is
      reliable at this scale, and B (an extra sub-agent + round-trip) earns its
      keep only on larger inputs, or borderline ones, where the heuristic might
      misjudge altitude. Record `B: skipped (small input — N files)`.
      Near-boundary override: a small or already-S-bucketed input can still be
      wrong — a handful of files can pack disproportionate structural density
      (many gateways/edges/subprocess-references per file), which is exactly
      the case a 3-file coverage-style fixture with a depth rawScore of 10.5
      surfaced (S's bucket ceiling is 10; 10.5 floors to 10 and silently locks
      S with edge cases demoted to text annotations, even though the fixture
      needed every edge case modeled as a real element). **Near-boundary** =
      the axis's `rawScore` is within 1.5 below the lower bound of the *next*
      bucket up from `a_size` (not any other bucket's bound). Concretely:
      a_size=S → near-boundary if rawScore ≥ 7.5 (width) / ≥ 9.5 (depth);
      a_size=M → rawScore ≥ 17.5 (width) / ≥ 17.5 (depth);
      a_size=L → rawScore ≥ 29.5 (width) / ≥ 27.5 (depth). (XL has no bucket
      above it, so a_size=XL is never near-boundary.) Near-boundary axes always
      dispatch B, overriding both the `a_size == S` lock and the small-input
      fast-path above.
3b.d. Detect run-unattended intent (regex-sweep invocation prompt).
3b.d2. Normalize an automatic depth: when depth is not explicit — no --depth flag or depth key,
      and --size / size absent or `auto` — and resolves to S — from A alone, from the A/B
      comparison, or under --dry-run — it is resolved as M. S's combining, edge-case inlining and
      subprocess abstraction apply only to an explicit depth=S. The report (3b.e), the dry-run
      memory/audit lines (3b.f) and the lock (3b.g) all use the normalized value; the report and
      memory keep `Depth A: S` as the raw recommendation and show `resolved depth=M (automatic S)`.
3b.e. Build the quantification report (see below) and ALWAYS print it.
3b.f. If --dry-run=true:
        - Resolved width/depth = A (the script's deterministic size), with 3b.d2 applied; B is skipped.
        - Skip the proceed prompt.
        - Append the dry-run entries to memory.md and audit.md.
        - Exit successfully. Do NOT proceed to 3b.g or beyond.
      Else if UNATTENDED=true: auto-resolve every disagreement (pick A); proceed.
      Else: user responds [proceed | override w=X | override d=X | abort | pick a / b / manual].
3b.g. Lock width and depth, each with its source: `explicit` when it came from --size/--width/
      --depth or from size/width/depth in run.config.yaml (size: auto is not explicit), or when the
      user overrode it at the proceed prompt; `auto` when A/B chose it. Record WIDTH_SOURCE and
      DEPTH_SOURCE.
      depth=S overrides 3a (force combined).
      depth=L+ overrides 3a (force separate even if same-instance check says same).
      width and WIDTH_SOURCE are threaded into every per-file subagent prompt.
```

## A — counting (deterministic)

**Run the counter — never count by hand.** A is produced by a script so it is
reproducible; hand-counting drifts run-to-run and is forbidden here.

```bash
# Size over the structurally-detailed source. The markers the formula counts
# (`### ` steps, `[XOR]`/`[ExclusiveGateway]`/`**Gateway ...**`, `[CallActivity]`) live in
# the completed discovery iteration's artifacts/. process-optimize output (process-tobe/)
# uses `## Step` / `[GATEWAY-UPDATED]` and would count as 0 — so size over that
# artifacts/ dir whenever a completed iteration exists, regardless of which INPUT_DIR
# generation reads.
node ".github/skills/process-os-bpmn-generation/scripts/iteration-dir.cjs" current process-discovery --complete --artifacts
```

Exit `0` → run the counter over the printed path. Exit `3` → no completed discovery iteration exists; run it over `INPUT_DIR`'s actual value instead (substitute it literally — it is not a shell variable):

```bash
node ".github/skills/process-os-bpmn-generation/scripts/quantify.cjs" "<DIR>"
```

It prints JSON: `width.size`/`width.score` and `depth.size`/`depth.score` are
`size_a` and the A scores; `width.perFile` + `width.avg{Steps,Gateways,Calls}`
and the depth breakdown (`processes`, `subprocesses`, `edges`, `e2e`, `mentions`)
feed the report. The script implements **exactly** the formulas below — they are
kept as the reference spec for what it computes; do not recompute by hand.

**Width formula** (over `process-NN-*.md`, excluding `process-00-e2e.md`):

| Signal | Source | Weight |
|--------|--------|--------|
| step count | `### ` headings | × 1 |
| gateway count | `[XOR]` / `[ExclusiveGateway]` / `[AND-Gateway]` / `[ParallelGateway]` / `[AND-Split]` / `[AND-Join]` / `**Gateway ...**` markers | × 2 |
| called subprocess count | `[CallActivity]` markers | × 1 |

```
width_score = avg(steps + 2 × gateways + 1 × call_activities)
```

| Score | Size |
|-------|------|
| 0–8   | S |
| 9–18  | M |
| 19–30 | L |
| 31+   | XL |

**Depth formula** (over the whole `.md` set):

| Signal | Source | Weight |
|--------|--------|--------|
| process count | `process-NN-*.md` (excl. `process-00-e2e.md`) | × 1 |
| subprocess count | `subprocess-*.md` | × 2 |
| edge count | `edge-*.md` | × 1 |
| e2e orchestration | presence of `process-00-e2e.md` | +3 |
| file mentions | basename of any other input file appearing in any source file (occurrences, no dedup) | ÷ 8 |

**Skip-list for cross-mention counting** (catalog files):
`00-index.md`, `meta-conventions.md`, `participants-and-systems.md`, `data-objects.md`, `gap-analysis.md`, `as-is-process.md`, `improvements-ai-automation.md`, `implementation-roadmap.md`, `metrics.md`, `00-holistic-assessment.md`, `manual-steps.md`.

```
depth_score = #processes
            + 2 × #subprocesses
            + #edges
            + (3 if process-00-e2e.md exists else 0)
            + (#file_mentions / 8)
```

| Score | Size |
|-------|------|
| 0–10  | S |
| 11–18 | M |
| 19–28 | L |
| 29+   | XL |

## B — AI judgment (parallel sub-agents)

**Dispatch both axis agents simultaneously** — run each as an independent subagent:

- **Claude Code:** issue ALL `Agent()` calls in a **single assistant turn** (one tool-message with 2 `tool_use` blocks, one per axis). Do not emit agents one-by-one across turns — that serialises execution. Results are awaited together before continuing.
- **Other platforms:** invoke each axis judgment sequentially if parallel dispatch is not available.

Each outputs:

```
WIDTH: <S|M|L|XL>
JUSTIFICATION: <one sentence, ≤30 words>
```

(or `DEPTH:` for the depth agent).

**Width prompt:**

```
You are judging the WIDTH (per-process complexity) of a process documentation set.
WIDTH measures how branchy, deep, and detailed a single process file is.
Rate width as one of: S, M, L, XL.

Anchors:
  S — Each process file describes 3–5 direct steps with little or no branching.
       Few system references. Single end state. Example: "send notification" phase.
  M — Each file has 6–12 steps with 1–2 decision points. Mostly direct actions,
       light annotation density. Example: simple intake.
  L — Each file has 10–20 steps with 2–4 decision points and multiple end states.
       Heavy system integration detail (field names, API references).
       Example: quote creation with approval routing.
  XL — Each file has 20+ steps OR 4+ decision points OR descriptions whose
        sub-bullets describe distinct sub-actions worth their own modelled task.
        Example: a renewal lifecycle covering 120 days with multiple correlated triggers.

Process files to judge:
<list of process-NN-*.md file paths>

[On rerun only — A's count breakdown:
  avg_steps=N, avg_xor=N, avg_call_activity=N across N process files.
  A judged this as <SIZE>. Reconcile your judgment with this data.]

Read each file. Output exactly:
  WIDTH: <S|M|L|XL>
  JUSTIFICATION: <one sentence, ≤30 words>
```

**Depth prompt:**

```
You are judging the DEPTH (count + interconnectedness) of a process documentation set.
DEPTH measures how many distinct processes exist and how strongly they reference one another.
Rate depth as one of: S, M, L, XL.

Anchors:
  S — 1–5 .md files. No subprocess files. No e2e orchestration file.
       Either a single-instance process collapsing to one BPMN, or loosely related
       independent processes with no cross-references.
  M — 5–12 .md files. Maybe 1 subprocess. Edge case files. Light cross-referencing.
       Example: 6-phase intake pipeline with 4 edge cases, no shared subprocesses.
  L — 12–25 .md files. Multiple subprocesses reused across parents. Edge cases.
       Often an e2e orchestration file. Frequent inter-process references.
       Example: full Q2C with 7 phases, 2 reusable subprocesses, 4 edges, e2e file.
  XL — 25+ .md files OR multiple subprocesses each called from 3+ parents OR
        explicit collaboration with separate pools/lanes/external participants.

File set:
  Processes: <list>
  Subprocesses: <list>
  Edges: <list>
  e2e orchestration file present: <yes/no>

[On rerun — A's count breakdown:
  N processes + N subprocesses + N edges + e2e? + N file-mentions
  → score N, A judged this as <SIZE>. Reconcile.]

Output exactly:
  DEPTH: <S|M|L|XL>
  JUSTIFICATION: <one sentence, ≤30 words>
```

## Comparison algorithm

For each axis independently:

```
1. Run A → size_a ∈ {S, M, L, XL}
2. If size_a == S AND not near-boundary (see 3b.c): lock S. Done.
3. Else: dispatch B → size_b ∈ {S, M, L, XL}
4. Compare:
     identical          → lock. Done.
     1 step apart       → surface to user, ask which to use
     ≥ 2 steps apart    → rerun once with variations
                          if still ≥ 2 apart: surface both with justifications,
                          offer [a | b | manual] choice. Stop after one rerun.
```

**Rerun variations (when A and B are ≥ 2 apart):**

- **A's variation**: switch aggregation `avg(...) → max(...)`. Use whichever produces a score furthest from a threshold boundary (most confident bucket).
- **B's variation**: prepend A's count breakdown to the prompt (the bracketed `[On rerun only...]` block).

**User inquiry when 1 apart:**

```
Width judgment is split:
  Counting (A) says M because:
    - 12 steps avg per file, 2 gateways avg, 1 edge end-state
  AI judgment (B) says L because:
    - high implementation density (system fields, data inputs/outputs)
    - 4 of 7 phases have ≥ 3 [XOR] gateways
Choose: [m] / [l]
```

## Quantification report (always shown)

```
Quantification report
─────────────────────
Width  (per-process complexity)
  Counting (A):  L  (avg score 23.75 over 8 process files)
                 17 steps + 5 gateways + 1.75 calls per file
  AI judgment (B):  L  ("dense implementation detail across all phases,
                         multiple gateways with derived data inputs")
  → Width: L  ✓ A and B agree

Depth  (count + interconnectedness)
  Counting (A):  L  (score 22.4)
                 8 processes + 2 subprocesses + 4 edges + e2e + 27 mentions
  AI judgment (B):  M  ("subprocesses are reused across only 2 callers,
                         orchestration is shallow")
  → Depth: 1 step apart between A and B. Choose:
     [m] use M (less interconnection assumed)
     [l] use L (more interconnection assumed)

Overall size: L  (or M depending on depth answer above)

Generation will produce (width=L, depth=L):
  <OUTPUT_DIR>/process-01-quoting.bpmn          ← 17 elements (full detail)
  ...
  Total: 16 files

Proceed? [y / abort / change w=s|m|l|xl / change d=s|m|l|xl]
```

The "X elements" estimate per file = `steps + gateways + start + end_events` from A's counts, scaled to the chosen width's element-count target.

When the user has forced size via flag or config: A still runs, B does not. Report shows the forced value plus A's auto-recommendation for transparency.

When UNATTENDED=true: report still printed; `Proceed? [...]` line replaced with `→ run-unattended: proceeding with width=L, depth=L (A picked on any disagreement; larger of A/B picked on any near-boundary disagreement)`.

## Depth effect tables

Depth modulates the BPMN set as a whole; width applies uniformly to every generated file.

| Size | Phase BPMNs | Edge cases | Subprocesses | Overview | E2E |
|------|-------------|------------|--------------|----------|-----|
| **S** | combined into one BPMN regardless of same/separate-instance check | inlined as text annotations | inlined as collapsed `<bpmn:subProcess>` | skipped | skipped |
| **M** | one per phase OR combined per same-instance check | own BPMN | own BPMN | generated when phases are separate | skipped |
| **L** | one per phase always (override same-instance collapse) | own BPMN | own BPMN | always generated | generated when `process-00-e2e.md` exists |
| **XL** | one per phase + per-system swimlane variants | own BPMN + per-edge-trigger drill-downs | own BPMN + recurring-pattern extraction | always generated | always generated, synthesized if e2e file missing |

**An automatic depth never drops documented content.** Only an explicit depth=S combines phases,
inlines edge cases as annotations, and abstracts called subprocesses; an automatic S is locked as
M (3b.g), so edge cases and subprocesses keep their own BPMN.

## Depth=S — inlining algorithm

Applies only when there are **2 or more** `process-NN-*.md` files to combine. With exactly one,
there is nothing to combine — generate it normally under its own basename (see bpmn-generation
SKILL.md's "naturally one phase file" single-file short-circuit), regardless of depth.

1. Force same-instance behavior (skip the boundary check, always combine). Write the result to
   **`<OUTPUT_DIR>/process-main.bpmn`** — the same filename the boundary check (step 3a) would have
   produced for a same-instance corpus; depth=S reaches that filename directly, without needing to
   run the check.
2. Read every `process-NN-*.md` (excluding `process-00-e2e.md`); concatenate phases into one left-to-right flow at the chosen width.
3. For each `subprocess-*.md`:
   - Grep main-flow files for the subprocess basename or `[CallActivity]` references.
   - At each calling point, replace the calling task with a collapsed `<bpmn:subProcess>` containing 1–3 abstract tasks. Width inside matches the chosen width.
   - If referenced by multiple parents, render once at the first calling point; on subsequent calls add `See subprocess: <name>` annotation.
4. For each `edge-*.md`:
   - Read the edge file's "Trigger" or "Starts when" line. If absent, ask the LLM.
   - Find the closest main-flow element semantically (LLM judgment, grounded on basename/keyword overlap).
   - Attach annotation:
     ```
     Edge: <basename>
     Trigger: <one-line>
     Outcome: <one-line>
     ```

## Depth=XL — e2e synthesis when `process-00-e2e.md` is missing

1. If `process-00-e2e.md` exists → render it as the e2e BPMN (default at L).
2. If missing:
   - Build a directed graph: each `process-NN-*.md` is a node; each cross-reference (file mention from one to another) is a directed edge from mentioner → mentioned.
   - Topological sort. If acyclic, that order is the e2e flow. If cyclic, dispatch a sub-agent: "Given these N processes and their cross-references, identify the entry point and main flow order."
   - Generate an e2e BPMN with one `<bpmn:callActivity>` per process, connected in determined order, plus banner annotation:
     ```
     ⚠ Synthesized from cross-references — process-00-e2e.md not provided.
     Verify the flow order with a process owner.
     ```
   - If the graph has fewer than 2 cross-references total, abort synthesis and emit:
     ```
     depth=XL requested but no orchestration signal in input —
     supply process-00-e2e.md or accept depth=L.
     ```

## Process instance boundary check (step 3a)

Read `INPUT_DIR/00-index.md` (if it exists) and the first `## Overview` paragraph of each phase file. Answer:

> Do all phase files describe steps of the **same process instance**, or do some phases have their own independent trigger and could run as a separate process definition?

**Same instance** — single business event starts one process instance progressing through every phase. → **One combined BPMN** (`<OUTPUT_DIR>/process-main.bpmn`); skip the overview BPMN.

**Separate instances** — at least one phase has its own distinct external trigger. → One BPMN per phase plus an overview.

Edge cases and subprocesses always get their own BPMNs regardless.

Adjust the generation plan output and todo list to match whichever path applies. Note that depth=S forces same-instance; depth=L+ forces separate.
