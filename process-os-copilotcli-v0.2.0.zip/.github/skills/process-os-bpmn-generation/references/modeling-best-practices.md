# Sub-Skill: Camunda Modeling Best Practices

Verify the planned model against each best practice before writing XML. Call `search_camunda_knowledge_sources` if any rule needs clarification.

## Best-practice checklist

| Best practice | Key checks |
|---------------|------------|
| [Creating Readable Process Models](https://docs.camunda.io/docs/components/best-practices/modeling/creating-readable-process-models/) | Max ~20 elements per diagram; clear left-to-right flow; meaningful labels |
| [Naming BPMN Elements](https://docs.camunda.io/docs/components/best-practices/modeling/naming-bpmn-elements/) | Events: object + past participle; tasks: verb + object; gateways: closed question ending in `?` |
| [Naming Technically Relevant IDs](https://docs.camunda.io/docs/components/best-practices/modeling/naming-technically-relevant-ids/) | IDs are PascalCase with type prefix (`Task_`, `Gateway_`, etc.), human-readable, stable |
| [Modeling Beyond the Happy Path](https://docs.camunda.io/docs/components/best-practices/modeling/modeling-beyond-the-happy-path/) | All exception/rejection paths modeled; no silent dead-ends |
| [Modeling with Situation Patterns](https://docs.camunda.io/docs/components/best-practices/modeling/modeling-with-situation-patterns/) | Correct pattern selected (straight-through, decision, escalation, compensation) |
| [Building Flexibility into BPMN Models](https://docs.camunda.io/docs/components/best-practices/modeling/building-flexibility-into-bpmn-models/) | No unnecessary complexity; flexibility added only where the process genuinely varies |
| [Choosing the DMN Hit Policy](https://docs.camunda.io/docs/components/best-practices/modeling/choosing-the-dmn-hit-policy/) | Only relevant if a business rule task feeds a DMN table |
| [BPMN Examples — situation patterns](https://camunda.com/bpmn/examples/) | Reference models for recurring situations: Four Eyes Principle, Two Step Escalation, Dependent Instances, Monthly Invoicing, Batch of Orders (multi-instance), Reassigning User Tasks, Additional Information after User Task, Business Rules |
| [BPMN Modeling Styles](https://camunda.com/bpmn/examples/) | Avoid crossing flows; naming conventions; symmetric modeling (same-type gateways for split/join pairs); equal task sizes |

The two `camunda.com/bpmn/examples` rows are a pattern gallery with right-vs-wrong example
diagrams. When the planned model matches one of the listed situations and the correct shape is
ambiguous, fetch the specific example page and use its model as the reference shape.

**Model-review findings sweep** — read [model-review-findings.md](model-review-findings.md),
the findings library distilled from Camunda Consulting's customer model reviews with real
occurrence rates. Generated BPMN must not contain its violation/correctness findings; the
top-occurrence readability findings (gateway standard pattern, happy-path alignment,
boundary-events-at-bottom) are what human reviewers flag first — verify the planned model against
them alongside the checklist above.

**Expected (accepted) warning — a deliberate inclusive gateway.** When a step genuinely needs
inclusive-OR semantics (finding F10's "genuine any-subset case" carve-out — e.g. a mix of mandatory
branches plus one or more independently-conditional ones, so the active subset varies by run) and
you keep the `bpmn:InclusiveGateway`, `bpmnlint:recommended`'s built-in `no-inclusive-gateway` rule
still flags the element type unconditionally as a readability advisory. That warning is expected in
this case — do not chase it to zero by removing or restructuring the gateway; F10 governs *whether*
the inclusive gateway is warranted, not whether the resulting lint warning must disappear.

**Logical correctness pre-flight** — run before writing XML:

1. **No temporal language in task names** — any task whose name or description contains "after N days", "within N hours", "wait N days", or "on deadline" must be replaced with a timer intermediate catch event or event-based gateway.
2. **No "wait for X or timeout" as a task** — when waiting for whichever of several events fires first, use event-based gateway + catch events, not a service task.
3. **Escalation ladders have interruption paths** — every timed escalation stage (dunning, SLA, renewal reminder) must include a message catch event for the interrupt (payment received, response arrived); the interrupt path must merge back to the happy-path end event.
4. **No dead elements** — every element (including all end events) must be reachable via at least one execution path from the start event. Every branch from every gateway reaches an end event or a joining gateway; no branch terminates silently. Remove or connect any element that no path leads to.

If any check reveals a modeling issue, fix the planned model before proceeding to XML.

## BPMN resource topology

Generate one top-level `bpmn:process` per `.bpmn` resource. A call activity belongs in
the parent resource, while its called process is a separate BPMN resource referenced by
`zeebe:calledElement processId`; do not place both independent processes in one file.

Multiple root processes are valid only for an explicit `bpmn:collaboration`, with one
`bpmn:participant` per process and a BPMN plane that references the collaboration. Do
not use a collaboration to bundle a call-activity parent with its child for deployment.

## Child process start and end events

If the phase file indicates this process is invoked by another (e.g. "called by", "triggered from", "sub-process of", or the orchestrator flagged it as a child during the Start Event Uniqueness Check), its start event and normal end event must be **none events** — plain `<bpmn:startEvent>` and `<bpmn:endEvent>` with no event definition child.

The parent's call mechanism is what triggers the child; the child must not declare its own triggering event type. Error end events (`<bpmn:errorEventDefinition>`) remain valid for exceptional outcomes. Applying message/signal/timer event definitions to a child's start or normal end event is incorrect.

## XOR gateway data requirements (width-conditional)

See `generate-phase.md` Step 1a for the authoritative annotation policy; per-width breakdown:

- **WIDTH=L or XL**: every exclusive gateway carries an `Implementation: Evaluates: <field>` annotation as part of its full `Implementation:` block.
- **WIDTH=M**: every exclusive gateway carries a stand-alone `Evaluates: <field>` annotation — one short line, no surrounding `Implementation:` density. This is the only annotation gateways get at width=M; it exists so `/process-os-artifact-generation` can emit correct `<bpmn:conditionExpression>` FEEL without falling back to source-markdown lookup. Example: `Evaluates: Co_Review_Decision__c` or `Evaluates: hold_placed`.
- **WIDTH=S**: skip entirely. `/process-os-artifact-generation` resolves the FEEL from the source phase markdown.

In every case the substantive constraint applies: **the gateway must evaluate concrete, already-available data**. Identify the exact variable or field. If unavailable — must be derived, looked up, scored, or computed — insert a `<bpmn:businessRuleTask>` immediately before the gateway. Name it to reflect the role (e.g. `Evaluate credit score`, `Determine approval category`); its `Implementation:` annotation describes the rule/lookup logic.

**Decision rule:** "Is the value the gateway branches on already a process variable here?" Yes → gateway. No → business rule task first.

## Signal vs message events

When a start, intermediate, or end event involves communication between processes, choose by whether the receiver is known.

- **Message** (`<bpmn:messageEventDefinition>`) — sender knows receiver. Point-to-point. **Default for inter-process communication.** Examples: subprocess → parent, service callback, system response.
- **Signal** (`<bpmn:signalEventDefinition>`) — broadcast without knowing who or how many will receive. Examples: system-wide status change, broadcast notification with no defined consumer.

Phase-file phrasing → event type:
- "notify", "trigger", "send to", "call" with a named receiver → message
- "broadcast", "publish", "announce", or no named receiver → signal

## Waiting states — timer and event-based gateway

**Single time-based wait** ("wait 24 hours", "process on the 1st", "deadline of 3 business days") → timer intermediate catch event:

```xml
<bpmn:intermediateCatchEvent id="Timer_WaitForDeadline" name="3-day deadline elapsed">
  <bpmn:incoming>Flow_ToTimer</bpmn:incoming>
  <bpmn:outgoing>Flow_FromTimer</bpmn:outgoing>
  <bpmn:timerEventDefinition id="TimerEventDefinition_1">
    <bpmn:timeDuration>P3D</bpmn:timeDuration>
  </bpmn:timerEventDefinition>
</bpmn:intermediateCatchEvent>
```

ISO 8601 for durations (`PT24H`, `P3D`, `P1M`) and dates/cycles where known. Unknown → placeholder + `❓` annotation.

**Multiple concurrent waiting states** ("wait for approval OR timeout OR cancellation") → event-based gateway followed by one intermediate catch event per branch. First event to fire wins:

```xml
<bpmn:eventBasedGateway id="Gateway_WaitForEvent" name="">
  <bpmn:incoming>Flow_ToGateway</bpmn:incoming>
  <bpmn:outgoing>Flow_ToApproval</bpmn:outgoing>
  <bpmn:outgoing>Flow_ToTimeout</bpmn:outgoing>
</bpmn:eventBasedGateway>

<bpmn:intermediateCatchEvent id="Catch_ApprovalReceived" name="Approval received">
  <bpmn:incoming>Flow_ToApproval</bpmn:incoming>
  <bpmn:outgoing>Flow_AfterApproval</bpmn:outgoing>
  <bpmn:messageEventDefinition id="MessageEventDefinition_Approval" />
</bpmn:intermediateCatchEvent>

<bpmn:intermediateCatchEvent id="Catch_TimeoutElapsed" name="Approval timeout elapsed">
  <bpmn:incoming>Flow_ToTimeout</bpmn:incoming>
  <bpmn:outgoing>Flow_AfterTimeout</bpmn:outgoing>
  <bpmn:timerEventDefinition id="TimerEventDefinition_Timeout">
    <bpmn:timeDuration>PT48H</bpmn:timeDuration>
  </bpmn:timerEventDefinition>
</bpmn:intermediateCatchEvent>
```

Every branch after an event-based gateway must start with an intermediate catch event (timer / message / signal). Never place a task or gateway directly after.

Recognise waiting states in phase-file language: "wait for", "until", "after N days/hours", "on deadline", "when received", "whichever comes first", "either … or …".

### Events vs connector-bound tasks (automatable mode)

The message/signal-event and event-based-gateway patterns above are the **strategic /
choreography default**. In **automatable mode**, a connector or a non-interrupting boundary
overrides the event idiom — bind the connectable **activity** instead:

- **Outbound communication** (send email, post to Slack, write to Salesforce, call REST) →
  always a **`serviceTask` + connector**, never a message *throw event*. OOTB connectors bind
  to service tasks, not throw events.
- **Inbound wait that must escalate without abandoning the wait** (e.g. "wait for the archive
  reply; if 2 days pass, escalate — but keep waiting") → a **`receiveTask` (or an
  inbound-connector receive) with a *non-interrupting* boundary timer**. This is required, not
  stylistic: boundary events attach only to **activities** (never to an intermediate catch
  event), and an **event-based gateway is interrupting** (the first event cancels the others),
  so neither of the event patterns above can express "escalate but keep waiting."
- **Inbound wait that is genuinely first-of-N-wins** (no need to survive the loser) → keep the
  **event-based gateway + intermediate catch events** pattern above (it is interrupting by
  design, which is correct here).
- **Inbound trigger that starts the process** → a **message start event** may carry an inbound
  connector (e.g. an email/IMAP trigger); declare the start event's `messageName` so the
  connector binds to a real message subscription.

Decision: connector or non-interrupting boundary in play → connectable activity
(`serviceTask`/`receiveTask`); otherwise → the event idiom.

## Temporal language detection (scan before mapping)

Before building the element list, scan the phase file for time-based language in task names, sub-bullets, or step descriptions:

- "after N days/hours/weeks"
- "within N days", "on day N"
- "wait N days then…", "N-day payment terms"
- "send reminder after X, escalate after Y"

Every occurrence signals **the wait IS the flow element**. Do not model these as service tasks with time in the name/annotation. Convert to timer intermediate catch event (single wait) or event-based gateway (wait where payment/response can arrive first).

## Time-based escalation with payment/response interruption

When a process escalates through multiple timed stages AND each waiting period can be interrupted by an external event (payment received, dispute filed, customer responds), model each stage as an **event-based gateway** followed by:

1. Timer catch event → next escalation step
2. Message catch event for each interrupting event

This is the correct pattern for dunning sequences, SLA escalation ladders, renewal reminders, and any "wait N days, then escalate unless X happens" flow. Never service tasks.

Example (two-stage dunning with payment interrupt):

```xml
<!-- Stage 1: after sending dunning reminder -->
<bpmn:eventBasedGateway id="Gateway_WaitAfterReminder1" name="">
  <bpmn:incoming>Flow_AfterReminder1</bpmn:incoming>
  <bpmn:outgoing>Flow_ToTimer7d</bpmn:outgoing>
  <bpmn:outgoing>Flow_ToPaymentDuring7d</bpmn:outgoing>
</bpmn:eventBasedGateway>

<bpmn:intermediateCatchEvent id="Catch_7DaysElapsed" name="7-day period elapsed">
  <bpmn:incoming>Flow_ToTimer7d</bpmn:incoming>
  <bpmn:outgoing>Flow_ToFinalNotice</bpmn:outgoing>
  <bpmn:timerEventDefinition id="TimerDef_7Days">
    <bpmn:timeDuration>P7D</bpmn:timeDuration>
  </bpmn:timerEventDefinition>
</bpmn:intermediateCatchEvent>

<bpmn:intermediateCatchEvent id="Catch_PaymentDuringReminder" name="Payment received">
  <bpmn:incoming>Flow_ToPaymentDuring7d</bpmn:incoming>
  <bpmn:outgoing>Flow_ToInvoicePaid</bpmn:outgoing>
  <bpmn:messageEventDefinition id="MsgDef_Payment1" />
</bpmn:intermediateCatchEvent>

<!-- Stage 2: after sending final notice -->
<bpmn:serviceTask id="Task_SendFinalNotice" name="Send final notice">
  <bpmn:incoming>Flow_ToFinalNotice</bpmn:incoming>
  <bpmn:outgoing>Flow_AfterFinalNotice</bpmn:outgoing>
</bpmn:serviceTask>

<bpmn:eventBasedGateway id="Gateway_WaitAfterFinalNotice" name="">
  <bpmn:incoming>Flow_AfterFinalNotice</bpmn:incoming>
  <bpmn:outgoing>Flow_ToTimer30d</bpmn:outgoing>
  <bpmn:outgoing>Flow_ToPaymentDuring30d</bpmn:outgoing>
</bpmn:eventBasedGateway>

<bpmn:intermediateCatchEvent id="Catch_30DaysElapsed" name="30-day period elapsed">
  <bpmn:incoming>Flow_ToTimer30d</bpmn:incoming>
  <bpmn:outgoing>Flow_ToCollections</bpmn:outgoing>
  <bpmn:timerEventDefinition id="TimerDef_30Days">
    <bpmn:timeDuration>P30D</bpmn:timeDuration>
  </bpmn:timerEventDefinition>
</bpmn:intermediateCatchEvent>

<bpmn:intermediateCatchEvent id="Catch_PaymentDuringFinal" name="Payment received">
  <bpmn:incoming>Flow_ToPaymentDuring30d</bpmn:incoming>
  <bpmn:outgoing>Flow_ToInvoicePaid</bpmn:outgoing>
  <bpmn:messageEventDefinition id="MsgDef_Payment2" />
</bpmn:intermediateCatchEvent>
```

Payment-received paths from both stages merge at a joining exclusive gateway before the single `Invoice paid` end event. ISO 8601 for all durations; unknown → placeholder + `❓`.

## Parallel gateways

Model a split/join pair when the phase file marks concurrency **explicitly** — either:

- steps sharing the same `**Parallel group:** parallel-N` value, **or**
- a `[AND-Gateway]` "Parallel Split" gateway paired with its "Parallel Join" (synonyms: `[ParallelGateway]`, `[AND-Split]`/`[AND-Join]`). This is a marker, exactly like `[XOR]`/`[ExclusiveGateway]` for exclusive gateways — treat it as authoritative, not as prose.

Do **not** infer parallelism from *unmarked* prose alone (e.g. "fans out into two parallel streams", "meanwhile", "at the same time" with no marker). The phase being named "parallel" is not a marker either.

When the marked branches are **streams** (each a sequence of steps) rather than single steps — as with a `[AND-Gateway]` split whose two branches are multi-step streams — give the split one outgoing per stream, model each stream as its own sequence, and join all streams before the next element. At width ≤ M, collapse each stream to its essential 1–2 tasks but **keep the split/join pair** (the parallelism is the point of the phase).

Mechanics:

1. `<bpmn:parallelGateway>` (split) — no label, no `default` — one outgoing flow per parallel branch (step or stream)
2. Each branch (a step, or a stream's first step), each receiving one outgoing flow
3. `<bpmn:parallelGateway>` (join) — no label — one incoming per branch, one outgoing to the next element

Parallel gateways do **not** use `default`. All outgoing from a split fire simultaneously.

```xml
<bpmn:parallelGateway id="ParallelGateway_Split_1" name="">
  <bpmn:incoming>Flow_ToSplit</bpmn:incoming>
  <bpmn:outgoing>Flow_ToTaskA</bpmn:outgoing>
  <bpmn:outgoing>Flow_ToTaskB</bpmn:outgoing>
</bpmn:parallelGateway>

<bpmn:serviceTask id="Task_LookUpOrder" name="Look up order">
  <bpmn:incoming>Flow_ToTaskA</bpmn:incoming>
  <bpmn:outgoing>Flow_TaskAToJoin</bpmn:outgoing>
</bpmn:serviceTask>

<bpmn:serviceTask id="Task_FetchPaymentHistory" name="Fetch payment history">
  <bpmn:incoming>Flow_ToTaskB</bpmn:incoming>
  <bpmn:outgoing>Flow_TaskBToJoin</bpmn:outgoing>
</bpmn:serviceTask>

<bpmn:parallelGateway id="ParallelGateway_Join_1" name="">
  <bpmn:incoming>Flow_TaskAToJoin</bpmn:incoming>
  <bpmn:incoming>Flow_TaskBToJoin</bpmn:incoming>
  <bpmn:outgoing>Flow_FromJoin</bpmn:outgoing>
</bpmn:parallelGateway>
```

**DI for parallel groups:** split gateway on the main flow (y=370). Parallel tasks in vertical columns at the same x — first task center y=290, second y=460, third y=630 (150px apart). Join gateway aligned to y=370. Route each task's outgoing flow to the join's left/top/bottom face.

**Naming:** parallel gateways carry no label (`name=""`). Tasks themselves carry the descriptive names.

## Async patterns — message send / message catch

When a step is async (process fires a request and waits for response/callback before continuing), model as paired intermediate event sequence — not a single task:

1. `<bpmn:intermediateThrowEvent>` with `<bpmn:messageEventDefinition>` — outgoing message (send)
2. `<bpmn:intermediateCatchEvent>` with `<bpmn:messageEventDefinition>` — waiting for response (catch)

Recognise async steps in phase-file language: "sends a request and waits", "triggers and polls", "fires and receives callback", "async call", "non-blocking", or any step where the process must pause until an external system responds. A plain service task is synchronous — for async, replace with the send/catch pair. The `Implementation:` annotation on throw describes what is sent; on catch describes what response is expected.

## Spawn pattern for long-running downstream processes

If a downstream process is long-running (runs over hours, days, or months) **or** starts
independently of the current process's completion, do **not** model it as a call activity in the
main flow — chaining it as a sequential call activity would hold the main process's token for the
downstream process's entire lifetime (e.g. months, for a renewal process). Use an intermediate
message throw event to spawn it as a separate process instance instead; the main process continues
immediately after throwing.

The spawned process has a corresponding **message start event** (not a none start event — it is
triggered by this throw, not called synchronously). The main process's next element follows the
throw event immediately — it does not wait for the spawned process to complete.

Recognise this pattern in phase-file language: a downstream process described as recurring on its
own schedule (renewal N months after activation, weekly expansion-monitoring scan, annual billing
cycle, churn-risk monitoring) or as starting independently of this process's outcome. Contrast with
a **call activity**, which is correct for a downstream process that (a) completes within this
process's own timeframe and (b) whose result this process needs before continuing.

## Error end events and boundary catch events

Classify each terminal outcome before writing XML.

**Exceptional outcomes** — error, failure, timeout, cancellation, violation, anything signalling the process could not complete normally — use an error end event:

```xml
<bpmn:endEvent id="EndEvent_PaymentError" name="Payment error">
  <bpmn:incoming>Flow_ToPaymentError</bpmn:incoming>
  <bpmn:errorEventDefinition id="ErrorEventDefinition_PaymentError" />
</bpmn:endEvent>
```

**Call activities — mandatory error boundary events.** Every `<bpmn:callActivity>` element MUST have at least one attached boundary error catch event. A called process that can end in error will throw that error back to the parent; without a boundary event the token is lost and the parent instance hangs indefinitely.

**Called process end events.** A process designed to be invoked as a call activity must define:
1. A **normal (none) end event** — plain `<bpmn:endEvent>` with no event definition — for successful completion.
2. At least one **error end event** (`<bpmn:errorEventDefinition>`) for exceptional outcomes.

Never leave a called process with only error end events or only a success end event.

**Named error end events → explicit parent handling paths.** When a called process defines a named error end event (i.e., the `<bpmn:errorEventDefinition>` references a specific `<bpmn:error>` by `errorRef`), the parent process must have a **separate** boundary error catch event for that exact error code, with its own dedicated handling path. A single catch-all boundary event is not sufficient when named errors require distinct responses.

```xml
<!-- In parent: two boundary events on the same call activity for two named errors -->
<bpmn:boundaryEvent id="BoundaryEvent_ValidationError" attachedToRef="Task_CallChildProcess" cancelActivity="true">
  <bpmn:outgoing>Flow_ToValidationHandler</bpmn:outgoing>
  <bpmn:errorEventDefinition id="ErrorEventDefinition_Validation" errorRef="Error_ValidationFailed" />
</bpmn:boundaryEvent>

<bpmn:boundaryEvent id="BoundaryEvent_SystemError" attachedToRef="Task_CallChildProcess" cancelActivity="true">
  <bpmn:outgoing>Flow_ToSystemErrorHandler</bpmn:outgoing>
  <bpmn:errorEventDefinition id="ErrorEventDefinition_System" errorRef="Error_SystemFailure" />
</bpmn:boundaryEvent>
```

**When this process is called as a child** (phase file says so, or orchestrator flagged it during Start Event Uniqueness Check): every task in the **parent process** that calls this child must have a **boundary error catch event** leading to an error-handling path:

```xml
<bpmn:boundaryEvent id="BoundaryEvent_ChildError" attachedToRef="Task_CallChildProcess" cancelActivity="true">
  <bpmn:outgoing>Flow_ToErrorHandler</bpmn:outgoing>
  <bpmn:errorEventDefinition id="ErrorEventDefinition_ChildError" />
</bpmn:boundaryEvent>
```

Route every boundary event to a dedicated error-handling task or error end event in the parent. Never leave a caught error without a handling path.

### Recovery pattern per failure mode

The mandatory boundary event above needs a handling path — choose it by the realistic failure mode
of the called process, not generically:

- **Business rejection** (customer declined, quote recalled, approval denied) — boundary error →
  exclusive gateway → error end event labeled with the business outcome (e.g. `Deal lost`, `Quote
  cancelled`). No retry: the outcome is final.
- **Recoverable operational error** (system timeout, validation failure, booking blocked) —
  boundary error → recovery task → loop back to a retry gateway before the call activity. In
  `automatable` mode, prefer an AI Agent ad-hoc sub-process (`ai-in-bpmn.md`) for the recovery task
  when the error is data-related or operational; use a UserTask only when the recovery requires
  business judgment an AI agent cannot safely exercise.
- **Unrecoverable error** (data corruption, unresolvable conflict) — boundary error → escalation to
  an error end event, or an incident-level notification service task → end event. No retry path.

Match the recovery task's element type to the same verdict-derived rules as any other step (see
`generate-phase.md`'s marker table) — a recovery task is just another task in the flow and gets the
same disposition treatment.

## Human task orchestration (multiple user tasks)

If a process contains 2+ user tasks, reason whether they fit the three-stage pattern:

1. **Data collection** — gather inputs, fill forms, collect documents
2. **User interaction** — review, validate, enrich, or act on the collected data
3. **Decision processing** — approve, reject, escalate, or route based on outcome

If they fit: order them accordingly + add a standalone text annotation near the first user task: `Human task orchestration: data collection → user interaction → decision processing`.

If they don't clearly map: leave the flow + add `❓ Multiple user tasks present — consider structuring as data collection → user interaction → decision processing`.

## Structural rules

**Left-to-right flow.** The process flows left-to-right. Every non-loop sequence flow moves to a higher x than its source. Incoming flows arrive at the **west (left) face** of every element — tasks, events, and gateways alike. Exception: joining gateways may also accept flows from the top or bottom face when merging from branch rows.

**Remove unnecessary gateways.** A gateway is valid only with 2+ outgoing (split) OR 2+ incoming (join). A gateway with exactly 1 in / 1 out adds no decision logic — delete it, connect predecessor → successor directly. Common when a phase file describes a condition with one outcome modelled.

**Multiple incoming / outgoing flows — gateways only:**
- Only gateways (and elements with attached boundary/intermediate events) may have more than one incoming or outgoing sequence flow.
- Regular tasks and events: exactly one incoming, one outgoing.
- **If a non-gateway element needs merging flows, insert a joining exclusive gateway immediately before it.** Never route multiple sequence flows directly into a task or event.
- **End events: exactly one incoming.** Multiple branches converging on the same end state → add a merging exclusive gateway before the end event.
- Loops: gateway-to-gateway. Never a direct backward edge from a task. Add a gateway at the loop-back point if needed.

**Boundary event paths must terminate.** Every path that leaves a boundary event (error, timer, signal, message) must reach an end event or loop back to a defined point in the main flow. A task reachable only via a boundary event, with no onward flow, leaves a stuck process token — add a connecting flow to an end event or a join gateway.

**Gateway side assignment — plan before writing DI:**
- Right face: outgoing only; incoming never arrives from the right.
- Incoming: left, top, or bottom face.
- Outgoing priority: **right → bottom → top**. Use each face once before doubling up.
- Branch targets always at higher x than the gateway (flows move rightward, never backward). A bottom-face exit routes down then right.

## Annotations — use text annotations, never `<bpmn:documentation>`

All human-readable notes, implementation hints, and data details must be modelled as **BPMN text annotations** (`<bpmn:textAnnotation>` + `<bpmn:association>`), not as the `<bpmn:documentation>` XML property. Text annotations are visible in the diagram canvas; `<bpmn:documentation>` is hidden in XML and ignored by most tooling.

```xml
<!-- Correct -->
<bpmn:textAnnotation id="TextAnnotation_ReviewTask">
  <bpmn:text>Implementation: Sends approval request via REST POST /approvals. Timeout: 48h.</bpmn:text>
</bpmn:textAnnotation>
<bpmn:association id="Association_ReviewTask" associationDirection="None"
  sourceRef="Task_ReviewOrder" targetRef="TextAnnotation_ReviewTask" />

<!-- Wrong — do not use -->
<bpmn:task id="Task_ReviewOrder" name="Review order">
  <bpmn:documentation>Sends approval request via REST POST /approvals.</bpmn:documentation>
</bpmn:task>
```

If existing XML contains `<bpmn:documentation>` elements, convert them to text annotations during generation. Never add new `<bpmn:documentation>` elements.

## Clarification annotations

Whenever ambiguity arises during mapping or best-practice validation — unclear trigger, unknown source system, ambiguous decision outcome, missing actor, or any assumption made — add a text annotation: `❓ <question>` (e.g. `❓ Who approves this step — manager or system?`, `❓ What happens if the invoice is not received within 24h?`).

These are intentional review flags for the process owner, not errors to suppress.
