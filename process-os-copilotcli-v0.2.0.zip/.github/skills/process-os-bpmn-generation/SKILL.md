---
name: process-os-bpmn-generation
description: >-
  Internal BPMN engine invoked by lifecycle skills, not run solo by users —
  generates human-readable Camunda BPMN from phase-doc markdown, edits existing
  BPMN, or surgically updates one BPMN from its edited markdown
  (--target/--from); caller-supplied input/output dirs (--input defaults to the
  last completed discovery iteration's artifacts/, --output required)
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
# /process-os-bpmn-generation

Generate human-readable BPMN 2.0 diagrams from process documentation. Output is documentation-grade BPMN — opens in Camunda Modeler or any BPMN viewer. Execution semantics (Zeebe extensions) are emitted only for the connector-bound and AI-Agent carve-outs documented below.

## GATE: Runtime deps present (before any dispatch — update/edit/generate all need this)

`@bpmnkit/core` is required. Never install it here, never hand-author XML instead — stop.

```bash
node ".github/skills/process-os-bpmn-generation/scripts/require-runtime-deps.cjs"
```

Exit 0 (silent) → continue. Exit 1 → print the message it wrote to stderr verbatim and stop;
nothing has been created yet, so there is nothing to clean up.

`bpmnlint` is deliberately **not** gated — a missing binary falls back to `npx --yes bpmnlint`
(see *EXEC: Setup* → "Nothing to resolve for bpmnlint"), which costs wall-clock, not correctness.

## EXEC: Dispatch — update mode? (check first)

**Before resolving dirs or mode**, check for the `--target` flag. If the invocation includes
`--target <file.bpmn>`, this is **update mode**: surgically re-derive one existing BPMN from
its edited Markdown source by **editing the retained `<target>.bpmn.gen.mjs` generator and
re-running it** — never a full-directory generate, never a hand-edit of the `.bpmn`.

```
process-os-bpmn-generation --target <file.bpmn> --from <file.md>[,<file2.md>,...]
```

Read `references/update-mode.md` and follow it **exclusively**, then stop — do not read the
rest of this skill. Update mode is the mechanism `/process-os-process-discovery`'s BPMN-regen
phase uses; any caller with a changed phase `.md` and its existing `.bpmn` pendant can use it.

Absent `--target`, continue to **EXEC: Resolve input + output** below (the standard
generate / edit paths).

## EXEC: Resolve input + output

process-os-bpmn-generation is **phase-agnostic**: it reads BPMN-source documents from an input dir and
writes BPMN to an output dir. It does not know about lifecycle phases or transformation
tiers — the caller chooses the directories.

**1. Resolve INPUT_DIR / OUTPUT_DIR:**

| Var | Flag | Default |
| --- | --- | --- |
| `INPUT_DIR` | `--input <dir>` (alias `--source`) | the last completed discovery iteration's `artifacts/` — resolved below; none when no completed iteration exists |
| `OUTPUT_DIR` | `--output <dir>` | **required — no default** |

(`source` in `run.config.yaml` still overrides the flag default when set. It has no schema
default, so the reader exits 1 and prints nothing when it is unset — resolve the fallback below
in that case.)

```bash
node ".github/skills/process-os-bpmn-generation/scripts/read-run-config.cjs" source
```

When neither `--input`/`--source` nor `source` in `run.config.yaml` supplies `INPUT_DIR`, resolve
the default to the last **completed** discovery iteration's `artifacts/` — a bare `process-discovery`
holds only `iteration-*/` subdirectories under this layout, and reading it directly would silently
find an empty document set:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/iteration-dir.cjs" current process-discovery --complete --artifacts
```

- Exit `0` → use the printed path as `INPUT_DIR`.
- Exit `3` → no completed discovery iteration exists. `process-os-bpmn-generation` is
  **phase-agnostic** and legitimately runs on a project with no discovery output at all, so this
  is not a hard error — it means the default is unavailable. Output
  `"process-os-bpmn-generation has no --input and no completed discovery iteration to default
  from; pass --input explicitly."` and stop.

**Applies to every `read-run-config.cjs` call in this skill.** process-os-bpmn-generation runs on any
BPMN-source directory, including one with no project config at all — so an exit of 2 whose
stderr is `run.config.yaml not found` means **there is no run config**: treat every key it
would have supplied as unset and take exactly the same fallback as an exit 1 (the schema
default, or the per-key behaviour documented at each read below). An exit of 2 for any other
reason — `Cannot parse run.config.yaml`, or ProcessOS Node deps not installed — **is** a hard
error: report it and stop. The distinction is that there a configured value exists but could
not be read, so falling back would silently override it.
`process-os-process-transformation` calls process-os-bpmn-generation with the resolved iteration's
`artifacts/` dir for both, e.g. `--input process-transformation/iteration-1/artifacts --output
process-transformation/iteration-1/artifacts --no-snapshot`.

`process-os-bpmn-generation` is an **internal engine** — it is invoked by the lifecycle skills
(`process-os-process-discovery`, `process-os-process-transformation`, `process-os-review-answer-application`,
`process-os-bpmn-to-md-sync`), not run solo by users. If `--output` is not provided (and no
`--target` is given), output: `"process-os-bpmn-generation requires --output; it is invoked by
the lifecycle skills. Run /process-os-process-transformation --bpmn to produce to-be BPMN."`
and stop.

**1b. Resolve EMBEDDED (sub-invocation).** `process-os-bpmn-generation` owns no
`.camunda/state.md` lifecycle row on any path (it is an internal engine — the
invoking lifecycle skill records its own phase state). The `EMBEDDED` flag now
governs only the *shared provenance* records. Set `EMBEDDED=true` when the
invocation carries `--embedded` (e.g. discovery Phase 3b `as-is-bpmn.md`
producing the AS-IS diagram, where the caller writes its own audit/memory);
otherwise `EMBEDDED=false`. When `EMBEDDED=true`, **skip** the `process-os-bpmn-generation`
audit line and the `## BPMN Decisions` memory entry so the nested run does not
duplicate the caller's records. Snapshots, timing, layout, lint, PROCESSES.md,
and the final output are unaffected.

**1c. Resolve NO_SNAPSHOT.** Set `NO_SNAPSHOT=true` when the invocation carries
`--no-snapshot`; otherwise `NO_SNAPSHOT=false`. `--no-snapshot` suppresses every
`snapshot.cjs save` write and the `SNAP_VERSION` computation, for a caller whose
`OUTPUT_DIR` is itself the version history (e.g. a discovery iteration directory) and so
needs none of `process-os-bpmn-generation`'s own `.snapshots/` bookkeeping. It is
independent of `EMBEDDED` (step 1b above) — `--embedded` and `--no-snapshot` gate
different records.

**Throughout this skill, bash/JS examples use the tokens `INPUT_DIR` / `OUTPUT_DIR` —
substitute the resolved paths (`--input` defaults to the last completed discovery iteration's
`artifacts/`, resolved above; `--output` is caller-supplied, typically a transformation
iteration's `artifacts/` dir).**

If `INPUT_DIR` does not exist or is empty → output `"Input dir <INPUT_DIR> not found or
empty."` and stop.

**2. Select MODE by what INPUT_DIR contains** — not by any phase/tier name:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/dir-contains.cjs" INPUT_DIR "*.bpmn" "*.md"
```

It prints `MATCH` / `NO MATCH` per pattern (or one `NO DIR` line when `INPUT_DIR`
is absent, which is the stop case above).

- INPUT_DIR holds phase `*.md` (`process-NN-*`, `edge-*`, `subprocess-*`) → **MODE=generate**:
  build BPMN from the markdown (the standard flow — parallel phase fan-out, overview,
  PROCESSES.md).
- INPUT_DIR holds `*.bpmn` and no phase `*.md` → **MODE=edit**: edit the existing BPMN from
  operator intent (no fan-out).
- Both kinds present → **MODE=generate** (phase `*.md` is the authoring source). Any
  `*.bpmn` in the dir is **supplementary input** — existing diagrams that inform and enrich
  the generated output (prior element names, structure, layout worth preserving). Pass each
  phase agent its matching `*.bpmn` (same basename) alongside the `*.md` as reference, so
  the markdown drives generation while the existing diagram supplements it.

**3. Branch:** MODE=edit → go to **EXEC: Edit mode** and follow it to its stop. MODE=generate
→ continue to **EXEC: Resolve Mode** (the rest of this skill).

## EXEC: Edit mode

Use when `INPUT_DIR` already holds `*.bpmn` (e.g. `process-os-process-transformation` invoking with
its iteration's `artifacts/` dir for both input and output). **No phase fan-out** — the BPMN already exists; this
path edits it from operator-supplied intent. Typically `INPUT_DIR == OUTPUT_DIR` (edit in
place), but both are honored independently.

### EXEC: Step 1 — Snapshot existing OUTPUT_DIR

If `OUTPUT_DIR` already holds `*.bpmn`, snapshot it before editing (generic pre-snapshot —
the same mechanism as generate-mode Setup). Under `--no-snapshot`, skip this step entirely:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/snapshot.cjs" save OUTPUT_DIR "*.bpmn" PROCESSES.md
```

Prints the created version (e.g. `v2`) when `OUTPUT_DIR` had `*.bpmn` to preserve; prints nothing and creates no directory when it didn't.

### AI: Step 3 — Capture operator intent (required, interactive)

List the named elements — never Read the `.bpmn` files themselves (an automatable one runs
well over the Read cap):

```bash
node ".github/skills/process-os-bpmn-generation/scripts/bpmn-extract.cjs" INPUT_DIR --names
```

Exit `2` → bad input (missing path, no `.bpmn` files, a dangling `--exclude`, or a malformed `--max-bytes`) — report stderr and stop.
Exit `3` means even that report is over the cap — re-run it one file at a time.

If `INPUT_DIR/*.md` is present, read it for reconciliation
context. Then **ask the operator explicitly how to tweak the BPMN for
this run** — what to add, change, or remove, per file. Do not infer edits silently. In
run-unattended mode (per "Run-unattended mode" below), if no intent is supplied, make **no**
structural edits — copy `INPUT_DIR` → `OUTPUT_DIR` unchanged (when they differ), re-lint,
snapshot, and note that no operator intent was given.

### AI: Step 4 — Apply edits via the bpmnkit operations API

For each file the operator wants changed, apply the edits with `applyBpmnOperations` (parse →
`applyBpmnOperations` → export), reading from `INPUT_DIR` and writing to `OUTPUT_DIR`. It
preserves existing layout and lays out only new nodes. See [the bpmnkit reference](references/bpmnkit.md)
("Editing an existing BPMN"). **Not the `compactify` → `applyOperations` → `expand` round-trip**:
it drops every `textAnnotation` and `association` on the diagram, which the discovery pendants
carry, and strips a bound element's template attributes.
Reconcile element names with `INPUT_DIR/*.md` where the operator's intent maps to a
discovery step. Do **not** rebuild from scratch (that discards the manual layout). Files the
operator does not change are copied to `OUTPUT_DIR` unchanged (when it differs from INPUT_DIR).

### EXEC: Step 5 — Lint

Lint every `OUTPUT_DIR/*.bpmn` with the structural config the hook uses (non-executable
unless connector-bound). **Redirect per file — never capture lint inline** (a large/broken
BPMN can exceed the harness ~25 KB Bash-stdout buffer → `parser aborted`):

```bash
node ".github/skills/process-os-bpmn-generation/scripts/lint-to-files.cjs" OUTPUT_DIR
```

It lints each `OUTPUT_DIR/*.bpmn` into `.camunda/.lint/<basename>.txt` and prints one
`<basename> EXIT:<code>` line per file. Exit `2` — from the script or on a file's line — means
those files were **not** linted; never read it as clean.

**Read** each non-clean file's `.camunda/.lint/<basename>.txt` with the Read tool. If one
contains `parser aborted` / `over-length`, don't retry — report the harness limit and lint
that file in isolation. Fix all errors before proceeding (edit via the bpmnkit script,
re-run, re-lint).

### AI: Step 6 — Regenerate PROCESSES.md + snapshot

Regenerate `OUTPUT_DIR/PROCESSES.md` per the **AI: Generate Documentation** section (source =
the BPMN now in `OUTPUT_DIR`). Then snapshot the result (generic post-snapshot). Under
`--no-snapshot`, skip the snapshot call — regeneration of `PROCESSES.md` still happens:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/snapshot.cjs" save OUTPUT_DIR "*.bpmn" "*.md"
```

Prints the created version bare (e.g. `v2`).

### EXEC: Step 7 — Audit + State + Memory

```bash
node ".github/skills/process-os-bpmn-generation/scripts/append-audit.cjs" "process-os-bpmn-generation (edit)" "Edited [N] BPMN in OUTPUT_DIR, snapshot v[N]"
```

Under `--no-snapshot`, Steps 1 and 6 above never ran, so there is no `v[N]` — omit the
`, snapshot v[N]` clause: `"Edited [N] BPMN in OUTPUT_DIR"`.

Update `.camunda/memory.md` section `## BPMN Decisions` with a bullet noting
INPUT_DIR/OUTPUT_DIR, files changed, and the operator intent applied.
`process-os-bpmn-generation` owns no `.camunda/state.md` lifecycle row — it is an internal
engine, and the invoking lifecycle skill records its own phase state.

### EXEC: Step 8 — Output

```
Edit-mode generation complete.

Edited [N] BPMN files → <OUTPUT_DIR>/
  [list changed filenames]
  PROCESSES.md  ← regenerated

All edited files linted. Snapshot: v[N]

Review options:
  /process-os-file-viewer          ← open a local bpmn-js viewer in your browser
```

Under `--no-snapshot`, omit the `Snapshot: v[N]` clause — the line reads `All edited files
linted.` alone.

**Stop here — do not continue to the generate-mode sections.**

---

## EXEC: Resolve Mode (required)

Every standard generation run requires an explicit mode. Resolve in order:

1. CLI flag `--bpmn-mode strategic` or `--bpmn-mode automatable`.
2. Else the `bpmn-mode` key in `run.config.yaml` — **only** when its value is `strategic` or
   `automatable`.

```bash
node ".github/skills/process-os-bpmn-generation/scripts/read-run-config.cjs" bpmn-mode
```

It prints the mode and exits 0 when the key is set. It exits 1 with **no** output when the key is absent — `bpmn-mode` deliberately has no schema default, precisely so this gate stays reachable. Per the rule under "Resolve input + output", a `run.config.yaml not found` exit 2 is likewise "no mode set" and falls through to the error below; an unparseable config or missing Node deps is a hard error — report it and stop rather than prompting for a mode the config may already carry.

If neither is set, output exactly:

```
Specify a mode: --bpmn-mode strategic (documentation-grade, non-executable) or
--bpmn-mode automatable (execution-leaning, connector-bound). You can also set
`bpmn-mode: strategic` or `bpmn-mode: automatable` in run.config.yaml.
```

and stop. **This rule holds under run-unattended too** — an unattended run with no
mode still errors and aborts (consistent with the all-three-flags error).

Capture `MODE` (`strategic` | `automatable`). It is passed to every phase subagent
and selects which modeling guide the subagent reads (see generate-phase.md).

- **strategic** → `isExecutable=false`, no Zeebe/connector/form extensions (a call activity keeps
  its `zeebe:calledElement`), business language. Subagent reads `references/strategic-modeling.md`.
  The connector/AI-agent carve-outs do NOT apply.
- **automatable** → connectors via `c8ctl element-template apply`, Zeebe user tasks,
  FEEL conditions, business-rule→DMN. Subagent reads `references/automatable-modeling.md`.

---

## Quantification (size control)

Two-axis model controls the size, count, and detail of generated BPMN diagrams:

- **width** (X): per-process complexity — how long and branchy a single BPMN is
- **depth** (Y): count + interconnectedness — how many BPMNs and how cross-linked

### CLI flags

| Flag | Controls | Values | Default |
| --- | --- | --- | --- |
| `--size` | overall (auto-derived label) | `auto`, `s`, `m`, `l`, `xl` | `auto` |
| `--width` | per-process complexity (X-axis) | `s`, `m`, `l`, `xl` | inherits from `--size` |
| `--depth` | count + interconnectedness (Y-axis) | `s`, `m`, `l`, `xl` | inherits from `--size` |
| `--dry-run` | exit after quantification report — no BPMN generation | `false`, `true` | `false` |

### Dry-run mode

When `--dry-run=true`, the skill executes through step 3b.e (compute and print the quantification report), then writes a short-form memory and audit entry and exits. No BPMN files are generated, no snapshot directory is created, and `state.md` is NOT updated.

**Persistence under dry-run:**
- `.camunda/memory.md` — appended with a `(dry-run)`-marked entry containing width, depth, A and B values. Format:
```markdown
 <!-- YYYY-MM-DD (dry-run) -->
  - Quantification only — no BPMN generated
  - Width A: <S|M|L|XL> (score N.N); B: <S|M|L|XL>; <agreed|surfaced>
  - Depth A: <S|M|L|XL> (score N.N); B: <S|M|L|XL>; <agreed|surfaced>
  - Resolved width=<S|M|L|XL>, depth=<S|M|L|XL>[ (automatic S)]
```
  When B did not run (e.g. A=S short-circuit, or user-forced size), record `B: skipped`.
  An automatic depth S is resolved as M; append ` (automatic S)` to the depth only then, so the
  record reads `depth=M (automatic S)`.
- `.camunda/audit.md` — appended with: `Dry-run quantification → w<W>/d<D>` (table format consistent with the other audit entries).
- `.camunda/state.md` `Key Output` line — NOT updated.
- `OUTPUT_DIR/` — NOT created.
- `OUTPUT_DIR/.snapshots/` — NOT created.

### Precedence

| Flags passed | Effect |
| --- | --- |
| nothing | auto on both axes |
| `--size` only | both axes inherit |
| `--size` + `--width` | depth ← size, width explicit |
| `--size` + `--depth` | width ← size, depth explicit |
| `--width` + `--depth` (no `--size`) | both explicit; overall label recomputed |
| **`--size` + `--width` + `--depth`** | **error** — surface conflict, force re-decision |

A non-`auto` width or depth supplied by a flag or configuration (or chosen at the proceed prompt) is
**explicit**; `size: auto` and an axis left to quantification are **automatic**. Only an explicit
width or depth may drop or fold documented steps — see [the quantification sub-skill](references/quantification.md).

### Configuration source

Both CLI flag and `run.config.yaml` are accepted. Flag wins.

```yaml
# run.config.yaml (project-scoped default)
size: auto       # auto | s | m | l | xl
# width: l       # optional — overrides size on this axis only
# depth: l       # optional — overrides size on this axis only
```

Read them with:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/read-run-config.cjs" size
node ".github/skills/process-os-bpmn-generation/scripts/read-run-config.cjs" width
node ".github/skills/process-os-bpmn-generation/scripts/read-run-config.cjs" depth
```

`size` always resolves (schema default `auto`). `width` and `depth` have no schema
default — an exit of 1 with no output means the axis is unset and is derived from `size`.

The all-three-keys-present rule applies inside the config too.

### Run-unattended mode (natural-language detection, not a flag)

There is **no `--run-unattended` flag**. Run-unattended intent is detected from the natural-language prompt that triggered the skill invocation. The orchestrator inspects the user's invocation message before running step 4b and sets a `UNATTENDED=true` internal state when the prompt expresses non-interactive intent.

**Detection — both conditions must be met:**

1. The phrase is in the *user's* invocation message that triggered `/process-os-bpmn-generation`, not in a referenced .md file or in earlier conversation turns about a different task.
2. The phrase expresses skip-all-prompts intent. Trigger phrases (case-insensitive, fuzzy match):
   - `run unattended` / `run-unattended`
   - `don't ask` / `dont ask` / `no questions` / `skip questions` / `skip all prompts`
   - `just do it` / `just generate` / `just run`
   - `non-interactive` / `unattended`
   - `auto-confirm` / `auto confirm` / `confirm everything`
   - `proceed without asking` / `no prompts`

**Detection algorithm:** at the start of step 4b, the orchestrator runs a single deterministic regex sweep against the invocation prompt. If any trigger phrase matches, `UNATTENDED=true`. No LLM call — keep this cheap and predictable. Ambiguous wording (e.g. "I don't want to wait") does NOT trigger run-unattended; the user must use one of the listed phrases.

**When UNATTENDED=true**, the skill never prompts the user. The quantification report is still printed (for the audit trail), but every interaction point is auto-resolved:

| Decision point | Default behavior | Run-unattended resolution |
| --- | --- | --- |
| Final confirmation prompt before generation | wait for `[y / abort / change ...]` | proceed immediately |
| A and B agree | lock the agreed size | (same — no prompt) |
| A and B are 1 step apart | surface, ask user to pick | **pick A** (deterministic counting) |
| A and B are ≥ 2 apart, after one rerun still ≥ 2 apart | surface `[a / b / manual]` choice | **pick A** (deterministic counting) |
| All-three-flags-error (`--size` + `--width` + `--depth`) | surface, force re-decision | **still error and abort** — run-unattended does not paper over invalid input |

## Camunda Docs

Otherwise continue here.

### AI Agents in BPMN

If a step involves **AI-driven decision making**, **dynamic tool selection**, **LLM reasoning**, or an **AI agent** / **agentic behavior**, first apply the **AI decision rule** in `automatable-modeling.md` (single bounded model call → plain `serviceTask` + AI connector; only dynamic tool selection / 2+ conditional API calls / agentic → `bpmn:adHocSubProcess`). **Read `references/ai-in-bpmn.md` ONLY when that rule resolves to an ad-hoc sub-process** — it is ~5k tokens of construction detail (don't read it just to confirm a service task). When you do build one, it contains:

- Structural invariants (hard constraints on valid XML)
- A copy-ready XML template with placeholders
- `fromAi()` function reference for tool parameter definitions
- Examples of tools, sub-flows, and parent process integration

When an AI agent ad-hoc sub-process is used, the "no Zeebe extensions" constraint (see v1 Constraints) is relaxed for that element — Zeebe extension elements (`zeebe:taskDefinition`, `zeebe:ioMapping`, `zeebe:adHoc`, etc.) are required for the AI Agent connector to function.

## EXEC: Prerequisites

This is the **MODE=generate** path — MODE=edit branched out at *EXEC: Resolve input +
output* and never reaches here. `INPUT_DIR` and `OUTPUT_DIR` are already resolved there
(`--input` defaults to the last completed discovery iteration's `artifacts/`; `--output` is
caller-supplied); the literals below are illustrative — substitute the resolved values. No
further input resolution, mode-by-content detection, or `--input`/`--output` handling happens
here.

(Legacy `process-tobe/` / `process-optimize/` dirs carry no special meaning — the caller
points `--input` at whatever holds the source docs.)

## Camunda Docs

For any uncertain BPMN rule, element type, attribute, or constraint: read `references/camunda-docs.md` and call `search_camunda_knowledge_sources` (camunda-docs MCP). Do not rely on training data alone. If the MCP tool is not available, fall back to HTTP as described in `references/camunda-docs.md`.

## Connectors (automatable mode)

Connector binding applies only when `MODE=automatable`. Read
`references/connectors.md` and bind via
`c8ctl element-template apply` — c8ctl emits all connector attributes including the icon.
Strategic mode never binds connectors.

**Never Read an element-template JSON** — not from c8ctl's user-level catalogue, not from a
template saved to a file. A template's `icon.contents` is an SVG data URL: the Read tool
encodes it as image content, and the API rejects it with HTTP 400 "Could not process image" —
not a size limit, an unconditional failure at any size. Inspect a template with
`c8ctl element-template get-properties <id>` (settable properties) or
`c8ctl element-template info <id>` (the metadata card) — both are icon-free and well under the
read cap. `c8ctl element-template get` is not an inspection route: even with `--no-icon` it
still prints ~34 KB, over the cap. See [the connectors reference](references/connectors.md).

## AI Agents in BPMN

If a step involves **AI-driven decision making**, **dynamic tool selection**, **LLM reasoning**, or an **AI agent** / **agentic behavior**, apply the **AI decision rule** in `automatable-modeling.md` first, and **read `references/ai-in-bpmn.md` ONLY when it resolves to an ad-hoc sub-process** (not to confirm a plain service task). The "no Zeebe extensions" baseline is relaxed for AI-connector elements — `zeebe:taskDefinition`, `zeebe:ioMapping`, `zeebe:adHoc`, etc. are required for the connector to function.

## EXEC: Setup

**1. Create output directories.**

```bash
node -e "for (const d of ['OUTPUT_DIR', '.camunda/timing']) require('fs').mkdirSync(d, { recursive: true })"
```

`.camunda/timing/` is the parent for per-run versioned subdirs (`v<N>-w<W>-d<D>/`); the exact name is computed in step 4.5.

If any BPMN files already exist in `OUTPUT_DIR/`, snapshot them first. Under `--no-snapshot`,
skip this step:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/snapshot.cjs" save OUTPUT_DIR "*.bpmn" PROCESSES.md
```

Prints the created version (e.g. `v2`) when `OUTPUT_DIR` had `*.bpmn` to preserve before regeneration; prints nothing and creates no directory when it didn't.

**2. Write `.bpmnlintrc`** to project root (skip if it exists):

```json
{ "extends": "bpmnlint:recommended" }
```

**Nothing to resolve for bpmnlint.** `process-os-bpmn-linting`'s `validate.cjs` finds the centrally-installed bpmnlint itself, relative to the project root (`.camunda/node_modules` first, then the project root), and falls back to `npx --yes bpmnlint` only when neither has it. That fallback is why a missing bpmnlint is **not** covered by the deps gate above. Every lint call below just passes files.

**2b-kit. Resolve bpmnkit** (installed centrally by `c8 os install`).

The phase subagents build BPMN with `@bpmnkit/core` (pinned in the root
`package.json`, installed to `.camunda/node_modules/`). Presence is guaranteed by the deps
gate above, so this only resolves *where* it is.

Emit a project-relative import specifier from `OUTPUT_DIR` to the pinned entry — pasted
verbatim into each generator's `import`. `OUTPUT_DIR` is resolved above (*EXEC: Resolve input +
output*); every phase's `.gen.mjs` is written directly inside it, so one relative path computed
here is correct for every phase this run generates:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/resolve-bpmnkit-import.cjs" "<OUTPUT_DIR>"
```

Capture `BPMNKIT_IMPORT=…` and pass it verbatim to every Phase Generation subagent prompt. Never empty — the gate stops the run instead.
`@bpmnkit/core` is ESM-only, so `NODE_PATH` does **not** resolve it — phase scripts
import it by that relative specifier (`import { Bpmn } from "<BPMNKIT_IMPORT>"`) and run as
plain `node <script>.mjs` (see generate-phase.md). Node resolves a relative specifier against
the importing file's own location (`import.meta.url`), not `process.cwd()`, so this still works
regardless of which directory `node` is invoked from.

**3. List process files:**

```bash
node ".github/skills/process-os-bpmn-generation/scripts/list-files.mts" "INPUT_DIR/process-[0-9]*-*.md" "INPUT_DIR/edge-*.md" "INPUT_DIR/subprocess-*.md"
```

**Allowlist by inclusion — not exclusion.** Match ONLY the three phase-file shapes:
main phases `process-NN-*.md` (incl. `process-00-e2e.md`), edge cases `edge-*.md`,
subprocesses `subprocess-*.md` — the shapes `quantify.cjs` counts
(`/^process-\d+-.*\.md$/`, `/^edge-.*\.md$/`, `/^subprocess-.*\.md$/`).

**The listing must never miss a file `quantify.cjs` counts.** A glob cannot spell `\d+`, so
`process-[0-9]*-*.md` is deliberately a *superset*: it requires the digit that `\d+` does — so
`process-summary.md` is still not a phase — but any digit count satisfies it, and it also admits
a malformed `process-1x-intake.md`. That asymmetry is the point. Listing a file quantify does not
count is visible and harmless (one extra phase agent, on a filename that should not exist).
Missing one quantify *does* count is silent, and surfaces downstream as a coverage gap rather
than an error. Enumerating digit widths instead would fail exactly that way on
`process-100-billing.md`. Note each file path and basename.

The output is grouped by glob, not globally sorted, so it is not phase order — take the
phase order from each file's `NN`, not from the position it was listed in.

A plain `*.md` listing minus an exclusion list — `README`, `index`, `state` — does NOT work: real discovery output
always ships catalog/metadata docs — `as-is-process.md`, `gap-analysis.md`,
`participants-and-systems.md`, `data-objects.md`, `provenance.md`, `review-log.md`,
`annotations.md`, `00-index.md` — none of which are phases.
An exclusion list silently lets them through, so the parallel dispatch spawns one
subagent per metadata doc and emits garbage BPMNs. The inclusion allowlist is the
only safe form.

## AI: Quantification (boundary check + size counting)

**3a. Process instance boundary check + 3b. Quantification.**

Read `references/quantification.md` and follow its 3a/3b sections to lock `WIDTH`, `DEPTH`, and decide same-instance vs separate. The quantification doc covers: A counting, B sub-agents, comparison algorithm, dry-run early-exit, run-unattended mode, the report format, and depth-effect tables.

After quantification: if `--dry-run=true`, exit per quantification step 3b.f. Otherwise continue.

## GATE: Confirm size before generation

Review quantification report and confirm WIDTH/DEPTH before BPMN generation begins. In run-unattended mode, auto-resolved per the run-unattended table (A wins disagreements; ≥2-step splits still pick A).

**4. State:** `process-os-bpmn-generation` owns no `.camunda/state.md` lifecycle row — it is an internal engine invoked by other skills, which record their own phase state. Do not write a `process-os-bpmn-generation` row here.

**4.5. Compute SNAP_VERSION + create the versioned timing directory.**

`SNAP_VERSION` is reused in "Save Snapshots" so `OUTPUT_DIR/.snapshots/<SNAP_VERSION>/` pairs 1:1
with its timing record. The skill is single-threaded; no entry is added to `.snapshots/` between
this step and that one, so recomputing yields the same value. Under `--no-snapshot` there is no
snapshot entry to pair with — `TIMING_DIR` stands alone (see step 4.5's `snapshot.cjs next` call
below for its derivation in that case).

`TIMING_DIR` gets an extra tier suffix when `OUTPUT_DIR`'s own last path segment is a bare tier
keyword — three sibling per-tier directories generating in parallel would otherwise all compute
the same `SNAP_VERSION` (each tier's `.snapshots/` is counted independently, per-tier) and write
per-file timing records with overlapping basenames (`process-01-quoting.json` in every tier) into
one shared `.camunda/timing/<SNAP_VERSION>/` directory, corrupting the aggregate table /
`_summary.json`. `SNAP_VERSION` itself (and the
`.snapshots/` name) stay unsuffixed — only the global timing path gets the discriminator. Any
other `OUTPUT_DIR` keeps the unsuffixed `.camunda/timing/<SNAP_VERSION>/`.

**The suffix needs two conditions at once:** `OUTPUT_DIR`'s last segment is a bare tier keyword,
**and** the caller omitted `--no-snapshot` (with it, this step never runs at all). A lifecycle
phase writes into an iteration's `artifacts/`, whose last segment is never a tier keyword, and
generates with `--no-snapshot` — so the suffix is reachable only from an invocation that names a
tier-keyword output directory itself and keeps snapshots on.

```bash
node ".github/skills/process-os-bpmn-generation/scripts/snapshot.cjs" next OUTPUT_DIR --suffix "-w<WIDTH>-d<DEPTH>"
```

Prints the version label alone (e.g. `v3-wL-dM`) — no directory is created yet. Capture it as `SNAP_VERSION`, then derive `TIMING_DIR` as `.camunda/timing/<SNAP_VERSION>`, with an extra `-<tier>` suffix (`OUTPUT_DIR`'s last path segment) appended only when that segment is itself a bare tier keyword; any other `OUTPUT_DIR` has no suffix. No `mkdir` needed — `timing.cjs` creates the directory on its first `event` call.

Under `--no-snapshot`, skip this call — no `SNAP_VERSION` exists. Derive `TIMING_DIR` instead as
`.camunda/timing/<basename of OUTPUT_DIR's parent>-w<WIDTH>-d<DEPTH>`; for a discovery output dir
of `process-discovery/iteration-2/artifacts` that is `.camunda/timing/iteration-2-wL-dM`.

Capture both. Earlier runs' versioned timing dirs stay in place — historical record paired with their snapshot dirs.

## EXEC: Phase Plan + Progress Setup

**At `DEPTH=S` with 2+ `process-NN-*.md` files, skip 4a–4c below** (DEPTH=S here is always explicit — an automatic S is locked as M) — quantification.md's
"Depth=S — inlining algorithm" already collapses every `process-NN-*.md` into one combined file,
written to `<OUTPUT_DIR>/process-main.bpmn`. Create a **single** TodoWrite item for it —
`{ "id": "process-main", "content": "Generate process-main.bpmn", "status": "todo", "priority": "medium" }`
— and no `overview` item (depth=S skips the overview per the depth table). Proceed straight to it
with `BASENAME`/`OUTPUT_BPMN` set to `process-main` / `<OUTPUT_DIR>/process-main.bpmn`.

**At `DEPTH=S` with exactly one `process-NN-*.md` file, there is nothing to combine** — the
inlining algorithm doesn't apply. Run 4a–4c normally; the single TodoWrite item keeps that file's
own basename (e.g. `process-01-asis`), not `process-main`. This is the "naturally one phase file"
case the single-file short-circuit below expects.

**4a.** Read each phase file's first `# Heading` for the phase title.

**4b.** Print the generation plan:

```
Generating BPMN for <N> files:
  process-01-<name>       →  <Phase Title>
  process-02-<name>       →  <Phase Title>
  edge-case-<name>        →  <Title>
  subprocess-<name>       →  <Title>
  ...
+ 1 overview diagram (main phases only)
```

**4c.** Create the TodoWrite tracker — one item per file plus one for `overview`, all `status: "todo"`. Use the basename (without `.md`) as the `id`:

```json
{
  "todos": [
    { "id": "process-01-<name>", "content": "Generate process-01-<name>.bpmn", "status": "todo", "priority": "medium" },
    ...
    { "id": "overview", "content": "Generate 00-overview.bpmn", "status": "todo", "priority": "medium" }
  ]
}
```

**4d.** Mark every phase item (not `overview`) `in_progress` via TodoRead/TodoWrite.

## AI: Phase Generation (parallel)

**Single-file short-circuit (exactly 1 TodoWrite item → generate inline, no subagent).** If your
TodoWrite list has exactly **one** phase item (excluding `overview`), do **not** dispatch a
subagent — generate it **inline in this orchestrator context** instead. Two shapes land here:

- **Naturally one phase file** (the corpus only has one `process-NN-*.md` to begin with): read
  `references/generate-phase.md` and follow it for that one file, using the same field values
  listed in the per-file prompt below (`PHASE_FILE`, `REF_BPMN`, `OUTPUT_BPMN`, `MODE`, `WIDTH`,
  `WIDTH_SOURCE`, `BASENAME`, `BPMNKIT_IMPORT`, `TIMING_DIR`).
- **`DEPTH=S` merge of multiple phase files** (the item is `process-main`): follow
  quantification.md's "Depth=S — inlining algorithm" instead — it reads every
  `process-NN-*.md` and concatenates them into the one flow itself, so `generate-phase.md`'s
  single-file walkthrough does not apply verbatim. `OUTPUT_BPMN` is
  `<OUTPUT_DIR>/process-main.bpmn` and `BASENAME` is `process-main`; still run the same lint /
  timing steps a normal phase generation would.

A subagent for a single output buys **no parallelism** and costs a full second context-load +
round-trip (~200s of measured wall). After it generates and lints clean, continue to the timing
aggregation and the rest of the flow; in the centralized lint gate there is **no producing
subagent** — lint and fix the file directly here. Skip the rest of this section.

**Two or more phase files → fan out (below).**

**Dispatch all phase agents simultaneously** — run one subagent per file as an independent agent:

- **Claude Code:** issue ALL `Agent()` calls in a **single assistant turn** (one tool-message with N `tool_use` blocks — one per phase file in your TodoWrite list, excluding `overview`) and nothing else — no `Read`, no `Bash`, no `TodoWrite` updates, no thinking out loud between dispatches. Do not emit agents one-by-one across turns — that serialises execution. Past runs that dispatched these one-by-one cost an extra ~25 min of wall time — this is the single largest source of waste in process-os-bpmn-generation. If you find yourself preparing one Agent call and considering reading or computing anything before the next, stop and re-batch all N into one response. Results are awaited together before continuing.
- **Other platforms:** invoke each phase sub-skill sequentially if parallel dispatch is not available.

**These agents have no inter-phase dependencies — they MUST run in parallel.**

Per-file prompt:

```
Read references/generate-phase.md and follow it.

PHASE_FILE:    <INPUT_DIR>/<basename>.md
REF_BPMN:      <INPUT_DIR>/<basename>.bpmn if it exists, else "none"
OUTPUT_BPMN:   OUTPUT_DIR/<basename>.bpmn
MODE:          <strategic|automatable>
WIDTH:         <s|m|l|xl>
WIDTH_SOURCE:  <explicit|auto>
BASENAME:      <basename>
BPMNKIT_IMPORT: <relative-import-specifier-from-Setup-step-2b-kit>
TIMING_DIR:    <abs-or-relative-path-from-Setup-step-4.5>
```

Field semantics:

- `BASENAME` — names the per-subagent timing record.
- `REF_BPMN` — set only when a `*.bpmn` with the same basename sits in `INPUT_DIR` alongside
  the `*.md` (the "both kinds present" case). It is **supplementary reference**: the agent
  reads it for existing element names, structure, and layout worth preserving, but the
  `PHASE_FILE` markdown still drives the model. `"none"` → generate purely from the markdown.
- `TIMING_DIR` — every `timing.cjs` invocation in the subagent MUST pass `--dir "<TIMING_DIR>"` (the Bash tool starts a fresh shell per call; an exported var would not survive). See `generate-phase.md` "Timing instrumentation".

Wait for all agents to complete. **Record the `agentId` from each Agent result,
keyed by `BASENAME`** (every result prints `agentId: a…`) — the centralized lint
gate below routes each file's findings back to the subagent that produced it. Then:

1. **Run the centralized lint gate** (see "## GATE: Centralized lint" immediately
   below) before anything else — the cross-file checks that follow assume every
   generated file is structurally valid.

2. Aggregate timing:
```bash
   node ".github/skills/process-os-bpmn-generation/scripts/timing.cjs" --dir "<TIMING_DIR>" aggregate
```
   Prints a per-file table (duration, MCP calls, connector resolutions, HTTP fetches, lint runs, lint fixes) and writes `<TIMING_DIR>/_summary.json`. Surface the table to the user.

3. TodoRead → set every phase item `completed`, mark `overview` `in_progress` → TodoWrite.

## GATE: Centralized lint (route per-file to producing subagent)

The PostToolUse lint hook is a **fast-path, not a guarantee**. It does not fire when
the plugin's hooks aren't active for the session (plugin installed/updated
mid-session, or dev/worktree/eval/CI runs), and it may not fire for **subagent** tool
calls at all. So a phase subagent that saw no findings surface has NOT been told its
file is clean — it may simply never have been linted. This gate is the authoritative
check; never skip it assuming the hook ran.

Lint each generated phase/edge file, partition findings by file, and route each
file's findings back to the subagent that produced it (using the `BASENAME → agentId`
map recorded at dispatch).

**Inline (single-file short-circuit) case:** if the file was generated inline (no subagent
was dispatched), there is no `agentId` to route to — skip the `SendMessage` routing and fix
the file **directly here** via its `.gen.mjs` fix-loop. The lint command in step 1 still
applies.

1. **Lint every `OUTPUT_DIR/process-*.bpmn`, `OUTPUT_DIR/edge-*.bpmn`, and
   `OUTPUT_DIR/subprocess-*.bpmn`
   individually** with the same structural config the hook's `lint-hook.cjs` uses
   (profile by `isExecutable`; strategic/non-executable shown here). **Redirect each file's
   output to its own file — never capture lint inline.** A broken XL BPMN can emit lint
   output larger than the harness's ~25 KB Bash-stdout buffer, which returns
   `parser aborted (timeout, resource limit, or over-length)` instead of the diagnostics and
   sends the fix-loop into an unbreakable retry. The per-file redirect + Read tool (which
   paginates) avoids it:

   ```bash
   node ".github/skills/process-os-bpmn-generation/scripts/lint-to-files.cjs" OUTPUT_DIR "process-*.bpmn" "edge-*.bpmn" "subprocess-*.bpmn"
   ```
   (`00-overview.bpmn` is excluded by the three patterns — it has no producing subagent and is
   linted in its own section. Exit `1` is findings, exit `2` means some file was never linted —
   see [the bpmnlint invocation reference](references/lint-bpmn.md).)

   The `EXIT:` lines tell you which files are non-clean (non-zero); **Read** each non-clean
   file's `.camunda/.lint/<basename>.txt` with the Read tool (never `cat` it into a Bash
   result). **Guard:** if a lint file contains `parser aborted` / `over-length`, that file is
   too large to lint inline — do **not** retry; report the harness limit and lint that one
   file in isolation.

2. **Route ONLY each non-clean file's findings to its producer.** Issue the
   `SendMessage` calls for all non-clean files in a **single response** so fixes run
   concurrently — each subagent touches only its own `.gen.mjs`, no
   cross-contamination:

```
  SendMessage(to: "<agentId for this BASENAME>", message:
     "The centralized lint gate found these issues in YOUR file
      OUTPUT_DIR/<basename>.bpmn (the PostToolUse hook is inactive this session,
      so it never surfaced them). Fix via your `.gen.mjs` fix-loop: edit
      <basename>.bpmn.gen.mjs, re-run `node <OUTPUT_BPMN>.gen.mjs`, lint again until
      clean. Do NOT delete the `.gen.mjs`. Report back.
      Findings:
      <paste ONLY this file's findings block>")
```
   Files that lint clean get no message.

3. **Verify, don't trust.** When a subagent reports done, **re-lint that file
   yourself** (step 1's command for the one file). A subagent can report clean
   wrongly, and the hook is not there to confirm.

4. **Fallback.** If a subagent stalls / can't be re-engaged, or after one resume it
   still has errors, fix that file directly (edit its `.gen.mjs`, re-run the layout
   orchestrator, re-lint). Do not block the whole run on one flaky subagent.

5. **Errors block, warnings don't.** Every file must reach **0 errors**. Warnings
   (e.g. `no-overlapping-elements` on a dense boundary-event activity) are surfaced
   and attempted, but non-blocking.

6. **Keep the generator scripts.** `OUTPUT_DIR/*.bpmn.gen.mjs` are kept permanently
   alongside their `.bpmn` output, not deleted once files lint clean — they are the
   bpmnkit source that produced the diagram and the fix-loop artifact for any future
   regeneration (re-run `node <OUTPUT_BPMN>.gen.mjs` after editing).

## EXEC: Start Event Uniqueness Check (extract names)

Verify start event names are unique across `process-*.bpmn`:

```bash
node -e '
const fs = require("fs");
const path = require("path");
const dir = "OUTPUT_DIR";
for (const f of fs.readdirSync(dir).filter(n => /^process-.*\.bpmn$/.test(n)).sort()) {
  const xml = fs.readFileSync(path.join(dir, f), "utf8");
  for (const m of xml.matchAll(/<bpmn:startEvent[^>]*name="([^"]*)"/g)) {
    console.log(`${path.join(dir, f)} ${JSON.stringify(m[1])}`);
  }
}
'
```

If all distinct → proceed to Overview BPMN. If any two share or are near-identical (same words, different tense/phrasing):

## AI: Fix duplicate start event names

- **Parent process**: the one whose flow contains a task that triggers the other.
- **Child process**: the one invoked by a task in the parent.
- **Rename parent start event** to a more generic business trigger.
- **Rename child start event** to describe the parent's state immediately before the call (e.g. `Order validated`, `Invoice approved by manager`). Find that preceding state by extracting the parent — never `Read` the `.bpmn`, an automatable one runs well over the Read cap:

  ```bash
  node ".github/skills/process-os-bpmn-generation/scripts/bpmn-extract.cjs" "OUTPUT_DIR/<parent>.bpmn" --topology
  ```

  `--topology` is required: `elements` is in XML close-tag order, not flow order, so the predecessor is only reachable via `sequenceFlows`. Locate the element that invokes the child, then take the flow whose `targetRef` is that element's `id` — its `sourceRef` names the predecessor, and that predecessor's `name` is the state to describe. Exit `2` → bad input — report stderr and stop. Exit `3` → the parent is over the cap even alone; take the preceding step from its phase markdown at `INPUT_DIR/<parent>.md` instead (`--names` is no fallback here — it drops `sequenceFlows`).
- Apply each rename by **editing the `name` in that file's `.gen.mjs` and re-running the standard
  layout-and-cleanup command**, never by hand-editing the `.bpmn`. The re-run regenerates the whole
  DI section, so label bounds need no manual recompute. Re-lint each renamed file afterwards.

## EXEC: Error Propagation Check (extract error end events)

Find error end events across phase BPMNs:

```bash
node -e '
const fs = require("fs");
const path = require("path");
const dir = "OUTPUT_DIR";
for (const f of fs.readdirSync(dir).filter(n => /^process-.*\.bpmn$/.test(n)).sort()) {
  const xml = fs.readFileSync(path.join(dir, f), "utf8");
  for (const m of xml.matchAll(/<bpmn:endEvent[^>]*name="([^"]*)"[^>]*>([\s\S]*?)<\/bpmn:endEvent>/g)) {
    if (m[2].includes("errorEventDefinition")) console.log(`${path.join(dir, f)} ${m[1]}`);
  }
}
'
```

If none → proceed to Overview BPMN.

## AI: Fix error propagation gaps

For each phase with error end events, check whether any other phase file references it as a called process (look for its process name or phase title in tasks/annotations of other phase files):

- **Parent identified**: open its BPMN and verify the calling task has a `<bpmn:boundaryEvent>` with `<bpmn:errorEventDefinition>`. If missing, add it in the parent's `.gen.mjs` with
  `.withBoundary("<id>", { errorCode: "<code>" }, h => h.…)` and re-run — routing to an error handler or error end event in the parent.
- **No parent calls the child**: no change — the error end event stands as a terminal exceptional outcome.

**Enforce none start/end events on confirmed child processes.** For every child:

- `<bpmn:startEvent>` must have **no** event definition child (`messageEventDefinition`, `signalEventDefinition`, `timerEventDefinition`, etc.). Remove if present — must be plain none start.
- Every `<bpmn:endEvent>` on the **normal** completion path must have **no** event definition child. Error end events on exceptional paths are exempt.

Fix every violation in the file's `.gen.mjs` — drop the `messageName` / `signalName` /
`timerDuration` option from that `.startEvent(...)` / `.endEvent(...)` call — then re-run the
standard layout-and-cleanup command and re-lint. Never hand-edit the `.bpmn`: it desyncs the
generator that update mode (`--target/--from`) re-derives the diagram from, and hand-added
elements get no DI.

**Do not reach for bpmnkit's operations API here.** Even the lossless `applyBpmnOperations`
re-serializes the whole document, so a one-element fix arrives as a whole-file diff — and the
`compactify` round-trip additionally drops every `textAnnotation` and `association` with its DI.
Fix the `.gen.mjs` and re-run.

## AI: Overview BPMN

One overview BPMN inline (no subagent), built with **bpmnkit** like the phases — never
hand-written XML. One abstract `<bpmn:task>` per **main phase** only — `process-NN-*.md`
files, sorted by number. Edge cases and subprocesses are not included.

1. Filter to `process-NN-*.md` files. Read each first `# Heading` for the title. Read the
   process name from `.camunda/state.md`.
2. Write `OUTPUT_DIR/00-overview.bpmn.gen.mjs`: start event → one `.task()` per phase
   (in number order) → end event. `.task()` emits a plain abstract `<bpmn:task>` — the right
   element for a phase box — with no Zeebe, so no post-export stripping. Worked script:

```javascript
  import { Bpmn } from "<BPMNKIT_IMPORT>";
   import { writeFileSync } from "node:fs";

   let p = Bpmn.createProcess("OverviewProcess").name("<Process Name> — Overview")
     .startEvent("StartEvent_Overview", { name: "<trigger>" });
   // one .task() per main phase, in number order:
   p = p.task("Task_Phase01", { name: "<Phase 1 title>" });
   p = p.task("Task_Phase02", { name: "<Phase 2 title>" });
   // …
   const b = p.endEvent("EndEvent_Overview", { name: "<final state>" })
     .executable(false).executionPlatformVersion("8.9.0");
   const defs = process.env.BPMN_LAYOUT === "bpmnkit" ? b.withAutoLayout().build() : b.build();

   writeFileSync("<OUTPUT_DIR>/00-overview.bpmn", Bpmn.export(defs));
   console.log("written");
```

3. Run it with the **same layout orchestrator** the phases use. It starts with a bpmnkit
   DI scaffold, lets bpmn-io produce final geometry, and uses the restored bpmnkit baseline
   for node placement and edge cleanup only when bpmn-io fails:
```bash
   node ".github/skills/process-os-bpmn-generation/scripts/layout-bpmn.cjs" "OUTPUT_DIR/00-overview.bpmn.gen.mjs" "OUTPUT_DIR/00-overview.bpmn"
```
   It runs `00-overview.bpmn.gen.mjs`, then bpmn-io layout and the DI check. If either fails,
   it regenerates the BPMN with bpmnkit layout and runs the bpmnkit cleanup steps.
4. Lint `00-overview.bpmn` (the hook may fire on the `.gen.mjs` token but is not
   guaranteed — lint explicitly with the same structural config; redirect, then Read):
   ```bash
   node ".github/skills/process-os-bpmn-generation/scripts/lint-to-files.cjs" OUTPUT_DIR 00-overview.bpmn
   ```
   Read `.camunda/.lint/00-overview.txt` (skip on `EXIT:0`). Fix all errors and warnings by
   **editing the `.gen.mjs` and re-running**, never by hand-editing the BPMN.
5. Keep `OUTPUT_DIR/00-overview.bpmn.gen.mjs` — it is not deleted, same as every other
   phase's generator script.
6. TodoRead → set `overview` `completed` → TodoWrite.

## AI: Generate Documentation

Operates on `OUTPUT_DIR` (resolved in *EXEC: Resolve input + output*) — reached both from
the generate flow here and from *EXEC: Edit mode* Step 6.

Skip-check:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/read-run-config.cjs" skip-bpmn-docs
```

It prints `true` or `false` (default `false`). Skip `PROCESSES.md` only when it prints `true` — skip this section, go to Save Snapshots.

Otherwise write `OUTPUT_DIR/PROCESSES.md` **inline in this conversation, using the `Write` tool directly**. This is mechanical extraction (element names from already-generated BPMN), not analysis — **do NOT spawn an `Agent` subagent for this step.** Past runs that delegated this write burned several minutes in subagent setup for a task that takes one Write call. Element names must match the BPMN exactly so reviewers can locate any element instantly.

**Never Read the generated `.bpmn` files** — a connector-bound one runs several times over the Read
tool's ~25 KB cap, and a whole `OUTPUT_DIR` batch multiplies that. Extract instead:
```bash
node ".github/skills/process-os-bpmn-generation/scripts/bpmn-extract.cjs" OUTPUT_DIR --names
```

Exit `2` → bad input (missing path, no `.bpmn` files, a dangling `--exclude`, or a malformed `--max-bytes`) — report stderr and stop. Exit `3` means the report itself is over the cap — re-run it one file at a time.

**Then, for each BPMN** (overview first, then phases in order):

1. Take every named element from the report's `elements` for that file: start events, tasks, gateways, end events. Preserve the exact `name` field value — no paraphrasing.
2. Write one `## <Phase Title>` section (use the phase title from the `# Heading` of the source phase file; use "Overview" for `00-overview.bpmn`).

**Section format:**

```markdown
## <Phase Title>

> File: `OUTPUT_DIR/<filename>.bpmn`

<One paragraph describing the overall purpose of this process/phase.>

### Elements

| Element | Type | Description |
|---------|------|-------------|
| `<exact name from BPMN>` | Start Event | <what triggers this process> |
| `<exact name from BPMN>` | Task | <what happens, who does it or what system> |
| `<exact name from BPMN>` | Gateway | <decision question + branch labels> |
| `<exact name from BPMN>` | End Event | <outcome reached> |
```

**Writing rules:**
- Element names in backticks, exact match.
- Descriptions drawn from the source phase file. One sentence each. No filler.
- Gateway rows: decision question + branch labels (e.g. "Yes → happy path, No → rejection").
- Omit unlabeled joining gateways (structural only).
- Overview section: one sentence per phase task.

Top-level heading: `# Process Documentation` + brief intro line naming the process (from `.camunda/state.md`).

## EXEC: Save Snapshots

Each run creates the next versioned snapshot directory under `OUTPUT_DIR/.snapshots/`. The matching `.camunda/timing/<SNAP_VERSION>/` already exists from Setup step 4.5 — leave it; the suffix correlates the BPMN snapshot with its timing data 1:1. Under `--no-snapshot`, skip this call — `OUTPUT_DIR` is itself the caller's version history, so there is nothing to write under `.snapshots/`:

```bash
node ".github/skills/process-os-bpmn-generation/scripts/snapshot.cjs" save OUTPUT_DIR "*.bpmn" "*.md" --suffix "-w<WIDTH>-d<DEPTH>"
```

Recomputes the same version number Setup step 4.5 did (the invariant above) and prints it bare — e.g. `v3-wL-dM`. `*.md` is copied best-effort — a directory with no `.md` files yet still gets its `*.bpmn` snapshotted. Timings for this run live at `.camunda/timing/<SNAP_VERSION>/`.

Existing `OUTPUT_DIR/.snapshots/v*/` directories without size suffix are still readable; new runs increment correctly.

## EXEC: Audit Entry

**Skip this entire step when `EMBEDDED=true`** (see *Resolve input + output* step 1b — the caller records its own audit line).

```bash
node ".github/skills/process-os-bpmn-generation/scripts/append-audit.cjs" process-os-bpmn-generation "Generated [N] BPMN files at w<WIDTH>/d<DEPTH> → snapshot <SNAP_VERSION>"
```

Replace `[N]` with the actual file count, and `<WIDTH>`, `<DEPTH>` and `<SNAP_VERSION>` with the
values resolved earlier in this skill. Under `--no-snapshot`, no `SNAP_VERSION` was computed
(step 1c) — omit the `→ snapshot <SNAP_VERSION>` clause: `"Generated [N] BPMN files at
w<WIDTH>/d<DEPTH>"`.

## AI: Write Memory Entry

**Skip this entire step when `EMBEDDED=true`** (see *Resolve input + output* step 1b — the caller owns discovery-phase memory).

Read `.camunda/memory.md`. Locate `## BPMN Decisions`. Synthesize 3–6 bullets covering: phases generated (count + names), width/depth (auto vs forced; A/B agreement), notable modeling choices (event/gateway types, deviations), constraints applied (v1 Constraints below), snapshot version + size suffix.

Append to the section, preceded by `<!-- [today YYYY-MM-DD] -->`:

```markdown
<!-- 2026-05-01 -->
- Generated 16 BPMN files at width=L, depth=L (auto-detected)
- Width A: L (avg score 23.75 over 8 process files); B: L; agreed
- Depth A: L (score 22.4); B: M; surfaced 1-step disagreement; user picked L
- Snapshot: v3-wL-dL
- Notable: depth=L generated synthesized e2e (process-00-e2e.md absent in input)
```

Run-unattended variant records the resolution explicitly:

```markdown
<!-- 2026-05-01 -->
- Generated 16 BPMN files at width=L, depth=L (run-unattended, auto-detected)
- Width A: L; B: L; agreed
- Depth A: L; B: M; 1-step apart; run-unattended picked A
- Snapshot: v3-wL-dL
```

## EXEC: Final State Update

`process-os-bpmn-generation` is an internal engine and owns no `.camunda/state.md` lifecycle
row. Do not update state here — the invoking lifecycle skill
(`process-os-process-discovery`, `process-os-process-transformation`, …) marks its own phase Done.

## EXEC: Output

```
BPMN generation complete.

Generated: OUTPUT_DIR/
  00-overview.bpmn              ← main phases only
  00-overview.bpmn.gen.mjs      ← bpmnkit source — kept, re-run after edits
  process-01-[phase].bpmn
  process-01-[phase].bpmn.gen.mjs
  process-02-[phase].bpmn
  process-02-[phase].bpmn.gen.mjs
  edge-case-[name].bpmn         ← if present in input
  subprocess-[name].bpmn        ← if present in input
  ...
  PROCESSES.md                  ← human-readable companion (element names match the BPMN exactly)

All files validated and fixed with /process-os-bpmn-linting. Each .bpmn.gen.mjs is kept next to its
output — edit it and re-run `node <file>.bpmn.gen.mjs` to regenerate instead of
hand-editing the BPMN.

Auto-layout: bpmnkit's `.withAutoLayout()` creates the DI scaffold. bpmn-io
(`bpmn-auto-layout`) produces final geometry. If bpmn-io or the DI check fails, bpmnkit is
regenerated and node-placement plus edge-cleanup repair that recovery result.

Review options:
  /process-os-file-viewer   ← open a local bpmn-js viewer in your browser

Feedback workflow:
  1. Open any .bpmn file in Camunda Modeler
  2. Add a text annotation to any element (+ an association arrow), or edit elements directly
  3. Save the file, then run /process-os-bpmn-to-md-sync --from <that.bpmn> --to <its .md>
  The AI reconciles your edits back into the documentation (guided). To rebuild the
  generated diagram/layout afterward, re-run /process-os-bpmn-generation --target <that.bpmn> --from <its .md>.
  (Inside a discovery/transformation run, /process-os-process-discovery and
  /process-os-process-transformation drive this sync-back automatically when folding in feedback.)

Cross-run timing trends:
  node ".github/skills/process-os-bpmn-generation/scripts/timing.cjs" list
  ← one row per versioned run (BPMN snapshot dirs and .camunda/timing/v* share a suffix).
    Transformation runs pass --no-snapshot, so they appear as iteration-<N>-w<W>-d<D> rows
    instead — one per transformation iteration, the same no-snapshot label shape discovery uses.
```

## v1 Constraints

- One default branch per gateway (continues main flow). Non-default branches end with `endEvent`.
- Max one non-default branch per gateway. Chain sequential gateways for more complex splits.
- Use parallel gateways only when the input marks concurrency **explicitly**: steps sharing a `**Parallel group:**` value, or a `[AND-Gateway]` (`[ParallelGateway]`/`[AND-Split]`/`[AND-Join]`) parallel-split marker paired with its join. Map split → one branch per parallel stream/step → join to a `<bpmn:parallelGateway>` fork/join pair. Do not introduce parallelism from unmarked prose (a "parallel"/"fans out"/"meanwhile" narrative with no marker).
- No pools, lanes, or collaboration diagrams.
- No Zeebe/Camunda execution extensions — pure BPMN 2.0 only. **Exceptions:** (1) AI Agent ad-hoc sub-processes (see "AI Agents in BPMN"); (2) connector-bound elements (see "Connectors (automatable mode)"); (3) a call activity's `zeebe:calledElement`, kept in both modes.
