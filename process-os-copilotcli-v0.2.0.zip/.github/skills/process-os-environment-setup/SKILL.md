---
name: process-os-environment-setup
description: >-
  Install and start Camunda 8 locally for development via c8ctl. Verifies Java,
  installs c8ctl, downloads the latest cluster, starts it.
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
**Kubernetes / self-managed:** if the user mentions Kubernetes, Helm, EKS, GKE, or a self-managed cluster, stop here and read `references/env-helm.md` instead. The rest of this skill is for local development only.

**SaaS:** if the user wants to connect to a Camunda SaaS cluster instead of running locally, read `references/env-saas.md` instead.

Set up a local Camunda 8 development environment using `c8ctl cluster`. Read `references/c8ctl.md` for the full c8ctl reference — this skill uses just the cluster plugin and the JSON output mode.

## Steps

### 1. Check if a local cluster is already running

```bash
node ".github/skills/process-os-environment-setup/scripts/http-request.cjs" --status-only http://localhost:8080/v2/topology
```

It prints the status code, or `UNREACHABLE` when nothing is listening. `200` means a local cluster
is already running — skip to step 5 (verify c8ctl matches), then print the summary. Anything else,
`UNREACHABLE` included, means there is no cluster to reuse: continue with step 2.

### 2. Check Java

Camunda 8 supports **OpenJDK 21–25**. Install JDK 25 to match the project's worker and test targets. Check with `java -version`. If missing or wrong version, tell the user to install JDK 25 and set `JAVA_HOME`.

**asdf/mise users**: `java -version` may succeed in an interactive shell but the cluster will fail to start in the background because asdf shims don't set `JAVA_HOME`. Detect:

```bash
node ".github/skills/process-os-environment-setup/scripts/probe-java-manager.cjs"
```

Prints one `<manager>: <path>` line per version manager actually on `PATH` (or `NOT CONFIGURED`
if that manager has no java set), or `no version manager detected` if neither is installed —
`NOT CONFIGURED` and "not installed" are both answers, not step failures; only a **path printed
for a manager** or the JDK version check above is a real signal. If a path is returned, set
`JAVA_HOME` to it before starting the cluster, with the form the shell supports:

```text
# bash / zsh
export JAVA_HOME="/path/from/asdf-or-mise"

# PowerShell 5.1+
$env:JAVA_HOME = "C:\path\from\asdf-or-mise"
```

### 3. Install c8ctl

```bash
node ".github/skills/process-os-environment-setup/scripts/probe-tools.cjs" c8ctl
```

If that prints a version, c8ctl is already installed — skip ahead. If it prints `NOT FOUND`,
install it:

```bash
npm install -g @camunda8/cli
```

Requires Node.js >= 22.18.0. Available on `PATH` as `c8ctl` (and alias `c8`).

### 4. Set output mode to JSON

```bash
c8ctl output json
```

Persists the preference. All later c8ctl invocations in this skill (and across the lifecycle) return JSON to stdout — agent-parseable.

### 5. Start the cluster

```bash
c8ctl cluster start
```

Pulls the latest stable Camunda 8 release on first run and starts it in the background. Subsequent runs reuse the cached version. Pass an explicit version if needed:

```bash
c8ctl cluster start 8.9        # specific minor
c8ctl cluster start alpha      # latest pre-release
```

Verify ready:

```bash
node ".github/skills/process-os-environment-setup/scripts/http-request.cjs" --status-only http://localhost:8080/v2/topology
```

`200` means the broker is accepting requests. Cold start typically takes 30–60 seconds, and until the
port is bound the probe prints `UNREACHABLE` — poll until ready.

### 6. Connector secrets (optional)

If the process uses connector secrets, set them as environment variables **before** starting the cluster. Store them in a gitignored `.env` file:

```dotenv
# .env (gitignored)
MY_SECRET=value
OTHER_SECRET=value
```

Loading a `.env` into the process environment has no cross-shell spelling — use the form the shell
supports, and start the cluster in the **same** command. Shell state does not survive between tool
calls, so a `c8ctl cluster start` of its own runs in a fresh shell with none of the secrets:

```text
# bash / zsh
set -a; . /path/to/project/.env; set +a; c8ctl cluster start

# PowerShell 5.1+
Get-Content /path/to/project/.env | ForEach-Object { if ($_ -match '^\s*([^#=]+)=(.*)$') { Set-Item -Path "env:$($matches[1].Trim())" -Value $matches[2].Trim() } }; c8ctl cluster start
```

`{{secrets.MY_SECRET}}` in BPMN resolves to the `MY_SECRET` env var. `CAMUNDA_CONNECTOR_SECRETS_*` prefixes do NOT work.

To stop and restart with new secrets: `c8ctl cluster stop`, then `c8ctl cluster start`.

### 7. Stop / status

```bash
c8ctl cluster status   # is anything running, on which version
c8ctl cluster stop     # stop the running cluster
c8ctl cluster logs     # stream broker logs
```

### 8. Summary

Print the URLs:

- REST API: <http://localhost:8080/v2/>
- Operate: <http://localhost:8080/operate>
- Tasklist: <http://localhost:8080/tasklist>
- Zeebe gRPC: localhost:26500

No authentication required. Default credentials for web UIs: demo/demo.
