#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Where a JVM version manager's `java` shim actually points, if one is in use.
//
// `java -version` can succeed in an interactive shell while a background
// `c8ctl cluster start` still can't find Java, because asdf/mise shims don't
// set `JAVA_HOME` — only `asdf where java` / `mise where java` reveal the
// real install path. A bare `<manager> where java` in a doc's shell fence
// risks the same PowerShell 5.1 trap `probe-tools.cjs` exists for: a manager
// that isn't in use exits non-zero with output on stderr, which PowerShell
// 5.1 promotes to a terminating error rather than a plain failed exit.
// Routing through `findOnPath` + `runShellCli` keeps "manager not installed"
// and "manager installed, no java set" both readable as answers rather than
// step failures — and skips invoking whichever manager isn't on PATH at all,
// so there is nothing for that promotion to catch.
//
// Usage:
//   node "probe-java-manager.cjs"
//
// stdout, one line per manager found on PATH (a manager entirely absent from
// PATH is omitted, not reported):
//   asdf: /home/user/.asdf/installs/java/21.0.1/bin/java
//   mise: NOT CONFIGURED
// If neither asdf nor mise is on PATH:
//   no version manager detected
//
// Exit codes:
//   0  always — absence (of a manager, or of a configured java) is an
//      answer, not a step failure

const { findOnPath, runShellCli } = require('./resolve-node-cli.cjs');

const EXIT = { OK: 0 };

const NOT_CONFIGURED = 'NOT CONFIGURED';

const MANAGERS = ['asdf', 'mise'];

const NONE_DETECTED = 'no version manager detected';

/**
 * Ask one manager where its `java` shim points.
 *
 * @param {string} manager `asdf` or `mise`.
 * @param {object} [deps]
 * @param {typeof runShellCli} [deps.run] Injectable runner, for tests.
 * @returns {string} The path the manager reports, or `NOT CONFIGURED`.
 */
function probeManager(manager, deps = {}) {
  const run = deps.run || runShellCli;

  const result = run(manager, ['where', 'java'], { encoding: 'utf8' });
  // Not launched, or exited non-zero (no java set under this manager) —
  // neither is a version, so report the same answer as "not configured".
  if (!result.launched || result.status !== 0) return NOT_CONFIGURED;
  // Some managers print to stderr on success; either stream is the path here.
  const output = `${result.stdout || ''}\n${result.stderr || ''}`;
  const first = output.split('\n').find((line) => line.trim() !== '');
  return first ? first.trim() : NOT_CONFIGURED;
}

/**
 * @param {object} [deps] Passed through to {@link probeManager}.
 * @param {typeof findOnPath} [deps.onPath] Injectable PATH probe, for tests.
 * @returns {string[]} Report lines, one per manager present on PATH.
 */
function probeAll(deps = {}) {
  const onPath = deps.onPath || findOnPath;
  const present = MANAGERS.filter((manager) => onPath(manager));

  if (present.length === 0) return [NONE_DETECTED];
  return present.map((manager) => `${manager}: ${probeManager(manager, deps)}`);
}

module.exports = { EXIT, NOT_CONFIGURED, NONE_DETECTED, MANAGERS, probeManager, probeAll };

if (require.main === module) {
  process.stdout.write(`${probeAll().join('\n')}\n`);
  process.exit(EXIT.OK);
}
