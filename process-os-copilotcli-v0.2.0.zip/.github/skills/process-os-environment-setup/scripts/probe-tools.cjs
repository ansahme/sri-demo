#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Report the installed version of each named CLI, or that it is absent.
//
// A per-tool `cmd --version 2>/dev/null || echo "NOT FOUND"` one-liner doesn't
// survive PowerShell 5.1: `||` is a parse error there, `head` does not exist,
// and `2>/dev/null` creates a file called `/dev/null` rather than discarding.
// The discard matters on both shells — without it PowerShell 5.1 promotes ANY
// native-command stderr output to an error record, so a healthy tool that
// prints its version banner to stderr surfaces as a failure.
//
// `c8ctl` is the reason this is a script rather than three one-liners: on Windows
// it exists only as `c8ctl.cmd`, so a bare spawn raises ENOENT even though
// `c8ctl --version` works in the shell. Everything here goes through the reviewed
// `findOnPath` + `runShellCli` pair, which settles "is it on PATH" before any
// shell can absorb the answer.
//
// Usage:
//   node "probe-tools.cjs" <tool>...
//
// stdout, one line per tool in the order given:
//   node: v22.18.0
//   gh: gh version 2.62.0 (2024-11-14)
//   c8ctl: NOT FOUND
//
// Only the FIRST line of a tool's output is reported — `gh --version` prints
// three, and the extra lines are noise in a prerequisites table.
//
// Exit codes:
//   0  every tool was probed (whether found or not — absence is an answer here,
//      which is why an optional CLI being missing must not fail the step)
//   2  usage error

const {
  findOnPath,
  runShellCli,
} = require('./resolve-node-cli.cjs');

const EXIT = { OK: 0, USAGE: 2 };

const NOT_FOUND = 'NOT FOUND';

const USAGE = 'usage: probe-tools.cjs <tool>...\n';

/**
 * Probe one tool.
 *
 * @param {string} tool Bare command name, e.g. `c8ctl`.
 * @param {object} [deps]
 * @param {typeof findOnPath} [deps.onPath] Injectable PATH probe, for tests.
 * @param {typeof runShellCli} [deps.run] Injectable runner, for tests.
 * @returns {string} The first line of its `--version` output, or `NOT FOUND`.
 */
function probe(tool, deps = {}) {
  const onPath = deps.onPath || findOnPath;
  const run = deps.run || runShellCli;

  if (!onPath(tool)) return NOT_FOUND;
  const result = run(tool, ['--version'], { encoding: 'utf8' });
  // A tool on PATH that could not be launched, or that failed, is not a version
  // — reporting a blank line as one would put an empty cell in the report.
  if (!result.launched || result.status !== 0) return NOT_FOUND;
  // Some tools print the banner to stderr; either stream is the version here.
  // Joined with a newline, not concatenated raw — stdout can lack a trailing
  // newline, and direct concatenation would merge its last line with stderr's
  // first (e.g. stdout "v1", stderr "warn\n" becoming the single line "v1warn").
  const output = `${result.stdout || ''}\n${result.stderr || ''}`;
  const first = output.split('\n').find((line) => line.trim() !== '');
  return first ? first.trim() : NOT_FOUND;
}

/**
 * @param {string[]} tools Command names.
 * @param {object} [deps] Passed through to {@link probe}.
 * @returns {string[]} One `<tool>: <version-or-NOT FOUND>` line per tool.
 */
function probeAll(tools, deps = {}) {
  return tools.map((tool) => `${tool}: ${probe(tool, deps)}`);
}

module.exports = { EXIT, NOT_FOUND, probe, probeAll };

if (require.main === module) {
  const tools = process.argv.slice(2);
  if (tools.length === 0) {
    process.stderr.write(USAGE);
    process.exit(EXIT.USAGE);
  }
  process.stdout.write(`${probeAll(tools).join('\n')}\n`);
  process.exit(EXIT.OK);
}
