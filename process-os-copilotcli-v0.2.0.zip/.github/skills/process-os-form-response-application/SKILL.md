---
name: process-os-form-response-application
description: >-
  Write submitted Camunda Form responses back into the ProcessOS questions store
  they came from. The write keys on the question-row shape ({id, q, a}), not on
  the phase, so it round-trips any Dynamic List questionnaire — any
  equally-shaped `<phase>Questions` array (e.g. discovery's discoveryQuestions
  or transformation's transformationQuestions) — plus legacy flat-variable forms
  and a flat qN-to-text map. Use after a user fills the Dynamic List form so the
  rest of the lifecycle consumes the answers, apply form-submission variables to
  the matching questions, or ingest a responses.json export.
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
# /process-os-form-response-application

**UTILITY SKILL** — a single deterministic transform (form responses → the questions store). No LLM
reasoning; idempotent write keyed on `qN`.

INVOKES: `form-to-questions.cjs`. Round-trip partner: `process-os-question-form-generation` produces the
questions JSON array (discovery's `discoveryQuestions`) this skill reads answers back from.

## USE FOR:

- Writing submitted form answers back into the questions store
- Applying a questionnaire variable (e.g. `discoveryQuestions` / `transformationQuestions`) to its `review-questions.yaml`
- Ingesting an SME's form submission into a phase's questions (e.g. discovery or transformation)
- Applying a reconciled `{qN: text}` map assembled from several answer sources

## DO NOT USE FOR:

- Generating the `discoveryQuestions` array from a store → instead use `process-os-question-form-generation`.
- A returned spreadsheet or Markdown file → use `process-os-xlsx-response-application` or
  `process-os-md-response-application`.
- Reviewing or acting on the answered questions → use `process-os-review-answer-application` /
  `process-os-process-transformation`.

Read submitted form responses and write each answer into the matching question of the store. The
primary input is a **questions array** — an array of `{id, q, a}` objects produced by a static Dynamic
List form (discovery's `gaps-discovery`, which binds `discoveryQuestions`). The write keys
on each row's `id` (`Question N` / `qN`), **not** on the phase or variable name, so any
equally-shaped questionnaire array — e.g. a transformation `transformationQuestions` — round-trips
identically. A caller that extracts the array by name up front and hands this skill a **bare array**
(`process-os-sme-feedback` via `scripts/read-job-input.cjs <key>`) therefore gets a
doc-set-agnostic write. The script reduces the array to a flat `{ qN: value }` map and writes each
answer into its question. Legacy flat `{ "q1": "...", "q3": "..." }` maps and `{ "variables": { ... } }`
envelopes are also accepted — on those envelope shapes the fast path still recognizes the
`discoveryQuestions` key **by name** (the bare-array path above is the phase-neutral one). That flat
shape is also how a caller applies a resolution it assembled from several answer sources. Only `answer`
and `status` are written; the question, its `confidence` / `impact` / `proposed` values and the
document structure are the store's. Idempotent — re-running with the same responses changes nothing.

$ARGUMENTS

### Step 1 — EXEC: write answers back

First argument is the questions store; the optional second argument is the responses JSON (defaults to
`<basename>.responses.json` next to the store).

```bash
node .github/skills/process-os-form-response-application/scripts/form-to-questions.cjs <path-to-store.yaml> [<responses.json>]
```

**Run it from the project root** — the directory containing `.camunda/`. The script reads and writes
the store through `scripts/questions-yaml.cjs`, which resolves the `yaml` package from
`.camunda/node_modules` relative to the working directory.

Pass `--dry-run` to **read the responses without writing** — see
[Reading a source without applying it](#reading-a-source-without-applying-it).

The responses JSON can be any of:

- A questions array: `[{id: "Question 1", q: "...", a: "..."}, ...]` (primary format from the Dynamic
  List form; the legacy `id: "q1"` shape is still accepted).
- A flat `{ "q1": "...", "q3": "..." }` map.
- A `{ "variables": { ... } }` envelope (unwrapped automatically).

Non-`qN` keys are dropped. Empty-string answers are left untouched (reported as still blank).

A response is **discarded** when the target question is already answered — it holds answer text, or
its `status` is `answered` — whatever the incoming value says. A current form does not present
such a question at all, so this only fires on a submission that did not come from one: an earlier
review cycle's, a replayed job, or a hand-set process variable.

### Step 2 — AI: Report

Tell the user all three counts the script prints, kept apart:

- **written** — the answers that landed.
- **already answered** — responses that were **discarded** because the store already considers that
  question settled. Never report these as blank: an answer the write threw away is something the user
  may want to look at, and it means the submission was stale.
- **still blank** — questions that are **still open** and got no answer from the responses, i.e.
  what remains to be answered. Already-answered questions the responses said nothing about are not
  counted here — they need nothing, so they appear in none of the three counts.

The store is now ready for the next lifecycle step.

## Reading a source without applying it

`--dry-run` reports what these responses **would** do and writes nothing:

```bash
node .github/skills/process-os-form-response-application/scripts/form-to-questions.cjs --dry-run <path-to-store.yaml> [<responses.json>]
```

Use it when the questionnaire is **not the only surface answering these questions** — a stakeholder
may also have returned the spreadsheet from `process-os-questions-xlsx-export` or the Markdown file
from `process-os-questions-md-export`, both of which write into the same store and join on the same
`qN`. Applying any source settles every question it touches, and an answer aimed at a settled question
is then correctly discarded — so whichever import ran first wins, and the disagreement is never seen.
Reading them all first is what lets a caller compare them; `process-os-sme-feedback` does exactly that
before it writes anything.

Output is JSON, so the caller can compare two sources' texts directly:

```json
{
  "source": "form",
  "target": "process-discovery/iteration-3/artifacts/review-questions.yaml",
  "answers": { "q2": "The Meridian Risk API at /v2/score." },
  "proposalUnchanged": [],
  "alreadyAnswered": ["q1"],
  "blank": ["q3"]
}
```

- **`answers`** — what would land, keyed by `qN`, **with the text**. These are the candidates.
- **`proposalUnchanged`** — a subset of `answers`' ids whose incoming value still agrees with that
  question's stored `proposed` value, whitespace aside. **Not real input.** The form pre-seeds every
  row's answer field from the proposal so the SME starts from current state, so an untouched row comes
  back carrying that text verbatim, indistinguishable from a typed answer. Applying one on its own is
  harmless; treating one as a *side of a disagreement* would raise a false conflict on every untouched
  row. A caller weighing two sources must let a real answer from another source win over one of these
  without asking.
  - Known limitation: an SME who reads the proposal and deliberately accepts it verbatim looks
    identical to one who never touched the row, so that acceptance loses to another source's differing
    answer instead of surfacing. The alternative — a conflict on every untouched row — is worse.
  - Neither the spreadsheet nor the Markdown projection needs an equivalent: the sheet leaves an open
    row's `Answer` cell **blank** and the `.md` renders the placeholder, so in both a filled value is
    always human input.
- **`alreadyAnswered`** / **`blank`** — the same two lists the real write reports, so a dry run and
  the write that follows it never disagree about what is settled and what is still open.

Then apply the reconciled result through the normal (non-`--dry-run`) path above: a flat
`{ "qN": "<the chosen text>" }` map is an accepted responses shape, so a caller that had to pick
between sources writes its resolved map to a JSON file and applies **that** — one write, through the
same gate, with no second import to overwrite it.

## Example

```bash
$ node .github/skills/process-os-form-response-application/scripts/form-to-questions.cjs \
    process-discovery/iteration-3/artifacts/review-questions.yaml process-discovery/iteration-3/artifacts/review-questions.responses.json
form-to-questions: wrote 2 answer(s) [q1, q2]; 0 already answered []; 1 still blank [q3] -> process-discovery/iteration-3/artifacts/review-questions.yaml
```

## Troubleshooting

- **`missing responses file`** — the second argument (or the default `<basename>.responses.json`) does
  not exist; pass the correct path.
- **`missing <path>`** (exit 2) — no store at that path.
- **`not a valid questions store`** (exit 4) — the store parses as YAML but does not match the schema;
  every problem is listed by path. If it was hand-authored, run
  `node ".github/skills/process-os-form-response-application/scripts/questions-yaml.cjs" format <that store>` to canonicalise and re-check it.
- **`not valid YAML`** (exit 5) — the message names the line.
- **Answers not appearing** — the response keys must match `qN` (or `discoveryQuestions[].id`) and be
  non-empty; non-`qN` keys and empty strings are skipped. A response aimed at an already-answered
  question is discarded by design (see above) and shows up in the `already answered` count, not the
  blank one.
- **Nothing changed on re-run** — expected: the write is idempotent, so applying the same responses
  twice is a no-op.
