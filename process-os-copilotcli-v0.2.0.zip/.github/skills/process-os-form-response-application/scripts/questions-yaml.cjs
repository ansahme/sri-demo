/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

/**
 * questions-yaml.cjs — read and write the canonical questions store.
 *
 * The store is the source of truth for review questions; `.md`, `.xlsx` and
 * the Camunda Form are projections of it. This module owns exactly one thing: getting the
 * document on and off disk without the format lying about the data. The field table and the
 * answer-state rules live in questions-schema.cjs; the Markdown projection lives in
 * questions-md.cjs.
 *
 * Value hygiene on write
 * ──────────────────────
 * Two normalisations, applied to every prose value before emission. Both exist because a
 * value that is not a fixed point of the write path silently changes underneath the store:
 *
 *   CRLF → LF          A string containing \r\n cannot be a literal block, so the emitter
 *                      falls back to a double-quoted scalar with \r escapes — correct, but
 *                      unreadable, and it makes an otherwise identical document diff. The
 *                      \r arrives from a `.md` edited on Windows and folded back in, which
 *                      is a first-class platform here, not an edge case.
 *
 *   trailing spaces    A literal block PRESERVES trailing whitespace and round-trips it
 *                      correctly, so nothing complains — until an editor or pre-commit hook
 *                      strips it and the value changes with no edit and no diff to explain
 *                      it. Stripping on write makes the file a fixed point under that pass.
 *
 * The third rule — every prose value emitted as a literal block scalar (`|-`) — is enforced
 * by yaml.cjs's stringifyBlockLiteral, driven by PROSE_FIELDS from the schema. See that
 * function for why a serializer option cannot express it.
 *
 * CLI
 * ───
 *   node "questions-yaml.cjs" check  <store.yaml>
 *   node "questions-yaml.cjs" format <store.yaml>
 *   node "questions-yaml.cjs" mark-answered <store.yaml> --qids q1,q3 [--date YYYY-MM-DD]
 *
 * `format` exists because a generating phase hand-authors the store with its file-writing tool,
 * which makes it the one writer in the system that is not serialize(). It validates AND
 * canonicalises in one pass, so a mis-indented continuation line inside a `|-` block is reported
 * by line rather than surviving as a store that reads back with text in the wrong field, and an
 * author's `answer: no` becomes `answer: |-` before any other parser sees it.
 *
 * `check` is the same validation without the write, for a caller reading a store it does not own.
 *
 * `mark-answered` is the settling annotation as a subcommand rather than a hand edit. A
 * mis-indented hand edit inside a block scalar does not fail to parse — it silently moves text
 * from one field into another — so the one field a skill needs to change gets a code path.
 */

const fs = require('node:fs');

// Peer requires: both are true siblings in place and once bundled, since the bundler copies a
// shared script's own shared dependencies as peers into every consuming skill's scripts dir.
const yaml = require('./yaml.cjs');
const schema = require('./questions-schema.cjs');

// Baked into every file the writer produces, so every skill it names must exist — asserted in
// questions-yaml.test.cjs against the skills directory rather than checked by eye.
const STORE_HEADER =
  '# Questions store — the source of truth for this phase\'s questions.\n' +
  '# Answers may be written here directly, or folded in from a projection with\n' +
  '# /process-os-md-response-application or /process-os-xlsx-response-application.\n';

/**
 * Normalise a single prose value. See "Value hygiene on write".
 *
 * Leading and trailing blank lines go too, not just trailing spaces per line. A value whose first
 * line is empty emits as an indentation-only line inside the block scalar, which a
 * whitespace-stripping editor or hook then rewrites — so the file would not be the fixed point
 * this rule exists to guarantee. A blank line at either end of an answer carries no meaning.
 *
 * @param {string} value
 * @returns {string}
 */
function normalizeProse(value) {
  return String(value == null ? '' : value)
    .replace(/\r\n?/g, '\n')
    .split('\n')
    .map((line) => line.replace(/[ \t]+$/, ''))
    .join('\n')
    .replace(/^\n+/, '')
    .replace(/\n+$/, '');
}

/**
 * Copy `doc` with every prose value normalised.
 *
 * Returns a new document rather than mutating, so a caller holding the object it passed in
 * does not silently observe rewritten values.
 *
 * Structure is preserved exactly as given — a non-list `sections` or `questions` is passed
 * through untouched rather than replaced with `[]`. Substituting an empty list here is what would
 * let a malformed document reach disk looking well-formed: a typo'd `question:` key would gain an
 * empty canonical `questions` list beside it, and every real question in that section would be
 * silently dropped from the store. Reporting that is `validate`'s job, and serialize() runs it
 * FIRST for exactly this reason.
 *
 * @param {object} doc
 * @returns {object}
 */
function normalizeDocument(doc) {
  const out = { ...doc };
  // Document- and section-level strings get the same hygiene as prose. They are not PROSE_FIELDS
  // (they are single-line labels, not free text, so they are never emitted as block scalars), but
  // rules 3 and 4 are about what reaches the FILE, not about which fields are prose: an
  // un-normalised `process` still emits an escaped `\r\n` quoted scalar, and un-stripped trailing
  // whitespace in `generated` still breaks the fixed-point property.
  for (const field of ['process', 'generated']) {
    if (typeof out[field] === 'string') out[field] = normalizeProse(out[field]);
  }
  if (!Array.isArray(out.sections)) return out;
  out.sections = out.sections.map((section) => {
    if (section === null || typeof section !== 'object' || !Array.isArray(section.questions)) {
      return section;
    }
    return {
      ...section,
      ...(typeof section.title === 'string' ? { title: normalizeProse(section.title) } : {}),
      questions: section.questions.map((q) => {
        if (q === null || typeof q !== 'object') return q;
        const next = { ...q };
        for (const field of schema.PROSE_FIELDS) {
          if (typeof next[field] === 'string') next[field] = normalizeProse(next[field]);
        }
        return next;
      }),
    };
  });
  return out;
}

/**
 * Serialise a store document to YAML text, header comment included.
 *
 * @param {object} doc
 * @returns {string}
 * @throws {Error} `QUESTIONS_INVALID` when the document does not validate.
 */
function serialize(doc) {
  // Validate the document AS GIVEN, before normalisation. The other order lets normalisation
  // answer a question the validator was about to ask, so a malformed document serialises cleanly
  // and only fails for whoever reads it next — or worse, reads back as valid with data missing.
  assertValid(doc, '<in-memory document>');
  return STORE_HEADER + yaml.stringifyBlockLiteral(normalizeDocument(doc), schema.PROSE_FIELDS);
}

/**
 * Parse store YAML text.
 *
 * @param {string} text
 * @param {string} [source] Path or label used in error messages.
 * @returns {object}
 * @throws {Error} `QUESTIONS_UNPARSEABLE` on invalid YAML, `QUESTIONS_INVALID` on a
 *   document that parses but does not match the schema.
 */
function parse(text, source = '<text>') {
  let doc;
  try {
    doc = yaml.parse(text);
  } catch (cause) {
    // A YAML syntax error and a schema violation are different failures with different
    // fixes, so they never share an error code. Tabs-as-indentation and duplicate keys both
    // land here, which is the right place: the yaml package rejects them outright rather
    // than guessing, so the message names the line.
    if (cause && cause.code === 'DEPS_MISSING') throw cause;
    const err = new Error(`${source}: not valid YAML — ${cause.message}`);
    err.code = 'QUESTIONS_UNPARSEABLE';
    err.cause = cause;
    throw err;
  }
  assertValid(doc, source);
  return doc;
}

/**
 * Read and validate a store file.
 *
 * @param {string} filePath
 * @returns {object}
 * @throws {Error} `QUESTIONS_NOT_FOUND`, `QUESTIONS_UNPARSEABLE` or `QUESTIONS_INVALID`.
 */
function read(filePath) {
  let text;
  try {
    text = fs.readFileSync(filePath, 'utf8');
  } catch (cause) {
    if (cause && cause.code === 'ENOENT') {
      const err = new Error(`${filePath}: no questions store at this path`);
      err.code = 'QUESTIONS_NOT_FOUND';
      throw err;
    }
    throw cause;
  }
  return parse(text, filePath);
}

/**
 * Write a store file.
 *
 * @param {string} filePath
 * @param {object} doc
 * @returns {string} The text written.
 */
function write(filePath, doc) {
  const text = serialize(doc);
  fs.writeFileSync(filePath, text, 'utf8');
  return text;
}

/**
 * Throw a single error listing every schema problem.
 *
 * All problems at once, not the first: a hand-authored store with three mistakes should
 * take one round trip to fix, not three.
 *
 * @param {unknown} doc
 * @param {string} source
 */
function assertValid(doc, source) {
  const problems = schema.validate(doc);
  if (problems.length === 0) return;
  const err = new Error(
    `${source}: not a valid questions store\n` + problems.map((p) => `  - ${p}`).join('\n'),
  );
  err.code = 'QUESTIONS_INVALID';
  err.problems = problems;
  throw err;
}

// ─── CLI ─────────────────────────────────────────────────────────────────────

// Exit codes, following the read-job-input.cjs precedent: each distinct broken-input reason
// gets its own code, so a caller tells them apart without matching on message text.
const EXIT = {
  OK: 0,
  USAGE: 2,
  IO: 3, // no file at that path, or an unreadable/unwritable one
  INVALID: 4, // parses as YAML, does not match the schema
  UNPARSEABLE: 5, // not valid YAML
  UNKNOWN_IDS: 6, // --qids names a question the store does not have; nothing written
};

const EXIT_FOR_CODE = {
  QUESTIONS_NOT_FOUND: EXIT.IO,
  QUESTIONS_INVALID: EXIT.INVALID,
  QUESTIONS_UNPARSEABLE: EXIT.UNPARSEABLE,
};

const USAGE = [
  'Usage: questions-yaml.cjs check  <store.yaml>                     (validate, write nothing)',
  '       questions-yaml.cjs format <store.yaml>                     (validate and canonicalise in place)',
  '       questions-yaml.cjs mark-answered <store.yaml> --qids q1,q3 [--date YYYY-MM-DD]',
].join('\n');

function usageError(message) {
  return Object.assign(new Error(message), { code: 'USAGE' });
}

/**
 * Parse argv (already sliced past node + script).
 *
 * @param {string[]} argv
 * @returns {{command: string, filePath: string, qids: string[], date: string|null}}
 */
function parseArgs(argv) {
  let command = null;
  let filePath = null;
  let qids = null;
  let date = null;

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--qids' || arg === '--date') {
      const value = argv[i + 1];
      if (value === undefined || value.startsWith('--')) {
        throw usageError(`${arg} needs a value`);
      }
      if (arg === '--qids') qids = value;
      else date = value;
      i += 1;
      continue;
    }
    if (arg.startsWith('--')) throw usageError(`unknown option ${arg}`);
    if (command === null) command = arg;
    else if (filePath === null) filePath = arg;
    else throw usageError(`unexpected argument ${arg}`);
  }

  if (command === null) throw usageError('no command given');
  if (!['check', 'format', 'mark-answered'].includes(command)) {
    throw usageError(`unknown command ${command}`);
  }
  if (filePath === null) throw usageError('no store path given');

  if (command === 'mark-answered') {
    if (qids === null) throw usageError('mark-answered needs --qids q1,q3');
    // Split on commas AND whitespace: the ids reach a skill as a space-separated list and
    // rejoining them with commas is one more step for a caller to get wrong.
    const ids = qids.split(/[,\s]+/).filter(Boolean);
    if (ids.length === 0) throw usageError('--qids listed no question ids');
    // Checked HERE rather than left to validate(). A malformed `--date 07/20/2026` would otherwise
    // reach the store as an invalid `updated`, and the failure would be reported as
    // "<in-memory document>: not a valid questions store" — which reads as "your store is broken"
    // when the store on disk is fine and the argument is what is wrong.
    if (date !== null && !schema.DATE_PATTERN.test(date)) {
      throw usageError(`--date must be YYYY-MM-DD, got ${JSON.stringify(date)}`);
    }
    return { command, filePath, qids: ids, date: date === null ? today() : date };
  }
  if (qids !== null) throw usageError(`--qids is only meaningful for mark-answered`);
  if (date !== null) throw usageError(`--date is only meaningful for mark-answered`);
  return { command, filePath, qids: [], date: null };
}

/** Today as `YYYY-MM-DD` in local time — the date a human reading the file would write. */
function today() {
  const now = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
}

/** "N question(s), M open" — the one summary every subcommand reports. */
function describe(doc) {
  const questions = schema.allQuestions(doc);
  const open = questions.filter(schema.isOpen).length;
  return `${questions.length} question(s), ${open} open`;
}

/**
 * Run one CLI command against the filesystem.
 *
 * Separated from main() so the tests can drive it without spawning for every case, and so every
 * error leaves through one place.
 *
 * @param {{command: string, filePath: string, qids: string[], date: string|null}} plan
 * @returns {{stdout: string, stderr: string, exit: number}}
 */
function runCommand(plan) {
  const doc = read(plan.filePath);

  if (plan.command === 'check') {
    return {
      stdout: `questions-yaml: ${plan.filePath} is a valid ${doc.kind} store — ${describe(doc)}\n`,
      stderr: '',
      exit: EXIT.OK,
    };
  }

  if (plan.command === 'format') {
    const before = fs.readFileSync(plan.filePath, 'utf8');
    const after = serialize(doc);
    if (after === before) {
      return {
        stdout: `questions-yaml: ${plan.filePath} is already canonical — ${describe(doc)}\n`,
        stderr: '',
        exit: EXIT.OK,
      };
    }
    fs.writeFileSync(plan.filePath, after, 'utf8');
    return {
      stdout: `questions-yaml: rewrote ${plan.filePath} — ${describe(doc)}\n`,
      stderr: '',
      exit: EXIT.OK,
    };
  }

  const { doc: next, marked, unknown } = schema.setAnswered(doc, plan.qids, plan.date);
  if (unknown.length > 0) {
    // Refused whole, nothing written. `mark-answered` is called with ids the caller just read
    // out of this store, so an id it does not have means the caller and the store disagree about
    // which questions exist — the same staleness the XLSX identity guard refuses on. Marking the
    // subset that happens to match is precisely the silent half-application to avoid.
    return {
      stdout: '',
      stderr:
        `questions-yaml: ${plan.filePath} has no question(s) [${unknown.join(', ')}] ` +
        '— nothing was written.\n' +
        '  The ids passed to --qids must come from this store. This usually means the store was ' +
        'regenerated after the ids were collected, or a different store was passed. Re-read the ' +
        'store and re-derive the ids, then re-run.\n',
      exit: EXIT.UNKNOWN_IDS,
    };
  }
  write(plan.filePath, next);
  return {
    stdout:
      `questions-yaml: marked ${marked.length} question(s) answered ${plan.date} ` +
      `[${marked.join(', ')}] -> ${plan.filePath}\n`,
    stderr: '',
    exit: EXIT.OK,
  };
}

function main(argv) {
  let plan;
  try {
    plan = parseArgs(argv);
  } catch (e) {
    process.stderr.write(`questions-yaml: ${e.message}\n${USAGE}\n`);
    return EXIT.USAGE;
  }
  try {
    const { stdout, stderr, exit } = runCommand(plan);
    if (stdout) process.stdout.write(stdout);
    if (stderr) process.stderr.write(stderr);
    return exit;
  } catch (e) {
    process.stderr.write(`questions-yaml: ${e.message}\n`);
    return (e && EXIT_FOR_CODE[e.code]) || EXIT.IO;
  }
}

module.exports = {
  STORE_HEADER,
  EXIT,
  normalizeProse,
  normalizeDocument,
  serialize,
  parse,
  read,
  write,
  parseArgs,
  runCommand,
};

if (require.main === module) process.exit(main(process.argv.slice(2)));
