#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Write submitted Camunda Form responses back into the ProcessOS questions store — the FORM
// PROJECTION's inbound half.
//
// Reads a questions array variable — the structured output of the Dynamic List form used by the
// governance process. Each entry is `{id, q, a}` where `id` is the human-readable roundtrip label
// emitted by /process-os-question-form-generation (e.g. "Question 1"); rowKey() below parses the
// trailing number out to recover the store's `qN` key, and the legacy raw "qN" id is still
// accepted for old fixtures.
//
// Also accepts the legacy flat `{q1: "...", q3: "..."}` shape and a `{variables}` envelope, for
// backward compatibility with local responses files and other callers. A caller that has already
// reconciled two answer sources writes its resolved map in exactly that flat shape and applies it
// here — one write, through one gate.
//
// Deterministic and idempotent — re-running with the same data is a no-op. applyAnswers() drops
// any response aimed at a question the store already considers settled, so a form submitted from
// an earlier review cycle (or a replayed job) cannot overwrite a real answer. The form never
// presents such a question in the first place, but presentation is a courtesy and the write gate
// is the guarantee — see questions-schema.cjs, "Where answer state is ENFORCED".
//
// `--dry-run` reports what this data WOULD do to the store and writes nothing, so a caller holding
// more than one answer source (the questionnaire, a returned spreadsheet and a returned `.md` all
// answer the same questions) can compare them before any of them is applied. Without it the only
// way to learn what a source says is to apply it, which settles every question it touches and
// leaves the other sources' answers with nowhere to land — see process-os-sme-feedback's
// "Reconcile the answer sources" step.
//
// Usage: node form-to-questions.cjs [--dry-run] <store.yaml> [<responses.json>]
// Default responses path: <basename>.responses.json next to the store
//
// Exit codes:
//   0  applied, or reported under --dry-run
//   2  usage error (missing/unknown argument, missing input file)
//   4  the store parses but does not match the schema
//   5  the store is not valid YAML

'use strict';

const fs = require('fs');
const path = require('path');
const store = require(path.join(__dirname, 'questions-yaml.cjs'));
const {
  flatQuestions,
  applyAnswers,
  answersAgree,
  formatAnswerCounts,
} = require(path.join(__dirname, 'questions-schema.cjs'));

const EXIT_FOR_CODE = { QUESTIONS_INVALID: 4, QUESTIONS_UNPARSEABLE: 5 };

// Camunda variable values arrive JSON-encoded (a string var "save" comes back
// as the literal `"save"`; a discoveryQuestions array as a stringified JSON
// array). Decode strings and arrays/objects — those are the shapes we care
// about — while leaving non-JSON payloads untouched.
function decodeVarValue(v) {
  if (typeof v === 'string') {
    try {
      const parsed = JSON.parse(v);
      if (typeof parsed === 'string') return parsed;
      // Also decode arrays/objects (discoveryQuestions is a JSON-encoded array).
      if (typeof parsed === 'object' && parsed !== null) return parsed;
    } catch { /* not JSON — use raw */ }
  }
  return v;
}

// Extract the store's qN key from a row's id. The questions rows carry a
// human-readable "Question N" label (preserved through the form's save cycle);
// the legacy "qN" form is still accepted so old fixtures/runs still resolve.
function rowKey(id) {
  if (typeof id !== 'string') return null;
  const m = id.match(/^Question\s+(\d+)$/i) || id.match(/^q(\d+)$/);
  return m ? `q${m[1]}` : null;
}

// Reduce the questions array ([{id, q, a}, ...]) to a flat { qN: value } map.
function reduceDiscoveryQuestions(arr) {
  const out = {};
  for (const row of arr) {
    if (!row || typeof row !== 'object') continue;
    const key = rowKey(row.id);
    if (key) out[key] = typeof row.a === 'string' ? row.a : String(row.a ?? '');
  }
  return out;
}

// Reduce any accepted variable shape to a flat { qN: value } map:
//   - a questions array: [{id, q, a}, ...]
//   - a flat object { q1: "...", notes: "..." }
//   - a { variables: {...} } envelope
//   - an array of { name, value } records (c8ctl variable rows; the JSON
//     output capitalizes them as { Name, Value })
// Non-`qN` keys are dropped; values are stringified.
function reduceToQMap(raw) {
  // Direct questions array: [{id, q, a}, ...]
  if (Array.isArray(raw) && raw.length > 0 && raw[0] && typeof raw[0].id === 'string') {
    return reduceDiscoveryQuestions(raw);
  }

  const unwrapped = raw && typeof raw === 'object' && !Array.isArray(raw) && raw.variables != null
    ? raw.variables
    : raw;

  // c8ctl search-vars rows (array of {name, value} or {Name, Value})
  if (Array.isArray(unwrapped)) {
    // Check if these are variable rows (name/value pairs)
    if (unwrapped.length > 0 && unwrapped[0] && (unwrapped[0].name != null || unwrapped[0].Name != null)) {
      // Look for a discoveryQuestions variable in the rows
      for (const r of unwrapped) {
        const name = r.name ?? r.Name;
        if (name === 'discoveryQuestions') {
          const val = decodeVarValue(r.value ?? r.Value);
          if (Array.isArray(val)) return reduceDiscoveryQuestions(val);
        }
      }
      // Fall back to flat qN extraction from variable rows
      const out = {};
      for (const r of unwrapped) {
        const k = r.name ?? r.Name;
        const v = decodeVarValue(r.value ?? r.Value);
        if (/^q\d+$/.test(k)) out[k] = typeof v === 'string' ? v : String(v);
      }
      return out;
    }
    // Array of {id, q, a} rows
    if (unwrapped.length > 0 && unwrapped[0] && typeof unwrapped[0].id === 'string') {
      return reduceDiscoveryQuestions(unwrapped);
    }
  }

  // Flat object — check for discoveryQuestions key first
  if (unwrapped && typeof unwrapped === 'object' && !Array.isArray(unwrapped)) {
    if (Array.isArray(unwrapped.discoveryQuestions)) {
      return reduceDiscoveryQuestions(unwrapped.discoveryQuestions);
    }
    // Also handle JSON-encoded discoveryQuestions
    if (typeof unwrapped.discoveryQuestions === 'string') {
      const decoded = decodeVarValue(unwrapped.discoveryQuestions);
      if (Array.isArray(decoded)) return reduceDiscoveryQuestions(decoded);
    }
    // Fall back to flat qN keys
    const out = {};
    for (const [k, v] of Object.entries(unwrapped)) {
      const decoded = decodeVarValue(v);
      if (/^q\d+$/.test(k)) out[k] = typeof decoded === 'string' ? decoded : String(decoded);
    }
    return out;
  }

  return {};
}

function loadResponses(source) {
  if (!fs.existsSync(source)) {
    process.stderr.write(`form-to-questions: missing responses file ${source}\n`);
    process.exit(2);
  }
  return reduceToQMap(JSON.parse(fs.readFileSync(source, 'utf8')));
}

// What this response data WOULD do to the store, without doing it. Reports answer texts, not just
// ids, because a caller comparing two answer sources needs the text to tell agreement from
// disagreement.
//
// `proposalUnchanged` exists because buildRow (questions-to-form.cjs) pre-seeds each form row's
// answer from the question's stored `proposed` value, so a row the SME never touched comes back
// carrying that proposal verbatim. Harmless when applied alone, but counted as a side of a
// disagreement it would raise a false conflict on every untouched row — so those ids are named
// separately and callers must not treat them as real input. Neither the xlsx nor the Markdown
// projection needs an equivalent: the sheet leaves an open row's `Answer` cell blank and the `.md`
// renders the placeholder, so in both a filled value is always human input. The cost is that an
// SME who deliberately accepts a proposal verbatim is indistinguishable from one who skipped the
// row, and loses to a differing source instead of raising a conflict.
function planResponses(doc, responses, storePath) {
  const { written, alreadyAnswered, blank } = applyAnswers(doc, responses);
  const proposedById = new Map(flatQuestions(doc).map((q) => [q.id, q.proposed]));
  const answers = {};
  const proposalUnchanged = [];
  for (const id of written) {
    answers[id] = responses[id];
    const proposed = proposedById.get(id);
    if (proposed && answersAgree(responses[id], proposed)) proposalUnchanged.push(id);
  }
  return { source: 'form', target: storePath, answers, proposalUnchanged, alreadyAnswered, blank };
}

function parseArgs(argv) {
  const dryRun = argv.includes('--dry-run');
  const rest = argv.filter((a) => a !== '--dry-run');
  const unknownFlag = rest.find((a) => a.startsWith('--'));
  if (unknownFlag) {
    throw Object.assign(
      new Error(
        `unknown option ${unknownFlag} (the only option is --dry-run; ` +
          `this is a pure transform — live-run fetching was removed)`
      ),
      { code: 'USAGE' }
    );
  }
  if (!rest[0]) throw Object.assign(new Error('no questions store path given'), { code: 'USAGE' });
  return { dryRun, storePath: rest[0], responsesPath: rest[1] };
}

function main() {
  let args;
  try {
    args = parseArgs(process.argv.slice(2));
  } catch (e) {
    process.stderr.write(
      `form-to-questions: ${e.message}\n` +
        'Usage: form-to-questions.cjs [--dry-run] <store.yaml> [<responses.json>]\n'
    );
    process.exit(2);
    return;
  }
  const { dryRun, storePath } = args;
  if (!fs.existsSync(storePath)) {
    process.stderr.write(`form-to-questions: missing ${storePath}\n`);
    process.exit(2);
  }
  const base = path.basename(storePath).replace(/\.ya?ml$/i, '');
  const responses = loadResponses(
    args.responsesPath || path.join(path.dirname(storePath), `${base}.responses.json`)
  );
  let doc;
  try {
    doc = store.read(storePath);
  } catch (e) {
    process.stderr.write(`form-to-questions: ${e.message}\n`);
    process.exit(EXIT_FOR_CODE[e.code] || 2);
    return;
  }
  if (dryRun) {
    // JSON, not the prose count line: the caller is another skill comparing this against a
    // second answer source, so it needs the answer texts machine-readably. Nothing is written.
    process.stdout.write(JSON.stringify(planResponses(doc, responses, storePath), null, 2) + '\n');
    return;
  }
  const { doc: next, ...counts } = applyAnswers(doc, responses);
  store.write(storePath, next);
  // Three counts through the shared phrasing, identical wherever answers are applied from.
  // They must not collapse into one: a DISCARDED answer (text arrived for a question the store
  // already settled) is the only one worth acting on, and reads as an unanswered question if it
  // shares a count with the blanks.
  process.stdout.write(`form-to-questions: wrote ${formatAnswerCounts(counts)} -> ${storePath}\n`);
}

if (require.main === module) main();

module.exports = {
  loadResponses,
  reduceToQMap,
  reduceDiscoveryQuestions,
  decodeVarValue,
  parseArgs,
  planResponses,
};
