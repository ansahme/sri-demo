/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

/**
 * questions-schema.cjs — the questions store's field table, the answer-state rules derived
 * from it, and the store's single writer.
 *
 * THE single place a questions field is declared. Every end of the store's life reads it
 * from here:
 *   - questions-yaml.cjs takes PROSE_FIELDS (which values must be emitted as literal block
 *     scalars) and calls validate() on everything it parses.
 *   - each projection — questions-md.cjs, questions-xlsx.cjs, and the Camunda-Form pair in
 *     process-os-question-form-generation / process-os-form-response-application — takes its
 *     ROW SELECTION (`selectOpenQuestions()`), its WRITE GATE (`applyAnswers()`) and the
 *     answer-state rules behind both (`isOpen()`, `STATUS`, `ANSWERED`, `statusLabel()`) from
 *     here, so no two of them can drift apart about when a question is settled or how a status
 *     is spelled to a human.
 *
 * What that does NOT include is QUESTION_FIELDS: no projection reads the field table, and none
 * renders or folds a field automatically just because it is declared here. `updated` is the
 * proof — adding it to the table got it emitted and validated for free, but the Markdown
 * projection needed dedicated code (statusDisplayText, updatedFromRawStatus) to show and recover
 * it at all, and the XLSX sheet still has no column for it. Adding a field therefore means one
 * line here PLUS, for every projection it should appear in, the code to render and read it back.
 * The table guarantees the emitter and the validator, not the projections.
 *
 * Nothing here knows any projection's format. That is the division of labour: a projection
 * owns its own syntax and nothing else, and this module owns everything that is true of the
 * questions regardless of how they are rendered — which fields exist, which questions are
 * still open, which answers may be written, how the outcome is counted and phrased.
 *
 * Answer state is DERIVED, never stored
 * ─────────────────────────────────────
 * Two independent signals: answer CONTENT and an explicit `status` ANNOTATION. They stay
 * separate fields because either can be true without the other, and the disagreement cases
 * are the interesting ones — an answer moved out into the phase documents leaves the marker
 * alone, and an interrupted run leaves the answer without the marker.
 *
 * Both reduce to a comparison here, because `answer` and `status` are read rather than
 * inferred. They stay separate functions, and `isOpen` stays their OR-combination and the
 * only place that combines them — do not re-derive it.
 *
 * `status` is a closed vocabulary, not free text
 * ───────────────────────────────────────────────
 * The Markdown grammar's `status` line is genuinely free text (`Partially answered`, `Unanswered
 * — pending human review`, a dated `answered 2026-07-20` marker, …), because SMEs and FDEs hand-type
 * it. A structured store does not need that latitude, and a closed set is what makes
 * `markedAnswered` an exact comparison instead of a prefix regex: see `STATUS` below. The date that
 * used to ride inside the free-text marker gets its own `updated` field instead — a value that must
 * mean "when was this settled" is easier to use correctly as its own field than as a suffix a
 * consumer has to parse back out of `status`.
 *
 * The Markdown projection (questions-md.cjs) is what bridges the two worlds: it maps the enum onto
 * the display text every existing `.md` consumer already expects, and, on the way in, recovers a
 * date from a dated marker into `updated` rather than discarding it.
 *
 * Where answer state is ENFORCED
 * ──────────────────────────────
 * `isOpen` decides two things, and this module owns both so that no projection — present or
 * future — implements its own version:
 *
 *   which questions are PRESENTED for answering — `selectOpenQuestions()`; every projection
 *     builds its rows from that, so a settled question is never re-asked.
 *   which answers may be WRITTEN — `applyAnswers()`; it is the store's single writer, so a
 *     settled question cannot be overwritten no matter where the answer came from, or whether
 *     the question was presented in the first place.
 *
 * The second is not redundant with the first. A projection that never shows a settled question
 * can still CARRY an answer for one: a replayed job, a submission built against an earlier
 * review cycle, a spreadsheet exported before the last fold, input assembled by hand or by a
 * script. Presentation is a courtesy; the write gate is the guarantee.
 */

const SCHEMA_VERSION = 1;

// `review` is the shape produced from completed phase output (Confidence/Impact per question) —
// the store's only kind.
const KINDS = ['review'];

// `q` + a 1-based index, matching the `### Q<N>:` heading the Markdown projection renders
// and the key every existing consumer already uses. No leading zeros: `q08` would be a
// second spelling of `q8` and the two would not compare equal.
const ID_PATTERN = /^q[1-9][0-9]*$/;

// The exact section title `review-questions.md`'s template mandates for its case-anchored
// exception questions (shared/references/review-questions.md's Section 5). Matched literally
// rather than inferred from `kind`, because a review-kind document's other sections (1-4) share
// the same question shape otherwise — only this one section carries the case-anchored carve-out
// (no `confidence`/`proposed`, `impact` required) enforced below.
const SECTION_5_TITLE = 'Section 5: Real-World Exception Handling';

// Fields the carve-out forbids on a Section 5 question: neither has a citation to hang a reason
// or a discovery-derived guess on, since Section 5 questions are not evidence-anchored.
const SECTION_5_FORBIDDEN_FIELDS = ['confidence', 'proposed'];

/**
 * Per-question fields.
 *
 * `prose` marks a value that must never be emitted as a bare YAML scalar, because a bare
 * scalar is typed and the value is not. Most of the time that is because the field is SME- or
 * LLM-authored free text — an answer of `no`, `1.0` or `12:30` would come back as a boolean, a
 * float and an integer respectively. `updated` is the exception that proves the rule rather
 * than free text: it is a plain `YYYY-MM-DD` string, but that exact shape is what a YAML 1.1
 * parser's classic implicit-timestamp resolver (PyYAML's `safe_load`, not this repo's `yaml`
 * package) reads back as a date object instead of a string — the same class of hazard, so it
 * gets the same fix. `id` and `status` are deliberately NOT prose: both are constrained
 * vocabularies this module validates, so a bare scalar is correct for them.
 */
const QUESTION_FIELDS = {
  id: { required: true, prose: false },
  text: { required: true, prose: true },
  confidence: { required: false, prose: true },
  impact: { required: false, prose: true },
  proposed: { required: false, prose: true },
  answer: { required: false, prose: true },
  status: { required: false, prose: false },
  // The date `status` was last set, `YYYY-MM-DD`. Optional, and set at whoever's discretion is
  // doing the settling — not required alongside `status: answered`, because not every settling
  // path (a hand edit, a fold from a projection with no date of its own) has a date to record.
  updated: { required: false, prose: true },
};

// Document-level fields. `process` and `generated` populate the Markdown projection's
// header; neither is required, because a store hand-authored for a test has no use for them.
//
// `string` marks a field validate() type-checks as a string. `schema` is a number and `sections`
// a list, so both are excluded and checked by shape instead.
const DOCUMENT_FIELDS = {
  schema: { required: true, string: false },
  kind: { required: true, string: true },
  process: { required: false, string: true },
  generated: { required: false, string: true },
  sections: { required: true, string: false },
};

// Section-level fields, so an unknown key here is caught rather than silently carried. A typo'd
// `question:` (singular) is the case that matters: without this check the store persists with its
// real questions under an unread key and a canonical `questions` list that is empty, and a
// re-read reports no problems at all.
const SECTION_FIELDS = { title: { required: false, string: true }, questions: { required: true, string: false } };

const STRING_DOCUMENT_FIELDS = Object.keys(DOCUMENT_FIELDS).filter((k) => DOCUMENT_FIELDS[k].string);

// Derived from the table rather than restated, so a new prose field cannot miss the
// block-scalar emission that makes it type-safe.
const PROSE_FIELDS = Object.keys(QUESTION_FIELDS).filter((k) => QUESTION_FIELDS[k].prose);
const REQUIRED_QUESTION_FIELDS = Object.keys(QUESTION_FIELDS).filter(
  (k) => QUESTION_FIELDS[k].required,
);

// The closed vocabulary `status` is validated against. `partially_answered` is still an OPEN
// state — it does not settle the question, it only annotates it (see isOpen/markedAnswered
// below) — matching what the Markdown grammar has always done with the human phrase this
// mirrors, `Partially answered`: still surfaced to the SME, just worth showing that it is not
// untouched.
const STATUS = { OPEN: 'open', PARTIALLY_ANSWERED: 'partially_answered', ANSWERED: 'answered' };
const STATUS_VALUES = Object.values(STATUS);

const ANSWERED = STATUS.ANSWERED;

// The human-facing text for each status. The enum's values are machine tokens, and
// `partially_answered` is one a stakeholder must never be shown — it reaches two surfaces that
// people read directly (the `.md` `**Status:**` line and the XLSX `Status` column), so the
// vocabulary lives here rather than being spelled out once per projection and drifting.
//
// `open` maps to nothing on purpose: an open question's status carries no annotation worth
// showing, and every row of the XLSX sheet is an open question already.
const STATUS_LABELS = {
  [STATUS.OPEN]: '',
  [STATUS.PARTIALLY_ANSWERED]: 'Partially answered',
  [STATUS.ANSWERED]: 'answered',
};

/**
 * The human-facing text for a question's status, or `''` when it has none worth showing.
 *
 * @param {object} q
 * @returns {string}
 */
function statusLabel(q) {
  const status = q && q.status;
  return Object.prototype.hasOwnProperty.call(STATUS_LABELS, status) ? STATUS_LABELS[status] : '';
}

/**
 * Settle a question — `status: answered` — keeping `updated` honest about it.
 *
 * `updated` means "when was `status` last set", so a write that CHANGES `status` must either
 * record a new date or record none. Carrying the previous status's date forward is the one
 * outcome that is always wrong: it asserts the question was settled on a day it was not, and the
 * Markdown projection renders that assertion to a human as `**Status:** answered <that date>`.
 * A question left `partially_answered` in January and answered today would read as settled in
 * January — off by however long the review cycle ran.
 *
 * A write that does NOT change `status` (it was already `answered`) leaves an existing `updated`
 * alone **even when a date is supplied**: nothing happened for a new date to describe, and
 * overwriting the settling date with the date of a re-run is the same lie in the other direction —
 * a question answered in January would read as settled today, every time a caller re-settles it.
 * Callers legitimately re-settle in bulk (`mark-answered` is handed every answered id, not only the
 * newly answered ones), so this has to be a no-op here rather than a gate each caller reimplements.
 * A supplied date still lands when the question is answered but carries no date at all — recording
 * one is strictly better than leaving the field absent.
 *
 * The date is the caller's to supply — scripts here take no clock — so "no date" is the normal
 * case for the projections, which know an answer arrived but not when it was authored.
 *
 * @param {object} q
 * @param {string} [date] `YYYY-MM-DD`, when the caller knows it.
 * @returns {object} A new question, settled.
 */
function settleQuestion(q, date) {
  const trimmed = String(date == null ? '' : date).trim();
  if (markedAnswered(q)) {
    const recorded = String((q && q.updated) == null ? '' : q.updated).trim();
    if (recorded !== '' || trimmed === '') return { ...q, status: ANSWERED };
    return { ...q, status: ANSWERED, updated: trimmed };
  }
  if (trimmed !== '') return { ...q, status: ANSWERED, updated: trimmed };
  // Status is changing and there is no date to put against it, so the old one has to go. Deleted
  // rather than blanked: absent is what "not recorded" already means for this field.
  const { updated, ...withoutDate } = q;
  return { ...withoutDate, status: ANSWERED };
}

const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

/** @param {object} q @returns {boolean} Does the question carry answer text? */
function hasAnswerText(q) {
  return String((q && q.answer) == null ? '' : q.answer).trim() !== '';
}

/**
 * Is the question explicitly marked answered? Exact equality against `STATUS.ANSWERED` — the
 * field is a validated enum now, not hand-typed prose, so there is no dated or capitalised
 * variant to tolerate. The settling date, when there is one, lives in `updated` instead.
 *
 * @param {object} q @returns {boolean}
 */
function markedAnswered(q) {
  return (q && q.status) === STATUS.ANSWERED;
}

/**
 * Does this question still need SME input? The single row-selection and single write gate,
 * OR-combining both signals — the only place that combines them.
 *
 * `status: partially_answered` does NOT settle a question — `markedAnswered` only matches
 * `answered` — so a partially-answered question stays open until something adds real answer
 * content or an agent moves it to `answered`.
 *
 * @param {object} q
 * @returns {boolean}
 */
function isOpen(q) {
  return !hasAnswerText(q) && !markedAnswered(q);
}

/** Every question in the document, in section order. @param {object} doc */
function allQuestions(doc) {
  const sections = (doc && doc.sections) || [];
  return sections.flatMap((s) => (s && s.questions) || []);
}

/**
 * The number a question's `q<N>` id carries.
 *
 * Falls back to `0` for an id validate() would reject, so a caller that bypassed the store
 * still gets a number rather than a NaN that silently poisons every comparison it reaches.
 *
 * @param {object} q
 * @returns {number}
 */
function questionNumber(q) {
  const m = ID_PATTERN.exec(String((q && q.id) == null ? '' : q.id));
  return m ? Number(m[0].slice(1)) : 0;
}

/**
 * Every question in the document, flattened, with the two positional values a projection needs
 * that the question itself does not carry.
 *
 * THE one place a projection gets a per-question section label. Sections are a document-level
 * structure and every projection is a flat list of questions, so each of them would otherwise
 * walk `doc.sections` itself — which is how two renderings of one store start disagreeing about
 * which section a question sits in.
 *
 *   num      the `q<N>` id's own N, so the id and any rendered number agree.
 *   section  the enclosing section's title, or '' for an untitled section. NOT inherited from
 *            the section above: a question under an untitled section sits under no named
 *            section, and blank is both correct and honest.
 *
 * @param {object} doc
 * @returns {object[]} `{...question, num, section}` in document order.
 */
function flatQuestions(doc) {
  const sections = (doc && doc.sections) || [];
  return sections.flatMap((section) => {
    const title = section && typeof section.title === 'string' ? section.title : '';
    return ((section && section.questions) || []).map((q) => ({
      ...q,
      num: questionNumber(q),
      section: title,
    }));
  });
}

// Sort `q<N>` ids the way a reader expects — q2 before q10, which a string sort gets wrong.
// Exported because every report path over these ids wants the same order.
const byQuestionNumber = (a, b) => Number(a.slice(1)) - Number(b.slice(1));

/**
 * The one row-selection rule for every projection: only OPEN questions are presented, so a
 * settled question is never re-asked.
 *
 * `total` and `excluded` ride along because a silently shrinking question list is
 * indistinguishable from a store that simply had fewer questions. Every caller reports them
 * through formatQuestionCount.
 *
 * @param {object[]} questions
 * @returns {{open: object[], total: number, excluded: number}}
 */
function selectOpenQuestions(questions) {
  const all = Array.isArray(questions) ? questions : [];
  const open = all.filter(isOpen);
  return { open, total: all.length, excluded: all.length - open.length };
}

/**
 * Compare two copies of a question's text — one read back from wherever it was rendered, one
 * from the store — tolerantly enough to survive a round trip. Any projection that shows question
 * text and reads it back needs this exact comparison, and needs it to be the same comparison,
 * or "the question changed" means different things in different places.
 *
 * Whitespace is normalised because it is not information: a wrapped spreadsheet cell comes back
 * with newlines, a `.md` edited on Windows contributes a trailing CR, editors add and eat
 * trailing spaces. Case and punctuation are deliberately NOT normalised — a reworded or
 * re-punctuated question IS a different question, which is the thing worth catching.
 *
 * @param {unknown} value
 * @returns {string}
 */
function normalizeQuestionText(value) {
  return String(value == null ? '' : value)
    .replace(/\s+/g, ' ')
    .trim();
}

// Do two copies of an ANSWER say the same thing? More than one projection can answer the same
// question — the Tasklist questionnaire, a returned spreadsheet and a returned `.md` all write
// into the same store — so before anything is applied, somebody has to decide whether two
// incoming answers AGREE or genuinely disagree. That decision needs exactly the comparison above
// and for exactly the same reasons: a wrapped spreadsheet cell, a CRLF `.md`, an editor that ate
// a trailing space are not disagreements, while a re-punctuated answer is a different answer.
// Exported as a predicate rather than left to each caller, so "these two answers agree" cannot
// come to mean two different things on two surfaces.
const answersAgree = (a, b) => normalizeQuestionText(a) === normalizeQuestionText(b);

/**
 * Apply a flat `{qN: value}` response map to a store document.
 *
 * The store's SINGLE WRITER, so it is where answer state is enforced for every projection at
 * once: an incoming value for a question that is not `isOpen` is dropped, whatever it says and
 * wherever it came from. That guarantee cannot live in a projection — the callers are exactly
 * what can be stale (a replayed job, a submission built against an earlier review cycle, a
 * workbook exported before the last fold, input assembled by hand) — and each one that
 * re-implemented the check would be another place for the definition of "already answered" to
 * drift from `isOpen`.
 *
 * Non-`q<N>` keys and empty values are ignored. Returns a NEW document; the input is not
 * mutated, so a caller holding the object it passed in does not silently observe rewritten
 * values.
 *
 * Reporting — three lists, each answering a different operator question:
 *
 *   written          what landed.
 *   alreadyAnswered  a real incoming answer the gate DISCARDED because the question is settled.
 *                    The one outcome that may need acting on, so it never shares a count with
 *                    anything else.
 *   blank            an OPEN question nothing came in for — i.e. what still needs answering.
 *
 * A settled question with no incoming value appears in NONE of them, deliberately: nothing
 * happened to it and nothing needs to. Counting it as `blank` would report a question that is
 * already answered as one still awaiting an answer, which is exactly backwards, and on a second
 * review cycle the settled questions outnumber the open ones.
 *
 * `skipped` is the union of the two unwritten lists, for callers that only need the total. Note
 * it is therefore NOT "every question that was not written" — settled questions nobody sent
 * anything for are outside all four lists.
 *
 * @param {object} doc
 * @param {Record<string, unknown>} responses
 * @returns {{doc: object, written: string[], skipped: string[], alreadyAnswered: string[],
 *   blank: string[]}}
 */
function applyAnswers(doc, responses) {
  const incoming = responses && typeof responses === 'object' ? responses : {};
  const written = [];
  const alreadyAnswered = [];
  const blank = [];

  const next = {
    ...doc,
    sections: ((doc && doc.sections) || []).map((section) => ({
      ...section,
      questions: ((section && section.questions) || []).map((q) => {
        const value = incoming[q && q.id];
        // The empty check runs FIRST, so a settled question nobody sent an answer for is never
        // reported as a discarded answer — "we threw your text away" must only be said when
        // there was text.
        if (value == null || String(value).trim() === '') {
          // ...and only an OPEN question counts as blank, because `blank` answers the operator's
          // question "what still needs answering". A settled question with nothing incoming had
          // nothing happen to it and needs nothing: listing it says the opposite.
          if (isOpen(q)) blank.push(q.id);
          return q;
        }
        if (!isOpen(q)) {
          alreadyAnswered.push(q.id);
          return q;
        }
        written.push(q.id);
        // Both answer-state signals are set together, so the store never carries an answer whose
        // status disagrees with it. No date: a projection knows an answer arrived, not when it was
        // authored — so settleQuestion drops any date the previous status left behind.
        return settleQuestion({ ...q, answer: String(value).trim() });
      }),
    })),
  };

  // All lists in question-number order. They are collected in document order, which is *usually*
  // the same thing but is not guaranteed — a hand-authored store can carry `q10` above `q2` — and
  // a report whose ids jump around reads like a bug in the tool.
  written.sort(byQuestionNumber);
  alreadyAnswered.sort(byQuestionNumber);
  blank.sort(byQuestionNumber);
  return {
    doc: next,
    written,
    skipped: [...blank, ...alreadyAnswered].sort(byQuestionNumber),
    alreadyAnswered,
    blank,
  };
}

/**
 * Stamp `status: answered` — plus `updated: <date>` when given one — onto the named questions.
 *
 * The settling ANNOTATION, written separately from the answer content because it marks a
 * different event: process-os-review-answer-application writes it once it has folded a question's
 * answer into the phase documents, which can happen long after the answer itself arrived — and
 * can happen for a question whose answer was moved out of the store entirely.
 *
 * The date goes in `updated`, NOT appended to `status`: `status` is a closed enum now, so
 * `answered 2026-07-20` is a value validate() rejects rather than the dated marker it used to be.
 * The Markdown projection puts the two back together when it renders.
 *
 * Named `setAnswered` rather than `markAnswered` so it cannot be misread as, or auto-completed
 * into, the `markedAnswered` predicate above. One is a write, the other a read.
 *
 * `unknown` reports an id the store does not have rather than inventing a question for it — a
 * caller passing an id from another cycle is reporting a real problem, not asking for a new
 * question.
 *
 * @param {object} doc
 * @param {string[]} ids
 * @param {string} date `YYYY-MM-DD`; the caller owns the clock (scripts here take no Date).
 * @returns {{doc: object, marked: string[], unknown: string[]}}
 */
function setAnswered(doc, ids, date) {
  const wanted = new Set(Array.isArray(ids) ? ids : []);
  const marked = [];

  const next = {
    ...doc,
    sections: ((doc && doc.sections) || []).map((section) => ({
      ...section,
      questions: ((section && section.questions) || []).map((q) => {
        if (!wanted.has(q && q.id)) return q;
        marked.push(q.id);
        return settleQuestion(q, date);
      }),
    })),
  };

  const present = new Set(marked);
  return {
    doc: next,
    marked: marked.sort(byQuestionNumber),
    unknown: [...wanted].filter((id) => !present.has(id)).sort(byQuestionNumber),
  };
}

// The one phrasing for "how many questions did we emit, and how many did we drop", so every
// report path reads identically. Stays silent about exclusions when there were none.
function formatQuestionCount({ rows, total, excluded }) {
  const count = Array.isArray(rows) ? rows.length : rows;
  return excluded > 0
    ? `${count} of ${total} question(s) (${excluded} already answered)`
    : `${count} question(s)`;
}

// The one phrasing for the inverse — "what did applying the answers actually do" — shared by
// every import CLI for the same reason formatQuestionCount is shared: two callers reporting the
// same three counts in two different shapes is how an operator learns to read one and misread
// the other.
//
// Always three counts, never a single collapsed "skipped": the discarded-answer count is the only
// one that may need acting on, and folding it into the blanks hides it. Ids ride along in
// brackets — an empty list still prints, because `0 already answered []` and a missing line are
// not the same statement.
function formatAnswerCounts({ written, alreadyAnswered, blank }) {
  const part = (label, ids) => `${ids.length} ${label} [${ids.join(', ')}]`;
  return (
    `${part('answer(s)', written)}` +
    `; ${part('already answered', alreadyAnswered)}` +
    `; ${part('still blank', blank)}`
  );
}

/**
 * Validate a parsed store document.
 *
 * Returns problems rather than throwing so a caller can report all of them at once; the
 * store's `read()` is what turns a non-empty result into an error.
 *
 * The type checks are not defensive boilerplate — they are the backstop for the emission
 * rule above. A field that reaches this function as a boolean, number or null is a field
 * that was written as a bare scalar and then coerced by a parser, which is precisely the
 * failure this format exists to prevent. Catching it here means it surfaces as a named
 * problem rather than as a downstream projection rendering `false` into a question.
 *
 * @param {unknown} doc Parsed document.
 * @returns {string[]} Problems, empty when valid.
 */
function validate(doc) {
  const problems = [];

  if (doc === null || typeof doc !== 'object' || Array.isArray(doc)) {
    return ['document is not a YAML mapping'];
  }

  if (doc.schema !== SCHEMA_VERSION) {
    problems.push(
      `schema must be ${SCHEMA_VERSION}, found ${JSON.stringify(doc.schema)}` +
        (typeof doc.schema === 'string' ? ' (a string — write it unquoted)' : ''),
    );
  }
  if (!KINDS.includes(doc.kind)) {
    problems.push(`kind must be one of ${KINDS.join(' | ')}, found ${JSON.stringify(doc.kind)}`);
  }
  // Driven off DOCUMENT_FIELDS rather than a restated list, so adding a document field here is
  // enough for the validator to enforce it — the claim this module's header makes.
  for (const field of STRING_DOCUMENT_FIELDS) {
    if (field === 'kind') continue; // covered by the KINDS check above
    if (doc[field] !== undefined && typeof doc[field] !== 'string') {
      problems.push(`${field} must be a string, found ${describeType(doc[field])}`);
    }
  }
  for (const field of Object.keys(doc)) {
    if (!DOCUMENT_FIELDS[field]) problems.push(`${field} is not a known document field`);
  }

  if (!Array.isArray(doc.sections)) {
    problems.push('sections must be a list');
    return problems;
  }

  const seen = new Set();
  doc.sections.forEach((section, si) => {
    const where = `sections[${si}]`;
    if (section === null || typeof section !== 'object' || Array.isArray(section)) {
      problems.push(`${where} is not a mapping`);
      return;
    }
    if (section.title !== undefined && typeof section.title !== 'string') {
      problems.push(`${where}.title must be a string, found ${describeType(section.title)}`);
    }
    for (const field of Object.keys(section)) {
      if (!SECTION_FIELDS[field]) problems.push(`${where}.${field} is not a known section field`);
    }
    if (!Array.isArray(section.questions)) {
      problems.push(`${where}.questions must be a list`);
      return;
    }
    section.questions.forEach((q, qi) => {
      const at = `${where}.questions[${qi}]`;
      if (q === null || typeof q !== 'object' || Array.isArray(q)) {
        problems.push(`${at} is not a mapping`);
        return;
      }
      for (const field of REQUIRED_QUESTION_FIELDS) {
        if (q[field] === undefined) problems.push(`${at}.${field} is required`);
      }
      for (const [field, value] of Object.entries(q)) {
        if (!QUESTION_FIELDS[field]) {
          problems.push(`${at}.${field} is not a known field`);
          continue;
        }
        if (value !== undefined && typeof value !== 'string') {
          // The block-scalar advice applies only to prose fields. `id` and `status` are emitted as
          // bare scalars by design, so telling someone to write one as `|-` would have them produce
          // a file the writer immediately reverts — advice that is not a fixed point is worse than
          // none.
          problems.push(
            `${at}.${field} must be a string, found ${describeType(value)}` +
              (QUESTION_FIELDS[field].prose
                ? ' — write it as a block scalar (|-) so YAML cannot retype it'
                : ' — quote it so YAML cannot retype it'),
          );
        }
      }
      if (typeof q.id === 'string') {
        if (!ID_PATTERN.test(q.id)) {
          problems.push(`${at}.id must match q<N> with no leading zero, found ${JSON.stringify(q.id)}`);
        } else if (seen.has(q.id)) {
          problems.push(`${at}.id duplicates an earlier question id (${q.id})`);
        } else {
          seen.add(q.id);
        }
      }
      // Blank is not a valid status: "no status" is spelled by omitting the field, not by
      // writing an empty one — unlike the prose fields, where blank is the natural default for
      // "not written yet". `status` already has a name for that state (`open`).
      if (typeof q.status === 'string' && !STATUS_VALUES.includes(q.status)) {
        problems.push(`${at}.status must be one of ${STATUS_VALUES.join(' | ')}, found ${JSON.stringify(q.status)}`);
      }
      // Unlike `status`, blank IS valid here — `updated` behaves like the other optional prose
      // fields (blank means "not recorded"), it just also happens to need format-checking
      // whenever it does carry a value.
      if (typeof q.updated === 'string' && q.updated !== '' && !DATE_PATTERN.test(q.updated)) {
        problems.push(`${at}.updated must be YYYY-MM-DD, found ${JSON.stringify(q.updated)}`);
      }
      // An omitted `impact` is not just a style slip: it makes the question permanently invisible
      // to process-os-review-answer-application's high-impact-blockers report (SKILL.md's
      // "Blockers" section filters on `impact` starting `High`).
      if (section.title === SECTION_5_TITLE) {
        for (const field of SECTION_5_FORBIDDEN_FIELDS) {
          if (q[field] !== undefined) {
            problems.push(`${at}.${field} is not allowed in "${SECTION_5_TITLE}"`);
          }
        }
        if (q.impact === undefined) {
          problems.push(`${at}.impact is required in "${SECTION_5_TITLE}"`);
        }
      }
    });
  });

  return problems;
}

/** Type name for a problem message, distinguishing null from object. */
function describeType(value) {
  if (value === null) return 'null';
  if (Array.isArray(value)) return 'a list';
  return `a ${typeof value}`;
}

module.exports = {
  SCHEMA_VERSION,
  KINDS,
  ID_PATTERN,
  SECTION_5_TITLE,
  SECTION_5_FORBIDDEN_FIELDS,
  QUESTION_FIELDS,
  DOCUMENT_FIELDS,
  SECTION_FIELDS,
  PROSE_FIELDS,
  REQUIRED_QUESTION_FIELDS,
  STATUS,
  STATUS_VALUES,
  STATUS_LABELS,
  statusLabel,
  settleQuestion,
  ANSWERED,
  DATE_PATTERN,
  hasAnswerText,
  markedAnswered,
  isOpen,
  allQuestions,
  questionNumber,
  flatQuestions,
  byQuestionNumber,
  selectOpenQuestions,
  normalizeQuestionText,
  answersAgree,
  applyAnswers,
  setAnswered,
  formatQuestionCount,
  formatAnswerCounts,
  validate,
};
