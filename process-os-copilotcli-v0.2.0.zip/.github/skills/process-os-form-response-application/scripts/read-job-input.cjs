#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Extract one named key from the staged skillInput object.
//
// process-os-governance-job-activation stages the activated job's `skillInput`
// variable to .camunda/job-input.json as { "skillInput": { ...keys } }. This
// helper reads one key out of that object for a job skill to consume.
//
// A key that is absent, or present with a null value, is treated identically as
// "not provided" (exit 3, no stdout). A FEEL object literal such as
// `={a: a, b: b}` serializes a referenced-but-unset source variable as `b: null`,
// so `null` and "missing key" must mean the same thing to callers.
//
// Usage: node read-job-input.cjs <key> [<path-to-job-input.json>]
//   Default path: .camunda/job-input.json (relative to the project WD).
//
// stdout (present, non-null): strings verbatim; arrays/objects/numbers/booleans as JSON.
//
// Exit codes:
//   0  present
//   2  usage error (no key argument)
//   3  absent/null — routine, expected on most runs; no stderr
//   4  broken: job-input.json missing or unreadable
//   5  broken: job-input.json is not valid JSON
//   6  broken: job-input.json has no "skillInput" object
//
// Codes 4-6 print a one-line diagnostic to stderr; callers should treat them as a
// distinct failure from the routine "not provided" case (3) rather than lumping
// every non-zero exit together. `readJobInput` mirrors this in-process by throwing
// an Error whose `.code` is one of JOB_INPUT_FILE_MISSING / JOB_INPUT_INVALID_JSON /
// JOB_INPUT_NO_SKILL_INPUT for the broken cases, and returning `undefined` (no throw)
// for the routine absent/null case.

'use strict';

const fs = require('fs');

const DEFAULT_PATH = '.camunda/job-input.json';

const EXIT_CODES = {
  JOB_INPUT_FILE_MISSING: 4,
  JOB_INPUT_INVALID_JSON: 5,
  JOB_INPUT_NO_SKILL_INPUT: 6,
};

function readJobInput(key, filePath = DEFAULT_PATH) {
  let raw;
  try {
    raw = fs.readFileSync(filePath, 'utf8');
  } catch (err) {
    throw Object.assign(new Error(err.message), { code: 'JOB_INPUT_FILE_MISSING' });
  }
  let doc;
  try {
    doc = JSON.parse(raw);
  } catch (err) {
    throw Object.assign(new Error(`${filePath} is not valid JSON: ${err.message}`), {
      code: 'JOB_INPUT_INVALID_JSON',
    });
  }
  const si = doc && typeof doc === 'object' ? doc.skillInput : undefined;
  if (!si || typeof si !== 'object') {
    throw Object.assign(
      new Error(`${filePath} has no "skillInput" object; cannot read "${key}"`),
      { code: 'JOB_INPUT_NO_SKILL_INPUT' }
    );
  }
  const v = si[key];
  if (v === null || v === undefined) return undefined;
  return v;
}

if (require.main === module) {
  const key = process.argv[2];
  const filePath = process.argv[3] || DEFAULT_PATH;
  if (!key) {
    process.stderr.write('usage: read-job-input.cjs <key> [<path-to-job-input.json>]\n');
    process.exit(2);
  }
  let v;
  try {
    v = readJobInput(key, filePath);
  } catch (err) {
    process.stderr.write(`read-job-input.cjs: ${err.message}\n`);
    process.exit(EXIT_CODES[err.code] || 1);
  }
  if (v === undefined) process.exit(3);
  process.stdout.write(typeof v === 'string' ? v : JSON.stringify(v));
  process.exit(0);
}

module.exports = { readJobInput };
