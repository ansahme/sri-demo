---
name: process-os-forms-linting
description: >-
  Lint a single Camunda Form file or a directory of form files against the
  official @bpmn-io/form-json-schema. Use after creating or modifying any .form
  file and before any subsequent step (deployment, further generation, review,
  …) — schema validation catches structural and component-type mismatches that
  the Camunda Forms engine accepts at parse time but that produce broken UI
  behaviour or runtime errors. JSON Schema is enumeration-free (no rule IDs like
  bpmnlint), so this skill maps the most common error keywords to fix
  instructions.
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
# Form Lint

## Scope

The caller passes a **target** — either a single `.form` file or a directory:

- **Single file** (e.g. `process-implementation/artifacts/src/main/resources/forms/quote-request.form`): lint exactly that file.
- **Directory** (e.g. `process-implementation/artifacts/src/main/resources/forms/`): discover every `.form` file beneath it (recursive). Skip these directories during discovery: `.git`, `node_modules`, `target`, `build`, `.gradle`, `.mvn`, `.idea`, `.settings`, `.snapshots`.

If the target is ambiguous, ask once. Otherwise infer from the path (file extension `.form` → single-file mode; anything else → directory mode).

## When to run

Run after every change to a `.form` file in the target and again after each fix round. Only proceed to subsequent steps when validation reports zero errors. The "subsequent step" is whatever the caller is doing — deployment, further generation, review, hand-off — this skill is agnostic to it.

## How to run

The skill ships its own validator (`scripts/validate.cjs`) that wraps the vendored `@bpmn-io/form-json-schema` (`scripts/schema.json`). Packages (`ajv`, `ajv-formats`) are installed by `c8 os install` into `.camunda/node_modules`; the validator resolves them from that path directly — no caller-side environment setup needed.

```bash
# Single-file mode
node .github/skills/process-os-forms-linting/scripts/validate.cjs path/to/file.form

# Directory mode — pass the discovered files explicitly so skip-dirs are honoured
node .github/skills/process-os-forms-linting/scripts/validate.cjs <space-separated list of discovered .form files>
```

Exit codes: `0` = clean, `1` = at least one file has schema violations, `2` = usage error / missing args.

## Output shape

```
quote-request.form
  /components/1/key  error  property at this path is not allowed for the surrounding component type  false schema
  /components/2      error  missing required property "id"  required

✖ 2 problems (2 errors, 0 warnings)
```

Format per report line: `<JSON-pointer>  <severity>  <message>  <ajv-keyword>` (severity is always `error`; columns are separated by 2+ spaces). Lines starting with `✖` are summary only — ignore.

## Fix loop

1. Read each affected form file (it's plain JSON).
2. For every reported error, apply the fix instruction below (table) using a targeted Edit/patch — never rewrite the whole file.
3. Re-run the validator against the same target.
4. Repeat until the run is clean.
5. Then return control to the caller — they decide what comes next (deployment, further generation, review, …).

### Parallel dispatch (>3 files)

If the discovered set has **more than 3 `.form` files with reported errors**, do NOT fix them serially in the orchestrator session. Spawn one `Agent` (subagent_type `general-purpose`) per file (or batch of up to 3 files that share an obvious root cause) so fixes run in parallel. This is explicitly wanted — the per-file fix work is independent and the orchestrator session should not be flooded with raw validation output across many files.

Each dispatched agent receives:
- The exact file path(s) it owns.
- The validation output for those files only (filtered).
- A pointer back to this skill's keyword table so it applies the same fix instructions.
- Instruction to re-run `node .github/skills/process-os-forms-linting/scripts/validate.cjs <its files>` until clean and report back: files touched, keywords resolved, final status.

After all parallel agents return, run a single consolidated validation from the orchestrator to confirm the whole set is clean before reporting done.

For 3 or fewer files with errors, fix serially in the current session — the parallel-dispatch overhead isn't worth it.

## Keyword → fix instruction

JSON Schema errors don't have stable rule IDs. The validator surfaces ajv's `keyword` field as the rightmost column. Map it to a fix as follows:

| Keyword | What it means | Fix |
|---|---|---|
| `required` | A required property is missing at the JSON pointer (e.g. `id`, `type`, `key` on a component, or top-level `components`). | Add the named property. The error message tells you which one. For top-level form: ensure `type: "default"`, `id`, and `components` exist. |
| `additionalProperties` | The component (or form) has a property that isn't part of its allowed set. | Remove the offending property — its name appears in the error message. Common cause: copy-pasting between component types (e.g. a `values` array left over from a `select` after switching to `textfield`). |
| `false schema` | A property is present but explicitly forbidden for this component type (e.g. `key` on a `button`, `layout` on a top-level form with `type: "default"`). | Delete that property. Buttons and other action components don't carry data, so they don't need `key`. |
| `type` | A value's JSON type is wrong (e.g. `key` is a number instead of a string). | Cast or rewrite to the expected type — the message tells you the expected one. |
| `enum` | A value isn't one of the allowed strings. | Replace with one of the allowed values listed in the message. Common case: a custom component `type` that the schema doesn't recognise. |
| `const` | A value must be exactly a fixed constant (e.g. top-level `type` must be `"default"`). | Set it to that constant. |
| `pattern` | A string doesn't match the required regex (e.g. `id` and `key` must match `^[A-Za-z_][A-Za-z0-9_]*$`). | Rename so it satisfies the pattern. Replace hyphens/spaces with underscores; ensure it doesn't start with a digit. |
| `if` (only surfaced when no leaf error matches the same path) | A conditional schema branch failed. | Inspect the surrounding component — usually means the component type doesn't match its other properties. Fix the type or align the properties to what that type allows. |

For any other keyword: the ajv message is usually informative enough; treat the JSON pointer as the location and apply standard JSON-Schema reasoning.

## Note on schema versions

Form files carry a `schemaVersion` integer (e.g. `7`, `12`, `18`). The vendored `@bpmn-io/form-json-schema` enforces the **current** rule set — older Camunda Modeler exports may legitimately validate as invalid because the schema has tightened over time (a known case: `key` on `type: "button"` was once tolerated, now forbidden). When linting a form exported by an old Modeler version, prefer fixing the form to current rules over downgrading the schema. The vendored schema can be refreshed by replacing `scripts/schema.json` with a newer copy from `@bpmn-io/form-json-schema/resources/schema.json`.
