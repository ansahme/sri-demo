---
name: process-os-governance-job-completion
description: >-
  Complete or fail a Zeebe job, forwarding any outbound variable payload the job
  skill produced. Accepts jobKey as an optional direct argument (used by
  process-os-governance-job-activation's block branch); when omitted, reads the
  active job from governance state and clears it on completion. Use --fail to
  fail instead of complete; --message for an optional error message. Commits
  whatever the job left in the working tree, mode-gated — automatic in
  unattended mode, confirmed first in interactive mode.
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
Read `references/c8ctl.md` for the full c8ctl command reference.

Parse skill arguments:
- First positional argument → `<jobKey>` (optional — see Phase 0)
- `--fail` → fail the job instead of completing it
- `--message <msg>` → optional error message (fail only)
- `--profile <name>` → CLI override for the c8ctl profile; when omitted, fall back to
  `c8ctl-profile` from governance state (Phase 0) when it was read, otherwise omit the flag

---

## EXEC: Phase 0 — Read State

If `<jobKey>` was given as a direct argument, use it as-is and skip governance state entirely —
this is the direct-key call site used by `/process-os-governance-job-activation`'s block branch,
which already has the job key in hand and has no payload of its own to forward. Skip Phase 2, and
skip Phase 5 (there is no active-job state to clear for a job this skill never tracked). Go to
Phase 1's guard for the fail-argument-only case below, then to Phase 3 or 4.

Otherwise, check whether `.camunda/governance.json` already exists:
```bash
node ".github/skills/process-os-governance-job-completion/scripts/path-exists.cjs" .camunda/governance.json
```

If it exists, read governance state:
```bash
node ".github/skills/process-os-governance-job-completion/scripts/governance-state.cjs" read
```

Extract the following values for use in later phases:
- `active-job-key`
- `active-job-skill`
- `c8ctl-profile`

Use `active-job-key` as `<jobKey>` throughout the phases below. Resolve `<name>` in every
`--profile <name>` below the same way: the CLI-supplied `--profile` wins when given; otherwise use
`c8ctl-profile` from state; omit the flag entirely when neither is set.

---

## AI: Phase 1 — Guards

_Only when a direct `<jobKey>` argument was given:_ direct-key mode exists solely for
`/process-os-governance-job-activation`'s block branch, which always fails the job it just
activated — it is not a general-purpose "complete an arbitrary job" shortcut. If `--fail` is not
also present, print:

```
Direct <jobKey> completion requires --fail. Run /process-os-governance-job-completion with no
arguments to complete the active job tracked in governance state.
```

Stop.

_Only when no direct `<jobKey>` argument was given._

If `.camunda/governance.json` does not exist, print:

```
No governance state found. Run /process-os-governance-start first.
```

Stop.

If `active-job-key` is null or empty, print:

```
No active job found. Run /process-os-governance-job-activation first to activate a job.
```

Stop.

---

## EXEC: Phase 2 — Check Outbound Variable Payload

_Only when completing (i.e. `--fail` is **not** present) and no direct `<jobKey>` argument was
given — the direct-key call site never carries an outbound-variables payload._

Any job skill may emit an outbound variable payload that must be uploaded as process variables
when the Zeebe job completes. The convention is skill-agnostic:

- **Path:** `.camunda/job-outputs/<active-job-skill>.variables.json`
- **Contents:** a fully-formed JSON object mapping process-variable names to values —
  e.g. `{"discoveryQuestions": [ ... ]}`. Whatever the file contains is forwarded verbatim to
  `c8ctl complete job --variables`, so no key-wrapping or transform happens here.
- **Lifecycle:** the emitting skill writes the file; Phase 3 forwards it by reference and deletes
  it after a successful completion. Missing file = no `--variables` on completion.

```bash
node ".github/skills/process-os-governance-job-completion/scripts/path-exists.cjs" ".camunda/job-outputs/<active-job-skill>.variables.json"
```

When it exists, Phase 3 attaches `--variables @.camunda/job-outputs/<active-job-skill>.variables.json`.
When it does not, Phase 3 omits `--variables` entirely.

---

## EXEC: Phase 3 — Complete Job

_Only when `--fail` is **not** present._

```bash
c8ctl --json complete job <jobKey> [--variables @.camunda/job-outputs/<active-job-skill>.variables.json] [--profile <name>]
```

The `@` form reads the payload straight from the file — c8ctl parses and validates it as a JSON
object itself, so nothing here needs shell quoting or escaping. Omit `--variables` when Phase 2
found no payload file.

After a successful completion, delete the payload file so it does not leak into the next job —
only when Phase 2 found one:

```bash
node ".github/skills/process-os-governance-job-completion/scripts/remove-path.cjs" ".camunda/job-outputs/<active-job-skill>.variables.json"
```

Then go to Phase 5.

---

## EXEC: Phase 4 — Fail Job

_Only when `--fail` is present. This is a distinct call shape: it reaches neither Phase 5 (there
is no active-job state to clear) nor Phase 7 — on success it goes to Phase 6 and stops there._

```bash
c8ctl --json fail job <jobKey> --retries 0 [--errorMessage '<msg>'] [--profile <name>]
```

`<msg>` is arbitrary text (a caller-supplied `--message`, or the sanitized block reason forwarded
from `/process-os-governance-job-activation` — which strips CR/LF/`"`/`\`/`` ` ``/`$` but
deliberately leaves apostrophes, since those are safe in a double-quoted argument). Single-quoting
it here means a literal `'` (e.g. "couldn't generate") still terminates the argument early; escape
it before substituting, in the form the shell supports — bash/zsh close the quote, escape the `'` as
`'\''`, and reopen it; PowerShell 5.1+ doubles it as `''` inside the single-quoted string. Omit
`--errorMessage` if `--message` was not provided.

On success, go to Phase 6 with `--status failed`, then print `Job <jobKey> failed.` and stop. On
error (the `c8ctl fail job` call itself failed), print the c8ctl error output and stop — do not go
to Phase 6; nothing was durably recorded to commit.

---

## EXEC: Phase 5 — Clear Active State

_Only reached from Phase 3 (successful completion), and only when no direct `<jobKey>` argument
was given (governance state was read in Phase 0)._

```bash
node ".github/skills/process-os-governance-job-completion/scripts/governance-state.cjs" set active-job-key=— active-job-skill=— active-job-started-at=—
```

Go to Phase 6 with `--status completed`.

---

## EXEC: Phase 6 — Commit Working Tree

_Reached from Phase 5 (successful completion) and from Phase 4 (successful fail)._ Commits
everything the job left in the working tree, so it lands in git history instead of sitting as
uncommitted state.

Read `mode` from the run config and gate on it, per this repo's commit rule:

```bash
node ".github/skills/process-os-governance-job-completion/scripts/read-run-config.cjs" mode
```

Every call below to `scripts/commit-job-output.cjs` uses `--status completed` when this phase was
reached from Phase 5, or `--status failed` when reached from Phase 4; and passes
`--skill <active-job-skill>` whenever Phase 0 read governance state (the normal call shape, for
both phases) — omitted for a direct-`<jobKey>` fail call (Phase 0's direct-argument branch), which
never reads governance state and so never learns the skill name, in which case the script falls
back to a generic commit subject.

- `unattended` (the governance path) → run the commit directly and report it:
  ```bash
  node ".github/skills/process-os-governance-job-completion/scripts/commit-job-output.cjs" --status completed|failed [--skill <active-job-skill>]
  ```
- `interactive` → preview first, so the ProcessOS user sees exactly what would be committed:
  ```bash
  node ".github/skills/process-os-governance-job-completion/scripts/commit-job-output.cjs" --status completed|failed [--skill <active-job-skill>] --dry-run
  ```
  Show the previewed path list and **wait** for approval. If approved, repeat the same command
  without `--dry-run` to commit for real. If declined, report
  `left as uncommitted changes (commit declined)` and continue — do not run the real commit.
- Reader exit `2` (`run.config.yaml` missing/unparseable, or the project's Node dependencies
  missing) — mode itself cannot be determined, and this can be the very condition that led here:
  job-activation's own run-config-apply failure (Phase 7) reaches this phase through the
  direct-`<jobKey>` fail path for exactly this reason. Stopping here would leave that incident's
  marker uncommitted indefinitely, recreating the bug this fix exists to close. Fall back to the
  `unattended` command above (no preview) instead, and report the reader's stderr line alongside
  the commit outcome.

Exit codes:
- `0` — a real commit reports the short sha from its `committed … as <sha>` log line; a
  `--dry-run` preview has no sha yet — report its previewed path count and list instead.
- `2` — usage error. This indicates a bug in the invocation above, not a runtime condition; the
  script reports it on stdout, not stderr — report that line and stop.
- `3` — nothing to commit; the job left the tree exactly as it found it. Report this, not a
  commit — it is a legitimate outcome, not a failure.
- `4` — not a git work tree, or git is not installed. Report the stdout line and continue anyway —
  a project that is not (yet) under version control must not be blocked from advancing the
  governance process merely because it cannot also gain a commit.

If this phase was reached from Phase 4, print `Job <jobKey> failed.` (per Phase 4) followed by the
commit outcome line, then stop — do not go to Phase 7. Otherwise, continue to Phase 7.

---

## AI: Phase 7 — Report

_Only reached from Phase 6, on the completion path (from Phase 5). The fail path (Phase 4 via
Phase 6) reports and stops on its own, above._

On success, print the report below and then **stop** — the process instance owns the boundary
between one job and the next, so never run `/process-os-governance-job-activation` off the back of
this report, and never begin the next job's work.

```
Job <jobKey> completed.

Run /process-os-governance-job-activation when you are ready to activate the next job.
```

On error, print the c8ctl error output and stop.
