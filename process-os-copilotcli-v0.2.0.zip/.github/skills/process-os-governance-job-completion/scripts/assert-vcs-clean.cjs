#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Assert that the ProcessOS workspace is fully committed to version control.
//
// Currently supports git only. Detection and checking are split so additional
// VCS backends can be added later without reshaping the caller contract.
//
// Uses execFileSync (no shell) so quoting and path semantics are identical on
// Windows, macOS, Linux, and other Unix — the git CLI is the only dependency.
//
// Output: a human-readable summary on stdout, or a JSON object with --json.
// Exit codes:
//   0  clean      — every tracked and untracked (non-ignored) file is committed
//   1  dirty      — uncommitted changes and/or untracked files exist
//   2  no-vcs     — target is not inside a supported VCS working tree
//   3  no-tool    — the VCS CLI (git) is not installed / not on PATH
//
// Usage:
//   node scripts/assert-vcs-clean.cjs [<dir>] [--json]

'use strict';

const { execFileSync } = require('child_process');

function parseArgs(argv) {
  const opts = { dir: process.cwd(), json: false };
  for (const arg of argv) {
    if (arg === '--json') opts.json = true;
    else if (arg === '--help' || arg === '-h') opts.help = true;
    else if (!arg.startsWith('-')) opts.dir = arg;
  }
  return opts;
}

function runGit(dir, args) {
  return execFileSync('git', args, {
    cwd: dir,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
  });
}

// Returns 'git' if dir is inside a git work tree, null if git is present but the
// dir is not a repo. Throws { code: 'no-tool' } when git is not installed.
function detectGit(dir) {
  try {
    const out = runGit(dir, ['rev-parse', '--is-inside-work-tree']);
    return out.trim() === 'true' ? 'git' : null;
  } catch (err) {
    if (err && err.code === 'ENOENT') throw { code: 'no-tool' };
    // Non-zero exit (e.g. "not a git repository") — git exists, dir is not a repo.
    return null;
  }
}

// Parse `git status --porcelain=v1 -z --untracked-files=all` output.
// Each record is `XY<space>PATH`; renames/copies append a second NUL-separated
// origin path which we consume so it is not mistaken for a new record.
function parsePorcelainZ(raw) {
  const tokens = raw.split('\0');
  const entries = [];
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    if (t === '') continue;
    const x = t[0];
    const y = t[1];
    const path = t.slice(3);
    entries.push({ x, y, path });
    if (x === 'R' || x === 'C') i++; // skip the rename/copy origin token
  }
  return entries;
}

function classify(entries) {
  const staged = [];
  const unstaged = [];
  const untracked = [];
  for (const e of entries) {
    if (e.x === '?' && e.y === '?') untracked.push(e.path);
    else {
      if (e.x !== ' ' && e.x !== '?') staged.push(e.path);
      if (e.y !== ' ' && e.y !== '?') unstaged.push(e.path);
    }
  }
  return { staged, unstaged, untracked };
}

function checkGit(dir) {
  const raw = runGit(dir, [
    'status', '--porcelain=v1', '-z', '--untracked-files=all',
  ]);
  const entries = parsePorcelainZ(raw);
  const groups = classify(entries);
  return {
    vcs: 'git',
    clean: entries.length === 0,
    count: entries.length,
    ...groups,
  };
}

function report(result, json) {
  if (json) {
    process.stdout.write(JSON.stringify(result, null, 2) + '\n');
    return;
  }
  if (result.status === 'no-tool') {
    process.stdout.write('git is not installed or not on PATH — cannot assert VCS state.\n');
    return;
  }
  if (result.status === 'no-vcs') {
    process.stdout.write(`Not inside a git working tree: ${result.dir}\n`);
    return;
  }
  if (result.clean) {
    process.stdout.write('CLEAN — working tree fully committed (vcs: git).\n');
    return;
  }
  process.stdout.write(`DIRTY — ${result.count} uncommitted path(s) (vcs: git):\n`);
  const section = (label, files) => {
    if (files.length === 0) return;
    process.stdout.write(`\n  ${label} (${files.length}):\n`);
    for (const f of files) process.stdout.write(`    ${f}\n`);
  };
  section('Staged, not committed', result.staged);
  section('Modified, not staged', result.unstaged);
  section('Untracked', result.untracked);
  process.stdout.write('\n');
}

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) {
    process.stdout.write(
      'Usage: node assert-vcs-clean.cjs [<dir>] [--json]\n' +
      'Exit codes: 0 clean, 1 dirty, 2 no-vcs, 3 no-tool.\n'
    );
    process.exit(0);
  }

  let vcs;
  try {
    vcs = detectGit(opts.dir);
  } catch (err) {
    if (err && err.code === 'no-tool') {
      report({ status: 'no-tool', vcs: null, clean: false, dir: opts.dir }, opts.json);
      process.exit(3);
    }
    throw err;
  }

  if (vcs !== 'git') {
    report({ status: 'no-vcs', vcs: null, clean: false, dir: opts.dir }, opts.json);
    process.exit(2);
  }

  const result = checkGit(opts.dir);
  result.status = result.clean ? 'clean' : 'dirty';
  result.dir = opts.dir;
  report(result, opts.json);
  process.exit(result.clean ? 0 : 1);
}

main();
