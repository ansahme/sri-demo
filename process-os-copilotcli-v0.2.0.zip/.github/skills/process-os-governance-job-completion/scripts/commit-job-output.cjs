#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Commit whatever a completed (or failed) governance job left in the working tree.
//
// Unlike commit-intake.cjs (which commits an explicit, skill-known path list), a job skill's
// output shape is unpredictable from job-completion's point of view — any job skill may write,
// modify, or delete arbitrary project files. So this sweeps the whole tree with `git add -A`,
// which respects .gitignore, rather than naming paths: job-outputs/, feedback scratch files,
// and anything else the project's own .gitignore excludes are never swept in.
//
// Usage:
//   node commit-job-output.cjs --status completed|failed [--skill <name>] [--dry-run]
//
// stdout carries the human-readable log. Nothing goes to stderr: the caller is an agent
// reading combined output, and Windows PowerShell 5.1 promotes any native-command stderr
// write to an error record.
//
// Exit codes:
//   0  committed (or, with --dry-run, reported what would be committed)
//   2  usage error (unknown flag, missing value, missing/unknown --status)
//   3  nothing to commit — the job left the tree exactly as it found it
//   4  not a git work tree, or git is not installed

'use strict';

const { execFileSync } = require('child_process');

const STATUSES = ['completed', 'failed'];

const EXIT = {
  OK: 0,
  USAGE: 2,
  NOTHING: 3,
  NO_VCS: 4,
};

/**
 * @param {string[]} argv Arguments after the script path.
 * @returns {{status: string, skill: string|null, dryRun: boolean}}
 * @throws {Error} On an unknown flag, a missing value, or an unknown/missing --status.
 */
function parseArgs(argv) {
  let status = null;
  let skill = null;
  let dryRun = false;
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--status') {
      const value = argv[++i];
      if (value === undefined) throw new Error('--status requires a value');
      if (!STATUSES.includes(value)) {
        throw new Error(`unknown status: ${value} (expected ${STATUSES.join(' or ')})`);
      }
      status = value;
    } else if (arg === '--skill') {
      const value = argv[++i];
      if (value === undefined) throw new Error('--skill requires a value');
      skill = value;
    } else if (arg === '--dry-run') {
      dryRun = true;
    } else {
      throw new Error(`unknown argument: ${arg}`);
    }
  }
  if (status === null) throw new Error('--status is required');
  return { status, skill, dryRun };
}

function git(args) {
  return execFileSync('git', args, {
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
  });
}

/**
 * True if `git commit` can already resolve both an author and a committer identity — from
 * config or the `GIT_AUTHOR_*`/`GIT_COMMITTER_*` env vars — without this script supplying one.
 *
 * `git commit` needs both identities independently, and an environment can resolve one without
 * the other — e.g. `GIT_AUTHOR_NAME`/`GIT_AUTHOR_EMAIL` set with no committer env vars and no
 * `user.*` config. Checking only the author would call the identity complete and skip the
 * fallback below, and the commit would then fail on the missing committer identity.
 *
 * A governance job may run in an environment with no git identity configured anywhere, and
 * git's own auto-detection is not a safe fallback: it degrades to a bogus `user@hostname`
 * address on some hosts and refuses outright ("Please tell me who you are") on others — e.g.
 * a container whose hostname has no valid domain part. Checking first means a human's own
 * configured identity is never overridden; the fallback below only fires when none exists.
 */
function hasGitIdentity() {
  try {
    git(['var', 'GIT_AUTHOR_IDENT']);
    git(['var', 'GIT_COMMITTER_IDENT']);
    return true;
  } catch {
    return false;
  }
}

/**
 * @param {string} status 'completed' or 'failed'.
 * @param {string|null} skill The job's skill name, when known.
 * @returns {string} The Conventional Commits subject line.
 */
function commitSubject(status, skill) {
  if (status === 'failed') {
    return skill ? `chore(job): record ${skill} job failure` : 'chore(job): record job failure';
  }
  return skill ? `chore(job): commit ${skill} output` : 'chore(job): commit job output';
}

/**
 * Commit everything the job left in the working tree.
 *
 * @param {{status: string, skill: string|null, dryRun?: boolean}} options
 * @returns {{log: string[], code: number}}
 */
function commitJobOutput({ status, skill, dryRun = false }) {
  const log = [];
  try {
    if (git(['rev-parse', '--is-inside-work-tree']).trim() !== 'true') {
      log.push('not inside a git work tree — cannot record the job output');
      return { log, code: EXIT.NO_VCS };
    }
  } catch (err) {
    log.push(
      err && err.code === 'ENOENT'
        ? 'git is not installed or not on PATH — cannot record the job output'
        : 'not inside a git work tree — cannot record the job output',
    );
    return { log, code: EXIT.NO_VCS };
  }

  if (dryRun) {
    // A preview stages nothing. The caller shows this to a human who may still decline, so
    // the index has to be exactly as it was afterwards — staging first and reporting from
    // the staged diff leaves a declined preview's paths sitting in the index, where an
    // unrelated later commit picks them up.
    //
    // -z, because a path with a space or a quote is otherwise reported quoted and would be
    // logged with its quoting intact. No path filter: the whole tree is in scope, and
    // `git status` already excludes ignored files unless asked to include them.
    //
    // A rename/copy record (X or Y is 'R'/'C') emits a second, NUL-separated token carrying
    // the origin path with no "XY " prefix — treating every token alike would double-count the
    // rename and mangle the origin path by slicing 3 real characters off it. Skip that second
    // token instead, the same way assert-vcs-clean.cjs's parsePorcelainZ does.
    const tokens = git(['status', '--porcelain=v1', '-z', '--untracked-files=all']).split('\0');
    const pending = [];
    for (let i = 0; i < tokens.length; i++) {
      const t = tokens[i];
      if (t === '') continue;
      pending.push(t.slice(3));
      if (t[0] === 'R' || t[0] === 'C') i++;
    }
    if (!pending.length) {
      log.push('nothing to commit — the job left the tree exactly as it found it');
      return { log, code: EXIT.NOTHING };
    }
    log.push(`would commit ${pending.length} path(s):`);
    for (const p of pending) log.push(`  ${p}`);
    return { log, code: EXIT.OK };
  }

  git(['add', '-A']);

  // --cached, because everything in scope is staged by now: a plain diff would report
  // nothing and this would look like "no output" on a job that produced plenty.
  const staged = git(['diff', '--cached', '--name-only']).trim();
  if (staged === '') {
    log.push('nothing to commit — the job left the tree exactly as it found it');
    return { log, code: EXIT.NOTHING };
  }

  const identity = hasGitIdentity()
    ? []
    : ['-c', 'user.name=ProcessOS', '-c', 'user.email=noreply@camunda.com'];
  git(['-c', 'commit.gpgsign=false', ...identity, 'commit', '-m', commitSubject(status, skill)]);
  const commit = git(['rev-parse', 'HEAD']).trim();

  log.push(`committed ${staged.split('\n').length} path(s) as ${commit.slice(0, 8)}`);
  return { log, code: EXIT.OK };
}

module.exports = { EXIT, commitSubject, commitJobOutput, parseArgs };

if (require.main === module) {
  let options;
  try {
    options = parseArgs(process.argv.slice(2));
  } catch (err) {
    process.stdout.write(
      `${err.message}\n` +
        'usage: node commit-job-output.cjs --status completed|failed [--skill <name>] [--dry-run]\n',
    );
    process.exit(EXIT.USAGE);
  }
  const { log, code } = commitJobOutput(options);
  for (const line of log) process.stdout.write(`${line}\n`);
  process.exit(code);
}
