---
name: process-os-dmn-linting
description: >-
  Lint a single DMN file or a directory of DMN files with the centralised
  dmnlint binary and apply targeted fixes. Use after creating or modifying any
  .dmn file and before any subsequent step (deployment, further generation,
  review, …) — dmnlint catches structural and naming issues that the Camunda DMN
  engine accepts at parse time but that produce broken or unmaintainable
  decisions. Wraps `dmnlint:recommended` and translates each rule into a
  concrete fix instruction (the CLI emits "what is wrong" but never "how to
  fix"; this skill carries the mapping).
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
# DMN Lint

## Scope

The caller passes a **target** — either a single `.dmn` file or a directory:

- **Single file** (e.g. `process-implementation/artifacts/src/main/resources/decisions/quote-approval.dmn`): lint exactly that file.
- **Directory** (e.g. `process-implementation/artifacts/src/main/resources/decisions/`): discover every `.dmn` file beneath it (recursive). Skip these directories during discovery: `.git`, `node_modules`, `target`, `build`, `.gradle`, `.mvn`, `.idea`, `.settings`, `.snapshots`.

If the target is ambiguous, ask once. Otherwise infer from the path (file extension `.dmn` → single-file mode; anything else → directory mode).

## When to run

Run after every change to a `.dmn` file in the target and again after each fix round. Only proceed to subsequent steps when lint reports zero errors. The "subsequent step" is whatever the caller is doing — deployment, further generation, review, hand-off — this skill is agnostic to it.

## How to run

The skill ships a `scripts/validate.cjs` wrapper that handles dmnlint resolution, config and invocation — pass files, nothing else.

```bash
# Single-file mode
node .github/skills/process-os-dmn-linting/scripts/validate.cjs path/to/file.dmn

# Directory mode — pass the discovered files explicitly so skip-dirs are honoured
node .github/skills/process-os-dmn-linting/scripts/validate.cjs <space-separated list of discovered .dmn files>
```

The wrapper resolves and spawns dmnlint's JS entrypoint with `process.execPath` — never the
extensionless `.bin/dmnlint` shim, which cannot be exec'd on Windows. It looks for dmnlint under
`.camunda/node_modules` (the pinned version `c8 os install` provisions) and then the project root,
both resolved against the **current working directory**; when it is in neither, it falls back to
`npx --yes dmnlint` (zero-install, and slower).

**So run it from the project root**, which is where every agent session starts. Nothing in the
wrapper enforces that: invoked from anywhere else it finds no pinned install and silently takes the
slow `npx` path, with the version unpinned.

Exit codes: `0` = clean, `1` = lint issues found (parse stdout), `2` = usage error or dmnlint
could not be run (read stderr).

## Output shape

```
quote-approval.dmn
  InputData_13   error  Element is missing label/name       label-required
  Decision_12    error  Element is missing label/name       label-required

✖ 2 problems (2 errors, 0 warnings)
```

Format per report line: `<elementId>  <severity>  <message>  <ruleId>` (severity is `error` or `warning`; columns are separated by 2+ spaces). Lines starting with `✖` are summary only — ignore.

## Fix loop

1. Read each affected DMN file.
2. For every reported issue, apply the fix instruction below (table) using a targeted Edit/patch — never rewrite the whole file.
3. Re-run lint against the same target (single file or discovered set).
4. Repeat until the run is clean. **Fix all errors. Fix warnings unless there is a deliberate reason to keep them.**
5. Then return control to the caller — they decide what comes next (deployment, further generation, review, …).

### Parallel dispatch (>3 files)

If the discovered set has **more than 3 `.dmn` files with reported issues**, do NOT fix them serially in the orchestrator session. Spawn one `Agent` (subagent_type `general-purpose`) per file (or batch of up to 3 files that share an obvious root cause) so fixes run in parallel. This is explicitly wanted — the per-file fix work is independent and the orchestrator session should not be flooded with raw lint output across many files.

Each dispatched agent receives:
- The exact file path(s) it owns.
- The lint output for those files only (filtered).
- A pointer back to this skill's rule table so it applies the same fix instructions.
- Instruction to re-run `node .github/skills/process-os-dmn-linting/scripts/validate.cjs <its files>` until clean and report back: files touched, rules fixed, final status.

After all parallel agents return, run a single consolidated `node .github/skills/process-os-dmn-linting/scripts/validate.cjs <all files>` from the orchestrator to confirm the whole set is clean before reporting done.

For 3 or fewer files with issues, fix serially in the current session — the parallel-dispatch overhead isn't worth it.

## Rule → fix instruction (dmnlint:recommended)

| Rule | Fix |
|---|---|
| `label-required` | Add a descriptive `name` attribute to this element (Decision, InputData, BusinessKnowledgeModel, KnowledgeSource, DecisionService). The `id` is not user-facing — `name` is what shows in the modeler and in error messages. |
| `no-duplicate-requirements` | Remove the duplicate dependency edge. A decision must reference each of its inputs (`informationRequirement`, `knowledgeRequirement`, `authorityRequirement`) at most once. |

For any rule not in this table: review and fix according to DMN 1.3 best practices.

## Note on diagram interchange

DMN files generated programmatically often ship with a minimal `<dmndi:DMNDI>` block. dmnlint does not currently enforce DMNDI completeness, but every Decision and InputData element should still have a corresponding `DMNShape`, and every requirement edge a `DMNEdge` — otherwise the file renders broken in modelers even though lint stays green.
