---
name: process-os-deployment-code
description: >-
  Building block of process-os-deployment — validate the generated Java Spring
  Boot workers after the resources deploy. Statically cross-checks every
  @JobWorker job type against the deployed BPMN service-task job types
  (connectors excluded) to catch missing or stray workers, then boots the
  artifacts app with mvn spring-boot:run and confirms it starts cleanly,
  connects to the cluster, and subscribes one live worker per job type. Triages
  any failure as a project-independent detail to fix inline versus a structural
  defect in process-os-artifact-generation to fix in the generator. Normally
  invoked by process-os-deployment (which resolves both the c8ctl profile and
  the app's Spring profile, and owns lifecycle state); can also run standalone
  against an already-deployed process.
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
# /process-os-deployment-code

The **Java worker counterpart** to `/process-os-deployment-resources`. Deployment proves the
BPMN/DMN/forms reach the engine; this proves the workers that execute the service
tasks actually **start** and **connect to their tasks by job-type id**. The
orchestrator `/process-os-deployment` runs it right after `-resources` succeeds.

All cluster queries go through **c8ctl**; `mvn spring-boot:run` is used only to
run the workers, not to deploy.

**Inputs — `<PROFILE>` and `<SPRING_PROFILE>`.** The orchestrator
(`/process-os-deployment` Step 0) names the version-named c8ctl profile;
substitute that name literally wherever the c8ctl calls below write `<PROFILE>` —
it is a value you carry, not a shell variable. Running standalone? Resolve it
first (see `/process-os-deployment` Step 0).

`<SPRING_PROFILE>` is the **worker app's** connection config, and is a different
thing from `<PROFILE>`: `<PROFILE>` addresses the cluster for c8ctl, while
`<SPRING_PROFILE>` selects which `process-implementation/artifacts/src/main/resources/application-*.yaml`
the app boots with. It defaults to `local`; pass `saas` when the cluster
`<PROFILE>` points at is Camunda 8 SaaS. Step 2 has the mapping.

This skill does **not** write `.camunda/state.md` — the orchestrator owns the
lifecycle phase.

Two questions, answered cheapest-first:

1. Does every worker map to a task, and every task to a worker? (static, offline)
2. Do the workers actually boot and subscribe on a running cluster? (runtime)

## EXEC: Step 1 — Static binding cross-check

Every non-connector `<zeebe:taskDefinition type="X">` in the deployed BPMN must
have a `@JobWorker(type = "X")` in the Java, and vice versa. Connector task types
(containing `:`, e.g. `io.camunda:http-json:1`) are wired by element templates,
not workers, and are excluded.

```bash
node ".github/skills/process-os-deployment-code/scripts/validate-worker-bindings.cjs" process-implementation/artifacts
```

- Exit 0 → every BPMN job type has exactly one worker and there are no strays.
- Exit 1 → the JSON report lists `missingWorker` (a task no worker serves → it
  will raise a job-not-activated incident at runtime) and/or `strayWorker` (a
  `@JobWorker` whose type matches no task → dead code / a typo'd job type).
  Triage per Step 4 before booting — a missing worker cannot be fixed by starting
  the app.

## EXEC: Step 2 — Start the worker app and confirm clean boot

Deployment already sent the resources to the cluster; now bring the **workers**
up. The app's boot log and pid land in `.camunda/`, which belongs to one local
run — keep them out of the project's git history, then start the app in the
background against the running cluster:

```bash
node ".github/skills/process-os-deployment-code/scripts/append-gitignore.cjs" ".camunda/spring-worker-app.log" ".camunda/spring-worker-app.pid"
node ".github/skills/process-os-deployment-code/scripts/spring-worker-app.cjs" start --spring-profile "<SPRING_PROFILE>"
```

The append is idempotent — a second deployment run adds nothing.

**Pick `<SPRING_PROFILE>` to match the cluster `<PROFILE>` addresses**, or the
workers boot against the wrong cluster. The generated app ships exactly two
profiles, and `--spring-profile` chooses between them:

| Cluster `<PROFILE>` points at | `<SPRING_PROFILE>` | Env vars that profile reads |
|---|---|---|
| Local c8run, **or** a self-managed cluster | `local` (also the script default) | `CAMUNDA_CLIENT_GRPC_ADDRESS`, `CAMUNDA_CLIENT_REST_ADDRESS`, `CAMUNDA_CLIENT_AUTH_USERNAME`, `CAMUNDA_CLIENT_AUTH_PASSWORD` |
| Camunda 8 **SaaS** | `saas` | `CAMUNDA_CLIENT_ID`, `CAMUNDA_CLIENT_SECRET`, `CAMUNDA_CLOUD_CLUSTER_ID`, `CAMUNDA_CLOUD_REGION` |

`application-local.yaml` is `camunda.client.mode: selfmanaged`, so despite its name
it is also the right profile for a **remote** self-managed cluster — repoint its
`CAMUNDA_CLIENT_*_ADDRESS` vars instead of switching profile. Only SaaS needs
`saas`. Step 1 deploying fine proves nothing here: c8ctl and the app read their
connection settings from different places, so resources can land on a SaaS cluster
while workers booted under `local` never reach it.

`start` runs `mvn -q spring-boot:run -Dspring-boot.run.profiles=<SPRING_PROFILE>`
in `process-implementation/artifacts/` as a detached background process (`--dir` overrides the project
directory — and note the Spring profile flag is **not** `--profile`, which means
the c8ctl profile everywhere else in this skill and is rejected here as an unknown
flag), writing its combined output to `.camunda/spring-worker-app.log` and its pid to
`.camunda/spring-worker-app.pid`. Exit `2` means the app never started at all —
no Maven available, the project directory is missing, the log file couldn't be
created/truncated, the PID file couldn't be written (the just-spawned process is
killed rather than left running untracked), or the spawn itself never produced a
process.

Then wait for the boot verdict (it polls the log; the budget defaults to 120s, for
a cold Maven cache):

```bash
node ".github/skills/process-os-deployment-code/scripts/spring-worker-app.cjs" wait
```

- `STARTED` (exit 0) → the Spring context is up. Continue.
- `FAILED` (exit 1) → boot failed; the same line names the first
  `APPLICATION FAILED TO START` / `Error starting ApplicationContext` / `Caused by:`
  in the log. **Read `.camunda/spring-worker-app.log`** for the surrounding trace and
  triage per Step 4. Common connection failure: `io.grpc ... UNAVAILABLE` /
  connection refused → the cluster isn't reachable at
  `camunda.client.grpc-address` (Class A — start the cluster or fix the project's
  connection config). If Step 1 deployed resources to that cluster without
  trouble, check `<SPRING_PROFILE>` first: booting `local` against SaaS produces
  exactly this error.
- `TIMEOUT` (exit 1) → no verdict within the budget. Re-run `wait` with
  `--timeout-ms <ms>` before concluding the boot is stuck.

Leave the app running for Step 3 (and for a subsequent `/process-os-process-instance-start`
run); stop it when done:

```bash
node ".github/skills/process-os-deployment-code/scripts/spring-worker-app.cjs" stop
```

- Exit `0` → stopped, or there was nothing running (stopping an already-stopped
  app is success, so this can run blind). The boot log is deliberately kept for
  triage; only the pid file goes.
- Exit `1` → the app is **still running** and could not be signalled, even after
  SIGTERM then SIGKILL (a wedged JVM, or a permissions failure). The pid file is
  kept on purpose, because the process is still there. Do not report the workers
  as stopped: its job workers are still subscribed and will keep activating jobs,
  and a later `start` will report "already running" rather than booting a second
  app. Kill the pid named in the message by hand
  (`kill -9 <pid>` / `taskkill /pid <pid> /T /F`), confirm it is gone, then re-run
  `stop` to clear the pid file. If a port stays bound afterwards, that leftover
  process is why — see the `Port 8080/8090 was already in use` row in Step 4.

## EXEC: Step 3 — Confirm each worker subscribed

The Camunda Spring SDK logs one line per worker as it opens its subscription. At
the default log level it reads:

```
i.c.client.jobhandling.JobWorkerManager : Starting job worker: <bean>#<method> with type <jobType>
```

What follows the announcement varies with both the client version and the logger's
level — under DEBUG it is a `JobWorkerValue{...}` dump, whose field layout differs
between client versions. Let the script below identify the job types rather than
matching a shape by eye.

Collect the job types that actually started, and compare them to the deployed
BPMN's non-connector job types (the set Step 1 validated):

```bash
node ".github/skills/process-os-deployment-code/scripts/spring-worker-app.cjs" types
```

- Exit `0` → it prints the distinct job types from those log lines, sorted, one
  per line (and nothing at all when none have started).
- Exit `2` → the log announces workers in a shape the script cannot parse, and it
  names the offending lines. **Do not read this as "no worker subscribed"** — the
  subscription list is unverified, not empty. Read `.camunda/spring-worker-app.log`
  directly to confirm the workers by hand, and raise the unparsed shape against
  `process-os` so the parser learns it.

Every BPMN job type must appear in that list. Interpret gaps:

- A BPMN job type with **no** `Starting job worker` line → the worker did not
  subscribe even though the app booted (bean not registered, `enabled=false`, or
  a start error). At runtime this task raises a job-not-activated incident.
- A started type that is **not** a BPMN job type → a stray worker polling for
  jobs that never arrive (harmless at runtime, but usually a generator/typo bug —
  it is the `strayWorker` from Step 1 seen live).

Optional live confirmation via c8ctl — with the workers up, start one instance
and verify it is served (no job-not-activated incident):

```bash
c8ctl create pi --bpmnProcessId <MainProcessId> --profile "<PROFILE>"
c8ctl list inc --fields elementId,errorType,errorMessage --profile "<PROFILE>"
```

A job-not-activated incident on an element whose job type DID show a `Starting
job worker` line points at a runtime error inside the worker; on an element with
NO worker line, it confirms the missing/stray finding above.

## AI: Step 4 — Triage (same Class A / B classification as deployment)

Classify each failure by the same rule as `/process-os-deployment-resources` Step 3.6:

> **Would this failure occur for _any_ project generated by
> `process-os-artifact-generation`** (it lives in the generated code/config),
> **or only because of project-specific content the user still owes** (secrets,
> endpoints, a running cluster)?

**Class A — project-independent detail → fix inline (in the project, not process-os):**

| Signature | Fix |
|-----------|-----|
| Boot fails with `io.grpc ... UNAVAILABLE` / connection refused | Cluster not reachable — start it (`c8ctl cluster start`) or fix `camunda.client.grpc-address` in the project's `application*.yaml`. When Step 1 deployed to that cluster fine, the likelier cause is the wrong `<SPRING_PROFILE>` (`local` against a SaaS cluster) — re-run `start` with the profile from Step 2's table. |
| Boot fails on a missing secret / env var (connector or REST client) | Supply the project's secret/endpoint — a TODO the generator intentionally left. |
| `Web server failed to start. Port 8080/8090 was already in use` | Free the port or set `server.port`. |
| Worker throws a business-logic exception at runtime | Project code the user owns — fix the worker body. |

**Class B — structural defect in process-os-artifact-generation → fix the generator:**

| Signature | Root cause / fix |
|-----------|------------------|
| Step 1 `missingWorker`: a BPMN job type has no `@JobWorker` | The generator emitted a service task with no worker (or a mismatched job-type string). Fix the worker generation / job-type derivation in `skills/process-os-artifact-generation/` (`references/analyze-phase.md`, `references/generate-worker-class.md`). |
| Step 1 `strayWorker`: a `@JobWorker` type matches no BPMN task | The generated worker's `type` doesn't equal the BPMN `zeebe:taskDefinition type` — a job-type derivation mismatch. Fix the generator so both sides render the same string. |
| App fails to boot on generated code/config: compile error, malformed `application.yaml`, duplicate/misannotated bean | A generator template/output bug — fix the offending template under `skills/process-os-artifact-generation/`. |
| A worker is configured but never emits `Starting job worker` (bean not picked up) | The worker template omits what makes it a Spring bean (e.g. the stereotype annotation) — fix the template. |

For a Class B defect: fix the generator, extend its unit test to lock the fix,
regenerate, and re-run Steps 1–3. Because the defect is in the shared generator,
raise it against `process-os` (commit/PR), not just this project.

## Report

```
Worker validation — <profile> (workers booted under Spring profile <SPRING_PROFILE>)

  Static bindings:  <M> matched | <N> missing worker | <S> stray worker
  App boot:         Started in <T>s   (or: FAILED — <first Caused by>)
  Live subscriptions: <K>/<M> BPMN job types have a running worker

Triage:
  - <jobType/file>: Class A — <inline fix>
  - <jobType/file>: Class B — <generator defect + where fixed>

Next:
  /process-os-process-instance-start — start an instance and poll it to confirm workers pick up jobs (workers stay up)
  Stop the workers: node ".github/skills/process-os-deployment-code/scripts/spring-worker-app.cjs" stop
```

If any BPMN job type lacks a live worker, or any Class B defect is unfixed, say
so plainly — do not report a clean validation.
