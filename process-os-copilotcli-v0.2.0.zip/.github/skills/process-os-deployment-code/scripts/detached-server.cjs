#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Start and stop a long-running local HTTP server (the discovery dashboard, the
// BPMN viewer) from a portable Node entrypoint.
//
// This replaces the `.sh` launchers those skills used to ship. Every construct
// the shell versions relied on — `$(pwd)`, `[[ … ]]`, `kill -0`, `sleep 0.5`,
// backgrounding with `&`, `$!` — is bash-only, so a native Windows PowerShell
// agent could not run them at all and had to invoke the server entrypoint by
// hand.
//
// Two behavioural improvements fall out of the rewrite:
//
//   * Readiness is OBSERVED, not slept on. The shell version slept 0.5s and then
//     checked the process was still alive, which both raced a slow start and
//     reported success for a server that had not bound a port yet. Here the
//     launcher polls for the PID file the server itself writes immediately after
//     `listen()`, so "ready" means ready.
//   * A server that dies during startup is reported as a failure instead of
//     being missed by a fixed sleep.
//
// Both servers `console.log` their `server-started` JSON *before* writing the PID
// file, and the child inherits this process's stdout — so by the time the PID
// file exists the caller has already received the URL, in order, on stdout.

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

/**
 * Parse the launcher flags the skills pass. Unknown arguments are ignored, which
 * matches the shell versions' `*) shift ;;` catch-all.
 *
 * @param {string[]} argv Arguments after the script name (`process.argv.slice(2)`).
 * @returns {{projectDir: string, file: string | null}} `projectDir` defaults to
 *   the current working directory — the ProcessOS project root.
 */
function parseArgs(argv) {
  let projectDir = process.cwd();
  let file = null;
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--project-dir' && i + 1 < argv.length) projectDir = argv[++i];
    else if (argv[i] === '--file' && i + 1 < argv.length) file = argv[++i];
  }
  return { projectDir, file };
}

/**
 * Read a PID file, rejecting anything that is not a plain positive integer.
 *
 * @param {string} pidFile Absolute path.
 * @returns {number | null} The PID, or null when the file is absent or malformed.
 */
function readPid(pidFile) {
  let raw;
  try {
    raw = fs.readFileSync(pidFile, 'utf8');
  } catch {
    return null;
  }
  // A truncated or hand-edited file must not become `kill(NaN)` — and must not
  // become `kill(0)` either. On POSIX, signal 0 and SIGTERM sent to pid 0 go to
  // the CALLER'S OWN process group, so a file reading `0` would make isAlive()
  // report "running" and stop() terminate this shell instead of the server.
  // Hence a positive integer, not just any run of digits.
  const trimmed = raw.trim();
  return /^[1-9]\d*$/.test(trimmed) ? Number(trimmed) : null;
}

/**
 * Test whether a process exists.
 *
 * `signal 0` performs the permission/existence check without delivering a
 * signal, and works on Windows too. EPERM means the process exists but belongs
 * to another user — still alive for our purposes.
 *
 * @param {number} pid Process id.
 * @returns {boolean}
 */
function isAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (err) {
    return err.code === 'EPERM';
  }
}

/**
 * @param {number} ms Delay.
 * @returns {Promise<void>}
 */
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Remove a PID file, ignoring an already-absent one.
 *
 * @param {string} pidFile Absolute path.
 */
function removePidFile(pidFile) {
  try {
    fs.unlinkSync(pidFile);
  } catch {
    /* already gone */
  }
}

/**
 * Start a server as a detached child and wait until it is ready.
 *
 * @param {Object} opts Options.
 * @param {string} opts.serverEntry Absolute path to the server's `.cjs` entrypoint.
 * @param {string[]} [opts.serverArgs] Positional arguments for the server.
 * @param {string} opts.pidFile Absolute path to the PID file the server writes.
 * @param {string} opts.projectDir Project root, passed as `PROJECT_DIR`.
 * @param {Record<string, string>} [opts.env] Extra environment for the child.
 * @param {string} opts.label Human name used in messages, e.g. `Dashboard`.
 * @param {number} [opts.timeoutMs] Readiness budget. Default 10s.
 * @returns {Promise<number>} Process exit code.
 */
async function start({ serverEntry, serverArgs = [], pidFile, projectDir, env = {}, label, timeoutMs = 10000 }) {
  const existing = readPid(pidFile);
  if (existing !== null && isAlive(existing)) {
    process.stderr.write(`${JSON.stringify({ type: 'already-running', pid: existing })}\n`);
    return 0;
  }
  // A PID file left behind by a crashed server would otherwise block every
  // future start.
  if (existing !== null) removePidFile(pidFile);

  // process.execPath, never a shell — a bare `node` depends on PATH, and a shell
  // launcher is what this rewrite exists to remove.
  const child = spawn(process.execPath, [serverEntry, ...serverArgs], {
    cwd: projectDir,
    detached: true,
    // Without this, a detached child on Windows gets its own console window —
    // a stray terminal popping up behind the agent for the life of the server.
    // Matches resolve-node-cli.cjs, which sets it on every spawn.
    windowsHide: true,
    // The child inherits stdout, so its `server-started` JSON reaches the caller
    // exactly as it did when the shell backgrounded it with `&`.
    stdio: ['ignore', 'inherit', 'inherit'],
    env: { ...process.env, PROJECT_DIR: projectDir, ...env },
  });

  let exited = null;
  child.on('exit', (code, signal) => {
    exited = { code, signal };
  });
  // A spawn that never launched is not a slow start — report it as its own
  // outcome rather than waiting out the full timeout.
  let spawnError = null;
  child.on('error', (err) => {
    spawnError = err;
  });

  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const pid = readPid(pidFile);
    if (pid !== null && isAlive(pid)) {
      // Let this process exit without waiting on the server.
      child.unref();
      return 0;
    }
    if (spawnError) {
      process.stderr.write(
        `${JSON.stringify({ type: 'error', message: `${label} could not be started: ${spawnError.message}` })}\n`,
      );
      return 1;
    }
    if (exited) {
      const how = exited.signal ? `signal ${exited.signal}` : `exit code ${exited.code}`;
      process.stderr.write(
        `${JSON.stringify({ type: 'error', message: `${label} exited during startup (${how})` })}\n`,
      );
      return 1;
    }
    await sleep(50);
  }

  // Timed out. The child is not simply slow from the caller's point of view — it
  // never wrote a PID file, so `stop` has nothing to find and NOTHING downstream
  // can ever reap it. Leaving it alive would orphan a process still holding its
  // port, after this call already reported failure. Kill it, then unref so this
  // wrapper can exit even if the kill races the child's own startup.
  child.kill();
  child.unref();
  process.stderr.write(
    `${JSON.stringify({ type: 'error', message: `${label} did not become ready within ${timeoutMs}ms` })}\n`,
  );
  return 1;
}

/**
 * Stop a server started by {@link start}.
 *
 * @param {Object} opts Options.
 * @param {string} opts.pidFile Absolute path to the PID file.
 * @param {string} opts.label Human name used in messages, e.g. `Dashboard`.
 * @returns {number} Process exit code. Stopping an already-stopped server is
 *   success, so the caller can run this unconditionally.
 */
function stop({ pidFile, label }) {
  const pid = readPid(pidFile);
  if (pid === null) {
    // Nothing to signal either way, and a malformed file must still be cleaned
    // up — but the two causes are not the same thing, so do not report a file
    // that was found and rejected as a file that was never there.
    const found = fs.existsSync(pidFile);
    removePidFile(pidFile);
    process.stdout.write(found
      ? `No ${label} running (unreadable PID file removed).\n`
      : `No ${label} running (no PID file found).\n`);
    return 0;
  }
  if (!isAlive(pid)) {
    removePidFile(pidFile);
    process.stdout.write(`${label} was not running (stale PID file removed).\n`);
    return 0;
  }
  try {
    process.kill(pid);
  } catch (err) {
    process.stderr.write(`Could not stop ${label} (pid ${pid}): ${err.message}\n`);
    return 1;
  }
  // Windows has no SIGTERM handler support, so the server's own cleanup hook does
  // not run there — remove the PID file from this side either way.
  removePidFile(pidFile);
  process.stdout.write(`${label} stopped.\n`);
  return 0;
}

/**
 * Resolve the PID file a server uses. Always under the project's `.camunda/`.
 *
 * @param {string} projectDir Project root.
 * @param {string} name PID file basename, e.g. `dashboard.pid`.
 * @returns {string} Absolute path.
 */
function pidFilePath(projectDir, name) {
  return path.join(projectDir, '.camunda', name);
}

module.exports = { parseArgs, readPid, isAlive, removePidFile, start, stop, pidFilePath };
