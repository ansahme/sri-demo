#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Cross-check the generated Java job workers against the process job types they
// must serve: every non-connector `<zeebe:taskDefinition type="X">` in the BPMN
// must have a `@JobWorker(type = "X")` in the Java, and every `@JobWorker` must
// map to a real BPMN task type. A mismatch is a worker that will never activate
// (BPMN task with no worker → job-not-activated at runtime) or a worker that is
// never invoked (stray/typo'd job type).
//
// This is the worker-side counterpart to the c8ctl artifact deploy: it validates
// the binding "each worker connects to its expected task via job-type id"
// statically, against the same artifacts that were deployed — no manifest and no
// running app required (unlike audit-artifact-deps.cjs, which is manifest-driven
// and generation-time, and never flags a stray Java worker).
//
// Connector task types (containing ':', e.g. io.camunda:http-json:1) are wired by
// element templates / the connector runtime, NOT by generated workers, so they
// are excluded from the worker match on both sides.
//
// Usage:
//   node validate-worker-bindings.cjs [artifactsRoot]
//     artifactsRoot default: "process-implementation/artifacts"
//     Java from   <root>/src/main/java/**/*Worker.java
//     BPMN from    <root>/src/main/resources/processes/**/*.bpmn
//
// Output: a JSON report on stdout. Exit 0 when every BPMN job type has a worker
// and no worker is stray; exit 1 on any mismatch; exit 2 on bad inputs.

const fs = require('fs');
const path = require('path');

const ROOT = process.argv[2] || 'process-implementation/artifacts';
const javaDirOf = (root) => path.join(root, 'src', 'main', 'java');
const bpmnDirOf = (root) => path.join(root, 'src', 'main', 'resources', 'processes');

function walk(dir, suffix, out) {
  if (!fs.existsSync(dir)) return;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, suffix, out);
    else if (e.name.endsWith(suffix)) out.push(p);
  }
}

const isConnector = (type) => type.includes(':');

// Worker job types: every @JobWorker(type = "X") across all *Worker.java.
// A single file may declare more than one handler, so scan all matches.
function collectWorkerTypes(root) {
  const files = [];
  walk(javaDirOf(root), 'Worker.java', files);
  const byType = new Map(); // type -> [files]
  const re = /@JobWorker\([^)]*\btype\s*=\s*"([^"]+)"/g;
  for (const f of files) {
    const src = fs.readFileSync(f, 'utf8');
    for (const m of src.matchAll(re)) {
      const t = m[1];
      if (!byType.has(t)) byType.set(t, []);
      byType.get(t).push(path.relative(root, f));
    }
  }
  return byType;
}

// BPMN job types: every <zeebe:taskDefinition type="X"> across all processes,
// connector types excluded.
function collectBpmnTypes(root) {
  const files = [];
  walk(bpmnDirOf(root), '.bpmn', files);
  const byType = new Map(); // type -> [files]
  const re = /<zeebe:taskDefinition\b[^>]*\btype="([^"]+)"/g;
  for (const f of files) {
    const xml = fs.readFileSync(f, 'utf8');
    for (const m of xml.matchAll(re)) {
      const t = m[1];
      if (isConnector(t)) continue;
      if (!byType.has(t)) byType.set(t, []);
      byType.get(t).push(path.relative(root, f));
    }
  }
  return byType;
}

function validate(root = ROOT) {
  const workerTypes = collectWorkerTypes(root);
  const bpmnTypes = collectBpmnTypes(root);

  const matched = [];
  const missingWorker = []; // BPMN task type with no @JobWorker → job-not-activated
  const strayWorker = []; //   @JobWorker with no BPMN task type → never invoked

  for (const [t, files] of bpmnTypes) {
    if (workerTypes.has(t)) matched.push(t);
    else missingWorker.push({ jobType: t, bpmn: files });
  }
  for (const [t, files] of workerTypes) {
    if (!bpmnTypes.has(t)) strayWorker.push({ jobType: t, workers: files });
  }

  matched.sort();
  missingWorker.sort((a, b) => a.jobType.localeCompare(b.jobType));
  strayWorker.sort((a, b) => a.jobType.localeCompare(b.jobType));

  return {
    ok: missingWorker.length === 0 && strayWorker.length === 0,
    counts: {
      bpmnJobTypes: bpmnTypes.size,
      workerTypes: workerTypes.size,
      matched: matched.length,
      missingWorker: missingWorker.length,
      strayWorker: strayWorker.length,
    },
    matched,
    missingWorker,
    strayWorker,
  };
}

module.exports = { validate, collectWorkerTypes, collectBpmnTypes, isConnector };

if (require.main === module) {
  if (!fs.existsSync(javaDirOf(ROOT)) && !fs.existsSync(bpmnDirOf(ROOT))) {
    process.stderr.write(
      `validate-worker-bindings: neither ${javaDirOf(ROOT)} nor ${bpmnDirOf(ROOT)} exists — ` +
        `pass the artifacts root (got "${ROOT}").\n`,
    );
    process.exit(2);
  }
  const report = validate();
  process.stdout.write(JSON.stringify(report, null, 2) + '\n');
  if (!report.ok) {
    for (const m of report.missingWorker) {
      process.stderr.write(
        `✖ missing worker: BPMN job type "${m.jobType}" (${m.bpmn.join(', ')}) has no @JobWorker\n`,
      );
    }
    for (const s of report.strayWorker) {
      process.stderr.write(
        `✖ stray worker: @JobWorker(type="${s.jobType}") (${s.workers.join(', ')}) matches no BPMN task\n`,
      );
    }
    process.exit(1);
  }
  process.stderr.write(
    `✓ ${report.counts.matched} worker binding(s) matched; no missing or stray workers\n`,
  );
}
