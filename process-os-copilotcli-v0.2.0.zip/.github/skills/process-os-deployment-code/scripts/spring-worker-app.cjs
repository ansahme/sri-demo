#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Run the generated Spring Boot worker app in the background and read its boot
// log — start, wait for the boot verdict, list the job workers that subscribed,
// stop.
//
// Java/Maven/Spring Boot only, hence the name: it spawns `mvn spring-boot:run`,
// and both log verdicts it reads (`Started … in … seconds`, the Camunda Spring
// SDK's `Starting job worker` subscription line) are Spring's own output. A
// worker app in another language or framework needs its own runner alongside
// this one, not a branch inside it.
//
// Replaces the bash this skill used to hand the agent across Steps 2 and 3.
// Every line of it is bash-only:
//
//   LOG=$(mktemp -t worker-boot-XXXX.log)
//   ( cd process-implementation/artifacts && mvn -q spring-boot:run … ) > "$LOG" 2>&1 &
//   APP_PID=$!
//   grep -m1 "Started .* in .* seconds" "$LOG"
//   grep -oE "…" "$LOG" | grep -oE "…" | sed "s/…//" | sort -u > /tmp/started-types.txt
//   kill $APP_PID
//
// — the `VAR=$( )` captures, the `cd X && Y` subshell, `&` backgrounding, `$!`,
// `grep`/`sed`/`sort` (absent on Windows), and `/tmp` as a writable path. The
// `mvn` spawn is its own defect: on Windows Maven exists only as `mvn.cmd`, which
// Node refuses to spawn without a shell.
//
// The log lives at `.camunda/spring-worker-app.log` and the PID at
// `.camunda/spring-worker-app.pid`, so a later `stop` (or a second `wait`) needs
// nothing carried in a shell variable that does not survive the step.
//
// Usage:
//   node "scripts/spring-worker-app.cjs" start [--dir <maven-project>] [--spring-profile <profile>]
//   node "scripts/spring-worker-app.cjs" wait  [--timeout-ms <ms>]
//   node "scripts/spring-worker-app.cjs" types
//   node "scripts/spring-worker-app.cjs" stop
//
// Exit codes:
//   0  start: launched | wait: the app booted | types: printed | stop: stopped
//      (stopping an already-stopped app is success, so `stop` can run blind)
//   1  wait: the app failed to boot, died, or never reported within the budget |
//      stop: the process was alive but could not be signalled (e.g. permissions)
//   2  usage error, no Maven available, or the app could not be started at all —
//      in none of those did the workers come up, so this is never a clean boot |
//      types: the log announces workers in a shape this script cannot parse, so
//      the subscription list would be wrong rather than empty

const fs = require('fs');
const path = require('path');
const { spawn, spawnSync } = require('child_process');
const { findOnPath, quoteForCmd } = require(path.join(__dirname, 'resolve-node-cli.cjs'));
const { wrapperIn } = require(path.join(__dirname, 'run-maven.cjs'));
const {
  isAlive,
  readPid,
  removePidFile,
} = require(path.join(__dirname, 'detached-server.cjs'));

const EXIT = { OK: 0, FAILED: 1, DID_NOT_RUN: 2 };

const USAGE =
  'usage: spring-worker-app.cjs start [--dir <maven-project>] [--spring-profile <profile>]\n' +
  '       spring-worker-app.cjs wait [--timeout-ms <ms>]\n' +
  '       spring-worker-app.cjs types\n' +
  '       spring-worker-app.cjs stop\n';

const LOG_FILE = path.join('.camunda', 'spring-worker-app.log');
const PID_FILE = path.join('.camunda', 'spring-worker-app.pid');

const DEFAULT_PROJECT_DIR = path.join('process-implementation', 'artifacts');
const DEFAULT_SPRING_PROFILE = 'local';
// A cold Maven cache resolves the whole Camunda dependency tree before Spring
// even starts, which the shell form budgeted at "~90s".
const DEFAULT_TIMEOUT_MS = 120000;
// Shutdown budgets. A Spring context closing its Camunda client and its pools
// takes a moment; 10s covers that without making a stuck app hang the step.
const TERM_GRACE_MS = 10000;
const KILL_GRACE_MS = 2000;

const BOOTED = /Started .* in .* seconds/;
const BOOT_FAILED = /APPLICATION FAILED TO START|Error starting ApplicationContext|Caused by:/;
// The Camunda Spring SDK announces each subscription with one line. What follows
// the announcement takes one of three shapes, selected by the client version and
// by the logger's own level:
//
//   (a) JobWorkerValue{type='<type>', name='<bean>#<method>', ...}
//       Clients below 8.9, at any level.
//   (b) JobWorkerValue{autoComplete=..., name=<src>[value=<bean>#<method>],
//                      type=<src>[value=<type>]}
//       Clients 8.9 and above with DEBUG enabled on io.camunda.client.jobhandling.
//       Each field is a SourceAware record rendered "<Source>[value=...]", and
//       type is the last field.
//   (c) <bean>#<method> with type <type>
//       Clients 8.9 and above at INFO, which is the default.
//
// A pinned client version therefore does not settle which shape a run produces:
// 8.9's JobWorkerManager formats the JobWorkerValue only when isDebugEnabled(),
// and String.format("%s with type %s", name, type) otherwise.
const WORKER_ANNOUNCEMENT = 'Starting job worker: ';
const WORKER_VALUE_QUOTED = /^JobWorkerValue\{.*?\btype='([^']*)'/;
// Greedy to the last "type=", which is where (b) carries it. The capture stops at
// "," or "]" so a SourceAware holding a second component yields only the value.
const WORKER_VALUE_RECORD = /^JobWorkerValue\{.*\btype=\w+\[value=([^\],]*)/;
// Greedy on the name, so a worker whose own name contains " with type " splits at
// the last separator — the job type is what follows it.
const WORKER_NAME_AND_TYPE = /^.* with type (.+)$/;

/**
 * Parse argv into a command and its options.
 *
 * @param {string[]} argv Arguments after the script path.
 * @returns {{command: string, dir: string, springProfile: string, timeoutMs: number}}
 * @throws {Error} On an unknown command or flag, or a flag with no value.
 */
function parseArgs(argv) {
  const [command, ...rest] = argv;
  if (!['start', 'wait', 'types', 'stop'].includes(command)) {
    throw new Error(`unknown command: ${command === undefined ? '(none)' : command}`);
  }
  let dir = DEFAULT_PROJECT_DIR;
  let springProfile = DEFAULT_SPRING_PROFILE;
  let timeoutMs = DEFAULT_TIMEOUT_MS;
  for (let i = 0; i < rest.length; i++) {
    const arg = rest[i];
    // A flag whose value is missing would otherwise silently take the default
    // and run against the wrong project or budget.
    const value = () => {
      const v = rest[++i];
      if (v === undefined) throw new Error(`${arg} requires a value`);
      return v;
    };
    if (arg === '--dir') dir = value();
    // Deliberately NOT `--profile`, and with no alias for it: `--profile` means
    // the c8ctl profile name everywhere else in this skill, so accepting it here
    // for the unrelated Spring profile would silently take a c8ctl profile name
    // (`Camunda8.8`) as a Spring one. Rejected as an unknown flag instead, which
    // names the mix-up instead of running the app under a profile that has no
    // `application-Camunda8.8.yaml`.
    else if (arg === '--spring-profile') springProfile = value();
    else if (arg === '--timeout-ms') {
      const raw = value();
      if (!/^[1-9]\d*$/.test(raw)) throw new Error('--timeout-ms must be a positive integer');
      timeoutMs = Number(raw);
    } else throw new Error(`unknown flag: ${arg}`);
  }
  return { command, dir, springProfile, timeoutMs };
}

/**
 * The Maven command for `dir`: the project's own wrapper when it ships one, else
 * an installed `mvn`.
 *
 * Settling "is Maven available" here keeps a real absence distinguishable from a
 * launch that failed for some other reason.
 *
 * @param {string} dir Maven project directory.
 * @param {object} [deps]
 * @param {string} [deps.platform] Overridable platform, for tests.
 * @param {typeof findOnPath} [deps.onPath] Injectable PATH probe, for tests.
 * @returns {string|null} The command to spawn, or null when there is no Maven.
 */
function mavenCommand(dir, { platform = process.platform, onPath = findOnPath } = {}) {
  const wrapper = wrapperIn(dir, platform);
  if (wrapper) return wrapper;
  return onPath('mvn') ? 'mvn' : null;
}

/**
 * Start the worker app as a detached background process.
 *
 * @param {object} opts
 * @param {string} opts.dir Maven project directory.
 * @param {string} opts.springProfile Spring profile to run under.
 * @param {object} [deps]
 * @param {typeof spawn} [deps.spawnFn] Injectable spawner, for tests.
 * @param {string} [deps.platform] Overridable platform, for tests.
 * @param {typeof findOnPath} [deps.onPath] Injectable PATH probe, for tests.
 * @param {typeof killTree} [deps.killTree] Injectable terminator, for tests —
 *   used only to clean up a just-spawned child if its PID file can't be written.
 * @param {typeof fs.writeFileSync} [deps.writePidFile] Injectable PID-file
 *   writer, for tests forcing the write-failure path without needing a real
 *   unwritable path (a directory left at PID_FILE is no longer one — see the
 *   pre-flight cleanup above, which now removes it before this runs).
 * @returns {{status: number, message: string}}
 */
function start({ dir, springProfile }, deps = {}) {
  const spawnFn = deps.spawnFn || spawn;
  const platform = deps.platform || process.platform;
  const terminate = deps.killTree || killTree;
  const writePidFile = deps.writePidFile || fs.writeFileSync;

  if (!fs.existsSync(dir)) {
    return { status: EXIT.DID_NOT_RUN, message: `Project directory not found: ${dir}` };
  }
  // KNOWN LIMITATION, accepted: liveness is all that is checked, not identity.
  // If the recorded PID died and the OS handed the same number to an unrelated
  // process, this refuses to start ("already running") and `stop` would signal
  // that stranger. Establishing identity needs the process's command line, which
  // means `ps`/`tasklist` — a per-platform spawn, and a second "did the probe
  // itself run?" failure mode — for a window that only opens if the app dies
  // without `stop` running AND the PID wraps around to it before the next start,
  // on one developer machine driving one local cluster. The failure is also
  // visible rather than silent: the reported pid is in the message, and deleting
  // `.camunda/spring-worker-app.pid` clears it.
  const existing = readPid(PID_FILE);
  if (existing !== null && isAlive(existing)) {
    return { status: EXIT.OK, message: `worker app already running pid=${existing} log=${LOG_FILE}` };
  }
  // Whatever is at PID_FILE is stale at this point, whether readPid returned a
  // dead PID or null — and null covers both "nothing there" and "there but
  // unreadable/malformed", including a directory left at that path. The latter
  // would otherwise block every future start permanently: the writeFileSync
  // below keeps failing EISDIR with nothing to self-heal it, since the plain
  // unlink-only removePidFile can't remove a directory either. Best-effort,
  // and a no-op when nothing is there.
  try {
    fs.rmSync(PID_FILE, { force: true, recursive: true });
  } catch {
    // Not fatal here — an unremovable path still surfaces its own DID_NOT_RUN
    // via the writeFileSync guard below.
  }

  const command = mavenCommand(dir, { platform, onPath: deps.onPath });
  if (!command) {
    return {
      status: EXIT.DID_NOT_RUN,
      message: `No Maven wrapper in ${dir} and no mvn on PATH — the workers were not started.`,
    };
  }

  let log;
  try {
    fs.mkdirSync(path.dirname(LOG_FILE), { recursive: true });
    // Truncate: a `wait` must read THIS boot's verdict, not the previous run's
    // "Started … in 4.2 seconds" still sitting at the top of an appended log.
    log = fs.openSync(LOG_FILE, 'w');
  } catch (err) {
    // Nothing has been spawned yet at this point, so there is nothing to clean
    // up — unlike the PID-file-write guard below, which runs after the child
    // already exists.
    return { status: EXIT.DID_NOT_RUN, message: `Could not prepare ${LOG_FILE}: ${err.message}` };
  }
  const isWin = platform === 'win32';
  const rawArgs = ['-q', 'spring-boot:run', `-Dspring-boot.run.profiles=${springProfile}`];
  // Node's shell:true on win32 hands the whole command line to cmd.exe, which
  // re-tokenizes on whitespace — the same reason runShellCli quotes both the
  // command and its args. `command` is the resolved wrapper's absolute path,
  // which carries `dir` verbatim, so an unquoted space there (a project path
  // like `…\Jane Doe\artifacts\mvnw.cmd`) would otherwise split the command in
  // two rather than merely mis-splitting an argument.
  const child = spawnFn(
    isWin ? quoteForCmd(command) : command,
    isWin ? rawArgs.map(quoteForCmd) : rawArgs,
    {
      cwd: dir,
      detached: true,
      // Without this a detached child on Windows gets its own console window.
      windowsHide: true,
      // Both streams into the log, as the shell's `> "$LOG" 2>&1` did: Maven
      // writes the build failure to stderr and Spring the boot failure to
      // stdout, and dropping either loses half the reason a boot failed.
      stdio: ['ignore', log, log],
      // Node refuses to spawn a .cmd without a shell even given its absolute
      // path, and on Windows both the wrapper and mvn are .cmd files.
      shell: isWin,
    }
  );
  fs.closeSync(log);
  // A spawn that fails asynchronously — ENOENT, or EACCES on a wrapper that is
  // not executable — reports it as an 'error' event on the child, and Node
  // rethrows an unheard one as an uncaught error. That would end the CLI with a
  // stack trace instead of the {status, message} contract `!child.pid` below
  // already returns, so the event is heard and dropped. Guarded because the tests
  // inject a plain object as the child.
  if (typeof child.on === 'function') child.on('error', () => {});

  if (!child.pid) {
    return { status: EXIT.DID_NOT_RUN, message: `${command} could not be started.` };
  }
  try {
    writePidFile(PID_FILE, `${child.pid}\n`);
  } catch (err) {
    // The app is already running detached at this point. Without a PID file
    // `stop`/`wait`/`types` have no handle on it at all, so it would be left
    // running orphaned and untracked — best-effort kill it now, before unref,
    // rather than reporting a clean start the caller has no way to act on.
    try {
      terminate(child.pid, { signal: 'SIGTERM', platform });
    } catch {
      // Nothing more to do — the write failure is the one reported below.
    }
    // unref() regardless of whether terminate() above actually landed: this
    // CLI's own caller always follows with process.exit(), which doesn't wait
    // on child references anyway, but start() is an exported function other
    // callers can use directly — a still-referenced child (e.g. terminate
    // failing with EPERM) would otherwise keep such a caller's event loop
    // alive instead of letting it observe the DID_NOT_RUN below and move on.
    if (typeof child.unref === 'function') child.unref();
    return { status: EXIT.DID_NOT_RUN, message: `Could not write ${PID_FILE}: ${err.message}` };
  }
  child.unref();
  return { status: EXIT.OK, message: `worker app pid=${child.pid}  log=${LOG_FILE}` };
}

/**
 * Classify a boot log.
 *
 * Failure is checked FIRST: a log can contain both a stack trace and a later
 * "Started" line from a retry, and reporting the boot as clean when it carried a
 * `Caused by:` is precisely the misread this skill's triage exists to catch.
 *
 * @param {string} log Boot log contents so far.
 * @returns {{verdict: 'failed'|'booted'|'pending', detail: string|null}}
 */
function classifyLog(log) {
  const failure = log.split('\n').find((line) => BOOT_FAILED.test(line));
  if (failure) return { verdict: 'failed', detail: failure.trim() };
  if (BOOTED.test(log)) return { verdict: 'booted', detail: null };
  return { verdict: 'pending', detail: null };
}

/**
 * @param {number} ms Delay.
 * @returns {Promise<void>}
 */
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Poll the boot log until it reports success or failure.
 *
 * @param {object} opts
 * @param {number} opts.timeoutMs Budget.
 * @param {object} [deps]
 * @param {() => string} [deps.readLog] Injectable log reader, for tests.
 * @param {() => boolean} [deps.alive] Injectable liveness probe, for tests.
 * @param {(ms: number) => Promise<void>} [deps.wait] Injectable delay, for tests.
 * @param {() => number} [deps.now] Injectable clock, for tests.
 * @returns {Promise<{status: number, message: string}>}
 */
async function waitForBoot({ timeoutMs }, deps = {}) {
  // A transient read failure (e.g. an AV lock, or a race with Maven still
  // writing) is not a verdict — it is retried on the next poll like any other
  // not-booted-yet state. Left uncaught, it would end the CLI with an
  // unhandled-rejection stack trace instead of the documented exit contract,
  // the same class of gap `start`'s PID-file write already guards against.
  //
  // Cached by size: a cold-Maven-cache boot can run this poll ~480 times over
  // the default timeout, and re-reading a multi-MB log from byte 0 every time
  // regardless of whether it grew is wasted I/O that scales with the log, not
  // with what actually changed. A stat first, skipping the read entirely when
  // the size hasn't moved since the last poll, is a full order simpler than
  // real tailing (which would also have to handle `start`'s own truncation on
  // a fresh boot) while still catching the common case: most of a boot's
  // wall-clock is Maven resolving dependencies with nothing new to read.
  const readLog =
    deps.readLog ||
    (() => {
      let cachedSize = -1;
      let cachedContent = '';
      return () => {
        let size;
        try {
          size = fs.statSync(LOG_FILE).size;
        } catch {
          return '';
        }
        if (size === cachedSize) return cachedContent;
        try {
          cachedContent = fs.readFileSync(LOG_FILE, 'utf8');
          cachedSize = size;
        } catch {
          return '';
        }
        return cachedContent;
      };
    })();
  const alive =
    deps.alive ||
    (() => {
      const pid = readPid(PID_FILE);
      return pid !== null && isAlive(pid);
    });
  const wait = deps.wait || sleep;
  const now = deps.now || (() => Date.now());

  const deadline = now() + timeoutMs;
  for (;;) {
    const { verdict, detail } = classifyLog(readLog());
    if (verdict === 'booted') return { status: EXIT.OK, message: `STARTED  log=${LOG_FILE}` };
    if (verdict === 'failed') return { status: EXIT.FAILED, message: `FAILED  ${detail}\nlog=${LOG_FILE}` };
    // A process that exited without ever writing a verdict is a failure too —
    // the fixed sleep the shell form used missed this entirely.
    if (!alive()) {
      return { status: EXIT.FAILED, message: `FAILED  the worker app exited during startup\nlog=${LOG_FILE}` };
    }
    if (now() >= deadline) {
      return { status: EXIT.FAILED, message: `TIMEOUT  no boot verdict within ${timeoutMs}ms\nlog=${LOG_FILE}` };
    }
    await wait(250);
  }
}

/**
 * What each announcement in the log says about its worker, in log order.
 *
 * Split on the announcement rather than on the line: concurrent writers can
 * interleave two events onto one physical line, and keying off the line would
 * report only the first of them. Splitting per line first keeps a payload from
 * running past its own line end.
 *
 * @param {string} log Boot log contents.
 * @returns {string[]} One payload per announcement — the text following it.
 */
function workerPayloads(log) {
  const payloads = [];
  for (const line of log.split(/\r?\n/)) {
    // The head of the split is whatever preceded the first announcement.
    const [, ...rest] = line.split(WORKER_ANNOUNCEMENT);
    payloads.push(...rest);
  }
  return payloads;
}

/**
 * The job type an announcement names, in whichever shape it is written.
 *
 * @param {string} payload The text following one announcement.
 * @returns {string|null} The job type, or null if it is in neither shape.
 */
function typeFromPayload(payload) {
  const asQuoted = WORKER_VALUE_QUOTED.exec(payload);
  if (asQuoted) return asQuoted[1];
  const asRecord = WORKER_VALUE_RECORD.exec(payload);
  if (asRecord) return asRecord[1];
  // The type runs to the end of the payload, so it picks up any spacing before a
  // second announcement sharing the line. A job type never has edge whitespace.
  const asNamed = WORKER_NAME_AND_TYPE.exec(payload);
  if (asNamed) return asNamed[1].trim() || null;
  return null;
}

/**
 * The job types that opened a subscription, de-duplicated and sorted.
 *
 * @param {string} log Boot log contents.
 * @returns {string[]}
 */
function startedTypes(log) {
  const types = new Set();
  for (const payload of workerPayloads(log)) {
    const type = typeFromPayload(payload);
    if (type !== null) types.add(type);
  }
  return [...types].sort();
}

/**
 * The announcements matching none of the three shapes.
 *
 * An unreadable announcement means the worker is there but undetermined, not
 * absent, so `types` fails on these rather than printing a short list.
 *
 * @param {string} log Boot log contents.
 * @returns {string[]}
 */
function unrecognizedWorkerLines(log) {
  return workerPayloads(log)
    .filter((payload) => typeFromPayload(payload) === null)
    .map((payload) => `${WORKER_ANNOUNCEMENT}${payload}`);
}

/**
 * Terminate `pid`'s whole process tree: its process GROUP on POSIX, the
 * `taskkill /T` tree on Windows.
 *
 * `start` spawns with `shell: true` on win32 (Node cannot exec a `.cmd`
 * wrapper otherwise), so the recorded PID there is the intermediate
 * `cmd.exe`, not the Maven/Java process it launches. `process.kill` only
 * signals the one PID it's given, which would leave the real worker process
 * running as an orphan while the PID file is removed — the file would then
 * say "stopped" for an app that is not.
 *
 * @param {number} pid
 * @param {object} [deps]
 * @param {string} [deps.platform] Overridable platform, for tests.
 * @param {typeof spawnSync} [deps.run] Injectable runner for `taskkill`, for tests.
 * @param {typeof process.kill} [deps.kill] Injectable signal sender, for tests.
 * @throws {Error} If the process could not be terminated.
 */
function killTree(pid, deps = {}) {
  const signal = deps.signal || 'SIGTERM';
  if ((deps.platform || process.platform) !== 'win32') {
    const kill = deps.kill || process.kill;
    // The GROUP, not the leader. `start` spawns detached, so Maven leads a new
    // process group, and `spring-boot:run` runs the application in a JVM it forks
    // into that group. Signalling the positive PID alone reaps Maven and leaves the
    // app running with its workers subscribed, while stop() removes the PID file
    // and every later stop reports "not running".
    try {
      kill(-pid, signal);
      return;
    } catch {
      // EVERY failure falls through to the single PID, ESRCH included. ESRCH does
      // not prove the process is gone — it also means no group has this id, which
      // is exactly the case of a PID file written by a launcher that did not
      // detach. Returning there would delete the PID file and leave that process
      // running. If the process really has exited, the positive signal raises
      // ESRCH in turn and stop()'s liveness re-check reports it as stopped.
    }
    kill(pid, signal);
    return;
  }
  const run = deps.run || spawnSync;
  const result = run('taskkill', ['/pid', String(pid), '/T', '/F'], { encoding: 'utf8' });
  if (result.error || result.status === null) {
    throw new Error(`taskkill could not be started: ${result.error ? result.error.message : 'no exit status'}`);
  }
  if (result.status !== 0) {
    throw new Error((result.stderr || result.stdout || '').trim() || `taskkill exited ${result.status}`);
  }
}

/**
 * Stop a worker app started by {@link start}.
 *
 * Waits for the process to actually go before reporting success, escalating to
 * SIGKILL if SIGTERM is ignored — see the comment at the wait itself for why the
 * PID file cannot be removed any earlier.
 *
 * Removes the PID file but deliberately keeps `.camunda/spring-worker-app.log`.
 * The log is the evidence Step 4's triage reads, and the most common reason to
 * run `stop` at all is a boot that failed — deleting it here would throw away
 * the stack trace at exactly the moment it is needed. It does not accumulate
 * either: `start` truncates it, so the file only ever holds the latest run.
 *
 * @param {object} [deps]
 * @param {typeof isAlive} [deps.isAlive] Injectable liveness check, for tests.
 * @param {typeof killTree} [deps.killTree] Injectable process terminator, for tests.
 * @param {(ms: number) => Promise<void>} [deps.wait] Injectable delay, for tests.
 * @param {() => number} [deps.now] Injectable clock, for tests.
 * @param {typeof fs.rmSync} [deps.removePidPath] Injectable remover for a
 *   malformed/unreadable PID path, for tests forcing the removal-failure
 *   message without needing a real undeletable path.
 * @returns {Promise<{status: number, message: string}>} Stopping an
 *   already-stopped app is success, so a caller can run this unconditionally.
 */
async function stop(deps = {}) {
  const checkAlive = deps.isAlive || isAlive;
  const terminate = deps.killTree || killTree;
  const removePidPath = deps.removePidPath || fs.rmSync;
  const wait = deps.wait || sleep;
  const now = deps.now || Date.now;
  const pid = readPid(PID_FILE);
  if (pid === null) {
    // A malformed file must still be cleaned up, but "found and rejected" is not
    // the same state as "never there". removePidFile's plain unlink can't
    // remove a directory, and null covers that shape too (readPid can't parse
    // a PID out of one) — fs.rmSync handles both, and is a no-op if nothing
    // is actually there.
    const found = fs.existsSync(PID_FILE);
    let removeErr = null;
    try {
      removePidPath(PID_FILE, { force: true, recursive: true });
    } catch (err) {
      removeErr = err;
    }
    return {
      status: EXIT.OK,
      message: !found
        ? 'No worker app running (no PID file found).'
        : removeErr
          ? `No worker app running (unreadable PID file could not be removed: ${removeErr.message}).`
          : 'No worker app running (unreadable PID file removed).',
    };
  }
  if (!checkAlive(pid)) {
    removePidFile(PID_FILE);
    return { status: EXIT.OK, message: 'Worker app was not running (stale PID file removed).' };
  }
  try {
    terminate(pid, { signal: 'SIGTERM' });
  } catch (err) {
    // The app can exit between the liveness check above and the signal, and
    // `taskkill` then reports "process not found" as a non-zero status. The
    // requested state was reached, so re-check before calling it a failure —
    // otherwise a stale PID file survives and every later stop reports the same
    // error for a process that is long gone.
    if (!checkAlive(pid)) {
      removePidFile(PID_FILE);
      return { status: EXIT.OK, message: 'Worker app had already exited (stale PID file removed).' };
    }
    return { status: EXIT.FAILED, message: `Could not stop the worker app (pid ${pid}): ${err.message}` };
  }

  // Signal delivery is asynchronous, and a JVM takes a moment to shut down — or
  // declines to. The PID file is the ONLY handle on that process, so it cannot be
  // removed until the process is actually gone: dropping it early lets a later
  // `start` bring up a second worker app alongside the first, and leaves a later
  // `stop` with nothing to finish the job with.
  if (await waitGone(pid, TERM_GRACE_MS, { checkAlive, wait, now })) {
    removePidFile(PID_FILE);
    return { status: EXIT.OK, message: 'Worker app stopped.' };
  }
  // SIGTERM was ignored or is taking too long. Escalate: on Windows the first
  // `taskkill /F` was already forceful, so this repeats it harmlessly.
  try {
    terminate(pid, { signal: 'SIGKILL' });
  } catch (err) {
    if (!checkAlive(pid)) {
      removePidFile(PID_FILE);
      return { status: EXIT.OK, message: 'Worker app stopped.' };
    }
    return { status: EXIT.FAILED, message: `Could not stop the worker app (pid ${pid}): ${err.message}` };
  }
  if (await waitGone(pid, KILL_GRACE_MS, { checkAlive, wait, now })) {
    removePidFile(PID_FILE);
    return { status: EXIT.OK, message: 'Worker app stopped (it needed SIGKILL).' };
  }
  // The PID file stays: the process is still there, and a caller that reads
  // "stopped" here would leave it running with its workers subscribed.
  return {
    status: EXIT.FAILED,
    message: `Worker app (pid ${pid}) is still running after SIGTERM and SIGKILL; PID file kept. Check it by hand.`,
  };
}

/**
 * Poll until `pid` is gone, or the budget runs out.
 *
 * @param {number} pid
 * @param {number} budgetMs
 * @param {{checkAlive: typeof isAlive, wait: typeof sleep, now: () => number}} deps
 * @returns {Promise<boolean>} Whether the process is gone.
 */
async function waitGone(pid, budgetMs, { checkAlive, wait, now }) {
  const deadline = now() + budgetMs;
  for (;;) {
    if (!checkAlive(pid)) return true;
    if (now() >= deadline) return false;
    await wait(100);
  }
}

module.exports = {
  EXIT,
  LOG_FILE,
  PID_FILE,
  classifyLog,
  killTree,
  mavenCommand,
  parseArgs,
  start,
  startedTypes,
  stop,
  unrecognizedWorkerLines,
  waitForBoot,
};

if (require.main === module) {
  (async () => {
    let options;
    try {
      options = parseArgs(process.argv.slice(2));
    } catch (err) {
      process.stderr.write(`spring-worker-app.cjs: ${err.message}\n${USAGE}`);
      process.exit(EXIT.DID_NOT_RUN);
    }
    if (options.command === 'types') {
      // A read failure (permissions, a directory at that path) is treated as no
      // subscriptions yet rather than crashing outside the documented exit-code
      // contract — the same guard waitForBoot's default readLog applies.
      let log = '';
      try {
        log = fs.existsSync(LOG_FILE) ? fs.readFileSync(LOG_FILE, 'utf8') : '';
      } catch {
        // log stays ''
      }
      const unreadable = unrecognizedWorkerLines(log);
      if (unreadable.length) {
        process.stderr.write(
          `spring-worker-app.cjs: could not parse ${unreadable.length} job worker line(s):\n` +
            `${unreadable.map((line) => `  ${line}`).join('\n')}\n` +
            'The client logs a shape this script does not know. Read the log directly ' +
            `(${LOG_FILE}) and treat the subscription list as unverified.\n`
        );
        process.exit(EXIT.DID_NOT_RUN);
      }
      const types = startedTypes(log);
      if (types.length) process.stdout.write(`${types.join('\n')}\n`);
      process.exit(EXIT.OK);
    }
    const { status, message } =
      options.command === 'start'
        ? start(options)
        : options.command === 'stop'
          ? await stop()
          : await waitForBoot(options);
    process.stdout.write(`${message}\n`);
    process.exit(status);
  })();
}
