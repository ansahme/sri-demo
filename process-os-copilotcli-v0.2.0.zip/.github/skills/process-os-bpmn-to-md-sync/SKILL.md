---
name: process-os-bpmn-to-md-sync
description: >-
  Use when a BPMN diagram was hand-edited directly and its markdown pendant must
  be brought back in sync — reconciles the diagram's changes into the .md source
  of truth. Invoked when discovery or transformation fold in feedback, reusable
  standalone. Uniform across transformation tiers — reconciles into their .md
  and adds to feedback_overrides.json audit sidecar.

  USE FOR: process-os-bpmn-to-md-sync, reconcile hand-edited .bpmn into its .md,
  reverse-sync a diagram change into the docs.

  DO NOT USE FOR: generating or updating BPMN from markdown (use
  process-os-bpmn-generation), applying review answers (use
  process-os-review-answer-application), validating doc consistency (use
  process-os-markdown-integrity-check).
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
# /process-os-bpmn-to-md-sync

**WORKFLOW SKILL** — reverse-sync: reconcile a hand-edited BPMN into its markdown pendant.
INVOKES: nothing (leaf). Invoked by `/process-os-process-transformation`, when it folds in feedback, for diagrams the
ProcessOS user changed directly; reusable standalone.

Markdown is the single source of truth. Normally `.md` drives `.bpmn` (via `process-os-bpmn-generation`).
But when a ProcessOS user **hand-edits a diagram** — adding a step, renaming an element, re-routing a
branch — the `.md` falls behind. This skill closes that gap **in the other direction**: it
reads what changed in the `.bpmn` and reconciles those changes into the `.md`, **guided** by
the human so meaning is never silently rewritten.

## USE FOR
- Reconciling a hand-edited `process-NN-*.bpmn` / `edge-NN-*.bpmn` into its `.md`
- `/process-os-process-transformation`'s fold-in step, reconciling a hand-edited diagram back into markdown
- Any "the diagram changed, update the docs" reconciliation

## DO NOT USE FOR
- Generating / updating BPMN from markdown → `process-os-bpmn-generation` (incl. `--target/--from`)
- Applying answered review questions → `process-os-review-answer-application`
- Cross-document consistency checks → `process-os-markdown-integrity-check`

## EXEC: 1. Resolve inputs

| Var | Flag | Default |
|-----|------|---------|
| `FROM` | `--from <file.bpmn>` | required — the hand-edited diagram |
| `TO` | `--to <file.md>[,<file2.md>...]` | inferred — see *Pendant inference* below |

Both are values **you** substitute into the steps below, written there as `<FROM>` and `<TO>`.
Do not spell them as shell variables: shell state does not survive between steps, and on
PowerShell `"$FROM"` expands to nothing — `git diff HEAD -- ""` then diffs the whole tree and
reads as a clean, if enormous, answer.

### Pendant inference

- **Default (uniform across discovery and every transformation tier):** same-basename `.md` in
  the same directory as `FROM` — `process-NN-*.bpmn` → `process-NN-*.md`, `edge-NN-*.bpmn` →
  `edge-NN-*.md`. This holds for every phase now that a `.bpmn` and its `.md` pendant are always
  siblings inside one iteration's `artifacts/` directory — this is the **only** feedback target
  for every tier.
  ```
  /process-os-bpmn-to-md-sync --from process-transformation/iteration-2/artifacts/process-02-contracting.bpmn
  ```
- A caller reconciling **across** directories — a later transformation iteration's fold-in step
  reads a hand-edited diagram from the seeded iteration's `feedback/` and writes into the *new*
  iteration's `artifacts/` — passes `--to` explicitly instead of relying on the default:
  ```
  /process-os-bpmn-to-md-sync --from process-transformation/iteration-1/feedback/process-02-contracting.bpmn \
    --to process-transformation/iteration-2/artifacts/process-02-contracting.md
  ```
- **`verdicts.json`** is the pre-feedback intermediate (the frozen "as-analyzed" record) — it is
  **not** a feedback target and is never passed to `--to`.

If `FROM` is missing or not a `.bpmn` → stop. If no `--to` and no same-basename `.md` exists →
stop and ask which `.md` to reconcile into. (`00-overview.bpmn` has no single pendant — it
aggregates every `process-NN-*.md`; require an explicit `--to` for it.)

## EXEC: 2. Read what changed in the diagram (diff-first, bounded)

Substitute the resolved `FROM` path for `<FROM>` below — do not pass a literal shell variable,
skill steps run in fresh shells and PowerShell would not inherit it:

```bash
git diff HEAD -- "<FROM>"     # what the hand-edit changed (usually all you need)
```

Diff against `HEAD`, not the index: when folding in feedback the hand-edited `.bpmn` is still
untracked/modified (unstaged) when this skill runs, but diffing against the baseline commit
stays correct even if the file was (partially) staged — a plain `git diff` shows nothing for
staged changes.

If the diff is dangling / lacks context — or the changed attribute is a
`zeebe:modelerTemplateIcon`, whose base64 blob the diff carries whole — extract from the file
instead of slurping it. Full mode, not `--names`: the reconciliation in Step 3 below needs
branch conditions (re-routed gateways) and `bpmn:documentation` text (hand-added annotations),
both of which `--names` drops, and a single file's report never approaches the read cap:

```bash
node ".github/skills/process-os-bpmn-to-md-sync/scripts/bpmn-extract.cjs" "<FROM>"
```

For an **untracked** `.bpmn` (no baseline commit exists yet, so `git diff HEAD` is empty), this
extraction is the *only* input — there is no diff to fall back on.

Exit `2` → bad input (missing path, no `.bpmn` files, a dangling `--exclude`, or a malformed `--max-bytes`) — report stderr and stop. Exit `3` → the report is over the cap — re-run one file at a time.

Never single-Read a large `.bpmn` (≤ ~25 KB Read limit; a connector-bound one runs 1.5–3×
over) — extract or diff, or read bounded line ranges. Then read the target `.md` pendant(s)
to see the current documented flow.

## AI: 3. Derive the markdown delta

Translate the diagram change into a **documentation** change, element-by-element:

| Diagram change | Markdown reconciliation |
|----------------|-------------------------|
| Added task / event | add the step (with the right `[UserTask]/[ServiceTask]/…` tag) at the matching position |
| Removed element | remove the step (or mark it dropped, if load-bearing elsewhere) |
| Renamed element | rename the step; keep provenance if it was a confirmed fact |
| New / re-routed gateway branch | update the decision point and its branch descriptions |
| New annotation (Implementation/Manual/Follow-up) | fold the note into the step's sub-bullets |

Preserve the `.md`'s existing structure, provenance markers, and unaffected content. Use
business language (per `process-os-bpmn-generation` naming conventions) — no element ids or system jargon in
step names.

**Verdict-interpretation pass (uniform, every tier).** A hand-edit or a hand-added annotation on
an iteration's `*.bpmn` element is a correction to that step's automation disposition —
interpret it and write the result as a **marker edit in the matching `## Step N:` entry** of the
`.md` pendant (`**Recommendation:**` and `**Optimized type:**` fields under the step
heading; there is no JSON field to set instead):

*Annotation text → marker* (read the hand-added/changed `bpmn:documentation` on the element —
from the diff when present, or from the matching element's `documentation` field in the Step 2
extraction fallback):

| Annotation says… | `.md` marker written |
|------------------|-----------------|
| "keep as human step" / "retain" / "manual required" / "needs human" | `**Recommendation:** [RETAINED]` + `**Optimized type:** UserTask`, add/keep `- Manual: <reason>` and `- Origin: retained-as-is` |
| "just an API call" / "should be API" / "no human needed" | `**Recommendation:** [CHANGED]` + `**Optimized type:** ServiceTask`, add `- API: <endpoint/connector, if named>` |
| "automate this" / "AI can do this" | `**Recommendation:** [CHANGED]` + `**Optimized type:** AI ServiceTask (AI Agent)`, add `- AI task: <what it evaluates>` |
| "AI assist but keep human" / "co-pilot" / "human oversight" | `**Recommendation:** [CHANGED]` + `**Optimized type:** AI Co-Pilot`, add/keep `- Confidence: <threshold\|80%>`, `- Manual: <reason>`, and `- Origin: ai-copilot` |
| "wrong confidence threshold: X%" | keep the existing `**Recommendation:**`/`**Optimized type:**`; edit only the `- Confidence:` sub-bullet to `X%` |
| any other correction to the description | fold into the step's sub-bullets only; no marker change |

*Element-type change → marker* (when there's no annotation, infer from what the hand-edit now
shows): a `UserTask` hand-added where the `.md` says `[CHANGED]`/ServiceTask ⇒ `[RETAINED]`/UserTask
(and vice versa), a task swapped to a service call ⇒ `[CHANGED]`/ServiceTask, etc. — same mapping
as the annotation-text table above, just triggered by the element-type diff instead of prose.

*Structural changes:*
- **Renamed** element → rename the `## Step N: <name>` heading to the new name; the step keeps its
  `**Recommendation:**`/`**Optimized type:**` and sub-bullets (so any prior override stays attached
  to the right step).
- **Removed** from the BPMN → do **not** delete the step. Mark it `⚠ removed-in-feedback` (a note
  under the step, alongside its existing markers) — a later full run (Phases 0–6, or a full
  re-analysis) must reassess it.
- **Added** to the BPMN → add a new `## Step N: <name>` entry with `**Recommendation:** ❓ unclassified`,
  `- Note: Added by hand — verdict not yet assessed`, and `- Origin: new-by-transformation` —
  `generate-phase.md` treats `Origin:` as mandatory and never-omitted for a step that did not exist
  in the as-is process, so it must be present from the moment the step is added, not deferred to
  the later full-run reassessment.

**Write the audit to a uniform sidecar** — append an additive record (never remove/rewrite the
historical ones) to `feedback_overrides.json`, in the same directory as `<TO>`, for **every**
tier (incremental included):

```json
{
  "feedback_overrides": [
    {
      "task": "Approve Contract",
      "original": "[CHANGED] ServiceTask",
      "override": "[RETAINED] UserTask",
      "source": "annotation | element-change | structural",
      "file": "<the hand-edited .bpmn>",
      "reason": "<annotation text / diff description — verbatim>",
      "applied": "<YYYY-MM-DD>"
    }
  ]
}
```

`original` / `override` record the `.md` marker + optimized-type pair (before → after).

**Note it in the proposal pendant** (`proposal.md`, in the same directory as `<TO>` — every tier has one) — append an audit section:

```markdown
## Human Feedback Applied — <YYYY-MM-DD>

| Task | Original | Override | Source | Reason |
|------|----------|----------|--------|--------|
| <task> | <original> | <override> | annotation / element-change / structural | <one-line> |

### Structural Changes Noted
- Renamed: [old] → [new] — step heading updated
- Removed from BPMN: [name] — ⚠ removed-in-feedback; run full analysis to reassess
- Added to BPMN: [name] — ❓ unclassified; assess before next full run
```

Omit "Structural Changes Noted" when there were no structural changes. This proposal note is
narrative-only — the `.md` marker edit and the `feedback_overrides.json` sidecar above are the
two places that actually carry the override forward; this section documents it for humans reading
the proposal.

Present every proposed override — the `.md` marker edit, the `feedback_overrides.json` sidecar
entry, and any proposal edits — in the same Stage 4 (Guided reconciliation) gate as the rest of
the markdown delta — never write them unconfirmed.

## GATE: 4. Guided reconciliation (never blind)

This pass is **guided** — surface every proposed `.md` edit and let the human confirm or adjust
before writing. Read `processTransformationGate.md` from `run.config.yaml` (default `true`):

```bash
node ".github/skills/process-os-bpmn-to-md-sync/scripts/read-run-config.cjs" processTransformationGate.md
```

Exit 2 → hard error: report stderr and stop; it means the reader failed, not that the key is unset.

- `true` (attended) → present each derived `.md` change (and any **ambiguous** diagram edit
  whose intent isn't clear) for approve / reject / amend.
- `false` (unattended) → apply the unambiguous reconciliations; still list anything ambiguous
  for the human rather than guessing.

Never blindly overwrite the `.md` from the diagram — the diagram carries no provenance or
prose, so a wholesale rewrite would destroy documentation the `.bpmn` can't reproduce.

## Notes on the generator script

The hand-edit made `<FROM>.gen.mjs` (if present) **stale** — it no longer reproduces the
diagram. That is expected in Phase 5 (Sync-back): the hand-edited `.bpmn` is kept as-is and the `.md` is
reconciled to match. A later clean regeneration (`process-os-bpmn-generation --target <FROM> --from <TO>`)
will rebuild the `.gen.mjs` and diagram from the now-synced `.md` if you want the generated
layout back.

## Output

```
Reconciled <FROM> → <TO>

Applied to markdown (N):
  - <md>: <step/gateway/annotation/marker change>
Overrides recorded (O):
  - <task>: <original> → <override> (feedback_overrides.json)
Ambiguous — needs your call (K):
  - <the diagram edit whose intent is unclear>

The hand-edited .bpmn is unchanged; its pendant now matches — the `.md` (the live source) and,
if this run derived any verdict overrides, the `feedback_overrides.json` audit sidecar next to
`<TO>`. (<FROM>.gen.mjs is stale — regenerate with process-os-bpmn-generation --target/--from
if you want the generated layout back. This is uniform across every tier.)
```

When invoked by `/process-os-process-transformation`'s fold-in step, the caller stages the updated
`.md` and `feedback_overrides.json` sidecar itself — the hand-edited `.bpmn` is the ProcessOS
user's own change and is not staged here. Do not `git add` here unless run standalone and asked to.
