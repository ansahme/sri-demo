---
name: process-os-lifecycle-status
description: >-
  Use when you want to see the current lifecycle state of a process project —
  shows all phases, completion dates, output files, and what to do next
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
# /process-os-lifecycle-status

Show the current lifecycle status of this process project.

## Steps

### EXEC: 1. Read state file

Read `.camunda/state.md`. Note whether it was found.

If not found, output: "No process project found here. Run `/process-os-project-initialization` to start one." Skip steps 2 and 3 (there is no lifecycle state to read) and go directly to step 4 — a project can still have a governance connection with no discovery/transformation lifecycle started.

### EXEC: 2. Read config (if present)

_Only when `.camunda/state.md` was found in step 1._

Read `process-scope.md`. Note: process-name. Read the specialist list with
`node ".github/skills/process-os-lifecycle-status/scripts/read-run-config.cjs" specialists`.
If `process-scope.md` does not exist, skip its part of this step — the display will use only the state file data. If `run.config.yaml` does not exist the reader exits 2; treat that as "no specialists to display" and carry on rather than failing the status output.

### EXEC: 3. Check for in-progress or review-ready phases

_Only when `.camunda/state.md` was found in step 1._

Read `data/progress.json` if it exists. Note the `phase` field — this indicates the sub-state within the current lifecycle phase:
- `"review-ready"` — a review file is pending; check which one (see display cases below)
- `"transformation-synthesis-complete"` — transformation synthesis ran and the current iteration's `artifacts/` was generated
- `"transformation-feedback-complete"` — a later `/process-os-process-transformation` iteration finished folding in feedback

(`"review-complete"` appears transiently while a review skill updates state.md; treat as normal phase completion — no special display needed.)

If `.camunda/state.md` lists `process-os-process-discovery` as done or in progress, resolve its
current output directory:

```bash
node ".github/skills/process-os-lifecycle-status/scripts/iteration-dir.cjs" current process-discovery --complete --artifacts
```

Exit `0` → prints `process-discovery/iteration-<N>/artifacts` — the directory Step 5 shows as
`Output:` and probes for `review-questions.yaml`. Exit `3` → no iteration has completed yet; Step
5's display already handles this (there is simply nothing to show for `Output:` or the review
check).

If the discovery phase is `🔄 In Progress`, list the coverage files: `node ".github/skills/process-os-lifecycle-status/scripts/list-files.mts" --natural "data/coverage-round*.md"`. `--natural` orders by the embedded number, so the **last line is the latest research round** — read that file and note its coverage summary. If nothing is returned, skip.

If `.camunda/state.md` lists `process-os-process-transformation` as done or in progress, resolve its
current output directory:

```bash
node ".github/skills/process-os-lifecycle-status/scripts/iteration-dir.cjs" current process-transformation --complete --artifacts
```

Exit `0` → prints `process-transformation/iteration-<N>/artifacts` — the directory Step 5 shows as
`Output:` and probes for `review-questions.yaml`. Exit `3` → no transformation iteration has
completed yet; Step 5's display already handles this (there is simply nothing to show for
`Output:` or the review check).

### EXEC: 4. Check governance connection

_Always run this step, regardless of whether `.camunda/state.md` was found._

```bash
node ".github/skills/process-os-lifecycle-status/scripts/path-exists.cjs" .camunda/governance.json
```
If not found, note that and skip the rest of this step — no `Governance:` block will be shown.

If found, read local governance state:
```bash
node ".github/skills/process-os-lifecycle-status/scripts/governance-state.cjs" read
```
Note `cluster`, `c8ctl-profile`, `instance-key`, `active-job-skill`, `active-job-key`, `active-job-started-at`, `active-job-blocked`.

If both `cluster` and `instance-key` are non-null, fetch a live snapshot (omit `--profile` if `c8ctl-profile` is null):
```bash
c8ctl --json get pi <instance-key> [--profile <c8ctl-profile>]
```
Note the `state` field (e.g. `ACTIVE`, `COMPLETED`) and any start-timestamp field present in the response. If the command errors or produces unparseable output, treat live state as unreachable — do not fail the whole skill.

### AI: 5. Display

If `.camunda/state.md` was not found in step 1, the "No process project found here…" message from step 1 is the entire lifecycle portion of the output — skip straight to the Governance section below (steps 2–3 and the phase table do not apply).

Otherwise, output a clean overview — example format:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Process: Quote-to-Cash
Organization: Camunda
Started: 2026-04-23
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Lifecycle:
  ✅ process-os-process-discovery    2026-04-23  (3 research rounds · glean, dealhub, web)
                          Output: process-discovery/iteration-<N>/artifacts/ ([M] files)
  ⏳ process-os-process-transformation  → ready to run
  ⬜ process-os-artifact-generation    pending

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Next: /process-os-process-transformation
```

If discovery is in progress, add:
```
  🔄 process-os-process-discovery    round 2/5  (glean ✓, dealhub ✓, hdp running...)
     Last coverage: Quoting 80%, Contracting 70%, Billing 45%, Cash 30%
```

If process-os-process-transformation is running (`.camunda/state.md` shows `process-os-process-transformation` 🔄 In Progress):
```
  ✅ process-os-process-discovery    YYYY-MM-DD
  🔄 process-os-process-transformation  analysis running…
  ⬜ process-os-artifact-generation    pending
```

If a review is pending (progress.json phase = "review-ready"):
- If `<the resolved discovery directory from Step 3>/review-questions.yaml` exists and no
  transformation iteration has completed (Step 3's transformation resolution exited `3`):
```
  ✅ process-os-process-discovery    YYYY-MM-DD
                          Output: process-discovery/iteration-<N>/artifacts/ ([M] files)
     ⚠️  Review pending — the questions are in
         process-discovery/iteration-<N>/artifacts/review-questions.yaml (read-only).
         Put the answers in process-discovery/iteration-<N>/feedback/, then run:
         /process-os-sme-feedback
         /process-os-process-discovery
```
- If `<the resolved transformation directory from Step 3>/review-questions.yaml` exists:
```
  ✅ process-os-process-discovery    YYYY-MM-DD
  ⏳ process-os-process-transformation  ⚠️  Review pending — answer
                              process-transformation/iteration-<N>/artifacts/review-questions.yaml, then run:
                              /process-os-process-transformation
```

If transformation synthesis completed for the current iteration (progress.json phase =
"transformation-synthesis-complete"):
```
  ✅ process-os-process-discovery    YYYY-MM-DD
  ✅ process-os-process-transformation  YYYY-MM-DD
                          Output: process-transformation/iteration-<N>/artifacts/
                          Manual steps remaining: [N] (see process-transformation/iteration-<N>/artifacts/manual-steps.md)
  ⏳ process-os-artifact-generation    → ready to run
  ⬜ process-os-test-suite             pending
  ⬜ process-os-deployment             pending
```

Always show every phase in the lifecycle display, in this order: process-os-process-discovery, process-os-process-transformation, process-os-artifact-generation, process-os-test-suite, process-os-deployment. `process-os-bpmn-generation` is NOT a phase (it runs implicitly inside discovery and transformation); neither are `process-os-deployment-{resources,code}` — those are building blocks the single `process-os-deployment` phase orchestrates. Use ⬜ for phases not yet started, ⏳ for ready, 🔄 for in progress, ✅ for done.

**Governance section.** Right after the phase table (and `Next:` line, if `.camunda/state.md` was found), append a `Governance:` block whenever `.camunda/governance.json` was found in step 4 — using the fields gathered there:

- If `cluster` is null:
  ```

  Governance: not connected — run /process-os-governance-start
  ```
- Else if `instance-key` is null:
  ```

  Governance:
    cluster:        <cluster>
    c8ctl-profile:  <c8ctl-profile>
    no instance started — run /process-os-governance-start
  ```
- Else (both `cluster` and `instance-key` set):
  ```

  Governance:
    cluster:        <cluster>
    c8ctl-profile:  <c8ctl-profile>
    instance-key:   <instance-key>
    state:          <state> (live via c8ctl)
  ```
  Add a `started: <start-timestamp>` line only if the `c8ctl get pi` response contained a start-timestamp field. If the live `c8ctl get pi` call in step 4 failed or produced unparseable output, replace the `state:` line with:
  ```
    ⚠ could not reach cluster for live state
  ```
  Then, only if `active-job-key` is non-null, append:
  ```
    active job:     <active-job-skill>
      job key:      <active-job-key>
      started:      <active-job-started-at>
  ```
  Or, if `active-job-blocked` is non-null instead:
  ```
    ⚠ blocked:      <active-job-blocked>
  ```
  Finally, always append (omit `--profile` if `c8ctl-profile` is null):
  ```

    View in Operate: c8ctl open operate [--profile <c8ctl-profile>]
  ```

If `.camunda/governance.json` was not found, omit the `Governance:` block entirely.

### EXEC: 6. Plugins

Run the skew check and render one line per declared plugin at the bottom of the lifecycle display. The check is offline-safe (`check-plugin-skew.cjs` returns `status: "unreachable"` rather than failing).

```bash
node ".github/skills/process-os-lifecycle-status/scripts/check-plugin-skew.cjs" | node ".github/skills/process-os-lifecycle-status/scripts/strip-bom.cjs" | node -e "
const r = JSON.parse(require('fs').readFileSync(0,'utf8'));
if (r.length === 0) process.exit(0);
process.stdout.write('\nPlugins:\n');
let unreachable = 0;
for (const p of r) {
  if (p.status === 'up-to-date') process.stdout.write('  ✓ ' + p.name + ' @ ' + p.declaredRef + ' — up to date\n');
  else if (p.status === 'behind') process.stdout.write('  ↑ ' + p.name + ' @ ' + p.declaredRef + ' — newer commits available (' + p.installedSha.slice(0,7) + ' → ' + p.remoteSha.slice(0,7) + '). Run /process-os-discovery-plugin update ' + p.name + '\n');
  else if (p.status === 'not-installed') process.stdout.write('  ✗ ' + p.name + ' @ ' + p.declaredRef + ' — declared but not installed. Remove .camunda/registry/discovery/' + p.name + '.md (or restore .camunda/plugins/' + p.name + '/) to resolve.\n');
  else if (p.status === 'unreachable') unreachable++;
}
if (unreachable > 0) process.stdout.write('  ⚠ couldn\'t reach ' + unreachable + ' plugin source(s)\n');
"
```
