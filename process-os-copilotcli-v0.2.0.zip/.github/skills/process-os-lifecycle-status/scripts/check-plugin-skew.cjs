#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Skew detection for installed plugins.
//
// For each registry entry in .camunda/registry/*.md:
//   1. Run `git ls-remote <source> <ref>` with a bounded timeout.
//   2. Compare the remote SHA with the install's HEAD.
//   3. Report one of: up-to-date | behind | unreachable | not-installed.
//
// Outputs a JSON array on stdout and always exits 0.
//
// Usage:
//   node "scripts/check-plugin-skew.cjs" [--project-root <path>] [--timeout-ms <n>]
//
// --project-root defaults to process.cwd(), which is the ProcessOS project root.

'use strict';

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const DEFAULT_TIMEOUT_MS = 2000;

function extractFrontmatter(content) {
  const m = content.match(/^---\r?\n([\s\S]*?)\r?\n---(\r?\n|$)/);
  return m ? m[1] : null;
}

function parseFrontmatterScalars(text) {
  const obj = {};
  for (const raw of text.split(/\r?\n/)) {
    const ln = raw.replace(/#.*$/, '');
    const m = ln.match(/^([A-Za-z_][\w-]*):\s*(.+?)\s*$/);
    if (m) obj[m[1]] = m[2].replace(/^["']|["']$/g, '').trim();
  }
  return obj;
}

function readRegistry(projectRoot) {
  const registryDir = path.join(projectRoot, '.camunda', 'registry', 'discovery');
  if (!fs.existsSync(registryDir)) return [];
  return fs.readdirSync(registryDir)
    .filter(f => f.endsWith('.md'))
    .sort()
    .map(f => {
      const content = fs.readFileSync(path.join(registryDir, f), 'utf8');
      const fmText = extractFrontmatter(content);
      if (fmText === null) return null;
      const fm = parseFrontmatterScalars(fmText);
      if (!fm.source || !fm.ref) return null;
      return { name: f.replace(/\.md$/, ''), source: fm.source, ref: fm.ref };
    })
    .filter(Boolean);
}

function lsRemote(source, ref, timeoutMs) {
  try {
    const out = execFileSync('git', ['ls-remote', source, ref], {
      timeout: timeoutMs, stdio: ['ignore', 'pipe', 'pipe'], encoding: 'utf8',
    });
    const m = out.match(/^([0-9a-f]{40})\b/);
    return m ? m[1] : null;
  } catch {
    return null;
  }
}

// Returns the SHA string if the install dir exists and has a git HEAD,
// the sentinel symbol NOT_INSTALLED if the dir is absent,
// or null if the dir exists but git rev-parse fails (broken/empty repo).
const NOT_INSTALLED = Symbol('not-installed');

function installedSha(projectRoot, name) {
  const dir = path.join(projectRoot, '.camunda', 'plugins', name);
  if (!fs.existsSync(dir)) return NOT_INSTALLED;
  try {
    // execFileSync, matching lsRemote above: no shell means no cmd.exe on
    // Windows and nothing to quote.
    return execFileSync('git', ['rev-parse', 'HEAD'], {
      cwd: dir, stdio: ['ignore', 'pipe', 'ignore'], encoding: 'utf8',
    }).trim();
  } catch { return null; }
}

function main(argv) {
  const args = argv.slice(2);
  let projectRoot = null;
  let timeoutMs = DEFAULT_TIMEOUT_MS;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--project-root') projectRoot = args[++i];
    else if (args[i] === '--timeout-ms') timeoutMs = Number(args[++i]);
  }
  if (!projectRoot) projectRoot = process.cwd();

  const entries = readRegistry(projectRoot);
  if (entries.length === 0) {
    process.stdout.write('[]\n');
    process.exit(0);
  }

  const results = entries.map(entry => {
    const installed = installedSha(projectRoot, entry.name);
    if (installed === NOT_INSTALLED) {
      return { name: entry.name, status: 'not-installed', declaredRef: entry.ref };
    }
    const remote = lsRemote(entry.source, entry.ref, timeoutMs);
    if (remote === null) {
      return {
        name: entry.name, status: 'unreachable',
        declaredRef: entry.ref,
        ...(installed !== null && { installedSha: installed }),
      };
    }
    return {
      name: entry.name,
      status: installed === remote ? 'up-to-date' : 'behind',
      declaredRef: entry.ref,
      installedSha: installed,
      remoteSha: remote,
    };
  });

  process.stdout.write(JSON.stringify(results, null, 2) + '\n');
  process.exit(0);
}

if (require.main === module) main(process.argv);
