---
name: process-os-process-transformation
description: >-
  Use after process-os-process-discovery — generates exactly one transformation
  tier per run, either a to-be tier (incremental, radical, moonshot) or the
  lift-and-shift migration tier, chosen via the governance form or
  run.config.yaml, into a new iteration seeded from the last completed one and
  folded with its reviewer feedback; --bpmn also generates BPMN, and regenerate
  re-runs BPMN generation and finalization for the existing tier
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
# /process-os-process-transformation

Radically challenge and transform a process by questioning system necessity, data flow
efficiency, and AI replacement potential — or lift-and-shift it as-is with the `migration` tier.
Generates the selected tier's proposal, phase docs, and (optionally) BPMN into
`process-transformation/iteration-<N>/artifacts/`, alongside a transformation rationale document.
Every run opens a new iteration seeded from the last completed one and folds in whatever feedback
a reviewer filed against it before generating.

## EXEC: Parse Arguments

Resolve `$ARGS` (text after `/process-os-process-transformation`) into these variables, once, up front:

| Variable | Rule |
|---|---|
| REGENERATE_MODE | `$ARGS` has `regenerate` → true |
| BPMN_FLAG | `$ARGS` has `--bpmn` or `bpmn` → true. `--bpmn-mode` is a **different** flag — it never sets this |
| BPMN_MODE | `--bpmn-mode strategic` \| `automatable` — the modeling mode, resolved in Phase 3 via `scripts/resolve-bpmn-mode.cjs`, not here |
| UNATTENDED_ARG | `$ARGS` has `unattended` → `unattended`. Else: `node ".github/skills/process-os-process-transformation/scripts/read-run-config.cjs" mode` prints `unattended` → `unattended`, else `normal` |
| UNATTENDED | `read-run-config.cjs mode` prints `unattended` → true. **Config state only** — a bare `unattended` CLI arg never sets this |
| REBASELINE | `$ARGS` has `--rebaseline` → true |
| TIER | resolved by `scripts/resolve-run-tier.cjs` — see **Tier resolution** below |
| MIGRATION | derived: true when TIER is `migration` |

Exit 2 from either `read-run-config.cjs` call above → hard error: report stderr and stop; it means the reader failed, not that the key is unset.

**Tier resolution.**

```bash
node ".github/skills/process-os-process-transformation/scripts/resolve-run-tier.cjs" --source "<ARGS>"
```

`<ARGS>` is the verbatim text after `/process-os-process-transformation`, quoted even when empty.
Stdout is `TIER`, one bare token; `--source` adds a `# tier source: <where>` note on stderr —
carry both into the tier statement below.

| Exit | Means | Do |
|---|---|---|
| `0` | TIER is on stdout | use it |
| `2` | usage error, or ProcessOS Node deps missing | hard error: report stderr and stop |
| `3` | nothing resolved and the run is interactive | ask the user: "Which transformation scenario should this iteration generate? (migration / incremental / radical / moonshot)"; feed the answer back through the same resolver (`--source "<answer>"`) to re-check it against the keyword list, asking again on anything that is not one of the four |
| `4` | an explicit value is not a tier keyword | hard error naming the bad value from stderr |

`migration` is a **lift-and-shift** tier: it makes the as-is process executable without changing
it. Every other tier proposes change.

**Examples:**

| Invocation | Resolves to |
|---|---|
| (bare) | TIER per the resolver — prompts if interactive with nothing configured, else `incremental` under `unattended` |
| `migration` | TIER=migration, MIGRATION=true |
| `migration regenerate --bpmn` | re-runs Phase 3 over the existing seed, never re-seeds |
| `migration --bpmn-mode strategic` | **error** — see Phase 3 |

## EXEC: Route to Starting Phase

Pick the starting phase from the resolved variables — each phase checks its own requirements next, right before it reads its reference file:

- REGENERATE_MODE=true → start at **Phase 3**.
- Else MIGRATION=true → start at **Phase 0M**. Phase 1 and Phase 2 are skipped entirely: they
  exist to decide what to change, and this tier changes nothing.
- Else → start at **Phase 1**.

**`REGENERATE_MODE` deliberately outranks `MIGRATION`.** `regenerate` means the tier is already
seeded — act on what is there. Re-entering Phase 0M would re-copy discovery's as-is docs over
`<ARTIFACTS_DIR>` and discard any feedback this run just folded in, so `migration regenerate`
goes straight to Phase 3.

Update `.camunda/state.md` (for all three cases above): add a
`process-os-process-transformation` row if not present, set Status → `🔄 In Progress`.

## EXEC: Open the Iteration

Every run opens (or resumes) its iteration before its starting phase does anything. It seeds from
the last completed one only when it generates the **same tier**, so resolve that first:

```bash
node ".github/skills/process-os-process-transformation/scripts/previous-tier.cjs"
```

Stdout is `<PREV_TIER>`: the tier the last completed iteration recorded, `none` when there is no
completed iteration, or `unknown` when one exists whose tier cannot be established. Exit `5` → hard
stop; the tree could not be read, and guessing here is what carries one tier's documents into
another.

`<PREV_TIER>` is `none` or equals `<TIER>`, or REGENERATE_MODE=true → **seed**:

```bash
node ".github/skills/process-os-process-transformation/scripts/iteration-dir.cjs" open process-transformation --seed --json
```

**Otherwise it opens empty** — a `<TIER>` differing from `<PREV_TIER>`, `unknown`, or `migration`
without `regenerate` — so drop `--seed`:

```bash
node ".github/skills/process-os-process-transformation/scripts/iteration-dir.cjs" open process-transformation --json
```

A tier is a scenario derived from the as-is, not a delta on the previous one — every phase agent's
input is an `<AS_IS_DIR>` document. The previous iteration's phase docs, `proposal.md` and
`verdicts.json` describe the tier it generated, so carrying them into a different one leaves a
manifest naming one scenario over documents describing another. `unknown` counts as different: a
base whose scenario cannot be established is not one to build on. `migration` is stricter still —
its documents are a byte-identical copy of the as-is, which Phase 0M's seed refuses to overwrite,
and a change to a migrated process belongs in the as-is docs discovery owns.

Phase 1's reuse gate still carries the tier-independent `00-holistic-assessment.md` across, the
part a change of tier does not invalidate.

Capture `dir` as `<ITERATION_DIR>`, `artifacts` as `<ARTIFACTS_DIR>`, `iteration` as `<N>`.

| Exit | Means | Do |
|---|---|---|
| `0` | opened (or resumed); `--seed` copied forward, or was ignored on a resume | continue |
| `4` | a malformed `iteration-<N>` child name | hard stop |
| `5` | IO failure | hard stop |
| `6` | (`--seed` only) no previous iteration to seed from | REGENERATE_MODE=true → stop: "No completed transformation iteration to regenerate from." Else — first iteration: re-run without `--seed` and use that result |

**If REGENERATE_MODE=true, `<TIER>` is inherited rather than resolved** — it re-runs Phase 3
onward over analysis it did not produce, so that analysis's tier is the only label its output can
carry:

```bash
node ".github/skills/process-os-process-transformation/scripts/iteration-manifest.cjs" read "<ARTIFACTS_DIR>" --key tier
```

Capture stdout as `<TIER>`, replacing what Parse Arguments resolved. Exit `3` (no manifest) or
`4` (present but broken) → report the message and stop. A tier this run resolved that differs →
stop: `regenerate` cannot produce a different scenario from iteration `<N>`'s existing `<TIER>`
analysis; name `/process-os-process-transformation <the other tier>` without `regenerate`.

**Every run writes the manifest**, before any analysis work, so an interrupted iteration says what
it was for and a later `regenerate` has a tier to inherit — the inherited `<TIER>` under
REGENERATE_MODE, the resolved one otherwise:

```bash
node ".github/skills/process-os-process-transformation/scripts/iteration-manifest.cjs" write "<ARTIFACTS_DIR>" --phase transformation --iteration <N> --tier <TIER>
```

Exit `2` (usage error, or ProcessOS Node deps missing) → hard error: report stderr and stop.

## EXEC: Fold In Feedback, Then State the Run

```bash
node ".github/skills/process-os-process-transformation/scripts/iteration-dir.cjs" current process-transformation --complete --feedback
```

Exit `3` (iteration 1) → `<K>` = 0. Exit `0` → capture stdout as `<FEEDBACK_DIR>` and list it:

```bash
node ".github/skills/process-os-process-transformation/scripts/list-feedback.cjs" "<FEEDBACK_DIR>"
```

One filed name per line, the `README.md` scaffold excluded; `<K>` is that count. `0` is ordinary —
nothing to fold in. Collecting feedback is **process-os-sme-feedback**'s own invocation against a
committed-clean tree, before this one.

Before any analysis work, state the run:

```
Iteration <N>, seeded from iteration <N-1>.
Folding in feedback from iteration <N-1>: <K> file(s).
Generating the <TIER> tier.
```

Drop the first line's clause on iteration 1, and the second line when `<K>` is 0; the third
carries the resolver's `# tier source:` note.

`<K>` > 0 → read and follow [feedback.md](references/feedback.md), passing `<ARTIFACTS_DIR>`,
`<FEEDBACK_DIR>` and `<N>`, then continue into the phase **Route to Starting Phase** picked.

**Two cases fold nothing in**, both because `<ARTIFACTS_DIR>` holds no document the correction
could land on. Leave the files where they are, name the case, and continue:

- `migration` — empty until Phase 0M seeds it, and what it writes stays a byte-identical copy of
  the as-is. That correction belongs in the discovery documents this tier copies.
- **`<TIER>` differs from `<PREV_TIER>`** — the feedback is about the previous scenario's
  documents. Report the `<K>` file(s) and their location so the ProcessOS user can decide: re-run
  `<PREV_TIER>` to fold them in, or restate what still applies here.

## EXEC: Phase 0M: Migration Seed *(migration only)*

**Check requirements:** follow [the discovery-artifacts check](references/requirements-check.md);
capture stdout as `<AS_IS_DIR>`.

Requirements met → read and follow [migration-seed.md](references/migration-seed.md). Then move on
to **Phase 3**. Phase 1 and Phase 2 do not apply to this tier.

## AI: Phase 1: Baseline Analysis

**Check requirements:** follow [the discovery-artifacts check](references/requirements-check.md);
capture stdout as `<AS_IS_DIR>`.

**Reuse gate.** Phase 1 is the run's most expensive step, and its tier-independent output —
`data/transformation-bootstrap.md`, `data/transformation-criteria.md` and
`00-holistic-assessment.md` — can be reused rather than re-derived.

**The gate never applies when TIER is `incremental`, and `REBASELINE=true` always forces Phase 1
to run.** Phase 1 *is* the incremental analysis: it produces that tier's phase docs, proposal,
verdicts and tier-level documents, so skipping it would close an iteration holding none of them and
leave Phase 4 reading a proposal nobody wrote.

```bash
node ".github/skills/process-os-process-transformation/scripts/list-files.mts" --count data/transformation-bootstrap.md data/transformation-criteria.md
node ".github/skills/process-os-process-transformation/scripts/search-files.mts" --pattern "^## Optimization Context" --quiet data/transformation-bootstrap.md
node ".github/skills/process-os-process-transformation/scripts/iteration-dir.cjs" current process-transformation --complete --json
```

`TIER` is not `incremental`, `REBASELINE=false`, the first call counts `2`, the second exits `0`,
the third exits `0` **and** its printed `artifacts` path holds `00-holistic-assessment.md` (one more
`list-files.mts --count` against that path) → skip Phase 1. Output
`Reusing the baseline from iteration <N>.` — `<N>` being the third call's printed `iteration` —
then carry the baseline into this run:

```bash
node ".github/skills/process-os-process-transformation/scripts/carry-baseline.cjs" "<ARTIFACTS_DIR>"
```

Non-zero exit (`2` usage/IO, `3` no completed iteration, which the checks above should make
unreachable) → stop and report its message.

Anything else (`TIER` = `incremental`, `REBASELINE=true`, either of the first two checks fails, or
`iteration-dir.cjs` exits `3`) → requirements met → read and follow
[baseline-analysis-phase.md](references/baseline-analysis-phase.md). Either way, then move on to
**Phase 2**.

**Only `00-holistic-assessment.md` moves forward.** The previous iteration's phase docs are that
iteration's tier's, so carrying them would leave a manifest naming one tier over documents
describing another. This run gets its own from Phase 2's flatten, which reads `verdicts.json` and
`<AS_IS_DIR>`.

## AI: Phase 2: AI-Challenge

**Check requirements:** follow [the discovery-artifacts check](references/requirements-check.md);
capture stdout as `<AS_IS_DIR>`.

If TIER is `incremental` → skip this phase entirely, continue to **Phase 3** — Phase 1 already
produced `incremental`'s proposal and verdicts, and nothing here applies to it.

Requirements met → read and follow [ai-challenge-phase.md](references/ai-challenge-phase.md). Then
move on to **Phase 3**.

## AI: Phase 3: BPMN Generation

**Check requirements:** follow [the discovery-artifacts check](references/requirements-check.md);
capture stdout as `<AS_IS_DIR>`.

If REGENERATE_MODE=true **and** MIGRATION=true, this tier has no analysis phase, so the analysis
checks below do not apply. Require only its seed:

```bash
node ".github/skills/process-os-process-transformation/scripts/list-files.mts" --count "<ARTIFACTS_DIR>/proposal.md" "<ARTIFACTS_DIR>/verdicts.json"
node ".github/skills/process-os-process-transformation/scripts/list-files.mts" --count "<ARTIFACTS_DIR>/process-[0-9]*-*.md"
```

First `<2` or second `0` → stop: "No seeded migration tier found. Run
`/process-os-process-transformation migration` (without `regenerate`) first." Both pass → output:
"Regenerate mode — reusing the existing migration seed. Jumping to the Phase 3 BPMN decision.",
then continue at the MODE resolution below. Phase 0M is **not** re-entered — re-seeding would
clobber feedback already folded in.

Otherwise, if REGENERATE_MODE=true (entered directly, skipping Phases 1 and 2) → read and follow
[the regenerate-mode gate](references/regenerate-gate.md), which establishes that the analysis this
run generates over is actually present, then return here for the MODE resolution below.

**If MIGRATION=true**, MODE is always `automatable` — executable output is this tier's definition.
Run the resolver anyway, purely to detect a *conflicting* setting:

```bash
node ".github/skills/process-os-process-transformation/scripts/resolve-bpmn-mode.cjs" --source "<ARGS>"
```

If it prints `strategic`, stop, naming the source from its `# mode source:` note on stderr:

> `migration` produces executable BPMN by definition — `--bpmn-mode strategic` (from
> `<args | run.config.yaml | transformation.config.md>`) would strip the connector bindings and
> Zeebe extensions that make it executable. Drop that setting, or drop `migration`.

Otherwise proceed with MODE=`automatable`. Read the resolver's *output*, not `$ARGS`: it reads
`--bpmn-mode` from all three sources named above, so an args-only check would let a config-carried
`bpmn-mode: strategic` override the tier silently.

Requirements met → decide whether to generate BPMN:

0. The fold-in changed a `.md` with a `.bpmn` pendant → generate, no prompt: seeding copied the
   previous diagrams in, and declining would close the iteration with BPMN describing documents
   that have since changed.
1. Else BPMN_FLAG=true → generate, skip the prompt.
2. Else UNATTENDED=true → generate, skip the prompt.
3. Else → ask the user: "Generate BPMN for the selected tier now? (recommended) [Y/n]". `Y`/empty/yes → generate. `n`/no → skip entirely; output: "No BPMN generated for this run — this iteration's `proposal.md` and `verdicts.json` are the deliverable. Run `/process-os-process-transformation regenerate --bpmn` to add BPMN later without re-running the analysis." (Phase 4 tolerates missing `.bpmn` files.)

If generating: read and follow [generate-bpmn-phase.md](references/generate-bpmn-phase.md) —
resolves MODE and dispatches the BPMN-generation subagent for this tier.

## AI: Phase 4: Rationale Synthesis

Dispatch a subagent. **If MIGRATION=true**, it follows
[migration-rationale-agent.md](references/migration-rationale-agent.md):

```
Read references/migration-rationale-agent.md and follow it.

AS_IS_DIR: <AS_IS_DIR>
ARTIFACTS_DIR: <ARTIFACTS_DIR>
TIER: <TIER>
```

Otherwise it follows [rationale-agent.md](references/rationale-agent.md):

```
Read references/rationale-agent.md and follow it.

AS_IS_DIR: <AS_IS_DIR>
ARTIFACTS_DIR: <ARTIFACTS_DIR>
TIER: <TIER>
```

A dispatched subagent never resolves the iteration itself. The caller holds `<ARTIFACTS_DIR>` from
the moment it opened the iteration, and a subagent re-resolving it would answer from whatever the
filesystem says at dispatch time rather than from the iteration this run is populating.

Migration must not enter `rationale-agent.md` — that document is built around STP rate and
touchpoint reduction, and this tier's honest numbers (0% reduction, 100% fidelity) rendered in
that framing read as a failed transformation rather than a faithful migration.

Wait for it to complete. Verify `<ARTIFACTS_DIR>/transformation-rationale.md` exists.

## EXEC: Completion Gate

The run is incomplete (do not report it done) until every check below passes, even if `.bpmn`
files already exist from Phase 3.

```bash
node ".github/skills/process-os-process-transformation/scripts/path-exists.cjs" "<ARTIFACTS_DIR>/transformation-rationale.md"
```

`NOT FOUND` → do not report the run as done; Phase 4's rationale is missing.

If Phase 3 ran this run (BPMN generated, not skipped at its prompt), also verify it produced BPMN:

```bash
node ".github/skills/process-os-process-transformation/scripts/dir-contains.cjs" "<ARTIFACTS_DIR>" "*.bpmn"
```

`NO MATCH` or `NO DIR` → do not report the run as done.

**If MIGRATION=true**, also verify the tier's output covers the discovered process and is
executable:

```bash
node ".github/skills/process-os-process-transformation/scripts/assert-migration-fidelity.mts" --artifacts "<ARTIFACTS_DIR>"
```

Non-zero exit → do not report the run as done.

- `COVERAGE —` lines each name an as-is phase doc that produced no BPMN: the tier dropped part of
  the discovered process. Re-dispatch Phase 3.
- An `EXECUTABLE —` line means no generated BPMN carries a task definition or template binding
  (or a call-activity link in a process marked executable) — the output looks like `strategic`
  mode. Re-run Phase 3 with `--bpmn-mode automatable`.

It deliberately does **not** compare step names or counts between markdown and BPMN (not
deterministic — see the script's header comment): fidelity holds by construction, since Phase 0M's
copy is byte-identical to the as-is.

Either check fails → re-dispatch Phase 3's subagent, or the Phase 4 rationale subagent, then
re-run this gate. Only those subagents may produce those files — never hand-write them. One
exception: `ProcessOS runtime dep missing: @bpmnkit/core …` → surface it and stop, since
re-dispatching cannot install a dependency.

**Do not close the iteration here.** [finalize.md](references/finalize.md) owns the close, beside
the state, audit and README writes in the same step — see **Phase 5**.

## EXEC: Phase 5: Final State Update

Read and follow [finalize.md](references/finalize.md): updates `.camunda/state.md`, updates
`README.md`, appends the audit entry, writes the memory entry, closes the iteration, and prints
the completion summary.
