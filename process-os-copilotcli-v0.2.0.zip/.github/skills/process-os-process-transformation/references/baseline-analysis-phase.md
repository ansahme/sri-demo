# Baseline Analysis: Bootstrap → Criteria Elicitation → Optimization Context → Parallel Phase Analysis → Synthesis

Produces the tier-agnostic baseline every tier's AI-Challenge input sources from, then the
`incremental` tier's own proposal. This whole file is skipped when the baseline is already on
disk from an earlier iteration — see SKILL.md's Phase 1 reuse gate.

## AI: Step 1: Bootstrap

Read and follow [bootstrap.md](references/bootstrap.md) inline.

After it completes, verify `data/transformation-bootstrap.md` exists and contains
`## System Inventory`. If missing, stop with:
"Bootstrap failed to write data/transformation-bootstrap.md with a '## System Inventory' section. Re-run /process-os-process-transformation."

## AI: Step 2: Criteria Elicitation

Read and follow [criteria.md](references/criteria.md) inline.

After it completes, verify `data/transformation-criteria.md` exists. If not, stop with:
"Criteria elicitation failed to write data/transformation-criteria.md. Re-run /process-os-process-transformation."

## AI: Step 3: Append Optimization Context

Read and follow [optimize-bootstrap.md](references/optimize-bootstrap.md) inline — it appends an
"## Optimization Context" section (anti-pattern catalog, confirmed APIs, confidence thresholds,
phase-agent assignments) to `data/transformation-bootstrap.md` (written in Step 1), and copies the
criteria from `data/transformation-criteria.md` (written in Step 2). This step
must run after Steps 1 and 2 — it reads the files those steps write.

After it completes, verify the section landed:

```bash
node ".github/skills/process-os-process-transformation/scripts/search-files.mts" --pattern "^## Optimization Context" --quiet data/transformation-bootstrap.md
```

Exit `0` means it is there. Exit `1` means the file was read and the section is absent. Exit `2` means
the search could not run at all — the file is missing, or it is there and could not be read. All
three of those stop the phase with: "Optimization bootstrap failed to append its section. Re-run
/process-os-process-transformation."

## AI: Step 4: Parallel Phase Analysis

Dispatch one subagent per phase/edge file assignment from `data/transformation-bootstrap.md`'s
"## Optimization Context" phase-agent assignment table, to follow [phase-agent.md](references/phase-agent.md).
**One row in that table = one subagent**.
Do **NOT** add an agent for a phase you recall from `00-index.md`, `gap-analysis.md`, or any other discovery doc if it
has no row in this table.

- **Claude Code:** issue ALL `Agent()` calls in a **single assistant turn**.
- **Other platforms:** invoke each phase-agent sub-skill sequentially.

For each subagent:

```
Read references/phase-agent.md and follow it.

PHASE_FILE: [actual phase file path from the row]
EDGE_FILES: [actual edge files, comma-separated, or "none"]
ARTIFACTS_DIR: <ARTIFACTS_DIR>
```

Wait for all subagents to complete.

## AI: Step 5: Synthesis

Read and follow [synthesis.md](references/synthesis.md) inline.

After it completes, verify `<ARTIFACTS_DIR>/00-holistic-assessment.md` AND
`<ARTIFACTS_DIR>/proposal.md` AND
`<ARTIFACTS_DIR>/verdicts.json` all exist. If any is missing, stop with:
"Synthesis failed to write the complete output set. Re-run /process-os-process-transformation."
