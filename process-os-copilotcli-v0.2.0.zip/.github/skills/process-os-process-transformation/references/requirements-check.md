# Discovery-artifacts requirement check

Every phase that reaches this check needs a completed `/process-os-process-discovery` iteration
before it can read the as-is documentation it builds on.

```bash
node ".github/skills/process-os-process-transformation/scripts/iteration-dir.cjs" current process-discovery --complete --artifacts
```

Exit `3` → stop: "Process discovery must complete first. Run `/process-os-process-discovery`."

Capture stdout as `<AS_IS_DIR>` — the last completed discovery iteration's `artifacts/`. Every
reference file substitutes this value literally wherever it appears, the same way `<TIER>` is
substituted elsewhere in the skill. Then:

```bash
node ".github/skills/process-os-process-transformation/scripts/list-files.mts" --count "<AS_IS_DIR>/as-is-process.md" "<AS_IS_DIR>/gap-analysis.md"
```

`<2` → stop: "Process discovery must complete first. Run `/process-os-process-discovery`."
