# Sub-Skill: Regenerate Mode Gate

`regenerate` enters Phase 3 directly, skipping Phases 1 and 2, so it runs over analysis a previous
run produced rather than any this one made. This gate establishes that the analysis is actually
there before generation starts — a missing input surfaces here, named, instead of as a generator
failing on a file it expected.

Read this only when `REGENERATE_MODE=true` and `MIGRATION=false`; the migration tier has no
analysis phase and `SKILL.md` checks its seed instead.

## EXEC: Check the inputs

**Always required:**

```bash
node ".github/skills/process-os-process-transformation/scripts/list-files.mts" --count data/transformation-bootstrap.md data/transformation-criteria.md "<ARTIFACTS_DIR>/00-holistic-assessment.md"
```

`<3` → stop: "Missing analysis outputs — run `/process-os-process-transformation` (without
`regenerate`) to generate them first."

**Required for TIER:**

```bash
node ".github/skills/process-os-process-transformation/scripts/list-files.mts" --count "<ARTIFACTS_DIR>/proposal.md" "<ARTIFACTS_DIR>/verdicts.json"
```

Either file missing → stop: "No analysis found for the <TIER> tier. Run without `regenerate` to
generate it first."

**If TIER is not `incremental`, also:**

```bash
node ".github/skills/process-os-process-transformation/scripts/list-files.mts" --count "<ARTIFACTS_DIR>/process-[0-9]*-*.md"
```

Zero → stop: "No phase docs found for <TIER> (`<ARTIFACTS_DIR>/process-[0-9]*-*.md`) — Phase 2's
flatten step never ran for this analysis. Run `/process-os-process-transformation <TIER>` (without
`regenerate`) to produce it."

**Do not auto-flatten to self-heal.** `<ARTIFACTS_DIR>/*.md` may carry feedback already folded in,
and re-flattening from `verdicts.json` — which fold-in never touches — would clobber it.

## EXEC: Report and continue

All pass → output:

> Regenerate mode — reusing existing analysis. Jumping to the Phase 3 BPMN decision, then Phase 4
> (rationale) and Phase 5 (final state).

Then continue at Phase 3's MODE resolution in `SKILL.md`.

`regenerate` alone does not imply BPMN generation: add `--bpmn` to skip that prompt too, or set
`mode: unattended` in `run.config.yaml`, which is what UNATTENDED reads. The bare `unattended`
argument sets only UNATTENDED_ARG, which the BPMN decision never reads.
