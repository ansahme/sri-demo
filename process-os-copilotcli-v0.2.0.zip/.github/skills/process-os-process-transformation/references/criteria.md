# Sub-Skill: Transformation Criteria Elicitation

You are running Phase 1 of process transformation — eliciting the optimization criteria that
guide the incremental tier's automation decisions and give context to the radical/moonshot
tiers' challenge scoring.

## AI: Criteria Elicitation

Read `<AS_IS_DIR>/as-is-process.md` and `<AS_IS_DIR>/gap-analysis.md` — `<AS_IS_DIR>` is the
discovery output directory the caller resolved at its own Check requirements step, substituted
literally.

Identify 4–6 optimization criteria relevant to this process. For each, assess current performance based on the discovery output. Always prepare a recommendation — the 1–2 criteria that would deliver the highest value given the specific as-is bottlenecks.

Standard criteria (select those that fit; add others if the process warrants):
1. Reduce end-to-end cycle time
2. Reduce manual touchpoints / human effort
3. Improve data quality and reduce errors
4. Reduce cost (labor, rework, handoffs)
5. Improve compliance and auditability
6. Improve customer or partner experience
7. Increase throughput and scalability

Present to the user:

```
Optimization criteria for [Process Name]:

  1. [criterion] — [one-line as-is assessment]
  2. [criterion] — [one-line as-is assessment]
  ...

Recommendation: [top 1–2 criteria] — [one sentence: why, citing specific as-is findings]

Which criteria should guide this optimization? (Enter numbers, e.g. "1, 3" — or press Enter to accept recommendation)
```

## GATE: Await criteria selection

Check for unattended mode:

```bash
node ".github/skills/process-os-process-transformation/scripts/read-run-config.cjs" mode
```

Exit 2 → hard error: report stderr and stop; it means the reader failed, not that the key is unset.

If it prints `unattended`: output "Unattended mode — auto-accepting recommendation." and use it without waiting.
If normal: wait for user input. If the user presses Enter or provides no input, use the recommendation.

## EXEC: Write criteria file

Run `node ".github/skills/process-os-process-transformation/scripts/make-dir.cjs" data`, then write `data/transformation-criteria.md`:

```markdown
# Transformation Criteria
Selected: [date]

## Primary Criteria
[each selected criterion, one per line]

## Rationale
[one sentence per criterion: why selected given specific as-is findings]
```
