# Sub-Skill: Transformation Bootstrap

You are running Phase 0 of process transformation. Load all discovery context and build the system inventory for downstream phases.

`<AS_IS_DIR>` below is the discovery output directory the caller resolved at its own Check
requirements step — substitute the literal value throughout.

## AI: Step 1: Read All Input

Read ALL of the following in a single parallel batch (issue all Read calls simultaneously):
- `<AS_IS_DIR>/as-is-process.md`
- `<AS_IS_DIR>/gap-analysis.md`
- `.camunda/memory.md`

Find additional files:
```bash
node ".github/skills/process-os-process-transformation/scripts/list-files.mts" "<AS_IS_DIR>/participants-and-systems.md" "<AS_IS_DIR>/process-*.md"
```
Read all found files in a second parallel batch (issue all Read calls simultaneously).

## AI: Step 2: Extract System Inventory

From all documents read, extract every named system, tool, SaaS platform, or internal application. For each, determine:
- **Role in process** — what function it serves in this specific process
- **Data it owns** — what data is stored in or managed by this system
- **Data it passes** — what data it sends to or receives from other systems
- **Integration points** — which other systems it exchanges data with (named)

## AI: Step 3: Extract UserTask Inventory

From all `<AS_IS_DIR>/process-*.md` files (main phases only — these represent the true as-is state), collect every step marked `[RETAINED] UserTask` or `[UserTask]`. For each:
- Task name
- Phase file it came from (basename only)
- One-line description of what the human does
- Actor/role performing it

This count is the **main-phase baseline** — the reduction denominator used in exec summaries and proposals. Edge cases and subprocesses are counted separately in Step 3b.

## AI: Step 3b: Extract Additional Process Scope (Edge Cases and Subprocesses)

Find edge case and subprocess files from the as-is discovery — use `<AS_IS_DIR>` for the true as-is state, not `<ARTIFACTS_DIR>` (that describes the to-be):
```bash
node ".github/skills/process-os-process-transformation/scripts/list-files.mts" "<AS_IS_DIR>/edge-*.md" "<AS_IS_DIR>/subprocess-*.md"
```
Read all found files in a parallel batch (issue all Read calls simultaneously).

For each file, count every step marked `[UserTask]` or `[RETAINED] UserTask`. Record:
- File basename
- UserTask count
- Task names (comma-separated)

**Important:** These counts are NOT added to the main-phase baseline (Step 3). They are tracked separately. The baseline is the reduction denominator in exec summaries. Edge/subprocess counts explain the difference between the baseline number and the actual `<bpmn:userTask` count across all generated BPMN files.

## AI: Step 4: Identify Key Data Flows

From the as-is process, identify the top 3–5 data flows that cross system boundaries — where data is produced in one system and consumed in another, especially where a manual step bridges the gap.

## AI: Step 5: Create Output Directories and Write Bootstrap File

`<ARTIFACTS_DIR>` already exists — the caller's Open the Iteration step created it before this
file was read. Only the project-level `data/` scope needs creating here:

```bash
node ".github/skills/process-os-process-transformation/scripts/make-dir.cjs" data data/system-capabilities
```

Write `data/transformation-bootstrap.md`:

```markdown
# Transformation Bootstrap
Generated: [date]

## Process
- **Name:** [process name from as-is-process.md]
- **Organization:** [org name if available, else "—"]

## System Inventory

| System | Role in process | Data it owns | Data it passes | Integration points |
|--------|----------------|--------------|----------------|-------------------|
| [name] | [role] | [data owned] | [data passed] | [connected systems] |

## UserTask Inventory (Main Phases — Baseline)

Source: `<AS_IS_DIR>/process-*.md` files only. This is the **main-phase baseline** — the reduction denominator in exec summaries. Count: [N] tasks.

| Task | Phase file | Description | Actor |
|------|-----------|-------------|-------|
| [task name] | [phase-01-name.md] | [one-line description] | [role] |

## Additional Process Scope

Edge cases and subprocesses from `<AS_IS_DIR>/edge-*.md` and `<AS_IS_DIR>/subprocess-*.md`. These tasks are NOT part of the main-phase baseline. They are tracked here so proposals can accurately forecast the net BPMN `<bpmn:userTask` count.

| File | UserTask count | Tasks |
|------|---------------|-------|
| [edge-01-name.md] | [N] | [task names, comma-separated] |
| [subprocess-name.md] | [N] | [task names, comma-separated] |

**Total additional scope:** [N] tasks across [N] files.

## Key Data Flows

1. [Data item] flows from [System A] to [System B] — currently bridged by: [manual step or direct integration]
2. [...]
```

Output: "Bootstrap complete. [N] systems, [N] main-phase UserTasks (baseline), [N] additional UserTasks across [N] edge/subprocess files inventoried."
