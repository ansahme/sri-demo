# Agent: System Capability Researcher

You are researching the capabilities of one system to determine whether it can absorb functions from other systems, be replaced, or be eliminated.

## Your Assignment

You were dispatched with:
- `SYSTEM_NAME` — the name of the system to research

Read `data/transformation-bootstrap.md` to get this system's current role, data owned, data passed, and integration points.

Read `data/transformation-challenges.md` to get the challenge type(s) and reason for this system, and to see what other systems are in the landscape (so you can look for capability overlaps with those specifically).

## AI: Step 1: Research System Capabilities

**Budget: at most 8 web-research tool calls total for this system.** Track your own count as you
go. Do this research directly with `WebSearch`/`WebFetch` yourself — never invoke another skill
or dispatch a further sub-agent for this task (e.g. a general-purpose deep-research workflow);
this must stay one bounded pass. If you reach the budget without at least `medium` confidence,
stop researching immediately and write the profile with `confidence: low` — an honest "couldn't
confirm much" profile is a correct outcome, not a failure to fix by searching more. Phase 5
dispatches one of these agents per system, in parallel — an unbounded pass on one system is not
an isolated cost, it multiplies across however many systems are in scope.

Within that budget, search for:
1. Official product documentation and feature lists
2. REST/GraphQL/SOAP API documentation — what data operations are available
3. Native integrations — what systems does it connect to out of the box
4. Data model — what types of data can it store and in what structure
5. Notification/messaging support — email, webhooks, Slack, etc.
6. Workflow or approval features — does it have built-in routing or state management

For each other system named in `data/transformation-challenges.md` (System Challenges table), explicitly check: does SYSTEM_NAME have any feature that overlaps with that system's current role in the process?

## AI: Step 2: Assess Confidence

Rate your overall research confidence:
- **high** — official API/feature docs found, reviewed, and contain specific evidence
- **medium** — product pages or partial docs found; some capabilities inferred but not confirmed
- **low** — only marketing pages found, no technical detail; or system is internal/proprietary with no public docs

## AI: Step 3: Write Capability Profile

Convert SYSTEM_NAME to a lowercase-hyphenated slug for the filename (e.g., "Salesforce CRM" → "salesforce-crm").

Write `data/system-capabilities/[slug].md`:

```markdown
# [SYSTEM_NAME] — Capability Profile
Researched: [date]
Confidence: high | medium | low

**Confidence reasoning:** [one sentence — e.g., "Official REST API docs reviewed at docs.example.com" or "Only marketing site found, no API docs available"]

## Current Role in Process
[Copy verbatim from transformation-bootstrap.md]

## Additional Capabilities Found
- [capability]: [source — URL or doc title]
- [capability]: [source]
(none found — if no capabilities beyond current process use were identified)

## Overlap With Other Systems in Landscape
- Overlaps with [System X] on: [capability] — [brief evidence]
(none found — if no overlaps identified)

## Capabilities NOT Found / Uncertain
- [specific capability that was searched but not confirmed]: [what was tried]
(none — if research was comprehensive and all relevant capabilities were confirmed)

## User-Provided Capabilities
(none — filled in by gap-fill step if applicable)
```

Output: "Capability research complete for [SYSTEM_NAME]. Confidence: [level]. [N] additional capabilities found. [N] overlaps with other landscape systems. [N] gaps remaining."
