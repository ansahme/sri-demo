# Final State Update

## EXEC: Step 1: Update `.camunda/state.md`

- `process-os-process-transformation` Status → `✅ Done`
- Completed → today's date
- Key Output → `"<ITERATION_DIR>/artifacts/ (<TIER> tier)"`
- Next Step → `"Review <ITERATION_DIR>/artifacts/ and run /process-os-artifact-generation to build it into deployable artifacts"`

## EXEC: Step 2: Update `README.md`

Read the file. In the "Process Lifecycle" table, find the `process-os-process-transformation`
row. Update its Status to `✅ Done` and Key Output to match the value above. If the row does not
exist, insert a new row for `process-os-process-transformation` immediately after the
`process-os-process-discovery` row. Write the file back.

## EXEC: Step 3: Append audit entry

```bash
node ".github/skills/process-os-process-transformation/scripts/append-audit.cjs" process-os-process-transformation "Transformation iteration <N> complete — <TIER>"
```

## AI: Step 4: Write memory entry

Read `.camunda/memory.md`. Locate `## Transformation Decisions`. If it does not exist, create it
at the end of the file (after the last existing section). Synthesize 3–6 bullets capturing:
- Which tier this run generated
- Systems removed or replaced
- AI replacements made and at what threshold
- Structural changes: steps merged, flows collapsed
- Key assumptions in the proposal (if `<TIER>` is `moonshot`)

Append bullets preceded by `<!-- [today YYYY-MM-DD] -->`. Write the updated file back.

## EXEC: Step 5: Close the iteration

```bash
node ".github/skills/process-os-process-transformation/scripts/iteration-dir.cjs" close process-transformation
```

## EXEC: Step 6: Print output

Output:
```
Transformation complete — <TIER> tier.
  Artifacts: <ITERATION_DIR>/artifacts/
  Rationale: <ITERATION_DIR>/artifacts/transformation-rationale.md

Next: review <ITERATION_DIR>/artifacts/, then run /process-os-artifact-generation to build it into deployable artifacts.
```
