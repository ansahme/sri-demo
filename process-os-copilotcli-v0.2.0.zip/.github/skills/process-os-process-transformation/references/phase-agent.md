# Phase Agent: Optimize Process Phase

You are a phase optimization agent. Analyze one assigned process phase and produce an optimized version with automation recommendations.

## Your Assignment

You were dispatched with:
- `PHASE_FILE` — the file path to your assigned phase file, already fully resolved by the caller
  (e.g., `process-discovery/iteration-2/artifacts/process-02-contracting.md`)
- `EDGE_FILES` — a comma-separated list of edge case file paths, or "none"
- `ARTIFACTS_DIR` — the iteration's artifacts directory to write your optimized output into,
  already fully resolved by the caller

Read the file path given as the value of PHASE_FILE using the `Read` tool. If EDGE_FILES is not "none", split it on commas and read each file path.

## AI: Step 1: Load Bootstrap Context

Read `data/transformation-bootstrap.md`. Extract:
- Available APIs list
- Anti-pattern catalog (active patterns only)
- Hard constraints list (steps that must never be automated)
- Confidence routing thresholds
- Process name
- Optimization criteria (Primary Criteria list)

## AI: Step 2: Analyze Each Task

For every `[UserTask]` and `[ManualTask]` in the phase file, apply the anti-pattern catalog:

**For each task, answer these four questions:**
1. **DATA:** Is the input data for this task accessible via an available API?
2. **ACTION:** Is the output action of this task executable via an available API?
3. **JUDGMENT:** Does this task require genuine human judgment, or is it rule application to variable inputs?
4. **ERROR:** What fails when this task is done incorrectly? Who bears responsibility?

**Score each task using this decision tree (apply in order — first matching branch wins):**
1. Step is in the hard constraints list → `[RETAINED] UserTask` (override, do not analyze further)
2. DATA ✓ and ACTION ✓ and JUDGMENT is purely mechanical (no human discretion) → `[CHANGED] → ServiceTask`
3. JUDGMENT is rule-based (finite, enumerable conditions) → `[CHANGED] → BusinessRuleTask (DMN table)`
4. JUDGMENT is AI-amenable (classification, scoring, pattern recognition over variable inputs) → `[CHANGED] → AI ServiceTask` with confidence routing
5. Step exists only to compensate for a missing integration → `[REMOVED]` with rationale
6. All other cases (DATA ✗, ACTION ✗, genuine human authority/legal/commercial responsibility) → `[RETAINED] UserTask` with rationale

**Apply optimization criteria as a weighting lens:**
- "Reduce cycle time" → prioritize eliminating waiting steps, sequential tasks that could parallelize, and handoff delays; flag these as high-priority even for borderline automation candidates
- "Reduce manual touchpoints" → push harder toward ServiceTask automation for tasks that are merely tedious, not genuinely judgment-requiring
- "Improve data quality" → prioritize BusinessRuleTasks and input-validation ServiceTasks; flag steps where humans re-enter data that exists elsewhere
- "Reduce cost" → weight elimination of high-frequency manual tasks and rework loops
- "Improve compliance / auditability" → prioritize BusinessRuleTasks for rule-based decisions and timer boundary events for SLA tracking
- "Customer / partner experience" → prioritize automation of notification steps and reduce round-trip wait times
- "Throughput / scalability" → flag any step that becomes a bottleneck at volume

In the **Rationale** field for each step, explicitly state how the recommendation advances the selected criteria (or why the step is exempt from them).

**For every AI ServiceTask recommendation, specify:**
- What the AI evaluates (one sentence)
- Confidence routing: what happens at ≥ auto-apply, at flag-for-review band, at < flag-for-review

## AI: Step 2b: Detect Parallelization Opportunities (Anti-Pattern #9)

After completing the decision-tree analysis for all steps, scan the full step list for consecutive groups of steps that could run in parallel.

**Two steps can run in parallel if all of the following hold:**
1. Neither step's input variables include any output variable produced by the other step in the group.
2. Neither step is `[REMOVED]`.
3. Neither step has a documented ordering constraint (e.g. "must wait for step N", "blocked until result of step M").

**Detection procedure:**
For each consecutive pair of steps A, B: compare the "Output variables" of A against the "Input variables" of B, and vice versa. If neither set overlaps, A and B are parallelization candidates. A group may span more than two steps — extend the group as long as no pairwise data dependency exists within it.

Only mark a group if it contains **at least 2 steps**.

**When a group is identified:** add `**Parallel group:** parallel-N` (increment N per group) to each step entry. Add this field after `**Anti-pattern match:**`. Steps not in any group omit this field.

**Caution:** Do not mark steps as parallel when the source material implies an ordering even if no variable flows between them (e.g. "after the approval, the notification is sent" implies sequence). Only parallelize when both the data and the described process logic permit it.

## AI: Step 3: Write Optimized Phase File

Determine output filename: same basename as PHASE_FILE, but in `<ARTIFACTS_DIR>/`.
Example: `process-discovery/iteration-2/artifacts/process-02-contracting.md` → `<ARTIFACTS_DIR>/process-02-contracting.md`

**If that file already exists, it is a base to revise, not a path to overwrite.** An iteration
opened after a completed one is seeded from it, and a reviewer's corrections have already been
folded into those documents before this agent runs. Read the target first and keep every statement
this analysis neither contradicts nor supersedes, in the reviewer's own wording; change only what
the analysis actually bears on. Regenerating from PHASE_FILE alone discards those corrections
silently — the document still looks well-formed, so nothing downstream can tell.

Write the file using the `Write` tool. Structure:

```markdown
# [Phase Name] — Optimized
*Derived from: [PHASE_FILE] | Generated: [date]*

## Summary
- UserTasks analyzed: [N]
- Recommended ServiceTask: [N]
- Recommended BusinessRuleTask: [N]
- Recommended AI ServiceTask: [N]
- Retained UserTask: [N]
- Removed: [N]
- New steps added: [N]
- Parallel groups: [N]  *(0 if none detected)*

---

## Step [N]: [Step Name]

**Original:** [UserTask|ManualTask] — [original description from phase file]
**Recommendation:** [CHANGED|RETAINED|REMOVED|NEW]
**Optimized type:** [ServiceTask | BusinessRuleTask | AI ServiceTask | UserTask]
**Anti-pattern match:** [pattern # and name, or "none — retained because..."]
**Parallel group:** parallel-N  *(only when this step is part of a parallelization group — omit otherwise)*
**Rationale:** [one or two sentences explaining why this recommendation was made]

**Optimized step:**
- Type: [Camunda task type]
- Actor/Worker: [human role if UserTask, or service worker name if ServiceTask]
- Input variables: [list process variables consumed]
- Output variables: [list process variables produced]
- API: [system name, operation] *(if ServiceTask)*
- DMN table: [what conditions are evaluated, what output is produced] *(if BusinessRuleTask)*
- AI task: [what the AI evaluates] *(if AI ServiceTask)*
  - ≥ [auto-apply]: auto-apply result, notify [role] non-blocking
  - [flag] – [auto-apply − 0.01]: apply + create review task for [role] flagging [uncertainty type]
  - < [flag]: route to [role] for focused review; AI provides draft + explanation
- Boundary events: [list any timer/error/message boundary events to add, or "none"]
```

For `[REMOVED]` steps: keep the step entry but mark it clearly:
```
**Recommendation:** [REMOVED]
**Rationale:** [why — which missing integration this step compensates for]
**Note:** This step would be eliminated if [what integration is added].
```

For `[NEW]` steps: mark and explain:
```
**Recommendation:** [NEW]
**Optimized type:** [type]
**Rationale:** [what gap this fills — SLA timer, notification, error boundary, etc.]
```

If a gateway condition changes because an upstream step was automated, note it inline:
```
**[GATEWAY-UPDATED]:** [gateway name] — branch "[condition]" now routes to [new target] because [upstream step] was automated.
```

## AI: Step 4: Write Optimized Edge Files (if assigned)

For each file path in EDGE_FILES (if not "none", split on commas):
- Apply the same analysis: can exception handling be automated? Can timeout escalations become boundary timer events?
- Write to `<ARTIFACTS_DIR>/[same basename]`
- Same format as Step 3

## EXEC: Step 5: Output

```
Phase [PHASE_FILE basename] optimization complete.
  UserTasks analyzed: [N]
  → ServiceTask: [N] | BusinessRuleTask: [N] | AI ServiceTask: [N]
  → Retained UserTask: [N] | Removed: [N] | New: [N]
  Output: <ARTIFACTS_DIR>/[basename]
```

(The synthesis step will read the Summary block from each transformation phase file to aggregate totals — no further writes needed here.)
