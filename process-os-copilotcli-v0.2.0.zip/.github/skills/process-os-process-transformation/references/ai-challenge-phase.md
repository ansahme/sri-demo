# AI-Challenge: Challenge Prioritization → System Capability Research → Transformation Analysis

Runs when the selected tier is `radical` or `moonshot`.

## AI: Step 1: Challenge Prioritization

Dispatch a subagent to follow [challenge-agent.md](references/challenge-agent.md):

```
Read references/challenge-agent.md and follow it.

AS_IS_DIR: <AS_IS_DIR>
ARTIFACTS_DIR: <ARTIFACTS_DIR>
```

Wait for it to complete. Verify `data/transformation-challenges.md` exists.

## AI: Step 2: System Capability Research

Read `data/transformation-challenges.md`. Extract all rows in the "System Challenges" table where Priority = "high" or "medium". For each, note the system name.

Dispatch one subagent per extracted system simultaneously using the `Agent` tool. Each subagent receives:

```
Read references/capability-agent.md and follow it.

SYSTEM_NAME: [system name]
```

[capability-agent.md](references/capability-agent.md) caps each dispatch at 8 web-research tool
calls (dispatch is parallel across every extracted system, so this bounds total cost).

Wait for all subagents to complete.

**Gap-fill:**

If UNATTENDED_ARG = "unattended": skip gap-fill entirely — proceed to Step 3.

If UNATTENDED_ARG = "normal":
1. Read all `data/system-capabilities/*.md` files.
2. Collect every item listed under "## Capabilities NOT Found / Uncertain" across all files.
3. If any gaps exist, present them to the user as a consolidated numbered list:

```
Capability gaps found for [N] systems. Fill in what you know, skip what you don't:

1. [System A] — [gap question]
2. [System B] — [gap question]
...

(Press Enter to skip any item)
```

4. Wait for user input. For each answered item, append the answer to the relevant `data/system-capabilities/<system-slug>.md` under a new section `## User-Provided Capabilities`.

## AI: Step 3: Transformation Analysis

Dispatch a subagent to follow [analysis-agent.md](references/analysis-agent.md):

```
Read references/analysis-agent.md and follow it.

TIER: <TIER>
AS_IS_DIR: <AS_IS_DIR>
ARTIFACTS_DIR: <ARTIFACTS_DIR>
```

Wait for it to complete. Verify:
- `<ARTIFACTS_DIR>/challenge-matrix.md` exists
- `<ARTIFACTS_DIR>/proposal.md` exists

**Flatten the tier's verdicts into phase docs.** Run the deterministic flattener so
`<ARTIFACTS_DIR>` holds one phase doc per as-is doc (`process-NN-*.md`, `edge-*.md`,
`subprocess-*.md` — mirroring the discovery output's basenames) in the same shape
`phase-agent.md` produces for `incremental`. Always runs here — regardless of `--bpmn`.

```bash
node ".github/skills/process-os-process-transformation/scripts/flatten-tier-phase-docs.cjs" "<ARTIFACTS_DIR>"
```

It runs `scripts/tier-verdicts-to-phase-docs.cjs` once against `<ARTIFACTS_DIR>` and gates
on the result: exit `1` means the flatten wrote no phase docs. Exit `2` is a usage error — either
this wrapper's own (`<ARTIFACTS_DIR>` missing; the message carries no `FLATTEN` prefix, since it
never reached a flatten attempt) or the flattener's own usage/IO error passed through unchanged
(message `FLATTEN FAILED`, told apart from the wrapper's own `2` by that prefix). Exit `5` means
the flattener could not be started at all (message `FLATTEN DID NOT RUN` — nothing was flattened,
not a pass). Any other non-zero code is the flattener's own, propagated unchanged so the
completeness gate (`3`) stays distinguishable. Stop and report the message it printed rather than
continuing to Phase 3.

The one thing that is *not* a failure is a `FLATTEN WARNING` line on stdout: the flattener exited
`1` on an orphan reference (a verdicts entry naming a `phase_file` or pattern that does not exist)
but wrote every phase doc correctly, so the wrapper reports it and carries on. Mention it in your
Phase 2 summary so the stray key gets cleaned up, but do not stop for it. On any passing run the
wrapper writes only to stdout — the flatten's `warning:` lines included — so anything on stderr
means the step failed.

**If the flatten step exits non-zero, this phase has failed — do not continue past it.** Exit code
`3` is the completeness gate: the phase file's verdicts propose changes but none of its verdict
entries matched one of its baseline step headings (typically because `verdicts.json` keys its
`tasks` by something other than the plain task name as it appears in the process-discovery doc
headings). The stderr output names each offending phase file and its unmatched keys. No phase docs
are written in that case — not even for the phase files that were keyed correctly. Fix the verdicts
keys (re-dispatch the analysis subagent with the correction, or edit the JSON keys directly if the
mismatch is mechanical) and re-run the flatten step until it exits 0. If a named key turns out to
be a task the transformation *adds* rather than one scored from the baseline, the fix is to mark
that entry `"new": true` in `verdicts.json` instead of renaming it — the gate ignores
declared-new entries, which is what lets an additions-only phase file through. Do not hand-write the phase
docs, do not proceed to BPMN generation with stale or missing phase docs, and do not downgrade this
to a warning — a silently failed flatten produces TO-BE BPMN that drops the entire transformation.

## AI: Step 4: Tier-Level Documents

Read and follow [tier-docs.md](references/tier-docs.md). Phase 1 already wrote the implementation
roadmap, metrics, manual steps inventory, updated participants & data objects, and review
questions from the `incremental` pass it always runs — running it again here regenerates every one
of those documents from the phase docs the flatten step just wrote, so they describe the tier this
run actually produced rather than the `incremental` pass Phase 1 left behind. That is the reason
this step exists: without it, a `radical` or `moonshot` run would ship tier-level documents that
still describe `incremental`.
