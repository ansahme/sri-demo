# Agent: Transformation Rationale Writer

You write the transformation rationale document — a stakeholder-facing record of what was found, what was challenged, and why decisions were made.

## Your Assignment

You were dispatched with:
- `AS_IS_DIR` — the discovery output directory, already resolved by the caller
- `ARTIFACTS_DIR` — the iteration's artifacts directory, already resolved by the caller
- `TIER` — the resolved tier keyword

Substitute each literally wherever it appears below. Do not resolve the iteration yourself: the
caller holds it from the moment it opened the iteration, and re-resolving here would answer from
whatever the filesystem says at dispatch time rather than from the iteration this run is
populating.

## AI: Step 1: Read All Context

Read these in a single parallel batch (issue all Read calls simultaneously; skip any that don't exist):
- `data/transformation-bootstrap.md`
- `data/transformation-challenges.md`
- `<ARTIFACTS_DIR>/challenge-matrix.md` (skip if absent — expected when TIER is `incremental`, the
  one tier the AI-Challenge phase that writes it never runs for; see the Standard Path Definition
  fallback below)
- `<ARTIFACTS_DIR>/proposal.md`

Find and read all capability profiles in a second parallel batch:
```bash
node ".github/skills/process-os-process-transformation/scripts/list-files.mts" "data/system-capabilities/*.md"
```
Read all found files simultaneously.

## EXEC: Step 2: Extract Exact Touchpoint Counts

Before writing the rationale, extract the exact counts from `<ARTIFACTS_DIR>/proposal.md`'s "Human
Touchpoint Count" section.

**Extract two categories separately:**

1. **Original as-is reduction numbers** (from "Original As-Is Touchpoint Reduction"):
   - Baseline count and task list
   - Retained count and task list (only original as-is tasks kept)
   - Eliminated count breakdown (api-replace, AI agent, merged/eliminated, system removal)

2. **New UserTasks added** (from "New UserTasks Added by This Tier"):
   - AI co-pilot exception handler count
   - Edge case / subprocess count
   - New exception path count
   - Net BPMN UserTask count (retained + new)

If `<ARTIFACTS_DIR>/challenge-matrix.md` exists and its baseline count disagrees with the
proposal's, use `challenge-matrix.md`'s value.

**Verify the arithmetic:** `baseline - eliminated = retained`. If they don't add up, re-read and resolve before proceeding.

**Also count actual UserTasks from the generated BPMN** (do this after reading the proposal):

```bash
node ".github/skills/process-os-process-transformation/scripts/bpmn-extract.cjs" "<ARTIFACTS_DIR>" --names --exclude 00-overview.bpmn |
  node ".github/skills/process-os-process-transformation/scripts/strip-bom.cjs" |
  node -e "
const report = JSON.parse(require('fs').readFileSync(0, 'utf8'));
let total = 0;
for (const f of report.files) {
  const n = f.elements.filter((e) => e.type === 'userTask').length;
  total += n;
  console.log(f.path + ': ' + n + ' userTask element(s)');
}
console.log('total: ' + total + ' userTask element(s)');
"
```

Exit `3` from `bpmn-extract.cjs` means the report is over the read cap — re-run over fewer files
at a time (`--names` is already the lighter projection). Exit `2` means a `.bpmn` file is not
well-formed XML — fix it before reconciling counts, since a broken file's count is undefined.

Write down the actual BPMN count. It WILL be higher than the proposal's "retained" count — that is
expected and correct. The difference = new UserTasks added by the transformation design.
Reconcile: `BPMN count - proposal retained = new UserTasks added`. If the discrepancy is larger
than the proposal's "New UserTasks Added" section claims, flag it in the rationale.

## EXEC: Step 3: Write count-touchpoints.cjs

Create the `tools/` directory if needed:
```bash
node ".github/skills/process-os-process-transformation/scripts/make-dir.cjs" tools
```

Write `tools/count-touchpoints.cjs` with the actual counts from the proposal embedded as a JS
object literal, plus a second section that counts from the generated BPMN directly for
reconciliation. This file is deposited into the ProcessOS project under management for its own
future re-verification — not a ProcessOS skill script — so it stays self-contained: no
`shared/scripts/` import, and resolve `<ARTIFACTS_DIR>` to its literal path before writing, since
the file has no access to this skill's placeholder substitution once it is on disk.

```javascript
#!/usr/bin/env node
/**
 * Touchpoint count verifier for [Process Name] transformation ([TIER] tier).
 * Verifies the proposal's reduction claim AND reconciles it against the actual BPMN userTask count.
 * Run: node tools/count-touchpoints.cjs
 */
'use strict';

const fs = require('fs');
const path = require('path');

// ── Proposal-derived counts (original as-is UserTasks only) ─────────────────
const data = {
  process: '[Process Name]',
  tier: '[TIER]',
  generated: '[date]',
  bpmnDir: '[resolved artifacts directory]',
  before: {
    count: [N_baseline],
    tasks: [
      // list every original as-is UserTask name as a string
    ],
  },
  after: {
    retainedCount: [N],
    tasks: [], // list every retained original as-is task name
    eliminated: {
      apiReplace: [N],
      aiAgent: [N],
      mergedEliminated: [N],
      systemRemoval: [N],
    },
    // New UserTasks ADDED by the transformation (not counted in reduction)
    newUsertasks: {
      copilotExceptionHandlers: [N],
      edgeCaseSubprocess: [N],
      newExceptionPaths: [N],
    },
  },
};

const errors = [];
const baseline = data.before.count;
if (data.before.tasks.length !== baseline) {
  errors.push(`ERROR: before.count=${baseline} but task list has ${data.before.tasks.length} entries`);
}

console.log(`── Original As-Is UserTask Reduction (${data.tier} proposal claim) ────────────`);
const retained = data.after.retainedCount;
const eliminated = Object.values(data.after.eliminated).reduce((a, b) => a + b, 0);
if (data.after.tasks.length !== retained) {
  errors.push(`ERROR: retainedCount=${retained} but task list has ${data.after.tasks.length} entries`);
}
if (retained + eliminated !== baseline) {
  errors.push(`ERROR: retained(${retained}) + eliminated(${eliminated}) = ${retained + eliminated} != baseline(${baseline})`);
}
const reductionPct = baseline > 0 ? Math.round((eliminated / baseline) * 100) : 0;
const newTotal = Object.values(data.after.newUsertasks).reduce((a, b) => a + b, 0);
const expectedNet = retained + newTotal;
console.log(
  `${data.tier}: ${retained} retained / ${baseline} baseline = ${reductionPct}% reduction ` +
    `| +${newTotal} new (copilot/edge/exception) = ${expectedNet} net BPMN count (expected)`
);

// ── Actual BPMN counts ───────────────────────────────────────────────────────
console.log('\n── Actual BPMN userTask Count ──────────────────────────────────────────');
const USER_TASK_TAG = /<(?:[\w.-]+:)?userTask\b/g;
let files = [];
try {
  files = fs
    .readdirSync(data.bpmnDir)
    .filter((f) => f.endsWith('.bpmn') && f !== '00-overview.bpmn')
    .sort();
} catch (e) {
  console.log(`  (BPMN scan setup failed: ${e.message})`);
}
let total = 0;
for (const fname of files) {
  const content = fs.readFileSync(path.join(data.bpmnDir, fname), 'utf8');
  const n = (content.match(USER_TASK_TAG) || []).length;
  total += n;
  console.log(`  ${fname}: ${n}`);
}
const status = total === expectedNet ? '✓' : `⚠ expected ${expectedNet}`;
console.log(`${data.tier}: ${total} actual  ${status}`);

if (errors.length) {
  console.log('\n' + errors.join('\n'));
  process.exit(1);
} else {
  console.log('\nAll proposal arithmetic verified. ✓');
  console.log("Note: BPMN count > proposal 'retained' is expected — see 'newUsertasks' above.");
}
```

## AI: Step 4: Write transformation-rationale.md

Write `<ARTIFACTS_DIR>/transformation-rationale.md`:

```markdown
# [Process Name] — Transformation Rationale
Generated: [date] | Tier: <TIER>

## What We Found

[2–3 paragraphs written for a stakeholder who was not in the analysis. Cover:]
[Paragraph 1: What the system landscape looked like — how many systems, what roles they played, any obvious redundancies or pass-through systems]
[Paragraph 2: Data flow inefficiencies — where data was produced in one system and manually re-entered or routed to another, where steps existed only because systems didn't integrate. Call out the pattern: tasks that exist only because two systems don't talk directly are prime API-replacement candidates.]
[Paragraph 3: Manual touchpoint findings — how many UserTasks exist in the as-is process, how many are api-replace candidates vs. genuine human decisions. Be specific about the numbers.]

[Write this section in confident, plain language. Example: "The process relies on four systems, two of which act primarily as data intermediaries. Of the 14 human tasks identified, 8 are direct API calls to systems that expose full REST APIs — these tasks exist only because no automation exists, not because human judgment is required."]

## How We Approached the Transformation

[1 paragraph describing the methodology:]
- Every system was assessed for challenge priority (high/medium/low) based on footprint, uniqueness, and compliance dependency
- Web research was conducted on each high/medium-priority system to find capabilities beyond current process use
- Every UserTask was first checked for API-replaceability: does a REST/webhook API exist, are all inputs available, is there a legal human mandate? Tasks passing the API check become Service Tasks regardless of AI candidacy.
- Remaining UserTasks were assessed for AI replacement feasibility (high/medium/low candidacy)
- Three proposal tiers: incremental (high-confidence API replacements + low-cost changes), radical (system replacements, AI agents, API automation with medium-confidence), moonshot (zero UserTasks as starting point — add humans back only where legally mandated)
- AI thresholds: 80% confidence for incremental/radical; 65% for moonshot. Below threshold triggers human escalation.

## Human Touchpoint Reduction

**Counting scope:** Two metrics are tracked separately. "STP rate" measures human touchpoints on the standard (happy) path — this is the exec headline. "Task elimination" measures original as-is UserTask types removed across all paths — this is the mechanism. The BPMN contains additional UserTasks not in either count — see "Net BPMN Count" table below. Verify with `node tools/count-touchpoints.cjs`.

### Standard Path STP Rate (Executive Headline)

*Standard path definition: [if `<ARTIFACTS_DIR>/challenge-matrix.md` exists, copy from its `##
Standard Path Definition`; otherwise (the `incremental` tier) copy from
`<ARTIFACTS_DIR>/proposal.md`'s own `### Standard Path Definition` subsection — the tier-docs step
writes one there precisely so this file is self-contained even when the AI-Challenge phase never
ran]*
*Volume: [X]% of instances — [source]*

| Tier | Standard path touchpoints | As-is standard path | STP rate |
|------|--------------------------|---------------------|----------|
| As-is | [N] | [N] | 0% (fully manual) |
| `<TIER>` | [N] | [N] | [X]% |

*Industry benchmark: Q2C automation leaders achieve 90%+ straight-through processing on standard paths.*

### Original As-Is UserTask Reduction (Mechanism)

| Tier | As-Is baseline | Retained (original) | Eliminated | Reduction |
|------|---------------|---------------------|------------|-----------|
| `<TIER>` | [N] | [N] | [N] | [X]% |

**Elimination breakdown:**

| Tier | API→Service Task | AI Agent | Merged/Eliminated | System Removal |
|------|-----------------|----------|-------------------|----------------|
| `<TIER>` | [N] | [N] | [N] | [N] |

**Retained tasks:** [list every remaining original UserTask name]
**Retained rationale:** [for each, one line — the specific legal/compliance/human-authority reason]

### Net BPMN UserTask Count

The generated BPMN contains more UserTask elements than the "retained" count above. The difference is new UserTasks added by the transformation design — AI co-pilot exception handlers, edge case handlers, error path fallbacks. These are net new, not replacements of original tasks.

| Tier | Retained (original) | New (co-pilot + edge + exception) | Net BPMN count | Verified |
|------|---------------------|-----------------------------------|----------------|---------|
| `<TIER>` | [N] | [N] | [N] | [✓ / ⚠] |

Verified = actual `<bpmn:userTask` count from the BPMN matches the expected net count. ⚠ = discrepancy found; investigate before presenting numbers.

## The Proposal

[Copy the Executive Summary verbatim from `<ARTIFACTS_DIR>/proposal.md` — do not paraphrase.]

**`<TIER>`:** [Executive Summary from proposal.md — verbatim]

## Decision Log

| Element | Type | Challenge | Evidence | Decision | Rationale |
|---------|------|-----------|----------|----------|-----------|
[One row per element from `<ARTIFACTS_DIR>/challenge-matrix.md`. Include every challenged element — systems, data flows, step groups, and UserTasks. Use the exact verdicts from the matrix. For UserTasks, "Type" column values: api-replace / high-AI / medium-AI / low-AI / legally-mandated. **If `challenge-matrix.md` is absent (the `incremental` tier), source these rows from `<ARTIFACTS_DIR>/proposal.md`'s per-task markers instead.**]
```

Output: "Rationale document written. Touchpoint reduction: `<TIER>` [X]%. Verification script: tools/count-touchpoints.cjs"
