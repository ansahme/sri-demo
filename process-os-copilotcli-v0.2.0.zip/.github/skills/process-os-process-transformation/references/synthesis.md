# Sub-Skill: Transformation Synthesis

You are running Phase 3 of process transformation — synthesizing the per-phase optimization
decisions from Phase 2 into the holistic assessment doc, then (via
[tier-docs.md](references/tier-docs.md)) the tier-level documents derived from it, then the
incremental tier's own proposal + verdicts pair. This phase never blocks on human review —
`review-questions.yaml` (written by [tier-docs.md](references/tier-docs.md)) is written
unanswered; a later run of `/process-os-process-transformation` folds the answers in.

## Important: do not delegate, write directly

`00-holistic-assessment.md` is **stitching, not analysis** — the phase agents already did the
analysis in Phase 2. Your job is composition only.

- **Do NOT spawn `Agent` subagents to write it.**
- Use the `Write` tool directly, in this conversation.

## AI: Read All Phase Outputs

Read all `<ARTIFACTS_DIR>/process-*.md` and `<ARTIFACTS_DIR>/edge-*.md` files, plus
`data/transformation-bootstrap.md` and `<AS_IS_DIR>/as-is-process.md` — `<AS_IS_DIR>` is the
discovery output directory the caller resolved at its own Check requirements step, substituted
literally.

## AI: Write Holistic Assessment

Write `<ARTIFACTS_DIR>/00-holistic-assessment.md` using the `Write` tool:

```markdown
# [Process Name] — Holistic Optimization Assessment
Generated: [date] | [N] phases analyzed

## Structural Bottlenecks

[Where work queues regardless of individual step speed — handoffs waiting on approvals, notifications waiting on responses, phases that serialize steps that could run in parallel. For each:]
- **Bottleneck:** [description]
- **Location:** [phase, step]
- **Root cause:** [why it exists]
- **Proposed fix:** [structural change — reorder, parallelize, eliminate]

## Criteria Alignment

*Optimization was guided by: [list primary criteria from data/transformation-bootstrap.md's ## Optimization Context section]*

| Criterion | Key changes advancing it | Expected impact |
|-----------|------------------------|----------------|
| [criterion] | [specific automations or structural changes] | [quantified or directional impact] |

## Top 5 Architectural Changes

*Ordered by impact on primary optimization criteria.*

1. [Highest impact change with expected outcome]
2. [...]
3. [...]
4. [...]
5. [...]

## Exception vs. Happy Path Ratio

| | As-Is | Optimized |
|---|-------|-----------|
| Happy path steps (human actions) | N | N |
| Exception/branching steps | N | N |
| Ratio | N:1 | N:1 |

[Commentary: does exception handling dominate? Expected for this process type?]

## Cross-Phase Data Gaps

[Data generated in one phase but not available in a later phase where it is needed — each gap forces a UserTask to re-enter or look up data that already exists elsewhere.]

| Data | Produced in | Needed in | Gap impact |
|------|------------|-----------|------------|

## Elimination Opportunities

[Entire phases or sub-phases that exist only to compensate for a missing integration.]

| Phase/Section | Exists because | Elimination requires | Value |
|--------------|----------------|---------------------|-------|

## Key Risks

[What could go wrong with the proposed automation]
- **[Risk]:** [description] — [mitigation]
```

## AI: Write Tier-Level Documents

Read and follow [tier-docs.md](references/tier-docs.md) — given `<ARTIFACTS_DIR>` holding the
phase docs just read above and the `00-holistic-assessment.md` just written, it writes the
implementation roadmap, metrics, manual steps inventory, updated participants & data objects, and
review questions.

## AI: Write Incremental Tier Proposal + Verdicts

Incremental's automation decisions come from the deterministic phase-agent decision tree
(Phase 2), not from AI challenge-scoring, so this step derives the proposal doc from the phase
docs already written rather than from an AI-challenge verdict.

`<ARTIFACTS_DIR>/proposal.md` has a reader: [rationale-agent.md](references/rationale-agent.md)'s
Step 1 extracts its "Human Touchpoint Count" section. `<ARTIFACTS_DIR>/verdicts.json` has none —
write it anyway, for structural symmetry with the schema
[analysis-agent.md](references/analysis-agent.md) writes on a radical or moonshot run, but do not
spend effort perfecting its schema beyond matching the shape in the table below.

**Write `<ARTIFACTS_DIR>/proposal.md`** using the same section structure
`references/analysis-agent.md`'s Step 3 defines (`# ... — Incremental Transformation Proposal`,
`## Executive Summary`, `## What Changes`, `## Resulting Flow`, `## Key Assumptions`, `##
Risks`, `## Why This Will Work`, `## What Implementation Requires`, `## Human Touchpoint
Count`), populated from `<ARTIFACTS_DIR>/00-holistic-assessment.md`, `metrics.md`, and the
per-task `[CHANGED]`/`[NEW]`/`[RETAINED]`/`[REMOVED]` markers in
`<ARTIFACTS_DIR>/process-NN-*.md` instead of AI verdicts.

**Important — do not reference `<ARTIFACTS_DIR>/challenge-matrix.md` here.** That file
is only written by `references/analysis-agent.md`, which does not run when TIER is `incremental`
(SKILL.md's Phase 2 routing skips it) — so it never exists for this section to read. The "Human
Touchpoint Count" section's counting rules (baseline = main phases only, standard-path STP rate,
arithmetic check) are the same *rules* as the radical/moonshot template, but incremental must
**derive its own Standard Path Definition locally** — from `<ARTIFACTS_DIR>/00-holistic-assessment.md`
and the as-is process — rather than copying it from `challenge-matrix.md`. Write a `###
Standard Path Definition` subsection inline (same fields: conditions, volume estimate, as-is
standard-path touchpoints) before using it in the STP-rate table, so the file is self-contained
even when `references/analysis-agent.md` never ran.

**Write `<ARTIFACTS_DIR>/verdicts.json`** in the same schema `references/analysis-agent.md`'s
Step 3b defines. Map each phase-agent marker to a verdict:

| Phase-agent marker | `verdicts.json` verdict |
|---|---|
| `[CHANGED]` → ServiceTask (API-backed) | `api-replace` |
| `[CHANGED]` → BusinessRuleTask | `ai-agent` (element: `Business Rule Task`) |
| `[NEW]` | `api-replace` or `ai-agent`, matching whichever element type the phase-agent assigned |
| `[RETAINED] UserTask` | `retained`, with the phase-agent's stated rationale as `reason` |
| `[REMOVED]` | omit from `tasks` (the step no longer exists — `references/bpmn-agent.md`'s incremental branch does not need a verdict for a step it never emits) |

**Completeness check:** every `[RETAINED] UserTask` and every automated
(`[CHANGED]`/`[NEW]`) step from `<ARTIFACTS_DIR>/process-NN-*.md` must appear in
`tasks` (except `[REMOVED]` steps, per the table above).

## EXEC: After All Files Written

If [tier-docs.md](references/tier-docs.md)'s Review Questions step wrote `data/progress.json`
phase → `"review-ready"` (skip-review case), leave it as-is. Otherwise update `data/progress.json`
phase → `"transformation-synthesis-complete"`.
