# To-Be Modeling Guidelines

Decision rules for the reengineering agents (challenge, analysis, phase) when assigning element
verdicts and designing to-be processes.

Each rule below has a test and a resolution. When a rule here conflicts with a more general
instruction elsewhere in this skill, this file wins.

---

## T1 — Determinism first (the prime directive)

**Test:** Can this step's logic — the routing, the order, the recovery — be described up front as
enumerable state transitions?

**Resolution:** Yes → deterministic BPMN (tasks, gateways, DMN, events). No → agent candidate
(continue at T2).

Whatever can be made deterministic should be. A deterministic path decides how to continue
correctly 100% of the time — always more reliable, cheaper, and faster than an agent. If you can
describe up front, step by step, how the logic resolves, build a deterministic process; an agent
earns its keep only where the work is genuinely non-enumerable and flexibility is required. Match
the modeling style to the nature of the work rather than defaulting everything to flexible.

**Tier scoping:** T1 is the baseline — and the tiers deliberately walk away
from it in controlled steps. That spread is the product: the user picks their point on the
determinism ↔ adaptability spectrum by picking a tier.

| Tier | T1 status |
|---|---|
| **incremental** | Binds strictly. Deterministic wherever possible; agents only for genuinely non-enumerable work (fuzzy interpretation, unstructured input, open-ended recovery). |
| **radical** | Default, consciously overridden. Confirmed multi-call orchestration may consolidate into agents even where routing is partially enumerable; every override carries the full T3 guardrail kit. |
| **moonshot** | Default inverts: **agent-first**. Enumerable service-task chains consolidate into agents aggressively; determinism is retained where it demonstrably wins — regulated decision points, payment-grade correctness, and the T3 validation seams themselves. |

Determinism-first is not discarded at the aggressive tiers — it is *encoded* there: as the
guardrail kit (T3) wrapped around every agent, as the deterministic validation seams before and
after each ad-hoc, and by keeping tier labels honest (each agent verdict states which tier's
default produced it). Aggressive tiers raise the agent count, never the agent riskiness.

**Corollary — the agent front-loads uncertainty:** place the agent where variance genuinely lives
(intake, interpretation, discretionary review, unpredictable recovery) and hand everything after
it back to deterministic flow at a hard seam. The agent's richest-context position does not
entitle it to downstream routing that a gateway can do with 100% reliability.

---

## T2 — Agent placement: the deterministic sandwich

When T1 resolves to "agent", the agent is an **ad-hoc sub-process embedded in a deterministic
frame** — never a free-floating process, never the whole process:

```
deterministic pre-check → [ agent ad-hoc sub-process ] → deterministic validation → route
                                                              ↓ invalid/low-confidence
                                                          human review
```

1. **Pre-check (deterministic gate):** cheap eligibility/data checks run *before* the agent. If
   hard data supports a decision without judgment, decide it in DMN before the agent ever runs.
2. **The agent** does the discretionary work: required + deterministic steps stay in control
   flow; only steps where the agent has genuine decision authority become tools inside the
   ad-hoc.
3. **Post-validation (deterministic guardrail):** the engine never auto-acts on unvalidated agent
   output — see T3.2/T3.3.

Structural rules for the ad-hoc container itself (tools as root nodes, no start/end events,
`toolCallResult` wiring, XML template): [ai-in-bpmn.md](ai-in-bpmn.md).

---

## T3 — Agent guardrail kit (mandatory)

Every AI-agent verdict must specify its guardrails in the proposal. An agent without them is an
incomplete verdict, not a lean one. The pattern throughout: **prefer a BPMN structural safeguard
over a system-prompt instruction — the LLM can ignore the latter but not the former**.

1. **Bound the loop.** Size `maxModelCalls` to the use case (default 10); low temperature/top-P;
   lower max tokens to what responses need.
2. **Clamp every LLM-authored value before the engine consumes it.** A `fromAi(...)` value that
   feeds a timer, a gateway condition, an amount, or any engine-facing field gets a deterministic
   FEEL clamp (floor/ceiling/whitelist) between the LLM and the element. The LLM may *normalize*
   genuinely dynamic inputs (a wait that arrives as date OR duration OR needs calculation), but an
   unclamped `PT0S` spam-loop and a silent `P10Y` sleep both pass lint. Work out the wait's valid
   limits and use a FEEL expression that forces whatever the LLM chose to fit within that range.
3. **Validate output deterministically before acting on it.** Prompt-constrained output formats
   are not enforcement — the prompt cannot enforce. A DMN task validates
   the agent's output (allowed codes, ranges, schema conformance); non-conformant output routes to
   human review, never onward. DMN as *guardrail*, not decider.
4. **Model the failure path.** Tell the agent how to fail in the system prompt *and* give it a
   structural way to do it: an escalation throw inside the ad-hoc caught by an escalation boundary
   on it. End events are forbidden inside ad-hoc sub-processes, so escalation is the canonical
   exit — an escalation boundary event is how you get around the missing direct error behavior.
   Always set an `escalationCode`. Know the blind spot: Zeebe *incidents* (job failures) are below
   the BPMN event layer — the agent cannot see or react to them, so a tool that can incident needs
   its own retry/error strategy.
5. **Time-box.** The LLM has no sense of elapsed time; the engine does. Timer boundary on the
   ad-hoc for the overall deadline; a boundary timer on every user-task tool — without it the
   agent waits forever for a human who never opens Tasklist.
6. **Gate risky tools at their entry task.** The engine can only start a tool from the first task
   of its chain — put a human task, a programmatic check, or a DMN rules table in front of any
   tool with irreversible side effects. A "check with a human first" prompt instruction is not a
   gate.
7. **Judge high-stakes runs.** A deterministic or human judge step *after* the ad-hoc (never as
   one of its tools) classifies the run: acceptable → end; suboptimal → human correction; optimal
   → store for reuse. When stakes are high, add a judge.
8. **Human fallback with threshold.** Low-confidence output routes to a human — this skill's
   existing confidence-threshold model. The escalation path from T3.4 and the validation failure
   path from T3.3 usually merge into the same review task.

---

## T4 — Decision logic placement

Sharpened ladder for "where does this decision live". The ladder is the **incremental-tier
default**; at radical/moonshot the middle rows may collapse into the agent (rule-based decisions
become agent-internal reasoning, with the DMN moving to the T3.3 output-guardrail position):

| Situation | Element | Why |
|---|---|---|
| Branch value already a process variable | XOR gateway | Cheapest, 100% reliable |
| Value derivable from in-hand attributes via business rules | DMN business rule task → gateway | Dynamic ≠ agentic — computing a value from data you already hold is a rules problem, not a judgment problem |
| Rule-based with enumerable conditions | **DMN at incremental; agent at radical/moonshot** | A decision table is the deterministic rendering; the aggressive tiers hand it to the agent and keep the DMN as output guardrail (T3.3). Regulated decisions keep structured DMN output at *every* tier |
| Genuine judgment: fuzzy criteria, natural language, contradictory inputs | Agent (T2) + validation (T3.3) | Only here does the agent earn its cost |

**Threshold literal vs DMN:** decide by **change frequency** and **ownership** —
value changes rarely (1–2×/year) and developers own it → a gateway literal is acceptable and
version-auditable; value changes often or business people must own it → DMN. Don't reflexively
extract every constant into DMN — that overengineers what is often a super easy fix.

**Regulated decisions emit structured rationale.** A decline/adverse-action path must carry *why*
as enumerable reason codes, not a bare boolean — widen the DMN output to
`{decision, reasonCodes, score}` and branch on `result.decision`. When an agent produces the
recommendation, the reason codes are exactly what the T3.3 guardrail DMN validates.

**Model selection is a DMN decision, not agent config.** When multiple vetted models serve one
agent, route the choice through a business rule task *before* the agent (`llmString` → provider
model field); swapping models becomes a DMN-only redeploy with an Operate audit trail.

---

## T5 — Event patterns

### T5.1 Message vs signal — and the key-construction trap

Message (correlated, one instance) is the **default** for anything instance-scoped; signal only
for genuine broadcast where every running instance should react (existing rule in
`process-os-bpmn-generation`'s best practices).

Dynamic-named signals
(`="poTracked_"+purchaseOrderKey`) used as pseudo-targeted delivery are single-instance **by key
construction only, not by engine semantics** — every subscription whose name resolves to that
string fires. That discipline is operator-carried and silently breaks on duplicate subscriptions
(backfill paths, re-entry loops). To-be designs use correlated messages for targeting; accept a
signal verdict only with an explicit broadcast justification written into the proposal.

### T5.2 Duplicate work: correlate, never query-and-kill

**Never** model duplicate detection as "search for open tasks/instances via Tasklist or Operate
API, then cancel the loser." Flip the model:

- One message name, two subscribers: a **message start event** and an **interrupting boundary
  (or event sub-process) on the running scope**, both correlated on the business key
  (`=mpi`, `=orderId` — never a hardcoded key).
- Zeebe routes it: instance running → boundary fires (re-trigger/refresh); nothing running →
  start event fires a new instance. **The subscription table is the dedup index** — no app DB, no
  API search task.

### T5.3 Mid-run updates to a running agent

New information reaching an agent mid-run goes through exactly one conduit: an event sub-process
**inside** the ad-hoc that writes to `toolCallResult` — the agent never polls process
variables. Requirements and semantics:

- Signal start event for broadcasts, message start event (name + correlationKey) for targeted
  updates; `isInterrupting="false"` so the agent keeps working.
- The agent task must set `data.events.behavior = WAIT_FOR_TOOL_CALL_RESULTS` — without it
  the handler's output is lost.
- **Batching caveat:** a non-interrupting event's `toolCallResult` is not injected immediately;
  it is delivered together with the next completing tool call. An update arriving after the
  agent's terminal step is dropped with the scope — by design, and acceptable only because the
  goal is already achieved. If a late update must still act, it needs a handler *outside* the
  ad-hoc.
- Cancellation (work no longer relevant) is the interrupting variant: interrupting event
  sub-process or boundary that abandons the agent scope.

### T5.4 Waits

Existing timer / event-based-gateway rules in `process-os-bpmn-generation`'s best practices
apply unchanged. Agent-specific addition: an agent-chosen wait is a two-element tool — script
task capturing `fromAi(toolCall.duration, …)` + timer catch on the result — and the duration
is clamped per T3.2 before it reaches the timer.

---

## T6 — Interrupting vs non-interrupting: decide by breach semantics

For an SLA/timeout on a human or receive step, the choice is a **business decision to record in
the phase doc**, not a default:

- **Breach is terminal** (hard SLA; late response must *not* revive the case) → interrupting
  timer. This knowingly accepts the race where a response arriving as the timer fires is dropped
  — an accepted tradeoff. Write the tradeoff down.
- **Escalate but keep waiting** (reminder ladders, nudges) → non-interrupting boundary timer on
  the waiting activity; the wait survives the escalation.

If the phase doc doesn't say which one, that is a review question — don't guess silently.

---

## T7 — Hard exclusions (verdicts to refuse)

All exclusions are tier-invariant except T7.3, which is scoped by tier.

1. **AI as a band-aid for a missing integration.** If the real gap is a capability you cannot
   query ("we consume events but can't ask the system for state"), an agent *guessing* the answer
   is not a fix — the verdict is an integration requirement, surfaced as such in the proposal.
2. **Agent on a fast, cheap, synchronous check.** Latency- and cost-sensitive pre-qualification
   paths (credit pre-check before the user even enters details) stay deterministic; agent loops
   are overkill there.
3. **Agent for an enumerable flow — tier-scoped.** At **incremental**: refuse — if gateway
   conditions or a DMN table can express the routing between calls, the chain stays
   deterministic. At **radical**: allowed with a stated
   justification (which variance the agent absorbs) plus the T3 kit. At **moonshot**: does not
   apply — consolidating 3+ service-task chains into agents is the tier's declared intent; the
   agent handles conditional routing, retries with context, and exception paths that a chain
   hard-codes. What stays non-negotiable at every tier: the T3 guardrail kit and exclusions
   T7.1/2/4/5.
4. **`fromAi(...)` for values already in process scope.** If the process already knows it
   (captured at start, produced by a prior step), the tool reads the variable directly — asking
   the LLM to reproduce a known value invites errors.
5. **Free-form agent replies where channel tools exist.** Agents communicate through tools only;
   the system prompt declares it, each channel is a separate response tool.

---

## T8 — Data hygiene for agent verdicts

Zeebe's variable model is optimized for minimal routing state; agentic context is large,
vaguely-sourced, and multi-provenance — mixing them is the first ceiling you hit: the model
breaks you from both sides, engine state capacity and context reliability. Keep three data
classes separate by design:

- **Process data** (routing state, correlation keys, verdict flags): process variables. Keep them
  minimal.
- **Entity data** (customer records, documents): fetched by tools on demand; results filtered
  *before* writing `toolCallResult` — pass only goal-relevant fields to the LLM, keep sensitive
  fields in variables the model never sees, or drop them.
- **LLM data** (agent context, conversation memory): agent memory; switch storage from in-process
  to Camunda Document when context may exceed ~5 MB.

---

## T9 — Lint expectations for agentic BPMN

The classic-BPMN rule pack is miscalibrated for ad-hoc interiors. Expect and document — do not
"fix" — these findings on generated agentic models:

- `end-event-required` / `no-implicit-end` **inside an ad-hoc sub-process**: false positives.
  Start/end events are forbidden there; tool-return throw events deliberately dangle (they write
  `toolCallResult` and return control to the agent). Adding an end event to satisfy the linter
  breaks the tool contract.
- Everything else stays enforced, and agentic models still commonly fail on: unlabeled events
  (`label-required`), missing `messageRef` on boundary message events, missing `escalationCode`
  on escalation events, missing form definitions on user-task tools. These are real defects —
  fix them.
