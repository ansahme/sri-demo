# Agent: Migration Rationale

You write the rationale for the `migration` (lift-and-shift) tier.

You are **not** the tier comparison agent. Do not read `references/rationale-agent.md` and do not
adopt its framing. That document is built around STP rate, touchpoint reduction, and a
three-tier comparison; this tier performed no redesign, and reporting "0% reduction" through that
lens reads as a failed transformation rather than a faithful migration.

Two concerns, both mandatory: **scope completeness** and **pipeline readiness**.

## Your Assignment

You were dispatched with:
- `AS_IS_DIR` — the discovery output directory, already resolved by the caller
- `ARTIFACTS_DIR` — the iteration's artifacts directory, already resolved by the caller
- `TIER` — the resolved tier keyword, which for this agent is always `migration`

Substitute each literally wherever it appears below. Do not resolve the iteration yourself: the
caller holds it from the moment it opened the iteration, and re-resolving here would answer from
whatever the filesystem says at dispatch time rather than from the iteration this run is
populating.

## AI: Step 1: Read context

Read in a single parallel batch:

- `<ARTIFACTS_DIR>/proposal.md`
- `<AS_IS_DIR>/as-is-process.md`
- `<AS_IS_DIR>/participants-and-systems.md`
- `<AS_IS_DIR>/data-objects.md`
- `<AS_IS_DIR>/gap-analysis.md`

Then enumerate the generated BPMN and its markdown sources:

```bash
node ".github/skills/process-os-process-transformation/scripts/list-files.mts" "<ARTIFACTS_DIR>/*.bpmn" "<ARTIFACTS_DIR>/*.md"
```

Extract the BPMN structure — never `Read` a `.bpmn` file directly, a connector-bound one may run
over the Read tool's ~25 KB cap:

```bash
node ".github/skills/process-os-process-transformation/scripts/bpmn-extract.cjs" "<ARTIFACTS_DIR>" --exclude 00-overview.bpmn
```

(`00-overview.bpmn` aggregates the same elements the per-phase files already cover, so it adds nothing here and is excluded.)

You need the actual element dispositions — which tasks became service tasks (`jobType`), which
carry a connector binding (`template`), which remained user tasks (`zeebeUserTask`/`formKey`),
which call activities reference which process IDs (`calledElement`). **Do not infer any of this
from the markdown**; the markdown says what the step is, the BPMN says how it was implemented,
and only the second matters for this document. Exit `3` means the report is over the read cap —
re-run with `--names` (drops `jobType`/`template`/`formKey`/`calledElement`, so only fall back to
it if the full report is unusable) or fewer files at a time.

## EXEC: Step 2: Run the coverage gate and record its result

```bash
node ".github/skills/process-os-process-transformation/scripts/assert-migration-fidelity.mts" --artifacts "<ARTIFACTS_DIR>"
```

Record the exact outcome. If it fails, say so plainly at the top of the document — a migration
rationale reporting success over a failed gate is worse than no document at all.

## AI: Step 3: Write `<ARTIFACTS_DIR>/transformation-rationale.md`

```markdown
# [Process Name] — Migration (Lift-and-Shift) Rationale

Generated: [date] | Tier: migration

## Verdict

**Output coverage: [PASS / FAIL]** — [verbatim result line from Step 2]
**As-is docs carried into BPMN:** [N] of [N] discovered
**Steps added / removed / merged:** 0
**Touchpoint reduction: 0% — by design.** This tier makes the as-is executable; it does not
redesign it.

## Scope Completeness

Three-way coverage: discovery data → as-is processes → migration processes. Nothing dropped,
nothing invented.

### Discovery data → executable model

| Discovered | Source | Present in model | Gap |
|---|---|---|---|
| [participant / system] | participants-and-systems.md | [yes — bound at `<element>` / no] | [what is missing] |
| [data object] | data-objects.md | [yes — written by `<task>` / no] | [what is missing] |

Every system in `participants-and-systems.md` and every object in `data-objects.md` gets a row. A
system with no connector binding and no job worker is a **gap**, not an omission — list it. These
gaps are the real migration work items and they belong in Pipeline Readiness below.

### As-is processes → migration processes

| As-is doc | Migration BPMN | Status |
|---|---|---|
| [process-NN-name.md] | [process-NN-name.bpmn] | [present / MISSING] |

Include every as-is doc — main phases, `edge-*`, and any `subprocess-*`. A doc with no BPMN is a
blocking gap and will have failed the Step 2 gate.

**Do not compare step names or step counts between the markdown and the BPMN.** The generator
appends system suffixes, rewords headings, and derives elements from prose that carries no task
heading, so those numbers legitimately differ and a discrepancy table would be noise presented as
alarm. Fidelity of the process comes from Phase 0M's byte-identical copy, not from this document.

## Pipeline Readiness — shortest path to a running process

This section optimizes the **pipeline** `process-discovery → process-transformation →
artifact-generate`. It does **not** propose optimizing the process itself — any such change
violates this tier's contract and belongs in a to-be tier. If you find yourself writing "this step
could be eliminated", stop: that is the to-be tiers' job, and saying it here invites someone to
break the migration's one guarantee.

What stands between this BPMN and a deployed, running process, ordered by what blocks deployment
first:

### 1. Blocking — deployment or generation fails without these

- **[element] in [file]:** [service task with neither a connector template nor a job type / call
  activity whose called process is not among the generated files / message event with no
  correlation key] → [what to build]

### 2. Required before a process instance can complete

- **Job workers to implement:** `[job type]` — [element], [what it must do]
- **User task forms:** [element] — fields [list], sourced from [data object]
- **Process variables read but never written:** `[variable]` — read by [element]

### 3. Ready

- **Connector-bound service tasks:** [N] — [element → template ID]
- **Job-typed service tasks:** [N] — [element → job type]
- **User tasks with forms:** [N]

[If anything is listed under "Blocking", state instead that artifact generation will fail until
those are resolved, and name them.]
```

Substitute real values everywhere. Never leave a `[…]` bracket in the written file. If a table has
no rows, write `(none)` rather than an invented example row.

## EXEC: Output

"Migration rationale written. Coverage: [PASS/FAIL]. As-is docs in BPMN: [N]/[N]. Blocking
readiness items: [N]."
