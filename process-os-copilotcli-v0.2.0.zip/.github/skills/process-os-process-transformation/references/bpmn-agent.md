# Agent: Transformation BPMN Generator

You generate the BPMN for the tier this transformation iteration produced. This is a thin
orchestrator — all actual BPMN element mapping, XML authoring, layout, and lint live in
`process-os-bpmn-generation`. You do not author BPMN XML here.

## Your Assignment

You were dispatched with:
- `TIER` — one of: migration, incremental, radical, moonshot
- `ARTIFACTS_DIR` — the iteration's artifacts directory, already resolved by the caller — holds
  this run's phase docs and is where the generated BPMN lands
- `MODE` — `strategic` or `automatable` (resolved once by the orchestrator — the project's
  configured mode if it has one, else the `automatable` default). It is always set; never
  substitute your own value or drop the flag.

Substitute `<ARTIFACTS_DIR>` literally wherever it appears below. Do not resolve the iteration
yourself: the caller holds it from the moment it opened the iteration, and re-resolving here would
answer from whatever the filesystem says at dispatch time rather than from the iteration this run
is populating.

## EXEC: Step 1: Input dir

`<ARTIFACTS_DIR>` is both the input and the output. Phase 2 (`ai-challenge-phase.md`, for
`radical`/`moonshot`), Phase 1 (`tier-docs.md`, for `incremental`), and Phase 0M (for `migration`)
already wrote `<ARTIFACTS_DIR>/process-NN-*.md` before this agent was dispatched, so this run's
phase docs are already in place here. This agent never produces them — it only consumes them.

## AI: Step 2: Generate via process-os-bpmn-generation

Invoke the `process-os-bpmn-generation` skill explicitly — a real, end-to-end generate-mode
invocation, not an advisory read of its docs. It owns element mapping, XML authoring, auto-layout,
and lint uniformly, whichever tier this run produced.

Invocation:

```
/process-os-bpmn-generation --input <ARTIFACTS_DIR> --output <ARTIFACTS_DIR> \
  --embedded --bpmn-mode <MODE> --no-snapshot

Run unattended — no questions, just generate.
```

- `--input <ARTIFACTS_DIR>` / `--output <ARTIFACTS_DIR>` — the same directory: the generated
  `.bpmn` lands beside the phase docs it was generated from.
- `--embedded` — this call is a sub-invocation inside the transformation skill's Phase 3, so
  `process-os-bpmn-generation` must not write the shared `.camunda/state.md`/`audit.md`/`memory.md`
  provenance records; the transformation skill's own Phase 5 (`finalize.md`) owns that bookkeeping.
- `--bpmn-mode <MODE>` — passed through unchanged from your assignment (see Your Assignment
  above); do not re-derive or default it here. No `--width`/`--depth`: a size the generator
  chooses itself is automatic and never drops a documented step.
- `--no-snapshot` — the iteration directory is this transformation run's own version history, and
  the phase directory is never allowed a `.snapshots/` subtree.
- The **Run unattended** line auto-resolves the size-confirmation gate so this call is never
  blocked on an interactive prompt.

`process-os-bpmn-generation` writes `process-NN-*.bpmn` (+ `.gen.mjs`), `edge-*.bpmn` (+
`.gen.mjs`), `00-overview.bpmn`, and `PROCESSES.md` into `<ARTIFACTS_DIR>`. Wait for it to return
before continuing.

## AI: Step 3: Confirm-disposition overlay

If `TIER` is `migration`, skip this step — output is: "BPMN generation complete for the migration
tier." Migration keeps no questions store: it makes the as-is process executable without proposing
any change, so nothing in it is an "unconfirmed automation assumption" to flag.

Otherwise, re-apply the open-review overlay on top of the BPMN `process-os-bpmn-generation` just
wrote. **What feeds it depends on the tier — but not on which tier reads a questions store.**
[tier-docs.md](references/tier-docs.md) writes
`<ARTIFACTS_DIR>/review-questions.yaml` for every tier that reaches it, so every tier here has one:

- **The questions store — every tier.** Unanswered questions in
  `<ARTIFACTS_DIR>/review-questions.yaml`, whose `id` and `text` values bind
  `question-targets.json` below. `tier-docs.md` derives them from the `[CHANGED]`, `[NEW]` and
  `[REMOVED]` markers in this iteration's phase docs, and those markers are present whichever step
  wrote the docs — the phase agents for `incremental`, the flatten for `radical`/`moonshot`.
- **The confirm-disposition marker — `radical`/`moonshot` only.**
  `scripts/tier-verdicts-to-phase-docs.cjs` renders the bullet
  `❓ Not in verdicts — confirm disposition` into `<ARTIFACTS_DIR>/process-NN-*.md` /
  `edge-NN-*.md` for a step no `verdicts.json` entry matched. Such a step keeps its `[RETAINED]`
  marker, and `tier-docs.md`'s question sources are the change markers, so an unscored step yields
  no question. The bullet is the only signal that its disposition is unconfirmed, so it gets a tag
  of its own with nothing to key to.

1. Read `<ARTIFACTS_DIR>/process-NN-*.md`, `<ARTIFACTS_DIR>/edge-NN-*.md` (the files just generated
   from) and `<ARTIFACTS_DIR>/review-questions.yaml`.
2. Write `<ARTIFACTS_DIR>/question-targets.json` — one entry per element still tied to an
   unanswered question in `<ARTIFACTS_DIR>/review-questions.yaml` (one whose `answer` is empty and
   whose `status` is not `answered`), in the schema the discovery phase's own
   `question-targets.json` uses (`process-discovery/references/as-is-bpmn.md` Stage 2), with
   `"severity": "CONFIRM"` on every entry — never `OPEN`. Discovery's four values are descriptive
   (a fact about the as-is process is unknown/risky/unverified/contested); this overlay is
   prescriptive (an automation recommendation resting on an unconfirmed API assumption) and
   `CONFIRM` ("likely correct but unvalidated") is the closest existing fit — `OPEN` would wrongly
   imply the fact itself is unknown, when the analysis did find a plausible API, it just isn't
   human-confirmed yet.

   Write it on every tier that reaches this step: the governance questionnaire asks this
   iteration's questions whichever tier produced it, and an answered question with no target to
   flip leaves a `[CONFIRM]` tag standing over a resolved assumption. It lives in `<ARTIFACTS_DIR>`
   beside the `.bpmn` files because `mark-resolved.cjs`, which a later
   `process-os-review-answer-application` pass uses to resolve these tags, scans one directory for
   `.bpmn` + `question-targets.json` + `annotations.md` together.

   On `radical`/`moonshot`, also write `<ARTIFACTS_DIR>/confirm-targets.json` — one entry per element
   carrying the confirm-disposition bullet, with no question id, since there is no bound review
   question to reference:
   ```json
   [{ "elementId": "task_reviewException", "step": "Review Exception" }]
   ```
   `step` is the as-is step name, which step 4 reports. Look the element ids up by name — never Read
   the `.bpmn`:
   ```bash
   node ".github/skills/process-os-process-transformation/scripts/bpmn-extract.cjs" "<ARTIFACTS_DIR>" --names --exclude 00-overview.bpmn
   ```
   These appear in neither `question-targets.json` nor `annotations.md`: with no question id there
   is nothing for a review to resolve. Skip the file when no element carries the bullet.
3. Run the injector to write the `<bpmn:documentation>[CONFIRM] (qN)</bpmn:documentation>` tags, the
   bare `<bpmn:documentation>[CONFIRM]</bpmn:documentation>` tags from `confirm-targets.json`, and
   emit `<ARTIFACTS_DIR>/annotations.md` — never hand-edit the `.bpmn`, and never hand-write
   `annotations.md`:
   ```bash
   node ".github/skills/process-os-process-transformation/scripts/bpmn-question-tags.cjs" --dir <ARTIFACTS_DIR> --title "Transformation BPMN Annotations Index"
   ```
   Exit `1` lists unresolved element ids and prose-documentation conflicts on stderr; exit `2` means
   one of the two JSON files is invalid, and nothing was written. Fix the cause and re-run — the
   script is idempotent. A `superseded:` line on stdout is not a failure: a question also names that
   element, so it carries the question's tag, which a review can resolve.

   **The tags live in the `.bpmn`, so regeneration drops them.** Re-run the injector after any later
   re-run of a `<file>.bpmn.gen.mjs` or `process-os-bpmn-generation --target/--from` over
   `<ARTIFACTS_DIR>`; it restores both kinds from the two files.
4. Add an "⚠ Unconfirmed automation" section to `<ARTIFACTS_DIR>/unconfirmed-automation.md`
   (created by this step, not by `process-os-bpmn-generation`) summarizing every `[CONFIRM]` tag
   added: the question text and the affected element for a keyed tag, and the affected element with
   its as-is step name for a bare one.

Output: "BPMN generation complete for the `<TIER>` tier — [N] elements tagged with unconfirmed
automation assumptions, pending review."
