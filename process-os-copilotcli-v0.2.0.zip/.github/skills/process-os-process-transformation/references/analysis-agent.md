# Agent: Transformation Analysis

You are the transformation synthesis agent. Read all challenge data and capability research, then produce a challenge matrix and this run's transformation proposal.

## Your Assignment

You were dispatched with:
- `TIER` — the resolved tier keyword. Always `radical` or `moonshot` — SKILL.md's Phase 2 routing
  never dispatches this agent for `incremental`.
- `AS_IS_DIR` — the discovery output directory, already resolved by the caller.
- `ARTIFACTS_DIR` — the iteration's artifacts directory, already resolved by the caller. Every
  path below resolves inside it.

## AI: Step 1: Read All Context

Read ALL of the following in a single parallel batch (issue all Read calls simultaneously):
- `data/transformation-bootstrap.md`
- `data/transformation-challenges.md`
- `<AS_IS_DIR>/as-is-process.md`
- `<AS_IS_DIR>/gap-analysis.md`
- `<ARTIFACTS_DIR>/00-holistic-assessment.md`
- Read `ai-in-bpmn.md` for AI-agent ad-hoc-subprocess structural rules.
- Read [modeling-guidelines.md](references/modeling-guidelines.md) for the expert-validated to-be modeling rules (T1–T9). T1's tier table sets each tier's agent-vs-deterministic default (incremental: determinism-first; radical: override with justification; moonshot: agent-first); the T3 guardrail kit is tier-invariant on every AI-agent verdict.

Find additional files:
```bash
node ".github/skills/process-os-process-transformation/scripts/list-files.mts" "data/system-capabilities/*.md" "<AS_IS_DIR>/process-*.md" "<AS_IS_DIR>/edge-*.md" "<AS_IS_DIR>/subprocess-*.md"
```
Read all found files in a second parallel batch (issue all Read calls simultaneously).

You must understand what makes a structurally valid Camunda AI agent ad-hoc subprocess before proposing any AI replacements — proposals that reference invalid BPMN patterns will cause Phase 3 agents to generate broken XML.

## AI: Step 2: Build Challenge Matrix

**Zero-Based Design framing — read before evaluating any individual challenge:**

The goal is not to make the existing process faster. The goal is to rebuild from the North Star Outcome — the actual business result this process exists to deliver — and ask for every step: "Does this step serve the outcome, or does it exist for historical, organizational, or integration-gap reasons?"

**Before writing verdicts, state the North Star Outcome:**
Write it as one sentence: what would a world-class result look like if technology were unconstrained? (e.g., "A qualified vendor is approved and onboarded within 4 hours of submitting their application, with zero manual touches on standard cases." or "A customer claim is resolved and paid within the same business day, with humans only involved in fraud cases and high-value disputes.") Every verdict below should be filtered through this lens.

**Anti-pattern to avoid — "paving the cow path":** automating a broken process is the most common transformation failure. Before asking "how can we automate step X?", ask "can AI eliminate the need for steps X, Y, and Z entirely?" The moonshot tier MUST start from this question, not from the as-is process steps.

For each element in `data/transformation-challenges.md`, make a verdict by tier.

**System verdicts — apply in order:**
1. If challenge type includes "remove": is there a system in the landscape with a confirmed-high-confidence capability to absorb this system's role? If yes → "Removed: absorbed by [System Y]". If confidence is medium → apply to radical/moonshot only. If confidence is low or no evidence → retain, note why.
2. If challenge type includes "replace": is the replacement system's overlap confirmed? Same confidence tiering.
3. If challenge type includes "consolidate": what specifically does the absorbing system need to do? Is that capability confirmed?

**Data flow / step group verdicts:**
- Merge: confirm all named steps write to the same data object with no ordering dependency. If confirmed → "Merged: [N] steps → 1 step".
- Eliminate: confirm a direct integration would make the step unnecessary. If confirmed → "Eliminated: requires [integration name]".
- Replace: confirm an API exists. If confirmed → "Replaced by: [service task / connector]".

**Structural / cross-task pattern verdicts:**
- sequential-approvals: determine if dependencies exist between approvals. If none → "Parallelized: [N] sequential approvals → parallel gateway. Cycle time reduction: [N] days → [N] hours."
- ping-pong: identify the missing data that causes the round trip. → "Eliminated: pre-populate [field] via service task at entry; round-trip removed."
- polling-task: check if the source system supports webhooks or callbacks. If yes → "Event-driven: polling task removed; [system] webhook → Camunda intermediate message catch event." If no → "Timer boundary: check every [interval] via service task."
- routing-task: → "Automated: routing task removed; gateway + [assignment rule description]."
- data-reentry: → "Eliminated: [field] populated once from [source system] via service task; passed as process variable to all [N] downstream tasks."
- notification-wait-pair: → "Event-driven: service task sends; intermediate message catch event receives reply; [N] polling tasks removed."
- parallel-update-chain: → "Parallelized: [N] sequential updates → parallel gateway of [N] service tasks."
- manual-batch: → "Multi-instance subprocess: automatic iteration over [collection variable]."
- queue-bottleneck: estimate the wait-to-active ratio. → "Queue eliminated: auto-assignment via [rule/ML classifier] + SLA boundary event escalation. Wait time: [N days] → [N minutes]." Combine with the underlying task verdict if the task itself is also automated — double impact.
- predictive-routing: → "ML routing: [N] outcome classifier trained on [signals]. Human dispatcher removed. Apply in radical/moonshot only."
- unstructured-entry: → "LLM extraction: AI Agent Ad-Hoc Subprocess reads [source], extracts [fields], writes to process variables. Manual transcription step eliminated." Apply in incremental tier if the extraction is straightforward; radical/moonshot for multi-source or complex documents.

For each structural pattern, specify which tier it applies to: incremental (no system changes required), radical (requires new integrations), moonshot (requires new system or fundamental redesign).

**External AI / rule engine verdicts:**
- camunda-ai-replace: confirm the Camunda AI Agent Ad-Hoc Subprocess can perform the same function (check ai-in-bpmn.md for structural validity). If yes → "Replaced by Camunda AI Agent: [capability description]. External system [name] removed." Specify which tier — if the external system is already in production, moonshot or radical only unless a parallel path is feasible.
- camunda-dmn-replace: → "Replaced by Camunda DMN decision table: [decision name]. External rule engine [name] removed." DMN replacements are typically lower risk — can apply to radical tier with medium confidence.

**UserTask verdicts — apply in this order:**

**1. api-replace candidacy** (from challenge-agent output):
- Any task marked `api-replace` → verdict is "Service Task: [connector type] — [API endpoint]"
- Identify the appropriate Camunda connector: HTTP Connector (generic REST), or a native connector if available (Salesforce, HubSpot, Slack, etc.)
- These tasks become Service Tasks in ALL tiers where the API confidence is confirmed. For incremental: require high-confidence API. For radical/moonshot: include medium-confidence.
- A single, deterministic API call with no conditional follow-up stays as a Service Task. If the task was upgraded to `ai-orchestration` (see below), do not use a Service Task.

**1b. ai-orchestration candidacy** (from challenge-agent output):
- Any task marked `ai-orchestration` → verdict is "AI Agent Ad-Hoc Subprocess: [N] tools — [API endpoints involved]"
- Model as a Camunda AI Agent Ad-Hoc Subprocess per ai-in-bpmn.md. Each API endpoint becomes one tool activity (root node, no incoming sequence flows) inside the subprocess.
- The system prompt describes what the agent is orchestrating; tools expose the individual API operations with `fromAi()` parameters.
- This is NOT only for fuzzy AI tasks — it is the Camunda-native pattern for multi-step API orchestration. The agent handles conditional routing, retries, and exception paths between API calls automatically.
- Apply in: incremental (if all APIs are high-confidence), radical and moonshot (include medium-confidence).

**1c. dmn-replace (incremental-tier rendering of enumerable rule decisions):**
- For any high/medium-candidacy task whose decision criteria are enumerable conditions over structured data (challenge-agent notes these `enumerable: yes` — rule-based decision, scoring against a known rubric), the **incremental** verdict is "DMN business rule task: [decision name] — [rule summary]" (`verdict: dmn-replace`) — deterministic, low risk, no confidence threshold needed.
- At **radical/moonshot** the same task follows the AI threshold model below (full AI agent) — the DMN→agent step is part of the tier gradient (modeling-guidelines T4), with the DMN moving to the output-guardrail position (T3.3).
- Regulated decisions (declines, adverse action) keep structured DMN output — `{decision, reasonCodes, ...}`, never a bare boolean — at **every** tier: as decider at incremental, as the agent-output guardrail at radical/moonshot.

**2. AI threshold model (applies to high/medium/low AI candidacy tasks):**
- **High candidacy:** assess which pattern applies:
  - Structured input + clear output criteria → Full AI agent, escalate if confidence < 80%
  - Review/approval with defined rubric → AI proposes + rationale; human approves/overrides
  - Data gathering across systems → AI agent with tools (REST lookups) replaces entirely
  All high-candidacy AI tasks use Camunda's AI agent ad-hoc subprocess. Confirm architectural validity against ai-in-bpmn.md before including.
- **Medium candidacy:** AI assist in radical/moonshot tiers only
- **Low candidacy:** retained as UserTask in all tiers; write one-sentence justification

**2b. AI Co-Pilot verdict (applies to every `legally-mandated` and `low` AI candidacy task):**

From challenge-agent's `ai-copilot` flag: even if the human step cannot be eliminated, AI can reduce active time per touchpoint significantly. Apply in radical and moonshot tiers; optionally in incremental.

Co-pilot pattern choice — apply the most impactful:
- **HITL threshold model:** AI handles standard 80% of cases fully automatically (high confidence path); the remaining 20% edge cases route to a human task with AI pre-work already done. BPMN: AI Agent Ad-Hoc Subprocess → exclusive gateway on confidence score → Service Task (auto-complete high-confidence) OR User Task (human reviews low-confidence). This is the highest-value pattern — it eliminates most touchpoints while preserving the human fallback.
- **Draft + confirm:** AI Agent generates draft (response, document, recommendation) → UserTask where human reviews and approves/edits. Active time: hours → minutes.
- **Summarize + decide:** AI Agent summarizes case history, relevant data, and prior decisions → UserTask where human sees the brief and makes the call. Eliminates information-gathering time.
- **Pre-validate + proceed:** AI Agent checks inputs for errors, policy violations, missing data → UserTask only if issues found; automated proceed otherwise.

Verdict: "AI Co-Pilot: [pattern]. [Task name] retained — [legal/judgment reason]. AI [drafts X / summarizes Y / pre-validates Z / handles 80% auto]. Human [approves / overrides / handles exceptions]."

**3. Moonshot override — apply last:**
For moonshot tier only: any UserTask NOT marked `legally-mandated` should be challenged one final time. Ask: "Could this task be replaced with an AI agent with a low confidence threshold (50%) plus human escalation on exception?" If yes, apply it. Moonshot should contain the minimum possible human UserTasks — if a task is retained, it must have an explicit documented reason in "What Stays and Why."

Write `<ARTIFACTS_DIR>/challenge-matrix.md`:

```markdown
# Challenge Matrix
Generated: [date] | Process: [process name]

## North Star Outcome
**[One sentence: what world-class result does this process exist to deliver?]**
**Anti-pattern check:** [Does the current process serve this outcome or is it paving a cow path? Name the biggest structural waste.]

## Baseline Touchpoint Count
**As-is UserTasks (human touchpoints):** [N] — list all task names

## Systems

| System | Priority | Challenge | Evidence | Confidence | Verdict | Tiers applied |
|--------|----------|-----------|----------|-----------|---------|--------------|
| [name] | high | remove | [evidence sentence] | medium | Removed — absorbed by [Y] | radical, moonshot |

## Data Flows & Step Groups

| Element | Steps involved | Challenge | Evidence | Verdict | Tiers applied |
|---------|---------------|-----------|----------|---------|--------------|

## Structural / Cross-Task Patterns

| Pattern | Tasks involved | Verdict | Cycle-time impact | Tiers applied |
|---------|---------------|---------|-------------------|--------------|
| sequential-approvals | [A, B, C] | Parallelized → parallel gateway | [N days] → [N hours] | incremental |
| polling-task | [Check order status] | Event-driven: webhook → message catch event | removes daily check | radical |
| data-reentry | [B, D, G] | Eliminated: pass as process variable | removes [N] manual entries | incremental |

## External AI / Rule Engine Systems

| System | Type | Verdict | Camunda element | Tiers applied |
|--------|------|---------|----------------|--------------|
| [system] | external-AI | Replaced by Camunda AI Agent: [capability] | AI Agent Ad-Hoc Subprocess | moonshot |
| [system] | rule-engine | Replaced by Camunda DMN: [decision name] | DMN Decision Table | radical |

## Unstructured Data Entry Points

| Step | Source | Extracted entities | Target | Verdict | Tiers applied |
|------|--------|-------------------|--------|---------|--------------|
| [task] | [email / PDF / portal] | [names, amounts, intent] | [process variables] | LLM extraction AI Agent | radical+ |

## Manual Touchpoint Analysis

| Task | Candidacy | Verdict | Connector/Pattern | Tiers applied |
|------|-----------|---------|-------------------|--------------|
| [task] | api-replace | Service Task: HTTP Connector PATCH /quotes/{id} | HTTP Connector | all |
| [task] | ai-orchestration | AI Agent: 3 tools (GET /customer, PATCH /quote, POST /notify) | AI Agent Ad-Hoc Subprocess | incremental+ |
| [task] | high AI | Full AI agent, escalate < 80% | AI Agent Ad-Hoc Subprocess | incremental+ |
| [task] | low AI | Retained — [reason]. AI Co-Pilot: summarizes case + recommends | UserTask + AI Agent | radical+ |
| [task] | legally-mandated | Retained — [specific legal requirement]. AI Co-Pilot: HITL 80/20 — AI handles standard cases; human reviews exceptions | UserTask + AI Agent | radical+ |
```

## AI: Step 2b: Define the Standard Path and STP Rate

Before writing any proposal, establish the standard path definition. This drives the headline metric in every exec summary.

**Standard path** = the instance that follows the main flow without triggering any edge cases, exception branches, or approval escalations. Define it precisely for this process: list the specific conditions that must hold (e.g., "discount within rep authority, no contract redlines, payment received within net-30, no entity deviation"). A reader must be able to answer "does this deal qualify?" with a yes/no.

**Volume estimate:** What % of process instances follow the standard path? Use this priority order:
1. Process instance trace data (e.g., BigQuery, CRM event logs) — compute the actual % of instances that never triggered an exception branch
2. As-is process documentation — look for explicit frequency hints ("~80% of deals", "rare — <5% of volume")
3. Conservative estimate from the process structure — if no data, use 60% as the floor and flag it as an estimate

**Standard path touchpoint count per tier:** Walk the standard path only. Count the human UserTasks a standard-path instance encounters. This number is the headline STP metric — it will be lower (often much lower) than the overall task elimination count.

Write these to `<ARTIFACTS_DIR>/challenge-matrix.md` under a `## Standard Path Definition` section:

```markdown
## Standard Path Definition

**Conditions:** [list the specific conditions that define a standard instance — e.g., "no legal redlines, discount ≤ rep authority threshold, payment within net-30, no entity deviation"]
**Volume estimate:** [X]% of instances — [source: process instance data / documentation hint / conservative estimate — flag if estimated]
**As-is standard path touchpoints:** [N] UserTasks — [list the specific tasks a standard-path instance encounters]

| Tier | Standard path human touchpoints | STP rate on standard path |
|------|---------------------------------|--------------------------|
| As-is | [N] | 0% (fully manual) |
| Incremental | [N] | [X]% of standard-path instances complete with ≤[N] touches |
| Radical | [N] | [X]% |
| Moonshot | [N] | [X]% — target: 100% STP on standard path |
```

The moonshot STP rate on the standard path should be 100% if the design is correct — if any UserTask survives on the happy path in moonshot, re-examine whether it's truly legally mandated or just conservative.

## AI: Step 3: Write the Proposal Doc

Write `<ARTIFACTS_DIR>/proposal.md` for `TIER`. `<ARTIFACTS_DIR>/challenge-matrix.md` (Steps 2 and
2b above) is already written, independent of `TIER`.

The proposal must be self-contained — it must not reference any other proposal file.

**Tier rule — follow the entry matching `TIER`** (never `incremental` — SKILL.md's Phase 2
routing skips this agent for it):
- **Radical:** System replacements where evidence confidence = high or medium. All structural patterns applied including queue-bottleneck elimination and predictive routing. api-replace → Service Task (all confirmed APIs). ai-orchestration → AI Agent Ad-Hoc Subprocess (all confirmed APIs). Enumerable rule-based decisions → full AI agent with DMN output guardrail (no dmn-replace at this tier). unstructured-entry → LLM extraction AI Agent. AI: full AI agent for high-candidacy (escalate < 80%), AI assist for medium-candidacy. External AI systems → Camunda AI Agent where capability match is confirmed. AI co-pilots applied to ALL retained UserTasks (`legally-mandated` and `low` AI candidacy). Challenges org structure boundaries.
- **Moonshot:** Start from zero UserTasks — do not enumerate as-is steps and automate them one by one. Start from the North Star Outcome and design backward: what is the minimum process that delivers that outcome? Add humans back ONLY where:
  - A specific legal/regulatory mandate names a human action (GDPR Art. 22, EU AI Act high-risk, SOX judgment, named contractual obligation), OR
  - The financial/legal consequence of an AI error is catastrophic AND no human review fallback is feasible
  All structural patterns applied without exception. All api-replace → Service Task. All ai-orchestration → AI Agent Ad-Hoc Subprocess (include medium-confidence APIs). Enumerable rule-based decisions → full AI agent with DMN output guardrail (no dmn-replace at this tier). All unstructured-entry → LLM extraction AI Agent. All high+medium AI candidacy → full AI agent (lower threshold to 65%). Low AI candidacy tasks: moonshot challenge — replace if any automation path exists. ALL external AI systems → Camunda AI Agent. ALL external rule engines → Camunda DMN. New systems may be introduced where needed.
  **AI co-pilots on ALL retained UserTasks:** no human task in moonshot proceeds without AI assistance. Use the HITL threshold model (80% auto / 20% human dashboard) wherever feasible — this is the pattern that achieves 90%+ straight-through processing while maintaining safe human fallback on exceptions.
  **Prefer AI Agent Ad-Hoc Subprocess over multi-step Service Task chains.** If you find 3+ sequential Service Tasks with gateways between them, consolidate into an AI Agent with tool activities. Camunda AI agents handle multi-system orchestration resiliently — conditional routing, retries with context, exception handling — making them better than Service Task chains for anything non-trivial. Use them aggressively at this tier: moonshot's default is agent-first (modeling-guidelines T1 tier table / T7.3). Every consolidated agent still carries the full T3 guardrail kit — aggressive tiers raise the agent count, never the agent riskiness.
  **Target: ≤ 10% of as-is UserTasks retained (Q2C automation leaders benchmark: 90%+ straight-through processing).** If moonshot retains more than 20%, re-examine — you are being too conservative.

Structure for each proposal doc:

```markdown
# [Process Name] — [Radical/Moonshot] Transformation Proposal

## Executive Summary

[3 sentences maximum. Write for an executive who will decide whether to pursue this tier.]

**Sentence 1 — the STP headline (lead with this, not the task count):** State the straight-through processing rate on the standard path. Format: "[Standard path description] — [X]% of [deal/claim/order] volume — [achieves full automation with zero human touchpoints / requires [N] human touchpoints, down from [M] today]." Be explicit about what "standard path" means in a brief parenthetical. Example: "The standard deal (no redlines, discount within rep authority, payment on first invoice) — roughly 65% of annual deal volume — completes with zero human touchpoints under this proposal, from quote acceptance through cash collection."

**Sentence 2 — the mechanism:** How is that STP rate achieved? Name the primary mechanism. Example: "This is achieved by replacing [N] of [N] original manual steps with API service tasks and AI agents, eliminating every task that existed only because [Salesforce / ERP / billing system] lacked automation — not because human judgment was required." Task elimination count goes here, as evidence for Sentence 1 — not as the headline.

**Sentence 3 — the call to action:** What does choosing this tier mean? Reference the specific timeline, cost-of-doing-nothing, or industry benchmark. Example: "Teams that have automated this path consistently report [X]% reduction in quote-to-cash cycle time within 6 months of go-live — the current [N]-day average cycle is the direct cost of the manual steps this tier removes."

Do NOT write generic tier descriptions. Every sentence must reference specific findings from THIS process. Do NOT lead with task counts — lead with STP rate on the standard path, which is the metric that translates directly to revenue cycle time and headcount.

## What Changes

### Systems
- **[System]:** [removed / replaced by X / consolidated into Y] — [one sentence rationale]
(none — if no system changes at this tier)

### Flow Restructuring
- **[Pattern name]:** [what changes structurally] — [cycle-time or latency impact]
  - Sequential approval chain → parallel gateway: [N] days cycle time eliminated
  - Polling task → event-driven: [N] manual checks per week eliminated
  - Data re-entry → process variable: [N] manual entries eliminated
  - Notification-wait pair → Service Task + message catch event: [N] follow-up tasks eliminated
(none — if no structural pattern changes at this tier)

### AI Agent Ad-Hoc Subprocesses
[List every AI agent in this tier — both ai-orchestration tasks and AI candidacy task replacements and external system replacements]
- **[Task or system name]:** [what the AI agent does] — tools: [list API endpoints / capabilities as tool names]; system prompt goal: [one sentence]
  Camunda element: AI Agent Ad-Hoc Subprocess (per ai-in-bpmn.md structural rules)
  Guardrails: [per modeling-guidelines T3 — output validation (what deterministic check gates the agent's output), failure path (escalation boundary target), time-box, clamps on any LLM-authored engine value, tool gates for irreversible actions]
- **[Rule engine name]:** Replaced by Camunda DMN decision table — [decision logic description]; external system removed
(none — if no AI agents or DMN replacements at this tier)

### Task Automation
- **[Task name]:** [api-replace → Service Task / Full AI agent / AI assist] — [what replaces it]; [connector or pattern]
(none — if no task-level automation changes at this tier)

### AI Co-Pilots
[List every retained UserTask that gets an AI assistance layer — these are tasks where the human step cannot be eliminated but AI reduces active time or routes standard cases automatically]
- **[Task name]:** [legal/judgment reason to retain] — Co-pilot: [HITL 80/20 — AI handles standard cases automatically, human reviews exceptions | AI drafts [X], human approves | AI summarizes [Y], human decides]
  Camunda element: AI Agent Ad-Hoc Subprocess (prepares context/draft/recommendation) → UserTask (human confirms/overrides)
(none — if no co-pilots at this tier)

### What Stays and Why
- **[System or step]:** Retained — [reason: compliance requirement / low confidence / org constraint / legally mandated human]

## Resulting Flow

[Narrative walkthrough of the new process, 3–8 paragraphs. Write for someone who knows the original process. Name each phase. Describe who or what handles each stage — human, service task, or AI agent. Be specific about what changed from the original.]

## Key Assumptions

1. [What must be true for this proposal to work]
2. [...]

## Risks

- **[Risk name]:** [description] — Mitigation: [how to address]

## Why This Will Work

[3–5 bullets. This is the stakeholder confidence section — it answers "why should we believe this will succeed?" Write each bullet as an evidence-backed claim, not a generic assertion.]

- **[Change X] is proven feasible because:** [specific evidence — API confirmed at docs.example.com, capability research found in data/system-capabilities/[slug].md, or industry precedent]
- **[Change Y] has been done before:** [brief industry precedent or pattern — e.g., "Salesforce CPQ customers routinely automate this step; no custom development required"]
- **The risk of over-automation is bounded:** [what the human escalation path or fallback is — e.g., "All AI agents escalate to a human on confidence < 80%; no irrecoverable automated decision exists in this design"]
- **Org change required is [minimal/moderate/significant]:** [honest assessment — e.g., "Sales team stops manually updating CRM stage; the system updates it. Their workload decreases; no retraining beyond awareness"]
- **What could prevent this:** [the one honest risk that is hardest to mitigate — surface it here so stakeholders don't discover it later]

This section must be specific to the actual changes in this tier. Do not write generic statements like "AI is capable of this type of task." Name the system, the capability, the evidence source.

## What Implementation Requires

- [Integration that must be built]
- [Migration that must happen]
- [Org change that must occur]
(Keep this high-level — this is not a project plan, just an honest assessment of cost)

## Human Touchpoint Count

**Counting scope:** These numbers count ONLY the original as-is UserTasks from the main phases (`<AS_IS_DIR>/process-*.md`) and whether they survive into this tier. Baseline = main phases only. Edge cases and subprocesses are NOT part of this baseline — they are tracked separately in `data/transformation-bootstrap.md` `## Additional Process Scope` and in "New UserTasks Added" below.

**Why this distinction matters:** when someone grep-searches `<bpmn:userTask` in the generated BPMN files, the count will be higher than "retained" — because the transformation adds new UserTasks from co-pilot handlers, AND edge/subprocess files contain additional UserTasks outside the baseline. The exec summary STP claim refers only to the standard-path instance — not the overall task inventory.

**Critical: this section must be exact. Enumerate every original as-is UserTask from the main-phase baseline. Do not estimate.**

### Standard Path STP Rate

This is the executive headline metric. It answers: "for a normal [deal/claim/order], how many humans touch it under this proposal?"

- **Standard path definition:** [conditions that define a standard instance — copy from challenge-matrix.md `## Standard Path Definition`]
- **Volume on standard path:** [X]% of instances — [source]
- **As-is standard path touchpoints:** [N] tasks — [list the specific tasks a standard-path instance encounters today]
- **This tier standard path touchpoints:** [N] tasks — [list only the tasks that survive on the standard path in this tier]
- **STP rate:** [X]% of standard-path instances complete with zero human touchpoints / [description if non-zero]

Standard path touchpoints ≤ overall retained count. The difference = tasks that only appear on exception branches, not the happy path. If any UserTask survives on the moonshot standard path, write one sentence explaining the specific legal/contractual mandate — if you cannot name one, challenge the retention.

### Original As-Is Touchpoint Reduction

- **As-is (baseline):** [N] UserTasks — [list every original task name, comma-separated]
- **Retained from as-is:** [N] UserTasks — [list every retained task name, comma-separated]
- **Eliminated in this tier:** [N] tasks ([X]% reduction)
  - api-replace → Service Task: [N] tasks — [list]
  - AI agent (full replacement): [N] tasks — [list]
  - AI orchestration: [N] tasks — [list]
  - Merged/eliminated: [N] tasks — [list]
  - System removal: [N] tasks — [list]

Arithmetic check: baseline ([N]) = retained ([N]) + eliminated ([N]). If they don't match, recount before writing.

### New UserTasks Added by This Tier

These are UserTasks that do NOT exist in the as-is process — added by the transformation design:

- **AI co-pilot exception handlers:** [N] tasks — [e.g., "Review AI recommendation (fallback for low-confidence AI agent output)"] — these appear in the BPMN on the <20% confidence path; standard cases are handled automatically
- **Edge case / subprocess UserTasks:** [N] tasks — use the exact counts from `data/transformation-bootstrap.md` `## Additional Process Scope` section; do NOT estimate. List the files and per-file counts from that section verbatim.
- **New exception path UserTasks:** [N] tasks — [UserTasks on error/exception paths that the transformation design explicitly adds]

**Net BPMN UserTask count:** retained ([N]) + new ([N]) = [N total] — this is the number grep(`<bpmn:userTask`) will return across all generated BPMN files for this tier.

### What to State in the Exec Summary

**Lead with the Standard Path STP Rate** — not the task elimination count. The STP rate is the metric that translates directly to revenue cycle time and headcount. Example lead sentence: "The standard [deal] — [X]% of volume — completes with zero human touchpoints under this proposal."

The task elimination count (from "Original As-Is Touchpoint Reduction") is the mechanism that explains the STP rate. State it in Sentence 2, not Sentence 1.

Never use the net BPMN count in the exec summary — it will be larger due to new exception handlers and is not the right metric for either claim.
```

## AI: Step 3b: Write the Verdict JSON

Write `<ARTIFACTS_DIR>/verdicts.json`. This is a **write-once, "as-analyzed, pre-feedback"
intermediate**: the deterministic flattener (`scripts/tier-verdicts-to-phase-docs.cjs`)
reads it once to produce this iteration's phase docs, and after that the `.md` files — not this
JSON — are the live source of truth. The fold-in phase of a later run edits the `.md` directly; it
never writes back to this file, so do not treat it as authoritative once generation has run.

```json
{
  "tier": "<TIER>",
  "generated": "[date]",
  "_note": "as-analyzed, pre-feedback — the phase docs in this iteration's artifacts/ directory are the live source",
  "baseline_scope": "<AS_IS_DIR>/process-*.md main phases only",
  "baseline_count": [N],
  "tasks": {
    "[Task Name as it appears in the as-is phase file]": {
      "verdict": "api-replace|ai-agent|ai-orchestration|dmn-replace|ai-copilot|legally-mandated|low-ai|retained|removed",
      "element": "Service Task|AI Agent Ad-Hoc Subprocess|Business Rule Task|UserTask|—",
      "phase_file": "process-01-name.md",
      "connector": "[connector type — for api-replace tasks only, else omit]",
      "decision": "[decision name + rule summary — for dmn-replace tasks only (incremental tier), else omit]",
      "reason": "[why UserTask is retained, or why the task was eliminated for a `removed` verdict — else omit]",
      "tools": ["[API endpoint tool, e.g. 'GET /customer']", "..."],
      "system_prompt": "[one-line agent goal — for ai-orchestration/ai-agent tasks only, else omit]"
    }
  },
  "structural_patterns": [
    {
      "pattern": "polling|notification-wait|sequential-approvals|manual-batch|data-reentry|routing-task|queue-bottleneck|time-based-escalation|spawn",
      "tasks": ["[task name]", "..."],
      "phase_file": "process-NN-name.md",
      "construct": "message-catch|send+catch|parallel-gateway|multi-instance|process-variable|gateway|event-based-gateway|intermediate-throw",
      "note": "[one line — e.g. 'NetSuite webhook replaces the daily poll']"
    }
  ]
}
```

One more key exists that the entry above deliberately does not show, because it belongs on **no** entry that scores a baseline task: `"new": true`, marking a task the transformation **adds** — one with no heading in its `phase_file`.

```json
"[Name of a task the transformation adds]": {
  "verdict": "ai-agent",
  "element": "AI Agent Ad-Hoc Subprocess",
  "phase_file": "process-01-name.md",
  "new": true,
  "tools": ["..."],
  "system_prompt": "..."
}
```

Write it as the JSON boolean `true` (never the string `"true"`), on every added task and on nothing else. It matters because the flattener renders a declared-new entry and a mis-keyed one identically — both become a `[NEW]` step — so this flag is the only thing that tells the two apart for the completeness gate below. Setting it on a baseline task blinds that gate; omitting it on an added one can stop the phase outright.

`tools` and `system_prompt` are **required** on every `ai-orchestration` and `ai-agent` task entry — the AI-Agent ad-hoc subprocess is only structurally valid with ≥1 tool activity (see `ai-in-bpmn.md`), so omitting them produces an under-specified agent downstream. Emit `"verdict": "removed"` (with `reason`) for any task the analysis eliminates outright (system/step eliminations from Step 2's system and data-flow verdicts) — this is the only way the JSON-only flattener can see an elimination; it never reads the proposal narrative.

`structural_patterns` is the **structured form of the "Structural / Cross-Task Patterns" table you already write to `challenge-matrix.md`** (Step 2) — one entry per pattern row that applies to this tier, not new analysis. Map the prose pattern names 1:1 onto the `pattern` enum above (e.g. `polling-task` → `"polling"`, `notification-wait-pair` → `"notification-wait"`). A handful of Step 2's patterns — `predictive-routing`, `unstructured-entry`, `ping-pong`, `parallel-update-chain` — fall outside this fixed vocabulary and have no JSON slot; leave those in the prose proposal only. The flattener matches a pattern's `tasks` against the steps it finds inside `phase_file`, so if a pattern's tasks span more than one phase file, write one `structural_patterns` entry per phase file involved (same `pattern`/`note`, each entry's `tasks` limited to the names that live in that `phase_file`).

`construct` is **informational only** — it documents, for a human (or a future analysis-agent run) reading the JSON, which BPMN construct the pattern is expected to map to. The flattener (`tier-verdicts-to-phase-docs.cjs`) decides the actual BPMN construct by switching on `pattern` alone; it never reads `construct`. Keep `construct` consistent with `pattern` by convention (e.g. `sequential-approvals` ↔ `parallel-gateway`) so the two never silently disagree, but do not treat `construct` as a build directive — `pattern` is the sole source of truth for what gets generated.

**Completeness check:** every task from `baseline_count` must appear in `tasks` with a verdict from the enum above, **including `removed`**. A task **absent** from `tasks` is not the same as `removed` — it defaults to the conservative `retained` + `❓` confirm-disposition marker in the flattener, so any genuine elimination must be written explicitly as `"verdict": "removed"`, never left out. A task missing from the JSON entirely is a data-quality gap — verify every baseline task is accounted for before BPMN generation. Key every `tasks` entry by the **plain task name exactly as it appears in the as-is phase doc heading** (identifier prefix stripped) — the flattener evaluates this **per phase file**: when a `phase_file`'s entries propose changes but **none of them, of any kind** (retained included), matches one of that file's baseline step headings, it refuses to write phase docs for the whole tier (exit 3), naming the offending files. A correctly-keyed sibling phase file does not cover for a mis-keyed one. Entries marked `"new": true` are exempt from the gate — that is what lets a phase file which only *adds* tasks through — so a genuine addition must carry the flag and a scored baseline task must not. Note the gate only catches a phase file's *total* mismatch: if even one of its entries matches, its remaining wrongly-keyed entries slip through as duplicate `[NEW]` steps instead — so the key contract holds for every entry, not just until the gate stops complaining.

Output: "Transformation analysis complete. North Star: [one-sentence outcome]. Challenge matrix: [N] system verdicts, [N] step group verdicts, [N] structural patterns, [N] unstructured entry points, [N] manual touchpoint verdicts ([N] api-replace, [N] ai-orchestration, [N] dmn-replace, [N] AI, [N] ai-copilot, [N] retained). Proposal written for the <TIER> tier: <ARTIFACTS_DIR>/proposal.md. Verdict file: <ARTIFACTS_DIR>/verdicts.json. Touchpoint reduction: [summary]."
