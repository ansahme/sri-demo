# Sub-Skill: Fold In Feedback

You are running the **fold-in phase** of `/process-os-process-transformation` — folding reviewer
feedback filed against the iteration this run was seeded from into the new iteration SKILL.md just
opened, before the rest of the pipeline generates over it. SKILL.md has already resolved and
confirmed non-empty everything this phase needs:

- `<ARTIFACTS_DIR>` — this iteration's output directory
- `<FEEDBACK_DIR>` — the seeded iteration's `feedback/`
- `<N>` — this iteration's number

This is **not** a fresh analysis: no baseline analysis, no AI-Challenge, no tier scope decisions
of its own — it edits the documents this run's own analysis phase will read next. What a reviewer
sent is a directory listing, not a diff, so this phase reads `feedback/`, not `git diff`. It never
commits; the rest of the pipeline has no commit step of its own either — the ProcessOS user
commits when they choose to.

**A hand-edited file under `artifacts/` is a manual override, not a channel.** This phase never
looks for one and never propagates it specially. SKILL.md's `--seed` already carried every file in
the completed iteration's `artifacts/` forward into this new iteration as an ordinary copy, and
nothing past that point treats it differently from any other file in the new iteration. A reviewer
who wants a document change reconciled belongs in `feedback/`, like any other input — see Phase 2
(Fold-in). A reviewer who wants a *diagram* change reconciled also belongs in `feedback/`, but is
handled separately — see Phase 3 (Sync-back).

The phases, in order (mentions below use `Phase N (Name)`):

| Phase | Name | Does | Invokes |
|-------|------|------|---------|
| 1 | **Answers** | apply the reconciled answer set to this iteration's review questions | `process-os-form-response-application`, `process-os-review-answer-application` |
| 2 | **Fold-in** | make every other feedback file readable, then fold it into the matching `.md` | (inline + sub-agents) |
| 3 | **Sync-back** | fold a hand-edited diagram into its `.md` source, plus an override sidecar | `process-os-bpmn-to-md-sync` |
| 4 | **Integrity** | validate every `.md` Phases 1–3 touched | `process-os-markdown-integrity-check` |

## AI: Phase 1 (Answers) — apply the reconciled answers

Conditional: if `<FEEDBACK_DIR>/answers.json` does not exist, there is nothing to apply here — skip
straight to Phase 2 (Fold-in). Feedback consisting only of prose, with no questionnaire response, is
a normal run, not an error.

```bash
node ".github/skills/process-os-process-transformation/scripts/path-exists.cjs" "<FEEDBACK_DIR>/answers.json"
```

When it reports `EXISTS`, apply it to the freshly seeded `<ARTIFACTS_DIR>/review-questions.yaml` —
every question the seed carried is still `open`, exactly as it was asked, so this is the first time
an answer lands in this iteration's copy:

```
process-os-form-response-application "<ARTIFACTS_DIR>/review-questions.yaml" "<FEEDBACK_DIR>/answers.json"
```

It prints how many answers were written, how many were already answered (discarded), and how many
questions are still blank. Exit `2` (missing store, missing `answers.json`, or a bad flag), `4` (not
a valid questions store), or `5` (not valid YAML) → this iteration's seed did not land as expected;
report and stop — none of these degrade to "nothing to apply".

Then invoke `process-os-review-answer-application`, which folds every landed answer into the
matching `.md`, updates the tier's tracking docs, flips answered questions to `[RESOLVED]` in the
BPMN, and returns a `STRUCTURAL_CHANGES` list:

```
process-os-review-answer-application --dir "<ARTIFACTS_DIR>"
```

Pass **one** `--dir` — no separate `--bpmn-dir` — because the `.md` and the `.bpmn` are siblings in
`<ARTIFACTS_DIR>` now.

Carry **`STRUCTURAL_CHANGES`** and the list of `.md` files this step touched forward into Phase 4
(Integrity).

Re-check for `[MANUAL-PENDING]` markers:

```bash
node ".github/skills/process-os-process-transformation/scripts/search-files.mts" --pattern "[MANUAL-PENDING]" --fixed "<ARTIFACTS_DIR>"
```

`--fixed` is load-bearing: as a regular expression `[MANUAL-PENDING]` is a character class that
matches any one of those letters and never the marker as written. Exit `0` — the printed
`<path>:<line>:<text>` rows are the remaining markers. Exit `1` — none remain. Exit `2` — the search
could not run, so nothing is known; report that the check could not be performed and stop this
phase rather than falling through with the gate unverified.

If any markers remain, read the gate:

```bash
node ".github/skills/process-os-process-transformation/scripts/read-run-config.cjs" processTransformationGate.questions
```

Exit 2 → hard error: report stderr and stop; it means the reader failed, not that the key is unset.
`true` (attended, default) → stop and present the remaining markers to the ProcessOS user for
resolution before continuing. `false` (unattended) → note them and continue.

## AI: Phase 2 (Fold-in) — fold every other feedback file into the matching `.md`  *(gate: `processTransformationGate.nonMd`)*

The feedback listing SKILL.md resolved, minus `answers.json` (Phase 1 (Answers)'s own input), minus
any raw answer-source export — an `.xlsx` in the shape `process-os-questions-xlsx-export` produces,
or a `.md` in the shape `process-os-questions-md-export` produces — and minus every `.bpmn` (Phase 3
(Sync-back) below handles a hand-edited diagram with a tool that preserves what a prose fold would
drop).

**An export is excluded whether or not its answers ever reached the store, so confirm that they
did.** Compare each export's question ids against `answers.json`; any id absent from it is
unreconciled and belongs in this phase's own **Unhandled feedback** summary (below), with the
reason "answers not reconciled — run `/process-os-sme-feedback transformation`". Dropping it from
the fold and saying nothing would lose those answers with no trace anywhere.

For everything else — reviewer notes, exported docs, spreadsheets, PDFs, even a scanned image —
nothing is silently dropped. First make it *readable*, then fold whatever it carries into the
matching `<ARTIFACTS_DIR>/*.md`.

### EXEC: Make each file readable

- **Text already** (`.txt`, `.csv`, `.tsv`, `.json`, `.yaml`, `.xml`, `.rtf`, source files, …) →
  read it directly, in bounded chunks (~25 KB per read) if it is large.
- **Binary / non-narrative** (`.pdf`, `.docx`, `.xlsx`, `.pptx`, `.doc`, `.xls`, images, …) → make a
  genuine effort to extract its text before giving up. There is no fixed toolchain to prescribe —
  discover what this environment actually offers, probe for a converter or library that can pull
  text out of the format at hand, and try it. Only if the format is genuinely opaque, or nothing on
  the box can read it, fall through to "Report what you couldn't" below.

### GATE: honour `processTransformationGate.nonMd`

```bash
node ".github/skills/process-os-process-transformation/scripts/read-run-config.cjs" processTransformationGate.nonMd
```

Exit 2 → hard error: report stderr and stop; it means the reader failed, not that the key is unset.

- `true` (attended, default) → present each proposed fold for approve/reject before writing.
- `false` (unattended) → apply the unambiguous folds directly; still list anything ambiguous for
  the ProcessOS user rather than guessing.

### AI: Fold in what you could read

For every file you got usable text out of, fan out a sub-agent that treats the extracted text as
**additional documentation**, cross-checks it against the existing `<ARTIFACTS_DIR>/*.md`, and folds
the relevant content **into the matching `.md`** (the source of truth) — never treat the feedback
file itself as canonical.

**Even when a feedback file's content turns out to already be reflected in the `.md`**, still fold
in — never silently skip a file just because it looks redundant. Append the source's own wording (or
its distinguishing detail) next to the existing content so the `.md` shows both sources agree.

Record every `.md` you folded into — carry that set into Phase 4 (Integrity).

### EXEC: Report what you couldn't — never discard silently

Collect every feedback file that was **not** folded in — no extractor was available, extraction
yielded no usable text, or the content is a pure binary asset — and hold the list as this phase's
**Unhandled feedback** summary, one line each with the reason (`no extractor`, `no text extracted`,
`binary asset`). Print it once, at the end of Phase 4 (Integrity), rather than at each file. These
files stay exactly where the reviewer put them, in the seeded iteration's `feedback/`, already
committed.

## AI: Phase 3 (Sync-back) — fold a hand-edited diagram into its source

**This is where transformation deliberately differs from discovery.** A to-be diagram carries Zeebe
extensions, connector bindings, and AI-agent ad-hoc subprocesses that a prose round-trip drops
silently, and the sidecar written below is the only record that they were dropped — these diagrams
are the executable input `process-os-artifact-generation` reads, so a lost binding surfaces as a
broken deployment much later. So a hand-edited `.bpmn` is reconciled with a tool built for the job,
not folded as prose the way Phase 2 (Fold-in) folds everything else.

For every `.bpmn` file in the feedback listing, reconcile it into its same-basename pendant in
`<ARTIFACTS_DIR>`:

```
process-os-bpmn-to-md-sync --from <FEEDBACK_DIR>/<name>.bpmn --to <ARTIFACTS_DIR>/<name>.md
```

`00-overview.bpmn` has no single pendant — it aggregates every `process-NN-*.md`. If a reviewer
hand-edited it, ask the ProcessOS user which `.md`(s) to reconcile it into. There is no separate
full-generate fallback to choose here — SKILL.md's own Phase 3 (BPMN Generation) runs later in
this same pipeline call and regenerates every `.bpmn` from whatever `.md` set this phase leaves
behind. Report every `.md` this phase touched so that phase can see it: a fold-in that changed a
diagram's source makes generation mandatory there rather than a decision that may be declined.

The invoked skill updates the `.md`, appends to `<ARTIFACTS_DIR>/feedback_overrides.json`, and notes
the change in `<ARTIFACTS_DIR>/proposal.md`'s "Human Feedback Applied" section — gated internally on
its own `processTransformationGate.md`. Record every `.md` it touched — carry that set into Phase 4
(Integrity) alongside whatever Phase 2 (Fold-in) touched.

## AI: Phase 4 (Integrity) — validate every `.md` this phase touched

Run one `process-os-markdown-integrity-check` per file touched by Phase 1 (Answers), Phase 2
(Fold-in), or Phase 3 (Sync-back) — **sequentially, one at a time** (do NOT fan them out in
parallel):

```
process-os-markdown-integrity-check --file <that.md> --dir "<ARTIFACTS_DIR>"
```

Run these serially even on Claude Code. Each agent validates its file against the rest of the set
and may **reconcile drift in sibling files**, not just its target — so two agents running
concurrently can edit the same sibling and race. Let each agent finish (and its edits land) before
starting the next.

Resolve any `NEEDS-DECISION` with the ProcessOS user.

If Phase 2 (Fold-in) held back an **Unhandled feedback** list, print it now, one line each with its
reason. This phase is then done — hand control back to whichever phase **Route to Starting Phase**
picked; do not close the iteration or ask about committing here, both belong to
[finalize.md](references/finalize.md) at the end of the run.

## Error handling

- Any `NEEDS-DECISION` from `process-os-markdown-integrity-check` → pause for the ProcessOS user; do
  not guess.
- Any step that fails outright (a hard error from a script, an unreadable store) → report it and
  stop; do not continue on a partial result.
