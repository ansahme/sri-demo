# BPMN Generation — execution

Resolves the engine parameters this run's BPMN generation needs, once, before dispatching the
subagent that generates — so it never blocks on `process-os-bpmn-generation`'s size-confirmation
gate.

## EXEC: Step 1: Resolve MODE

Run the resolver once — substitute the verbatim text after `/process-os-process-transformation`
for `<ARGS>` (quoted, even when empty):

```
node ".github/skills/process-os-process-transformation/scripts/resolve-bpmn-mode.cjs" --source "<ARGS>"
```

**Stdout is MODE and nothing else** — one bare token, `strategic` or `automatable`, which goes
verbatim into the dispatch's `--bpmn-mode`. `--source` adds a `# mode source: <where>` note on
**stderr** (`args`, a config filename, or `default`); report that alongside MODE in this phase's
output so the ProcessOS user can see whether the mode was chosen or defaulted. If your tooling
shows stdout and stderr as one merged blob, **MODE is the line that is exactly `strategic` or
`automatable`** — the `#`-prefixed note is never MODE. Never fold the note into MODE, and drop
`--source` if you do not want it.

Its resolution order lives in `scripts/resolve-bpmn-mode.cjs`. Unlike
`process-os-bpmn-generation`'s own `EXEC: Resolve Mode` step, which errors when no mode is set,
this resolver always falls back to a default instead.

MODE always resolves — never dispatch without one, and never invent a value the resolver did not
print. Pass MODE through unchanged to the dispatched subagent.

## EXEC: Step 2: Leave the size to the generator

Pass no width or depth. `process-os-bpmn-generation` resolves the size itself: a non-`auto`
`size`, `width` or `depth` in `run.config.yaml` is explicit and is honoured, and may fold
steps; otherwise its quantification chooses the size — over the completed discovery iteration's
`artifacts/` when one exists, else over the generator's input — and a size it chooses is
automatic, so it never drops or folds a documented step. A width or depth passed as a flag would
count as an explicit request for a reduced diagram. The dispatched call runs unattended, which
resolves the generator's size-confirmation gate without a prompt.

## AI: Step 3: Dispatch

Dispatch one subagent to follow [bpmn-agent.md](references/bpmn-agent.md):

```
Read references/bpmn-agent.md and follow it.

TIER: <TIER>
ARTIFACTS_DIR: <ARTIFACTS_DIR>
MODE: <MODE>
```

Do **not**:
- Perform `bpmn-agent.md`'s steps yourself inline — invoking `process-os-bpmn-generation` and the
  confirm-disposition overlay are the dispatched subagent's job only.
- Continue before the dispatched subagent completes.

## EXEC: Step 4: Verify dispatch

```bash
node ".github/skills/process-os-process-transformation/scripts/dir-contains.cjs" "<ARTIFACTS_DIR>" "*.bpmn"
```

`MATCH` means BPMN was produced. `NO MATCH` — or a `NO DIR` line, meaning `<ARTIFACTS_DIR>` was
never created — is `INCOMPLETE`: no BPMN was produced for this run.

If this fails, re-dispatch the subagent — do not report the run as done.

## Not done yet

BPMN on disk is the midpoint, not the finish line — do not summarize or stop here. The iteration
directory is this run's own history, so there is no separate snapshot to save — Phase 4
(rationale) and Phase 5 (finalize) still need to run before this iteration can close.
