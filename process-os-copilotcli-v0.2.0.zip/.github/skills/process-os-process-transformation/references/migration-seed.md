# Sub-Skill: Migration Seed (Phase 0M)

You are seeding the `migration` tier — a **lift-and-shift** of the as-is process into executable
form. You do not analyse, propose, or improve anything. You copy.

The tier's contract: **the implementation of steps may change; the process may not.** No step is
added, removed, merged, reordered, or parallelized. Making a step executable — binding a connector
template, assigning a job type — is implementation, and it happens downstream in Phase 3. Deciding
that a step is unnecessary is a process change, and it is out of scope for this tier entirely.

`<AS_IS_DIR>` below is the discovery output directory the caller (SKILL.md Phase 0M's Check
requirements) resolved, and `<ARTIFACTS_DIR>` is this iteration's output directory, opened before
Phase 0M runs. Both are passed to `scripts/seed-migration.cjs` as arguments rather than baked into
its source, so neither value has to be re-typed into a string literal.

## EXEC: Step 1: Seed the docs

```bash
node ".github/skills/process-os-process-transformation/scripts/seed-migration.cjs" --as-is "<AS_IS_DIR>" --out "<ARTIFACTS_DIR>"
```

| Exit | Means | Do |
|---|---|---|
| `0` | seeded; the doc count is on stdout | continue to Step 2 |
| `2` | usage error, or `<AS_IS_DIR>` unreadable | hard error: report stderr and stop |
| `3` | `<AS_IS_DIR>` holds no as-is phase doc | stop: "No as-is phase docs in `<AS_IS_DIR>`. Run `/process-os-process-discovery` first." |
| `4` | `<ARTIFACTS_DIR>` already holds a phase doc | stop — see below |

The script's allowlist matches `process-os-bpmn-generation`'s own, so whatever it will generate
from is exactly what gets seeded here. Its printed count is the **only** source of truth for what
was copied. Do not add a file you recall from `00-index.md` or any other prose doc — those may
describe more phases than exist on disk.

`subprocess-*.md` is in that allowlist deliberately. No ProcessOS writer emits that file class
today, so the pattern usually matches nothing — but a hand-authored subprocess doc is a legitimate
input that `process-os-bpmn-generation` generates from, and migration must not be the step that
drops it.

**On exit `4`**, stop with:

> `<ARTIFACTS_DIR>` is already seeded. Re-seeding would overwrite it, discarding any feedback
> already folded into those docs. To regenerate BPMN from the existing docs, run
> `/process-os-process-transformation migration regenerate --bpmn`. To start over deliberately,
> delete the copied docs under `<ARTIFACTS_DIR>` first.

This is a safety net, not the primary control — routing already sends `regenerate` straight past
this phase. It exists because that routing is prose, and the cost of getting it wrong is the
silent destruction of human feedback.

**Do not edit the copied content.** Rewording a step so it reads as "more automatable" is exactly
the drift the next step catches, and it is a process change wearing implementation clothes.

## EXEC: Step 2: Verify the copy is byte-identical below the header

This is the tier's actual fidelity guarantee. Because Phase 3 generates from these copies, a
byte-identical copy means the generated BPMN is whatever `process-os-bpmn-generation` would have
produced from the as-is docs themselves — there is no transformation step in which the process
could drift. This is also why the check compares bytes rather than step names or step counts
between the markdown and the BPMN: that comparison is not deterministic (the generator reorders,
rewords, and derives elements from prose with no task heading at all), so it would fail on nearly
every real run. Byte-identity is the one guarantee construction can make instead.

```bash
node ".github/skills/process-os-process-transformation/scripts/seed-migration.cjs" --as-is "<AS_IS_DIR>" --out "<ARTIFACTS_DIR>" --verify-only
```

| Exit | Means | Do |
|---|---|---|
| `0` | every copy matches its source below the provenance header | continue to Step 3 |
| `5` | a copy differs from its source below the provenance header, or is missing — each offender named on stderr | stop — see below |

**On exit `5`**, treat it as a bug rather than something to fix by hand: Step 1 just wrote these
files, so a mismatch this soon means the copy step itself misbehaved, not that content drifted
over time. Delete the copied docs under `<ARTIFACTS_DIR>` and re-run Step 1 — do not edit the
flagged copy directly, and do not re-run Step 1 without deleting first, since it will refuse with
exit `4`.

## EXEC: Step 3: Write the proposal doc

Write `<ARTIFACTS_DIR>/proposal.md`:

```markdown
# [Process Name] — Migration (Lift-and-Shift) Proposal

## Executive Summary

The as-is process is carried into executable form unchanged. Every step discovered in
`<AS_IS_DIR>` appears in the generated BPMN, in the same order, with the same branching.
What changes is implementation only: steps a system can perform become service tasks bound to that
system's connector template or a job worker; steps requiring human judgment remain user tasks with
forms.

**Process fidelity: 100%. Touchpoint reduction: 0% — by design.**

If you want touchpoint reduction, run `/process-os-process-transformation` for the to-be tiers
(`incremental`, `radical`, `moonshot`). This tier deliberately answers a different question:
"make what we have run", not "what should we have".

## Scope

- **As-is docs carried over:** [N] — [list the filenames Step 1 copied]
- **Steps preserved:** [N] — the total across those files
- **Steps added / removed / merged:** 0

## What Changes

Implementation only. Element dispositions are decided by `process-os-bpmn-generation` under
`--bpmn-mode automatable` and reported in `<ARTIFACTS_DIR>/transformation-rationale.md` after
Phase 3 — this document does not predict them.

## What Does Not Change

Step inventory, step order, gateway conditions, branch structure, edge-case coverage, and the
participants and systems involved.
```

Substitute real values for every `[…]`. Never leave a bracket in the written file.

## EXEC: Step 4: Write the verdicts JSON

Write `<ARTIFACTS_DIR>/verdicts.json`. Every step from every copied doc gets
`"verdict": "retained"` — an honest machine-readable statement that nothing changed. This exists so
`regenerate` and the fold-in phase work uniformly across tiers without special-casing.

**Omit `element` entirely.** The service-task-vs-user-task decision is made inside
`process-os-bpmn-generation` by its connector-template matching, which has not run yet. Guessing
here would put a wrong disposition into a file later readers treat as authoritative.

```json
{
  "tier": "migration",
  "generated": "[YYYY-MM-DD]",
  "baseline_scope": "process-discovery as-is docs, copied verbatim",
  "baseline_count": 0,
  "tasks": {
    "[Step Name exactly as it appears in the doc heading]": {
      "verdict": "retained",
      "phase_file": "[process-NN-name.md]"
    }
  }
}
```

Set `baseline_count` to the real total and include one entry per step. The step name is the heading
text with its task-type token and any `T1:` / `2.4` identifier prefix stripped.

## EXEC: Output

```
Migration tier seeded.
  Docs copied: [N] → <ARTIFACTS_DIR>
  Steps preserved: [N] (0 added, 0 removed)
  Proposal: <ARTIFACTS_DIR>/proposal.md
  Verdicts: <ARTIFACTS_DIR>/verdicts.json
```
