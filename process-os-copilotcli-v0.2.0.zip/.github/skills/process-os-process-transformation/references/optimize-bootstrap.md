# Sub-Skill: Optimization Context

This runs after **both** `references/bootstrap.md` **and** `references/criteria.md` have completed.
It loads discovery context plus the selected optimization criteria and appends the `## Optimization Context`
section (anti-pattern catalog, available APIs, confidence thresholds, phase-agent assignments) for downstream agents
to consume.

## AI: Step 1: Read All Discovery Output

`<AS_IS_DIR>` below is the discovery output directory the caller resolved at its own Check
requirements step — substitute the literal value throughout.

Read ALL of the following using the `Read` tool:
- `<AS_IS_DIR>/as-is-process.md`
- `<AS_IS_DIR>/gap-analysis.md`
- `<AS_IS_DIR>/00-index.md`
- `<AS_IS_DIR>/participants-and-systems.md`
- `<AS_IS_DIR>/data-objects.md`
- All `<AS_IS_DIR>/process-NN-*.md` files (find them: `node ".github/skills/process-os-process-transformation/scripts/list-files.mts" "<AS_IS_DIR>/process-*.md"`)
- All `<AS_IS_DIR>/edge-NN.md` files (find them: `node ".github/skills/process-os-process-transformation/scripts/list-files.mts" "<AS_IS_DIR>/edge-*.md"`)
- `data/transformation-criteria.md` (written by criteria elicitation step)

## AI: Step 2: Read Optimization Config

Read `transformation.config.md`. If it exists, extract:
- Constraints — steps that must never be automated
- Disabled Anti-Patterns — pattern numbers to remove from the catalog
- Custom Anti-Patterns — additional patterns to add
- Systems with APIs — supplements `participants-and-systems.md`
- Confidence Thresholds — override defaults if provided

If `transformation.config.md` does not exist: use all defaults. Do NOT ask interactively.

Also read `run.config.yaml` for transformation settings (these supplement transformation.config.md):

```bash
node ".github/skills/process-os-process-transformation/scripts/read-run-config.cjs" transformation-aggressiveness
node ".github/skills/process-os-process-transformation/scripts/read-run-config.cjs" transformation-topics
```
Exit 2 from either read above → hard error: report stderr and stop; it means the reader failed, not that the key is unset.

- `transformation-topics` — free-text optimization goals, held as a YAML list. The reader prints **one goal per line**; treat each line as one additional optimization criterion added to the selected criteria. Do **not** re-split a line on commas — a comma inside a goal is part of it (`reduce handoffs, especially in finance` is one criterion). No output means no extra criteria.
- `transformation-aggressiveness` — integer 1, 2, or 3. Default: 2. Controls confidence thresholds and automation stance (see Step 5).

## EXEC: Step 3: Build Anti-Pattern Catalog

Start with the full default catalog:

| # | Pattern | Replace with |
|---|---------|-------------|
| 1 | Human enters ID that exists in another system | ServiceTask: API lookup using shared key |
| 2 | Human copies data between two systems | ServiceTask: API read → write |
| 3 | Human sends notification or routes work to another person | ServiceTask: messaging/webhook API |
| 4 | Post-review mechanical action (set status, trigger, publish) | ServiceTask |
| 5 | Yes/no decision based on a rule | XOR gateway + DMN table |
| 6 | Human reviews AI/system output before passing along | AI ServiceTask + confidence routing |
| 7 | Human applies consistent criteria to variable inputs | BusinessRuleTask or AI ServiceTask |
| 8 | Human coordinates between parties by messaging back and forth | Automated routing + SLA timers |
| 9 | Sequential steps with no data dependency between them | Parallel gateway split/join (run simultaneously, re-join before next step) |

Remove any pattern numbers listed under "Disable Anti-Patterns" in the config.
Append any custom patterns from the config, numbered 9, 10, etc.

## AI: Step 4: Build Available APIs List

Combine:
- Systems in `<AS_IS_DIR>/participants-and-systems.md` that have API access noted
- Systems listed under "Systems with APIs" in `transformation.config.md` (if file present)

For each system, note: name, API type (REST/SOAP/webhook/GraphQL), what operations are possible.

## EXEC: Step 5: Set Confidence Thresholds

If `transformation.config.md` provides explicit thresholds, use those. Otherwise derive from `transformation-aggressiveness`:

| Level | auto-apply | flag-for-review | Stance |
|-------|-----------|-----------------|--------|
| 1 — moderate | 0.95 | 0.85 | Automate only when near-certain; default to UserTask on any doubt |
| 2 — medium (default) | 0.90 | 0.70 | Standard thresholds |
| 3 — aggressive | 0.70 | 0.50 | Automate unless hard-constrained; every UserTask must justify its existence |

Routing rule:
- ≥ auto-apply → auto-apply, notify human non-blocking
- flag-for-review to (auto-apply − 0.01) → apply + create review task
- < flag-for-review → route to focused human review; AI provides draft and explanation

**For aggressiveness level 3**, add this instruction to `data/transformation-bootstrap.md` under a new subsection `### Automation Stance` (within the `## Optimization Context` section written in Step 7):
> AGGRESSIVE. Every UserTask is a candidate for elimination. Retain a UserTask only when: (a) it is listed in Hard Constraints, or (b) a non-delegable human judgment is required AND the consequence of a wrong automated decision is high (e.g., financial approvals above a configured amount threshold). For every retained UserTask, write a one-sentence justification.

## EXEC: Step 6: Identify Phase Agent Assignments

List all phase files in `<AS_IS_DIR>`:
```bash
node ".github/skills/process-os-process-transformation/scripts/list-files.mts" "<AS_IS_DIR>/process-*.md"
node ".github/skills/process-os-process-transformation/scripts/list-files.mts" "<AS_IS_DIR>/edge-*.md"
node ".github/skills/process-os-process-transformation/scripts/list-files.mts" "<AS_IS_DIR>/subprocess-*.md"
```

Match each edge file to its parent phase (by number prefix: `edge-01` pairs with `process-01`).

If no `<AS_IS_DIR>/process-*.md` files are found:
- Output "No process phase files found under the discovery output directory. Ensure /process-os-process-discovery completed successfully."
- Do NOT proceed. Stop.

If there are phase files:
- **The listing output above is the only source of truth for this table**. One row per *phase* file returned by the first command, with any matching edge file (from the second) listed in that row's Edge files column.
- **One additional row per subprocess file** returned by the third command, with `—` in the Edge files column. Subprocess docs are analysed exactly like phases. Without a row they are counted under `## Additional Process Scope` and then silently dropped — no subagent is assigned one, so nothing is ever written to `<ARTIFACTS_DIR>`, and the run loses part of the discovered process. (No ProcessOS writer emits `subprocess-*.md` today, so this listing usually returns nothing. A hand-authored subprocess doc is a legitimate input that `process-os-bpmn-generation` generates from, and must not be lost here.)
- Do NOT consult `00-index.md`, `gap-analysis.md`, or any other prose doc read in Step 1. Those docs may describe more phases than actually exist on disk.

Build the assignment table:

| Agent | Phase file | Edge files |
|-------|-----------|------------|
| Agent 1 | `<AS_IS_DIR>`/process-01-*.md | [edge-01.md or —] |
| Agent 2 | `<AS_IS_DIR>`/process-02-*.md | [edge-02.md or —] |
| Agent 3 | `<AS_IS_DIR>`/subprocess-[name].md | — |

## EXEC: Step 7: Append Optimization Context to data/transformation-bootstrap.md

Append the following section to `data/transformation-bootstrap.md` (append — do **not** overwrite existing content).

```markdown
## Optimization Context

### Process
- **Name:** [process name from as-is-process.md]
- **Phases:** [N] — [list filenames]
- **Edge case files:** [N] — [list filenames, or "none"]

### Available APIs
| System | Type | Operations available |
|--------|------|---------------------|
| [system name] | [REST/SOAP/etc.] | [create, read, update, delete, search, ...] |

### Anti-Pattern Catalog (Active)
| # | Pattern | Replace with |
|---|---------|-------------|
| [N] | [pattern] | [replacement] |

[If any patterns were disabled: "Patterns disabled per transformation.config.md: N, N"]
[If custom patterns added: list them here]

### Optimization Criteria
[Copy Primary Criteria and Rationale sections from data/transformation-criteria.md verbatim]

### Hard Constraints — Never Automate
[List each constraint. Source: transformation.config.md or "none specified"]

### Confidence Routing Thresholds
- ≥ [auto-apply, e.g. 0.90] → auto-apply, notify human non-blocking
- [flag, e.g. 0.70] – [auto-apply − 0.01, e.g. 0.89] → apply + create review task flagging specific uncertainty
- < [flag, e.g. 0.70] → route to focused human review; AI provides draft and explanation

(Substitute the actual resolved threshold values from Step 5 — do not write the expressions, write the numbers.)

### Phase Agent Assignments
| Agent | Phase file | Edge files |
|-------|-----------|------------|
[rows from Step 6]
```

Output: "Optimization Context appended — [N] phase agents assigned." (substitute the total number of rows in the Phase Agent Assignments table — phases plus subprocesses — for [N])
