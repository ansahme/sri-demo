# Sub-Skill: Tier-Level Documents

Given `<ARTIFACTS_DIR>` holding the selected tier's phase docs, write the tier-level documents:
the implementation roadmap, metrics, manual steps inventory, updated participants & data
objects, and review questions. This file is tier-agnostic by construction — every document below
is derived from whichever phase docs are present in `<ARTIFACTS_DIR>`, never from the tier's
name, so the same steps apply whichever tier produced them.

## Your Assignment

You were dispatched with the values below, resolved by the caller before this file is read —
substitute each literally wherever it appears:
- `ARTIFACTS_DIR` — the iteration's artifacts directory, holding this run's phase docs and its
  already-written `00-holistic-assessment.md`
- `AS_IS_DIR` — the discovery output directory
- `TIER` — the resolved tier keyword (unused in any path here — see the contract above)

## Important: do not delegate, write directly

Every document below is **stitching, not analysis** — the phase agents already did the analysis
in Phase 2. Your job is composition only.

- **Do NOT spawn `Agent` subagents to write these files.**
- Use the `Write` tool directly, in this conversation.

## AI: Read Inputs

Read all `<ARTIFACTS_DIR>/process-*.md` and `<ARTIFACTS_DIR>/edge-*.md` files, plus
`<ARTIFACTS_DIR>/00-holistic-assessment.md`, `data/transformation-bootstrap.md`,
`<AS_IS_DIR>/as-is-process.md`, `<AS_IS_DIR>/participants-and-systems.md`, and
`<AS_IS_DIR>/data-objects.md`.

## AI: Write Implementation Roadmap and Metrics

The assistant turn that produces these two documents must be a **single response containing two
`Write` tool_use blocks in parallel** — one for `implementation-roadmap.md`, one for
`metrics.md`. Both are independent of each other; once you have the inputs above, emit the two
Writes together.

Write `<ARTIFACTS_DIR>/implementation-roadmap.md` using the `Write` tool:

```markdown
# [Process Name] — Implementation Roadmap
Generated: [date]

*Wave ordering prioritizes changes that most directly advance the primary optimization criteria.*

## Wave 1: High Value, Low Effort
*Simple ServiceTask conversions and data-transfer automation. Target: implement within 1–2 sprints.*

| Phase | Step | Change | API / System | Estimated Effort | Value |
|-------|------|--------|-------------|-----------------|-------|

## Wave 2: Medium Effort
*DMN tables, AI ServiceTasks with confidence routing. Target: implement within 1 quarter.*

| Phase | Step | Change | Dependency | Estimated Effort | Value |
|-------|------|--------|-----------|-----------------|-------|

## Wave 3: Complex / Speculative
*Structural phase changes, new integration endpoints. Evaluate feasibility before committing.*

| Phase | Step | Change | Prerequisite | Estimated Effort | Value |
|-------|------|--------|-------------|-----------------|-------|

## Dependencies

[Which Wave 2 items require Wave 1 items first. Which Wave 3 items depend on Wave 2.]

## What NOT to Automate

| Step | Phase | Reason |
|------|-------|--------|
[All steps marked [RETAINED] with "hard constraint" rationale]
```

For basic totals, read the Summary block at the top of each phase file (no need to re-read every step):
- Eliminated = `Recommended ServiceTask` + `Recommended BusinessRuleTask` + `Recommended AI ServiceTask` + `Removed` (from Summary block)
- Retained = `Retained UserTask` (from Summary block)
- New = `New steps added` (from Summary block)
- As-Is UserTasks = Eliminated + Retained + Removed (back-calculate from totals)

For Reduced Scope specifically (the Summary block cannot provide this): scan the full step entries in each phase file. Count `[RETAINED]` steps whose Rationale or Optimized step description explicitly mentions AI pre-fill or confidence routing reducing scope.

Write `<ARTIFACTS_DIR>/metrics.md` using the `Write` tool:

```markdown
# [Process Name] — Optimization Metrics
Generated: [date] | [N] phases analyzed

## Task Count Changes
| Phase | As-Is UserTasks | Eliminated | Reduced Scope | Retained | Net |
|-------|----------------|------------|---------------|----------|-----|
| [phase filename] | N | N | N | N | N |
| **Total** | N | N | N | N | N |

Eliminated = step replaced by ServiceTask, BusinessRuleTask, or removed entirely.
Reduced = step retained as UserTask but scope cut by ≥50% via AI pre-fill or confidence routing.
Retained = step requires human judgment, legal authority, or commercial decision.

## Happy Path Comparison
| Stage | As-Is human actions | To-Be human actions | Change |
|-------|--------------------|--------------------|--------|
| [phase] | N | N | −N (−N%) |
| **Total** | N | N | −N (−N%) |

## New Automation Nodes
| Type | Count | Key examples |
|------|-------|-------------|
| ServiceTask (converted from UserTask) | N | [step 1, step 2, ...] |
| ServiceTask (new — fills integration gap) | N | [step 1, ...] |
| BusinessRuleTask / DMN | N | [step 1, ...] |
| AI ServiceTask | N | [step 1, ...] |

## Estimated Time Savings *(estimates — adjust with actual volumes)*
| Role | Current time/case | Optimized time/case | Annual savings (N cases/yr) |
|------|------------------|---------------------|-----------------------------|
| [role] | [Nh] *(estimated)* | [Nh] *(estimated)* | [Nh] *(estimated)* |

## Waiting Time Reductions
| Step | Current wait | Optimized wait | Bottleneck removed |
|------|-------------|----------------|-------------------|

## Data Quality Improvements
| Problem | Root cause | Fix applied |
|---------|-----------|------------|

## SLA Observability
Steps that become Camunda boundary timer events (currently untracked):
| Step | Phase | Timer | Escalation action |
|------|-------|-------|------------------|
```

## EXEC: Write Manual Steps Inventory

Scan all `<ARTIFACTS_DIR>/process-NN-*.md` files for any step marked `[RETAINED]
UserTask` or `[UserTask]`. Write `<ARTIFACTS_DIR>/manual-steps.md`:

```markdown
# Manual Steps Inventory
*All steps requiring a human actor in the transformed process*

| ID | Phase | Step Name | Actor | Why It Stays Human |
|----|-------|-----------|-------|-------------------|
| [step identifier] | [phase filename] | [step name] | [actor/role] | [rationale: legal / commercial authority / judgment / org policy] |
```

## EXEC: Write Updated Participants & Data Objects

Copy `<AS_IS_DIR>/participants-and-systems.md` to `<ARTIFACTS_DIR>/participants-and-systems.md`,
adding a "New Service Workers" section listing each ServiceTask worker introduced by
`[CHANGED]`/`[NEW]` recommendations (read from `<ARTIFACTS_DIR>/process-NN-*.md`
before any markers are stripped at generation time), each DMN decision engine for BusinessRuleTask
recommendations, and each AI model endpoint for AI ServiceTask recommendations.

Copy `<AS_IS_DIR>/data-objects.md` to `<ARTIFACTS_DIR>/data-objects.md`, adding process
variables that were manual inputs and are now auto-populated by ServiceTasks, plus new process
variables introduced by automated steps.

## AI: Write Review Questions

Read all `<ARTIFACTS_DIR>/process-NN-*.md` files, `<ARTIFACTS_DIR>/00-holistic-assessment.md`,
and `data/transformation-bootstrap.md`'s `## Optimization Context` section — look for:
- `[CHANGED]` steps where the API is listed as available but the specific operation was assumed, not confirmed in the original discovery
- `[CHANGED]` steps with AI ServiceTask where confidence thresholds may need organizational validation
- `[REMOVED]` steps — each removal should receive explicit approval before the clean to-be is generated
- `[NEW]` steps that introduce process logic not present in the original as-is process
- Items in `00-holistic-assessment.md`'s "Key Risks" section
- Items in "Elimination Opportunities" that require significant integration investment
- APIs in `## Optimization Context` where only partial operations were confirmed (API listed but operations field is vague)
- Its Hard Constraints list — is it complete? Are there steps marked `[CHANGED]` that should have been hard constraints?

Write `<ARTIFACTS_DIR>/review-questions.yaml` using the `Write` tool. This YAML document is the
**questions store** — the source of truth for this phase's questions. Markdown, spreadsheet and
Camunda Form views of it are projections, generated on request by their own skills; do **not** write
any of them here.

**An existing store's answered questions survive.** A seeded iteration carries the reviewed
iteration's store forward, and the fold-in step has already written this cycle's answers into it.
Read it before writing: carry every question that still applies across with its answer intact, drop
only those this tier's analysis has made moot, and add the new ones. Writing the store fresh would
re-ask what a reviewer has already answered, which reads to them as the answer having been lost.

Follow this exact format:

```yaml
schema: 1
kind: review
process: [Process Name]
generated: [YYYY-MM-DD]
sections:
  - title: "Section 1: Automation Assumptions to Validate"
    questions:
      - id: q1
        text: |-
          [specific question — e.g., "Does the Salesforce REST API support bulk contact status update in a single API call?"]
        confidence: |-
          Low — [which step file and step number assumed this, and why it is uncertain]
        impact: |-
          High | Medium | Low — [which transformation step depends on this being true]
        proposed: |-
          [a one-line best-inference answer based on the transformation data above]
        answer: ""
        status: open
  - title: "Section 2: API Availability to Confirm"
    questions:
      - id: qN
        text: |-
          [specific question — e.g., "Does your ERP expose a write API for order status updates?"]
        confidence: |-
          Low — [why availability is uncertain — not listed in participants-and-systems.md, or only read access confirmed]
        impact: |-
          High | Medium | Low — [which ServiceTask recommendation depends on this]
        proposed: |-
          [a one-line best-inference answer based on the transformation data above]
        answer: ""
        status: open
  - title: "Section 3: Constraints to Verify"
    questions:
      - id: qN
        text: |-
          [specific question — e.g., "Should contract countersigning remain a UserTask when the counterparty is an established trusted entity?"]
        confidence: |-
          Low — [why this constraint boundary is uncertain — is it legal, policy, or preference?]
        impact: |-
          High | Medium | Low — [whether this step stays as UserTask or gets automated]
        proposed: |-
          [a one-line best-inference answer based on the transformation data above]
        answer: ""
        status: open
  - title: "Section 4: Proposed Changes to Approve or Reject"
    questions:
      - id: qN
        text: |-
          [specific question — e.g., "Phase 3 'Manual Data Entry' is proposed for full elimination. Approved?"]
        confidence: |-
          Low — [the key assumption that makes this change possible — name it explicitly]
        impact: |-
          High | Medium | Low — [what reverts to manual if this is rejected]
        proposed: |-
          [a one-line best-inference answer based on the transformation data above]
        answer: ""
        status: open
```

**Format rules that are not style preferences** — each closes a real defect, so follow them exactly:

- **Every QUESTION-level prose value is a literal block scalar (`|-`)**, including a single-line
  one — `text`, `confidence`, `impact`, `proposed`, `answer`, `updated`. A bare
  YAML scalar is *typed*: an answer of `no` reads back as boolean `false` to a YAML 1.1 parser, and
  `1.0`, `08` and `12:30` come back as numbers. A literal block is a string whatever it contains.
  The document-level `process` and `generated` are single-line labels rather than prose, so they
  stay plain scalars — as the template above shows.
- **`answer: ""` for an unanswered question**, and `status: open`. An empty string has no block form.
- **`id` is `q` + a 1-based number with no leading zero**, numbered sequentially across all sections
  (`q1`, `q2`, `q3` … `qN` — do **not** restart at 1 per section). It is the stable key every
  projection joins on.
- **Continuation lines of a block scalar are indented to the same column as the first**, and no line
  carries trailing whitespace.
- `id` and `status` stay bare — they are constrained vocabularies, not free text. `status` is a
  closed set: `open` | `partially_answered` | `answered`, and anything else is rejected when the
  store is read. A settling date is not part of it — that goes in `updated` (`YYYY-MM-DD`, and a
  block scalar like every other value, because a bare date reads back as a timestamp).

**Fill in `proposed` for every question.** It is a real one-line best-inference answer based on the
transformation data you just read (changed/removed/new markers, hard constraints, API confirmations)
— the reviewer sees it pre-populated in the UI textarea and can edit or accept it. Never leave a
bracketed placeholder in the file; omit the field entirely rather than writing a non-answer into it.

Rules:
- Only generate questions where there is actual uncertainty in the analysis (unconfirmed API operation, assumed availability, removal needing explicit approval, constraint boundary unclear)
- Each question must name the specific source file and step number
- Keep all four sections even if one has no questions — write it with an empty `questions: []` list rather than dropping it, so the section numbering stays stable across cycles
- Prioritize questions where a wrong assumption would cause significant manual rework during BPMN implementation
- Do NOT generate speculative questions — only surface what is evidenced in the transformation files

### EXEC: Then validate what you wrote

Hand-authored YAML is the one writer in the system that does not go through the store's own
serializer, so canonicalise and validate it in one step:

```bash
node ".github/skills/process-os-process-transformation/scripts/questions-yaml.cjs" format "<ARTIFACTS_DIR>/review-questions.yaml"
```

Exit `0` → valid, and rewritten into canonical form (a value written bare becomes a block scalar).
Exit `4` → the document parses but does not match the schema; every problem is listed by path.
Exit `5` → the YAML itself is broken and the message names the line. Do not go on until it exits `0`.

Skip this whole step (and the store) if `node ".github/skills/process-os-process-transformation/scripts/read-run-config.cjs" skip-review`
prints `true` — in that case update `data/progress.json` phase → `"review-ready"` directly,
instead of the `"transformation-synthesis-complete"` phase
[synthesis.md](references/synthesis.md) writes once this file returns control to it.

Exit 2 → hard error: report stderr and stop; it means the reader failed, not that the key is unset.

Output:
```
Transformation review questions written to <ARTIFACTS_DIR>/review-questions.yaml

Found: [N] questions ([N1] automation assumptions, [N2] API availability, [N3] constraints, [N4] proposed changes)

Next step: answer the questions, then run:
  /process-os-process-transformation

Answer directly in the .yaml (fill each `answer:` as a `|-` block), or take a copy in
another format and fold it back when it comes home:
  /process-os-questions-md-export    → a .md, applied back by /process-os-md-response-application
  /process-os-questions-xlsx-export  → a .xlsx, applied back by /process-os-xlsx-response-application
```
