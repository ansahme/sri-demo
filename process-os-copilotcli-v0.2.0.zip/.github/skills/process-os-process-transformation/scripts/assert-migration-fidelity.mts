#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Completion-gate check for the `migration` tier.
//
// It compares the two sides of the migration hop, matched by filename stem:
//
//   DISCOVERY side      the completed discovery iteration's artifacts/*.md — the frozen as-is record
//   TRANSFORMATION side <artifacts-dir>/*.bpmn — this run's generated output, in the same
//                       transformation iteration's artifacts/ that holds the seeded phase docs
//
// Usage: node scripts/assert-migration-fidelity.mts --artifacts <dir> [--discovery <dir>]
//   --artifacts  transformation-side dir, required, no default. A run's artifacts/ live under
//                process-transformation/iteration-<N>/, one of potentially several iterations —
//                defaulting to a guessed one is how this gate ends up asserting against the wrong
//                pass, so the caller must always resolve and pass it explicitly.
//   --discovery  discovery-side doc dir       (default: the last completed process-discovery
//                iteration's artifacts/, via iteration-dir.cjs; falls back to the
//                bare `process-discovery` name when no completed iteration exists)
//
// This does NOT compare step names or step counts between the discovery-side markdown and the
// transformation-side BPMN, and no future version should. Markdown -> BPMN is an interpretive
// transformation: the generator appends system suffixes ("Get client profile" -> "Get client
// profile (ClientVault)"), rewords ("Confirm KYC analyst assignment + Conflict-of-Interest
// declaration" -> "Confirm analyst assignment + COI declaration"), and derives elements from
// prose with no task heading at all ("Patch case status to PENDING_DOCUMENTS", from a phase
// doc's "Phase 1 End" section). On a representative intake phase that is four task-token
// headings against five activities. A name- or count-matching gate would fail on nearly
// every real run and be deleted rather than fixed.
//
// Process fidelity is guaranteed by CONSTRUCTION instead: the transformation side is generated
// from a byte-identical copy of the discovery side (references/migration-seed.md verifies the
// copy), so there is no transformation step in which the process could drift.
//
// What IS deterministic across the two sides, and what this asserts:
//   1. File coverage  — every discovery-side as-is doc has a transformation-side .bpmn of the
//                       same stem.
//   2. Executable out — at least one transformation-side .bpmn carries a
//                       `zeebe:taskDefinition` or template binding, or a `zeebe:calledElement`
//                       in a process marked `isExecutable="true"`.
//
// The discovery-side allowlist mirrors process-os-bpmn-generation's own ("List process files"),
// so whatever that skill generates from is exactly what this gate demands an output for.
// Discovery metadata docs (00-index.md, gap-analysis.md, ...) simply do not match.
//
// Exit codes: 0 pass, 1 violation, 2 usage/IO error (including a missing --artifacts).
import { existsSync, readFileSync, readdirSync } from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
const { currentIteration } = require(path.join(__dirname, 'iteration-dir.cjs'));

// Discovery-side docs that must each produce a transformation-side BPMN.
const AS_IS_FILE_RE = /^(?:process-\d+-.*|edge-.*|subprocess-.*)\.md$/;
// A landscape diagram: never required, and never counted as evidence of executability.
const OVERVIEW = '00-overview.bpmn';
// A task definition or a template binding proves a .bpmn came out of `automatable` mode. A
// `zeebe:calledElement` does not on its own: `strategic` keeps it as the structural link from a
// call activity to the process it calls. It counts only in a process marked isExecutable="true".
const ZEEBE_EXEC_RE = /<zeebe:taskDefinition\b|modelerTemplate=/;
// The opening tag must not be self-closing, or an empty process would swallow the next one's body.
const PROCESS_BLOCK_RE = /<bpmn:process\b([^>]*?)(?<!\/)>([\s\S]*?)<\/bpmn:process>/g;
const EXECUTABLE_ATTR_RE = /\bisExecutable\s*=\s*(?:"true"|'true')/;

function carriesExecution(xml: string): boolean {
  if (ZEEBE_EXEC_RE.test(xml)) return true;
  for (const match of xml.matchAll(PROCESS_BLOCK_RE)) {
    const attrs = match[1] ?? '';
    const body = match[2] ?? '';
    if (EXECUTABLE_ATTR_RE.test(attrs) && /<zeebe:calledElement\b/.test(body)) return true;
  }
  return false;
}

function fail(msg: string): void {
  process.stderr.write(msg + '\n');
}

function argOf(argv: string[], flag: string, dflt: string): string {
  const i = argv.indexOf(flag);
  const next = i >= 0 ? argv[i + 1] : undefined;
  return next ?? dflt;
}

// Unlike argOf, returns undefined rather than a default when the flag is absent or has no
// value — for a flag a missing default would silently guess wrong for, so the caller must
// distinguish "not given" from "given".
function requiredArgOf(argv: string[], flag: string): string | undefined {
  const i = argv.indexOf(flag);
  return i >= 0 ? argv[i + 1] : undefined;
}

// The last completed process-discovery iteration's artifacts/ — falls back to the bare
// `process-discovery` name when no completed iteration exists, so a project with no discovery
// output yet still gets the same "cannot read"/"no as-is docs" diagnosis, rather than a
// different one.
function defaultDiscoveryDir(): string {
  const entry = currentIteration('process-discovery', { complete: true });
  return entry ? entry.artifacts : 'process-discovery';
}

function main(argv: string[]): number {
  const cwd = process.cwd();
  const artifactsArg = requiredArgOf(argv, '--artifacts');
  if (artifactsArg === undefined) {
    fail('usage: assert-migration-fidelity.mts --artifacts <dir> [--discovery <dir>]');
    return 2;
  }
  const artifactsDir = path.resolve(cwd, artifactsArg);
  const discoveryDir = path.resolve(cwd, argOf(argv, '--discovery', defaultDiscoveryDir()));

  let discoveryDocs: string[];
  try {
    discoveryDocs = readdirSync(discoveryDir)
      .filter((n) => AS_IS_FILE_RE.test(n))
      .sort();
  } catch {
    fail(`cannot read the discovery side: ${discoveryDir}`);
    return 2;
  }
  if (discoveryDocs.length === 0) {
    fail(`no as-is phase docs found on the discovery side: ${discoveryDir}`);
    return 2;
  }

  let violations = 0;
  let executable = 0;

  for (const docName of discoveryDocs) {
    const stem = docName.replace(/\.md$/, '');
    const bpmnPath = path.join(artifactsDir, `${stem}.bpmn`);
    if (!existsSync(bpmnPath)) {
      fail(
        `COVERAGE — discovery doc ${docName} has no transformation-side BPMN at ` +
          path.relative(cwd, bpmnPath),
      );
      violations++;
      continue;
    }
    // An as-is doc can never be named `00-overview`, so anything counted here is a real
    // process file rather than the landscape diagram.
    if (path.basename(bpmnPath) !== OVERVIEW && carriesExecution(readFileSync(bpmnPath, 'utf8'))) {
      executable++;
    }
  }

  if (violations > 0) {
    fail(
      `\n${violations} coverage violation(s) between the discovery side and the transformation\n` +
        'side. Every as-is phase doc must produce a BPMN — a missing one means the migration\n' +
        'tier dropped part of the discovered process. Re-dispatch Phase 3 for this tier.',
    );
    return 1;
  }

  if (executable === 0) {
    fail(
      'EXECUTABLE — no BPMN on the transformation side carries a task definition, template binding, or executable call-activity link.\n\n' +
        'The migration tier exists to make the as-is process executable. This output looks\n' +
        'like `strategic` mode. Re-run Phase 3 with --bpmn-mode automatable.',
    );
    return 1;
  }

  process.stdout.write(
    `Migration output covers ${discoveryDocs.length} discovery doc(s) with transformation-side BPMN; ` +
      `${executable} carry execution markers.\n`,
  );
  return 0;
}

process.exit(main(process.argv.slice(2)));
