#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';
// Flattens one iteration's verdicts JSON into that iteration's artifacts directory as
// `process-NN-*.md` / `edge-*.md` / `subprocess-*.md` phase docs, then asserts the docs actually
// landed. Runs the deterministic flattener (tier-verdicts-to-phase-docs.cjs) once
// against `--dir <artifacts-dir>` — this script adds only the post-condition the flatten step is
// gated on.
//
// Usage: node scripts/flatten-tier-phase-docs.cjs <artifacts-dir>
//
// Called from references/ai-challenge-phase.md's flatten step, which passes the iteration's
// artifacts directory as the sole positional.
//
// The flattener is spawned with process.execPath and an absolute path resolved from __dirname:
// it sits next to this file in a bundled skill but is nowhere near the project root, which is
// what a spawned child's cwd is.
//
// Exit codes:
//   0  the flattener wrote at least one phase doc into <artifacts-dir>.
//   1  the flattener ran (any exit) but <artifacts-dir> ended up with no phase doc.
//   2  usage error — <artifacts-dir> is missing. The flattener's own usage/IO errors (also 2)
//      pass through unchanged from below, told apart by the message prefix: this wrapper's own
//      usage error carries no "FLATTEN" prefix at all, since it never reached a flatten attempt.
//   5  the flattener could not be started at all (a spawn that never launched is not a pass).
//      Distinct from usage error 2: this is the OS failing to launch the child, not the child
//      rejecting its input.
// Any other non-zero flattener exit (in particular its completeness gate, 3) is propagated
// unchanged rather than collapsed, so it stays distinguishable from this wrapper's own codes.
//
// The one flattener code NOT treated as a failure is its exit 1, which that script documents as
// an orphan-reference *warning* — a verdicts entry naming a phase_file or pattern that does not
// exist, with every phase doc still written correctly. Aborting the whole challenge phase on it
// would turn a self-documented warning into a hard stop precisely in the unattended runs this
// wrapper is meant to keep moving. It is surfaced on stdout and the post-condition below still
// has to pass.
//
// Stream contract — machine-readable output goes to stdout only: nothing reaches this
// process's stderr on a success path. The flattener holds to the same rule and puts its own
// success-path `warning:` lines on ITS stdout, so on a pass they arrive here in `result.stdout`
// already. The streams are still captured rather than inherited, and a pass replays whatever did
// land on the child's stderr onto OUR stdout anyway: inheriting would let any such write escape
// through this process's stderr, where PowerShell 5.1 promotes any native-command stderr output to
// a NativeCommandError and a bash `2>&1` capture folds it into the value — which would undo the
// exit-code split above for a warning the flattener never meant as a failure. On a failure path
// both streams are replayed as they came, since a failure's diagnosis belongs on stderr.
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

// Source import of a shared sibling; the bundler rewrites it to a local sibling path when it
// copies the flattener into this skill's scripts/ dir.
const FLATTENER = path.join(__dirname, 'tier-verdicts-to-phase-docs.cjs');
// The shapes tier-verdicts-to-phase-docs.cjs writes, mirroring the `process-discovery/` basenames
// it reads — kept identical to that script's AS_IS_FILE_RE, since a doc it wrote must be a doc
// this gate recognizes. An iteration legitimately has no edge/subprocess docs, so any one of these
// is enough — requiring all three would false-fail a plain process-only tier.
const PHASE_DOC_RE = /^(process-\d\d-.+|edge-.+|subprocess-.+)\.md$/;

const EXIT = { OK: 0, FAILED: 1, USAGE: 2, DID_NOT_RUN: 5 };

function hasPhaseDocs(dir) {
  if (!fs.existsSync(dir)) return false;
  return fs.readdirSync(dir).some((f) => PHASE_DOC_RE.test(f));
}

// Returns { ok: true, notes, stdout, stderr } or { ok: false, code, message, stdout, stderr }.
// `notes` are this wrapper's own success-path diagnostics, which main() writes to stdout. The
// child's captured streams travel with the result rather than being written here, so main() alone
// decides which of them lands on which stream. `run` and `flattener` are injectable so the tests
// can drive the failure branches without a real flatten.
function flattenArtifacts(dir, { cwd = process.cwd(), flattener = FLATTENER, run = spawnSync } = {}) {
  const label = path.basename(flattener);
  // maxBuffer raised well above the flattener's real output (a summary line plus per-entry
  // warnings): an overrun surfaces as an ENOBUFS error with a null status, i.e. indistinguishable
  // from the "did not run" branch below, on a flatten that in fact ran fine.
  const result = run(process.execPath, [flattener, '--dir', dir], {
    cwd,
    encoding: 'utf8',
    maxBuffer: 32 * 1024 * 1024,
  });
  const stdout = typeof result.stdout === 'string' ? result.stdout : '';
  const stderr = typeof result.stderr === 'string' ? result.stderr : '';
  if (result.error || result.status === null) {
    const why = result.error ? result.error.message : 'no exit status';
    return {
      ok: false,
      code: EXIT.DID_NOT_RUN,
      message: `FLATTEN DID NOT RUN — could not run ${label} for ${dir}: ${why}`,
      stdout,
      stderr,
    };
  }
  const notes = [];
  if (result.status === 1) {
    // Non-fatal by the flattener's own contract: orphan references warned about, phase docs
    // written. Report it, then fall through to the post-condition.
    notes.push(
      `FLATTEN WARNING — ${label} exited 1 for ${dir} (orphan verdicts references; see its ` +
      'warnings above). Phase docs were still written.'
    );
  } else if (result.status !== 0) {
    // Propagate the flattener's own code — 3 is its completeness gate, and a caller that sees a
    // flat 1 cannot tell that case from any other flatten failure.
    return {
      ok: false,
      code: result.status,
      message: `FLATTEN FAILED — ${label} exited ${result.status} for ${dir}`,
      stdout,
      stderr,
    };
  }
  // The flattener can exit 0 having written nothing (e.g. no as-is docs to mirror), and the
  // phase docs are what Phase 7 and the fold-in phase read — so the exit code alone is not the
  // post-condition.
  const absDir = path.resolve(cwd, dir);
  if (!hasPhaseDocs(absDir)) {
    return {
      ok: false,
      code: EXIT.FAILED,
      message: `FLATTEN FAILED — no phase docs written for ${dir}`,
      stdout,
      stderr,
    };
  }
  return { ok: true, notes, stdout, stderr };
}

// `flatten`, `out` and `err` are injectable so the tests can assert the stream routing on a child
// that writes to stderr and still passes. The real flattener no longer does — it holds to the same
// stdout-only contract — which is exactly why the routing needs a test of its own: nothing
// end-to-end reaches this branch any more, and it is the last line of defence if a future change
// puts something back on the child's stderr.
function main(argv, { flatten = flattenArtifacts, out = process.stdout, err = process.stderr } = {}) {
  const positionals = argv.filter((a) => !a.startsWith('-'));
  const dir = positionals[0];
  if (!dir) {
    err.write('usage: flatten-tier-phase-docs.cjs <artifacts-dir>\n');
    return EXIT.USAGE;
  }
  const result = flatten(dir);
  if (result.stdout) out.write(result.stdout);
  if (!result.ok) {
    // Failure: the child's own diagnosis and ours both belong on stderr.
    if (result.stderr) err.write(result.stderr);
    err.write(result.message + '\n');
    return result.code;
  }
  // Pass: anything the child did put on stderr is part of the result, so it goes to stdout with
  // everything else — see the stream contract in the header.
  if (result.stderr) out.write(result.stderr);
  for (const note of result.notes) out.write(note + '\n');
  out.write(`Phase docs flattened for: ${dir}\n`);
  return EXIT.OK;
}

if (require.main === module) process.exit(main(process.argv.slice(2)));

module.exports = { flattenArtifacts, hasPhaseDocs, main, FLATTENER, PHASE_DOC_RE, EXIT };
