#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Seeds the `migration` tier: a byte-identical copy of process-discovery's as-is phase docs,
// each carrying a provenance header, into the transformation iteration's artifacts/.
//
// The tier's contract: the implementation of steps may change; the process may not. This script
// enforces the "may not" half. It never edits a step, reorders one, or drops one — it copies, and
// `--verify-only` re-reads every copy to prove the body below the provenance header is still
// byte-for-byte the source. That byte-identical guarantee — not a comparison of step names or
// counts between the as-is markdown and the later-generated BPMN — is what proves the tier's
// fidelity: process-os-bpmn-generation reads these copies, so a byte-identical copy means its
// output is exactly what it would have produced from the as-is docs themselves. There is no
// transformation step in which the process could drift.
//
// Usage:
//   node "scripts/seed-migration.cjs" --as-is <dir> --out <artifacts-dir> [--verify-only]
//
// Default mode seeds: it refuses to run if <artifacts-dir> already holds a matching doc, so a
// re-entry never silently overwrites the folded-in edits accumulated since the last seed.
// `--verify-only` instead re-checks an existing seed without writing anything, which is why it
// does not carry the same clobber refusal — a seed that already exists is exactly what it expects
// to find.
//
// Exit codes:
//   0  seeded (or, under --verify-only, verified). The doc count is on stdout.
//   2  usage error (bad or missing flags), or --as-is is not a readable directory.
//   3  --as-is holds no doc matching ALLOWLIST_RE.
//   4  default mode only: --out already holds a doc matching ALLOWLIST_RE — refusing to clobber.
//      Nothing is copied.
//   5  --verify-only only: a copy in --out differs from its --as-is source below the provenance
//      header, or is missing entirely. Each offending file is named on stderr.

const fs = require('node:fs');
const path = require('node:path');

const EXIT = { OK: 0, USAGE: 2, NO_DOCS: 3, CLOBBER: 4, DRIFT: 5 };

// Mirrors process-os-bpmn-generation's own allowlist, so whatever it will generate from is
// exactly what gets seeded here. `subprocess-*.md` is included deliberately: no ProcessOS writer
// emits that class today, but a hand-authored subprocess doc is a legitimate input.
const ALLOWLIST_RE = /^(?:process-\d+-.*|edge-.*|subprocess-.*)\.md$/;

// Matches one or more leading HTML-comment lines followed by a blank line — the shape
// `provenanceHeader` writes. Stripping it recovers exactly the as-is body underneath.
const HEADER_STRIP_RE = /^(?:<!--[^\n]*-->\n)+\n/;

const USAGE = 'usage: seed-migration.cjs --as-is <dir> --out <artifacts-dir> [--verify-only]\n';

/**
 * @param {string} message
 * @param {'UNREADABLE'|'NO_DOCS'|'CLOBBER'|'DRIFT'} code
 * @returns {Error} Tagged with one of {@link EXIT}'s non-OK, non-USAGE names.
 */
function taggedError(message, code) {
  const err = new Error(message);
  err.code = code;
  return err;
}

/**
 * @param {string} dir
 * @returns {string[]} Basenames directly under `dir` matching {@link ALLOWLIST_RE}, sorted.
 * @throws {Error} Propagated as-is when `dir` cannot be read (missing, not a directory, no
 *   permission) — the caller decides what that means for its own mode.
 */
function listAllowedDocs(dir) {
  return fs.readdirSync(dir).filter((name) => ALLOWLIST_RE.test(name)).sort();
}

/**
 * @param {string} asIsDir
 * @param {string} name
 * @returns {string} The three-line HTML-comment header this script inserts above the copied
 *   body, followed by a blank line.
 */
function provenanceHeader(asIsDir, name) {
  return (
    `<!-- migration-tier: lift-and-shift copy of ${path.join(asIsDir, name)} -->\n` +
    '<!-- No transformation verdicts apply. Steps are unchanged from the as-is; only their -->\n' +
    '<!-- implementation (connector template, job type, form) is decided downstream.       -->\n\n'
  );
}

/**
 * @param {string} asIsDir
 * @returns {string[]} The as-is docs to seed, sorted.
 * @throws {Error} Tagged `UNREADABLE` when `asIsDir` cannot be read; tagged `NO_DOCS` when it
 *   holds no doc matching {@link ALLOWLIST_RE}.
 */
function requireAsIsDocs(asIsDir) {
  let docs;
  try {
    docs = listAllowedDocs(asIsDir);
  } catch {
    throw taggedError(`cannot read --as-is: ${asIsDir}`, 'UNREADABLE');
  }
  if (docs.length === 0) {
    throw taggedError(`no as-is phase docs in ${asIsDir}`, 'NO_DOCS');
  }
  return docs;
}

/**
 * Copies every as-is doc into `outDir` with its provenance header.
 *
 * @param {string} asIsDir
 * @param {string} outDir
 * @returns {{count: number}}
 * @throws {Error} Tagged `UNREADABLE`, `NO_DOCS` (see {@link requireAsIsDocs}), or `CLOBBER` when
 *   `outDir` already holds a doc matching {@link ALLOWLIST_RE}.
 */
function seedMigration(asIsDir, outDir) {
  const asIsDocs = requireAsIsDocs(asIsDir);

  let outDocs;
  try {
    outDocs = listAllowedDocs(outDir);
  } catch {
    outDocs = [];
  }
  if (outDocs.length > 0) {
    throw taggedError(`${outDir} already holds ${outDocs.length} phase doc(s)`, 'CLOBBER');
  }

  fs.mkdirSync(outDir, { recursive: true });
  for (const name of asIsDocs) {
    const body = fs.readFileSync(path.join(asIsDir, name), 'utf8');
    fs.writeFileSync(path.join(outDir, name), provenanceHeader(asIsDir, name) + body);
  }
  return { count: asIsDocs.length };
}

/**
 * Re-reads every as-is doc's copy in `outDir` and confirms the body below the provenance header
 * is still byte-for-byte the source. Writes nothing.
 *
 * @param {string} asIsDir
 * @param {string} outDir
 * @returns {{count: number}}
 * @throws {Error} Tagged `UNREADABLE`, `NO_DOCS` (see {@link requireAsIsDocs}), or `DRIFT` — the
 *   error's `badFiles` array names every doc that differs from its source or is missing from
 *   `outDir` entirely.
 */
function verifySeed(asIsDir, outDir) {
  const asIsDocs = requireAsIsDocs(asIsDir);

  const badFiles = [];
  for (const name of asIsDocs) {
    const orig = fs.readFileSync(path.join(asIsDir, name), 'utf8');
    let copy;
    try {
      copy = fs.readFileSync(path.join(outDir, name), 'utf8');
    } catch {
      badFiles.push(name);
      continue;
    }
    if (copy.replace(HEADER_STRIP_RE, '') !== orig) badFiles.push(name);
  }
  if (badFiles.length > 0) {
    const err = taggedError(`${badFiles.length} doc(s) failed verification`, 'DRIFT');
    err.badFiles = badFiles;
    throw err;
  }
  return { count: asIsDocs.length };
}

/**
 * @param {string[]} argv
 * @returns {{asIs: string, out: string, verifyOnly: boolean}|null} `null` on any usage error: an
 *   unknown flag, a flag with no value, or a missing --as-is/--out.
 */
function parseArgs(argv) {
  let asIs;
  let out;
  let verifyOnly = false;
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--as-is' || arg === '--out') {
      const value = argv[i + 1];
      if (value === undefined) return null;
      if (arg === '--as-is') asIs = value;
      else out = value;
      i++;
    } else if (arg === '--verify-only') {
      verifyOnly = true;
    } else {
      return null;
    }
  }
  if (asIs === undefined || out === undefined) return null;
  return { asIs, out, verifyOnly };
}

/**
 * @param {string[]} argv `process.argv.slice(2)`.
 */
function main(argv) {
  const parsed = parseArgs(argv);
  if (parsed === null) {
    process.stderr.write(USAGE);
    process.exit(EXIT.USAGE);
  }
  const { asIs, out, verifyOnly } = parsed;

  let result;
  try {
    result = verifyOnly ? verifySeed(asIs, out) : seedMigration(asIs, out);
  } catch (err) {
    if (err.code === 'UNREADABLE') {
      process.stderr.write(`${err.message}\n`);
      process.exit(EXIT.USAGE);
    }
    if (err.code === 'NO_DOCS') {
      process.stderr.write(`${err.message}\n`);
      process.exit(EXIT.NO_DOCS);
    }
    if (err.code === 'CLOBBER') {
      process.stderr.write(`${err.message}\n`);
      process.exit(EXIT.CLOBBER);
    }
    if (err.code === 'DRIFT') {
      for (const name of err.badFiles) {
        process.stderr.write(`SEED DRIFT — ${name} differs from its source below the provenance header\n`);
      }
      process.stderr.write('\nThe migration tier copies the as-is verbatim. Re-copy without editing.\n');
      process.exit(EXIT.DRIFT);
    }
    throw err;
  }

  process.stdout.write(
    verifyOnly
      ? `verified ${result.count} doc(s) in ${out}\n`
      : `seeded ${result.count} doc(s) into ${out}\n`,
  );
  process.exit(EXIT.OK);
}

module.exports = { EXIT, ALLOWLIST_RE, seedMigration, verifySeed };

if (require.main === module) main(process.argv.slice(2));
