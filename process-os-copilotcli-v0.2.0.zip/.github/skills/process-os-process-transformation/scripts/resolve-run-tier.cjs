#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';
// Resolves the transformation tier a single run generates: exactly one of
// migration | incremental | radical | moonshot.
//
// Precedence: an explicit tier in the caller's `$ARGS` text wins over `run.config.yaml`'s
// `transformation-tier` key, which wins over an unattended-run fallback. There is no
// unconditional default the way `resolve-bpmn-mode.cjs` has `automatable`: an
// interactive run with no signal either way must stop and ask, because generating a
// tier nobody chose is not a safe guess the way "assume the executable BPMN mode" is.
// Only an unattended run — where nobody is available to answer a prompt — gets a
// fallback, and that fallback is `incremental`, the smallest tier that always applies.
//
// Contract: stdout is *only* the resolved tier, one bare token, exit 0 — it is
// interpolated straight into a `--tier <TIER>`-shaped call, so nothing else may share
// that stream. `--source` adds a note on stderr instead, prefixed `#` so that even a
// caller whose harness merges stdout and stderr can still extract TIER deterministically:
// exactly one line of the combined output is a bare tier token, and a `#` line is never
// it. Missing or unreadable run.config.yaml is not an error: it is read the same way
// `resolve-bpmn-mode.cjs` reads it, where absent/unparseable falls through rather than
// raising. The one exception is missing ProcessOS Node deps — see readRunConfig() below.
//
// Exit 4 exists here where `resolve-bpmn-mode.cjs` has no equivalent: that resolver
// silently falls through on an unrecognised `bpmn-mode` value because BOTH of its
// possible outcomes are always a mode. This resolver's "nothing recognised" outcome is
// not always a tier — it can mean "ask a human" (exit 3) — so a value that reads as an
// explicit tier request but names no real tier cannot be silently downgraded to "no
// tier given" without changing what the caller does next. Falling through a mistyped
// `--tier radcial` would generate a tier nobody asked for and report success; exiting 4
// instead tells the caller the request was understood but wrong, not absent.
const fs = require('node:fs');
const path = require('node:path');
// Source imports of shared siblings; the bundler rewrites these to local sibling
// requires when it copies the peers into this skill's scripts/ dir. read-run-config.cjs
// pulls in yaml.cjs and run-config-schema.cjs transitively, and the bundler's fixed
// point copies those too.
const yaml = require(path.join(__dirname, 'yaml.cjs'));
const { resolveKey } = require(path.join(__dirname, 'read-run-config.cjs'));

const TIERS = ['migration', 'incremental', 'radical', 'moonshot'];
const DEFAULT_TIER = 'incremental';
const RUN_CONFIG = 'run.config.yaml';

class InvalidTierError extends Error {
  constructor(value) {
    super(`"${value}" is not a transformation tier. Valid tiers: ${TIERS.join(', ')}`);
    this.code = 'INVALID_TIER';
  }
}

function tierFromArgs(argsText) {
  // `(?:^|\s)` is a left boundary, and the value alternation accepts a double-quoted,
  // single-quoted, or bare token — the same reasoning as resolve-bpmn-mode.cjs's
  // `--bpmn-mode` scan, copied verbatim for `--tier`.
  // Presence and value are matched separately, because they fail differently. A `--tier` with
  // nothing after it matches the presence test and not the value test, and folding that into "no
  // flag given" would let a malformed explicit request fall through to the config value or the
  // unattended default — generating a tier the caller never asked for while believing they had
  // named one.
  if (/(?:^|\s)--tier(?:$|[=\s])/i.test(argsText)) {
    const flag = argsText.match(/(?:^|\s)--tier[=\s]+(?:"([^"]*)"|'([^']*)'|(\S+))/i);
    const v = flag ? (flag[1] ?? flag[2] ?? flag[3]).toLowerCase() : '';
    if (TIERS.includes(v)) return v;
    // An explicit --tier request that names no real tier is a broken request, not an
    // absent one — see the file-level comment for why this differs from a bare word.
    throw new InvalidTierError(v);
  }
  // A bare keyword on whitespace boundaries. Deliberately no heuristic typo detection
  // here: a misspelling that is not behind --tier reads as "no tier given" and falls
  // through to run.config.yaml, which is the accepted cost of not guessing.
  const bare = argsText.match(new RegExp('(?:^|\\s)(' + TIERS.join('|') + ')(?=\\s|$)', 'i'));
  return bare ? bare[1].toLowerCase() : null;
}

// run.config.yaml — the structured source. Absent or unparseable is NOT an error: fall
// through to the unattended-mode fallback (or exit 3) rather than raise. A project can
// legitimately run process-os-process-transformation before it has a run.config.yaml.
//
// Missing Node deps are the deliberate exception, rethrown for main() to exit 2 on, for
// the same reason resolve-bpmn-mode.cjs rethrows it: DEPS_MISSING means the project is
// broken, not unconfigured, so we cannot tell whether run.config.yaml sets a tier.
// Silently falling through would ignore a configured value and generate a tier the
// user did not ask for.
function readRunConfig() {
  let txt;
  try {
    txt = fs.readFileSync(path.join(process.cwd(), RUN_CONFIG), 'utf8');
  } catch {
    return null;
  }
  try {
    return yaml.parse(txt) || {};
  } catch (e) {
    if (e.code === 'DEPS_MISSING') throw e;
    // The file is there and will not parse. read-run-config.cjs treats that as a hard error
    // rather than "everything is default", precisely so a broken project cannot look configured,
    // and falling through here would resolve a tier while ignoring one the file may well name.
    // Absent stays absent — that case returned above, before any parse.
    const err = new Error(
      RUN_CONFIG + ' exists but is not valid YAML: ' + e.message,
    );
    err.code = 'CONFIG_UNPARSEABLE';
    throw err;
  }
}

function tierFromConfig(obj) {
  // resolveKey, not resolveWithDefault: the latter consults RUN_DEFAULTS, where
  // `transformation-tier` has no entry by design (see run-config-schema.cjs's header).
  // Using resolveKey also keeps this resolver correct if someone later adds one.
  const found = resolveKey(obj, 'transformation-tier');
  if (found.status !== 'scalar') return null;
  const v = found.value.trim().toLowerCase();
  if (TIERS.includes(v)) return v;
  // A configured value that names no real tier is a broken project, not an
  // unconfigured one — exits 4 unconditionally, never falls through to the default.
  throw new InvalidTierError(v);
}

function isUnattended(obj) {
  const found = resolveKey(obj, 'mode');
  return found.status === 'scalar' && found.value.trim().toLowerCase() === 'unattended';
}

function resolve(argsText) {
  const fromArgs = tierFromArgs(argsText);
  if (fromArgs) return { tier: fromArgs, source: 'args' };

  const obj = readRunConfig();
  if (obj) {
    const fromConfig = tierFromConfig(obj);
    if (fromConfig) return { tier: fromConfig, source: RUN_CONFIG };
    if (isUnattended(obj)) return { tier: DEFAULT_TIER, source: 'default (unattended)' };
  }
  // Nothing resolved. An interactive run (or no run.config.yaml at all, which reads the
  // same as interactive — the safe assumption when nothing says otherwise) means the
  // caller must prompt rather than guess a tier.
  return null;
}

function main() {
  const argv = process.argv.slice(2);
  const withSource = argv.includes('--source');
  // Everything else is the caller's raw `$ARGS` text — accepted either as one quoted
  // string or as separate argv entries.
  const argsText = argv.filter((a) => a !== '--source').join(' ');
  let resolved;
  try {
    resolved = resolve(argsText);
  } catch (e) {
    if (e.code === 'DEPS_MISSING' || e.code === 'CONFIG_UNPARSEABLE') {
      // Nothing on stdout — a caller interpolating stdout into a `--tier <TIER>`-shaped
      // call must get an empty value and a non-zero exit, never a guessed tier.
      process.stderr.write(e.message + '\n');
      process.exit(2);
    }
    if (e.code === 'INVALID_TIER') {
      process.stderr.write(e.message + '\n');
      process.exit(4);
    }
    throw e;
  }
  if (!resolved) {
    // Nothing on stdout — the caller prompts.
    process.exit(3);
  }
  process.stdout.write(`${resolved.tier}\n`);
  if (withSource) process.stderr.write(`# tier source: ${resolved.source}\n`);
}

if (require.main === module) main();

module.exports = { TIERS, resolve };
