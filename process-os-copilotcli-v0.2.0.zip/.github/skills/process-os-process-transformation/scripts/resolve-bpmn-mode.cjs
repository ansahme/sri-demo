#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';
// Resolves the BPMN modeling mode this skill passes to `process-os-bpmn-generation`.
//
// `bpmn-mode` is a dedicated config key for this axis — distinct from `mode`, which
// carries the *interaction* value (`interactive`/`unattended`) and is never read here.
// The two sit side by side in run.config.yaml, which is exactly the adjacency the split
// was meant to make safe. With no explicit signal the default is `automatable`, because
// the transformation BPMN is executable input for `process-os-artifact-generation` (it
// reads zeebe:taskDefinition, modelerTemplate bindings and AI-Agent ad-hoc subprocesses
// out of these files) — all of which `strategic` strips.
//
// The `automatable` default lives HERE and deliberately NOT in run-config-schema.cjs's
// RUN_DEFAULTS. read-run-config.cjs serves schema defaults to every caller, so an entry
// there would hand `process-os-bpmn-generation` a mode too and make its "Specify a mode"
// hard error unreachable. Keeping the default in this resolver is what preserves that
// per-consumer asymmetry.
//
// Contract: stdout is *only* the resolved mode, one bare token, exit 0 — it is
// interpolated straight into `--bpmn-mode <MODE>`, so nothing else may share that
// stream. `--source` adds a note on stderr instead, prefixed `#` so that even a caller
// whose harness merges stdout and stderr can still extract MODE deterministically:
// exactly one line of the combined output is a bare `strategic`/`automatable` token,
// and a `#` line is never it. Missing or unreadable config files are not an error: this
// resolver always yields a usable mode. The one exception is missing ProcessOS Node
// deps — see modeFromRunConfig() below.
const fs = require('node:fs');
const path = require('node:path');
// Source imports of shared siblings; the bundler rewrites these to local sibling
// requires when it copies the peers into this skill's scripts/ dir. read-run-config.cjs
// pulls in yaml.cjs and run-config-schema.cjs transitively, and the bundler's fixed
// point copies those too.
const yaml = require(path.join(__dirname, 'yaml.cjs'));
const { resolveKey } = require(path.join(__dirname, 'read-run-config.cjs'));

const BPMN_MODES = ['strategic', 'automatable'];
const DEFAULT_MODE = 'automatable';
const RUN_CONFIG = 'run.config.yaml';
// Still a markdown file post-split: it carries `artifact-iteration:` and the threshold /
// hard-constraint keys, and a `bpmn-mode:` line there collides with nothing.
const MD_CONFIG = 'transformation.config.md';

function modeFromArgs(argsText) {
  // `(?:^|\s)` is a left boundary: `$ARGS` is verbatim user prose, and without it a
  // `--bpmn-mode` glued to a preceding token (`--dry-run--bpmn-mode`, a `…#--bpmn-mode=…`
  // URL fragment) matched as if it were the flag. The value alternation accepts a
  // double-quoted, single-quoted, or bare token — `$ARGS` is raw user prose, and
  // `--bpmn-mode "strategic"` / `--bpmn-mode='strategic'` are realistic inputs that a
  // bare `\S+` token would otherwise capture as `"strategic"` (quotes included) and
  // silently fail to match `BPMN_MODES`.
  const m = argsText.match(/(?:^|\s)--bpmn-mode[=\s]+(?:"([^"]*)"|'([^']*)'|(\S+))/i);
  if (!m) return null;
  const v = (m[1] ?? m[2] ?? m[3]).toLowerCase();
  return BPMN_MODES.includes(v) ? v : null;
}

// run.config.yaml — the structured source. Absent or unparseable is NOT an error: fall
// through to transformation.config.md and then the default. Both the AS-IS and
// pre-initialization paths legitimately run before any run.config.yaml exists.
//
// Missing Node deps are the deliberate exception, rethrown for main() to exit 2 on. It
// looks inconsistent with "always yields a usable mode", and is intentional:
// DEPS_MISSING means the project is broken, not unconfigured, so we cannot tell whether
// run.config.yaml sets `strategic`. Silently defaulting to `automatable` there would
// ignore a configured value and emit an executable diagram the user did not ask for.
function modeFromRunConfig() {
  let txt;
  try {
    txt = fs.readFileSync(path.join(process.cwd(), RUN_CONFIG), 'utf8');
  } catch {
    return null;
  }
  let obj;
  try {
    obj = yaml.parse(txt) || {};
  } catch (e) {
    if (e.code === 'DEPS_MISSING') throw e;
    return null;
  }
  // resolveKey, not resolveWithDefault: the latter consults RUN_DEFAULTS, where
  // `bpmn-mode` has no entry by design (see the header). Using resolveKey also keeps
  // this resolver correct if someone later adds one.
  const found = resolveKey(obj, 'bpmn-mode');
  if (found.status !== 'scalar') return null;
  const v = found.value.trim().toLowerCase();
  return BPMN_MODES.includes(v) ? v : null;
}

function modeFromMarkdownConfig(file) {
  let txt;
  try {
    txt = fs.readFileSync(path.join(process.cwd(), file), 'utf8');
  } catch {
    return null;
  }
  // First `bpmn-mode:` line only — a later one does not override an earlier, ignored value.
  const m = txt.match(/^bpmn-mode:[^\S\n]*(.*)$/m);
  const v = m ? m[1].trim().toLowerCase() : null;
  return BPMN_MODES.includes(v) ? v : null;
}

function resolve(argsText) {
  const fromArgs = modeFromArgs(argsText);
  if (fromArgs) return { mode: fromArgs, source: 'args' };
  const fromRunConfig = modeFromRunConfig();
  if (fromRunConfig) return { mode: fromRunConfig, source: RUN_CONFIG };
  const fromMd = modeFromMarkdownConfig(MD_CONFIG);
  if (fromMd) return { mode: fromMd, source: MD_CONFIG };
  return { mode: DEFAULT_MODE, source: 'default' };
}

function main() {
  const argv = process.argv.slice(2);
  const withSource = argv.includes('--source');
  // Everything else is the caller's raw `$ARGS` text — accepted either as one quoted
  // string or as separate argv entries.
  const argsText = argv.filter((a) => a !== '--source').join(' ');
  let resolved;
  try {
    resolved = resolve(argsText);
  } catch (e) {
    if (e.code === 'DEPS_MISSING') {
      // Nothing on stdout — a caller interpolating stdout into `--bpmn-mode <MODE>`
      // must get an empty value and a non-zero exit, never a guessed mode.
      process.stderr.write(e.message + '\n');
      process.exit(2);
    }
    throw e;
  }
  process.stdout.write(`${resolved.mode}\n`);
  if (withSource) process.stderr.write(`# mode source: ${resolved.source}\n`);
}

if (require.main === module) main();

module.exports = { resolve };
