#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Print the tier the last completed transformation iteration generated.
//
// Usage: node "scripts/previous-tier.cjs"        (takes no arguments)
//
// Stdout is one bare token, and every one of the three is an answer rather than
// an error:
//
//   <tier>    the tier that iteration's manifest records
//   none      no completed iteration exists — this run is the first
//   unknown   a completed iteration exists but its tier cannot be established:
//             no manifest, or one that is present and unreadable
//
// The caller seeds a new iteration from the last completed one only when it is
// about to generate the same tier. `none` seeds nothing because there is nothing
// to seed from, and `unknown` counts as a different tier: a base whose scenario
// cannot be established is not one to build a different scenario on.
//
// Folding the whole enquiry into one token keeps that decision from being spelled
// as two commands and four exit codes at the call site, where the branch a caller
// gets wrong is the one that carries a previous tier's documents into this one.
//
// Exit codes:
//   0  answered; the token is on stdout.
//   2  usage error (an argument was passed).
//   5  the phase directory exists but could not be read.

const path = require('path');

const { currentIteration } = require(path.join(__dirname, 'iteration-dir.cjs'));
const { readManifest } = require(path.join(__dirname, 'iteration-manifest.cjs'));

const EXIT = { OK: 0, USAGE: 2, IO: 5 };

const PHASE_DIR = 'process-transformation';

const NONE = 'none';
const UNKNOWN = 'unknown';

const USAGE = 'Usage:\n  previous-tier.cjs          (takes no arguments)\n';

/**
 * Resolve the last completed iteration's tier.
 *
 * @returns {string} The tier, `none`, or `unknown`.
 * @throws {Error} Tagged `.code = 'IO'` when the phase directory cannot be read.
 */
function previousTier() {
  let entry;
  try {
    entry = currentIteration(PHASE_DIR, { complete: true });
  } catch (err) {
    const wrapped = new Error(`cannot read ${PHASE_DIR}: ${err && err.message}`);
    wrapped.code = 'IO';
    throw wrapped;
  }
  if (entry === null) return NONE;

  // readManifest signals a missing or malformed manifest with its own `.code`; both
  // mean the same thing here — the scenario behind those documents is not established.
  let manifest;
  try {
    manifest = readManifest(path.join(...entry.artifacts.split('/')));
  } catch (err) {
    if (err && (err.code === 'MISSING' || err.code === 'INVALID')) return UNKNOWN;
    // Anything else — a missing YAML dependency, an unreadable directory — is a failure to
    // run, not an answer about the tier.
    const wrapped = new Error(`cannot read ${entry.artifacts}: ${err && err.message}`);
    wrapped.code = 'IO';
    throw wrapped;
  }
  const tier = manifest && manifest.tier;
  return typeof tier === 'string' && tier.trim() !== '' ? tier.trim() : UNKNOWN;
}

/**
 * @param {string[]} argv
 */
function main(argv) {
  if (argv.length > 0) {
    process.stderr.write(`previous-tier.cjs: takes no arguments\n\n${USAGE}`);
    process.exit(EXIT.USAGE);
  }
  let answer;
  try {
    answer = previousTier();
  } catch (err) {
    process.stderr.write(`${err.message}\n`);
    process.exit(EXIT.IO);
  }
  process.stdout.write(`${answer}\n`);
  process.exit(EXIT.OK);
}

module.exports = { EXIT, NONE, UNKNOWN, PHASE_DIR, previousTier };

if (require.main === module) main(process.argv.slice(2));
