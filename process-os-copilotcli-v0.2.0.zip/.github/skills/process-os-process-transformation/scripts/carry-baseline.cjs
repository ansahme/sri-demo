#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Carries the baseline analysis forward from the last completed `process-transformation`
// iteration into a new one, so Phase 1's reuse gate does not have to re-run the baseline every
// time a later run targets a different tier.
//
// Copies exactly one file: `00-holistic-assessment.md`. That is the whole of the baseline that
// survives a change of tier — the rest of Phase 1's tier-independent output
// (`data/transformation-bootstrap.md`, `data/transformation-criteria.md`) lives outside any
// iteration and is reused in place.
//
// **The phase docs are deliberately not carried.** They belong to the source iteration's own tier:
// on a `radical` or `moonshot` run Phase 2's flatten wrote them from that tier's verdicts, and on
// an `incremental` run the phase agents did. Copying them forward would make the next run analyse
// the previous scenario, and would close an iteration whose `iteration.yaml` names one tier while
// its documents describe another. A `radical` or `moonshot` run gets its own phase docs from the
// flatten, which reads `verdicts.json` and the as-is docs rather than anything carried.
//
// Never the whole directory either — `iteration-dir.cjs open --seed` already does that, and it
// would bring the previous tier's `.bpmn` files, `PROCESSES.md` and `annotations.md` as well.
// Naming the one file this script copies is what keeps all of that impossible, rather than
// something a caller has to remember to clean up afterwards.
//
// **A file already in the target is kept, never overwritten.** An iteration seeded from the one
// it follows already holds that assessment, and the fold-in step runs before this one — so the
// copy in the target can carry a reviewer's correction that the committed copy in the source does
// not. Overwriting would discard it silently, in the same run that applied it. The source is the
// fallback for an iteration that opened empty, which is the case this script exists for.
//
// Usage:
//   node "scripts/carry-baseline.cjs" <target-artifacts-dir>
//
// Exit codes:
//   0  the target holds the baseline. What was copied and what was already there is on stdout.
//   2  usage error (not exactly one argument), or an IO failure copying the files.
//   3  no completed process-transformation iteration to carry from, or its artifacts/ has no
//      00-holistic-assessment.md — its baseline analysis never completed, so there is nothing to
//      carry forward from it. Nothing on stdout.

const fs = require('node:fs');
const path = require('node:path');
// Sibling import spelled so the bundler's dependency-closure grep sees a literal
// <shared dir>/<file> path. This file already lives outside that directory, so the require
// round-trips via '../../..' to reach it in source, and once copied as a peer into this skill's
// scripts/ dir the bundler rewrites it to a local sibling require.
const { currentIteration } = require(path.join(__dirname, 'iteration-dir.cjs'));

const EXIT = { OK: 0, USAGE: 2, NO_BASELINE: 3 };
const PHASE = 'process-transformation';
const ASSESSMENT = '00-holistic-assessment.md';

const USAGE = 'usage: carry-baseline.cjs <target-artifacts-dir>\n';

/**
 * @param {string} message
 * @returns {Error} Tagged `NO_BASELINE`.
 */
function noBaselineError(message) {
  const err = new Error(message);
  err.code = 'NO_BASELINE';
  return err;
}

/**
 * @param {string} artifactsDir
 * @returns {string[]} The named set this script carries, as basenames directly under
 *   `artifactsDir` — `00-holistic-assessment.md` and nothing else. Empty when `artifactsDir`
 *   does not exist, or when it exists without the assessment.
 */
function namedSetFiles(artifactsDir) {
  let names;
  try {
    names = fs.readdirSync(artifactsDir);
  } catch (err) {
    if (err.code === 'ENOENT') return [];
    throw err;
  }
  return names.filter((name) => name === ASSESSMENT);
}

/**
 * @param {string} targetArtifactsDir
 * @returns {{count: number, source: string}} How many files were copied, and the source
 *   `artifacts/` they came from.
 * @throws {Error} Tagged `NO_BASELINE` when there is no completed `process-transformation`
 *   iteration, or its `artifacts/` carries no `00-holistic-assessment.md`; untagged for an
 *   unexpected filesystem error while copying.
 */
function carryBaseline(targetArtifactsDir) {
  const source = currentIteration(PHASE, { complete: true });
  if (source === null) {
    throw noBaselineError(`no completed ${PHASE} iteration to carry a baseline from`);
  }
  const names = namedSetFiles(source.artifacts);
  if (!names.includes(ASSESSMENT)) {
    throw noBaselineError(
      `${source.artifacts} has no ${ASSESSMENT} — its baseline analysis never completed`,
    );
  }
  fs.mkdirSync(targetArtifactsDir, { recursive: true });
  const copied = [];
  const kept = [];
  for (const name of names) {
    const target = path.join(targetArtifactsDir, name);
    if (fs.existsSync(target)) {
      kept.push(name);
      continue;
    }
    fs.copyFileSync(path.join(source.artifacts, name), target);
    copied.push(name);
  }
  return { copied, kept, count: copied.length, source: source.artifacts };
}

/**
 * @param {string[]} argv `process.argv.slice(2)`.
 */
function main(argv) {
  if (argv.length !== 1) {
    process.stderr.write(USAGE);
    process.exit(EXIT.USAGE);
  }
  const [targetArtifactsDir] = argv;

  let result;
  try {
    result = carryBaseline(targetArtifactsDir);
  } catch (err) {
    if (err.code === 'NO_BASELINE') {
      process.stderr.write(`${err.message}\n`);
      process.exit(EXIT.NO_BASELINE);
    }
    process.stderr.write(`${err.message}\n`);
    process.exit(EXIT.USAGE);
  }
  const keptNote = result.kept.length
    ? `, kept ${result.kept.length} already in place (${result.kept.join(', ')})`
    : '';
  process.stdout.write(`copied ${result.copied.length} file(s) from ${result.source}${keptNote}\n`);
  process.exit(EXIT.OK);
}

module.exports = { EXIT, ASSESSMENT, carryBaseline };

if (require.main === module) main(process.argv.slice(2));
