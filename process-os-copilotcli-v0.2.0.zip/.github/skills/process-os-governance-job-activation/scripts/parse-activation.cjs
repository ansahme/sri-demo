/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

/**
 * Parse the JSON emitted by `c8ctl --json activate jobs`.
 *
 * c8ctl uses PascalCase field names: Key, Process Instance, Custom Headers,
 * Variables. Returns a typed result so callers (CLI and tests) share one path.
 */
function parseActivationOutput(raw) {
  let arr;
  try { arr = JSON.parse(raw || '[]'); }
  catch (e) { return { type: 'parse_error', message: e.message }; }

  const job = (Array.isArray(arr) && arr[0] && arr[0].Key) ? arr[0] : null;
  if (!job) return { type: 'no_job' };

  const vars = (job.Variables && typeof job.Variables === 'object') ? job.Variables : {};
  return {
    type: 'job',
    key: job.Key,
    processInstance: job['Process Instance'],
    customHeaders: job['Custom Headers'] || {},
    vars,
  };
}

/**
 * Classify one fetched job variable for stdout reporting.
 *
 * One classifier serves every fetched variable, because they share one activation
 * contract: `--fetchVariable` filters server-side over a comma-separated name list, so a
 * job that does not set a named variable returns it absent rather than erroring.
 *
 * `absent` therefore cannot distinguish a variable the instance does not carry from one
 * the request never asked for — which is why the request's own shape is guarded, in
 * activation-command.test.cjs.
 *
 * A FEEL expression evaluating to null serializes the variable as `null`, so a
 * referenced-but-unset value arrives present-and-null instead of missing. `empty` covers
 * that alongside a `''` or `{}` payload; only `set` means a consumer has something to act
 * on.
 *
 * @param {Record<string, unknown>|undefined|null} vars Fetched job variables.
 * @param {string} name Variable name, e.g. 'skillInput'.
 * @returns {'absent'|'empty'|'set'}
 */
function variableStatus(vars, name) {
  if (!vars || !Object.prototype.hasOwnProperty.call(vars, name)) return 'absent';
  const v = vars[name];
  if (v === null || v === undefined || v === '') return 'empty';
  if (typeof v === 'object' && Object.keys(v).length === 0) return 'empty';
  return 'set';
}

/**
 * The reportable value of a short scalar variable, or null when there is none.
 *
 * `skillMode` is the one variable safe to print by value — a single word the agent appends
 * to the skill invocation. A non-primitive is not a usable skill argument, so it reports as
 * no value and the skill runs its default path, the same outcome as an absent mode.
 *
 * @param {Record<string, unknown>|undefined|null} vars Fetched job variables.
 * @param {string} name Variable name, e.g. 'skillMode'.
 * @returns {string|null}
 */
function scalarVariableValue(vars, name) {
  if (variableStatus(vars, name) !== 'set') return null;
  const v = vars[name];
  return typeof v === 'object' ? null : String(v);
}

/**
 * The stdout report for an activated job.
 *
 * `skillInput` and `runConfig` are reported as status only. Either can hold a large
 * free-text context, and a shell-copied blob carrying apostrophes, quotes or newlines does
 * not survive the round trip — their content reaches the next phase through
 * `.camunda/job-variables.json` instead. Custom headers are small scalars and print by
 * value.
 *
 * @param {{key: unknown, processInstance: unknown, customHeaders: Record<string, unknown>, vars: Record<string, unknown>}} result
 * @returns {string[]} One report line each, without trailing newlines.
 */
function reportLines(result) {
  const lines = [
    'jobKey: ' + result.key,
    'processInstanceKey: ' + result.processInstance,
  ];
  for (const [k, v] of Object.entries(result.customHeaders || {})) {
    lines.push('customHeaders.' + k + ': ' + v);
  }
  lines.push('skillInput: ' + variableStatus(result.vars, 'skillInput'));
  lines.push('runConfig: ' + variableStatus(result.vars, 'runConfig'));
  const mode = scalarVariableValue(result.vars, 'skillMode');
  lines.push('skillMode: ' + (mode === null ? 'absent' : mode));
  return lines;
}

/**
 * Run `c8ctl <args>` and return its stdout, or why it did not succeed.
 *
 * c8ctl runs from here rather than being piped in: a Windows PowerShell 5.1 pipe between two
 * native commands re-encodes the text with `$OutputEncoding` (ASCII by default), which turns
 * every non-ASCII character in a variable — `ø`, `ä`, `é` — into `?`. The capture is unbounded,
 * as the pipe was: spawnSync's 1 MiB default would kill c8ctl on a large `skillInput` after it
 * may already have locked the job, and report that as a c8ctl that did not run.
 *
 * @param {string[]} args Arguments for c8ctl.
 * @param {function} run Runner in runShellCli's shape; injected by tests.
 * @returns {{stdout: string}|{error: string}}
 */
function runActivation(args, run) {
  const r = run('c8ctl', args, { stdio: ['ignore', 'pipe', 'pipe'], encoding: 'utf8', maxBuffer: Infinity });
  if (!r.launched) return { error: 'c8ctl did not run: ' + ((r.error && r.error.message) || 'unknown reason') };
  if (r.status !== 0) return { error: 'c8ctl exited ' + r.status + ': ' + (String(r.stderr || '').trim() || '(no output)') };
  return { stdout: String(r.stdout || '') };
}

module.exports = { parseActivationOutput, variableStatus, scalarVariableValue, reportLines, runActivation };

if (require.main === module) {
  const fs = require('fs');
  const path = require('path');
  const { stripBOM } = require(path.join(__dirname, 'strip-bom.cjs'));
  const { runShellCli } = require(path.join(__dirname, 'resolve-node-cli.cjs'));
  const args = process.argv.slice(2);
  let raw;
  if (args.length > 0) {
    const activation = runActivation(args, runShellCli);
    if (activation.error) {
      process.stdout.write('ACTIVATION_ERROR: ' + activation.error + '\n');
      process.exit(2);
    }
    raw = stripBOM(activation.stdout);
  } else {
    raw = stripBOM(fs.readFileSync(0, 'utf8'));
  }
  const result = parseActivationOutput(raw);

  if (result.type === 'parse_error') {
    process.stdout.write('ACTIVATION_PARSE_ERROR: ' + result.message + '\n');
    process.exit(1);
  }
  if (result.type === 'no_job') {
    process.stdout.write('NO_JOB\n');
    process.exit(0);
  }

  fs.mkdirSync('.camunda', { recursive: true });
  fs.writeFileSync('.camunda/job-variables.json', JSON.stringify(result.vars) + '\n');
  process.stdout.write(reportLines(result).join('\n') + '\n');
}
