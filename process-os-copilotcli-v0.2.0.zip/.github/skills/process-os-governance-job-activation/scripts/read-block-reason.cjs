#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Read the `message` field out of a job-block marker (e.g.
// `.camunda/init-block.json`), sanitized for safe use as a double-quoted shell
// argument, portably.
//
// Replaces a hand-rolled `node -e "try { JSON.parse(...) } catch {} ..."`
// one-liner: parsing a JSON file with a fallback, then stripping shell-unsafe
// characters and truncating, is more than a line of logic once written out, and
// logic that size belongs in a file with tests rather than an inline `node -e`.
//
// Usage:
//   node "read-block-reason.cjs" [--default <text>] [<path>]
//
//   <path>       marker file to read. Defaults to `.camunda/init-block.json`.
//   --default    fallback text when the file is absent, or present and valid
//                but has no `message` field. Defaults to
//                'blocked (no reason given)'.
//
// Prints the sanitized reason to stdout with no trailing newline, so a caller
// can substitute it directly into a double-quoted argument.
//
// Exit codes:
//   0  a reason (or the fallback) was printed
//   1  the marker exists but could not be read (EACCES, EISDIR, I/O) or is not
//      valid JSON. Nothing is printed to stdout. Distinct from 0 on purpose:
//      "no marker" and "a corrupt marker" are different states, and the caller
//      substitutes this value into a Zeebe job-failure message an operator
//      reads in Operate — falling back there would invent a cause for an
//      incident whose real cause is unknown
//   2  usage error
//
// A marker that parses but carries no `message` stays exit 0: you still know
// the job blocked, and the fallback ('blocked (no reason given)') says exactly
// that. Invalid JSON is different — nothing in the file can be trusted.

const fs = require('fs');
const { stripBOM } = require('./strip-bom.cjs');

const EXIT = { OK: 0, UNREADABLE: 1, USAGE: 2 };

const DEFAULT_PATH = '.camunda/init-block.json';
const DEFAULT_FALLBACK = 'blocked (no reason given)';

// Strips CR, LF, double quote, backslash, backtick, and `$` — the characters that
// break out of a double-quoted shell argument on bash or PowerShell 5.1 alike (see
// the identically-spelled class in process-os-governance-job-activation's
// SKILL.md, which this script replaces). The backslash matters on its own: a reason
// ending in one escapes the wrapper's own closing quote in bash, so
// `--message "…failed\"` swallows the rest of the command line.
const UNSAFE_CHARS = /[\r\n\x22\x5c\x60\x24]/g;

/**
 * Read and sanitize the block reason.
 *
 * @param {string} filePath Marker file to read.
 * @param {string} fallback Text to use when the marker is absent or carries no message.
 * @returns {string} Sanitized reason, truncated to 300 characters.
 * @throws {Error} When the marker exists but cannot be read or is not valid JSON.
 *   Carries an `exitCode` of {@link EXIT.UNREADABLE}.
 */
function readReason(filePath, fallback) {
  let raw;
  try {
    raw = fs.readFileSync(filePath, 'utf8');
  } catch (err) {
    // Absence is the legitimate "no block recorded" state the fallback exists
    // for; anything else (EACCES, EISDIR, an I/O error) is a marker that is
    // there and unreadable, which the fallback would disguise as absent.
    if (err.code !== 'ENOENT') {
      throw Object.assign(new Error(`could not read ${filePath}: ${err.message}`), {
        exitCode: EXIT.UNREADABLE,
      });
    }
    return sanitize(fallback);
  }
  let parsed;
  try {
    // The marker is written with `fs.writeFileSync`, so a BOM should never
    // appear — but now that malformed JSON is a hard error rather than a silent
    // fallback, a stray BOM would turn a perfectly good marker into a failure.
    parsed = JSON.parse(stripBOM(raw));
  } catch (err) {
    throw Object.assign(new Error(`could not parse ${filePath}: ${err.message}`), {
      exitCode: EXIT.UNREADABLE,
    });
  }
  const hasMessage = parsed && typeof parsed.message === 'string' && parsed.message !== '';
  return sanitize(hasMessage ? parsed.message : fallback);
}

/**
 * @param {string} text
 * @returns {string} `text` with shell-unsafe characters replaced, truncated to 300 characters.
 */
function sanitize(text) {
  return text.replace(UNSAFE_CHARS, ' ').slice(0, 300);
}

/**
 * @param {string[]} argv Arguments after the script name.
 * @returns {{filePath: string, fallback: string} | null} Parsed args, or null on usage error.
 */
function parseArgs(argv) {
  let fallback = DEFAULT_FALLBACK;
  const rest = [];
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--default') {
      fallback = argv[i + 1];
      i++;
    } else if (argv[i].startsWith('--')) {
      // A mistyped flag would otherwise become the path and this would go read a
      // file named `--help`, printing the fallback as though the marker were absent.
      return null;
    } else {
      rest.push(argv[i]);
    }
  }
  if (rest.length > 1 || fallback === undefined) {
    return null;
  }
  return { filePath: rest[0] || DEFAULT_PATH, fallback };
}

module.exports = { readReason, parseArgs, EXIT, DEFAULT_PATH, DEFAULT_FALLBACK };

if (require.main === module) {
  const args = parseArgs(process.argv.slice(2));
  if (!args) {
    process.stderr.write('usage: read-block-reason.cjs [--default <text>] [<path>]\n');
    process.exit(EXIT.USAGE);
  }
  let reason;
  try {
    reason = readReason(args.filePath, args.fallback);
  } catch (err) {
    // Nothing on stdout: the caller substitutes it into a quoted argument, so a
    // partial or explanatory value here would be read as the reason itself.
    process.stderr.write(`read-block-reason.cjs: ${err.message}\n`);
    process.exit(err.exitCode || EXIT.UNREADABLE);
  }
  process.stdout.write(reason);
}
