#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';
// Read and update .camunda/governance.json.
//
// Usage:
//   governance-state.cjs read [--project-root <path>]
//   governance-state.cjs set key=value ... [--project-root <path>]
//
// read  → writes JSON object of all keys to stdout (null for absent/null values); exits 0
// set   → merges given keys into the file (creates if absent); exits 0
//         exits 1 if a key is unknown

const fs = require('fs');
const path = require('path');

const EM_DASH = '—';

const VALID_KEYS = [
  'cluster',
  'c8ctl-profile',
  'project-name',
  'instance-key',
  'active-job-key',
  'active-job-skill',
  'active-job-started-at',
  'active-job-blocked',
];
const VALID_KEY_SET = new Set(VALID_KEYS);

const DEFAULTS = Object.fromEntries(VALID_KEYS.map(k => [k, null]));

function parseArgs(argv) {
  const args = argv.slice(2);
  const result = { command: null, projectRoot: null, pairs: {}, unparsed: [] };
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--project-root') {
      result.projectRoot = args[++i];
      if (result.projectRoot === undefined) {
        process.stderr.write('error: --project-root requires a path argument\n');
        process.exit(1);
      }
    } else if (!result.command) {
      result.command = args[i];
    } else {
      const eq = args[i].indexOf('=');
      if (eq !== -1) {
        result.pairs[args[i].slice(0, eq)] = args[i].slice(eq + 1);
      } else {
        result.unparsed.push(args[i]);
      }
    }
  }
  return result;
}

function findProjectRoot(start) {
  let dir = path.resolve(start);
  while (true) {
    if (fs.existsSync(path.join(dir, '.camunda'))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) return null;
    dir = parent;
  }
}

function readGovernanceFile(govPath) {
  if (!fs.existsSync(govPath)) return { ...DEFAULTS };
  return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(govPath, 'utf8')) };
}

function writeGovernanceFile(govPath, data) {
  fs.mkdirSync(path.dirname(govPath), { recursive: true });
  fs.writeFileSync(govPath, JSON.stringify(data, null, 2) + '\n', 'utf8');
}

const { command, projectRoot: rootArg, pairs, unparsed } = parseArgs(process.argv);

const root = rootArg ? path.resolve(rootArg) : findProjectRoot(process.cwd());
if (!root) {
  process.stderr.write('no process project found (.camunda/ not found in this directory or any parent)\n');
  process.exit(2);
}

const govPath = path.join(root, '.camunda', 'governance.json');

if (command === 'read') {
  if (unparsed.length > 0) {
    process.stderr.write(`Unexpected argument(s): ${unparsed.join(', ')}\n`);
    process.exit(1);
  }
  const data = readGovernanceFile(govPath);
  process.stdout.write(JSON.stringify(data, null, 2) + '\n');
  process.exit(0);
}

if (command === 'set') {
  if (unparsed.length > 0) {
    process.stderr.write(`Unexpected argument(s): ${unparsed.join(', ')}\nArguments to set must be in key=value form.\n`);
    process.exit(1);
  }
  const unknown = Object.keys(pairs).filter(k => !VALID_KEY_SET.has(k));
  if (unknown.length > 0) {
    process.stderr.write(`Unknown key(s): ${unknown.join(', ')}\nValid keys: ${VALID_KEYS.join(', ')}\n`);
    process.exit(1);
  }
  const data = readGovernanceFile(govPath);
  for (const [k, v] of Object.entries(pairs)) {
    data[k] = v === EM_DASH ? null : v;
  }
  writeGovernanceFile(govPath, data);
  process.exit(0);
}

process.stderr.write(
  'Usage:\n' +
  '  governance-state.cjs read [--project-root <path>]\n' +
  '  governance-state.cjs set key=value ... [--project-root <path>]\n'
);
process.exit(1);
