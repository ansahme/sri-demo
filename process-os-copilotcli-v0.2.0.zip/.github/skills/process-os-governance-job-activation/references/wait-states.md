# Handle no job activated

**Never complete an open user task yourself, even in `unattended` mode.** Governance user tasks are
SME sign-offs and decisions; `unattended` only covers a skill's own review gates. Report the task and
stop, unless the user has explicitly instructed you to complete that specific task.

The most likely cause is a user task waiting for human input. Check whether the cluster supports
wait-state search (available since Camunda 8.10):

```bash
node ".github/skills/process-os-governance-job-activation/scripts/c8ctl-wait-state-support.cjs" [--profile <c8ctl-profile>]
```

Omit `--profile` if `c8ctl-profile` is null. Apply the same rule to all commands below.

The script calls c8ctl itself and prints one word on stdout:

| stdout | Exit | Meaning |
|---|---|---|
| `SUPPORTED` | 0 | cluster >= 8.10 — query wait states directly |
| `UNSUPPORTED` | 1 | cluster < 8.10 — use the fallback below |
| `UNDETERMINED` | 2 | the check did not complete (c8ctl missing, cluster unreachable, bad response) — the reason is on stderr |

On `UNDETERMINED`, do not guess a version. Report the stderr reason to the user, then use the
`UNSUPPORTED` fallback, which works against every version — and say explicitly that the capability
check could not be completed.

**On `SUPPORTED`**, query wait states directly:

```bash
c8ctl --json search ws --processInstanceKey <instance-key> [--profile <c8ctl-profile>]
```

Parse the returned array. Each entry has an `elementType` and `elementId`. Describe what the process
is waiting for:
- `USER_TASK` — name the task and say it must be completed in Tasklist.
- `TIMER` — describe the timer and when it will fire.
- `MESSAGE_CATCH` / `SIGNAL` — name the expected message or signal.

**On `UNSUPPORTED` (or `UNDETERMINED`)**, use a three-step fallback:

1. Fetch the instance snapshot:
   ```bash
   c8ctl --json get pi <instance-key> [--profile <c8ctl-profile>]
   ```
   If the instance state is `COMPLETED`, report completion and stop.

2. Otherwise, check for open user tasks:
   ```bash
   c8ctl --json search user-tasks --processInstanceKey <instance-key> --state CREATED [--profile <c8ctl-profile>]
   ```
   If tasks are found, describe each by name and indicate it must be completed in Tasklist.

3. If no user tasks were found, check for active incidents:
   ```bash
   c8ctl --json search incidents --processInstanceKey <instance-key> --state ACTIVE [--profile <c8ctl-profile>]
   ```
   Describe any incidents found (error type, message, element).

Print a clear, human-readable explanation. This is not an error — stop cleanly.
