---
name: process-os-governance-job-activation
description: >-
  Activate the next pending job of a governance process instance. Pulls the next
  process-os-job job from Zeebe, fetches the fixed-name `skillInput`,
  `runConfig` and `skillMode` variables, writes activation state to
  .camunda/governance.json, merges the job's run-configuration overrides into
  run.config.yaml, and invokes the corresponding job skill. The Zeebe job is not
  completed — the user reviews output and runs
  process-os-governance-job-completion explicitly.
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
Read [the c8ctl guide](references/c8ctl.md) for the full c8ctl command reference.

Parse skill arguments:
- First positional argument → `<jobType>` (default: `process-os-job`)
- `--projectName <name>` → CLI override for the project-name prefix; when omitted, fall back to
  `project-name` from governance state (Phase 0)
- `--profile <name>` → CLI override for the c8ctl profile; when omitted, fall back to
  `c8ctl-profile` from governance state (Phase 0)

---

## EXEC: Phase 0 — Read Governance State

Check whether `.camunda/governance.json` already exists:
```bash
node ".github/skills/process-os-governance-job-activation/scripts/path-exists.cjs" .camunda/governance.json
```

- If there is no governance state file:
  - Tell the user to run `/process-os-governance-start` first, then stop.
- Otherwise, read the state:
  ```bash
  node ".github/skills/process-os-governance-job-activation/scripts/governance-state.cjs" read
  ```
  Extract the following from the JSON output and use them throughout the skill:
  - `instance-key`
  - `active-job-key`
  - `active-job-skill`
  - `active-job-started-at`
  - `c8ctl-profile`
  - `project-name`

  Resolve the two CLI-overridable values used for the rest of this skill: the CLI-supplied
  `--projectName`/`--profile` wins when given; otherwise fall back to `project-name`/`c8ctl-profile`
  from state. Prepend the resolved project-name to `<jobType>` (`<projectName>_<jobType>`), skipping
  the prefix entirely when the resolved value is null. Use the resolved profile as `<name>` in every
  `--profile <name>` below, omitting the flag entirely when the resolved value is null.

---

## AI: Phase 1 — Guards

Check the extracted values and stop early if any guard fires:

**Guard A — No instance:**
If `instance-key` is null, print:

```
No governance process instance found.

Run /process-os-governance-start to start or attach to a process instance.
```

Stop.

**Guard B — Job already in progress:**
If `active-job-key` is non-null, print:

```
A job is already in progress: <active-job-skill>
  job key:  <active-job-key>
  started:  <active-job-started-at>

Complete it with /process-os-governance-job-completion before activating the next job.
```

Stop.

---

## EXEC: Phase 2 — Version Check

```bash
node ".github/skills/process-os-governance-job-activation/scripts/check-c8ctl-version.cjs" process-os-governance-job-activation
```

If the version check fails (non-zero exit), stop here — do not proceed.

---

## EXEC: Phase 3 — Activate Job

Always request `--customHeaders --fetchVariable skillInput,runConfig,skillMode`. Those three are the
fixed transport-variable names a governance service task's per-instance values ride on, and
`skillName` is the one custom header. Zeebe never evaluates a task header — a header written
`=someVariable` reaches the worker as that literal string — so a per-instance value has to be an
input mapping; `skillName` is a constant per task, so it stays a header.

This skill is skill-agnostic and knows nothing about any specific job skill's own variable naming
or shape. Each channel has exactly one consumer: `skillInput` is the job skill's domain payload,
`runConfig` is a set of `run.config.yaml` overrides this skill applies itself, and `skillMode` is
the argument appended to the invocation. `--fetchVariable` filters variables server-side, so a job
that sets none of them simply returns them absent (not an error) — this is what makes the
fixed-name fetch safe across every governance service task.

Because `skillInput` and `runConfig` can each hold a large free-text context, their **content must
not travel through stdout**. The script runs c8ctl itself with the arguments after its path (never
pipe c8ctl into it — a PowerShell pipe turns non-ASCII characters into `?`), writes variable
**content** to `.camunda/job-variables.json`, and prints each channel's status plus the small
scalars `customHeaders` and `skillMode`:

```bash
node .github/skills/process-os-governance-job-activation/scripts/parse-activation.cjs --json activate jobs <jobType> --maxJobsToActivate 1 --timeout 3600000 --worker process-os --customHeaders --fetchVariable skillInput,runConfig,skillMode [--profile <name>]
```

If stdout is exactly `NO_JOB`, go to Phase 4.

If stdout starts with `ACTIVATION_ERROR:` (c8ctl did not run or failed) or
`ACTIVATION_PARSE_ERROR:` (its response was not valid JSON), print the line verbatim and stop —
this **is** an error, not "no job".

Otherwise extract from stdout:
- `jobKey`
- `processInstanceKey`
- `customHeaders.skillName`
- `skillInput: <set|empty|absent>` — status only, never the value
- `runConfig: <set|empty|absent>` — status only, never the value
- `skillMode: <value|absent>` — a short scalar, printed by value

`skillMode: absent` covers an unmapped mode and a mapping that evaluated to `null` alike. Both
mean the invoked skill runs its default path, so treat them identically.

Variable **content** lives in `.camunda/job-variables.json`, read in Phases 7 and 8.

---

## AI: Phase 4 — Handle No Job

_Only when Phase 3's stdout was exactly `NO_JOB`._

Read [the wait-state reference](references/wait-states.md) and follow it.

---

## EXEC: Phase 5 — Wrong-Instance Guard

_Only when a job was returned._

Compare `processInstanceKey` from the activation output against `instance-key` from
governance.json.

If they differ:

1. Release the wrong job back to the pool by expiring its lock immediately:
   ```
   /process-os-governance-job-update <jobKey> --timeout 1 --profile <c8ctl-profile>
   ```
   Omit `--profile` if null.

   A timeout of 1 second releases the lock immediately, returning the job to the activatable pool
   without creating an incident.

2. Retry activation once by repeating Phase 3 (re-run the `node .github/skills/process-os-governance-job-activation/scripts/parse-activation.cjs --json activate jobs …` command
   with the same arguments).
3. If the retry returns `NO_JOB`, go to Phase 4 and stop.
4. Parse `jobKey`, `processInstanceKey`, `customHeaders.skillName`, `skillInput`, `runConfig` and
   `skillMode` from the new output.
5. If `processInstanceKey` still does not match `instance-key`, release this second wrong job the
   same way as the first (step 1) — otherwise it stays locked for up to the full activation timeout
   even though this skill is stopping and cannot use it:

   ```
   /process-os-governance-job-update <jobKey> --timeout 1 --profile <c8ctl-profile>
   ```
   Omit `--profile` if null.

   Then print:

   ```
   Wrong instance returned twice. Cannot safely activate.

   Expected instance key: <instance-key>
   Returned instance key: <processInstanceKey>

   Investigate manually — another process instance may be competing for the same job type.
   ```

   Stop.

---

## EXEC: Phase 6 — Write Activation State

Get the current timestamp:
```bash
node -e "process.stdout.write(new Date().toISOString())"
```

Write activation state to governance.json. Clear any stale `active-job-blocked` marker from a
previous blocked run — a fresh activation means the incident has moved on:
```bash
node ".github/skills/process-os-governance-job-activation/scripts/governance-state.cjs" set active-job-key=<jobKey> active-job-skill=<skillName> active-job-started-at=<ISO-8601-timestamp> active-job-blocked=—
```

---

## EXEC: Phase 7 — Apply Run Configuration

_Only when a job was returned._

**Stage the run-configuration overrides.** Write the fetched `runConfig` variable to
`.camunda/run-config-input.json` as `{ "runConfig": … }`. Read from
`.camunda/job-variables.json` (never from stdout), so values with quotes/newlines are handled
safely. Always write the file (empty object when `runConfig` is absent), for every `skillName`, so
the apply step below has one input shape and reports "nothing to apply" instead of being skipped
conditionally.

Phase 3 writes `.camunda/job-variables.json` unconditionally for every activated job, so a missing
or malformed file here means the activation bridge itself is broken — a different, worse state than
`runConfig` being legitimately absent from an otherwise-valid file. Let this step fail loudly
(non-zero exit, Node's own stack trace) rather than staging an empty object, which would apply no
configuration while reporting success:

```bash
node -e '
const fs = require("fs");
const vars = JSON.parse(fs.readFileSync(".camunda/job-variables.json", "utf8"));
const rc = (vars && typeof vars.runConfig === "object" && vars.runConfig) ? vars.runConfig : {};
fs.mkdirSync(".camunda", { recursive: true });
fs.writeFileSync(".camunda/run-config-input.json", JSON.stringify({ runConfig: rc }, null, 2) + "\n");
'
```

If this command fails, stop — do not proceed to the merge or to the invocation.

**Merge the overrides into `run.config.yaml`.** `runConfig`'s keys are run-configuration keys, and
a submitted governance form is a decision, so the keys it carries override whatever the file
already holds. Applying the same overrides twice leaves the file byte-identical, so a re-activated
job is safe:

```bash
node ".github/skills/process-os-governance-job-activation/scripts/apply-run-config.cjs" .camunda/run-config-input.json
```

The four exit codes this phase distinguishes:

| Exit | Constant | Meaning | Action |
|---|---|---|---|
| `0` | `EXIT.OK` | applied, or a no-op because nothing changed | continue |
| `3` | `EXIT.NOTHING_TO_APPLY` | the document carries no usable key — the routine case for a task that configures nothing | continue |
| `2` | `EXIT.USAGE` | usage error, or the project's Node dependencies are missing | fail the job, below |
| `4` | `EXIT.UNPARSEABLE` | `run.config.yaml` is present and does not parse; nothing was written | fail the job, below |

**Discard the staged configuration file.** `.camunda/run-config-input.json` is a one-shot artifact
of this single activation cycle — it is read once, by the merge above, and the next activation
writes it afresh. Delete it now, unconditionally, so nothing lingers in the workspace between
cycles:

```bash
node ".github/skills/process-os-governance-job-activation/scripts/remove-path.cjs" .camunda/run-config-input.json
```

**On exit `2` or `4`, fail the job and stop here.** Activation writes project configuration, so an
unwritten or half-applied `run.config.yaml` must never be followed by a skill run that reads it as
configured. Print the script's stderr verbatim for the user, then record the incident in
governance state and fail the Zeebe job so it is visible in Operate — the same handling a blocked
job skill gets in Phase 9.

Use the exit code's own fixed `<REASON>` below, so no arbitrary stderr text has to survive shell
quoting:

| Exit | `<REASON>` |
|---|---|
| `2` | `runConfig could not be applied: usage error or missing project Node dependencies (apply-run-config.cjs exit 2)` |
| `4` | `runConfig could not be applied: run.config.yaml is present but unparseable (apply-run-config.cjs exit 4)` |

Record the incident **before** failing the job — job-completion's own commit step runs inside the
call below, so the marker has to exist first or it is left uncommitted:

```bash
node ".github/skills/process-os-governance-job-activation/scripts/governance-state.cjs" set active-job-key=— active-job-skill=— active-job-blocked="<REASON>"
```

```
/process-os-governance-job-completion <jobKey> --fail --message "<REASON>" [--profile <c8ctl-profile>]
```

Omit `--profile` if null.

Then print and stop — do not invoke the job skill:

```
Job '<skillName>' BLOCKED — job <jobKey> failed: <REASON>

An incident has been raised on the process instance. Fix the reported run-configuration problem and let the job re-activate; do not run /process-os-governance-job-completion.
```

---

## AI: Phase 8 — Invoke Job Skill

**Stage scope input.** Transform the fetched `skillInput` into the job skill's deterministic,
non-interactive input file, `.camunda/job-input.json`. Read from `.camunda/job-variables.json`
(never from stdout), so free-text values with quotes/newlines are handled safely. Always write the
file (empty object when `skillInput` is absent), for every `skillName`, so a job skill that
relies on this file blocks loudly on incomplete input instead of prompting. A job skill that has
no use for `skillInput` simply never reads the file — its presence is harmless.

Phase 3 writes `.camunda/job-variables.json` unconditionally for every activated job, so a missing
or malformed file here means the activation bridge itself is broken — a different, worse state than
`skillInput` being legitimately absent from an otherwise-valid file. Let this step fail loudly
(non-zero exit, Node's own stack trace) rather than staging an empty object, which would let the
invoked job skill silently skip work or prompt instead of surfacing the real failure:

```bash
node -e '
const fs = require("fs");
const vars = JSON.parse(fs.readFileSync(".camunda/job-variables.json", "utf8"));
const si = (vars && typeof vars.skillInput === "object" && vars.skillInput) ? vars.skillInput : {};
fs.mkdirSync(".camunda", { recursive: true });
fs.writeFileSync(".camunda/job-input.json", JSON.stringify({ skillInput: si }, null, 2) + "\n");
'
```

If this command fails, stop — do not proceed to invoke the job skill.

**Discard the staged transport file.** `.camunda/job-variables.json` is a one-shot artifact of this
single activation cycle — its two readers are Phase 7 and the staging step above, and the next
activation overwrites it regardless. Delete it now, unconditionally, so nothing lingers in the
workspace between cycles:

```bash
node ".github/skills/process-os-governance-job-activation/scripts/remove-path.cjs" .camunda/job-variables.json
```

**Clear the block marker before invoking.** Remove any stale `.camunda/init-block.json` before the
invocation, for every `skillName`, so the post-invocation check is unambiguous:

```bash
node ".github/skills/process-os-governance-job-activation/scripts/remove-path.cjs" .camunda/init-block.json
```

Invoke the job skill by name. When the job carries a `skillMode` value, pass it as the skill
argument:
```
/<skillName> [<skillMode>]
```

The `skillName` value from `customHeaders.skillName` is the full skill name — invoke it directly
(e.g. `/process-os-process-discovery`). When Phase 3 reported a `skillMode` value, append it as
the argument (e.g. `/process-os-sme-feedback discovery`); when it reported `absent`, omit the
argument entirely and let the skill run its default path.

**Discard the staged input file.** `.camunda/job-input.json` is also a one-shot artifact of this
single activation cycle. Whichever job skill just ran may already have consumed and removed it;
delete it again now, unconditionally, so a job skill that doesn't consume the file never leaves
it lying around for the next cycle:

```bash
node ".github/skills/process-os-governance-job-activation/scripts/remove-path.cjs" .camunda/job-input.json
```

**Detect a block deterministically.** After the invocation, check for the durable marker file
rather than scraping the skill's stdout for a `BLOCK:` line. Any job skill may hard-stop with
nothing scaffolded/changed by writing `.camunda/init-block.json` (`{ "code": "...", "exit": <n>,
"message": "…" }`) before exiting non-zero; this check is skill-agnostic and requires no changes
here for a new job skill to adopt it:

```bash
node ".github/skills/process-os-governance-job-activation/scripts/path-exists.cjs" .camunda/init-block.json
```

If it reports `EXISTS`, Phase 9 takes the block branch below. Job skills that don't implement the
contract never write the marker, so the probe always reports `NOT FOUND`.

**Job lock extension:** During the skill run, periodically check whether approximately 45 minutes
have elapsed since `active-job-started-at`. Perform this check after each significant step or tool
call by comparing the current time to `active-job-started-at` in governance.json. When 45 minutes
have passed, call:

```
/process-os-governance-job-update <jobKey> --profile <c8ctl-profile>
```

Omit `--profile` if null. This extends the job lock by one hour. Repeat every 45 minutes for
jobs that run longer than an hour.

---

## AI: Phase 9 — Done

**If the job skill blocked** (`.camunda/init-block.json` exists, per the Phase 8 check): do not
print the normal completion message. Read the block reason from the marker, record the block in
governance state, then fail the job so the incident is visible in Operate — recording it first
means job-completion's own commit step, which runs inside the fail call below, actually captures
it, and a status check (`process-os-lifecycle-status`) reports it rather than a caller trying to
complete a failed job.

Read the reason with newlines collapsed and shell-unsafe characters stripped, truncated to 300
chars — the marker's `message` can be an arbitrary error string (not just the identity-fields
list), so it must be safe to drop into a double-quoted argument below. Read the printed value and
substitute it literally as `<REASON>` in the two steps that follow (a shell variable would not
survive between steps, so use the printed value directly):

```bash
node ".github/skills/process-os-governance-job-activation/scripts/read-block-reason.cjs" .camunda/init-block.json
```

**If this exits non-zero**, the marker exists but could not be read or parsed — a different, worse
state than the "no reason given" fallback the script's exit `0` case covers. Do not substitute an
empty `<REASON>`: use `"block marker exists but is unreadable/corrupt (.camunda/init-block.json)"`
as `<REASON>` in both steps below instead, so the failed job and governance state carry a real
explanation rather than a blank message.

Re-read `active-job-key` from governance state rather than trusting the value captured back in
Phase 3 — the job skill invocation in between (Phase 8) may have run long enough to age out of
context, the same reason the job-lock-extension check re-reads state instead of relying on memory:

```bash
node ".github/skills/process-os-governance-job-activation/scripts/governance-state.cjs" read
```

Using that `active-job-key` as `<jobKey>`, and the sanitized reason as `<REASON>`:

```bash
node ".github/skills/process-os-governance-job-activation/scripts/governance-state.cjs" set active-job-key=— active-job-skill=— active-job-blocked="<REASON>"
```

```
/process-os-governance-job-completion <jobKey> --fail --message "<REASON>" [--profile <c8ctl-profile>]
```

Then print:

```
Job '<skillName>' BLOCKED — job <jobKey> failed: <reason>

An incident has been raised on the process instance. Resolve the reported issue (e.g. correct the `skillInput` scope input for the failed job) and let the job re-activate; do not run /process-os-governance-job-completion.
```

**Otherwise** (normal case): clear any stale `.camunda/init-block.json` — defense in depth for a
prior block resolved out-of-band (e.g. an operator fixed the incident directly in Operate), so a
later job's Phase 8 check is never misled by a marker from an unrelated, already-resolved incident:

```bash
node ".github/skills/process-os-governance-job-activation/scripts/remove-path.cjs" .camunda/init-block.json
```

Then print the report below and **stop** — the process instance owns the boundary between one job
and the next, so never run `/process-os-governance-job-completion` off the back of this report.

```
Job '<skillName>' complete.

Review the output above, then run /process-os-governance-job-completion when you are ready to advance the process.
```
