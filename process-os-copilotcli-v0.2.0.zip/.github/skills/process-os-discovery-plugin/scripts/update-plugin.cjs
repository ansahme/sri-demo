#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Update an installed ProcessOS discovery plugin to the ref its registry entry
// declares.
//
// Replaces the whole `update` half of SKILL.md — `export NAME="${1:?…}"`,
// `test -d`/`test -f`, a `REF=$(node -e "…")` capture wrapping a multi-line
// frontmatter parser, `BEFORE=$(git …)`, `|| { … }`, `[ "$VALID" -ne 0 ]` and a
// `printf … >> audit.md`. None of it parses in native PowerShell 5.1.
//
// Usage:
//   node "scripts/update-plugin.cjs" <name>
//
// Re-validation is WARNING-only and never rolls back, matching the documented
// contract: an update that introduces a specialist error stays applied, and the
// caller is told to bump `ref:` and re-run.
//
// Exit codes:
//   0  updated (possibly with a validation WARNING), or already at the ref
//   1  not installed, no registry entry, malformed frontmatter, or bad ref
//   2  usage error

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const { validate } = require(path.join(__dirname, 'validate-plugin.cjs'));
const { appendAudit } = require(path.join(__dirname, 'append-audit.cjs'));

const EXIT = { OK: 0, FAILED: 1, USAGE: 2 };

const SKILL_NAME = 'process-os-discovery-plugin';
const PLUGINS_DIR = path.join('.camunda', 'plugins');
const REGISTRY_DIR = path.join('.camunda', 'registry', 'discovery');

const USAGE = 'usage: update-plugin.cjs <name>\n';

/**
 * Read the `ref:` field out of a registry entry's frontmatter.
 *
 * @param {string} markdown The registry entry's contents.
 * @returns {{ref: string} | {error: string}} Discriminated so the caller can use
 *   the skill's documented wording for each malformed case.
 */
function readRef(markdown) {
  const frontmatter = markdown.match(/^---\r?\n([\s\S]*?)\r?\n---/);
  if (!frontmatter) return { error: 'no frontmatter' };
  const line = frontmatter[1]
    .split(/\r?\n/)
    .map((l) => l.match(/^ref:\s*(.+?)\s*$/))
    .find(Boolean);
  if (!line) return { error: 'no ref: field' };
  return { ref: line[1].replace(/^["']|["']$/g, '') };
}

/**
 * Run a git command. git is a real executable everywhere, so it needs no shell.
 *
 * @param {string[]} args
 * @param {typeof spawnSync} run
 * @returns {{ok: boolean, stdout: string, stderr: string}}
 */
function git(args, run) {
  const result = run('git', args, { encoding: 'utf8' });
  if (result.error || result.status === null) {
    return {
      ok: false,
      stdout: '',
      stderr: `git could not be started: ${result.error ? result.error.message : 'no exit status'}`,
    };
  }
  return { ok: result.status === 0, stdout: result.stdout || '', stderr: result.stderr || '' };
}

/**
 * Update the plugin.
 *
 * @param {string} name Plugin name.
 * @param {object} [deps]
 * @param {typeof spawnSync} [deps.run] Injectable runner, for tests.
 * @param {typeof validate} [deps.validatePlugin] Injectable validator, for tests.
 * @param {Date} [deps.now]
 * @returns {{lines: string[], exitCode: number}}
 */
function update(name, deps = {}) {
  const run = deps.run || spawnSync;
  const validatePlugin = deps.validatePlugin || validate;
  const now = deps.now || new Date();

  const installDir = path.join(PLUGINS_DIR, name);
  const registryFile = path.join(REGISTRY_DIR, `${name}.md`);

  if (!fs.existsSync(installDir)) {
    return { lines: [`error: plugin '${name}' is not installed`], exitCode: EXIT.FAILED };
  }
  if (!fs.existsSync(registryFile)) {
    return { lines: [`error: no ${registryFile}`], exitCode: EXIT.FAILED };
  }

  const parsed = readRef(fs.readFileSync(registryFile, 'utf8'));
  if (parsed.error) {
    return {
      lines: [`error: ${parsed.error} in registry entry for ${name}`],
      exitCode: EXIT.FAILED,
    };
  }
  const { ref } = parsed;

  const before = git(['-C', installDir, 'rev-parse', 'HEAD'], run);
  if (!before.ok) {
    return {
      lines: [`error: could not read HEAD of plugin '${name}'`, before.stderr.trim()].filter(Boolean),
      exitCode: EXIT.FAILED,
    };
  }
  // A failed fetch is not fatal on its own — the ref may already be local, and
  // an offline update to an existing tag still works. It only matters if the
  // checkout then fails: "ref not found" would blame the registry entry for what
  // is really a network or auth problem.
  const fetched = git(['-C', installDir, 'fetch', '--quiet', '--tags'], run);

  const checkedOut = git(['-C', installDir, 'checkout', '--quiet', ref], run);
  if (!checkedOut.ok) {
    return {
      lines: fetched.ok
        ? [`error: ref '${ref}' not found in plugin '${name}'`]
        : [
            `error: could not check out ref '${ref}' in plugin '${name}' — the preceding fetch failed, so the ref may simply not be local yet`,
            fetched.stderr.trim(),
          ].filter(Boolean),
      exitCode: EXIT.FAILED,
    };
  }
  const after = git(['-C', installDir, 'rev-parse', 'HEAD'], run);
  if (!after.ok) {
    return {
      lines: [`error: could not read HEAD of plugin '${name}' after checkout`, after.stderr.trim()].filter(Boolean),
      exitCode: EXIT.FAILED,
    };
  }

  const beforeSha = before.stdout.trim();
  const afterSha = after.stdout.trim();

  const lines = [];
  const verdict = validatePlugin(process.cwd(), name);
  if (!verdict.valid) {
    // WARNING-only by contract: the update is NOT rolled back.
    lines.push(
      'WARNING: plugin now reports errors:',
      ...verdict.errors.map((e) => `  ${e.kind}: ${e.message}`),
      `Roll back by bumping ref: in ${registryFile} and re-running /${SKILL_NAME} update ${name}`
    );
  }

  // Re-running `update` against an unchanged ref is normal, so the ledger must
  // stay silent on it: a dated "Updated" row that rolls forward on every run
  // tells a stakeholder the plugin moved on a day it did not.
  // The checkout has already happened. The ledger is a human-readable mirror,
  // not the authoritative state, so a failed append is a warning — crashing
  // here would report a stack trace for an update that actually landed.
  if (beforeSha !== afterSha) {
    try {
      appendAudit(SKILL_NAME, `Updated '${name}' ${beforeSha} -> ${afterSha} (ref: ${ref})`, { now });
    } catch (err) {
      lines.push(`WARNING: could not record this update in the audit ledger: ${err.message}`);
    }
  }

  lines.push(
    beforeSha === afterSha
      ? `Already at ${ref} (no change).`
      : `Updated ${name}: ${beforeSha} -> ${afterSha} (ref: ${ref})`
  );
  return { lines, exitCode: EXIT.OK };
}

module.exports = { EXIT, readRef, update };

if (require.main === module) {
  const [name, ...rest] = process.argv.slice(2);
  if (!name || rest.length > 0) {
    process.stderr.write(USAGE);
    process.exit(EXIT.USAGE);
  }
  const { lines, exitCode } = update(name);
  process.stdout.write(`${lines.join('\n')}\n`);
  process.exit(exitCode);
}
