#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Install a ProcessOS discovery plugin from a git source.
//
// Replaces the whole `install` half of SKILL.md — eight bash blocks built from
// `${1:?…}`, `test -d`, `[ -f … ]`, `mkdir -p`, `rm -rf`, `$(basename …)`,
// `$(date …)`, a heredoc and `||  { … }` groups. None of it parses in native
// PowerShell 5.1, and the rollback in particular is where a hand-translation
// going wrong leaves a half-installed plugin behind.
//
// Usage:
//   node "scripts/install-plugin.cjs" <source> [<ref>]
//
//   <source>  git URL (HTTPS, SSH) or local path — anything `git clone` accepts.
//   <ref>     tag, branch, or SHA. Default `main`.
//
// The plugin name is the basename of <source> with any `.git` suffix stripped.
//
// Rollback is all-or-nothing: a bad ref or a failed validation removes both the
// clone and the registry entry, so a retry starts from a clean state.
//
// Exit codes:
//   0  installed, validated and bridged
//   1  not a process project, already installed, bad ref, clone failed, or the
//      plugin failed validation (rolled back)
//   2  usage error

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const { validate } = require(path.join(__dirname, 'validate-plugin.cjs'));
const { appendAudit } = require(path.join(__dirname, 'append-audit.cjs'));

const EXIT = { OK: 0, FAILED: 1, USAGE: 2 };

const SKILL_NAME = 'process-os-discovery-plugin';
const PLUGINS_DIR = path.join('.camunda', 'plugins');
const REGISTRY_DIR = path.join('.camunda', 'registry', 'discovery');
const DEFAULT_REF = 'main';

const USAGE = 'usage: install-plugin.cjs <source> [<ref>]\n';

/**
 * Derive the plugin name from a source URL or path.
 *
 * @param {string} source
 * @returns {string} Basename with any `.git` suffix stripped; '' if none.
 */
function pluginNameFor(source) {
  // Both separators, because a Windows caller may pass a backslash path while a
  // git URL always uses forward slashes.
  const last = source.replace(/[/\\]+$/, '').split(/[/\\]/).pop() || '';
  return last.replace(/\.git$/, '');
}

/**
 * Build the registry entry body.
 *
 * @param {object} args
 * @param {string} args.name
 * @param {string} args.source
 * @param {string} args.ref
 * @param {Date} [args.now]
 * @returns {string}
 */
function registryEntry({ name, source, ref, now = new Date() }) {
  const pad = (n) => String(n).padStart(2, '0');
  const date = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
  return `---
source: ${source}
ref: ${ref}
---

# ${name}

Installed by /${SKILL_NAME} install on ${date}.
`;
}

/**
 * Run a git command, inheriting nothing (output is reported by the caller).
 *
 * git is a real executable on every platform this runs on, so it needs no shell.
 *
 * @param {string[]} args
 * @param {typeof spawnSync} run
 * @returns {{ok: boolean, stdout: string, stderr: string}}
 */
function git(args, run) {
  const result = run('git', args, { encoding: 'utf8' });
  if (result.error || result.status === null) {
    return {
      ok: false,
      stdout: '',
      stderr: `git could not be started: ${result.error ? result.error.message : 'no exit status'}`,
    };
  }
  return { ok: result.status === 0, stdout: result.stdout || '', stderr: result.stderr || '' };
}

/**
 * Install the plugin.
 *
 * @param {object} args
 * @param {string} args.source
 * @param {string} args.ref
 * @param {object} [deps]
 * @param {typeof spawnSync} [deps.run] Injectable runner, for tests.
 * @param {typeof validate} [deps.validatePlugin] Injectable validator, for tests.
 * @param {(root: string) => string[]} [deps.bridge] Injectable bridge step, for tests.
 * @param {Date} [deps.now]
 * @returns {{lines: string[], exitCode: number}}
 */
function install({ source, ref }, deps = {}) {
  const run = deps.run || spawnSync;
  const validatePlugin = deps.validatePlugin || validate;
  const now = deps.now || new Date();

  if (!fs.existsSync('.camunda')) {
    return {
      lines: [
        'error: not a process project (no .camunda/ here). Run /process-os-project-initialization first.',
      ],
      exitCode: EXIT.FAILED,
    };
  }

  const name = pluginNameFor(source);
  if (!name) {
    return { lines: ['error: could not derive plugin name from source'], exitCode: EXIT.FAILED };
  }

  const installDir = path.join(PLUGINS_DIR, name);
  const registryFile = path.join(REGISTRY_DIR, `${name}.md`);

  if (fs.existsSync(installDir)) {
    return {
      lines: [
        `error: plugin '${name}' is already installed. Use /${SKILL_NAME} update ${name} to bump its ref, or remove the directory and re-install.`,
      ],
      exitCode: EXIT.FAILED,
    };
  }
  if (fs.existsSync(registryFile)) {
    return {
      lines: [
        `error: registry already declares '${name}' but the install directory is missing. Remove ${registryFile} (or restore the install) and retry.`,
      ],
      exitCode: EXIT.FAILED,
    };
  }

  // Everything from here can fail, and every failure removes both artifacts.
  const rollback = () => {
    fs.rmSync(registryFile, { force: true });
    fs.rmSync(installDir, { recursive: true, force: true });
  };

  fs.mkdirSync(PLUGINS_DIR, { recursive: true });
  const cloned = git(['clone', '--quiet', source, installDir], run);
  if (!cloned.ok) {
    rollback();
    return {
      lines: [`error: could not clone ${source}`, cloned.stderr.trim()].filter(Boolean),
      exitCode: EXIT.FAILED,
    };
  }

  const checkedOut = git(['-C', installDir, 'checkout', '--quiet', ref], run);
  if (!checkedOut.ok) {
    rollback();
    return { lines: [`error: ref '${ref}' not found in ${source}`], exitCode: EXIT.FAILED };
  }

  fs.mkdirSync(REGISTRY_DIR, { recursive: true });
  fs.writeFileSync(registryFile, registryEntry({ name, source, ref, now }));

  const verdict = validatePlugin(process.cwd(), name);
  if (!verdict.valid) {
    rollback();
    return {
      lines: [
        `error: plugin '${name}' failed validation:`,
        ...verdict.errors.map((e) => `  ${e.kind}: ${e.message}`),
      ],
      exitCode: EXIT.FAILED,
    };
  }

  const lines = deps.bridge ? deps.bridge(process.cwd()) : bridge(run);

  // Same reasoning as a bridge failure: the plugin is installed, validated and
  // registered by this point. The ledger is a human-readable mirror, not the
  // authoritative state, so failing to write it is a warning — crashing here
  // would report a stack trace for an install that actually succeeded.
  try {
    appendAudit(SKILL_NAME, `Installed plugin '${name}' (ref: ${ref})`, { now });
  } catch (err) {
    lines.push(`WARNING: could not record this install in the audit ledger: ${err.message}`);
  }

  lines.push(
    `Installed: ${name} @ ${ref}`,
    `  Source: ${source}`,
    `  Specialists: ${verdict.specialists}`,
    '',
    `Next: /process-os-lifecycle-status to verify, then /process-os-process-discovery to use the new specialists.`
  );
  return { lines, exitCode: EXIT.OK };
}

/**
 * Bridge the freshly installed plugin into the host runtime.
 *
 * Adapters are Node scripts spawned with `process.execPath` — a shebang script
 * cannot be executed on native Windows. A bridge failure is a warning, not an
 * install failure: the plugin is on disk and the adapter subcommand can be run
 * by hand.
 *
 * @param {typeof spawnSync} run
 * @returns {string[]} Warning lines, empty when the bridge succeeded.
 */
function bridge(run) {
  const whichRuntime = path.join(__dirname, 'which-runtime.cjs');
  const detected = run(process.execPath, [whichRuntime], { encoding: 'utf8' });
  const warning =
    'warning: bridge step failed — plugin installed but not visible to the host runtime. Run the adapter bridge subcommand manually.';
  if (detected.error || detected.status !== 0) return [warning];

  const adapter = path.join(__dirname, (detected.stdout || '').trim());
  const bridged = run(process.execPath, [adapter, 'bridge', process.cwd()], { stdio: 'inherit' });
  return bridged.error || bridged.status !== 0 ? [warning] : [];
}

module.exports = { EXIT, bridge, install, pluginNameFor, registryEntry };

if (require.main === module) {
  const [source, ref = DEFAULT_REF, ...rest] = process.argv.slice(2);
  if (!source || rest.length > 0) {
    process.stderr.write(USAGE);
    process.exit(EXIT.USAGE);
  }
  const { lines, exitCode } = install({ source, ref });
  process.stdout.write(`${lines.join('\n')}\n`);
  process.exit(exitCode);
}
