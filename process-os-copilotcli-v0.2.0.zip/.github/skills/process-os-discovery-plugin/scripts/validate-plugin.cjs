#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Runs list-active-plugins.cjs and reports pass/fail for one
// named plugin — the enumeration+filter step both verbs of
// process-os-discovery-plugin need. The response to a failure
// (rollback vs. warning-only) is the caller's decision, not this script's.
//
// Usage:
//   validate-plugin.cjs --project-root <dir> <name>
//
// Prints one JSON line to stdout and exits 0 (valid) or 1 (invalid):
//   {"valid":true,"specialists":2}
//   {"valid":false,"errors":[{"kind":"...","message":"..."}]}
//
// Exit codes: 0 valid, 1 invalid, 2 usage error.

'use strict';

const path = require('path');

// Single literal-string references: bundling detects this exact form and copies both
// files into this skill's own scripts/ directory, rewriting these to sibling paths.
const LIST_ACTIVE_PLUGINS = path.join(__dirname, 'list-active-plugins.cjs');
const { runNodeCli } = require(path.join(__dirname, 'resolve-node-cli.cjs'));

/**
 * @param {string[]} argv Full process.argv.
 * @returns {{projectRoot: string, name: string}} Exits 2 on
 *   a usage error rather than returning, so callers need no error branch.
 */
function parseArgs(argv) {
  const args = argv.slice(2);
  let projectRoot = null;
  const rest = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--project-root') projectRoot = args[++i];
    else rest.push(args[i]);
  }
  const name = rest[0];
  if (!projectRoot || !name) {
    process.stderr.write('usage: validate-plugin.cjs --project-root <dir> <name>\n');
    process.exit(2);
  }
  return { projectRoot, name };
}

/**
 * Enumerate the project's active plugins.
 *
 * Runs through `runNodeCli` (resolve-node-cli.cjs), which spawns
 * `process.execPath` directly rather than the bare name `node`: a bare command
 * name is resolved through PATH (and PATHEXT on Windows), so it depends on the
 * caller's environment rather than on the interpreter already running this
 * script. No shell is involved, which is also why no BOM can appear on the
 * child's stdout. Reusing the shared helper also means `!r.launched` here
 * means exactly what it means everywhere else in the repo.
 *
 * The three ways this can go wrong are reported as three distinct kinds. Folded
 * into one, "Node could not be started" is indistinguishable from "the registry
 * is malformed" — and the caller cannot tell whether the answer means anything.
 *
 * @param {string} projectRoot Project root passed through to the enumerator.
 * @param {Object} [deps]
 * @param {function} [deps.run] runNodeCli stand-in; injected by tests.
 * @returns {{ok: true, value: Object} | {ok: false, kind: string, message: string}}
 */
function enumerate(projectRoot, deps = {}) {
  const run = deps.run || runNodeCli;
  const r = run(LIST_ACTIVE_PLUGINS, ['--project-root', projectRoot], { encoding: 'utf8' });

  if (!r.launched) {
    return {
      ok: false,
      kind: 'enumeration-did-not-run',
      message: `could not start the plugin enumerator: ${(r.error && r.error.message) || 'terminated by signal'}`,
    };
  }
  if (r.status !== 0) {
    return {
      ok: false,
      kind: 'enumeration-failed',
      message: `plugin enumerator exit ${r.status}: ${String(r.stderr || '').trim() || '(no output)'}`,
    };
  }
  try {
    return { ok: true, value: JSON.parse(r.stdout) };
  } catch (err) {
    return {
      ok: false,
      kind: 'enumeration-unparseable',
      message: `plugin enumerator output was not JSON: ${err.message}`,
    };
  }
}

/**
 * Decide whether one named plugin is valid.
 *
 * @param {string} projectRoot Project root.
 * @param {string} name Plugin name.
 * @param {Object} [deps] Passed through to enumerate.
 * @returns {{valid: true, specialists: number} | {valid: false, errors: {kind: string, message: string}[]}}
 */
function validate(projectRoot, name, deps = {}) {
  const enumeration = enumerate(projectRoot, deps);
  if (!enumeration.ok) {
    return { valid: false, errors: [{ kind: enumeration.kind, message: enumeration.message }] };
  }
  const enumerated = enumeration.value;

  const errors = enumerated.errors.filter((e) => e.plugin === name || e.file === `${name}.md`);
  if (errors.length > 0) {
    return { valid: false, errors: errors.map((e) => ({ kind: e.kind, message: e.message })) };
  }

  const plugin = enumerated.plugins.find((p) => p.name === name);
  if (!plugin) {
    return {
      valid: false,
      errors: [{ kind: 'not-in-registry', message: `plugin '${name}' has no registry entry` }],
    };
  }

  return { valid: true, specialists: Array.isArray(plugin.specialists) ? plugin.specialists.length : 0 };
}

function main(argv) {
  const { projectRoot, name } = parseArgs(argv);
  const verdict = validate(projectRoot, name);

  process.stdout.write(JSON.stringify(verdict) + '\n');
  process.exit(verdict.valid ? 0 : 1);
}

module.exports = { enumerate, validate, parseArgs };

if (require.main === module) main(process.argv);
