#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Runtime adapter: Claude Code.
//
// Subcommands:
//   bridge <project-root>           link .camunda/plugins/<name>/ into <home>/.claude/plugins/<name>/
//   spawn  <skill-id> <args-json>   no-op on Claude Code (the LLM uses Agent() directly)
//
// Node rather than a shell script, because neither half of a shell
// implementation works on a native Windows agent:
//
//   - An extensionless script with a `#!` line cannot be spawned at all: Windows
//     has no shebang support, so spawnSync returns status null with no output —
//     the silent non-launch this repo treats as its own outcome, never as clean.
//   - `ln -s` needs Developer Mode or an elevated process. A directory *junction*
//     needs no privileges, so that is what the bridge creates there.
//
// Usage:
//   node scripts/process-os-adapter-claude-code.cjs bridge <project-root>
//
// Exit codes: 0 success, 2 usage / missing plugins directory.

'use strict';

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const USAGE = `usage: process-os-adapter-claude-code.cjs <subcommand> [args...]
  bridge <project-root>
  spawn  <skill-id> <args-json>
`;

/**
 * Home directory the Claude Code plugin tree hangs off.
 *
 * `HOME` first so a caller can redirect the bridge (the test suite does);
 * `USERPROFILE` is the Windows spelling, which os.homedir() also consults but
 * only from the real process environment.
 *
 * @param {Object.<string,string>} [env] Environment to read.
 * @returns {string} Absolute home directory.
 */
function homeDir(env = process.env) {
  return env.HOME || env.USERPROFILE || os.homedir();
}

/**
 * The `fs.symlink` type to use for a directory link on this platform.
 *
 * `junction` on Windows: an ordinary symlink there requires Developer Mode or
 * elevation, whereas a junction is unprivileged. Node reports a junction as a
 * symbolic link through `lstat`, so callers see one shape on every platform.
 * The type argument is ignored on POSIX.
 *
 * @returns {'junction'|'dir'} Link type for fs.symlinkSync.
 */
function linkType() {
  return process.platform === 'win32' ? 'junction' : 'dir';
}

/**
 * Whether `link` already resolves to `target`.
 *
 * Compares realpaths rather than the raw `readlink` value: a Windows junction
 * reads back in a normalized spelling (and can carry a trailing separator), and
 * on macOS a temp directory resolves through the /var → /private/var symlink.
 *
 * @param {string} link Path of the existing link.
 * @param {string} target Directory it should point at.
 * @returns {boolean}
 */
function pointsAt(link, target) {
  try {
    return fs.realpathSync(link) === fs.realpathSync(target);
  } catch {
    return false;
  }
}

/**
 * Point `link` at the directory `target`, replacing whatever is there.
 *
 * @param {string} target Absolute path to the plugin directory.
 * @param {string} link Absolute path of the link to create.
 * @returns {'linked'|'unchanged'} Whether anything was written.
 */
function linkPlugin(target, link) {
  if (pointsAt(link, target)) return 'unchanged';

  const existing = fs.lstatSync(link, { throwIfNoEntry: false });
  if (existing) {
    if (existing.isSymbolicLink()) {
      // Remove the link itself, never what it points at. A junction is a
      // directory reparse point, so unlink can refuse it — rmdir removes the
      // reparse point alone and still leaves the target untouched.
      try {
        fs.unlinkSync(link);
      } catch {
        fs.rmdirSync(link);
      }
    } else {
      fs.rmSync(link, { recursive: true, force: true });
    }
  }

  fs.symlinkSync(target, link, linkType());
  return 'linked';
}

/**
 * @param {string} message Written to stderr.
 * @returns {never}
 */
function fail(message) {
  process.stderr.write(`error: ${message}\n`);
  process.exit(2);
}

/**
 * bridge — make every installed plugin visible to Claude Code's skill system.
 * Idempotent: a link already pointing at the right directory is left alone.
 *
 * @param {string[]} args Positional arguments after the subcommand.
 * @param {Object.<string,string>} [env] Environment to read HOME from.
 */
function cmdBridge(args, env = process.env) {
  const projectRoot = args[0];
  if (!projectRoot) fail('bridge requires <project-root>');

  const pluginsDir = path.join(projectRoot, '.camunda', 'plugins');
  if (!fs.existsSync(pluginsDir)) {
    // The documented layout is spelled with `/` regardless of platform — this
    // names the contract, not a path on the local filesystem.
    fail(`no .camunda/plugins/ at ${projectRoot}`);
  }

  const targetRoot = path.join(homeDir(env), '.claude', 'plugins');
  fs.mkdirSync(targetRoot, { recursive: true });

  for (const entry of fs.readdirSync(pluginsDir, { withFileTypes: true })) {
    if (!entry.isDirectory()) continue;
    linkPlugin(path.join(pluginsDir, entry.name), path.join(targetRoot, entry.name));
  }
}

/**
 * spawn — contract stub. ADR-0005: on Claude Code the LLM calls Agent()
 * directly, so there is nothing for the adapter to run.
 *
 * @param {string[]} args Positional arguments after the subcommand.
 */
function cmdSpawn(args) {
  if (args.length < 2) fail('spawn requires <skill-id> <args-json>');
  process.stdout.write('spawn: no-op on Claude Code (caller should use Agent() directly)\n');
}

function main(argv = process.argv.slice(2)) {
  const [sub, ...rest] = argv;
  switch (sub) {
    case 'bridge':
      return cmdBridge(rest);
    case 'spawn':
      return cmdSpawn(rest);
    case undefined:
      process.stderr.write(USAGE);
      return process.exit(2);
    default:
      return fail(`unknown subcommand: ${sub}`);
  }
}

module.exports = { homeDir, linkType, pointsAt, linkPlugin };

if (require.main === module) main();
