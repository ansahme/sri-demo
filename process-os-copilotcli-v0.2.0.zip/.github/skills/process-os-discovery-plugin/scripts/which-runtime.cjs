#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Prints the adapter binary name for the current runtime.
//
// Detection: inspect well-known environment markers. If none are set, defaults
// to Claude Code (the only adapter shipped today). If two or more markers are
// set simultaneously, exits non-zero to surface the ambiguity rather than guess.
//
// Usage:
//   scripts/plugin-discovery/which-runtime.cjs
//
// Exit codes: 0 (printed adapter name to stdout), 2 (ambiguous environment).

'use strict';

// Adapters are Node scripts in this directory, run as
// `node scripts/<adapter>`. The printed name carries the `.cjs` extension
// because that is the real filename: an extensionless executable relying on a
// shebang cannot be spawned on native Windows.
const RUNTIMES = [
  { envVar: 'CLAUDECODE', adapter: 'process-os-adapter-claude-code.cjs' },
  { envVar: 'COPILOT_CLI', adapter: 'process-os-adapter-copilot.cjs' },
];

function main() {
  const matches = RUNTIMES.filter(r => process.env[r.envVar]);
  if (matches.length > 1) {
    process.stderr.write(
      `error: multiple runtime markers set (${matches.map(m => m.envVar).join(', ')})\n`
    );
    process.exit(2);
  }
  const adapter = matches[0]?.adapter ?? 'process-os-adapter-claude-code.cjs';
  process.stdout.write(adapter + '\n');
}

if (require.main === module) main();
