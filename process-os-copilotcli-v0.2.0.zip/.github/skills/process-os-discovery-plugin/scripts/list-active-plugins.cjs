#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Deterministic enumeration of active process-os plugins for the current process project.
//
// Reads `.camunda/registry/discovery/*.md` (one file per active discovery plugin;
// filename = plugin name; YAML frontmatter declares the git source + ref). For each
// declared plugin, checks whether `.camunda/plugins/<name>/` exists (the install root,
// gitignored), and if so reads `specialists/*.md` from inside it (auto-discovered,
// frontmatter-driven).
//
// Discovery is currently the only lifecycle phase with a plugin contract. The phase
// segment in the registry path is intentional — future phases will live as siblings
// (`registry/optimize/`, `registry/generate/`, …) with their own enumeration scripts.
//
// Emits a JSON document on stdout. Exits 0 on enumeration success (per-plugin errors
// land in `errors`, never abort). Exits 2 only if no process project is found.
//
// Usage:
//   scripts/plugin-discovery/list-active-plugins.cjs [--project-root <path>]

'use strict';

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

function findProjectRoot(start) {
  let dir = path.resolve(start);
  while (true) {
    if (fs.existsSync(path.join(dir, '.camunda'))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) return null;
    dir = parent;
  }
}

const VALID_MODEL_TIERS = ['high', 'medium', 'low'];
const DEFAULT_MODEL_TIER = 'medium';

// ─── frontmatter extraction ───────────────────────────────────────────────────

function extractFrontmatter(content) {
  const m = content.match(/^---\r?\n([\s\S]*?)\r?\n---(\r?\n|$)/);
  return m ? m[1] : null;
}

// ─── tiny YAML parser for the constrained frontmatter schema ──────────────────
//
// Supports: top-level `key: scalar`, `key:` followed by indented `- item` list,
// `key:` followed by indented `subkey: scalar` map. Two levels of nesting max.
// Quoted strings (single/double) are unquoted. Comments stripped. No anchors,
// flow style, or multi-line scalars. If the schema ever outgrows this, swap
// for js-yaml.

function parseYaml(text) {
  const lines = text.split(/\r?\n/);
  const result = {};
  let i = 0;
  while (i < lines.length) {
    const raw = lines[i];
    const line = raw.replace(/#.*$/, '').replace(/\s+$/, '');
    if (!line.trim()) { i++; continue; }

    const indent = line.match(/^ */)[0].length;
    if (indent !== 0) {
      throw new Error(`unexpected indentation at line ${i + 1}: ${raw}`);
    }

    const m = line.match(/^([A-Za-z_][\w-]*):\s*(.*)$/);
    if (!m) throw new Error(`unparseable line ${i + 1}: ${raw}`);
    const key = m[1];
    const rest = m[2];

    if (rest !== '') {
      result[key] = unquote(rest);
      i++;
      continue;
    }

    const child = [];
    i++;
    while (i < lines.length) {
      const nraw = lines[i];
      const nline = nraw.replace(/#.*$/, '').replace(/\s+$/, '');
      if (!nline.trim()) { i++; continue; }
      const nindent = nline.match(/^ */)[0].length;
      if (nindent === 0) break;
      child.push({ indent: nindent, text: nline });
      i++;
    }
    if (child.length === 0) { result[key] = null; continue; }

    if (child[0].text.trim().startsWith('- ')) {
      result[key] = child.map(c => unquote(c.text.trim().slice(2)));
    } else {
      const sub = {};
      for (const c of child) {
        const sm = c.text.trim().match(/^([A-Za-z_][\w-]*):\s*(.*)$/);
        if (!sm) throw new Error(`unparseable nested line: ${c.text}`);
        sub[sm[1]] = unquote(sm[2]);
      }
      result[key] = sub;
    }
  }
  return result;
}

function unquote(s) {
  s = s.trim();
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) {
    return s.slice(1, -1);
  }
  return s;
}

// ─── registry enumeration ─────────────────────────────────────────────────────

function readRegistry(projectRoot) {
  const registryDir = path.join(projectRoot, '.camunda', 'registry', 'discovery');
  if (!fs.existsSync(registryDir)) return [];

  const files = fs.readdirSync(registryDir)
    .filter(f => f.endsWith('.md'))
    .sort();

  const entries = [];
  for (const f of files) {
    const name = f.replace(/\.md$/, '');
    const filePath = path.join(registryDir, f);
    const content = fs.readFileSync(filePath, 'utf8');
    const fmText = extractFrontmatter(content);
    if (fmText === null) {
      // Files without frontmatter are inert documentation (e.g. README.md).
      continue;
    }
    try {
      const entry = parseYaml(fmText);
      if (!entry.source) throw new Error(`registry/discovery/${f}: missing required frontmatter field: source`);
      if (!entry.ref) throw new Error(`registry/discovery/${f}: missing required frontmatter field: ref`);
      entries.push({ ok: true, name, source: entry.source, ref: entry.ref, registryPath: filePath });
    } catch (err) {
      entries.push({ ok: false, name, file: f, registryPath: filePath, message: err.message });
    }
  }
  return entries;
}

// ─── specialist enumeration ───────────────────────────────────────────────────

function readSpecialists(pluginRoot) {
  const specialistsDir = path.join(pluginRoot, 'specialists');
  if (!fs.existsSync(specialistsDir)) return { specialists: [], errors: [] };

  const files = fs.readdirSync(specialistsDir)
    .filter(f => f.endsWith('.md'))
    .sort();

  const specialists = [];
  const errors = [];
  for (const f of files) {
    const sPath = path.join(specialistsDir, f);
    const result = readSpecialist(sPath, f);
    if (result.ok) specialists.push(result.specialist);
    else errors.push({ kind: result.kind, file: f, message: result.message });
  }
  return { specialists, errors };
}

function readSpecialist(filePath, filename) {
  const content = fs.readFileSync(filePath, 'utf8');
  const fmText = extractFrontmatter(content);
  if (fmText === null) {
    return { ok: false, kind: 'specialist-no-frontmatter', message: `${filename}: no frontmatter block` };
  }

  let fm;
  try {
    fm = parseYaml(fmText);
  } catch (err) {
    return { ok: false, kind: 'specialist-yaml-parse', message: `${filename}: ${err.message}` };
  }

  const expectedName = filename.replace(/\.md$/, '');
  if (!fm.name) {
    return { ok: false, kind: 'specialist-missing-field', message: `${filename}: frontmatter missing required field: name` };
  }
  if (fm.name !== expectedName) {
    return { ok: false, kind: 'specialist-name-mismatch', message: `${filename}: frontmatter name "${fm.name}" does not match filename "${expectedName}"` };
  }
  if (!fm.description) {
    return { ok: false, kind: 'specialist-missing-field', message: `${filename}: frontmatter missing required field: description` };
  }

  const model = fm.model ?? DEFAULT_MODEL_TIER;
  if (!VALID_MODEL_TIERS.includes(model)) {
    return { ok: false, kind: 'specialist-invalid-model', message: `${filename}: invalid model tier "${model}" (must be ${VALID_MODEL_TIERS.join('|')})` };
  }

  const env = Array.isArray(fm.env) ? fm.env : [];

  return {
    ok: true,
    specialist: {
      name: fm.name,
      description: fm.description,
      path: filePath,
      env,
      model,
    },
  };
}

function readInstalledSha(projectRoot, name) {
  const dir = path.join(projectRoot, '.camunda', 'plugins', name);
  try {
    // execFileSync, not execSync: no shell means no cmd.exe on Windows and
    // nothing to quote.
    return execFileSync('git', ['rev-parse', 'HEAD'], { cwd: dir, stdio: ['ignore', 'pipe', 'ignore'] })
      .toString().trim();
  } catch {
    return null;
  }
}

// ─── main ─────────────────────────────────────────────────────────────────────

function main(argv) {
  const args = argv.slice(2);
  let projectRoot = null;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--project-root') projectRoot = args[++i];
  }
  if (!projectRoot) {
    projectRoot = findProjectRoot(process.cwd());
    if (!projectRoot) {
      process.stderr.write('no process project found (.camunda/ not found in this directory or any parent)\n');
      process.exit(2);
    }
  }

  const out = { projectRoot, plugins: [], errors: [] };

  const registry = readRegistry(projectRoot);
  for (const r of registry) {
    if (!r.ok) {
      out.errors.push({ kind: 'registry-parse', file: r.file, message: r.message });
      continue;
    }
    const plugin = {
      name: r.name,
      declared: { source: r.source, ref: r.ref },
      registryPath: r.registryPath,
    };
    const pluginRoot = path.join(projectRoot, '.camunda', 'plugins', r.name);
    if (!fs.existsSync(pluginRoot)) {
      plugin.installed = false;
    } else {
      plugin.installed = true;
      plugin.installedSha = readInstalledSha(projectRoot, r.name);
      const { specialists, errors } = readSpecialists(pluginRoot);
      plugin.specialists = specialists;
      for (const e of errors) {
        out.errors.push({ kind: e.kind, plugin: r.name, file: e.file, message: e.message });
      }
    }
    out.plugins.push(plugin);
  }

  process.stdout.write(JSON.stringify(out, null, 2) + '\n');
  process.exit(0);
}

if (require.main === module) main(process.argv);

module.exports = { extractFrontmatter, parseYaml };
