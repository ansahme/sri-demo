---
name: process-os-discovery-plugin
description: >-
  Install or update a ProcessOS discovery plugin from a git source, dispatched
  by verb (install | update).

  Install clones into .camunda/plugins/<name>/, validates specialists, writes
  the registry entry under

  .camunda/registry/discovery/, and bridges into the host runtime. Update
  re-checks-out the ref declared in the registry entry and re-validates
  (WARNING-only, never rolled back).

  USE FOR: install a discovery plugin from git, bump an installed plugin to its
  declared ref,

  re-validate a plugin after a registry ref change.

  DO NOT USE FOR: checking plugin skew without updating (use
  process-os-lifecycle-status).
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
# /process-os-discovery-plugin

Install or update a ProcessOS discovery plugin from a git source. (Only the discovery phase has a plugin contract today.)

## Verb dispatch

The skill takes a verb as its first argument. Run the matching script and nothing else:

| Invocation | Command |
|---|---|
| `install <source> [<ref>]` | `node ".github/skills/process-os-discovery-plugin/scripts/install-plugin.cjs" <source> [<ref>]` |
| `update <name>` | `node ".github/skills/process-os-discovery-plugin/scripts/update-plugin.cjs" <name>` |

Any other verb: stop with `error: unknown verb '<verb>' — expected 'install' or 'update'`.

Both scripts validate through `scripts/validate-plugin.cjs`, which returns
`{"valid":true,"specialists":N}` or `{"valid":false,"errors":[{"kind":"...","message":"..."}]}` —
each verb reacts to that verdict per its own failure semantics, described below.

## Install

### Arguments

`/process-os-discovery-plugin install <source> [<ref>]`

- `<source>` — git URL (HTTPS, SSH) or local path (absolute, `~/...`, or relative to the project root). Anything `git clone` accepts.
- `<ref>` — optional tag, branch, or SHA. Defaults to `main`.

### EXEC: 1. Install

```bash
node ".github/skills/process-os-discovery-plugin/scripts/install-plugin.cjs" <source> <ref>
```

Omit `<ref>` to take the `main` default. In one run the script:

1. Verifies this is a process project (`.camunda/` exists).
2. Derives the plugin name — the basename of `<source>` with any `.git` suffix stripped — and
   refuses if either the install directory or the registry entry already exists.
3. Clones into `.camunda/plugins/<name>/` and checks out `<ref>`.
4. Writes the registry entry `.camunda/registry/discovery/<name>.md`: filename = plugin name,
   frontmatter = `source` + `ref`, body is human prose (left near-empty; edit later to add
   rationale, owner, ticket links).
5. Validates. **Any failure from step 3 on rolls back both the clone and the registry entry**, so
   a retry starts clean.
6. Bridges into the host runtime by spawning the adapter `scripts/which-runtime.cjs` names. A
   bridge failure is a warning, not an install failure — the plugin is on disk and the adapter's
   `bridge` subcommand can be run by hand.
7. Appends the audit row and prints the install summary (name, ref, source, specialist count).

Exit `0` installed, `1` any of the failures in the table below, `2` usage error.

### Install errors

- `error: not a process project` — run `/process-os-project-initialization` first.
- `error: plugin '<name>' is already installed` — use `/process-os-discovery-plugin update <name>` instead.
- `error: ref '<ref>' not found in <source>` — bad tag/branch/SHA.
- `error: plugin '<name>' failed validation` — specialists are malformed (see printed details); the rollback has already removed the install and registry entry.

## Update

### Arguments

`/process-os-discovery-plugin update <name>`

`<name>` — the plugin's name (the basename of its file in `.camunda/registry/discovery/`).

### EXEC: 1. Update

```bash
node ".github/skills/process-os-discovery-plugin/scripts/update-plugin.cjs" <name>
```

In one run the script:

1. Verifies the plugin is installed and has a registry entry.
2. Reads the declared `ref:` out of that entry's frontmatter.
3. Records `HEAD`, fetches with tags, checks out the declared ref, records `HEAD` again.
4. Re-validates. **A failure here is a WARNING and is never rolled back** — the new ref stays
   checked out, and the message tells the user to bump `ref:` and re-run.
5. Appends the audit row and reports either the SHA transition or `Already at <ref> (no change).`

Exit `0` updated (with or without a validation WARNING), `1` any of the failures in the table
below, `2` usage error.

### Update errors

- `error: plugin '<name>' is not installed` — run `/process-os-discovery-plugin install <source> [<ref>]` first.
- `error: no .camunda/registry/discovery/<name>.md` — there is no registry entry for this plugin; either add one (frontmatter with `source` + `ref`) or remove the install directory.
- `error: no frontmatter in registry entry for <name>` / `error: no ref: field in registry entry for <name>` — the registry file is malformed; edit it to include a frontmatter block with `source` and `ref`.
- `error: ref '<ref>' not found in plugin '<name>'` — the declared `ref:` does not exist in the plugin's remote; update the registry entry to a valid tag/branch/SHA.
- `WARNING: plugin now reports errors:` — the new ref has a specialist issue. The update is **not** rolled back. Fix by bumping `ref:` in `.camunda/registry/discovery/<name>.md` to a working version and re-running `/process-os-discovery-plugin update <name>`.
