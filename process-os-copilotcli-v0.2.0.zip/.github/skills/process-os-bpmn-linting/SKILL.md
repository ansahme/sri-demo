---
name: process-os-bpmn-linting
description: >-
  Lint a single BPMN file or a directory of BPMN files with bpmnlint:recommended
  plus the ProcessOS custom rule pack and apply targeted fixes. Use after
  creating or modifying any .bpmn file and before any subsequent step
  (deployment, further generation, review, …) — bpmnlint catches structural and
  best-practice issues that Zeebe deployment validation misses, and the custom
  rules close gaps the recommended set leaves open (notably boundary events
  attached to non-activities, which bpmn-moddle silently accepts, and
  sequence-flow conditions missing the `=` FEEL prefix, which deploy-fails on
  Zeebe). Wraps `bpmnlint:recommended` + `bpmnlint-plugin-process-os` and
  translates each rule into a concrete fix instruction (the CLI emits "what is
  wrong" but never "how to fix"; rule metadata is only available via the Node
  API, so this skill carries the mapping).
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
# BPMN Lint

## Scope

The caller passes a **target** — either a single `.bpmn` file or a directory:

- **Single file** (e.g. `process-transformation/iteration-1/artifacts/00-overview.bpmn`): lint exactly that file.
- **Directory** (e.g. `process-implementation/artifacts/src/main/resources/processes/`): discover every `.bpmn` file beneath it (recursive). Skip these directories during discovery: `.git`, `node_modules`, `target`, `build`, `.gradle`, `.mvn`, `.idea`, `.settings`, `.snapshots`.

If the target is ambiguous, ask once. Otherwise infer from the path (file extension `.bpmn` → single-file mode; anything else → directory mode).

## When to run

Run after every change to a `.bpmn` file in the target and again after each fix round. Only proceed to subsequent steps when lint reports zero errors. The "subsequent step" is whatever the caller is doing — deployment, further generation, review, hand-off — this skill is agnostic to it.

## How to run

The skill ships a `scripts/validate.cjs` wrapper that handles bpmnlint resolution, config and invocation — pass files, nothing else. Read [the bpmnlint invocation reference](references/lint-bpmn.md) for the full invocation reference including the exit-code contract.

```bash
# Single-file mode
node .github/skills/process-os-bpmn-linting/scripts/validate.cjs path/to/file.bpmn

# Directory mode — pass the discovered files explicitly so skip-dirs are honoured
node .github/skills/process-os-bpmn-linting/scripts/validate.cjs <space-separated list of discovered .bpmn files>
```

## Output shape

```
process.bpmn
  Process_1  error    Process is missing end event   end-event-required
  Task_1     warning  Element is missing label/name  label-required

✖ 2 problems (1 error, 1 warning)
```

Format per report line: `<elementId>  <severity>  <message>  <ruleId>` (severity is `error` or `warning`; columns are separated by 2+ spaces). Lines starting with `✖` are summary only — ignore.

## Fix loop

1. For each affected file, locate before editing — never `Read` the whole file (a connector-bound BPMN may run over the Read tool's ~25 KB cap):
   - Extract once for context: `node ".github/skills/process-os-bpmn-linting/scripts/bpmn-extract.cjs" "<file>"` — gives every element's current name, type, job type, form key, template and documentation, so you know what the fix should contain before touching the file. Exit `2` → bad input (missing path, or the file is not well-formed XML) — report stderr and stop; a file that will not parse is a finding in its own right, not a step to skip past. Exit `3` → the report is over the cap — re-run with `--names` (drops job type, form key, template, call activity target and documentation, so the bounded `Read` below becomes the only source for those).
   - For each reported issue, locate its edit site — the report gives an `elementId` but no line number. Run `node ".github/skills/process-os-bpmn-linting/scripts/search-files.mts" --pattern 'id="<elementId>"' --fixed "<file>"` to find the element's own tag (never a raw `grep` — it isn't available on native Windows PowerShell). For a diagram-only rule (`no-bpmndi`, `no-overlapping-elements`), search for `bpmnElement="<elementId>"` instead — no match means the shape doesn't exist yet and must be inserted, not edited.
   - `Read` the file with a bounded `offset`/`limit` window around the located line, wide enough to cover the whole element (open tag through close tag). This also satisfies `Edit`'s requirement that the file be `Read` first.
2. For every reported issue, apply the fix instruction below (table) using a targeted Edit/patch — never rewrite the whole file.
3. Re-run lint against the same target (single file or discovered set).
4. Repeat until the run is clean. **Fix all errors. Fix warnings unless there is a deliberate reason to keep them.**
5. Then return control to the caller — they decide what comes next (deployment, further generation, review, …).

### Parallel dispatch (>3 files)

If the discovered set has **more than 3 `.bpmn` files with reported issues**, do NOT fix them serially in the orchestrator session. Spawn one `Agent` (subagent_type `general-purpose`) per file (or batch of up to 3 files that share an obvious root cause) so fixes run in parallel. This is explicitly wanted — the per-file fix work is independent and the orchestrator session should not be flooded with raw lint output across many files.

Each dispatched agent receives:
- The exact file path(s) it owns.
- The lint output for those files only (filtered).
- A pointer back to this skill's rule table so it applies the same fix instructions.
- Instruction to re-run `node .github/skills/process-os-bpmn-linting/scripts/validate.cjs <its files>` until clean and report back: files touched, rules fixed, final status.

After all parallel agents return, run a single consolidated `node .github/skills/process-os-bpmn-linting/scripts/validate.cjs <all files>` from the orchestrator to confirm the whole set is clean before reporting done.

For 3 or fewer files with issues, fix serially in the current session — the parallel-dispatch overhead isn't worth it.

## Rule → fix instruction (bpmnlint:recommended + ProcessOS rules)

| Rule | Fix |
|---|---|
| `process-os/boundary-event-attached-to-activity` | Boundary events must attach to an Activity (Task / SubProcess / CallActivity). If the host is currently an event (StartEvent / IntermediateCatchEvent / EndEvent), refactor: for a wait-OR-timeout pattern use an event-based gateway with a message catch + timer catch alternative; for a non-interrupting reminder around a message catch, wrap the catch in a sub-process and attach the boundary event to the sub-process. |
| `process-os/condition-expression-feel-prefix` | Prefix the condition expression body with `=` so Zeebe evaluates it as FEEL (e.g. `not(approvalNeeded)` → `=not(approvalNeeded)`). If the conditionExpression is empty, either add a FEEL expression or remove it and mark the flow as the default flow on its source gateway/activity. |
| `process-os/event-subprocess-must-be-expanded` | Give every event subprocess (`triggeredByEvent="true"`) a `BPMNShape` with `isExpanded="true"`. Do not collapse it; collapsed event subprocesses are not authorable in Camunda Modeler. Ordinary embedded subprocesses may remain collapsed. |
| `process-os/one-process-per-resource` | Keep one root process in the BPMN resource. For reusable work, move the called process to a separate BPMN resource and invoke it with a Call Activity. For contained work, use an embedded subprocess. Multiple root processes are allowed only in a collaboration where every process has a participant and the BPMN DI plane references the collaboration. |
| `ad-hoc-sub-process` | Remove start and end events from the ad-hoc sub-process; ensure every intermediate catch event has an outgoing sequence flow. |
| `conditional-flows` | Add a condition expression or designate a default flow. |
| `end-event-required` | Add an End Event to every process/subprocess. |
| `event-based-gateway` | Ensure the event-based gateway has at least 2 outgoing sequence flows and none are conditional. |
| `event-sub-process-typed-start-event` | Add an event definition (Message, Timer, Error, …) to the Event Sub-Process Start Event. |
| `fake-join` | Add a joining gateway before this element with multiple incoming flows. |
| `global` | Ensure global Error/Escalation/Message/Signal elements are named, referenced by at least one element, and unique per type. |
| `label-required` | Add a descriptive name/label to this element. |
| `link-event` | Name every link event definition and ensure each link throw event has a matching catch event in the same scope. |
| `no-bpmndi` | Add BPMNDI graphical information for this element so it is visible in modeling tools. |
| `no-complex-gateway` | Replace Complex Gateways with Exclusive + Parallel combinations. |
| `no-disconnected` | Connect this element with sequence flows. |
| `no-duplicate-sequence-flows` | Remove the duplicate sequence flow between source and target. |
| `no-gateway-join-fork` | Split into separate join and fork gateways. |
| `no-implicit-end` | Add an explicit End Event — do not let tokens silently drop off. |
| `no-implicit-split` | Add an explicit Parallel or Exclusive Gateway before the multiple outgoing flows. |
| `no-implicit-start` | Add an explicit Start Event — do not let elements spawn tokens implicitly. |
| `no-inclusive-gateway` | Replace with Parallel or Exclusive Gateways — Inclusive Gateways are discouraged. |
| `no-overlapping-elements` | Rearrange elements so they do not visually overlap — ensure sufficient spacing. |
| `single-blank-start-event` | Ensure exactly one blank (untyped) Start Event. |
| `single-event-definition` | Use at most one event definition per event; split if needed. |
| `start-event-required` | Add a Start Event to the process. |
| `sub-process-blank-start-event` | Remove the event definition from the sub-process Start Event — it must be blank. |
| `superfluous-gateway` | Remove this gateway — it has only one in and one out flow. |
| `superfluous-termination` | Replace the Terminate End Event with a normal End Event — no other tokens exist to cancel. |

For any rule not in this table: review and fix according to BPMN 2.0 best practices. Report the missing rule and the message back to the user to get a fix instruction. Create a GitHub issue in the camunda/camunda-os-cli repo if the rule is missing from this list.

## Note on diagram interchange

`no-bpmndi` and many "missing element" issues stem from incomplete `<bpmndi:BPMNDiagram>`. Every flow node needs a `BPMNShape`, every sequence flow a `BPMNEdge` — partial diagrams render broken in modelers and trip the linter.
