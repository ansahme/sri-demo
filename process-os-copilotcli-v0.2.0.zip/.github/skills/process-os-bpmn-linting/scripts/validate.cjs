#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Validate BPMN files using bpmnlint:recommended + bpmnlint-plugin-process-os.
// Writes .bpmnlintrc inline so the skill ships no dotfile that packaging would
// silently drop.
//
// Usage:  node scripts/validate.cjs <file.bpmn>...
//
// bpmnlint is looked up under `.camunda/node_modules` (where `c8 os install`
// puts the pinned version), then the project root; if it is in neither,
// `npx --yes bpmnlint` is used (zero-install, ~370 ms vs ~65 ms for the pinned
// install). Callers pass no path.
//
// Both roots are resolved against the CWD, which this script does not verify:
// run it from anywhere but the project root and it finds no pinned install and
// takes the npx path silently, unpinned. Callers are expected to run from the
// project root, which is where every agent session starts.
//
// bpmnlint is always run by spawning its JS entrypoint with `process.execPath`,
// never by exec'ing the extensionless `.bin/bpmnlint` shim — that cannot be
// exec'd on Windows (see resolve-node-cli.cjs).
//
// Exit codes: 0 clean, 1 lint issues, 2 usage error OR bpmnlint could not be run.

const path  = require('path');
const fs    = require('fs');
const { resolveNodeCliEntry, runNodeCli, runShellCli } =
  require(path.join(__dirname, 'resolve-node-cli.cjs'));

// The skill root, not this scripts/ dir: `.bpmnlintrc` and `plugins/` live there,
// and process-os-bpmn-generation's lint hook reads that exact .bpmnlintrc path.
const SKILL_DIR = path.resolve(__dirname, '..');
const RC_PATH = path.join(SKILL_DIR, '.bpmnlintrc');

// Inline the static config — content is identical to the former .bpmnlintrc.
fs.writeFileSync(
  RC_PATH,
  JSON.stringify({ extends: ['bpmnlint:recommended', 'plugin:process-os/recommended'] }, null, 2) + '\n'
);

const USAGE = 'Usage: node scripts/validate.cjs <file.bpmn>...\n';

const files = process.argv.slice(2);
if (files.length === 0) {
  process.stderr.write(USAGE);
  process.exit(2);
}

// Resolve relative to caller's cwd before switching context to the skill dir.
const absFiles = files.map(p => path.resolve(p));
for (const f of absFiles) {
  if (!fs.existsSync(f)) {
    process.stderr.write(`File not found: ${f}\n`);
    process.exit(2);
  }
}

// Resolves the JS entry of the bpmnlint installed under .camunda/node_modules,
// then the project root; null when neither has it (npx fallback below).
const entry = resolveNodeCliEntry('bpmnlint');

const runOpts = {
  cwd: SKILL_DIR,
  env: { ...process.env, NODE_PATH: path.join(SKILL_DIR, 'plugins') },
  stdio: 'inherit',
};
const args = ['--config', RC_PATH, ...absFiles];

const result = entry
  ? runNodeCli(entry, args, runOpts)
  // Zero-install fallback: no local bpmnlint to resolve, so there is no JS entry
  // to spawn. npx exists only as a shell wrapper (npx.cmd on Windows), hence the
  // shell — see runShellCli.
  : runShellCli('npx', ['--yes', 'bpmnlint', ...args], runOpts);

// A spawn that never started is neither "clean" nor "findings": reported as exit 1
// (bpmnlint's own findings code) with no output, it reads as a clean pass.
if (!result.launched) {
  process.stderr.write(`bpmnlint could not be started: ${result.error && result.error.message}\n` +
    'These files were NOT linted. Run `c8 os install` (or `c8 os update`) and retry.\n');
  process.exit(2);
}
process.exit(result.status);
