# process-os-bpmn-linting — How to run

The skill ships a `scripts/validate.cjs` wrapper and a zero-install custom rule pack at `plugins/bpmnlint-plugin-process-os/`. The wrapper writes `.bpmnlintrc` inline into the skill root at startup, then invokes bpmnlint with `cwd` set to the skill root so the config and the plugin (via `NODE_PATH`) are always found regardless of where the caller runs from — no project-side `.bpmnlintrc` is touched.

bpmnlint is run by spawning its **JS entrypoint** with the current Node binary, never by exec'ing the extensionless `node_modules/.bin/bpmnlint` shim, which cannot be exec'd on Windows. See [`scripts/resolve-node-cli.cjs`](scripts/resolve-node-cli.cjs).

**Where bpmnlint comes from.** The wrapper takes no bin path — callers pass files only. It looks for bpmnlint under `.camunda/node_modules` (the pinned version `c8 os install` provisions) and then the project root, both resolved against the **current working directory** — not against the script's own location. When it is in neither, the wrapper falls back to `npx --yes bpmnlint` (zero-install, but slower).

**So run it from the project root**, which is where every agent session starts. Nothing in the wrapper enforces that: invoked from anywhere else it finds no pinned install and silently takes the slow `npx` path, with the version unpinned. Passing the script itself as a project-root-relative path — the form cross-skill callers use, `node ".github/skills/process-os-bpmn-linting/scripts/validate.cjs" <files>` — keeps cwd where it belongs; the skill-relative `node .github/skills/process-os-bpmn-linting/scripts/validate.cjs` below is the in-skill shorthand for the same command and does not change cwd.

```bash
# Single-file mode
node .github/skills/process-os-bpmn-linting/scripts/validate.cjs path/to/file.bpmn

# Directory mode — pass the discovered files explicitly so skip-dirs are honoured
node .github/skills/process-os-bpmn-linting/scripts/validate.cjs <space-separated list of discovered .bpmn files>
```

Exit codes: `0` = clean, `1` = lint issues found (parse stdout), `2` = usage error, or bpmnlint could not be started at all (read stderr). Exit `2` means the files were **not** linted — never treat it as clean.
