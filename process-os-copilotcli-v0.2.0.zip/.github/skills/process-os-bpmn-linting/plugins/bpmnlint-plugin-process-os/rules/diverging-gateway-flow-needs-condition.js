/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Inlined from bpmnlint-utils to keep this plugin dependency-free (see
// boundary-event-attached-to-activity.js for the rationale).
function is(element, type) {
  if (!element) return false;
  if (typeof element.$instanceOf === 'function') return element.$instanceOf(type);
  return element.$type === type;
}

/**
 * Rule: diverging-gateway-flow-needs-condition
 *
 * Every outgoing sequence flow of a diverging exclusive gateway must either be
 * the gateway's `default` flow or carry a <bpmn:conditionExpression>. A flow
 * that is neither is unreachable-or-nondeterministic: at runtime Zeebe finds no
 * condition true and no default, and raises an incident ("no outgoing sequence
 * flow could be taken").
 *
 * This is the guard that lets artifact-generation stop synthesizing gateway
 * conditions in its wiring step (wire-execution-bpmn.mts). Branch conditions are
 * authored by the transformation BPMN (process-flow logic); this rule catches a
 * transformation that left a diverging gateway unconditioned, at the §3.6
 * consolidated lint gate — rather than the old behaviour where a per-phase agent
 * silently patched it (or didn't).
 *
 * Fires per offending sequence flow so the report names the exact flow to fix.
 */
module.exports = function() {
  return {
    check(node, reporter) {
      if (!is(node, 'bpmn:SequenceFlow')) return;
      const src = node.sourceRef;
      if (!is(src, 'bpmn:ExclusiveGateway')) return;
      // Only diverging gateways branch; a converging/pass-through gateway with a
      // single outgoing flow needs no condition.
      if (!src.outgoing || src.outgoing.length < 2) return;
      // The default flow is the fallback — it must NOT carry a condition.
      if (src.default === node || src.default === node.id) return;
      if (node.conditionExpression) return;
      reporter.report(
        node.id,
        `Sequence flow out of diverging exclusive gateway <${src.id}> has no ` +
        '<bpmn:conditionExpression> and is not the gateway default — Zeebe will ' +
        'incident when no branch matches. Add a condition, or mark one flow as the ' +
        'gateway default. Branch conditions are authored in the transformation BPMN.'
      );
    }
  };
};
