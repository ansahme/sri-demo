/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Inlined from bpmnlint-utils to keep this plugin dependency-free, so it can
// be loaded via NODE_PATH alongside an npx-installed bpmnlint without needing
// an `npm install` step in the user's project.
function is(element, type) {
  if (!element) return false;
  if (typeof element.$instanceOf === 'function') return element.$instanceOf(type);
  return element.$type === type;
}

/**
 * Rule: condition-expression-feel-prefix
 *
 * Camunda 8 (Zeebe) requires every sequence-flow condition to be a FEEL
 * expression, i.e. its body must start with "=". A body without the "="
 * prefix is treated as a static value — the file parses clean, passes
 * bpmnlint:recommended and camunda-compat, but Zeebe rejects the whole
 * deployment. Because ProcessOS deploys all resources together, one bad
 * condition takes down every process in the bundle.
 *
 * Checked regardless of isExecutable. A strategic (non-executable) diagram is
 * never deployed, but it is not a separate lifecycle: strategic and automatable
 * are two renderings of the same phase docs by the same bpmnkit engine, and a
 * sequence-flow condition is core BPMN — it survives strategic mode's
 * extensionElements strip and is written by the same `.condition("= …")` call
 * in both. The non-executable lint profile is also structural-only
 * (bpmnlint:recommended + plugin:process-os/recommended), so exempting those
 * files would leave this rule running only where camunda-compat already looks.
 */
module.exports = function() {
  return {
    check(node, reporter) {
      if (!is(node, 'bpmn:SequenceFlow')) return;

      const condition = node.conditionExpression;
      if (!condition) return;

      const body = (condition.body || '').trim();
      if (!body) {
        reporter.report(
          node.id,
          'SequenceFlow has an empty conditionExpression — ' +
          'add a FEEL expression starting with "=", or remove the conditionExpression ' +
          'and mark the flow as the default flow on its source gateway/activity'
        );
        return;
      }
      if (!body.startsWith('=')) {
        const preview = body.length > 60 ? body.slice(0, 57) + '...' : body;
        reporter.report(
          node.id,
          'Condition expression must start with "=" (FEEL) — Zeebe treats a non-"=" body ' +
          `as a static value and rejects the deployment; found "${preview}"`
        );
      }
    }
  };
};
