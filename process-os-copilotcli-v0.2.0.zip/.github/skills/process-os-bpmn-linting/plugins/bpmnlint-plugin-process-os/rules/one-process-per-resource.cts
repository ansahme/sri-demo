/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

type ModdleElement = {
  $instanceOf?: (type: string) => boolean;
  $type?: string;
  id?: string;
  rootElements?: ModdleElement[];
  participants?: ModdleElement[];
  processRef?: ModdleElement | string;
  diagrams?: ModdleElement[];
  plane?: { bpmnElement?: ModdleElement | string };
};

type Reporter = {
  report(id: string | undefined, message: string): void;
};

// Inlined from bpmnlint-utils to keep this plugin dependency-free (see
// boundary-event-attached-to-activity.js for the rationale).
function is(element: ModdleElement | null | undefined, type: string): boolean {
  if (!element) return false;
  if (typeof element.$instanceOf === 'function') return element.$instanceOf(type);
  return element.$type === type;
}

function referenceId(reference: ModdleElement | string | undefined): string | undefined {
  return typeof reference === 'string' ? reference : reference?.id;
}

function hasParticipantsForAllProcesses(
  collaboration: ModdleElement,
  processIds: Array<string | undefined>
): boolean {
  const participantProcessIds = new Set(
    (collaboration.participants ?? []).map((participant) => referenceId(participant.processRef))
  );

  return processIds.every((processId) => participantProcessIds.has(processId));
}

function hasDiagramForCollaboration(definitions: ModdleElement, collaboration: ModdleElement): boolean {
  return (definitions.diagrams ?? []).some(
    (diagram) => referenceId(diagram.plane?.bpmnElement) === collaboration.id
  );
}

/**
 * Rule: one-process-per-resource
 *
 * A deployment resource represents one executable process. A called process
 * belongs in its own resource and is invoked through a call activity; placing
 * both as unrelated root processes in one file hides that relationship and
 * makes the resource topology ambiguous. Multiple root processes are only
 * meaningful when they are explicitly represented as a collaboration.
 */
module.exports = function() {
  return {
    check(node: ModdleElement, reporter: Reporter) {
      if (!is(node, 'bpmn:Definitions')) return;

      const rootElements = node.rootElements ?? [];
      const processes = rootElements.filter((element) => is(element, 'bpmn:Process'));
      if (processes.length <= 1) return;

      const processIds = processes.map((process) => process.id);
      const validCollaboration = rootElements.some((element) => (
        is(element, 'bpmn:Collaboration') &&
        hasParticipantsForAllProcesses(element, processIds) &&
        hasDiagramForCollaboration(node, element)
      ));

      if (validCollaboration) return;

      reporter.report(
        node.id,
        'A BPMN resource may contain one process only; multiple processes require a collaboration ' +
        'with participants and a collaboration plane. Model reusable work as a call activity that ' +
        'invokes a process in a separate BPMN resource, or model contained work as an embedded subprocess.'
      );
    }
  };
};
