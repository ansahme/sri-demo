/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

type ModdleElement = {
  $instanceOf?: (type: string) => boolean;
  $parent?: ModdleElement;
  $type?: string;
  bpmnElement?: ModdleElement | string;
  diagrams?: ModdleElement[];
  id?: string;
  isExpanded?: boolean;
  plane?: { planeElement?: ModdleElement[] };
  triggeredByEvent?: boolean;
};

type Reporter = {
  report(id: string | undefined, message: string): void;
};

function is(element: ModdleElement | null | undefined, type: string): boolean {
  if (!element) return false;
  if (typeof element.$instanceOf === 'function') return element.$instanceOf(type);
  return element.$type === type;
}

function definitionsOf(element: ModdleElement): ModdleElement | null {
  let current = element;
  while (current && current.$parent) current = current.$parent;
  return is(current, 'bpmn:Definitions') ? current : null;
}

function shapeOf(
  definitions: ModdleElement | null,
  element: ModdleElement
): ModdleElement | null {
  for (const diagram of definitions?.diagrams ?? []) {
    const planeElements = diagram.plane?.planeElement ?? [];
    for (const planeElement of planeElements) {
      if (is(planeElement, 'bpmndi:BPMNShape') &&
          (planeElement.bpmnElement === element || planeElement.bpmnElement === element.id)) {
        return planeElement;
      }
    }
  }
  return null;
}

/**
 * Rule: event-subprocess-must-be-expanded
 *
 * Camunda Modeler cannot author a collapsed event subprocess. bpmn-auto-layout
 * can produce one by leaving its BPMNShape's `isExpanded` unset, so reject that
 * generated form while allowing ordinary collapsed subprocesses.
 */
module.exports = function() {
  return {
    check(node: ModdleElement, reporter: Reporter) {
      if (!is(node, 'bpmn:SubProcess') || node.triggeredByEvent !== true) return;

      const shape = shapeOf(definitionsOf(node), node);
      if (!shape) {
        reporter.report(
          node.id,
          'Event subprocess has no BPMNShape in the BPMN definitions diagrams.'
        );
        return;
      }

      if (shape.isExpanded !== true) {
        reporter.report(
          node.id,
          'Event subprocess BPMNShape must set isExpanded="true"; collapsed event subprocesses are not authorable in Camunda Modeler.'
        );
      }
    }
  };
};
