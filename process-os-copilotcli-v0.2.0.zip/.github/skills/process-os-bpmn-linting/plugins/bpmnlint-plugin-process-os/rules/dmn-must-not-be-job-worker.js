/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Inlined from bpmnlint-utils to keep this plugin dependency-free, so it can
// be loaded via NODE_PATH alongside an npx-installed bpmnlint without needing
// an `npm install` step in the user's project (see
// boundary-event-attached-to-activity.js for the rationale).
function is(element, type) {
  if (!element) return false;
  if (typeof element.$instanceOf === 'function') return element.$instanceOf(type);
  return element.$type === type;
}

// Reserved job-type namespace meaning "this is a DMN". Nothing may use a
// `dmn-` / `dmn:` prefixed type on a job-worker <zeebe:taskDefinition>.
// Connector types (`io.camunda:…`) do not match, so this never fires on a
// connector-bound element.
const DMN_JOBTYPE_RE = /^dmn[-:]/i;

/**
 * Rule: dmn-must-not-be-job-worker
 *
 * A DMN evaluation modeled as a task + <zeebe:taskDefinition> (instead of a
 * <bpmn:businessRuleTask> + <zeebe:calledDecision>) is, per Zeebe semantics, a
 * job worker: the engine creates a job of that type and waits for an external
 * worker — there is no DMN evaluation. Downstream artifact-generation then
 * correctly emits a Java worker for it (analyze-phase reads structure, and a
 * bare taskDefinition IS a worker), so the intended DMN silently becomes a
 * hand-written stub that never evaluates the decision.
 *
 * Observed on the moonshot tier: four "Evaluate the X DMN" tools were authored
 * as serviceTask + type="dmn-ubo-complexity" in process-05, while the identical
 * intent was correctly a businessRuleTask in edge-02 / process-07. This rule
 * makes the mis-authoring a hard error at the AUTHORING gate (the source BPMN,
 * linted by process-os-bpmn-generation), BEFORE artifact-generation name-derives
 * the `dmn-` job type away (`dmn-ubo-complexity` -> `derive-ubo-complexity`) and
 * erases the evidence.
 *
 * Fix: model it as <bpmn:businessRuleTask> with <zeebe:calledDecision
 * decisionId="…" resultVariable="…"/>. If the element genuinely is a job worker
 * and not a DMN, rename its job type out of the reserved `dmn-` prefix.
 */
module.exports = function() {
  return {
    check(node, reporter) {
      const ext = node.extensionElements;
      if (!ext || !ext.values) return;

      // Connector-bound elements are serviced by the connector runtime and
      // carry the template id as their type — skip defensively.
      if (node.modelerTemplate != null) return;
      if (node.$attrs && (node.$attrs['zeebe:modelerTemplate'] != null ||
                          node.$attrs.modelerTemplate != null)) return;

      for (const entry of ext.values) {
        if (!is(entry, 'zeebe:TaskDefinition')) continue;
        // `type` is a typed property when zeebe-bpmn-moddle is loaded (the
        // camunda-compat pipeline); fall back to the lax `$attrs` form so the
        // rule still fires under a vanilla bpmn-moddle parse.
        const type = entry.type != null
          ? entry.type
          : (entry.$attrs && entry.$attrs.type);
        if (typeof type === 'string' && DMN_JOBTYPE_RE.test(type)) {
          reporter.report(
            node.id,
            `<${node.$type}> carries a job-worker <zeebe:taskDefinition type="${type}"> ` +
            'in the reserved "dmn-" namespace — a DMN evaluation must be a ' +
            '<bpmn:businessRuleTask> with <zeebe:calledDecision>, not a job worker ' +
            '(artifact-generation would emit a dead Java worker for it). ' +
            'Change the element type and add zeebe:calledDecision, or rename the ' +
            'job type if it is not a DMN.'
          );
        }
        return; // at most one taskDefinition per element
      }
    }
  };
};
