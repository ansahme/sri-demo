/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Inlined from bpmnlint-utils to keep this plugin dependency-free, so it can
// be loaded via NODE_PATH alongside an npx-installed bpmnlint without needing
// an `npm install` step in the user's project.
function is(element, type) {
  if (!element) return false;
  if (typeof element.$instanceOf === 'function') return element.$instanceOf(type);
  return element.$type === type;
}

/**
 * Rule: boundary-event-attached-to-activity
 *
 * BPMN 2.0 spec requires every <bpmn:boundaryEvent> to attach to an Activity
 * (Task / SubProcess / CallActivity / Transaction / AdHocSubProcess).
 * Attaching a boundary event to another event (StartEvent / IntermediateCatchEvent
 * / IntermediateThrowEvent / EndEvent) is invalid — bpmn-moddle silently
 * resolves the IDref without enforcing the type constraint, so the file parses
 * clean but renders as a "floating" boundary event in modelers and is rejected
 * by Zeebe at deploy time.
 *
 * For the wait-for-message-OR-timeout pattern, use an event-based gateway with
 * a message catch + timer catch. For non-interrupting reminder timers around a
 * message catch, wrap the catch in a sub-process and attach the boundary event
 * to the sub-process.
 */
module.exports = function() {
  return {
    check(node, reporter) {
      if (!is(node, 'bpmn:BoundaryEvent')) return;

      const attachedTo = node.attachedToRef;
      if (!attachedTo) {
        reporter.report(node.id, 'BoundaryEvent has no attachedToRef');
        return;
      }
      if (!is(attachedTo, 'bpmn:Activity')) {
        reporter.report(
          node.id,
          'BoundaryEvent must attach to an Activity (Task / SubProcess / CallActivity); ' +
          `<${attachedTo.id}> is a <${attachedTo.$type}>`
        );
      }
    }
  };
};
