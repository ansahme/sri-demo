/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

/**
 * bpmnlint-plugin-process-os
 *
 * Custom bpmnlint rules shipped with the ProcessOS Claude Code plugin.
 * Bundled and consumed only by the process-os-bpmn-linting skill — not published to npm.
 */

module.exports = {
  rules: {
    // bpmnlint resolves these as paths relative to this file
    'boundary-event-attached-to-activity': './rules/boundary-event-attached-to-activity',
    'condition-expression-feel-prefix': './rules/condition-expression-feel-prefix',
    'dmn-must-not-be-job-worker': './rules/dmn-must-not-be-job-worker',
    'diverging-gateway-flow-needs-condition': './rules/diverging-gateway-flow-needs-condition',
    // .cts: CommonJS with type annotations, stripped by Node at require() time.
    // bpmnlint requires the path as-is and calls the result, so this rule cannot
    // be ESM — require() of an ESM module yields a namespace, not a factory.
    'event-subprocess-must-be-expanded': './rules/event-subprocess-must-be-expanded.cts',
    'one-process-per-resource': './rules/one-process-per-resource.cts'
  },

  configs: {
    recommended: {
      rules: {
        'process-os/boundary-event-attached-to-activity': 'error',
        'process-os/condition-expression-feel-prefix': 'error',
        'process-os/dmn-must-not-be-job-worker': 'error',
        'process-os/diverging-gateway-flow-needs-condition': 'error',
        'process-os/event-subprocess-must-be-expanded': 'error',
        'process-os/one-process-per-resource': 'error'
      }
    }
  }
};
