---
name: process-os-process-instance-start
description: >-
  Start a Camunda process instance with variables. Use when testing or launching
  a process.
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
Start a process instance. $ARGUMENTS

Read `references/c8ctl.md` for the full c8ctl reference. Set output to JSON once per session before invoking any of the verbs below:

```bash
c8ctl output json
```

## Three verbs, pick the one that fits

**Start an instance, return immediately** (most common):

```bash
c8ctl create pi --id <bpmnProcessId> --variables '{"key": "value"}'
```

`--id` is the BPMN process ID — the value of `<bpmn:process id="…">` in the deployed BPMN, not the numeric process-definition key. Use `--processDefinitionId` / `--processDefinitionKey` for the numeric form.

The returned JSON includes `processInstanceKey` — capture it for follow-up `c8ctl get pi <key>` polling.

**Deploy + start in one shot** (single BPMN file, no Java module):

```bash
c8ctl run <path-to.bpmn>
```

Useful for quick standalone smoke tests where the BPMN isn't part of an artifact bundle.

**Start an instance and block until it terminates** (autonomous-loop friendly):

```bash
c8ctl await pi --id <bpmnProcessId> --variables '{"key": "value"}'
```

Returns when the instance reaches a terminal state (COMPLETED / TERMINATED / FAILED). On FAILED, follow up with `c8ctl list inc --filter '{"processInstanceKey": "<key>"}'` to find the incident — see `references/c8ctl.md` for the full incident workflow.

## Polling and cancelling

```bash
c8ctl get pi <key>                # snapshot of one instance
c8ctl list pi --fields processInstanceKey,bpmnProcessId,state
c8ctl cancel pi <key>             # terminate a stuck instance
```

Use `--fields` to trim list responses — see `references/c8ctl.md` "Agent flags".

Run `c8ctl help create pi` for all flags.
