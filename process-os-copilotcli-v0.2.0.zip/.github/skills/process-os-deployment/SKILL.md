---
name: process-os-deployment
description: >-
  Deploy a generated process application to a Camunda 8 cluster — the deployment
  lifecycle phase. Orchestrates two building blocks against a version-matched
  cluster — process-os-deployment-resources (BPMN/DMN/forms to the engine), then
  process-os-deployment-code (boot the Java workers and confirm each connects to
  its task). Resolves camunda-version and provisions the version-named c8ctl
  profile once, up front, for both halves. Run it as the production deployment
  after process-os-test-suite (advances the lifecycle), or with --validate for a
  non-advancing test-wise check that a freshly generated bundle is
  engine-deployable (used by process-os-artifact-generation).
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
# /process-os-deployment

The **deployment lifecycle phase**, and a thin **orchestrator** over two reusable
building blocks:

1. **`process-os-deployment-resources`** — deploy BPMN/DMN/forms to the engine.
2. **`process-os-deployment-code`** — boot the Java workers and confirm each
   subscribes to its BPMN job type.

This skill owns what is shared across both halves — version/profile resolution
(Step 0), the resources→code gate, and the lifecycle-state write — so the two
building blocks stay pure (they take the profile as input and write no lifecycle
state, which is what makes them independently reusable).

All cluster operations go through **c8ctl**; `mvn spring-boot:run` (inside
`-code`) only runs the workers.

## Modes

- **Production (default)** — run after `/process-os-test-suite`. Deploys against
  the target cluster and **advances** the `process-os-deployment` lifecycle phase.
- **`--validate`** — a non-advancing, test-wise check that a freshly generated
  bundle is engine-deployable (invoked by `/process-os-artifact-generation`
  against a local/throwaway cluster). Runs both building blocks but **skips the
  lifecycle write** (Step 3). Nothing is marked done; this is a quality gate, not
  the deployment milestone.

> **Nested skills don't end your turn.** Steps 1–2 invoke other skills. When a
> building block returns (with its own completion summary), that is a step
> result — continue with the next step here. Only stop where THIS skill says to
> (the Step 1 gate, or the final Report).

## EXEC: Step 0 — Resolve the target version + cluster profile

Deploy against a cluster matching the project's **TO-BE** `camunda-version`, and
address it through an explicit c8ctl profile. (When more than one profile is
configured, `c8ctl deploy` refuses to run without `--profile` — so a named
profile is required, not optional.) Resolve both once here; the building blocks
consume `<PROFILE>`, and Step 2 additionally consumes `<SPRING_PROFILE>` (below).

```bash
node ".github/skills/process-os-deployment/scripts/resolve-camunda-version.cjs" run.config.yaml
```

**`<CAMUNDA_VERSION>` and `<PROFILE>` are values you carry, not shell variables.**
A shell variable does not survive across the building-block invocations, and
`$PROFILE` is a *built-in* variable in PowerShell (the profile-script path), so
`--profile "$PROFILE"` there silently deploys against a nonsense profile name
rather than failing. `<CAMUNDA_VERSION>` is what the resolver printed. `<PROFILE>`
is `Camunda<CAMUNDA_VERSION>` **only when you provision the profile yourself in
this step** — see "Caller-supplied profile" immediately below for the other
case. `<SPRING_PROFILE>` (resolved further below) is carried the same way, to
Step 2. Substitute all three literally into every command below and into the
building blocks you invoke.

**Caller-supplied profile.** If the caller already named a profile (e.g.
`/process-os-artifact-generation`'s deployability gate found a reachable cluster
and named one), `<PROFILE>` is **that name** — not `Camunda<CAMUNDA_VERSION>`.
Honor it as `<PROFILE>`: skip the cluster-start / `add profile`
below and just confirm reachability with `c8ctl get topology --profile "<PROFILE>"`.
Only resolve/provision a profile yourself when the caller didn't supply one.

`camunda-version` is `8.8` | `8.9` | `8.10`, default `8.10` (the resolver exits 0
with the default when the config is absent or omits the key). **Exit 2 means no
version was resolved — there is no `<CAMUNDA_VERSION>` and `<PROFILE>` would
degrade to a bare `Camunda`, so stop rather than deploying.** Either the config
names an unsupported/unquoted version (have the user fix it), or the project's
Node deps are missing (`c8 os install`) and the configured version could not be
read at all — never assume the default in that case.

Then make `<PROFILE>` point at the cluster to deploy to:

- **Local (default; the norm for `--validate`).** Ensure a local cluster of the
  target version is running, then register the profile:

  ```bash
  c8ctl cluster status                         # is a cluster running, and on what version?
  # If a DIFFERENT version is already running, do NOT stop it without asking —
  # surface the mismatch and let the user pick (validate on the running version,
  # or stop it and start <CAMUNDA_VERSION>). Otherwise:
  c8ctl cluster start "<CAMUNDA_VERSION>"       # first run downloads; later runs reuse the cache
  c8ctl list profile --json                     # is <PROFILE> already registered?
  c8ctl add profile "<PROFILE>" --baseUrl http://localhost:8080/v2   # only if it isn't listed above
  ```

  (First-time local install of Java/c8ctl is `/process-os-environment-setup`.)

- **Qualified SaaS / self-managed cluster (typical for production).** Reuse the
  engagement's existing profile instead of creating a local one — take
  `<PROFILE>` to be that profile's name (see it in `c8ctl list profile`, or
  `.camunda/governance.json` → `c8ctl-profile`). Confirm its cluster version
  matches `<CAMUNDA_VERSION>`; a mismatch is worth surfacing before deploying. See
  `references/env-saas.md` for first-time SaaS profile setup.

**`<SPRING_PROFILE>` — the worker app's own connection config.** `<PROFILE>` tells
c8ctl which cluster to *deploy* to; it says nothing about how the worker app Step 2
boots connects to that same cluster. That comes from a Spring profile, and the
generated app ships exactly two (`process-implementation/artifacts/src/main/resources/application-*.yaml`).
You have just established which cluster is the target, so resolve the matching one
here too rather than leaving Step 2 on its default:

| Target cluster (the case you picked above) | `<SPRING_PROFILE>` | Env vars that profile reads |
|---|---|---|
| Local c8run, **or** a self-managed cluster | `local` (the default) | `CAMUNDA_CLIENT_GRPC_ADDRESS`, `CAMUNDA_CLIENT_REST_ADDRESS`, `CAMUNDA_CLIENT_AUTH_USERNAME`, `CAMUNDA_CLIENT_AUTH_PASSWORD` |
| Camunda 8 **SaaS** | `saas` | `CAMUNDA_CLIENT_ID`, `CAMUNDA_CLIENT_SECRET`, `CAMUNDA_CLOUD_CLUSTER_ID`, `CAMUNDA_CLOUD_REGION` |

The `local` profile is `camunda.client.mode: selfmanaged`, so it is also the right
one for a **remote** self-managed cluster — point its `CAMUNDA_CLIENT_*_ADDRESS`
vars at that cluster rather than switching profile. Only SaaS needs `saas`.

Carry all three resolved values into the building blocks below — tell each one the
`<PROFILE>` name explicitly rather than relying on an inherited environment.

## EXEC: Step 1 — Deploy resources (gate)

Invoke the **process-os-deployment-resources** skill. It lints, deploys
`process-implementation/artifacts/src/main/resources/{processes,forms,decisions}` with `--profile
"<PROFILE>"`, smoke-tests the main process, and triages any failure (Class A
inline / Class B generator defect).

**Gate:** if resources do not deploy (a Class B generator defect, or an
unresolved rejection), **stop here** — there is no point booting workers against
a cluster with no process definitions. Surface the triage and, in production
mode, leave the `process-os-deployment` phase unadvanced.

## EXEC: Step 2 — Deploy code (workers)

Invoke the **process-os-deployment-code** skill. Given `<PROFILE>` and
`<SPRING_PROFILE>`, it statically cross-checks `@JobWorker` types against the
deployed BPMN job types, boots the worker app (`mvn spring-boot:run` under
`<SPRING_PROFILE>`), confirms a live subscription per job type, and triages
failures with the same Class A / B classification.

Pass `<SPRING_PROFILE>` explicitly whenever it is not `local` — the skill's
default is `local`, so a SaaS deployment left unstated boots workers that try to
reach a self-managed cluster and fail with `io.grpc … UNAVAILABLE` against a
cluster the resources deployed to perfectly well in Step 1.

## EXEC: Step 3 — Lifecycle update (production only)

**Skip this step entirely under `--validate`** — a validation run advances
nothing.

Otherwise, if `.camunda/state.md` exists, update the single
`process-os-deployment` row:
- Resources deployed AND every BPMN job type has a live worker, no Class B defect
  outstanding → Status `✅ Done`, Completed today, Key Output the deployment key
  + worker count.
- Anything excluded/unfixed → `⚠️ Partial` (or leave `⏳ Next` if nothing
  deployed), do not mark done. The phase table has no free-text column — record
  what was excluded or unfixed in the `.camunda/audit.md` entry instead.
- On `✅ Done`, `process-os-deployment` is the last lifecycle phase: there is no
  next phase to set `⏳ Next`. Replace the Next Step line with the literal
  `Lifecycle complete — monitor production via c8ctl, Operate and Optimize.`
- Either way, append an audit entry to `.camunda/audit.md`.

## Report

```
Deployment — Camunda <version> (<profile>)  [production | --validate]

  resources:  <deploy key or FAILED>
  code:       app boot <ok/failed>; <K>/<M> job types have a live worker

  Lifecycle:  process-os-deployment → ✅ Done   (omitted under --validate)

Triage (if any):
  - <item>: Class A — <inline fix>  |  Class B — <generator defect + where fixed>

Next:  none — process-os-deployment is the last lifecycle phase; monitor
       production via c8ctl, Operate and Optimize   (printed only on ✅ Done)
```

If resources didn't deploy, any job type lacks a live worker, or a Class B defect
is unfixed, say so plainly — do not report a clean deployment.
