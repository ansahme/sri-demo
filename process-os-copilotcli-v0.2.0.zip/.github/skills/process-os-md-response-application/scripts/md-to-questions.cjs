#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Fold answers from a questions `.md` back into the ProcessOS questions store — the MARKDOWN
// PROJECTION's inbound half, and the inverse of process-os-questions-md-export.
//
// Writes ONLY the fields whoever ANSWERS owns: `answer`, `status`, and — when the
// `.md` carries a dated `**Status:** answered <YYYY-MM-DD>` marker — that date into `updated`.
// Question text is read from the `.md` for the identity check and never written back, and the
// remaining question prose is not read at all: the store owns it, so an SME who edits a question in
// the projection is reported rather than silently promoted into the source of truth.
//
// Deterministic; idempotent — questions-schema.cjs's applyAnswers gate (via
// foldAnswersFromMarkdown) drops answers aimed at a question the store already considers settled,
// so re-running with the same `.md` is a no-op.
//
// Two outcomes are refusals rather than reports, and only one of them:
//
//   mismatched  REFUSED (exit 4, nothing written). A question's text in the `.md` differs from the
//               store's, so this file was rendered from a different version of the store and its
//               positional `q<N>` join key no longer identifies the same question. Folding it
//               would write an answer onto the wrong question.
//   missing     REPORTED. A store question with no block in the `.md` is a legitimate input: an
//               operator can hand an SME the questions in their area and fold back what comes home.
//
// `--dry-run` reports what the `.md` WOULD do to the store and writes nothing, so a caller holding
// more than one answer source (the Tasklist questionnaire and a returned spreadsheet answer these
// same questions) can compare them before any of them is applied. The mismatch guard still runs
// first, so a `.md` a real fold would refuse can never contribute a phantom answer to that
// comparison.
//
// Usage: node md-to-questions.cjs [--dry-run] <answered.md> <target.yaml>
//
// Exit codes:
//   0  applied, or reported under --dry-run (possibly zero answers — an untouched `.md` is a
//      valid no-op)
//   2  usage error (missing/unknown argument, missing input file)
//   3  runtime/IO failure
//   4  REFUSED: the `.md`'s question text does not match the target store, so nothing was applied
//      and the store is untouched. Its own code, following the precedent in
//      read-job-input.cjs (codes 4+ for "the input itself is broken", kept
//      distinct from the routine failures below it) and matching
//      process-os-xlsx-response-application's stale-workbook code: a caller must be able to tell
//      "this Markdown is from an older version of the store, re-export it" from "the file wasn't
//      there".
//   5  the target store parses but does not match the schema
//   6  the target store is not valid YAML

'use strict';

const fs = require('fs');
const path = require('path');
const store = require(path.join(__dirname, 'questions-yaml.cjs'));
const { foldAnswersFromMarkdown, parseAnswerBlocks } = require(path.join(__dirname, 'questions-md.cjs'));
const { formatAnswerCounts } = require(path.join(__dirname, 'questions-schema.cjs'));

const MISMATCH_CODE = 'QUESTION_TEXT_MISMATCH';
const EXIT_FOR_CODE = { [MISMATCH_CODE]: 4, QUESTIONS_INVALID: 5, QUESTIONS_UNPARSEABLE: 6 };

function usage(message) {
  return Object.assign(new Error(message), { code: 'USAGE' });
}

function parseArgs(argv) {
  const dryRun = argv.includes('--dry-run');
  const rest = argv.filter((a) => a !== '--dry-run');
  const unknownFlag = rest.find((a) => a.startsWith('--'));
  if (unknownFlag) throw usage(`unknown option ${unknownFlag} (the only option is --dry-run)`);
  const [mdPath, storePath] = rest;
  if (!mdPath) throw usage('no input .md path given — pass the answered questions Markdown');
  if (!storePath) throw usage('no target store path given — pass the questions .yaml to write answers into');
  if (rest.length > 2) throw usage(`unexpected argument ${rest[2]}`);
  return { dryRun, mdPath, storePath };
}

function truncate(value, max = 80) {
  const s = String(value == null ? '' : value);
  return s.length <= max ? s : `${s.slice(0, max)}...`;
}

function mismatchError(mismatched, doc, blocksById) {
  const first = mismatched[0];
  const expected = new Map(
    (doc.sections || []).flatMap((s) => (s.questions || []).map((q) => [q.id, q.text])),
  );
  return Object.assign(
    new Error(
      `question text does not match the target store for ${mismatched.length} question(s) ` +
        `[${mismatched.join(', ')}] — nothing was applied.\n` +
        `  ${first}: expected "${truncate(expected.get(first))}"\n` +
        `  ${first}: found    "${truncate(blocksById.get(first))}"\n` +
        'This Markdown was rendered from a different version of the questions store. The ' +
        '`### Q<N>:` headings no longer identify the same questions, so folding it would write ' +
        'answers onto the wrong ones. Re-export the Markdown from the current store with ' +
        'process-os-questions-md-export, then re-collect or re-enter the answers.'
    ),
    { code: MISMATCH_CODE, mismatched }
  );
}

function run(mdPath, storePath, { dryRun = false } = {}) {
  if (!fs.existsSync(mdPath)) throw usage(`missing ${mdPath}`);
  if (!fs.existsSync(storePath)) throw usage(`missing ${storePath}`);

  const mdText = fs.readFileSync(mdPath, 'utf8');
  const doc = store.read(storePath);
  const result = foldAnswersFromMarkdown(mdText, doc);

  if (result.mismatched.length > 0) {
    // Refused before any write, so the store is byte-for-byte unchanged. The guard runs on the
    // --dry-run path too: a caller comparing this against another answer source must not be handed
    // answers from a file a real fold would refuse.
    const blocksById = new Map(parseAnswerBlocks(mdText).map((b) => [b.id, b.text]));
    throw mismatchError(result.mismatched, doc, blocksById);
  }

  if (dryRun) {
    // The answers keyed by id, with their texts — a caller weighing two sources against each other
    // needs the text, not just the count. Every answer here is real human input: the render leaves
    // an open question's answer region holding only the `[write your answer here]` placeholder,
    // which the answer-region scan excludes, so a value can only have been typed.
    const answers = {};
    for (const id of result.written) {
      const q = (result.doc.sections || [])
        .flatMap((s) => s.questions || [])
        .find((x) => x.id === id);
      answers[id] = q ? q.answer : '';
    }
    return {
      source: 'md',
      target: storePath,
      answers,
      alreadyAnswered: result.alreadyAnswered,
      blank: result.blank,
      missing: result.missing,
    };
  }

  store.write(storePath, result.doc);
  return {
    written: result.written,
    alreadyAnswered: result.alreadyAnswered,
    blank: result.blank,
    missing: result.missing,
  };
}

function main() {
  let plan;
  try {
    plan = parseArgs(process.argv.slice(2));
  } catch (e) {
    process.stderr.write(
      `md-to-questions: ${e.message}\n` +
        'Usage: md-to-questions.cjs [--dry-run] <answered.md> <target.yaml>\n'
    );
    process.exit(2);
    return;
  }
  try {
    const result = run(plan.mdPath, plan.storePath, { dryRun: plan.dryRun });
    if (plan.dryRun) {
      // JSON, not the prose count line: the caller is another skill comparing this against a
      // second answer source, so it needs the answer texts machine-readably.
      process.stdout.write(JSON.stringify(result, null, 2) + '\n');
      return;
    }
    // The same three counts, in the same shared phrasing, that every other import path prints.
    let line = `md-to-questions: wrote ${formatAnswerCounts(result)} -> ${plan.storePath}`;
    // The fourth count is this projection's own, and it is never folded into the others: a
    // question the `.md` did not carry was not answered, but it was also not asked, so calling it
    // "still blank" would be a different statement. Reported only when it happened, since a full
    // render leaves it empty and a `0 not in the file []` on every run would be noise.
    if (result.missing.length > 0) {
      line += `\nmd-to-questions: ${result.missing.length} question(s) not in the file [${result.missing.join(', ')}] — left untouched`;
    }
    process.stdout.write(`${line}\n`);
  } catch (e) {
    process.stderr.write(`md-to-questions: ${e.message}\n`);
    process.exit(e.code === 'USAGE' ? 2 : EXIT_FOR_CODE[e.code] || 3);
  }
}

if (require.main === module) main();

module.exports = { parseArgs, run, MISMATCH_CODE };
