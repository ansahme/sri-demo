/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// The MARKDOWN PROJECTION of the ProcessOS questions store, in both directions.
//
//   renderMarkdown(doc)                    store  -> `.md`
//   foldAnswersFromMarkdown(mdText, doc)    `.md` -> store   (answers only)
//
// The store (questions-yaml.cjs, schema in questions-schema.cjs) is the source of truth for
// review questions. This file owns one rendering of it and nothing else: no answer
// state is decided here, no question is selected here, and nothing outside this file reads the
// `.md` for content the store already holds.
//
// The `.md` is generated only when a skill is asked for it (process-os-questions-md-export), never
// as a side effect of a phase: a file that reappears on its own can be overwritten between an SME
// opening it and answering it, and it invites treating whichever file is newer as authoritative.
// process-os-md-response-application folds a returned one back.
//
// Why there is still a reader here
// ────────────────────────────────
// The `.md` is writable-back — an SME who was handed one answers in it — so the fold needs to read
// the answer region and the `**Status:**` marker out of a file a human has edited. That is
// `parseAnswerBlocks`, and it is deliberately the smallest reader that supports the fold: the join
// key, the question text, the answer region, and the status line — no offsets, no
// section or Confidence/Impact parsing. Those values live in the store; reading them back out of a
// rendering of the store is how two copies of one fact start to disagree.
//
// The four content exclusions
// ───────────────────────────
// A Markdown answer region mixes SME-authored answer text with scaffolding authored WITH the
// question, in one text region, so the reader has to tell them apart line by line:
//
//   [write your answer here]   PLACEHOLDER      the open-question prompt
//   AI Proposal: …             PROPOSED_RE      the proposal offered to the SME
//   an empty `**Label:**`      BARE_LABEL_RE    e.g. a `**Risks:**` sub-heading in an answer
//   `---` / `***` / `___`      HRULE_RE         ends the block, keeping the file footer out of the
//                                              last answer region
//
// Every one is load-bearing in the same direction: miscount any of them and a question nobody has
// answered reads as settled, so it silently never reaches the SME. The store needs none of this —
// `answer` and `status` are separate fields that are read, not inferred — which is exactly why it
// is the source of truth and this is a projection.
//
// The renderer's escaping (`answerLineIsLost`) mirrors the same set, because a stored answer may
// legitimately contain any of those shapes. The two are asserted against each other in
// questions-md.test.cjs rather than restating the list.
//
// Exports:
//   renderMarkdown(doc) -> string — a store document rendered as questions Markdown
//   foldAnswersFromMarkdown(mdText, doc) -> { doc, written, alreadyAnswered, blank,
//                                             mismatched, missing }
//   parseAnswerBlocks(mdText) -> [{ num, id, text, hasAnswerText, answerText, markedAnswered,
//                                   status }]
//   PLACEHOLDER, QUESTION_RE

// Peer require: questions-schema.cjs is a true sibling both in-place and once bundled
// (bundle-dists copies a shared script's own further shared-script dependencies as peers into
// a consuming skill's scripts dir too).
const schema = require('./questions-schema.cjs');

const QUESTION_RE = /^### Q(\d+):\s*(.*)$/;
const HEADING_RE = /^#{1,3}\s/;
const ANSWER_RE = /^\*\*Answer:\*\*\s*$/;
const PROPOSED_RE = /^AI Proposal:\s?(.*)$/;
// A status line settles a question when it BEGINS with `answered`, so the dated
// `answered <YYYY-MM-DD>` shape ProcessOS has always written counts. Deliberately looser than the
// store's own `markedAnswered`, which is an exact match against the `status` ENUM: this side reads
// `.md` text a human hand-typed, where the dated and capitalised variants are real. Bridging the
// two is this module's job — see statusDisplayText going out and updatedFromRawStatus coming in.
const STATUS_ANSWERED_RE = /^\*\*Status:\*\*\s*answered\b/i;

// The `**Status:**` line's raw value, so the fold can recover a dated marker's date into the
// store's structured `updated` field — a boolean cannot carry a date. Scanned independently of
// STATUS_ANSWERED_RE rather than derived from whichever line that matched: this captures the FIRST
// status line in the region whatever it says, which is the honest reading of "the block's status",
// while the settling verdict stays STATUS_ANSWERED_RE's alone.
const STATUS_VALUE_RE = /^\*\*Status:\*\*\s*(.*)$/i;
// A markdown horizontal rule (`---`, `***`, `___`) — a thematic break, so it closes a question
// block exactly like a heading does. Load-bearing for the LAST block in a file: renderMarkdown
// ends the question list with a rule followed by a footer ("Found: 10 questions… "). Without this
// the rule and the whole footer stay inside that block's answer region, so the final question
// folds back as answered with the footer as its answer.
const HRULE_RE = /^(?:-{3,}|\*{3,}|_{3,})$/;
// Block scaffolding that lives *below* `**Answer:**` and is therefore inside the answer region,
// yet is authored WITH the question rather than by whoever answers it.
//
//   BARE_LABEL_RE   an empty `**Label:**` line, no value after the colon. Deliberately does NOT
//                   match a label WITH a value, so a `**Status:** answered` line below
//                   `**Answer:**` still counts as text (it is not where the marker belongs — see
//                   renderQuestionBlock).
const BARE_LABEL_RE = /^\*\*[^*]+:\*\*$/;
const PLACEHOLDER = '[write your answer here]';

/**
 * Read the answer state out of a questions `.md`.
 *
 * The smallest reader `foldAnswersFromMarkdown` can work from, per `### Q<N>:` block:
 *
 *   id / num        the join key, from the heading's own number
 *   text            the identity guard's evidence (compared, never written back)
 *   answerText      the answer region's surviving content, newline-joined and trimmed
 *   hasAnswerText   whether that content is non-empty
 *   markedAnswered  whether a `**Status:** answered` line sits ABOVE `**Answer:**`
 *   status          that line's raw text, or '' — the boolean cannot carry a dated marker's date,
 *                   and the fold recovers it into the store's `updated`
 *
 * `hasAnswerText` is derived from `answerText` rather than tracked alongside it — one scan, one
 * exclusion set, no way for a caller reading the text to disagree with the flag.
 *
 * @param {string} mdText
 * @returns {object[]}
 */
function parseAnswerBlocks(mdText) {
  // CRLF is stripped per line rather than up front, and both matter. The line-anchored regexes
  // above cannot match a line with a trailing CR — `.` does not match `\r` and JS `$` without /m
  // only matches true end-of-input — so on a CRLF file every block would vanish and the fold
  // would report nothing at all, silently. Reachable without doing anything unusual: the repo's
  // root .gitattributes (`* text=auto eol=lf`) normalizes git's own checkout/add path for `.md`
  // files, but it can't reach an editor's live save — an SME answering in a Windows editor can
  // still write CRLF back to disk before the file is ever committed or re-checked-out.
  const lines = String(mdText == null ? '' : mdText)
    .split('\n')
    .map((l) => (l.endsWith('\r') ? l.slice(0, -1) : l));

  const headings = [];
  for (let i = 0; i < lines.length; i++) {
    if (QUESTION_RE.test(lines[i])) headings.push(i);
  }

  const blocks = [];
  for (const i of headings) {
    const m = lines[i].match(QUESTION_RE);
    const num = Number(m[1]);

    // The block ends at the next markdown heading (## section or ### question), the next
    // horizontal rule, or EOF.
    let endLine = lines.length;
    for (let j = i + 1; j < lines.length; j++) {
      if (HEADING_RE.test(lines[j]) || HRULE_RE.test(lines[j].trim())) {
        endLine = j;
        break;
      }
    }

    let answerLine = -1;
    for (let j = i + 1; j < endLine; j++) {
      if (ANSWER_RE.test(lines[j])) {
        answerLine = j;
        break;
      }
    }

    // The marker is looked for between the heading and `**Answer:**` only (or across the whole
    // block when there is no marker line at all). That region is otherwise unparsed, so this
    // never overlaps the answer scan below, and a `**Status:**` line written BELOW `**Answer:**`
    // does not count — it is answer content there.
    const statusScanEnd = answerLine === -1 ? endLine : answerLine;
    let markedAnswered = false;
    for (let j = i + 1; j < statusScanEnd; j++) {
      if (STATUS_ANSWERED_RE.test(lines[j])) {
        markedAnswered = true;
        break;
      }
    }

    // The first `**Status:**` line's raw value, kept ALONGSIDE the boolean rather than instead of
    // it. The fold needs the text, not just the verdict: a dated `answered 2026-07-20` marker
    // carries a date that belongs in the store's structured `updated` field, and discarding it
    // here would lose it silently. `markedAnswered` stays its own scan above so its parity with
    // questions-schema's grammar is unaffected by what this captures.
    let status = '';
    for (let j = i + 1; j < statusScanEnd; j++) {
      const sm = lines[j].match(STATUS_VALUE_RE);
      if (sm) {
        status = sm[1].trim();
        break;
      }
    }

    // The answer region: every line below `**Answer:**` that survives the four content
    // exclusions. See this file's header for why each one is load-bearing.
    const answerLines = [];
    if (answerLine !== -1) {
      for (let j = answerLine + 1; j < endLine; j++) {
        const line = lines[j];
        if (PROPOSED_RE.test(line)) continue;
        const t = line.trim();
        if (t === '' || t === PLACEHOLDER) continue;
        if (BARE_LABEL_RE.test(t)) continue;
        answerLines.push(line); // keep the line's own indentation (nested lists, code)
      }
    }
    const answerText = answerLines.join('\n').trim();

    blocks.push({
      num,
      id: `q${num}`,
      text: m[2].trim(),
      hasAnswerText: answerText !== '',
      answerText,
      markedAnswered,
      status,
    });
  }

  return blocks;
}

// ─── store -> `.md` ──────────────────────────────────────────────────────────

const HOW_TO_USE =
  '## How to use\n' +
  'Answer directly under each question. Keep the question text intact.\n' +
  'Partial answers accepted — unanswered questions remain as gaps.\n';

const KIND_TITLES = { review: 'Review Questions' };

/**
 * Render a `**Label:** value` line, or nothing when the value is empty.
 *
 * Emitted on ONE line even when the stored value spans several: a `**Confidence:**` whose
 * continuation lines started at column 0 would parse as part of the next field, and for a field
 * above `**Answer:**` that silently moves text into the block header.
 */
function labelLine(label, value) {
  const v = oneLine(value);
  if (v === '') return '';
  return `**${label}:** ${v}\n`;
}

/**
 * Would this line be LOST if it appeared verbatim inside the answer region?
 *
 * Covers every shape `parseAnswerBlocks`'s answer scan drops or stops at — not just the two that
 * end the block — because the effect on a stored answer is the same either way: the line is not in
 * `answerText`, so the projection shows something other than what the store holds.
 *
 * Mirrors that scan exactly, including which regexes see the RAW line and which see the TRIMMED
 * one. Getting that wrong in either direction would escape a line that did not need it (visible
 * backslash noise) or miss one that did.
 *
 *   HEADING_RE    raw     — needs column 0, so indentation alone defeats it
 *   HRULE_RE      trimmed — indenting a rule does NOT save it
 *   PROPOSED_RE   raw     — the `AI Proposal:` line is authored with the question
 *   PLACEHOLDER   trimmed — exact match
 *   BARE_LABEL_RE trimmed — an empty `**Label:**`, e.g. a `**Risks:**` sub-heading in an answer
 *
 * A blank line is deliberately absent: it cannot be escaped into something non-blank, which is
 * the documented paragraph-break lossiness of this projection.
 */
function answerLineIsLost(line) {
  const t = line.trim();
  return (
    HEADING_RE.test(line) ||
    HRULE_RE.test(t) ||
    PROPOSED_RE.test(line) ||
    t === PLACEHOLDER ||
    BARE_LABEL_RE.test(t)
  );
}

/**
 * Does this line need a leading backslash so it survives a round trip?
 *
 * Recursive on a leading backslash, and that recursion is the whole correctness argument. Escaping
 * has to be INJECTIVE: if the predicate were just `answerLineIsLost(line)`, a stored answer that
 * already began `\---` would be emitted unescaped (it is not a rule, so nothing is lost) and then
 * *unescaped* on the way back — silently deleting the author's own backslash and turning an
 * untouched render into a reported "refused edit". Escaping `\---` to `\\---` keeps the pair
 * inverse for any number of leading backslashes.
 */
function answerLineNeedsEscape(line) {
  if (answerLineIsLost(line)) return true;
  return line.startsWith('\\') && answerLineNeedsEscape(line.slice(1));
}

/**
 * Escape the answer lines the grammar would otherwise swallow.
 *
 * A stored answer is free text: nothing stops an SME or an LLM writing `---` as a separator,
 * `### Something` as a sub-heading, or a bolded `**Risks:**` sub-label. Emitted verbatim the
 * damage is not limited to losing that one line:
 *
 *   - `### Q9: …` inside an answer parses as a WHOLE EXTRA QUESTION, which then reaches the SME
 *     on the form as a fabricated open question.
 *   - For `---`/`### …`, everything after the line vanishes from every `.md` consumer.
 *   - Either way, folding the rendered file straight back reports a settled question as a refused
 *     edit, because the text that came back no longer matches the store.
 *
 * A single leading backslash neutralises every shape in `answerLineIsLost` — none of those
 * patterns tolerate a leading `\` — and Markdown renders it as the literal text.
 * `unescapeAnswerLines` reverses it exactly.
 */
function escapeAnswerLines(answer) {
  return answer
    .split('\n')
    .map((line) => (answerLineNeedsEscape(line) ? `\\${line}` : line))
    .join('\n');
}

/**
 * Reverse escapeAnswerLines. Strips a leading backslash only where escaping would have added one,
 * so a legitimate backslash in an answer survives.
 */
function unescapeAnswerLines(answer) {
  return answer
    .split('\n')
    .map((line) =>
      line.startsWith('\\') && answerLineNeedsEscape(line.slice(1)) ? line.slice(1) : line,
    )
    .join('\n');
}

/** Collapse a value that must occupy a single Markdown line, CR included. */
function oneLine(value) {
  // The pre-pass is not redundant with the \s* fold: QUESTION_RE and the `**Label:**` regexes all
  // end at `$` and match content with `.`, and `.` does not match ANY of these characters — so
  // one of them inside a question's text makes the whole `### Q<N>:` heading unparseable and the
  // question disappears from the projection while the footer still counts it.
  //
  // U+2028/U+2029 belong here for exactly the reason CR does: both are `\s`, so the fold below
  // looks like it should handle them, and neither is matched by `.`. They survive a YAML round
  // trip unchanged, so a hand-authored store can carry one indefinitely.
  // Written as escapes, not literals: U+2028/U+2029 are invisible in an editor, so a literal
  // here reads as a stray space and gets "tidied" away by the next person through this file.
  return String(value == null ? '' : value)
    .replace(/\r\n|[\r\u2028\u2029]/g, '\n')
    .replace(/\s*\n\s*/g, ' ')
    .trim();
}

/**
 * Map the store's enum `status` onto the line every `.md` consumer already expects.
 *
 * `answered` reconstitutes the dated marker process-os-review-answer-application's SKILL.md
 * mandates (`**Status:** answered <YYYY-MM-DD>`) from the two fields the store keeps separately
 * — the enum and `updated` — rather than storing the date inside `status` itself.
 * `partially_answered` renders as the human phrase `questions-xlsx.cjs` has always surfaced
 * verbatim (`Partially answered`). `open`, blank, or anything else renders no line of its own;
 * `renderQuestionBlock`'s fallback covers a question settled by answer content alone.
 *
 * @param {object} q Store question.
 * @returns {string} The `**Status:**` line's value, or `''` for no line.
 */
function statusDisplayText(q) {
  const label = schema.statusLabel(q);
  if (label === '') return '';
  // Only `answered` takes the date, and only this projection reconstitutes it: the dated marker is
  // a shape the `.md` GRAMMAR reads back, not a general-purpose label, which is why the date is
  // composed here rather than in the shared vocabulary.
  if (q.status !== schema.STATUS.ANSWERED) return label;
  const updated = oneLine(q.updated);
  return updated === '' ? label : `${label} ${updated}`;
}

/**
 * Render one question block in the grammar `parseAnswerBlocks()` reads.
 *
 * Field order is load-bearing. `**Status:**` sits ABOVE `**Answer:**` because that is where the
 * marker is looked for (a `**Status:**` line below the marker is answer content).
 *
 * An open question keeps its `AI Proposal:` line and the `[write your answer here]` placeholder;
 * both are authored WITH the question, and both are excluded from `answerText`, so rendering them
 * cannot make an unanswered question look settled. An answered one keeps the proposal line too,
 * so a reader can still see what was offered.
 *
 * @param {object} q Store question.
 * @param {number} num 1-based question number, from the `q<N>` id.
 * @returns {string}
 */
function renderQuestionBlock(q, num) {
  const answer = String(q.answer == null ? '' : q.answer).trim();
  const open = schema.isOpen(q);

  let out = `### Q${num}: ${oneLine(q.text)}\n`;
  out += labelLine('Confidence', q.confidence);
  out += labelLine('Impact', q.impact);
  // The enum is mapped to the human-facing line every `.md` consumer already expects — see
  // statusDisplayText. The fallback below is keyed on `!open`, NOT on `markedAnswered`, so a
  // question settled by answer content alone with a blank or `open` status still renders a
  // marker instead of nothing: there is no separate "settled, but the enum still says open"
  // display text to fall back to, since `open` carries no annotation of its own to show.
  //
  // That fallback is what makes the settledness of such a question rest on more than this line,
  // and the answer text surviving the answer-region scan — which escapeAnswerLines guarantees —
  // is the other half. Load-bearing, not belt-and-braces: do not weaken it on the assumption
  // that a marker is always present too.
  const statusText = statusDisplayText(q);
  if (statusText !== '') out += `**Status:** ${statusText}\n`;
  else if (!open) out += `**Status:** ${schema.ANSWERED}\n`;
  out += '**Answer:**\n';

  const proposed = oneLine(q.proposed);
  if (proposed !== '') out += `AI Proposal: ${proposed}\n`;
  if (answer !== '') out += `${escapeAnswerLines(answer)}\n`;
  else if (open) out += `${PLACEHOLDER}\n`;

  return out;
}

/**
 * Render a store document as questions Markdown.
 *
 * @param {object} doc Validated store document.
 * @returns {string} Markdown text.
 */
function renderMarkdown(doc) {
  const title = KIND_TITLES[doc.kind] || KIND_TITLES.review;
  // oneLine, not a bare trim, on every one of these. They are document- and section-level
  // strings, so they are not in PROSE_FIELDS and the store's own normalisation never touches
  // them — a newline reaches the renderer intact. Emitted raw into a single-line position, a
  // `title` containing "### Q9: …" parses as a WHOLE EXTRA QUESTION that then reaches the SME on
  // the form, and a lone CR in a title splits the `## ` heading so the rest of it becomes body
  // text. Same class as the question-field cases, one level up.
  const process = oneLine(doc.process);

  let out = `# ${process === '' ? title : `${process} — ${title}`}\n`;
  const generated = oneLine(doc.generated);
  if (generated !== '') out += `Generated: ${generated}\n`;
  out += '\n' + HOW_TO_USE + '\n---\n';

  let num = 0;
  let open = 0;
  let sectionNumber = 0;
  for (const section of doc.sections || []) {
    const heading = oneLine(section.title);
    sectionNumber += 1;
    // A heading is emitted even for an untitled section. Omitting it would let a reader carry the
    // PREVIOUS `## Section N:` forward, attributing these questions to a section they do not sit
    // in — the outcome flatQuestions' blank-not-inherited rule exists to prevent. The trailing
    // colon is what keeps the `Section <n>:` shape, so the label stays positionally accurate
    // instead of collapsing to blank.
    out += `\n## ${heading === '' ? `Section ${sectionNumber}:` : sectionHeading(heading, sectionNumber)}\n`;
    for (const q of section.questions || []) {
      num += 1;
      if (schema.isOpen(q)) open += 1;
      out += '\n' + renderQuestionBlock(q, schema.questionNumber(q) || num);
    }
  }

  // The closing rule is what keeps this footer out of the last question's answer region —
  // see HRULE_RE. Without it the final question folds back with the footer as its answer.
  out += `\n---\nFound: ${num} question${num === 1 ? '' : 's'} — ${open} still open.\n`;
  return out;
}

/**
 * Render a section heading in the `Section <n>: …` shape.
 *
 * The store's titles are free-form, and a bare topic title — `Unclear Process Steps` — renders a
 * heading no reader can tell from the file's own boilerplate (`## How to use`). Prefixing when the
 * title lacks the shape keeps the store's titles free-form without the projection losing them.
 */
function sectionHeading(title, position) {
  return /^Section \d+:/.test(title) ? title : `Section ${position}: ${title}`;
}

// ─── `.md` -> store ─────────────────────────────────────────────────────────

// Recovers the date from a `**Status:** answered <YYYY-MM-DD>` marker — the shape
// process-os-review-answer-application's SKILL.md mandates — so a date already present in the
// `.md` lands in the store's structured `updated` field instead of being discarded when the
// enum-only `status: answered` is written. Anything else trailing `answered` (`(from doc)`, no
// date at all) yields `''`, which is `settleQuestion`'s "no date" case — it never invents one.
const ANSWERED_DATE_RE = /^answered\s+(\d{4}-\d{2}-\d{2})\b/i;
function updatedFromRawStatus(rawStatus) {
  const m = ANSWERED_DATE_RE.exec(String(rawStatus == null ? '' : rawStatus).trim());
  return m ? m[1] : '';
}

/**
 * Fold answers from a questions `.md` back into a store document.
 *
 * Writes ONLY the fields whoever ANSWERS authors: `answer`, `status`, and — when a
 * dated `answered <YYYY-MM-DD>` marker is present — `updated`.
 *
 * Question text is read from the `.md` for the identity check (via `normalizeQuestionText`) but
 * never written back — the store owns it, so an SME editing a question's text in a projection is
 * reported as a mismatch rather than silently promoted into the source of truth. Confidence,
 * impact and proposed are not read at all: `parseAnswerBlocks` does not even carry them, because
 * the store is the only thing that renders them and nothing here compares or overwrites them.
 *
 * Answer state is decided by questions-schema's `isOpen`, so a settled question cannot be
 * overwritten from here — the same guarantee `applyAnswers()` gives every other projection, and
 * for the same reason: a projection can carry an answer for a question it never showed (a
 * hand-edited file, a `.md` rendered from an earlier cycle).
 *
 * `alreadyAnswered` reports only a settled question whose `.md` answer DIFFERS from the stored
 * one, i.e. someone tried to change a settled answer and it was refused. A rendered `.md`
 * necessarily contains every existing answer, so reporting each one back on every fold would bury
 * the discarded edits in noise — the same reason `applyAnswers()` says "we threw your text away"
 * only when there was incoming text.
 *
 * KNOWN LOSSINESS, all of it in the TYPED direction. `renderMarkdown` escapes what it emits, but a
 * line the SME types into the `.md` gets no such protection: `parseAnswerBlocks` has already
 * discarded it before this function runs, so nothing here can recover it.
 *
 *   a paragraph break            blank lines are dropped from the answer region (they also
 *                                separate one block from the next), so two paragraphs come back as
 *                                two adjacent lines. The comparison below is whitespace-tolerant
 *                                partly to absorb this.
 *   `---` / `***` / `___`,       ends the block: the answer is truncated at that line.
 *   `#`–`###` heading
 *   `**Risks:**`-style bare      dropped; the rest of the answer is kept.
 *   label, `AI Proposal:`,
 *   placeholder
 *
 * The REPORTING is the part to be careful about, because neither shape looks like a loss: a
 * swallowed line mid-answer is dropped while the question is still reported in `written` — a silent
 * partial write — and an answer consisting only of such a line vanishes entirely and is reported in
 * `blank`, as though the SME had typed nothing at all.
 *
 * The `isOpen` gate confines every case above to newly typed answers: a stored answer is never
 * re-read from its own projection, so it cannot be damaged by a round trip.
 *
 * @param {string} mdText Markdown to read answers from.
 * @param {object} doc Store document to fold into.
 * @returns {{doc: object, written: string[], alreadyAnswered: string[], blank: string[],
 *   mismatched: string[], missing: string[]}} A NEW document plus per-id outcomes.
 */
function foldAnswersFromMarkdown(mdText, doc) {
  const blocks = new Map(parseAnswerBlocks(mdText).map((b) => [b.id, b]));
  const written = [];
  const alreadyAnswered = [];
  const blank = [];
  const mismatched = [];
  const missing = [];

  const next = {
    ...doc,
    sections: (doc.sections || []).map((section) => ({
      ...section,
      questions: (section.questions || []).map((q) => {
        const block = blocks.get(q.id);
        if (!block) {
          // Reported, not refused. A partial `.md` is a legitimate input — an operator can hand an
          // SME the questions in their area and fold back what comes home.
          missing.push(q.id);
          return q;
        }
        if (schema.normalizeQuestionText(block.text) !== schema.normalizeQuestionText(q.text)) {
          mismatched.push(q.id);
          return q;
        }
        if (!block.hasAnswerText) {
          // The marker is a settling signal in its own right, and the fold has to be able to
          // ACQUIRE it — not just preserve one already in the store. A `.md` block marked answered
          // with its answer region empty is the documented post-fold-in state (the answer was moved
          // out into the phase documents). Reading that as still-open would report a settled
          // question in `blank`, i.e. as work outstanding, and leave the store disagreeing with
          // the `.md`.
          if (block.markedAnswered && schema.isOpen(q)) {
            written.push(q.id);
            return schema.settleQuestion(q, updatedFromRawStatus(block.status));
          }
          // Only an OPEN question counts as blank: `blank` answers "what still needs
          // answering", and a settled question with nothing incoming needs nothing.
          if (schema.isOpen(q)) blank.push(q.id);
          return q;
        }
        // Reverse the render-side escaping before the value is compared or stored, so an answer
        // containing `---` or `### …` round-trips to exactly what the store already holds.
        const incoming = unescapeAnswerLines(block.answerText);
        if (!schema.isOpen(q)) {
          // Only a CHANGED answer is a discarded edit, and `answersAgree` is the one place that
          // decides what "changed" means — this projection is just another surface answering the
          // same question, so re-deriving the comparison here is exactly the drift that predicate
          // exists to prevent. Its whitespace tolerance is also what absorbs the paragraph
          // flattening described above.
          if (!schema.answersAgree(incoming, q.answer)) alreadyAnswered.push(q.id);
          return q;
        }
        written.push(q.id);
        // Both answer-state signals are set together, so the store never carries an answer
        // whose status disagrees with it.
        return schema.settleQuestion({ ...q, answer: incoming }, updatedFromRawStatus(block.status));
      }),
    })),
  };

  for (const list of [written, alreadyAnswered, blank, mismatched, missing]) {
    list.sort(schema.byQuestionNumber);
  }
  return { doc: next, written, alreadyAnswered, blank, mismatched, missing };
}

module.exports = {
  parseAnswerBlocks,
  renderMarkdown,
  foldAnswersFromMarkdown,
  PLACEHOLDER,
  QUESTION_RE,
};
