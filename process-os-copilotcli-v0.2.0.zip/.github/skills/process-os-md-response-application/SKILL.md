---
name: process-os-md-response-application
description: >-
  Fold answers from an answered questions Markdown file back into the ProcessOS
  questions store it was rendered from. Use when an SME or the ProcessOS user
  has filled in the .md produced by process-os-questions-md-export and those
  answers need to reach the store. Writes only the fields whoever answers owns -
  answer, status, and a dated marker's date into updated; refuses the whole file
  when its question text no longer matches the store.
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
# /process-os-md-response-application

**UTILITY SKILL** — a single deterministic transform (an answered questions `.md` → the questions
store). No LLM reasoning; idempotent fold keyed on `q<N>`.

INVOKES: `md-to-questions.cjs`.

## USE FOR:

- Folding an answered `.md` back into the store it was rendered from
- Applying an SME's filled-in Markdown to transformation's `review-questions.yaml` (under its
  current iteration's `artifacts/`)
- Reading a returned `.md` without applying it (`--dry-run`) — including against a completed
  discovery iteration's `review-questions.yaml`, which is frozen: `process-os-sme-feedback` reads
  a return this way, then deposits the resolved answers in that iteration's `feedback/` for a
  later discovery iteration to fold into its own copy

## DO NOT USE FOR:

- Rendering the `.md` in the first place → instead use `process-os-questions-md-export`.
- A returned spreadsheet → use `process-os-xlsx-response-application`.
- Submitted Camunda Form variables → use `process-os-form-response-application`.
- Acting on the answers — folding them into the phase documents, marking BPMN questions resolved →
  use `process-os-review-answer-application`.

The store is the source of truth and the `.md` is a projection of it, so this skill writes **only**
the fields whoever *answers* owns: `answer`, `status`, and — when the `.md` carries a
dated `**Status:** answered <YYYY-MM-DD>` marker — that date into `updated`. Question text is read
for the identity check and **never** written back, and confidence, impact and the proposed answer
are not read at all: an SME who edits a question in the projection is reported, not silently
promoted into the source of truth.

A question the store already considers settled — it holds answer text, or its `status` is
`answered` — is **not** overwritten, whatever the `.md` says. The rendered `.md` shows
such a question read-only with no place to type, so this only fires on a file that did not come
from a current render: an earlier cycle's, or a hand-edited one.

$ARGUMENTS

### Step 1 — EXEC: fold the answers in

```bash
node .github/skills/process-os-md-response-application/scripts/md-to-questions.cjs <answered.md> <target.yaml>
```

**Run it from the project root** — the directory containing `.camunda/`. The script reads and writes
the store through `scripts/questions-yaml.cjs`, which resolves the `yaml` package from
`.camunda/node_modules` relative to the working directory.

Both arguments are required and both must exist. Pass `--dry-run` to **read the file without
writing** — see [Reading a source without applying it](#reading-a-source-without-applying-it).

### Step 2 — AI: Report

Tell the user the three counts the script prints, kept apart:

- **written** — the answers that landed.
- **already answered** — an answer that was **discarded** because the store already considers that
  question settled *and* the `.md` value differs from the stored one. Never report these as blank:
  a discarded edit is something the user may want to look at. An *unchanged* settled answer is not
  reported at all — a rendered `.md` necessarily contains every existing answer, so reporting each
  one back on every fold would bury the real discarded edits in noise.
- **still blank** — questions that are **still open** and got no answer, i.e. what remains to be
  answered.

Plus a fourth line when it applies:

- **not in the file** — store questions the `.md` did not contain. Not an error: handing an SME only
  the questions in their area is a supported workflow. These are left exactly as they were, and are
  deliberately *not* counted as blank — a question that was never asked is a different statement
  from one that was asked and not answered.

The store is now ready for the next lifecycle step — usually
`/process-os-review-answer-application`, which folds the answers into the phase documents.

## When it refuses

**Exit 4 — the question text no longer matches.** `q<N>` ids are positional, and a phase re-run
rewrites the store wholesale and renumbers from scratch. A `.md` rendered before that run would
apply every answer to whatever question now occupies that position. So every question the `.md`
carries must still hold the same text (whitespace-normalised — rewrapping is not an edit, but a
reworded or re-punctuated question is). Any mismatch **refuses the whole file** and the store is
untouched.

Recovery: re-render the Markdown from the current store with `/process-os-questions-md-export`, then
re-collect or re-enter the answers. Do **not** apply the matching subset by hand — against a
renumbered store the "matching" questions are matching by accident, and no one can tell which
subset is trustworthy.

A question the `.md` simply does not contain is the opposite case and is **not** a refusal: the file
covers less, not something different. It is reported and left alone.

## Reading a source without applying it

`--dry-run` reports what this `.md` **would** do and writes nothing:

```bash
node .github/skills/process-os-md-response-application/scripts/md-to-questions.cjs --dry-run <answered.md> <target.yaml>
```

Use it when the `.md` is **not the only surface answering these questions** — the SME may also have
answered the Tasklist questionnaire, or returned the spreadsheet from
`process-os-questions-xlsx-export`. All three write into the same store and join on the same `q<N>`.
Applying any one of them settles every question it touches, and an answer aimed at a settled
question is then correctly discarded — so whichever import ran first wins, and the disagreement is
never seen. Reading all of them first is what lets a caller compare them; `process-os-sme-feedback`
does exactly that before it writes anything.

The mismatch refusal above still runs first, so a `.md` a real fold would refuse can never
contribute a phantom answer to that comparison.

Output is JSON, so the caller can compare two sources' texts directly:

```json
{
  "source": "md",
  "target": "process-discovery/iteration-3/artifacts/review-questions.yaml",
  "answers": { "q2": "The Meridian Risk API at /v2/score." },
  "alreadyAnswered": ["q1"],
  "blank": ["q3"],
  "missing": []
}
```

- **`answers`** — what would land, keyed by `qN`, **with the text**. Every one is real human input:
  the render leaves an open question's answer region holding only the `[write your answer here]`
  placeholder, which the reader excludes, so a value can only have been typed. (The questionnaire
  needs a `proposalUnchanged` caveat for exactly this reason; this projection does not.)
- **`alreadyAnswered`** / **`blank`** / **`missing`** — the same lists the real write reports, so a
  dry run and the write that follows it never disagree.

Then apply the reconciled result through whichever import owns the chosen text. A flat
`{ "qN": "<the chosen text>" }` map applied via `/process-os-form-response-application` is the
shape for a resolution assembled from several sources — one write, through the same gate, with no
second import to overwrite it.

## Example

```bash
$ node .github/skills/process-os-md-response-application/scripts/md-to-questions.cjs process-discovery/iteration-3/artifacts/review-questions.md process-discovery/iteration-3/artifacts/review-questions.yaml
md-to-questions: wrote 2 answer(s) [q1, q2]; 0 already answered []; 1 still blank [q3] -> process-discovery/iteration-3/artifacts/review-questions.yaml

# one section handed to a single SME: the rest of the store is reported, not touched
$ node .github/skills/process-os-md-response-application/scripts/md-to-questions.cjs process-transformation/iteration-2/feedback/for-compliance.md process-transformation/iteration-2/artifacts/review-questions.yaml
md-to-questions: wrote 3 answer(s) [q4, q5, q7]; 0 already answered []; 0 still blank [] -> process-transformation/iteration-2/artifacts/review-questions.yaml
md-to-questions: 7 question(s) not in the file [q1, q2, q3, q6, q8, q9, q10] — left untouched
```

## Troubleshooting

- **`missing <path>`** — one of the two files does not exist; confirm both paths.
- **`question text does not match the target store`** (exit 4) — see
  [When it refuses](#when-it-refuses). Nothing was written.
- **`not a valid questions store`** (exit 5) — the target parses as YAML but does not match the
  schema; every problem is listed.
- **`not valid YAML`** (exit 6) — the target's YAML is broken; the message names the line.
- **Answers not appearing** — the `.md` must keep each `### Q<N>:` heading and its `**Answer:**`
  marker intact, with the answer text on the lines directly below the marker. An answer aimed at an
  already-settled question is discarded by design and shows up in the `already answered` count.
- **An answer landed shorter than what was typed** — a typed `---`/`***`/`___` or a `#`–`###`
  heading ends the question's block, so everything after it is lost; a typed bare `**Label:**`,
  `AI Proposal: …` or `[write your answer here]` line is dropped. These are
  properties of the Markdown format, not of this skill, and they apply only to text typed in — a
  stored answer is never re-read from its own projection. Use the store directly, the Camunda Form,
  or the spreadsheet projection when an answer needs those shapes.
- **Blank lines disappeared from an answer** — a blank line is what separates one question block
  from the next, so a newly typed two-paragraph answer folds back as two adjacent lines. Same
  scope: typed text only.
- **Nothing changed on re-run** — expected: the fold is idempotent, so applying the same `.md`
  twice is a no-op.
