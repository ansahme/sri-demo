#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Validate BPMN files for Camunda 8 (Cloud) runtime compatibility using
// bpmnlint + bpmnlint-plugin-camunda-compat + zeebe-bpmn-moddle. Output mirrors
// the bpmnlint shape (one block per file), so the skill's fix loop works
// identically to process-os-bpmn-linting / process-os-dmn-linting / process-os-forms-linting.
//
// Usage:  node scripts/validate.cjs [--version <X.Y>] <file.bpmn>...
//
// Runs the pre-installed bpmnlint from `.camunda/node_modules` by spawning its JS
// entrypoint with `process.execPath` (never the extensionless `.bin/bpmnlint`
// shim — that cannot be exec'd on Windows; see resolve-node-cli.cjs). The camunda-compat
// plugin + zeebe-bpmn-moddle resolve via `NODE_PATH`.
// Caller's working directory is untouched. The skill ships its own .bpmnlintrc
// inside this dir (rewritten per --version) so any project-side config the user
// has is ignored — runtime-compat checks are the whole point.
//
// Exit codes: 0 clean, 1 findings, 2 bad input OR bpmnlint could not be run.

const path = require('path');
const fs = require('fs');
const { resolveNodeCliEntry, runNodeCli } = require(path.join(__dirname, 'resolve-node-cli.cjs'));

const SKILL_DIR = __dirname;

// Parse args: --version flag (default: latest cloud config) plus file paths.
const SUPPORTED_VERSIONS = ['8.0','8.1','8.2','8.3','8.4','8.5','8.6','8.7','8.8','8.9','8.10'];
const DEFAULT_VERSION = '8.9';

let version = DEFAULT_VERSION;
const files = [];
const argv = process.argv.slice(2);
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a === '--version' || a === '-v') {
    version = argv[++i];
  } else if (a === '--help' || a === '-h') {
    printHelp();
    process.exit(0);
  } else {
    files.push(a);
  }
}

if (!SUPPORTED_VERSIONS.includes(version)) {
  process.stderr.write(`Unsupported version "${version}". Supported: ${SUPPORTED_VERSIONS.join(', ')}\n`);
  process.exit(2);
}
if (files.length === 0) {
  printHelp();
  process.exit(2);
}

// Resolve user paths *before* spawning with cwd: SKILL_DIR; the user passed
// them relative to their own shell, not relative to the skill dir.
const absFiles = files.map(p => path.resolve(p));
for (const f of absFiles) {
  if (!fs.existsSync(f)) {
    process.stderr.write(`File not found: ${f}\n`);
    process.exit(2);
  }
}

// Write the per-version .bpmnlintrc in the skill dir. bpmnlint walks up from
// cwd looking for this file; running with cwd=SKILL_DIR makes it pick ours up
// regardless of where the user invoked us from.
const cfg = {
  extends: [
    'bpmnlint:recommended',
    `plugin:camunda-compat/camunda-cloud-${version.replace('.', '-')}`,
    'plugin:process-os/recommended'
  ],
  moddleExtensions: { zeebe: 'zeebe-bpmn-moddle/resources/zeebe.json' }
};
fs.writeFileSync(path.join(SKILL_DIR, '.bpmnlintrc'), JSON.stringify(cfg, null, 2) + '\n');

const bpmnlint = resolveNodeCliEntry('bpmnlint', {
  searchPaths: [path.join(process.cwd(), '.camunda'), process.cwd()],
});
if (!bpmnlint) {
  process.stderr.write('ProcessOS runtime dep missing: bpmnlint at .camunda/node_modules. Run `c8 os update` — or `c8 os install <target>` (e.g. claudecode) if ProcessOS is not installed here.\n');
  process.exit(2);
}
// Resolve the zero-install process-os plugin (lives in the process-os-bpmn-linting skill) via
// NODE_PATH so `plugin:process-os/recommended` in the config above loads.
const processOsPlugins = path.resolve(SKILL_DIR, '..', '..', 'process-os-bpmn-linting', 'plugins');
const env = { ...process.env, NODE_PATH:
  [processOsPlugins, path.join(process.cwd(), '.camunda', 'node_modules'), process.env.NODE_PATH]
    .filter(Boolean).join(path.delimiter) };
const result = runNodeCli(bpmnlint, absFiles, { cwd: SKILL_DIR, stdio: 'inherit', env });
// A spawn that never started is neither "clean" nor "findings": reported as exit 1
// (bpmnlint's own findings code) with nothing on stdio, it reads as a clean pass.
if (!result.launched) {
  process.stderr.write(`bpmnlint could not be started: ${result.error && result.error.message}\n` +
    'Compatibility was NOT validated. Run `c8 os update` — or `c8 os install <target>` (e.g. claudecode) if ProcessOS is not installed here — then retry.\n');
  process.exit(2);
}
process.exit(result.status);

function printHelp() {
  process.stderr.write([
    'Usage: node scripts/validate.cjs [--version X.Y] <file.bpmn>...',
    '',
    'Validates BPMN files for Camunda 8 (Cloud) runtime compatibility.',
    `Supported versions: ${SUPPORTED_VERSIONS.join(', ')} (default: ${DEFAULT_VERSION})`,
    'Camunda 7 (Platform) is not supported by this wrapper — see SKILL.md for manual config.',
    ''
  ].join('\n'));
}
