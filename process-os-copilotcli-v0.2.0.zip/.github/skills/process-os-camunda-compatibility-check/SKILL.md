---
name: process-os-camunda-compatibility-check
description: >-
  Validate a single BPMN file or a directory of BPMN files for Camunda 8 (Cloud)
  runtime compatibility using bpmnlint + bpmnlint-plugin-camunda-compat +
  zeebe-bpmn-moddle. Use after creating or modifying any .bpmn file and before
  any subsequent step (deployment, further generation, review, …). This is a
  stricter superset of /process-os-bpmn-linting — it includes
  `bpmnlint:recommended` AND the per-Camunda-version compat rules
  (executable-process, feel, io-mapping, implementation, …) that catch cases
  where a structurally-valid BPMN still fails to deploy or run on Zeebe. Wraps
  the official Camunda compat plugin and runs bpmnlint with the right moddle
  extension so Zeebe extension elements are parsed.
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
# Camunda Compat Lint

## When to use this vs /process-os-bpmn-linting

- `/process-os-bpmn-linting` — fast, runtime-agnostic structural check (`bpmnlint:recommended` only). Run it during early modeling when the target Camunda version isn't pinned yet.
- **`/process-os-camunda-compatibility-check`** (this skill) — runtime-specific. Adds 50+ rules from `bpmnlint-plugin-camunda-compat`, each tied to a specific Camunda 8 version. Run it before deployment, before tests that hit a real Zeebe broker, and before considering a process "done".

It includes everything `/process-os-bpmn-linting` checks, so you don't need to run both — this skill is the strict gate.

## Scope

The caller passes a **target** — either a single `.bpmn` file or a directory:

- **Single file** (e.g. `process-transformation/iteration-1/artifacts/order-fulfilment.bpmn`): lint exactly that file.
- **Directory** (e.g. `process-implementation/artifacts/src/main/resources/processes/`): discover every `.bpmn` file beneath it (recursive). Skip these directories during discovery: `.git`, `node_modules`, `target`, `build`, `.gradle`, `.mvn`, `.idea`, `.settings`, `.snapshots`.

If the target is ambiguous, ask once. Otherwise infer from the path (file extension `.bpmn` → single-file mode; anything else → directory mode).

## Camunda version

The plugin's rule set varies per Camunda 8 minor version (8.0 through 8.10). The wrapper defaults to **8.9** (latest stable). Override with `--version`:

```bash
node .github/skills/process-os-camunda-compatibility-check/scripts/validate.cjs --version 8.7 path/to/file.bpmn
```

Pick the version that matches the broker the process will deploy to. If unsure, prefer the older version — its rule set is stricter (e.g., `inclusive-gateway` is forbidden through 8.5, allowed from 8.6 onward).

Camunda 7 (Platform) is not supported by this wrapper. If you need it, see the bpmnlint-plugin-camunda-compat README for `camunda-platform-7-X` configs and swap `zeebe-bpmn-moddle` for `camunda-bpmn-moddle`.

## When to run

Run after every change to a `.bpmn` file in the target and again after each fix round. Only proceed to subsequent steps when lint reports zero errors. The "subsequent step" is whatever the caller is doing — deployment, further generation, review, hand-off — this skill is agnostic to it.

## How to run

The skill ships its own wrapper (`validate.cjs`) that handles config and invocation. It runs the pre-installed `bpmnlint` from `.camunda/node_modules` (installed by `c8 os install`) by spawning its JS entrypoint with the current Node binary — never the extensionless `.bin/bpmnlint` shim, which cannot be exec'd on Windows — and resolves `bpmnlint-plugin-camunda-compat` + `zeebe-bpmn-moddle` via `NODE_PATH`. The user's project directory is otherwise untouched (no project-side `.bpmnlintrc` overridden — the wrapper runs bpmnlint with `cwd` set to the skill dir, where its own `.bpmnlintrc` lives).

```bash
# Single-file mode (default version: 8.9)
node .github/skills/process-os-camunda-compatibility-check/scripts/validate.cjs path/to/file.bpmn

# Single-file mode, specific version
node .github/skills/process-os-camunda-compatibility-check/scripts/validate.cjs --version 8.5 path/to/file.bpmn

# Directory mode — pass the discovered files explicitly so skip-dirs are honoured
node .github/skills/process-os-camunda-compatibility-check/scripts/validate.cjs <space-separated list of discovered .bpmn files>
```

Exit codes: `0` = clean, `1` = lint issues found (parse stdout), `2` = wrapper usage / install error, or bpmnlint could not be started at all (read stderr). Exit `2` means compatibility was **not** validated — never treat it as clean.

## Output shape

Same as `/process-os-bpmn-linting` — bpmnlint's standard report:

```
order-fulfilment.bpmn
  Activity_1  error  No task definition <zeebe:taskDefinition> for <bpmn:ServiceTask>  implementation
  Activity_1  error  Property value of <${data.foo}> not allowed                      feel

✖ 2 problems (2 errors, 0 warnings)
```

Format per report line: `<elementId>  <severity>  <message>  <ruleId>` with 2+ spaces between columns. **Caveat:** for some `camunda-compat/*` rules, the rightmost column is the offending element's `name` attribute rather than the rule ID (a quirk of the plugin's reporter — to be fixed upstream). When you see a non-rule-looking value there, look at the message keywords (`io-mapping`, `taskDefinition`, `FEEL`, …) to identify which rule fired. The plugin's full rule list is at <https://github.com/camunda/bpmnlint-plugin-camunda-compat/tree/main/rules/camunda-cloud>.

## Fix loop

1. For each affected file, locate before editing — never `Read` the whole file (a connector-bound BPMN may run over the Read tool's ~25 KB cap):
   - Extract once for context: `node ".github/skills/process-os-camunda-compatibility-check/scripts/bpmn-extract.cjs" "<file>"` — gives every element's current name, type, job type, form key, template and documentation, so you know what the fix should contain before touching the file. Exit `2` → bad input (missing path, or the file is not well-formed XML) — report stderr and stop; a file that will not parse is a finding in its own right, not a step to skip past. Exit `3` → the report is over the cap — re-run with `--names` (drops job type, form key, template, call activity target and documentation, so the bounded `Read` below becomes the only source for those).
   - For each reported issue, locate its edit site — the report gives an `elementId` but no line number. Run `node ".github/skills/process-os-camunda-compatibility-check/scripts/search-files.mts" --pattern 'id="<elementId>"' --fixed "<file>"` to find the element's own tag (never a raw `grep` — it isn't available on native Windows PowerShell). For a diagram-only rule (`no-bpmndi`, `no-overlapping-elements`), search for `bpmnElement="<elementId>"` instead — no match means the shape doesn't exist yet and must be inserted, not edited.
   - `Read` the file with a bounded `offset`/`limit` window around the located line, wide enough to cover the whole element (open tag through close tag). This also satisfies `Edit`'s requirement that the file be `Read` first.
2. For every reported issue, apply a targeted Edit/patch — never rewrite the whole file. Most `camunda-compat/*` rules indicate a *missing* element/attribute or an *invalid* value; fix at the JSON-pointer-equivalent path the report names.
3. Re-run the wrapper against the same target.
4. Repeat until the run is clean. **Fix all errors. Fix warnings unless there is a deliberate reason to keep them.**
5. Then return control to the caller — they decide what comes next (deployment, further generation, review, …).

### Parallel dispatch (>3 files)

If the discovered set has **more than 3 `.bpmn` files with reported issues**, do NOT fix them serially in the orchestrator session. Spawn one `Agent` (subagent_type `general-purpose`) per file (or batch of up to 3 files that share an obvious root cause) so fixes run in parallel. This is explicitly wanted — the per-file fix work is independent and the orchestrator session should not be flooded with raw lint output across many files.

Each dispatched agent receives:
- The exact file path(s) it owns.
- The lint output for those files only (filtered).
- A pointer back to this skill and to the bpmnlint-plugin-camunda-compat rules folder.
- Instruction to re-run `node .github/skills/process-os-camunda-compatibility-check/scripts/validate.cjs <its files>` until clean and report back: files touched, rules fixed, final status.

After all parallel agents return, run a single consolidated validation from the orchestrator to confirm the whole set is clean before reporting done.

For 3 or fewer files with issues, fix serially in the current session — the parallel-dispatch overhead isn't worth it.

## Rule families (pointer, not exhaustive)

The plugin has 50+ rules; the precise active set depends on `--version`. The most common families and what they check:

| Family | What it catches | Typical fix |
|---|---|---|
| `executable-process` | Process root has `isExecutable="false"` (or attribute missing). | Set `isExecutable="true"` on the `<bpmn:process>`. |
| `implementation` | Service Task / Business Rule Task / etc. lacks `<zeebe:taskDefinition>` (or `calledDecision`, etc. for the task type). | Add the appropriate `<bpmn:extensionElements>` block under the task. |
| `feel` | Expression isn't valid FEEL — usually a `${...}` Camunda 7-style expression in a Camunda 8 file. | Rewrite to FEEL (`= someVariable`, `= someExpr.field`). |
| `io-mapping` | `<zeebe:input>` / `<zeebe:output>` source/target uses a non-FEEL expression like `$.foo`. | Replace `$.foo` with `=foo` or whatever the FEEL equivalent is. |
| `element-type` | A BPMN element type isn't supported by the target Camunda version (e.g. `<bpmn:complexGateway>` is never supported). | Replace with a supported equivalent (Exclusive + Parallel split). |
| `loop-characteristics` | Multi-instance loop config is incomplete or malformed. | Add `<zeebe:loopCharacteristics>` with valid input/output collections. |
| `user-task-form` / `user-task-definition` | User Task is missing form binding or task definition Zeebe expects. | Add `<zeebe:formDefinition>` (form key) and/or `<zeebe:userTask />`. |
| `version-tag` / `no-version-tag` | The `<zeebe:versionTag>` element is required from 8.6+, forbidden before that. | Add or remove based on the target version. |
| `timer` | Timer event definition uses a non-FEEL expression or wrong type for the target version. | Use FEEL (`PT1H`, `=now() + duration("PT1H")`). |
| `inclusive-gateway` | Inclusive Gateway forbidden before 8.6. | Replace with Exclusive + Parallel pattern, or upgrade target version. |

For any other rule the report surfaces: open the file under `.camunda/node_modules/bpmnlint-plugin-camunda-compat/rules/camunda-cloud/<rule>.js` (populated by `c8 os install`) — the source of each rule is short and self-explanatory.

## Note on the user's project state

The wrapper places `.bpmnlintrc` inside the skill directory, not the user's project. This means:
- Any project-side `.bpmnlintrc` the user has is ignored — runtime-compat checks always use the configuration this skill ships.
- The user's project directory stays free of skill-installed config files; `bpmnlint` + its plugins are shared, project-level dependencies under `.camunda/node_modules` (installed by `c8 os install`), not per-skill installs.
- Re-running with a different `--version` rewrites the in-skill config — single-source-of-truth.
