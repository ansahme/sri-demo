---
name: process-os-markdown-integrity-check
description: >-
  Use to validate that a changed markdown file in a phase's document set is
  still consistent with the rest of that set — cross-references, phase ordering,
  participants/systems, data objects, naming, and structural step/gateway
  validity. Doc-set-agnostic via --dir, so it serves any phase: invoked per
  changed .md when discovery or transformation fold in feedback, and reusable
  standalone after any manual edit. Reads diffs, reports inconsistencies, and
  reconciles unambiguous ones.

  USE FOR: process-os-markdown-integrity-check, validate a phase's docs for
  consistency, check a changed process-NN-*.md against the rest, find
  cross-document drift.

  DO NOT USE FOR: generating BPMN (use process-os-bpmn-generation), applying
  review answers (use process-os-review-answer-application), reconciling
  non-markdown feedback (that is discovery's fold-in step), running discovery
  from scratch (use /process-os-process-discovery).
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
# /process-os-markdown-integrity-check

**ANALYSIS SKILL** — validates one changed markdown file against the whole discovery doc set
for semantic + structural integrity. INVOKES: nothing (leaf); invoked by
`/process-os-process-discovery`'s integrity-check step, per changed `.md`, and usable standalone.

Markdown is the single source of truth for a `/process-os-process-discovery` result. When one `.md`
changes, the rest of the set can silently drift — a renamed step still referenced in
`00-index.md`, a new system never added to `participants-and-systems.md`, a gateway branch
that no longer resolves. This skill checks a **single changed file** against its siblings and
either **reconciles** unambiguous drift or **reports** what needs a human.

## USE FOR
- Validating a changed `process-NN-*.md` / `edge-NN-*.md` against the rest of the set
- Catching cross-document drift after a manual edit to the discovery docs
- `/process-os-process-discovery`'s integrity-check step, run per changed `.md`

## DO NOT USE FOR
- Generating or updating BPMN → `process-os-bpmn-generation`
- Applying answered review questions → `process-os-review-answer-application`
- Folding non-markdown feedback into `.md` → discovery's fold-in step

## EXEC: 1. Resolve inputs

| Var | Flag | Default |
|-----|------|---------|
| `FILE` | `--file <path>` | required — the changed `.md` to validate |
| `DIR` | `--dir <dir>` | the last completed `process-discovery` iteration's `artifacts/` — the doc set to validate against; exit `2` if none has completed yet |

If `FILE` does not exist or is not under `DIR` → output `"Nothing to validate: <FILE>"` and stop.

## EXEC: 2. Gather integrity context (diff-first, bounded)

Do **not** slurp the whole set. Gather only what the check needs:

```bash
# What changed in the target (diff-first — usually all you need). Diff against HEAD, not
# just the worktree: a caller may have already staged this file (process-os-process-transformation's
# feedback phases stage as they go) or left it unstaged (process-os-process-discovery's
# Phase 3 (Fold-in) does not stage anything until its Phase 6 Commit gate) — `git diff HEAD`
# shows either, where a plain `git diff` would miss a staged change.
git --no-pager diff HEAD -- "<FILE>"

# The sibling docs and their anchors (cheap indexes, not full bodies).
node ".github/skills/process-os-markdown-integrity-check/scripts/sibling-anchors.cjs" --file "<FILE>" --dir "<DIR>"
```

It prints the sibling paths, then one `path:line:text` per anchor line (`#`/`##`/`###`
headings, `[UserTask]`/`[ServiceTask]`/`[ManualTask]`/`[ScriptTask]` markers, `[GAP]`).
`<FILE>` is not in the paths list — you already have its diff — but its own anchors are in
the index, since the checks below run in both directions and a diff shows only the lines
that changed, not the file's full inventory.

The gather is dir-aware, not a blind recursive sweep: catalog docs live directly under
`<DIR>` (e.g. `process-discovery/iteration-3/artifacts/participants-and-systems.md`). A doc
set that nests phase docs one level down, in `<FILE>`'s own subdirectory, has those gathered
too. So it gathers `<DIR>`'s own top-level `*.md` plus `<FILE>`'s immediate directory's `*.md`
when `<FILE>` is nested, and nothing deeper — never commingling one subdirectory's docs with
an unrelated sibling's. `.bpmn` files are never gathered regardless of nesting: only `*.md` is
listed.
Exit `2` means no index was produced — `<DIR>` does not exist, it is not a directory, or one
of its docs could not be read. None of those is a clean doc set: read the message on stderr
for which it was, then stop and report it.

If `git diff HEAD` is empty or lacks context (e.g. a brand-new file), read `FILE` in full — it
is a single phase doc, well under the ~25 KB Read limit. For a **sibling** you must inspect,
prefer its `git diff HEAD` or a slice extracted with
`node ".github/skills/process-os-markdown-integrity-check/scripts/search-files.mts" --pattern "<REGEX>" "<SIBLING>"` over a full read.

## AI: 3. Run the integrity checks

Validate the target's change against the set. For each check, decide **reconcile** (the fix is
unambiguous and local) vs **flag** (needs a human decision):

| Check | Drift it catches |
|-------|------------------|
| **Cross-references** | a step / actor / system / data object named in `FILE` that no sibling defines (or vice-versa) |
| **Phase ordering** | `FILE`'s trigger / end-state no longer lines up with `00-index.md` or the neighbouring `process-NN` |
| **Participants & systems** | a system/actor introduced or renamed in `FILE` but missing/stale in `participants-and-systems.md` |
| **Data objects** | a business object referenced in `FILE` but absent/misnamed in `data-objects.md` |
| **Naming consistency** | the same element named differently across docs (tense/casing/phrasing) |
| **Structural validity** | invalid or missing step type tag; a gateway without resolvable branches; a dangling `[GAP]` the change was meant to close |

**Reconcile** unambiguous drift by editing the affected `.md` (e.g. add the new system to
`participants-and-systems.md`, align a renamed step in `00-index.md`). **Flag** anything that
changes meaning or has more than one plausible fix.

## GATE: 4. Attended vs unattended

The feedback gate lives in the shared project config `run.config.yaml`, but the gate **key**
is per doc set — derive it from `DIR` (Step 1) so a non-discovery run reads its own gate rather
than discovery's. The rows below are examples, not a closed set — add a row per doc set:

| `DIR` | `<GATE>` |
|-------|----------|
| starts with `process-transformation` | `processTransformationGate` |
| anything else | `processDiscoveryGate` |

Read `<GATE>.md` from `run.config.yaml` (default `true`), substituting the key from the table
literally:

```bash
node ".github/skills/process-os-markdown-integrity-check/scripts/read-run-config.cjs" "<GATE>.md"
```

An exit of 2 — `run.config.yaml` missing/unparseable, or ProcessOS Node deps not installed —
is a hard error: report it and stop. Neither branch below matches an empty value, so falling
into one silently would pick attended-vs-unattended behaviour the config never specified.

- `true` (attended) → present each proposed reconciliation and each flagged issue for
  approve/reject before writing.
- `false` (unattended) → apply the unambiguous reconciliations; still list the flagged issues.

(This skill never runs `git add` itself. `/process-os-process-discovery` stages its
entire iteration directory once, at its commit-gate step — not per file here.
`/process-os-process-transformation` stages the affected `.md` itself, in its own
Stage step. Run standalone and asked to stage, `git add` the reconciled file yourself.)

## Output

```
Integrity check — <FILE> vs <DIR> (N sibling docs)

Reconciled (M):
  - <file>: <what was aligned>
Flagged for you (K):
  - <file>: <the inconsistency and why it needs a decision>

Verdict: CONSISTENT | RECONCILED | NEEDS-DECISION
```

`CONSISTENT` = no drift; `RECONCILED` = all drift was unambiguous and fixed; `NEEDS-DECISION`
= at least one flagged issue remains.
