#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// List a doc set's sibling markdown files and the anchor lines inside them —
// headings and element/gap markers — as a cheap index of the set to check a
// changed file against.
//
// A script rather than shell steps: collecting the paths and grepping them needs
// arrays, `[ … ]` tests, process substitution and NUL-delimited reads, none of which
// native PowerShell 5.1 can parse.
//
// The gather is deliberately DIR-AWARE rather than a recursive sweep. Catalog docs
// sit directly under <dir> (e.g.
// `process-discovery/iteration-<N>/artifacts/participants-and-systems.md`). A doc
// set that nests phase docs one level down, in the changed file's own
// subdirectory, has those gathered too. So: <dir>'s own top-level `*.md`, plus the
// changed file's immediate directory's `*.md` when it is nested, and nothing
// deeper — never commingling one subdirectory's docs with an unrelated sibling's.
//
// Usage:
//   node "scripts/sibling-anchors.cjs" --file <changed.md> [--dir <doc-set>]
//
// stdout — the sibling paths, then one `path:line:text` per anchor:
//
//   process-discovery/iteration-<N>/artifacts/00-index.md
//   process-discovery/iteration-<N>/artifacts/participants-and-systems.md
//   process-discovery/iteration-<N>/artifacts/00-index.md:3:## Phases
//   process-discovery/iteration-<N>/artifacts/participants-and-systems.md:12:- [ServiceTask] Notify
//
// The changed file is not listed among the sibling PATHS — the caller already has its
// diff — but its own anchors ARE in the index. The integrity checks run in both
// directions, and a modified file's diff shows only the changed lines, not the full
// heading/[ServiceTask]/[GAP] inventory the cross-checks compare against.
//
// Exit codes:
//   0  the set was gathered (an empty set is a legitimate answer: a doc set with
//      one file has no siblings)
//   2  usage error, <dir> does not exist, or a listed sibling could not be read —
//      neither "the doc set is not there" nor "one of its files is unreadable" is
//      "the doc set is clean"

const fs = require('fs');
const path = require('path');
const { currentIteration } = require(path.join(__dirname, 'iteration-dir.cjs'));

const EXIT = { OK: 0, USAGE: 2 };

const USAGE = 'usage: sibling-anchors.cjs --file <changed.md> [--dir <doc-set>]\n';

/**
 * The doc set to validate against when `--dir` is omitted: the last completed
 * `process-discovery` iteration's `artifacts/`.
 *
 * @returns {string}
 * @throws {Error} When no `process-discovery` iteration has completed — an empty
 *   result here would validate nothing and report a clean doc set that was never
 *   looked at.
 */
function resolveDefaultDir() {
  const entry = currentIteration('process-discovery', { complete: true });
  if (!entry) {
    throw new Error('no completed process-discovery iteration found; pass --dir explicitly');
  }
  return entry.artifacts;
}

// Headings down to h3, element-type markers, and gap markers — the anchors the
// integrity checks compare across documents.
const ANCHOR =
  /^#{1,3} |\[(?:UserTask|ServiceTask|ManualTask|ScriptTask)\]|\[GAP\]/;

/**
 * Parse argv into options.
 *
 * @param {string[]} argv Arguments after the script path.
 * @returns {{file: string, dir: string}}
 * @throws {Error} On a missing `--file`, an unknown flag, or a flag with no value.
 */
function parseArgs(argv) {
  let file = null;
  let dir = null;
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--file' || arg === '--dir') {
      // A flag with no value would otherwise gather the wrong directory and
      // report a clean set for a doc set never looked at.
      const value = argv[++i];
      if (value === undefined) throw new Error(`${arg} requires a value`);
      if (arg === '--file') file = value;
      else dir = value;
    } else {
      throw new Error(`unexpected argument: ${arg}`);
    }
  }
  if (!file) throw new Error('--file is required');
  if (dir === null) dir = resolveDefaultDir();
  return { file, dir };
}

/**
 * Whether `p` is a regular file, following symlinks.
 *
 * Only "absent" answers false. A stat that fails for any OTHER reason — an
 * unsearchable parent directory, say — is rethrown for markdownIn's "could not
 * read" path: swallowed, it would drop every listed doc and exit 0 with an empty
 * index, which is the present-but-broken-read-as-clean state this file refuses.
 *
 * @param {string} p Path to test.
 * @returns {boolean} False when absent, dangling, or not a regular file.
 * @throws {Error} When `p` exists but could not be stat'ed.
 */
function isFile(p) {
  try {
    return fs.statSync(p).isFile();
  } catch (err) {
    // ELOOP is a symlink cycle, which is "no file at the end of it" too.
    if (err.code === 'ENOENT' || err.code === 'ENOTDIR' || err.code === 'ELOOP') return false;
    throw new Error(`could not read ${p}: ${err.message}`);
  }
}

/**
 * The `*.md` files directly in `dir` — one level, never recursive.
 *
 * @param {string} dir Directory to list.
 * @returns {string[]} Paths, sorted; empty when `dir` is absent.
 */
function markdownIn(dir) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch (err) {
    // An absent directory legitimately has no markdown in it. An unreadable one
    // does not: collapsed to [], it exits 0 with a clean, empty index — the
    // broken-as-empty state anchors() above refuses to produce.
    if (err.code !== 'ENOENT') throw new Error(`could not read ${dir}: ${err.message}`);
    return [];
  }
  // Dirent.isFile() is false for a symlink, so a doc set that symlinks a shared
  // catalog would contribute no anchors under a clean exit 0. Follow the link and ask
  // what it points at instead — which also drops a DANGLING one, since anchors()
  // treats an unreadable listed file as fatal and one broken link would otherwise take
  // the whole index down with it.
  return entries
    .filter((entry) => path.extname(entry.name) === '.md' && isFile(path.join(dir, entry.name)))
    .map((entry) => path.join(dir, entry.name))
    .sort();
}

/**
 * The sibling docs for `file` within `dir`.
 *
 * @param {string} file Changed markdown file.
 * @param {string} dir Doc-set root.
 * @returns {string[]} Paths, de-duplicated and sorted, excluding `file` itself.
 */
function siblings(file, dir) {
  const fileDir = path.dirname(file);
  const found = new Set(markdownIn(dir));
  // Only when the changed file is nested: a flat doc set would otherwise list
  // <dir> twice, which is harmless but makes the intent unreadable.
  if (path.resolve(fileDir) !== path.resolve(dir)) {
    for (const sibling of markdownIn(fileDir)) found.add(sibling);
  }
  found.delete(file);
  // A caller may pass `./process-discovery/x.md` for a file listed as
  // `process-discovery/x.md`; compare resolved so the exclusion still holds.
  const resolvedFile = path.resolve(file);
  return [...found].filter((s) => path.resolve(s) !== resolvedFile).sort();
}

/**
 * The anchor lines in `files`.
 *
 * A file that cannot be READ throws rather than being skipped: every path here
 * came from a directory listing moments ago, so an unreadable one is a broken
 * state, and dropping it silently would hand the caller an index missing that
 * file's anchors under exit 0 — the same "present but broken read as clean" the
 * missing-`<dir>` check exists to prevent.
 *
 * @param {string[]} files Markdown files.
 * @returns {string[]} `path:line:text` entries, in file order.
 * @throws {Error} When a listed file cannot be read.
 */
function anchors(files) {
  const out = [];
  for (const file of files) {
    let contents;
    try {
      contents = fs.readFileSync(file, 'utf8');
    } catch (err) {
      throw new Error(`could not read ${file}: ${err.message}`);
    }
    contents.split(/\r?\n/).forEach((line, index) => {
      if (ANCHOR.test(line)) out.push(`${file}:${index + 1}:${line}`);
    });
  }
  return out;
}

/**
 * The files whose anchors belong in the index: the siblings, plus the changed file
 * itself when it is on disk (a brand-new file may not be yet).
 *
 * @param {string} file Changed markdown file.
 * @param {string[]} found Its siblings, from siblings().
 * @returns {string[]} Paths, sorted.
 */
function indexed(file, found) {
  // isFile, not existsSync: existsSync answers false for EVERY stat failure, so a
  // present-but-unstattable file would be dropped from the index under exit 0 — an
  // incomplete inventory reported as a clean one. isFile throws for anything but
  // "absent", which the caller turns into exit 2.
  if (!isFile(file)) return found;
  return [...found, file].sort();
}

module.exports = { ANCHOR, EXIT, anchors, indexed, markdownIn, parseArgs, resolveDefaultDir, siblings };

if (require.main === module) {
  let options;
  try {
    options = parseArgs(process.argv.slice(2));
  } catch (err) {
    process.stderr.write(`sibling-anchors.cjs: ${err.message}\n${USAGE}`);
    process.exit(EXIT.USAGE);
  }
  // Not existsSync: it answers false for every stat failure, so a doc set that IS there
  // behind an unreadable ancestor was reported as "not found" — pointing the reader at
  // the wrong directory and hiding the permission problem the gather would have named.
  // A --dir naming a file stats fine and falls through to the gather, which names it.
  try {
    fs.statSync(options.dir);
  } catch (err) {
    const absent = err.code === 'ENOENT' || err.code === 'ENOTDIR';
    process.stderr.write(
      absent
        ? `Doc set not found: ${options.dir}\n`
        : `sibling-anchors.cjs: could not read ${options.dir}: ${err.message}\n`,
    );
    process.exit(EXIT.USAGE);
  }
  let lines;
  try {
    const found = siblings(options.file, options.dir);
    lines = [...found, ...anchors(indexed(options.file, found))];
  } catch (err) {
    // An incomplete index under exit 0 would read as a clean doc set.
    process.stderr.write(`sibling-anchors.cjs: ${err.message}\n`);
    process.exit(EXIT.USAGE);
  }
  // Deliberately no process.exit here. It quits immediately, dropping whatever
  // stdout has not finished writing, and on macOS a write to a pipe finishes in the
  // background — so a long index can be cut off mid-way. The caller cannot tell a
  // cut-off index from a complete one; it just looks like a doc set with fewer
  // anchors. Returning instead exits 0 on its own, after the write completes.
  if (lines.length) process.stdout.write(`${lines.join('\n')}\n`);
}
