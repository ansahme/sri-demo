---
name: process-os-governance-job-update
description: >-
  Extend the timeout of a Zeebe job lock. Accepts jobKey as a direct argument.
  Use --timeout 1 to release a stuck job immediately (frees it for re-activation
  by any worker).
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
Read `references/c8ctl.md` for the full c8ctl command reference.

Parse skill arguments:
- First positional argument → `<jobKey>` (required)
- `--timeout <seconds>` → timeout in seconds, default `3600`; use `1` to release the lock immediately
- `--profile <name>` → pass through to c8ctl (omit the flag entirely when not provided)

If `<jobKey>` is not provided, print:

```
Usage: process-os-governance-job-update <jobKey> [--timeout <seconds>] [--profile <name>]
```

Stop.

---

## EXEC: Phase 1 — Version Check

```bash
node ".github/skills/process-os-governance-job-update/scripts/check-c8ctl-version.cjs" process-os-governance-job-update
```

If the version check fails (non-zero exit), stop here — do not proceed.

---

## EXEC: Phase 2 — Update Job Timeout

Convert `<seconds>` to milliseconds: multiply by 1000.

```bash
c8ctl --json update job <jobKey> --timeout <ms> [--profile <name>]
```

---

## AI: Phase 3 — Confirm

On success, print one of:
- `Job <jobKey> timeout extended to <seconds>s.` (when `<seconds>` > 1)
- `Job <jobKey> lock released.` (when `<seconds>` = 1)

On error, print the c8ctl error output and stop.
