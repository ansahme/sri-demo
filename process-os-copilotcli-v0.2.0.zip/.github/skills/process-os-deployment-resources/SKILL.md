---
name: process-os-deployment-resources
description: >-
  Building block of process-os-deployment — deploy the Camunda resources (BPMN,
  DMN, forms) of a generated bundle to the engine via c8ctl. Lints the
  deployable set, deploys
  process-implementation/artifacts/src/main/resources/{processes,forms,decisions}
  against a caller-provided version-named profile, smoke-tests the main process,
  and triages any deployment failure as a project-independent detail to fix
  inline versus a structural defect in process-os-artifact-generation to fix in
  the generator. Normally invoked by process-os-deployment (which resolves the
  version/profile and owns lifecycle state); can also run standalone to deploy
  just the resources.
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
**Kubernetes / self-managed:** if deploying to a Camunda cluster running on Kubernetes via Helm, read `references/env-helm.md` for the deployment procedure and stop — the steps below are for SaaS and local (C8 Run via c8ctl) only.

For environment setup, read `references/env-saas.md` or `references/env-c8run.md` as appropriate. For the c8ctl reference (commands, output mode, profiles), read `references/c8ctl.md`.

## Inputs — `<PROFILE>`

The orchestrator (`/process-os-deployment` Step 0) resolves `camunda-version`,
provisions the version-named c8ctl profile, and hands this skill the profile
**name** as `<PROFILE>`. Every c8ctl call below passes `--profile "<PROFILE>"` —
substitute the name literally. It is not a shell variable: one does not survive
across skill invocations, and a shell-variable spelling of it is a *built-in*
variable in PowerShell (the profile-script path), so that form silently addresses
a nonsense profile there rather than failing.

Running this building block **standalone**? Resolve it yourself first:

```bash
node ".github/skills/process-os-deployment-resources/scripts/resolve-camunda-version.cjs" run.config.yaml
```

`<PROFILE>` is then `Camunda<what the resolver printed>`. Ensure that
cluster/profile exists — see `/process-os-deployment` Step 0.

This skill does **not** write `.camunda/state.md`; the orchestrator owns the
lifecycle phase.

## EXEC: Step 1 — Lint before deploy

Run all relevant linters on the deployable set before sending to the engine. Zero errors required across the board; warnings are non-blocking. If a category lints clean but you know it will fail to deploy (e.g. broken DMNs that have not been regenerated), skip that category in Step 3 rather than letting c8ctl reject it atomically.

Resolve the BPMN deploy tree and the deployable set in it:

```bash
node ".github/skills/process-os-deployment-resources/scripts/resolve-deploy-set.cjs"
```

It walks candidate trees in priority order, first non-empty wins (see the script's `CANDIDATES` and `EXCLUDED_SEGMENTS` for the exact trees and skip list). It prints the resolved tree as `<DEPLOY_DIR>`, then one line per deployable resource:

```text
DEPLOY_DIR: process-implementation/artifacts/src/main/resources/processes
BPMN: process-implementation/artifacts/src/main/resources/processes/process-01-intake.bpmn
DMN: process-implementation/artifacts/src/main/resources/decisions/eligibility.dmn
FORM: process-implementation/artifacts/src/main/resources/forms/intake.form
```

`NO DEPLOY DIR` (exit 1) means no candidate tree holds a BPMN — there is nothing to deploy. Never read that as "everything linted clean"; stop and report it. Exit 2 is the different case: a candidate tree is there but could not be read, so no verdict was reached at all — report that too, and do not treat it as an empty deploy set.

Then lint each listed file by invoking the matching skill on it — one invocation per file, not a shell loop:

- every `BPMN:` file → `/process-os-camunda-compatibility-check <file>` (structural + Camunda 8 runtime compat, a stricter superset)
- every `DMN:` file → `/process-os-dmn-linting <file>` (structural validation)
- every `FORM:` file → `/process-os-forms-linting <file>` (JSON Schema validation)

If you deploy a single file in Step 3, lint that single file in Step 1 instead — match scopes.

If any linter reports errors:
- **BPMN errors** → fix or regenerate via `/process-os-process-transformation --bpmn` / `/process-os-artifact-generation`. Do NOT proceed.
- **DMN errors** → fix or regenerate via `/process-os-artifact-generation`; if the upstream generator is the bug, drop the broken DMNs from Step 3's deploy call and record under Step 4 `⚠️ Partial`.
- **Form errors** → fix per `/process-os-forms-linting` output; same partial-skip rule applies.

## EXEC: Step 2 — Set c8ctl output to JSON

```bash
c8ctl output json
```

Persists the preference. Subsequent commands return JSON to stdout, agent-parseable.

## EXEC: Step 3 — Deploy to Camunda

**Always deploy with `c8ctl` — it is the one tool for deployment and every other
operation against the cluster** (deploy, smoke-test, list, incidents). It emits a
JSON deployment record Step 4 parses for definition keys, decouples deploy from
worker availability, and keeps a single, scriptable interface to the engine. Do
NOT deploy by other means (e.g. relying on `mvn spring-boot:run` to auto-deploy
on startup, or hand-rolled REST calls). `mvn spring-boot:run` has one role here —
starting the Java **workers** *after* c8ctl has deployed — see Step 3.5.

c8ctl is atomic per-invocation — a single bad resource fails the whole call — so
target the subdirectories you want, NOT the resources root. Camunda Spring Boot
starter projects (the shape `/process-os-artifact-generation` produces) keep
`application*.yaml` at `src/main/resources/`; c8ctl treats those as "unknown
resource type" and refuses to deploy. Always pass the deployable subdirs (any
subset of `processes/`, `forms/`, `decisions/`), with the profile from Step 0:

```bash
c8ctl deploy process-implementation/artifacts/src/main/resources/processes process-implementation/artifacts/src/main/resources/forms process-implementation/artifacts/src/main/resources/decisions --profile "<PROFILE>"
```

(For a single-module Spring Boot starter or legacy layout, substitute the deploy
tree resolved in Step 1: `<DEPLOY_DIR>` and its `../decisions`, `../forms` siblings.)

If a sibling category fails (e.g. DMN parsing errors), drop that argument and
re-run with the remaining subdirs, then go to Step 3.6 to triage — record the
exclusion in `.camunda/state.md` Notes for Step 4. Do NOT pass
`process-implementation/artifacts/src/main/resources` as a single argument: it picks up
`application*.yaml` and any broken sibling takes down the atomic deploy.

Single-file deploy is also fine when you only want one resource:

```bash
c8ctl deploy process-implementation/artifacts/src/main/resources/processes/process-01-intake.bpmn --profile "<PROFILE>"
```

On success the record is `{"status":"success","key":...}` plus one array entry
per resource. On failure it is `{"status":"error",...}` with a `Command 'CREATE'
rejected` block naming the offending files — go to Step 3.6.

## GATE: Step 3.5 — Smoke-test the main process

Pick the main process from the deployment record (the BPMN listed first in `state.md` "Main process" or the only top-level executable BPMN if there is one). Start one instance and verify it doesn't immediately incident:

```bash
c8ctl create pi --bpmnProcessId <MainProcessId> --profile "<PROFILE>"
# use --id as a synonym; c8ctl 2.8+ rejects positional process IDs
c8ctl get pi --processInstanceKey <key-from-create> --profile "<PROFILE>"
```

Expected: `state=ACTIVE` and either `hasIncident=false` (workers running) or `hasIncident=true` with a job-not-activated incident (workers not running — fine for a deploy-only verification). Any other incident type means the deploy is broken even though c8ctl exit was 0; surface it and stop.

To exercise the process to completion you need the Java **workers** running.
Start them *after* the c8ctl deploy above, via `/process-os-deployment-code`
Step 2 — it owns the worker app's lifecycle and picks the Spring profile that
matches the cluster `<PROFILE>` addresses (booting the default `local` against a
SaaS cluster leaves the workers unable to connect). Maven's role there is running
the workers, not deploying — c8ctl already did that. With workers up,
`hasIncident=true` always indicates a real defect.

## AI: Step 3.6 — Triage deployment failures

For every rejected resource, classify the error and act. To attribute a failure
in an atomic multi-subdir deploy, re-run one subdir at a time (`processes` /
`forms` / `decisions`) with `--profile "<PROFILE>"`; the category that fails
alone is the culprit. The decision rule:

> **Would this error appear for _any_ project generated by
> `process-os-artifact-generation`** (it lives in the generator's
> template/output), **or only because of project-specific content the user still
> owes** (secrets, business rules, endpoints)?

**Class A — project-independent detail → fix inline (in the project, not process-os):**

| Signature | Fix |
|-----------|-----|
| `Multiple profiles configured but no profile specified` | Pass `--profile "<PROFILE>"` (Step 0/3). |
| c8ctl skips `application*.yaml` / "unknown resource type" | Deploy the three subdirs, not the resources root. |
| A user-edited DMN/BPMN cell left half-filled (real business logic still `TODO`) | Fill in the project's decision logic / condition. |
| Runtime incident after deploy: missing connector secret, unbound variable | Supply the project's secret/variable — a TODO the generator intentionally left. |

**Class B — structural defect in process-os-artifact-generation → fix the generator:**

| Signature | Root cause / fix |
|-----------|------------------|
| `Failed to parse DMN: DmnModelException: Unable to parse model` | Generated DMN uses a non-canonical namespace (e.g. `.../20191111/DC/` instead of `.../20180521/DC/`). Fix `skills/process-os-artifact-generation/scripts/generate-dmn.cjs`. |
| `FEEL expression: failed to parse expression ''` | Generated rule cell is empty `<text></text>`. Generator must emit deployable placeholders (`-` for input entries, `null` for output entries). |
| `multiple values aren't allowed for UNIQUE hit policy` on evaluation | Generator emits >1 catch-all stub row under `hitPolicy="UNIQUE"`. It must emit a single stub rule. |
| A malformed Zeebe extension element the generator emits for every process | Fix the corresponding generator script/template under `skills/process-os-artifact-generation/`. |

For a Class B defect: fix the generator script, extend its unit test to lock the
fix, regenerate the affected artifacts, and re-deploy. Because the defect is in
the shared generator, raise it against `process-os` (commit/PR), not just this
project. If you cannot fix it here, drop the broken category from the Step 3
deploy call so the rest deploys, and record the excluded category + the generator
defect in Step 4 `⚠️ Partial`.

## Report

Report the deployment key from the c8ctl "Deployment successful" JSON plus the
deployed process-definition IDs (from `Type=Process` entries; for 5+, a count).
If a category was excluded due to an upstream defect, name it and the defect.

Return control to the orchestrator (`/process-os-deployment`), which runs the
`-code` half and writes the lifecycle phase. If deploy failed, say so — the
orchestrator's Step 1 gate stops before booting workers.
