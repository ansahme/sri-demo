#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Resolve the BPMN deploy tree and list the deployable resources in it.
//
// A script rather than shell steps: resolving the tree needs a directory walk with a
// depth limit and an exclusion list, and every shell spelling of that is bash-only —
// command substitution around a `for` loop, `[ -d … ]`, `&&` chaining and `xargs sh -c`
// are all parse errors in native PowerShell 5.1.
//
// This script only NAMES the files. Linting them is a ProcessOS skill invoked per file,
// which the agent runs itself, so there is no loop here to run it in.
//
// Usage:
//   node "scripts/resolve-deploy-set.cjs"
//
// stdout, in this order — nothing is written to stderr on the success path, so a
// caller can capture stdout without a redirect PowerShell spells differently:
//
//   DEPLOY_DIR: process-implementation/artifacts/src/main/resources/processes
//   BPMN: process-implementation/artifacts/src/main/resources/processes/process-01-intake.bpmn
//   DMN: process-implementation/artifacts/src/main/resources/decisions/eligibility.dmn
//   FORM: process-implementation/artifacts/src/main/resources/forms/intake.form
//
// A category with no files simply contributes no lines — that is an answer, not
// an error. No candidate directory holding a BPMN at all prints one line:
//
//   NO DEPLOY DIR
//
// Exit codes:
//   0  a deploy dir was resolved (its resource lines follow)
//   1  no candidate directory holds a deployable BPMN — there is nothing to
//      deploy, which the caller must not read as "everything linted clean"
//   2  usage error, or a candidate tree exists but could not be read. An
//      unreadable tree must NOT fall through to 1: "nothing to deploy" is a
//      verdict about a tree that was actually looked at.

const fs = require('fs');
const path = require('path');

const EXIT = { OK: 0, NO_DEPLOY_DIR: 1, USAGE: 2 };

const USAGE = 'usage: resolve-deploy-set.cjs\n';

// Priority order, first non-empty wins:
//   1. ProcessOS / process-os-artifact-generation output
//   2. single-module Spring Boot starter
//   3. legacy Maven layout
//   4. standalone BPMN-only repo
const CANDIDATES = [
  path.join('process-implementation', 'artifacts', 'src', 'main', 'resources', 'processes'),
  path.join('src', 'main', 'resources', 'processes'),
  path.join('src', 'main', 'resources', 'bpmn'),
  '.',
];

// Directory names that never hold a deployable resource. Matched by segment, not
// by substring: a `/`-joined path literal would never match on Windows, and a
// substring test would exclude a legitimate `build-permits/` process directory.
const EXCLUDED_SEGMENTS = new Set([
  'target',
  'node_modules',
  '.git',
  'build',
  '.snapshots',
  'transformation',
  'process-bpmn-reviewed',
]);

// Candidate SELECTION is depth-limited so a deep unrelated tree under `.` (candidate
// 4) cannot make the repo root look like a deploy dir. Collection from the chosen dir
// is NOT limited — see collectDeploySet.
const MAX_DEPTH = 3;

/**
 * Files under `dir` with `extension`, skipping excluded directory segments.
 *
 * @param {string} dir Directory to walk.
 * @param {string} extension Including the dot, e.g. `.bpmn`.
 * @param {number} [maxDepth] Directory levels below `dir` to descend; `Infinity`
 *   for an unbounded sweep.
 * An unreadable directory throws, deliberately, and there is no tolerant mode. Read
 * as empty it would be worse than a hard stop in every direction: during collection
 * the caller deploys a set missing resources, and during candidate selection it reads
 * as "this candidate holds no BPMN" and silently demotes to a lower-priority tree —
 * linting and deploying stale BPMN, exit 0, nothing on stderr to say the intended
 * tree was never read. (Tolerating it during selection alone buys nothing either:
 * collection re-walks the chosen tree unbounded and strict, so the same directory
 * stops the run one step later.)
 *
 * @returns {string[]} Paths, sorted, relative to the working directory.
 */
function findFiles(dir, extension, maxDepth = MAX_DEPTH) {
  const found = [];
  const walk = (current, depth) => {
    let entries;
    try {
      entries = fs.readdirSync(current, { withFileTypes: true });
    } catch (err) {
      // An absent sibling directory contributes nothing — `../decisions` simply
      // may not exist. An unreadable one is different: read as empty, the caller
      // deploys a set missing resources, or reports NO DEPLOY DIR for a tree that
      // does hold BPMN.
      if (err.code !== 'ENOENT' && err.code !== 'ENOTDIR') {
        throw new Error(`could not read ${current}: ${err.message}`);
      }
      return;
    }
    for (const entry of entries) {
      const abs = path.join(current, entry.name);
      if (entry.isDirectory()) {
        // `depth + 1`, not `depth`: a file inside this subdirectory sits
        // `depth + 2` levels below `dir`, so gating on `depth >= maxDepth` would
        // descend one level further than `maxDepth` allows.
        if (depth + 1 >= maxDepth) continue;
        if (EXCLUDED_SEGMENTS.has(entry.name)) continue;
        walk(abs, depth + 1);
      } else if (path.extname(entry.name) === extension) {
        found.push(abs);
      }
    }
  };
  walk(dir, 0);
  return found.sort();
}

/**
 * The first candidate directory that holds a deployable BPMN.
 *
 * @param {string[]} [candidates] Overridable, for tests.
 * A null return therefore always means "looked everywhere, found no BPMN". A candidate
 * that could not be read throws instead, so null is never a verdict about a tree
 * nobody managed to read.
 *
 * @returns {string|null}
 */
function resolveDeployDir(candidates = CANDIDATES) {
  for (const candidate of candidates) {
    if (!isDirectory(candidate)) continue;
    if (findFiles(candidate, '.bpmn').length > 0) return candidate;
  }
  return null;
}

/**
 * Whether `dir` is a directory that exists.
 *
 * One stat in a try/catch rather than `existsSync` + `statSync`: existsSync answers
 * false for EVERY stat failure, so an unreadable ANCESTOR of a candidate reads as
 * "this candidate is absent" and the loop demotes to a lower-priority tree — linting
 * and deploying stale BPMN, exit 0, with nothing on stderr. findFiles' strictness
 * cannot catch that, because it is never reached.
 *
 * @param {string} dir Path to test.
 * @returns {boolean} False only when nothing is there.
 * @throws {Error} When `dir` exists but could not be stat'ed.
 */
function isDirectory(dir) {
  try {
    return fs.statSync(dir).isDirectory();
  } catch (err) {
    if (err.code === 'ENOENT' || err.code === 'ENOTDIR') return false;
    throw new Error(`could not read ${dir}: ${err.message}`);
  }
}

/**
 * The deployable set for `deployDir`.
 *
 * Every sweep here is unbounded, BPMN and sibling categories alike. The depth limit
 * belongs to candidate SELECTION only (so a deep unrelated tree cannot elect the repo
 * root); applying it to collection would lint a narrower set than Step 3 deploys —
 * `c8ctl deploy …/decisions` picks up `decisions/v2/eligibility.dmn` recursively, so a
 * resource too deep to be listed still gets deployed, unlinted.
 *
 * DMN and form resources are the siblings of the BPMN tree (`../decisions`,
 * `../forms`).
 *
 * @param {string} deployDir Resolved BPMN deploy tree.
 * @returns {{bpmn: string[], dmn: string[], form: string[]}}
 */
function collectDeploySet(deployDir) {
  // Not path.resolve(deployDir) first: for the repo-root candidate ('.'), resolving to
  // an absolute path before taking dirname climbs to the parent of the repo itself and
  // looks for siblings outside it. `path.dirname('.')` is '.', which is what we want.
  const parent = path.dirname(deployDir);
  const sibling = (name) => path.relative(process.cwd(), path.join(parent, name)) || '.';
  return {
    bpmn: findFiles(deployDir, '.bpmn', Infinity),
    dmn: findFiles(sibling('decisions'), '.dmn', Infinity),
    form: findFiles(sibling('forms'), '.form', Infinity),
  };
}

/**
 * The stdout lines for a resolved set.
 *
 * @param {string} deployDir
 * @param {{bpmn: string[], dmn: string[], form: string[]}} set
 * @returns {string[]}
 */
function formatLines(deployDir, set) {
  return [
    `DEPLOY_DIR: ${deployDir}`,
    ...set.bpmn.map((f) => `BPMN: ${f}`),
    ...set.dmn.map((f) => `DMN: ${f}`),
    ...set.form.map((f) => `FORM: ${f}`),
  ];
}

module.exports = {
  CANDIDATES,
  EXCLUDED_SEGMENTS,
  EXIT,
  collectDeploySet,
  findFiles,
  formatLines,
  resolveDeployDir,
};

if (require.main === module) {
  if (process.argv.length > 2) {
    process.stderr.write(USAGE);
    process.exit(EXIT.USAGE);
  }
  let deployDir;
  let lines;
  try {
    deployDir = resolveDeployDir();
    if (deployDir) lines = formatLines(deployDir, collectDeploySet(deployDir));
  } catch (err) {
    // findFiles throws on an unreadable directory. Letting that escape would exit
    // 1 — the NO DEPLOY DIR code — and the caller would report "nothing to deploy"
    // for a tree it never managed to read.
    process.stderr.write(`resolve-deploy-set.cjs: ${err.message}\n`);
    process.exit(EXIT.USAGE);
  }
  if (!deployDir) {
    process.stdout.write('NO DEPLOY DIR\n');
    process.exit(EXIT.NO_DEPLOY_DIR);
  }
  // Deliberately no process.exit here. It quits immediately, dropping whatever
  // stdout has not finished writing, and on macOS a write to a pipe finishes in the
  // background — so a long list can be cut off mid-way. A cut-off list looks like a
  // repo with fewer resources to lint, not like an error. Returning instead exits 0
  // on its own, after the write completes.
  process.stdout.write(`${lines.join('\n')}\n`);
}
