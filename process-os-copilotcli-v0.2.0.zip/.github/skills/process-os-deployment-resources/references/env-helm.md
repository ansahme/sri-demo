# Self-Managed — Helm Chart

Reference for installing and upgrading Camunda 8 on Kubernetes using the official Helm chart.

---

## Prerequisites

```bash
kubectl version --client    # 1.25+
helm version                # 3.12+
kubectl get nodes           # cluster connected and ready
```

Add the Camunda Helm repo:

```bash
helm repo add camunda https://helm.camunda.io
helm repo update
```

---

## Install

```bash
helm install camunda camunda/camunda-platform \
  --namespace camunda-platform \
  --create-namespace \
  --values values.yaml
```

Wait for all pods to be ready:

```bash
kubectl rollout status deployment -n camunda-platform
kubectl get pods -n camunda-platform
```

Expected pods: `camunda-zeebe-*`, `camunda-operate-*`, `camunda-tasklist-*`, `camunda-identity-*`, `camunda-keycloak-*`, `camunda-elasticsearch-*` (and optionally `camunda-optimize-*`, `camunda-connectors-*`).

---

## Minimal values.yaml configurations

### Development (local Kubernetes / kind / minikube)

```yaml
# Minimal dev setup — single broker, no HA
global:
  identity:
    auth:
      publicIssuerUrl: "http://localhost:18080/auth/realms/camunda-platform"
      # Override if using Ingress:
      # publicIssuerUrl: "http://identity.camunda.local/auth/realms/camunda-platform"

zeebe:
  clusterSize: 1
  partitionCount: 1
  replicationFactor: 1
  resources:
    requests:
      memory: "1Gi"
      cpu: "500m"
    limits:
      memory: "2Gi"
      cpu: "1"

zeebeGateway:
  resources:
    requests:
      memory: "512Mi"
      cpu: "250m"

operate:
  enabled: true

tasklist:
  enabled: true

optimize:
  enabled: false    # heavy; disable for dev

connectors:
  enabled: true

identity:
  enabled: true
  firstUser:
    username: demo
    password: demo

elasticsearch:
  enabled: true
  master:
    replicaCount: 1
    resources:
      requests:
        memory: "1Gi"
```

### Staging (3-node HA)

```yaml
zeebe:
  clusterSize: 3
  partitionCount: 3
  replicationFactor: 3

optimize:
  enabled: true

connectors:
  enabled: true
  # Connector secrets
  extraEnvVars:
    - name: CAMUNDA_CONNECTOR_SECRETPROVIDER_ENVIRONMENT_API_TOKEN
      valueFrom:
        secretKeyRef:
          name: connector-secrets
          key: api-token

elasticsearch:
  master:
    replicaCount: 3
```

---

## Component flags

| Component | `values.yaml` key | Default |
|-----------|------------------|---------|
| Zeebe broker | always enabled | — |
| Zeebe gateway | always enabled | — |
| Operate | `operate.enabled` | `true` |
| Tasklist | `tasklist.enabled` | `true` |
| Optimize | `optimize.enabled` | `true` |
| Connectors | `connectors.enabled` | `true` |
| Identity + Keycloak | `identity.enabled` | `true` |
| Web Modeler | `webModeler.enabled` | `false` |
| Elasticsearch | `elasticsearch.enabled` | `true` |

Disabling Identity disables all auth. Only do this for isolated dev clusters.

---

## Port-forward for local access

Each forward is a long-lived process, so it has to run in the background — and backgrounding has
no cross-shell spelling (`&` is a parse error in Windows PowerShell 5.1). Use the one your shell
supports; either way, leave the forwards running for as long as you need cluster access.

```text
# bash / zsh
kubectl port-forward svc/camunda-zeebe-gateway 26500:26500 -n camunda-platform &   # Zeebe gRPC
kubectl port-forward svc/camunda-operate 8080:80 -n camunda-platform &             # Zeebe REST / Operate / Tasklist
kubectl port-forward svc/camunda-keycloak 18080:80 -n camunda-platform &           # Identity / Keycloak
kubectl port-forward svc/camunda-optimize 8083:80 -n camunda-platform &            # Optimize

# PowerShell 5.1+
Start-Process kubectl -NoNewWindow -ArgumentList 'port-forward','svc/camunda-zeebe-gateway','26500:26500','-n','camunda-platform'
Start-Process kubectl -NoNewWindow -ArgumentList 'port-forward','svc/camunda-operate','8080:80','-n','camunda-platform'
Start-Process kubectl -NoNewWindow -ArgumentList 'port-forward','svc/camunda-keycloak','18080:80','-n','camunda-platform'
Start-Process kubectl -NoNewWindow -ArgumentList 'port-forward','svc/camunda-optimize','8083:80','-n','camunda-platform'
```

---

## Get credentials

After installing with Identity enabled, get the client secret for the `zeebe` client:

```bash
kubectl get secret camunda-zeebe-identity-secret \
  -n camunda-platform \
  -o jsonpath='{.data.zeebe-secret}' | base64 -d
```

Set `.env` for workers and tests:

```dotenv
CAMUNDA_CLIENT_ID=zeebe
CAMUNDA_CLIENT_SECRET=<value from above>
ZEEBE_REST_ADDRESS=http://localhost:8080
ZEEBE_GRPC_ADDRESS=grpc://localhost:26500
CAMUNDA_OAUTH_URL=http://localhost:18080/auth/realms/camunda-platform/protocol/openid-connect/token
ZEEBE_TOKEN_AUDIENCE=zeebe.camunda.io
```

---

## Upgrade procedure

**Before upgrading**:

1. Read the Camunda release notes for the target version — check for breaking changes
2. Back up Elasticsearch data if this is a major version upgrade
3. Check the Helm chart changelog: `helm show changelog camunda/camunda-platform`

```bash
# Update the chart repo
helm repo update

# Dry run first
helm upgrade camunda camunda/camunda-platform \
  --namespace camunda-platform \
  --values values.yaml \
  --dry-run

# Apply the upgrade
helm upgrade camunda camunda/camunda-platform \
  --namespace camunda-platform \
  --values values.yaml \
  --reuse-values
```

**Monitor the rollout**:

```bash
kubectl rollout status deployment -n camunda-platform --timeout=5m
kubectl get pods -n camunda-platform -w
```

**Known upgrade gotchas**:

- **`clusterSize` changes** require a full cluster restart and data migration — plan for downtime
- **Keycloak realm upgrades** — if the realm schema changed, Keycloak may need to re-import. Check Keycloak logs.
- **Elasticsearch index mappings** — major version upgrades may require re-indexing. Check Operate and Optimize logs for mapping errors.
- **`--reuse-values` risk** — only works if your values.yaml is complete. If a new chart version adds required values, `--reuse-values` won't include them. Prefer `--values values.yaml` with an up-to-date file.

---

## Diagnose connectivity issues

**Check all pods are running**:

```bash
kubectl get pods -n camunda-platform
# All should be Running, not CrashLoopBackOff or Pending
```

**Check Zeebe broker health**:

```bash
kubectl logs -n camunda-platform -l app.kubernetes.io/component=zeebe-broker --tail=50
```

**Check Operate connection to Zeebe**:

```bash
kubectl logs -n camunda-platform -l app.kubernetes.io/component=operate --tail=50
```

Scan those 50 lines yourself for `zeebe`, `error` and `exception`, in either case. `--tail` already
bounds the output, so there is nothing worth a pipe into a filter that does not exist on every
platform.

**Check Identity / Keycloak**:

```bash
kubectl logs -n camunda-platform -l app.kubernetes.io/component=keycloak --tail=50
```

Scan for `error` and `exception` the same way.

**Common failures**:

| Symptom | Cause | Fix |
|---------|-------|-----|
| Operate/Tasklist `503` | Keycloak not ready | Wait for Keycloak pod to be Running; check `publicIssuerUrl` matches port-forward |
| Zeebe `UNAVAILABLE` | Broker not elected | Wait for broker; check `clusterSize` vs actual broker count |
| `401 Unauthorized` on REST API | Wrong audience in token request | Use `zeebe.camunda.io` for Zeebe, `operate.camunda.io` for Operate |
| Optimize shows no data | Elasticsearch not reachable from Optimize | Check `optimize.elasticsearch.host` in values |
| Connectors fail to start | Missing connector secrets | Add `extraEnvVars` with `CAMUNDA_CONNECTOR_SECRETPROVIDER_ENVIRONMENT_*` |

---

## Uninstall

```bash
helm uninstall camunda -n camunda-platform

# Delete PVCs (persistent volumes) if you want a clean slate
kubectl delete pvc -n camunda-platform --all
```

**Warning**: deleting PVCs removes all process instance data and Elasticsearch indices permanently.
