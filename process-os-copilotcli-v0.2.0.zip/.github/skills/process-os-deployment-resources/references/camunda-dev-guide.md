# Camunda 8 Development Guide

Only non-obvious, Camunda-specific patterns that you can't infer from general knowledge. Read before generating any Camunda resources.

---

## MCP Server Setup

### Camunda Docs MCP — REQUIRED (documentation lookups)

URL: `https://camunda-docs.mcp.kapa.ai`
Provides: `search_camunda_knowledge_sources` — semantic search over Camunda 8 docs, forum posts, blogs.
This is how the AI agent looks up connector-specific configs (Slack, Kafka, SendGrid task types and input targets), current API patterns, and BPMN element support. Without it, the agent relies on training data which may be outdated.

First use requires Google sign-in (rate limiting: 40 req/hr, 200 req/day).

**Claude Code:**

```bash
claude mcp add camunda-docs --transport http https://camunda-docs.mcp.kapa.ai
```

**Other tools (VS Code Copilot, Cursor, ChatGPT Desktop):**

```json
{ "mcpServers": { "camunda docs": { "url": "https://camunda-docs.mcp.kapa.ai" } } }
```

See <https://docs.camunda.io/docs/reference/mcp-docs/> for IDE-specific setup.

### Camunda Orchestration Cluster MCP — OPTIONAL (C8 Run 8.9+)

URL: `http://localhost:8080/mcp/cluster` (built-in, enabled by default)
Provides: start instances, search tasks/instances/incidents, resolve incidents, get BPMN XML.
Does NOT provide deployment.

This overlaps with c8ctl (which covers all the same operations plus deployment, watch mode, profiles). Use if your tool supports MCP natively (e.g., Claude Desktop), otherwise c8ctl is preferred.

**Claude Code:** `claude mcp add camunda --transport http http://localhost:8080/mcp/cluster`
SaaS does not have a built-in MCP endpoint — use c8ctl instead for SaaS operations.

---

## BPMN for Camunda 8 (Zeebe)

### Required Namespaces and Attributes

```xml
<bpmn:definitions
  xmlns:zeebe="http://camunda.org/schema/zeebe/1.0"
  xmlns:modeler="http://camunda.org/schema/modeler/1.0"
  modeler:executionPlatform="Camunda Cloud"
  modeler:executionPlatformVersion="8.9.0"
  ...>
  <bpmn:process id="my-process" isExecutable="true">
```

The `zeebe` namespace and `isExecutable="true"` are mandatory. Without `modeler:executionPlatform`, Camunda Modeler won't recognize it as a C8 process.

**Minimum supported version**: Always use `8.6.0` or higher. Camunda no longer supports 8.1–8.5 (dropped as of 8.9 release cycle). Use `8.9.0` for new diagrams; when updating existing diagrams, bump to at least `8.6.0`.

**Key change at 8.5+**: `<zeebe:userTask/>` is required for native user tasks (see User Tasks section). Diagrams without it fall back to the deprecated job-based user task implementation.

### Element and Process Naming

Every generated or edited BPMN must use human-readable, developer-friendly IDs. Never leave Modeler-generated IDs (`Process_1wofod9`, `Activity_1obc9ev`, `Event_0gqxgpw`). These conventions follow [Camunda 8 naming best practices](https://docs.camunda.io/docs/components/best-practices/modeling/naming-technically-relevant-ids/).

| Element | ID convention | Example |
|---------|--------------|---------|
| Process | `PascalCase` + `Process` suffix | `LoanApprovalProcess` |
| Service / user / rule task | `Task_<VerbNoun>` | `Task_ApproveLoan`, `Task_CheckCredit` |
| Start event | `StartEvent_<Trigger>` | `StartEvent_ApplicationReceived` |
| End event | `EndEvent_<Outcome>` | `EndEvent_LoanApproved`, `EndEvent_ApplicationRejected` |
| Exclusive gateway | `Gateway_<Question>` | `Gateway_CreditSufficient` |
| Intermediate catch event | `IntermediateCatchEvent_<WaitFor>` | `IntermediateCatchEvent_ApprovalReceived` |
| Boundary event | `BoundaryEvent_<Type>` | `BoundaryEvent_ApprovalTimeout` |
| Sequence flow | `SequenceFlow_<SourceToTarget>` (optional; omit when obvious) | `SequenceFlow_CheckCreditToGateway` |
| Message | `Message_<Name>` | `Message_ApplicationSubmitted` |
| Error | `Error_<Type>` | `Error_CreditCheckFailed` |

Element **labels** (the visible name in the diagram) follow these semantic rules:

- Tasks: **object + infinitive verb** — "Approve loan", "Check credit score"
- Events: **business state noun** — "Application received", "Loan approved"
- Gateways: **question form** — "Credit score sufficient?"
- Sequence flows from gateways: **labelled with the condition** — "Yes / No" or "Score ≥ 650"
- Use sentence case throughout (first letter uppercase, rest lowercase except proper nouns)

---

### Zeebe Extension Elements

**Service task (custom job worker):**

```xml
<zeebe:taskDefinition type="my-task-type" retries="3"/>
```

The `type` string must exactly match the `taskType` in worker registration. Case-sensitive.

**Business rule task (DMN):**

```xml
<zeebe:calledDecision decisionId="risk-assessment" resultVariable="riskLevel"/>
```

**User task (Camunda Form):**

```xml
<zeebe:formDefinition formId="my-form-id"/>
<zeebe:userTask/>
```

The `formId` must match the `id` field in the `.form` JSON file.
The `<zeebe:userTask/>` element is **required** for native Camunda user tasks (8.5+). Without it, the task falls back to the deprecated job-based implementation and won't appear in the user-tasks API or Tasklist.

**Task assignment** — assign to a group, not an individual. Users claim from the group:

```xml
<zeebe:assignmentDefinition candidateGroups="finance-team" />
```

`assignee` sets a fixed individual (bypasses claiming). `candidateUsers` allows a list of individuals. For dynamic assignment (e.g. round-robin), use a task listener.

**Task list frontends** — three options:

- **Camunda Tasklist** (built-in): works out of the box; limited customisation
- **Custom app via Tasklist API**: full UI control; you handle create/complete/cancel task lifecycle
- **Third-party integration** (Jira, ServiceNow, etc.): bidirectional sync required — listen for task created/completed/cancelled events and propagate both ways

**Setting variables via IO mapping (e.g., before a notification task):**

```xml
<zeebe:ioMapping>
  <zeebe:input source="some-value" target="myVariable"/>
</zeebe:ioMapping>
```

### FEEL variable naming

Process variable names used in `resultVariable`, `zeebe:input`/`zeebe:output` targets, and condition expressions must be valid FEEL identifiers. FEEL treats `-` as the subtraction operator, so **hyphens in variable names silently break expressions**.

Use underscores, not hyphens:

```xml
<!-- Wrong — zzp-score is parsed as (zzp) minus (score) -->
<zeebe:script expression="=klanten.score + omvang.score" resultVariable="zzp-score" />
<conditionExpression>=zzp-score &lt; 5</conditionExpression>

<!-- Correct -->
<zeebe:script expression="=klanten.score + omvang.score" resultVariable="zzp_score" />
<conditionExpression>=zzp_score &lt; 5</conditionExpression>
```

The same rule applies to gateway output variables, ioMapping targets, and any variable name that will appear in a FEEL expression downstream.

### FEEL dotted variable naming conflict (silent bug)

If a process variable is a context object (e.g., `omzet = {totaal: 100000}`) and a script task stores output to `resultVariable="omzet.score"`, two separate things exist in the variable store: the `omzet` context and a flat variable named `omzet.score`.

When any subsequent FEEL expression references `omzet.score`, the engine performs **field access on the context variable** — not a lookup of the flat variable. Since `omzet = {totaal: 100000}` has no `score` field, the result is `null`. No error, no incident.

**Symptoms**: subscores compute and store correctly (visible in Operate's Variables tab), but aggregation tasks or gateway conditions that reference them return null.

**Fix**: never give a `resultVariable` a dot-prefix that matches an existing context variable. Use underscores (`omzet_score`) or fold the score back into the context object (`omzet = {totaal: 100000, score: 8}`).

### Script task `resultVariable` scope and IO mappings

A script task's `resultVariable` propagates to **process scope only when the task has no IO mappings**. If the task has input IO mappings but no output IO mappings, `resultVariable` is stored in local task scope and **does not propagate back to the process**. Downstream gateways and aggregations see null.

Fix: either remove all IO mappings (access process variables directly), or add an explicit output mapping:

```xml
<zeebe:ioMapping>
  <zeebe:input source="=omzet" target="scopedOmzet"/>
  <zeebe:output source="=omzet_score" target="omzet_score"/>  <!-- explicit propagation -->
</zeebe:ioMapping>
<zeebe:script expression="=scopedOmzet.totaal * 0.1" resultVariable="omzet_score"/>
```

### FEEL Expressions in BPMN

All FEEL expressions must be prefixed with `=`:

```xml
<bpmn:conditionExpression xsi:type="bpmn:tFormalExpression">=riskLevel = "HIGH"</bpmn:conditionExpression>
```

**Timer durations are also FEEL expressions** — they must use the `="..."` format:

```xml
<bpmn:timeDuration xsi:type="bpmn:tFormalExpression">="PT7D"</bpmn:timeDuration>
```

Plain `PT7D` without the FEEL prefix will be rejected as an invalid duration format.

### Wildcard Error Catching

An empty `<bpmn:errorEventDefinition/>` on a boundary event catches ANY error (wildcard). To catch specific errors, add `errorRef`.

### Non-Interrupting Events

Boundary events default to `cancelActivity="true"` (interrupting). For non-interrupting (e.g., reminder timers), explicitly set `cancelActivity="false"`.

### Start Event Selection

| Start event type | When to use |
|-----------------|-------------|
| **None** (blank) | Single starting point — the default for most processes |
| **Message** | Multiple distinct triggers that need different correlation (e.g. "order placed via web" vs "order placed via phone") |
| **Timer** | Scheduled or periodic execution |
| **Signal** | Broadcast to all running instances simultaneously (rare; prefer messages for targeted routing) |

For message correlation: the correlation key must be **unique per process instance** — static keys cause random routing when multiple instances wait on the same message.

### Service Task vs. Send/Receive Tasks

Use **service tasks** for all integration work (REST calls, connectors, custom workers) — they model synchronous and asynchronous patterns equally well and keep the diagram simpler.

Use **send task** only when making the async "fire and forget" nature of a message explicit is worth the diagram complexity. Use **receive task** for an inbound message that arrives independently of any send.

### Sub-process completeness checklist

Every embedded sub-process (not ad-hoc) must satisfy all of these before the diagram passes `bpmnlint`:

- **Named start event** — one `<bpmn:startEvent>` with a `name` attribute. "Start" is acceptable for internal events.
- **Named end event** — one or more `<bpmn:endEvent>` elements, each with a `name` attribute describing the outcome ("Omvang berekend", "Error", etc.). A sub-process with no end event triggers `end-event-required`.
- **No gateway that both joins and forks** — if a parallel gateway has multiple incoming AND multiple outgoing flows, split it into a dedicated join gateway followed by a dedicated split gateway. A single element doing both triggers `no-gateway-join-fork`.
- **No duplicate sequence flows** — two flows with the same source and target are always wrong; remove the duplicate element and the duplicate `<bpmn:incoming>`/`<bpmn:outgoing>` references.

These same rules apply to the top-level process. Run `npx bpmnlint --config .bpmnlintrc <file>` after every structural change.

### Timer Start Events

Processes with **only** a timer start event cannot be started manually via `createProcessInstance` API or `c8ctl create pi`. For local development and testing, add a second `<bpmn:startEvent>` (none type) alongside the timer. Both are valid — the timer fires on schedule, the none event allows manual triggering.

### Editing BPMN files programmatically — do not use xml.etree.ElementTree

Python's `xml.etree.ElementTree` re-serialises the entire BPMN file on write: it strips namespace prefixes (`bpmn:` → unprefixed default namespace), changes character encoding (`&#34;` → `&quot;`, `&#60;` → `&lt;`), and re-orders attributes. The result is hundreds of changed lines for a single logical edit — unusable as a diff.

**Do not use ET (or any XML parser that round-trips through serialisation) to edit BPMN files.**

Instead, make targeted string replacements on the raw file content. BPMN attribute values use these encodings:
- `"` inside attribute values → `&#34;` or `&quot;`
- newline inside attribute values → `&#10;`
- `<` inside attribute values → `&#60;` or `&lt;`

Match the exact encoded string as it appears in the file and replace only that substring.

### BPMN DI — Waypoint alignment rules

Every `<bpmndi:BPMNEdge>` waypoint that terminates **on a gateway** must land exactly on one of the four connection points, never on a corner. For a gateway with bounds `x, y, width, height`:

| Side   | Waypoint                  |
|--------|---------------------------|
| Top    | `(x + width/2, y)`        |
| Bottom | `(x + width/2, y + height)` |
| Left   | `(x, y + height/2)`       |
| Right  | `(x + width, y + height/2)` |

Standard gateways are 50×50, so the offsets are 25 and 50.

When a flow approaches a gateway from the side (e.g., top and bottom branches of a parallel join), route the intermediate waypoint to the gateway's center-x before the final turn:

```xml
<!-- Task at (1667, 4200) → top of gateway at (1837, 4295) -->
<!-- gateway cx = 1837 + 25 = 1862, top = 4295             -->
<bpmndi:BPMNEdge id="Flow_example_di" bpmnElement="Flow_example">
  <di:waypoint x="1767" y="4240" />   <!-- right edge of task -->
  <di:waypoint x="1862" y="4240" />   <!-- move to gateway cx -->
  <di:waypoint x="1862" y="4295" />   <!-- down to gateway top -->
</bpmndi:BPMNEdge>
```

Using the corner `(x, y)` or `(x, y+height)` instead of the center-of-side creates a misaligned arrowhead in Camunda Modeler.

---

## Connectors (40+ built-in)

All outbound connectors (REST, Slack, Kafka, SendGrid, OpenAI, AWS, etc.) use the **same BPMN structure**. Only the task type and input target names change per connector.

### Universal pattern

```xml
<zeebe:taskDefinition type="<CONNECTOR_TASK_TYPE>" retries="3"/>
<zeebe:ioMapping>
  <zeebe:input source="<value or FEEL expression>" target="<connector-specific-field>"/>
  <!-- more inputs as needed -->
</zeebe:ioMapping>
<zeebe:taskHeaders>
  <zeebe:header key="resultVariable" value="myResult"/>
  <zeebe:header key="resultExpression" value="=<FEEL expression to extract fields>"/>
  <zeebe:header key="retryBackoff" value="PT0S"/>
</zeebe:taskHeaders>
```

### To configure any specific connector

1. Look up the connector in Camunda docs (use the Docs MCP tool or <https://docs.camunda.io/docs/components/connectors/out-of-the-box-connectors/>)
2. Find the **task type** (e.g., `io.camunda:http-json:1`, `io.camunda:slack:1`, `io.camunda:kafka:1`)
3. Find the **required input target names** and expected values
4. Apply them to the pattern above

Secrets (API keys, tokens) are referenced as `{{secrets.MY_SECRET}}` in input values.

### Non-obvious connector behaviors

- Inputs (method, URL, body, auth, etc.) go in `<zeebe:ioMapping>` as `<zeebe:input>`
- Outputs (result extraction) go in `<zeebe:taskHeaders>` as `<zeebe:header>` — NOT in ioMapping
- Response shape for REST: `response.status`, `response.headers`, `response.body`
- `retryBackoff` is a reserved header key handled by the connector runtime

### REST connector example (most common, `io.camunda:http-json:1`)

```xml
<zeebe:taskDefinition type="io.camunda:http-json:1" retries="1"/>
<zeebe:ioMapping>
  <zeebe:input source="noAuth" target="authentication.type"/>
  <zeebe:input source="POST" target="method"/>
  <zeebe:input source="http://localhost:3001/api/endpoint" target="url"/>
  <zeebe:input source="={&#10;  &quot;name&quot;: applicantName,&#10;  &quot;email&quot;: email&#10;}" target="body"/>
  <zeebe:input source="20" target="connectionTimeoutInSeconds"/>
  <zeebe:input source="20" target="readTimeoutInSeconds"/>
</zeebe:ioMapping>
<zeebe:taskHeaders>
  <zeebe:header key="resultExpression" value="={&#10;  verified: response.body.verified,&#10;  score: response.body.score&#10;}"/>
  <zeebe:header key="retryBackoff" value="PT0S"/>
</zeebe:taskHeaders>
```

### REST connector input targets (must be exact)

`method`, `url`, `body`, `headers`, `queryParameters`, `authentication.type`, `authentication.token`, `authentication.username`, `authentication.password`, `connectionTimeoutInSeconds`, `readTimeoutInSeconds`

---

## Agentic BPMN (AI Agents)

Requires Camunda 8.8+ (C8 Run 8.8+ bundles the Connector Runtime with AI Agent support).

### Ad-hoc Sub-process

The agent's toolbox. Each inner activity is a "tool" the agent can invoke dynamically.

```xml
<bpmn:adHocSubProcess id="agent-tools" name="Support Agent">
  <bpmn:extensionElements>
    <zeebe:taskDefinition type="io.camunda.agenticai:aiagent-job-worker:1" retries="3"/>
    <zeebe:adHoc outputCollection="toolCallResults"
      outputElement="={id: toolCall._meta.id, name: toolCall._meta.name, content: toolCallResult}"/>
    <zeebe:ioMapping>
      <!-- AI Agent connector inputs go here -->
    </zeebe:ioMapping>
    <zeebe:taskHeaders>
      <zeebe:header key="resultVariable" value="agent"/>
    </zeebe:taskHeaders>
  </bpmn:extensionElements>
  <!-- Tools: root activities with NO incoming sequence flows, NO start/end events -->
  <bpmn:serviceTask id="MyTool" name="My Tool">...</bpmn:serviceTask>
</bpmn:adHocSubProcess>
```

Non-obvious rules:

- **No start/end events** inside — activities are activated by the agent, not by flow
- Must contain at least one activity
- Do **not** set `cancelRemainingInstances` when using `zeebe:taskDefinition` (job worker / AI Agent Sub-process) — the engine rejects this combination
- Tool name = activity `name` attribute, tool description = `<bpmn:documentation>` element (or name if no docs)
- Tools can be any activity: service tasks, connectors, script tasks, user tasks, or sub-processes

### AI Agent Connector

**AI Agent Sub-process** (recommended) — applied directly to the ad-hoc sub-process:

- Task type: `io.camunda.agenticai:aiagent-job-worker:1`
- Tool calling loop handled internally (no explicit loop in BPMN)

**AI Agent Task** (explicit loop) — applied to a regular service task:

- Task type: `io.camunda:agentic-ai:1`
- Requires explicit BPMN loop: agent task → gateway (`=not(agent.toolCalls = null) and count(agent.toolCalls) > 0`) → ad-hoc sub-process (parallel multi-instance) → back to agent task

Input targets are **provider-specific** — nested under `provider.<type>.*`. Example for Anthropic:

| Input target | Description |
|---|---|
| `provider.type` | `anthropic`, `openai`, `azureOpenAi`, `googleVertexAi`, `bedrock`, `openaiCompatible` |
| `provider.anthropic.authentication.apiKey` | API key — use `{{secrets.MY_KEY}}` |
| `provider.anthropic.model.model` | Model ID (e.g. `claude-sonnet-4-20250514`) |
| `provider.anthropic.model.parameters.maxTokens` | Max tokens per LLM call |
| `provider.anthropic.model.parameters.temperature` | Temperature (0-1) |
| `data.systemPrompt.prompt` | Agent behavior and goal (**FEEL required** — use `="prompt text"`) |
| `data.userPrompt.prompt` | The user request (**FEEL required** — e.g. `="Handle: " + issue`) |
| `agentContext` | `=agent.context` — pass back for memory across iterations |
| `data.memory.storage.type` | `in-process` (default), `camunda-document`, `custom` — **hyphenated, not camelCase** |
| `data.memory.contextWindowSize` | Number of messages to retain |
| `data.limits.maxModelCalls` | Max LLM calls before stopping (safety limit) |

Other providers follow the same pattern: `provider.openai.authentication.apiKey`, `provider.openai.model.model`, etc.

Result variable: `agent` — contains `agent.context`, `agent.response`, `agent.toolCalls`.

### System prompt — what belongs (and what doesn't)

The system prompt encodes **strategy** and **output contract**, not a tool catalog.

- **DO** write: when to call X before Y, what to do when a tool returns nothing, how to escalate, when to stop, what shape the response takes, what triggers an out-of-scope signal.
- **DO NOT** write a "Tool usage" / "Available tools" / "Tools you have" list. The runtime injects each tool's name and description from its BPMN configuration (`<bpmn:documentation>`, the task `name`, the per-tool description on its connector element template). Restating them creates two copies that drift the moment a new tool is added and the prompt isn't updated.
- If a tool's purpose isn't obvious from its runtime-injected description, improve the tool's `<bpmn:documentation>` — don't paper over it in the prompt.
- Per-tool nudges that apply only to *this agent's* use of *one* tool ("prefer the directory lookup before the search call on the first iteration") are strategy, not description — those are fine in the prompt.

Provenance in the connector source (`camunda/connectors`, `connectors/agentic-ai`): tool definitions originate from `AdHocToolsSchemaResolverImpl`, are wrapped by `AgentToolsResolverImpl`, and serialised to provider-native tool specifications by `ToolSpecificationConverterImpl`. Descriptions ride along; the LLM sees them on every request.

### Output format — pick Pattern A (JSON mode) or Pattern B (XML extraction)

Two established patterns for getting a structured response back from the agent.

#### Pattern A — Provider-native JSON mode + schema

On the AI Agent template:

- **Response format** = `json`
- **Response JSON schema** = a FEEL Map literal modelling JSON Schema
- **Response JSON schema name** = a short name the model sees as a type label (default `"Response"`)

For Bedrock+Anthropic and OpenAI, langchain4j translates this into a forced tool-call under the hood — the model is structurally prevented from emitting prose preambles. The provider rejects malformed args. On parse failure the connector throws `ConnectorException(ERROR_CODE_FAILED_TO_PARSE_RESPONSE_CONTENT)` → job failure → incident with the configured retries.

The connector does **not** post-hoc schema-validate; enforcement lives at the provider.

#### Pattern B — Free-text XML + FEEL substring extraction

Use when targeting a provider without good JSON-mode support, or when consistency with existing XML-emitting agents matters.

- **Response format** = `text`
- **Parse text as JSON** = `=false`
- Prompt instructs the model: *"Your response must be only the following XML template — no additional text before or after"*, then shows a literal template with named children.
- A downstream `bpmn:scriptTask` extracts each tag via FEEL:

```feel
={
  value: string(substring before(substring after(agent.responseText, "<value>"), "</value>")),
  confidence: string(substring before(substring after(agent.responseText, "<confidence>"), "</confidence>")),
  error: substring before(substring after(agent.responseText, "<error>"), "</error>"),
  explanation: substring before(substring after(agent.responseText, "<explanation>"), "</explanation>")
}
```

For array-valued fields, ask the model to emit a JSON array inside the tag and parse with `from json(...)`. Guard against empty extracts:

```feel
sources: if substring before(substring after(agent.responseText, "<sources>"), "</sources>") != ""
         then from json(substring before(substring after(agent.responseText, "<sources>"), "</sources>"))
         else [],
```

#### Why not `text` + `Parse text as JSON = true`?

The connector tries `JSON.parse` on the whole response and **silently sets `responseJson = null` on failure** (`AgentResponseHandlerImpl.handleTextResponseFormat`, the `catch (Exception e) { LOGGER.warn(...); }` branch). Models that emit a friendly preamble before the JSON object — common with Claude — defeat this mode and the failure is invisible to downstream FEEL. Either go JSON-mode (Pattern A) or commit to XML (Pattern B); don't mix.

### `fromAi()` — Tool Parameter Definitions

Tags input values as AI-generated so the connector auto-builds JSON Schema tool definitions. Used in `zeebe:input` mappings of tools inside the ad-hoc sub-process.

```text
=fromAi(toolCall.<paramName>, "<description>", "<type>")
```

Types: `string` (default), `number`, `boolean`, `array`, `object`. The `toolCall.` prefix is required.

Example — REST connector tool with an AI-generated URL parameter:

```xml
<zeebe:input source="=&quot;http://localhost:3001/api/customers/&quot; + fromAi(toolCall.customerId, &quot;Customer ID to look up&quot;, &quot;string&quot;)" target="url"/>
```

### Tool Result Collection (critical)

Every tool **must** write its output to a variable named `toolCallResult`. The `zeebe:adHoc` element on the ad-hoc sub-process collects these and maps them back to tool call IDs for the LLM. Without this, the agent stalls after the first tool call.

How to set `toolCallResult` depends on the task type:

- **HTTP/REST connector:** `resultExpression` header → `={toolCallResult: response.body}`
- **Script task:** `<zeebe:script resultVariable="toolCallResult" .../>`
- **User task:** output mapping → `<zeebe:output source="=myFormVar" target="toolCallResult"/>`

When the AI Agent's next iteration fires, the connector sees the new entries in `toolCallResults` and feeds them back into the conversation as tool-result messages keyed by the original tool-call id. The agent then reasons over the results and either calls more tools or emits the final response.

### Tool error handling — HTTP errors become `toolCallResult` payloads

Tool tasks inside an AHSP must **never** raise incidents from HTTP errors — an unhandled job failure propagates out of the AHSP and stalls the entire process. HTTP tool tasks must convert 4xx/5xx responses into a structured `toolCallResult` so the agent can react. Non-HTTP failures (connection errors, secret resolution failures, misconfiguration) must **not** be swallowed — they should propagate as incidents so they are visible and actionable.

#### `errorExpression` (on every HTTP tool task header)

```text
=if error != null
  then (if error.code != null
    then bpmnError("TOOL_HTTP_ERROR", error.message,
      {toolCallResult: {statusCode: error.code, error: error.variables.response.body}})
    else null)
  else null
```

- `error != null` — outer guard; `else null` is a safety net for the rare case where `errorExpression` is evaluated without an active error (certain connector runtime versions in test harnesses). Never use a bare `else bpmnError(...)` as the default branch — it breaks happy-path unit tests.
- `error.code != null` — true only for HTTP errors (4xx/5xx), where the REST connector sets `error.code` to the HTTP status code string (e.g. `"404"`). See the [REST connector error handling docs](https://docs.camunda.io/docs/components/connectors/protocol/rest/#error-handling).
- When `error.code` is null (connection failure, secret resolution error, misconfiguration), the expression returns `null` — the job fails normally and raises an incident, which is the correct outcome for infrastructure problems the agent cannot fix.
- `error.variables.response.body` — present for all HTTP errors; no `is defined` guard needed since `error.code != null` already implies an HTTP response was received.

#### Error boundary event (on every HTTP tool task)

Every task with the `errorExpression` above also needs an **interrupting** error boundary event catching `TOOL_HTTP_ERROR`, with an `ioMapping` output that promotes `toolCallResult` from local scope so it lands in the AHSP's `outputCollection`:

```xml
<bpmn:boundaryEvent attachedToRef="my_tool_task">
  <bpmn:extensionElements>
    <zeebe:ioMapping>
      <zeebe:output source="=toolCallResult" target="toolCallResult" />
    </zeebe:ioMapping>
  </bpmn:extensionElements>
  <bpmn:errorEventDefinition errorRef="Error_ToolHttpError" />
</bpmn:boundaryEvent>
```

And declare the error at the process level once:

```xml
<bpmn:error id="Error_ToolHttpError" name="TOOL_HTTP_ERROR" errorCode="TOOL_HTTP_ERROR" />
```

No outgoing sequence flow is required — the boundary event terminates silently, `toolCallResult` is collected by the AHSP's `outputCollection`, and the agent job worker fires again with the error payload in `toolCallResults`. From the model's perspective there is no distinction from a successful call — it just sees that the tool reported an error and can adapt.

### Escaping untrusted content in tool results

The connector runtime resolves `{{secrets.NAME}}` patterns in connector input fields — including variables passed as inputs to the AI Agent job worker. If a tool returns external or customer-controlled text that happens to contain `{{secrets.NAME}}`, the connector runtime will replace it with the actual secret value when the agent's next iteration runs. This leaks secrets to the LLM.

**Escape any string field that comes from untrusted external sources before it becomes `toolCallResult`:**

```feel
replace(text, "secrets.", "secrets_.")
```

This converts `{{secrets.MY_KEY}}` → `{{secrets_.MY_KEY}}`, which the connector runtime does not resolve. The pattern is a regex where `.` matches any character — broad enough to cover any variant of the pattern.

**What counts as untrusted:**

| Source | Field | Trust |
|--------|-------|-------|
| Glean / external search | `title`, `snippet`, response text | ❌ Escape |
| Customer comments / Jira fields | summary, description, comments | ❌ Escape |
| Customer cluster `name` | `cluster.name` from Console API | ❌ Escape |
| Console API cluster metadata | `generation`, `region`, `datacenter.name` | ✅ Camunda-controlled |
| Kapa.ai / product docs | Any field | ✅ Camunda-controlled |
| Status page | Any field | ✅ Camunda-controlled |
| UUIDs, timestamps, status codes | Any | ✅ Structural |

Apply escaping in the expression that assembles `toolCallResult` — in the `resultExpression` header for REST connectors, or in the `zeebe:script` expression for script tasks:

```feel
// REST connector resultExpression — wrap the external text field:
={
  "toolCallResult": replace(response.body.messages[-1].text, "secrets.", "secrets_.")
}

// Script task — inline replace on each untrusted string field:
=flatten(for r in results return {
  title: replace(r.title, "secrets.", "secrets_."),
  url: r.url,
  snippet: replace(r.snippet, "secrets.", "secrets_.")
})
```

**Patching one field in a complex API object** — when a tool returns a large API response object and only one field (e.g. `name`) is customer-controlled, use FEEL's `put()` to patch just that field without enumerating the rest:

```feel
// put(context, key, value) returns the context with that key replaced
={
  c: apiResponse[uuid = targetId][1],
  toolCallResult: {orgId: orgId, cluster: put(c, "name", replace(c.name, "secrets.", "secrets_."))}
}.toolCallResult
```

`put()` preserves all other fields on the object so the agent still sees the full Console record — only the customer-named field is sanitised.

### Sub-flow Tool Pattern

The agent discovers tools by finding **root elements** in the ad-hoc sub-process (elements with no incoming sequence flows). A sub-process counts as one root element, so everything inside it is hidden from the agent — it's implementation detail.

This enables multi-step tools:

```text
[sub-process "Send message and wait for reply"]
  └── Service Task (send) → Sequence Flow → Intermediate Catch Event (wait for callback)
```

The agent sees one tool. BPMN executes two steps. The sub-process is the tool entry point; the catch event inside has an incoming flow so it's not discovered as a separate tool.

Use this for any tool that needs to:

- Send a message and wait for an async callback
- Start an external process and poll for completion
- Make a request, wait for human approval, then continue

### Webhook Connector in Agent Tools

Use `io.camunda:webhook:1` as an intermediate catch event inside a sub-flow tool. This enables tools that send a request and wait for an async reply via HTTP callback.

```xml
<bpmn:intermediateCatchEvent id="WaitForReply" name="Wait for reply">
  <bpmn:extensionElements>
    <zeebe:taskDefinition type="io.camunda:webhook:1" />
    <zeebe:properties>
      <zeebe:property name="inbound.type" value="io.camunda:webhook:1" />
      <zeebe:property name="inbound.context" value="my-webhook-path" />
      <zeebe:property name="inbound.shouldValidateHmac" value="disabled" />
      <zeebe:property name="correlationKeyExpression" value="=request.body.correlationKey" />
      <zeebe:property name="resultExpression" value="={toolCallResult: request.body.text}" />
    </zeebe:properties>
  </bpmn:extensionElements>
  <bpmn:messageEventDefinition>
    <bpmn:extensionElements>
      <zeebe:subscription correlationKey="=myCorrelationKeyVariable" />
    </bpmn:extensionElements>
  </bpmn:messageEventDefinition>
</bpmn:intermediateCatchEvent>
```

Key points:

- The endpoint is auto-created at `http://<connectors-host>/inbound/<context-path>`
- `correlationKeyExpression` extracts the key from the incoming request body
- `correlationKey` on the subscription references the process variable to match against
- `resultExpression` **must** wrap in `toolCallResult` for the agent to receive the result
- Set `inbound.shouldValidateHmac` to `disabled` for local dev; enable for production

### Correlation Key Uniqueness

When an agent tool sends a message and waits for an async reply, the correlation key must be **unique per tool invocation** — not per process instance, not static.

Pattern:

```javascript
// In the send-message worker:
const replyCorrelationKey = `${chatId}-${crypto.randomUUID()}`;
// Send key alongside the message to the external system
// Return key to the process so the webhook can correlate
job.complete({ replyCorrelationKey });
```

The webhook subscriber references this variable: `correlationKey="=replyCorrelationKey"`. When the external system replies, it includes the key in the request body. The webhook extracts it via `correlationKeyExpression="=request.body.correlationKey"` and matches it to the waiting subscription.

Why not static keys: Zeebe picks randomly among matching subscriptions. With static keys, two concurrent instances create two subscriptions on the same key — replies go to the wrong one with no error.

### Out-of-scope signal

For agents that should refuse rather than fabricate a low-confidence answer, define an `intermediateThrowEvent` inside the AHSP (e.g. named "Out of scope"). Attach an interrupting boundary event of the same throw signature to the AHSP itself, routing to a "skip" script that synthesises a deterministic empty / low-confidence response variable. The system prompt explicitly tells the model to invoke this signal when no diagnosis is possible.

This decouples "no answer" from "bad parse" — bad parses raise incidents, the no-answer path flows cleanly.

### Confidence semantics

Convention for agents using Pattern B (XML) output: a parsed `confidence` of `"Low"` (or absent/empty, defaulting to `"Low"` in the extraction FEEL) signals "no actionable suggestion". Downstream consumers check `if confidence != "Low" then ... else null` and skip emitting a suggestion. This makes the no-answer path safe-by-default — a parse failure degrades to "no comment" rather than "high-confidence guess from a malformed response".

A common contract for chained agents: if a draft agent's input findings indicate `confidence == "Low"` (or a null suggestion), it emits exactly the literal string `NO_DRAFT` instead of a customer-facing reply, and the comment-builder strips that case.

### Memory storage & context window — defaults and when to switch

The AI Agent template offers three memory storage modes via `data.memory.storage.type`:

- `in-process` (default) — agent context inlined into the BPMN variable. Cheapest, simplest.
- `camunda-document` — context offloaded to document storage. Useful when context grows past a few hundred KB.
- `custom` — bring-your-own storage.

Default to `in-process` until you see Camunda variable-size warnings in Operate or hit the 4 MB job-payload ceiling.

The default `data.memory.contextWindowSize` is 20 most-recent messages. For agents that call many tools per iteration, bump to 30–40 to avoid losing the chain of reasoning. Lower for cost-bounded agents that don't need long memory.

### Process Variables — store only what you need

Store as few variables as possible. Prefer **references** (IDs) over full payloads:

| Store this | Not this |
|-----------|---------|
| `orderId: "ORD-123"` | entire order object |
| `invoiceRef: {documentId: "..."}` | invoice PDF bytes |
| `approved: true` | full approval decision object |

Store full payload only when: the data exists nowhere else, it drives a gateway decision, it is being passed between systems, or it acts as a local cache. For large data (> ~100KB), use the document store (below).

Variables in parallel branches can collide — write only the output variables on job completion, never echo all inputs back.

### Document Store for Large Data

Process variables work well for small data (< ~100KB). For larger payloads (API responses, file contents), use the Camunda document store:

```javascript
// Upload (in a worker)
const docRef = await uploadDocument(largeData, 'my-data.json');
job.complete({ myDataRef: docRef }); // Only the small reference is stored

// Download (in a downstream worker)
const data = await downloadDocument(variables.myDataRef);
```

Pattern: Store large raw data as documents, pass references as variables. When a downstream task needs only a small subset, that subset can be a regular variable.

The document store REST API is at `http://localhost:8080/v2/documents`. Node.js helpers:

```javascript
async function uploadDocument(data, fileName) {
  const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
  const form = new FormData();
  form.append('file', blob, fileName);
  form.append('metadata', JSON.stringify({ fileName }));
  const res = await fetch(`${ZEEBE_REST}/v2/documents`, { method: 'POST', body: form });
  return (await res.json());
}

async function downloadDocument(docRef) {
  const res = await fetch(`${ZEEBE_REST}/v2/documents/${docRef.documentId}`);
  return res.json();
}
```

### Secrets for LLM API Keys

Use Camunda secrets: `{{secrets.ANTHROPIC_API_KEY}}`

- **C8 Run:** set `ANTHROPIC_API_KEY` in the environment before starting C8 Run, which exposes every env var as a connector secret by default. There is no cross-shell spelling, so use the one your shell supports:

  ```text
  # bash / zsh
  export ANTHROPIC_API_KEY=<key>

  # PowerShell 5.1+
  $env:ANTHROPIC_API_KEY = "<key>"
  ```
- **SaaS:** Console → Manage Clusters → Connector Secrets

---

## DMN Decision Tables

### Namespace (must be exact)

```xml
<definitions xmlns="https://www.omg.org/spec/DMN/20191111/MODEL/" ...>
```

### Non-obvious rules

- Output string values **must be quoted**: `"HIGH"` not `HIGH` — unquoted = silent evaluation failure
- Empty `<text></text>` in input entries = **wildcard** (matches anything)
- List matching for strings: `"US","GB","DE"` (comma-separated, each quoted)
- Reference from BPMN: `<zeebe:calledDecision decisionId="..." resultVariable="..."/>`
- **`resultVariable` overwrites**: The DMN output is stored in the variable named by `resultVariable`. If this matches an existing process variable (e.g., an input), it **overwrites** it. Use a distinct name (e.g., `qualified` not `resumeScore`) to avoid clobbering input data.

---

## Camunda Forms

- File extension: `.form`
- Metadata fields (`type`, `id`, `executionPlatform`, `executionPlatformVersion`, `schemaVersion`) come **first**, before `components`
- Current `schemaVersion`: 19 (verify via Docs MCP); `executionPlatformVersion`: `"8.9.0"`
- The `id` field links to `<zeebe:formDefinition formId="..."/>` in the BPMN
- Form `key` values map directly to process variables
- Deploy `.form` files alongside BPMN in the same deployment request
- Forms must be separate `.form` files — never embedded as `<zeebe:userTaskForm>` in BPMN

### Naming conventions

**Filename, `id`, and BPMN `formId` must all be the same value** — a PascalCase identifier derived from the user task (or start event) name. Follow the [Camunda ID naming guide](https://docs.camunda.io/docs/next/components/best-practices/modeling/naming-technically-relevant-ids/).

| User task name | Form filename | Form `id` | BPMN `formId` |
|---|---|---|---|
| Manager Review | `ManagerReview.form` | `ManagerReview` | `ManagerReview` |
| Approve Absence | `ApproveAbsence.form` | `ApproveAbsence` | `ApproveAbsence` |
| Create Expense Report | `CreateExpenseReport.form` | `CreateExpenseReport` | `CreateExpenseReport` |

**PascalCase rules**: capitalize each word, keep acronyms uppercase (HR, QA, CI), drop apostrophes and special characters, no hyphens or underscores.

Do NOT use generated IDs (`Form_8936f568`, `userTaskForm_0abc123`, `Form_05218fe1-7e95-4430-8387-d74c6dc7b58b`) — these are not human-readable and break the link between the form file, its id, and the task it serves.

---

## Local Environment Troubleshooting

**Availability check**: Use `GET /v2/topology` (returns 200 with broker info when the cluster is up). Do not use `/actuator/health`, which was removed in Camunda 8.7+.

**c8ctl cluster + asdf Java**: `c8ctl cluster start` runs the broker in a JVM that requires `JAVA_HOME` to be set explicitly in non-interactive shells (Claude Code, CI runners). asdf shims don't set it. Ask `asdf where java` for the path, then set `JAVA_HOME` to it before `c8ctl cluster start` — an assignment has no cross-shell spelling, and `$(asdf where java)` in particular cannot be nested into one:

```text
# bash / zsh
export JAVA_HOME="/path/from/asdf"

# PowerShell 5.1+
$env:JAVA_HOME = "C:\path\from\asdf"
```

Check the output / `c8ctl cluster logs` for "failed to get JAVA_HOME" as a failure signal.

**Operate URL**: Operate runs on port 8080 alongside the REST API — not a separate port. The UI is at `http://localhost:8080/operate/`. To open a specific process instance: `http://localhost:8080/operate/processes/{processInstanceKey}`. Default credentials: `demo` / `demo`.

**Operate default view hides completed instances**: The Processes view filters to **Running** (active) instances by default. A process that completes in under 10 seconds disappears from this view before you can observe it — this looks like the process was never created. To find finished instances: click the process definition → change the filter dropdown from **Running** to **Finished**.

---

## CLI: c8ctl

Install: `npm install -g @camunda8/cli` (requires Node.js >= 22.18). Available as `c8ctl` and alias `c8`. Throughout this kit we use `c8ctl` for clarity.

Set output to JSON once per session — required for agent-friendly parsing:

```bash
c8ctl output json
```

Falls back to `localhost:8080` by default — zero config needed for the local cluster started via `c8ctl cluster start`. Full reference: [the c8ctl reference](c8ctl.md). Key non-obvious features:

- `c8ctl deploy <folder-or-file>` deploys all resources atomically (all-or-nothing)
- `c8ctl run <bpmn-file>` deploys AND starts in one command
- `c8ctl watch <folder>` monitors folder and auto-redeploys on file changes
- `c8ctl use profile "modeler:Local Dev"` reads profiles from Camunda Desktop Modeler
- `c8ctl await pi --id=myProcess` starts and blocks until terminal state — autonomous-loop friendly
- `--fields <list>` trims any list response to specific fields
- `--dry-run` prints the planned API request without executing

**Profile management for SaaS:**

```bash
c8ctl list profiles   # NOT "c8ctl config list" — that command does not exist
c8ctl add profile "my-saas" --baseUrl="https://<region>.api.camunda.io/<cluster-id>/v2" --clientId="..." --clientSecret="..." --oauthTokenUrl="https://login.cloud.camunda.io/oauth/token" --audience="api.camunda.io"
c8ctl deploy . --profile my-saas
```

SaaS REST API URL format: `https://<region>.api.camunda.io/<cluster-id>/v2` — **region first, then cluster-id**, with the `api.camunda.io` audience. This is the unified orchestration-cluster domain 8.9 introduced. The component hostnames it replaces — `<cluster-id>.<region>.zeebe.camunda.io`, `<region>.operate.camunda.io/<cluster-id>`, and the `zeebe.camunda.io` / `operate.camunda.io` audiences — were deprecated in 8.9 and **removed in 8.10**, so they fail against the line ProcessOS targets by default. Credentials downloaded for a pre-8.9 cluster may still carry the legacy values; regenerate them in Console rather than keeping the old host. Secure connectivity (AWS PrivateLink) uses a different pattern again: `https://<cluster-id>.<region>.privateconnectivity.camunda.io/api/v2`. See [SaaS orchestration architecture](https://docs.camunda.io/docs/apis-tools/migration-manuals/saas-orchestration-architecture/).

## Deployment

Atomic (all-or-nothing): `c8ctl deploy ./resources` or `c8ctl deploy .`

Java/Spring Boot: BPMN/DMN/Forms in `src/main/resources/` auto-deploy on startup.

---

## Resource Binding Types

Call activities, business rule tasks (DMN), and user tasks (forms) each have three binding options — set in `<zeebe:calledElement binding="...">`:

| Binding | Behaviour | Use when |
|---------|-----------|---------|
| `latest` | Resolves to newest deployed version at runtime | Development / rapid iteration |
| `deployment` | Pinned to the version co-deployed in the same deployment request | Self-contained apps where BPMN + DMN/form always deploy together |
| `versionTag` | Pinned to a user-defined string tag (e.g. `"v2.1"`) | Shared external resources owned by another team |

`latest` is the default and is fine for development, but can cause silent breakage in production when a new version of a shared resource is deployed. Prefer `deployment` for stable self-contained apps.

## Process Versioning

New deployments always create a new version. Running instances **continue on their old version** unless explicitly migrated. Key rules:

- **Parallel versions are the default** — old instances finish on v1, new instances start on v2. This is safe and requires no action.
- **Migrate instances** when you need to apply a bug fix to in-flight instances, or when operating multiple versions indefinitely becomes unacceptable. Use Operate UI or the `MigrateProcessInstance` REST API.
- **Only version BPMN and DMN files** using the engine's built-in versioning. Worker code, forms, and scripts live in the application — handle backward compatibility in code, not by forking files.
- **Cut long-running processes** (> 6 months) at natural wait points into separate process definitions. Use call activities with `deployment` binding to chain them. This avoids migration complexity when the engine is upgraded.

## API Gotchas (v2 — Camunda 8.9)

These matter when writing UI code or using the REST API directly. c8ctl abstracts most of these away.

| What | Wrong (v1/old) | Correct (v2/8.9) |
|------|---------------|-------------------|
| Start process field | `bpmnProcessId` | `processDefinitionId` |
| Flow node endpoint | `/v2/flownode-instances/search` | `/v2/element-instances/search` |
| Flow node ID field | `flowNodeId` | `elementId` |
| Job activation worker field | `workerName` | `worker` |

**Filter body IDs must be strings**: When calling any search endpoint (`POST /v2/user-tasks/search`, `/v2/process-instances/search`, etc.), all key values in the `filter` body must be **strings**, not integers. Sending `"processInstanceKey": 12345` returns `400 "cannot be parsed"`. Always use `"processInstanceKey": "12345"`.

**Job activation field is `worker`, not `workerName`**: `POST /v2/jobs/activation` takes `"worker": "my-worker"`. The wrong field name silently activates 0 jobs with no error.

### Useful debugging endpoints

Both searches below POST a JSON filter. Write that filter to a file with your file-writing tool
first — a request body always travels as a file, never as an inline `-d '{…}'` argument, because a
single-quoted JSON literal is one string in bash and a parse error in PowerShell.

**Inspect all variables for an instance** (scoped to process root). Filter file:

```json
{"filter":{"processInstanceKey":"<key>","scopeKey":"<key>"},"page":{"limit":50}}
```

```bash
node ".github/skills/process-os-deployment-resources/scripts/http-request.cjs" --method POST --header "Content-Type: application/json" --body-file "<FILTER_FILE>" http://localhost:8080/v2/variables/search
```

Note: scope variables (e.g., inside a sub-process) use a different `scopeKey`. Omit `scopeKey` to get all scopes.

**Find which end event was reached** (determine process outcome without a decision variable). Filter file:

```json
{"filter":{"processInstanceKey":"<key>","type":"END_EVENT","state":"COMPLETED"},"page":{"limit":20}}
```

```bash
node ".github/skills/process-os-deployment-resources/scripts/http-request.cjs" --method POST --header "Content-Type: application/json" --body-file "<FILTER_FILE>" http://localhost:8080/v2/element-instances/search
```

Returns the completed end event elementIds — map these to business outcomes in your UI code.

For both: the response body goes to stdout. Exit `1` is a non-2xx — the body still prints and says
why, which for these endpoints is usually a key sent as a number rather than a string. Exit `2` means
no cluster answered at `localhost:8080`, which is a different problem from a rejected filter.

### Variable serialization

Variables from the API are double-serialized. String values come back as `"\"MEDIUM\""`. Always `JSON.parse(v.value)` to get the actual value.

---

## Worker SDK

### Node.js (@camunda8/sdk)

```typescript
import { Camunda8 } from '@camunda8/sdk';
const c8 = new Camunda8();
const zeebe = c8.getZeebeGrpcApiClient();
zeebe.createWorker({ taskType: 'my-type', taskHandler: async (job) => {
  return job.complete({ output: 'value' });
  // or: job.fail('reason')
  // or: job.error('BPMN_ERROR_CODE', 'message')
}});
```

Environment variables (SDK reads these automatically):

```text
ZEEBE_REST_ADDRESS=http://localhost:8080
ZEEBE_GRPC_ADDRESS=grpc://localhost:26500
CAMUNDA_AUTH_STRATEGY=NONE
```

### Polling for process completion

When waiting for a process to finish, always check `hasIncident` and fail fast. A gateway incident (e.g., condition expression evaluates to null) leaves `state: ACTIVE` indefinitely — polling for `state !== 'ACTIVE'` will time out after 60 seconds with no useful signal.

```javascript
async function waitForCompletion(key, maxMs = 30000) {
  const deadline = Date.now() + maxMs;
  while (Date.now() < deadline) {
    const resp = await fetch(`http://localhost:8080/v2/process-instances/${key}`);
    if (resp.ok) {
      const data = await resp.json();
      if (data.hasIncident) return 'INCIDENT'; // fail fast
      if (data.state !== 'ACTIVE') return data.state;
    }
    await new Promise(r => setTimeout(r, 1000));
  }
  return null; // timeout
}
```

### Incidents

When a job fails with retries = 0, Camunda raises an **incident** — the token stops and the process instance pauses. Incidents are visible in Operate; operators can inspect the error message, fix the root cause, and resolve the incident to resume. This is the designed escalation path for unrecoverable technical errors — do not suppress or auto-resolve incidents in code.

### Java (Camunda Spring Boot Starter)

```java
import io.camunda.client.annotation.JobWorker;
import io.camunda.client.annotation.VariablesAsType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class MyWorker {
    @JobWorker(type = "my-type")
    public ProcessVariables handle(@VariablesAsType ProcessVariables vars) {
        // business logic via injected @Service
        return vars;
    }
}
```

Maven: `io.camunda:camunda-spring-boot-starter`

Config (`application.yaml` for C8 Run):

```yaml
camunda:
  client:
    mode: simple
    zeebe:
      enabled: true
      gateway-url: http://localhost:26500
      base-url: http://localhost:8080
```

**Java auto-deploys** BPMN/DMN/Forms from `src/main/resources/` on startup.

---

## SaaS Differences (vs. C8 Run)

- Auth: OAuth2 client credentials. Audience: `<clusterId>.zeebe.camunda.io`
- c8ctl: use `c8ctl add profile` + `c8ctl use profile` to switch between local and SaaS (run `c8ctl help profiles`)
- REST connector URLs **cannot reach localhost** — APIs must be publicly accessible or tunneled (ngrok)
- Cluster MCP: not available on SaaS (no built-in endpoint) — use c8ctl for all operations
- SDK env vars: `CAMUNDA_CLIENT_ID`, `CAMUNDA_CLIENT_SECRET`, `CAMUNDA_CLUSTER_ID`, `CAMUNDA_CLUSTER_REGION`

---

## Business Transactions & Compensation (Saga Pattern)

Camunda processes are not ACID transactions — each service call commits independently. When partial failures create inconsistency, use **BPMN compensation events** to implement the Saga pattern:

1. Mark completed activities with a **compensation boundary event** + **compensation handler** task (the "undo" step).
2. When a step fails, throw a compensation event — Camunda automatically invokes all handlers for completed activities in reverse order.

Three strategies when something goes wrong: **ignore** (continue anyway), **apologize** (notify affected parties), or **resolve** (trigger compensation handlers to undo completed steps). Model these as distinct end events so outcomes are visible in reporting.

## Process Reporting & KPIs

To make processes reportable without adding operational complexity:

- **Milestones**: add intermediate catch/throw events (with no execution logic) at business milestone points — they appear in the process history and enable duration reporting between stages.
- **Phases**: wrap related activities in a sub-process to demarcate business phases; the sub-process state (entered / active / completed) is visible in Operate.
- **Outcome clarity**: use distinct named end events for every business outcome (e.g. "Loan approved", "Loan rejected", "Application abandoned") — this enables outcome ratio reporting directly from the engine history without custom analytics.
- Java config: `camunda.client.mode: saas` with auth block
