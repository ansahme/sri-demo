# C8 Run (Local)

Local Camunda 8 cluster managed via `c8ctl cluster` (the default plugin in c8ctl). See [the c8ctl reference](c8ctl.md) for the full c8ctl reference.

| Component | URL |
|-----------|-----|
| REST API | <http://localhost:8080/v2/> |
| MCP Server | <http://localhost:8080/mcp/cluster> (built-in, enabled by default) |
| Operate | <http://localhost:8080/operate> |
| Tasklist | <http://localhost:8080/tasklist> |
| Zeebe gRPC | localhost:26500 |

No authentication.

For non-obvious Camunda-specific modeling and runtime rules, read [the Camunda 8 Development Guide](camunda-dev-guide.md).

C8 Run does not include Web Modeler. Web Modeler deployment and Git Sync are
separate from the local cluster configuration described here.

## Lifecycle

```bash
c8ctl cluster start              # latest stable; installs on first run
c8ctl cluster start 8.9          # specific minor
c8ctl cluster status             # is anything running?
c8ctl cluster stop               # stop the running cluster
c8ctl cluster logs               # stream broker logs
```

## MCP setup (Claude Code)

```text
claude mcp add camunda --transport http http://localhost:8080/mcp/cluster
claude mcp add camunda-docs --transport http https://camunda-docs.mcp.kapa.ai
```

## Worker env vars

```text
ZEEBE_REST_ADDRESS=http://localhost:8080
ZEEBE_GRPC_ADDRESS=grpc://localhost:26500
CAMUNDA_AUTH_STRATEGY=NONE
```

Java (`application.yaml`):

```yaml
camunda:
  client:
    mode: simple
    zeebe:
      enabled: true
      gateway-url: http://localhost:26500
      base-url: http://localhost:8080
```

REST connectors can reach `http://localhost:*` directly.

## Connector secrets

The connector runtime exposes **all environment variables** as connector secrets by default (no prefix needed). `{{secrets.OPENAI_API_KEY}}` resolves to the env var `OPENAI_API_KEY`.

Set secrets in the shell **before** starting the cluster:

```dotenv
# .env (gitignored)
MY_SECRET=value
OTHER_SECRET=value
```

Loading a `.env` into the process environment has no cross-shell spelling, so use the one your
shell supports. Load it and start the cluster in the **same** command — shell state does not
survive between tool calls, so a separate `c8ctl cluster start` gets none of the secrets:

```text
# bash / zsh
set -a; . /path/to/.env; set +a; c8ctl cluster start

# PowerShell 5.1+
Get-Content /path/to/.env | ForEach-Object { if ($_ -match '^\s*([^#=]+)=(.*)$') { Set-Item -Path "env:$($matches[1].Trim())" -Value $matches[2].Trim() } }; c8ctl cluster start
```

Never inline secret values in the terminal command — they end up in shell history and may appear in `ps aux`.

**Important:** The env var must be in the cluster process environment. If you restart the cluster, re-source the `.env` first. The `CAMUNDA_CONNECTOR_SECRETS_` prefix does **not** work — all env vars are exposed as secrets by their exact name.

## JAVA_HOME (asdf/mise users)

If Java is managed by asdf or mise, `JAVA_HOME` is not set in non-interactive shells. The cluster will fail to start in the background. Print the path (`asdf where java`, or `mise where java`) and set `JAVA_HOME` to it before `c8ctl cluster start`, with the form your shell supports:

```text
# bash / zsh
export JAVA_HOME="/path/from/asdf-or-mise"; c8ctl cluster start

# PowerShell 5.1+
$env:JAVA_HOME = "C:\path\from\asdf-or-mise"; c8ctl cluster start
```

## Element Templates & Custom Connectors

**Connector secrets for element templates** — when an element template requires a secret (e.g. an API key), make it available as an environment variable before `c8ctl cluster start`:

```text
# bash / zsh
export MY_API_KEY=sk-...; c8ctl cluster start

# PowerShell 5.1+
$env:MY_API_KEY = "sk-..."; c8ctl cluster start
```

`MY_API_KEY` is then available as `{{secrets.MY_API_KEY}}`. The variable has to be set in the
same command that starts the cluster: a `c8ctl cluster start` in its own tool call runs in a
fresh shell that never saw it.

**Custom connector JAR** — `c8ctl cluster` manages the install root for you. Find it via `c8ctl cluster status` (or look under the c8ctl cache dir reported there). Drop the `-with-dependencies.jar` into the `custom_connectors/` directory inside that root, then restart:

```bash
c8ctl cluster stop
cp my-connector-1.0-with-dependencies.jar <c8run-root>/custom_connectors/
c8ctl cluster start
```

## Known Issues

| Version | Issue | Workaround |
|---------|-------|------------|
| 8.9.0-alpha4 | Webhook connector version conflicts: redeploying BPMN with webhooks creates a new version but the old connector instance stays active and intercepts requests | `c8ctl cluster stop`, then `c8ctl cluster start`, after every deploy. Fixed in alpha5 (camunda/camunda#6056). |
| 8.9.0-alpha1 | "Text cannot be null or empty" on AI Agent connector when LLM returns tool calls without text content | Upgrade to alpha2+ which includes fix (camunda/camunda#4828). |
