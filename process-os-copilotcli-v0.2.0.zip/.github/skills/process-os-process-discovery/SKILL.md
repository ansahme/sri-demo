---
name: process-os-process-discovery
description: >-
  Use when you want to discover and document a business process — runs the
  configured specialists over the project's data sources and produces
  as-is-process.md, gap-analysis.md, and the rest of an iteration's
  process-discovery documentation. Every run opens one new iteration, seeded
  from the last completed one, and folds in any feedback left there before
  researching further.
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
# /process-os-process-discovery

**WORKFLOW SKILL** — orchestrates discovery across multiple specialist agents and phases, cycling a gather → synthesize research-round loop before a final document phase.

INVOKES: [bootstrap.md](references/bootstrap.md) → [feedback.md](references/feedback.md) _(fold-in, skipped when there is nothing to fold)_ → parallel specialists _(skipped when this iteration has no new information — see below)_ → [analyze.md](references/analyze.md) → [document.md](references/document.md) _(produces review-questions.yaml inline)_ → [as-is-bpmn.md](references/as-is-bpmn.md) _(optional, gated by `--bpmn`)_ → [finalize.md](references/finalize.md)

## USE FOR:
- Discovering and documenting a business process end-to-end
- Mapping how a current ("as-is") process works across systems and stakeholders
- Documenting a process with specialist agents across systems and stakeholders
- Starting a Camunda 8 process improvement project from scratch
- Scraping data sources to understand a process
- Folding SME feedback from the last completed iteration into a new one — every run does this automatically whenever feedback is present, with no separate invocation

## DO NOT USE FOR:
- Generating BPMN diagrams alone, or when documentation is already complete and only the diagrams are missing — use `/process-os-bpmn-generation` directly
- Optimizing an already-documented process — use `/process-os-process-transformation`
- Applying already-answered review questions with no new SME feedback to gather — use `/process-os-review-answer-application` directly
- Single-phase or single-file operations — load the individual reference module directly

Don't use this skill to hand-author the discovery documents — it always runs the pipeline below.

## Source mode

Before dispatching specialists, read `source-mode` from `run.config.yaml`:

```bash
node ".github/skills/process-os-process-discovery/scripts/read-run-config.cjs" source-mode
```

Exit 2 → hard error: report stderr and stop; it means the reader failed, not that the key is unset.

- `source-mode: hint` (default) — specialists treat any `## Data sources` entries as priority hints. They read those first then explore the workspace, public web, and GitHub as their specialist body describes.
- `source-mode: allowlist` — specialists discover ONLY from the URLs / paths listed in the `## Data sources` section. Filesystem specialist skips the glob scan. Web specialist skips `WebSearch` and only `WebFetch`s listed http(s) URLs. GitHub specialist only reads listed `github.com/...` URLs. Each specialist that finds zero matching sources for its category writes a one-line "allowlist mode, no [filesystem|web|github] sources" findings file and stops.

The mode is locked at instance creation and applies to every iteration.

## Decomposition + edge-cases

`run.config.yaml` carries two further flags that gate the Phase 3 output structure:

- `decomposition: per-phase` (default) | `single` — controls the markdown phase file layout (Phase 3); the AS-IS BPMN (Phase 3a) then follows that layout via `/process-os-bpmn-generation`. Under `single`, exactly one `process-01-asis.md` is produced with the entire end-to-end flow inlined. See [document.md](references/document.md) Step 1 and [as-is-bpmn.md](references/as-is-bpmn.md) for the contract.
- `edge-cases: standalone` (default) | `skip` — controls whether variants and exceptions get standalone `edge-NN-*.md` files. Under `skip` (and implicitly under `decomposition: single`), variants are inlined into the relevant phase file's "Error Paths" / "Known Issues" sections instead.

Both flags are read inside `document.md` Step 1 and threaded through `data/doc-context.md` so phase agents see them.

## AS-IS BPMN generation (optional, recommended)

Generating the as-is BPMN (Phase 3a) is **optional but recommended** — it's required for Phase 3b (system context) and can be shared with SMEs for feedback. It is gated by the invocation:

- `/process-os-process-discovery --bpmn` — always generate the BPMN, no prompt.
- `/process-os-process-discovery` (no flag) — after the docs are written, **ask** whether to generate (default yes). See Phase 3a.
- Unattended mode (`mode: unattended` in `run.config.yaml`) — never prompts; generates by default (the recommended path).

Either way the markdown docs (`as-is-process.md`, `gap-analysis.md`, `process-NN-*.md`, …) are always produced; only the BPMN is gated. If skipped, run `/process-os-process-discovery --bpmn` or `/process-os-bpmn-generation` later.

## EXEC: Apply staged data sources

Every governance "Execute discovery" job stages the project's configured data sources as
`dataSources` in its `skillInput` — each iteration's form offers the list again, so entries may
have been added or removed since the last pass. Write them into `process-scope.md` before bootstrap
reads them:

```bash
node ".github/skills/process-os-process-discovery/scripts/apply-data-sources.cjs"
```

The script upserts the `## Data sources` section — [bootstrap.md](references/bootstrap.md) Step 2
extracts and categorizes those entries, and the specialists honour them under
`source-mode: allowlist`. Act on the exit code:

- `0` — the section is current (written, replaced, or already identical). Continue. Remember
  whether its printed line started with `wrote` (the list **changed**) or `already lists` (it did
  **not**) — the research-round entitlement decision below needs it.
- `3` — nothing was staged, or the staged list is empty. Routine on a standalone run; continue
  silently, and treat this the same as **not changed**.
- `4`, `5`, `6` — `.camunda/job-input.json` exists but is unreadable, is not valid JSON, or carries
  no `skillInput` object. Report the printed line and stop; the staged input is broken, not absent.
- `7` — data sources are staged but `process-scope.md` is missing. Report the printed line and stop.

## Where `data/` lives

`data/` is always the **project-root** `data/` directory — in this file and in every
`references/*.md`, never a subdirectory of `<ITERATION_DIR>` or `<ARTIFACTS_DIR>`. It holds the
research evidence and progress record for the run as a whole, which span iterations; an
iteration directory holds only what that iteration produced (`artifacts/`) and the feedback it
was given (`feedback/`).

## EXEC: Phase 0: Bootstrap

Read and follow `references/bootstrap.md`.

After bootstrap completes:
- `data/bootstrap.md` exists with process context and active specialist list
- `data/progress.json` exists (initialized with phase "bootstrap")
- `.camunda/state.md` updated to 🔄 In Progress
- `<N>` — this run's iteration number — and `<ITERATION_DIR>` / `<ARTIFACTS_DIR>` are known, from
  `iteration-dir.cjs open --seed`'s output. `<N> - 1` is the iteration this one seeded from,
  whenever `<N> > 1`; iteration 1 seeds from nothing.

## EXEC: Resolve feedback, decide research rounds, state the run

Resolve the seeded iteration's feedback before deciding anything else:

```bash
node ".github/skills/process-os-process-discovery/scripts/iteration-dir.cjs" current process-discovery --complete --feedback
```

- **Exit `3`** — no completed iteration exists (this is iteration 1). `<FOLD_COUNT>` is `0`.
- **Exit `0`** — prints `<FEEDBACK_DIR>`. List it:
  ```bash
  node ".github/skills/process-os-process-discovery/scripts/list-feedback.cjs" "<FEEDBACK_DIR>"
  ```
  One filed name per line, the directory's own `README.md` scaffold excluded. `<FOLD_COUNT>` is
  that count.

**Decide whether this iteration is entitled to research rounds** (`max-research-rounds`, read in
bootstrap Step 2, bounds the loop whenever it runs — not only on iteration 1):
- `<N> == 1` → entitled, unconditionally.
- `<N> > 1` → entitled only if the data-sources step above changed the section, **or**
  `<FOLD_COUNT> > 0`. Otherwise not entitled — nothing new arrived since iteration `<N> - 1`.

State the run before any of the above is acted on:

```
Iteration <N>[, seeded from iteration <N-1>].
Folding in feedback from iteration <N-1>: <FOLD_COUNT> file(s).
Research rounds: entered, up to <max-research-rounds> | skipped, no new information since iteration <N-1>.
```

Drop the `, seeded from iteration <N-1>` clause on iteration 1. Omit the second line entirely when
`<FOLD_COUNT>` is `0` — including on iteration 1, which never has a `<FEEDBACK_DIR>` to fold from.

## AI: Fold in feedback (skipped when there is nothing to fold)

Skip this step when `<FOLD_COUNT>` is `0`. Otherwise, read [feedback.md](references/feedback.md)
and follow it: it applies the reconciled answers to `<ARTIFACTS_DIR>/review-questions.yaml`, then
folds every other file in `<FEEDBACK_DIR>` into the matching `<ARTIFACTS_DIR>/*.md`. Carry forward
the set of `.md` files it reports touching, plus its `STRUCTURAL_CHANGES` list, into Phase 3c
(Integrity) below.

Then update `data/progress.json`: set phase to `"gathering"` and all specialist statuses to
`"pending"`. See [the progress-record reference](references/progress.md) for the schema.

## AI: Phase 1: Parallel Gather (loop starts here)

Reached only when the previous step decided this iteration is **entitled** to research rounds. Not
entitled → skip Phase 1 and Phase 2 entirely and continue directly to **Phase 3: Output** below.

Read `data/bootstrap.md` to get:
- Active specialist list
- Current research round number N

For each active specialist, read its prompt file:
`specialists/<name>.md`

Read [the specialist extraction rule](references/specialist-extraction.md) once. Its
`## Extraction` section goes into **every** specialist's prompt, built-in and plugin alike, so
each one applies the same rule without the specialist files carrying their own copy.

### AI: Plugin specialists

Read `data/plugin-specialists.json` (written by bootstrap, Step 3). For each entry, prepare an `Agent()` call:

- **Role instructions** — read the file at `entry.path`. Strip the frontmatter block (first `---` … `---` chunk) and put the body at the **top of the `prompt` argument**, above the task line below.
- **Model** — resolve the tier:
  ```bash
  node ".github/skills/process-os-process-discovery/scripts/resolve-model-tier.cjs" "$ENTRY_MODEL"
  ```
  Pass the printed model id to `Agent()` as the `model` parameter.
- **Extraction** — the `## Extraction` section from the rule above, after the role instructions.
- **Task line** — appended after those instructions, in the same `prompt`: `"Run process discovery for [processName], research round [N]. Read data/bootstrap.md first for context. Write findings to data/<qualified>-roundN.md (e.g. data/acme-sap-round1.md)."`
- **Findings file** — each plugin specialist writes to `data/<plugin>-<name>-round<N>.md` (qualified name with `-` instead of `:` for filesystem safety).

**Dispatch all active specialists simultaneously** — run each as an independent subagent:

- **Claude Code:** issue ALL `Agent()` calls in a **single assistant turn** (one tool-message with N `tool_use` blocks). Do not emit agents one-by-one across turns — that serialises execution. Results are awaited together before continuing.
- **Other platforms:** invoke each specialist sub-skill sequentially if parallel dispatch is not available.

The batch includes both built-ins and plugin specialists; results are awaited together. Each agent's
`prompt` carries, in this order:
- its specialist prompt — the body of `specialists/<name>.md` (or the plugin's `entry.path`), frontmatter stripped
- then the `## Extraction` section of the specialist extraction rule
- then the task line: "Run process discovery for [processName], research round [N]. Read data/bootstrap.md first for context."

Built-in specialists write findings to `data/<specialist>-roundN.md`; plugin specialists write to
`data/<plugin>-<name>-roundN.md`.

**The specialist prompt goes in `prompt`, not a system prompt.** `Agent()` exposes no
system-prompt parameter, so `prompt` is the only channel that reaches a subagent — a role left out
of it never reaches the agent at all, and an agent that does not know which specialist it is will
read the prompt files itself and wander into another specialist's work or into Phase 2, which is
the orchestrator's alone. Naming a predefined agent type instead is not open to ProcessOS: that
would mean shipping agent definitions under an agent-owned directory.

Before dispatching, update `data/progress.json` to set all active specialists to status `"running"`. After all agents return, update each specialist's status to `"done"` and set their `itemsProcessed` from the findings file. Progress tracking uses qualified names (e.g. `acme:sap`) for plugin specialists.

Wait for all specialist agents to complete before proceeding.

## AI: Phase 2: Synthesize + Coverage

Read and follow `references/analyze.md`.

This phase:
- Reads all findings files
- Produces `data/coverage-roundN.md`
- Presents coverage report to human
- Returns one of: APPROVE or LOOP

### GATE: Review coverage report (APPROVE or LOOP)

Whether this gate is due is decided by `node ".github/skills/process-os-process-discovery/scripts/check-coverage-gate.cjs"` (run inside
`analyze.md`), never freehand. Run-unattended mode auto-approves a triggered gate; while the
script prints `CONTINUE`, every mode loops.

**If LOOP:** `analyze.md` has already updated `data/bootstrap.md` with gap instructions and the incremented research round counter. Return directly to Phase 1.
**If APPROVE:** proceed to Phase 3.

## AI: Phase 3: Output

Read and follow `references/document.md`.

### AI: Phase 3a: AS-IS BPMN (optional, recommended)

Generating the as-is BPMN is **optional but recommended**.

**Decide whether to run it:**

0. If the fold-in step changed any `.md` that has a `.bpmn` pendant → **generate**, and do not
   prompt. The pendant is stale the moment its source changes, and leaving the two disagreeing is
   worse than the cost of rebuilding: a reviewer's correction would be live in the document and
   absent from the diagram anyone opens.
1. Else if the invocation included the `--bpmn` flag → **generate** (skip the prompt).
2. Else if unattended mode is active — `node ".github/skills/process-os-process-discovery/scripts/read-run-config.cjs" mode` prints `unattended` → **generate** (the recommended default; an unattended run never prompts).
3. Otherwise → **ask the user**: "Generate as-is BPMN diagrams now? (recommended)
   [Y/n]".
   - `Y` / empty / yes → generate.
   - `n` / no → skip Phase 3a (and Phase 3b: system context, which depends on an as-is BPMN). Output the **urgent** recommendation: "⚠ No as-is BPMN was generated — system context (Phase 3b) will be skipped, and the diagram won't be available to share with SMEs for feedback. Strongly recommended — run `/process-os-process-discovery --bpmn` now." Then continue to Phase 3c.

Exit 2 → hard error: report stderr and stop; it means the reader failed, not that the key is unset.

**If generating:** read and follow `references/as-is-bpmn.md`. After completion,
verify at least one generated BPMN exists in `<ARTIFACTS_DIR>` (read from `data/bootstrap.md`'s
`- **Artifacts dir:**` line)
(`00-overview.bpmn` or a `process-NN-*.bpmn`). If none is present, output: "AS-IS
BPMN missing after Phase 3a — discovery output is incomplete. Re-run
/process-os-process-discovery --bpmn." Before stopping, set `data/progress.json` phase to `"error"` and update `.camunda/state.md` to ❌ Incomplete. Then stop.

### AI: Phase 3b: system context (optional, recommended)

Generating the system context is **optional but recommended**. The discovery output and the as-is BPMN can be mapped to the external systems and manual artifacts the process integrates with (collapsed-pool context diagrams + a systems index).

**Decide whether to run it:**
 
1. If unattended mode is active — `node ".github/skills/process-os-process-discovery/scripts/read-run-config.cjs" mode` prints `unattended` → **generate** (the recommended default; an unattended run never prompts).
2. Otherwise → **ask the user**: "Generate system context diagrams now? (recommended)
   [Y/n]".
    - `Y` / empty / yes → generate.
    - `n` / no → skip Phase 3b.

Exit 2 → hard error: report stderr and stop; it means the reader failed, not that the key is unset.

**If generating:** run the skill `/process-os-system-context --input <ARTIFACTS_DIR> --output <ARTIFACTS_DIR>` until it completes — explicit `--input`/`--output` are required here because `process-os-system-context`'s own defaults resolve the last *completed* iteration, not this in-flight one. Display any success, error, or warning messages it produces. Inform the user how to handle them as a follow-up. Continue to Phase 3c.

### AI: Phase 3c: Integrity check (skipped when nothing was folded in)

Skip entirely when the "Fold in feedback" step above did not run (`<FOLD_COUNT>` was `0`).
Otherwise, validate the union of files it reported touching plus its `STRUCTURAL_CHANGES` —
**sequentially, one at a time**, never in parallel: each check may reconcile drift in a sibling
file, and two running concurrently could race on the same write.

```
process-os-markdown-integrity-check --file <that.md> --dir "<ARTIFACTS_DIR>"
```

Resolve any `NEEDS-DECISION` with the ProcessOS user before continuing to Phase 4.

## AI: Phase 4: Finalize

Reached from Phase 3a/3b (BPMN and system context, generated or skipped) and then Phase 3c
(Integrity, run or skipped). `document.md` has already written the discovery files and
`review-questions.yaml`; this step performs completion **once, last** so it never fires before the
optional AS-IS BPMN or the integrity check.

Read and follow `references/finalize.md`: mark discovery ✅ Done in `.camunda/state.md`, append the
audit entry, write the memory entry, close the iteration, and print the final summary (including the
AS-IS BPMN block if Phase 3a ran).

## Error Handling

- Specialist agent fails to write findings file → note in coverage report as "no data", continue
- No config + no state → bootstrap.md will ask user interactively, wait for answers
- Human gate no response → remain paused, resume on next user message
- Research round limit reached → proceed to Phase 3 regardless of coverage; unverified claims marked *(unverified — research round limit reached)*
