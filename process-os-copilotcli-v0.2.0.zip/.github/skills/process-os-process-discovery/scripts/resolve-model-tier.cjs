#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Resolves a portable model tier (high|medium|low) to a Claude Code model id.
//
// This is the Claude Code adapter's tier mapping per ADR-0006. Other runtime
// adapters will ship their own version of this script (or replace it via
// scripts/plugin-discovery/which-runtime.cjs's resolution).
//
// Usage:
//   scripts/plugin-discovery/resolve-model-tier.cjs [tier]
//
// Defaults to "medium". Exits 2 on unknown tier.

'use strict';

const MAP = {
  high: 'claude-opus-4-7',
  medium: 'claude-sonnet-4-6',
  low: 'claude-haiku-4-5',
};

function main() {
  const tier = process.argv[2] ?? 'medium';
  const model = MAP[tier];
  if (!model) {
    process.stderr.write(`error: unknown tier "${tier}" (expected high|medium|low)\n`);
    process.exit(2);
  }
  process.stdout.write(model + '\n');
}

if (require.main === module) main();
