#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Write the governance job's staged `dataSources` into process-scope.md as the
// `## Data sources` section.
//
// The "Execute discovery" service task stages the configured data sources as
// `dataSources` inside its `skillInput`, which process-os-governance-job-activation
// writes to .camunda/job-input.json. `## Data sources` is the heading Phase 0
// bootstrap extracts and categorizes into filesystem, web and github buckets, and
// the one the specialists honour under `source-mode: allowlist` — so that section is
// the only interface those entries have to the discovery pipeline.
//
// Usage: node apply-data-sources.cjs        (takes no arguments)
//
// The section is upserted: an existing `## Data sources` section has its body
// replaced in place and any duplicate of it is dropped, so a re-activated job cannot
// leave two sections behind for bootstrap to read. Every other section is copied
// through unchanged and in its original order, and a run whose result equals the file
// on disk writes nothing at all — an unchanged file must not be rewritten.
//
// A missing process-scope.md is a hard error rather than a file to create: the
// identity and scope sections are process-os-project-initialization's output, and a
// file carrying nothing but data sources would read as a complete scope.
//
// stdout carries the human-readable log; nothing is written to stderr, since the
// caller is an agent reading the combined output and Windows PowerShell 5.1 promotes
// any native-command stderr write to an error record.
//
// Exit codes:
//   0  the `## Data sources` section is current — written, replaced, or already identical
//   2  usage error (an argument was passed)
//   3  nothing to apply: no staged job input, no `dataSources` key, or an empty list.
//      Routine — a standalone run stages nothing — and process-scope.md is untouched
//   4  .camunda/job-input.json exists but could not be read
//   5  .camunda/job-input.json is not valid JSON
//   6  .camunda/job-input.json has no "skillInput" object
//   7  data sources are staged but process-scope.md is missing
//
// Codes 4-7 are the "there but broken" states: input exists and could not be applied.
// None of them is ever reported as the routine 3, so a caller cannot read a broken
// staged input as nothing to do.

'use strict';

const fs = require('fs');
const path = require('path');
// Source import of the shared reader; the bundler rewrites it to a local sibling
// require(path.join(__dirname, 'read-job-input.cjs')) inside this skill's scripts/ dir.
const { readJobInput } = require(
  path.join(__dirname, 'read-job-input.cjs')
);

const JOB_INPUT = path.join('.camunda', 'job-input.json');
const SCOPE = 'process-scope.md';
const KEY = 'dataSources';

const HEADING = '## Data sources';
// Case-insensitive, so a hand-authored `## Data Sources` is replaced rather than
// duplicated.
const HEADING_RE = /^##[ \t]+data sources[ \t]*$/i;
// A section runs to the next top- or second-level ATX heading; a `###` under the
// heading is part of the data-source content and is replaced with it.
const SECTION_BREAK_RE = /^#{1,2}[ \t]/;

const EXIT = {
  OK: 0,
  USAGE: 2,
  NOTHING_TO_APPLY: 3,
  JOB_INPUT_UNREADABLE: 4,
  JOB_INPUT_INVALID_JSON: 5,
  JOB_INPUT_NO_SKILL_INPUT: 6,
  SCOPE_MISSING: 7,
};

// readJobInput signals each broken-input reason with an `.code`; keep this script's
// codes equal to the shared reader's own so one exit-code table covers both.
const READ_ERROR_EXIT = {
  JOB_INPUT_FILE_MISSING: EXIT.JOB_INPUT_UNREADABLE,
  JOB_INPUT_INVALID_JSON: EXIT.JOB_INPUT_INVALID_JSON,
  JOB_INPUT_NO_SKILL_INPUT: EXIT.JOB_INPUT_NO_SKILL_INPUT,
};

const USAGE = 'usage: node apply-data-sources.cjs\n';

/**
 * Project a staged `dataSources` value onto trimmed, de-duplicated bullet strings.
 *
 * The discovery form's data-source rows are contexts (`{url}`), and a plain
 * dynamiclist emits `{value, label}` rows, so an object row is projected before it is
 * trimmed — without the projection every row collapses to `''` and the section renders
 * empty rather than raising. A non-array value is treated as a newline-separated
 * block, with a leading bullet marker stripped so an already-bulleted line is not
 * bulleted twice. Identical entries collapse to one bullet.
 *
 * @param {unknown} value The value read from the staged skillInput.
 * @returns {string[]} Entry strings, in first-seen order.
 */
function normalizeEntries(value) {
  if (value == null) return [];
  const rows = Array.isArray(value)
    ? value.map((row) => {
        if (row == null) return '';
        if (typeof row !== 'object') return row;
        return row.url ?? row.value ?? row.label ?? '';
      })
    : String(value)
        .split(/\n/)
        .map((line) => line.replace(/^[-*][ \t]+/, ''));
  const entries = new Set();
  for (const row of rows) {
    const entry = String(row).trim().replace(/\s+/g, ' ');
    if (entry) entries.add(entry);
  }
  return [...entries];
}

/**
 * Every `## Data sources` section in a line array, as `[start, end)` index pairs.
 *
 * @param {string[]} lines
 * @returns {Array<[number, number]>}
 */
function sectionRanges(lines) {
  const ranges = [];
  for (let i = 0; i < lines.length; i++) {
    if (!HEADING_RE.test(lines[i])) continue;
    let end = i + 1;
    while (end < lines.length && !SECTION_BREAK_RE.test(lines[end])) end++;
    ranges.push([i, end]);
    i = end - 1;
  }
  return ranges;
}

/**
 * The markdown with exactly one `## Data sources` section carrying `entries`.
 *
 * An absent section is appended at the end of the file, because the position of the
 * existing sections is the author's and moving one is an edit nobody asked for. An
 * existing section keeps its own heading spelling for the same reason.
 *
 * @param {string} markdown The current process-scope.md content.
 * @param {string[]} entries Entry strings from `normalizeEntries`.
 * @returns {string} The rewritten markdown.
 */
function upsertSection(markdown, entries) {
  const eol = markdown.includes('\r\n') ? '\r\n' : '\n';
  const lines = markdown.split(/\r?\n/);
  const bullets = entries.map((entry) => `- ${entry}`);
  const ranges = sectionRanges(lines);

  if (!ranges.length) {
    const body = [...lines];
    while (body.length && body[body.length - 1].trim() === '') body.pop();
    const prefix = body.length ? [...body, ''] : [];
    return [...prefix, HEADING, '', ...bullets, ''].join(eol);
  }

  const out = [];
  let cursor = 0;
  let placed = false;
  for (const [start, end] of ranges) {
    out.push(...lines.slice(cursor, start));
    if (!placed) {
      out.push(lines[start], '', ...bullets, '');
      placed = true;
    }
    cursor = end;
  }
  out.push(...lines.slice(cursor));
  return out.join(eol);
}

/**
 * Read the staged entries and bring process-scope.md's section in line with them.
 *
 * @param {object} [paths]
 * @param {string} [paths.jobInputPath] Staged job input to read.
 * @param {string} [paths.scopePath] Scope document to update.
 * @returns {{log: string[], exitCode: number}}
 */
function applyDataSources({ jobInputPath = JOB_INPUT, scopePath = SCOPE } = {}) {
  // Checked before the read so an absent file stays the routine "nothing staged"
  // case: a standalone discovery run has no governance job behind it. A file that is
  // there and unreadable still reaches readJobInput and exits 4.
  if (!fs.existsSync(jobInputPath)) {
    return {
      log: [`no ${jobInputPath}; nothing was staged — ${scopePath} left unchanged`],
      exitCode: EXIT.NOTHING_TO_APPLY,
    };
  }

  let value;
  try {
    value = readJobInput(KEY, jobInputPath);
  } catch (err) {
    return {
      log: [`cannot read ${KEY} from ${jobInputPath} — ${err.message}`],
      exitCode: READ_ERROR_EXIT[err.code] || 1,
    };
  }

  const entries = normalizeEntries(value);
  if (!entries.length) {
    return {
      log: [`no ${KEY} staged in ${jobInputPath} — ${scopePath} left unchanged`],
      exitCode: EXIT.NOTHING_TO_APPLY,
    };
  }

  // Checked only once there is something to write, so a standalone run with neither
  // a staged input nor a scope document still reports the routine outcome.
  if (!fs.existsSync(scopePath)) {
    return {
      log: [
        `${scopePath} not found; the ${HEADING} section has nothing to attach to. ` +
          'Run /process-os-project-initialization first.',
      ],
      exitCode: EXIT.SCOPE_MISSING,
    };
  }

  const current = fs.readFileSync(scopePath, 'utf8');
  const next = upsertSection(current, entries);
  if (next === current) {
    return {
      log: [`${scopePath} already lists these ${entries.length} data source(s) — unchanged`],
      exitCode: EXIT.OK,
    };
  }
  fs.writeFileSync(scopePath, next);
  return {
    log: [`wrote ${entries.length} data source(s) to ${HEADING} in ${scopePath}`],
    exitCode: EXIT.OK,
  };
}

module.exports = {
  EXIT,
  HEADING,
  applyDataSources,
  normalizeEntries,
  sectionRanges,
  upsertSection,
};

if (require.main === module) {
  if (process.argv.length > 2) {
    process.stdout.write(`apply-data-sources.cjs: takes no arguments\n${USAGE}`);
    process.exit(EXIT.USAGE);
  }
  const { log, exitCode } = applyDataSources();
  if (log.length) process.stdout.write(`${log.join('\n')}\n`);
  process.exit(exitCode);
}
