#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';
// Deterministic coverage-gate check for the discovery loop (analyze.md Step 3).
//
// Reads data/progress.json (agent-maintained, schema in references/progress.md) from the
// current working directory — the ProcessOS project root — and evaluates the three gate
// triggers exactly as specified:
//   1. all coverage areas >= 70% confidence
//   2. rounds run in this iteration >= maxRounds
//   3. new findings this research round < 5% of total findings (diminishing returns)
//
// Trigger 3 needs the previous round's findings count, which progress.json does not keep;
// this script maintains its own per-round record in data/.coverage-gate-history.json.
// On the first round the trigger is not evaluable and counts as not satisfied.
//
// That sidecar has no link back to the progress.json it was recorded from, so it must not be
// trusted blindly: a user who aborts a run and deletes data/progress.json to start over leaves it
// behind untouched, and the new run's round 2 would then diff against the *old* run's round-1
// count — firing the diminishing-returns gate on a coincidence and reproducing the premature exit
// this script exists to prevent. Two rules keep it honest: an iteration always begins at its own
// first round, so seeing that round discards the whole history; and any recorded round at or above
// the current one is from a superseded pass and is dropped (which also makes re-running the script
// within one round idempotent).
//
// Output (stdout): one "GATE: <trigger>" line per satisfied trigger, or "CONTINUE" plus one
// "below-threshold: <area> (<pct>%)" line per area under 70%; then one "warning: <text>" line per
// trigger that could not be evaluated at all.
//
// Those warnings qualify the verdict, so they are part of the result and share its stream — a
// caller reads this script's stdout, and stderr carries nothing but the exit-2 error —
// machine-readable output goes to stdout only. On native Windows a caller cannot redirect the
// two apart anyway: `2>/dev/null` is bash-only, and PowerShell's `2>&1` would fold a warning into
// the captured value.
//
// Exit codes: 0 = gate triggered (proceed to human review / approval),
//             1 = gate NOT triggered (loop: another gather round),
//             2 = usage/IO error (missing or invalid data/progress.json).
//
// The gate decides only WHETHER human review is due. WHO approves it (the user, or unattended
// mode auto-approving) is the caller's concern — unattended mode must never skip this check.

const fs = require('node:fs');
const path = require('node:path');

const THRESHOLD_PCT = 70;
const DIMINISHING_RATIO = 0.05;
const DEFAULT_MAX_ROUNDS = 5;

function fail(msg) {
  process.stderr.write(`error: ${msg}\n`);
  process.exit(2);
}

function main() {
  const progressPath = path.join(process.cwd(), 'data', 'progress.json');
  let progress;
  try {
    progress = JSON.parse(fs.readFileSync(progressPath, 'utf8'));
  } catch (e) {
    fail(`cannot read ${progressPath}: ${e.message}`);
  }
  if (!progress || typeof progress !== 'object' || Array.isArray(progress)) {
    fail(`invalid ${progressPath}: expected a JSON object`);
  }

  // progress.md's schema requires a positive-integer round — defaulting it would let a
  // malformed progress.json silently mis-evaluate the round-limit trigger.
  if (!Number.isInteger(progress.round) || progress.round < 1) {
    fail(`invalid ${progressPath}: "round" must be a positive integer (got ${JSON.stringify(progress.round)})`);
  }
  const round = progress.round;
  // `round` keeps running across iterations so each round's findings file stays addressable,
  // which means the budget cannot be read off the number itself: it is counted from where this
  // iteration began. Absent, the run is in its first iteration and the two coincide.
  if (
    progress.iterationStartRound !== undefined &&
    (!Number.isInteger(progress.iterationStartRound) ||
      progress.iterationStartRound < 1 ||
      progress.iterationStartRound > round)
  ) {
    fail(
      `invalid ${progressPath}: "iterationStartRound" must be a positive integer <= "round" ` +
        `(got ${JSON.stringify(progress.iterationStartRound)})`
    );
  }
  const iterationStartRound = Number.isInteger(progress.iterationStartRound)
    ? progress.iterationStartRound
    : 1;
  const roundsThisIteration = round - iterationStartRound + 1;
  const maxRounds =
    Number.isInteger(progress.maxRounds) && progress.maxRounds > 0 ? progress.maxRounds : DEFAULT_MAX_ROUNDS;
  const coverage = Array.isArray(progress.coverage) ? progress.coverage : [];
  // The progress.md schema requires every coverage row to carry {area: string, pct: 0-100}.
  // A malformed row means progress.json was written wrong — fail loudly rather than letting
  // it silently skew the CONTINUE/GATE decision.
  for (const c of coverage) {
    const areaOk = c && typeof c.area === 'string' && c.area.trim() !== '';
    const pctOk = c && typeof c.pct === 'number' && Number.isFinite(c.pct) && c.pct >= 0 && c.pct <= 100;
    if (!areaOk || !pctOk) {
      fail(`invalid ${progressPath}: coverage entry ${JSON.stringify(c)} must have {area: string, pct: 0-100}`);
    }
  }
  const findingsRecorded =
    progress.stats && Number.isInteger(progress.stats.findingsRecorded) && progress.stats.findingsRecorded >= 0
      ? progress.stats.findingsRecorded
      : null;

  // Per-round findings record for the diminishing-returns trigger.
  const historyPath = path.join(process.cwd(), 'data', '.coverage-gate-history.json');
  let history = { rounds: {} };
  try {
    const parsed = JSON.parse(fs.readFileSync(historyPath, 'utf8'));
    if (parsed && typeof parsed.rounds === 'object' && parsed.rounds !== null) history = parsed;
  } catch {
    // first run — no history yet
  }
  if (round === iterationStartRound) {
    // An iteration always starts here, so anything on disk belongs to a previous, abandoned
    // pass — see the sidecar note in the header.
    history = { rounds: {} };
  } else {
    for (const k of Object.keys(history.rounds)) {
      if (Number(k) >= round) delete history.rounds[k];
    }
  }

  const triggers = [];
  // Collected rather than written as they arise, so the verdict lines stay at the top of stdout.
  const warnings = [];

  if (coverage.length > 0) {
    if (coverage.every((c) => c.pct >= THRESHOLD_PCT)) {
      triggers.push(`GATE: all ${coverage.length} coverage areas >= ${THRESHOLD_PCT}%`);
    }
  } else {
    warnings.push('warning: coverage table is empty — the >=70% trigger cannot be evaluated');
  }

  if (roundsThisIteration >= maxRounds) {
    triggers.push(`GATE: round ${roundsThisIteration} of ${maxRounds} — round limit reached`);
  }

  if (findingsRecorded !== null) {
    const prev = history.rounds[String(round - 1)];
    if (Number.isInteger(prev) && findingsRecorded < prev) {
      // findingsRecorded is cumulative (analyze.md Step 5) — a decrease means progress.json
      // was written wrong, and treating it as "0 new findings" would false-trigger the gate.
      fail(
        `invalid ${progressPath}: stats.findingsRecorded (${findingsRecorded}) decreased vs ` +
        `round ${round - 1} (${prev}) — the count is cumulative across research rounds`
      );
    }
    if (Number.isInteger(prev) && findingsRecorded > 0) {
      const newFindings = findingsRecorded - prev;
      if (newFindings / findingsRecorded < DIMINISHING_RATIO) {
        triggers.push(
          `GATE: ${newFindings} new finding(s) this round out of ${findingsRecorded} total (< ${DIMINISHING_RATIO * 100}%) — diminishing returns`
        );
      }
    }
    history.rounds[String(round)] = findingsRecorded;
  } else {
    warnings.push('warning: stats.findingsRecorded missing — the diminishing-returns trigger cannot be evaluated');
  }

  // Written unconditionally, so a reset or prune above lands on disk even when this round
  // recorded no count of its own — otherwise the discarded history would survive to the next run.
  try {
    fs.writeFileSync(historyPath, JSON.stringify(history, null, 2) + '\n');
  } catch (e) {
    warnings.push(`warning: cannot write ${historyPath}: ${e.message}`);
  }

  if (triggers.length > 0) {
    for (const t of triggers) process.stdout.write(t + '\n');
    for (const w of warnings) process.stdout.write(w + '\n');
    process.exit(0);
  }

  process.stdout.write('CONTINUE\n');
  for (const c of coverage) {
    if (c.pct < THRESHOLD_PCT) {
      process.stdout.write(`below-threshold: ${c.area} (${c.pct}%)\n`);
    }
  }
  for (const w of warnings) process.stdout.write(w + '\n');
  process.exit(1);
}

if (require.main === module) main();
