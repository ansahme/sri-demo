#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Merge the reconciled answers.json a reviewer returned into the new iteration's seeded
// review-questions.yaml (the Answers step of discovery's fold-in phase).
//
// The seeded store carries every question exactly as it was originally asked — every `answer` is
// still empty — so this is the first time an answer can land in this iteration's copy. Applying
// it goes through the questions store's own write gate, `questions-schema.cjs`'s `applyAnswers()`,
// the same one the Markdown- and XLSX-response paths use: it writes the block-scalar formatting
// and `status`/`updated` bookkeeping correctly, and it never overwrites a question the store
// already considers settled.
//
// `applyAnswers()` only visits questions the store has, so a response id matching none of them is
// silently invisible to its own written/alreadyAnswered/blank accounting. This script computes
// that set itself and reports it as `unknown` — a stable `qN` should never go missing between the
// seed and the answer, so an id in `answers.json` naming no question in the store is an anomaly to
// surface, not to drop.
//
// Usage:
//   node "scripts/apply-feedback-answers.cjs" <review-questions.yaml> <answers.json>
//
// Output (stdout, on exit 0): {"written": [...], "alreadyAnswered": [...], "blank": [...],
// "unknown": [...]} — see questions-schema.cjs's applyAnswers() for what the first three mean.
//
// Exit codes:
//   0  applied (or nothing to apply — an answers.json of `{}` is a legitimate no-op).
//   2  usage error (wrong number of arguments).
//   3  <answers.json> does not exist, or could not be read.
//   4  <answers.json> exists but is not valid JSON, or is valid JSON that is not a plain object of
//      {qid: text} — an array, a string, a number, or null. "There but broken" never degrades to
//      an empty result: a caller reading `{}` back from a bad file would believe nothing was sent.
//   5  <review-questions.yaml> could not be read at all — missing, not valid YAML, or valid YAML
//      that fails the store's schema. Every one of those means Phase 1 (Advance)'s seed did not
//      land as expected, which is not a state this script can repair, so it fails loud with the
//      underlying reason in the message rather than picking a specific sub-code for it.

const fs = require('fs');
const path = require('path');

const store = require(path.join(__dirname, 'questions-yaml.cjs'));
const { applyAnswers } = require(path.join(__dirname, 'questions-schema.cjs'));

const EXIT = {
  OK: 0,
  USAGE: 2,
  ANSWERS_IO: 3,
  ANSWERS_MALFORMED: 4,
  STORE_ERROR: 5,
};

const USAGE = 'usage: apply-feedback-answers.cjs <review-questions.yaml> <answers.json>\n';

/**
 * @param {number} code
 * @param {string} message
 * @returns {never}
 */
function fail(code, message) {
  process.stderr.write(`apply-feedback-answers: ${message}\n`);
  process.exit(code);
}

/**
 * Read and validate the answers file: a flat JSON object of {qid: text}.
 *
 * @param {string} answersPath
 * @returns {Record<string, unknown>}
 */
function readAnswers(answersPath) {
  let text;
  try {
    text = fs.readFileSync(answersPath, 'utf8');
  } catch (e) {
    fail(EXIT.ANSWERS_IO, `cannot read ${answersPath}: ${e.message}`);
  }
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch (e) {
    fail(EXIT.ANSWERS_MALFORMED, `${answersPath}: not valid JSON — ${e.message}`);
  }
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    fail(
      EXIT.ANSWERS_MALFORMED,
      `${answersPath}: expected a JSON object of {qid: text}, got ${Array.isArray(parsed) ? 'an array' : typeof parsed}`
    );
  }
  return parsed;
}

/**
 * @param {object} doc A validated questions-store document.
 * @returns {Set<string>} Every question id the store holds, across all sections.
 */
function collectKnownIds(doc) {
  const ids = new Set();
  for (const section of (doc && doc.sections) || []) {
    for (const q of (section && section.questions) || []) {
      if (q && typeof q.id === 'string') ids.add(q.id);
    }
  }
  return ids;
}

/**
 * @param {string[]} argv Arguments after the script name.
 */
function main(argv) {
  if (argv.length !== 2) {
    process.stderr.write(USAGE);
    process.exit(EXIT.USAGE);
  }
  const [reviewPath, answersPath] = argv;

  const responses = readAnswers(answersPath);

  let doc;
  try {
    doc = store.read(reviewPath);
  } catch (e) {
    fail(EXIT.STORE_ERROR, `${reviewPath}: ${e.message}`);
  }

  const known = collectKnownIds(doc);
  const unknown = Object.keys(responses).filter((id) => !known.has(id));

  const result = applyAnswers(doc, responses);
  store.write(reviewPath, result.doc);

  process.stdout.write(
    JSON.stringify(
      { written: result.written, alreadyAnswered: result.alreadyAnswered, blank: result.blank, unknown },
      null,
      2
    ) + '\n'
  );
  process.exit(EXIT.OK);
}

if (require.main === module) main(process.argv.slice(2));

module.exports = { EXIT, readAnswers, collectKnownIds, main };
