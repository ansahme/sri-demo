# Fold-in phase: apply feedback from the seeded iteration

This is the fold-in phase of `/process-os-process-discovery`'s single pipeline. `SKILL.md`
resolves `<FEEDBACK_DIR>` (the seeded iteration's `feedback/`) and `<ARTIFACTS_DIR>` (this
iteration's, seeded from it) before invoking this file, and only invokes it when that directory
holds more than its `README.md` scaffold. Two things happen here, in order: applying the
reconciled answer set to this iteration's copy of the review questions, then folding every other
file a reviewer left into the matching `.md`. Research rounds and the coverage loop are the
pipeline's own, run after this phase, not inside it; regenerating BPMN and closing the iteration
are the pipeline's own later steps too.

This phase only **writes files** — it never stages or commits. `SKILL.md`'s finalize step closes
the iteration once everything else is done.

**A hand-edited file under `artifacts/` is a manual override, not a channel.** This phase never
looks for one. A reviewer who wants a diagram or document change reconciled belongs in
`<FEEDBACK_DIR>`, like any other input — see "Fold every other feedback file" below.

## AI: Apply the reconciled answers

Conditional: if `<FEEDBACK_DIR>/answers.json` does not exist, there is nothing to apply here — skip
straight to the per-file fold-in below. Feedback consisting only of prose, with no questionnaire
response, is normal, not an error.

```bash
node ".github/skills/process-os-process-discovery/scripts/path-exists.cjs" "<FEEDBACK_DIR>/answers.json"
```

When it reports `EXISTS`, first merge the reconciled `{qN: "<text>"}` map into the seeded
`<ARTIFACTS_DIR>/review-questions.yaml` — every question the seed carried is still `open`, exactly
as it was asked, so this is the first time an answer lands in this iteration's copy:

```bash
node ".github/skills/process-os-process-discovery/scripts/apply-feedback-answers.cjs" "<ARTIFACTS_DIR>/review-questions.yaml" "<FEEDBACK_DIR>/answers.json"
```

It applies the answers through the store's own write gate (the same one the Markdown- and
XLSX-response paths use), so the block-scalar formatting and `status`/`updated` bookkeeping come
out right without hand-editing the YAML. On exit `0` it prints `{written, alreadyAnswered, blank,
unknown}`:

- `written` — the ids that landed.
- `alreadyAnswered` — should be empty on a freshly seeded store; report it if it is not, since it
  means `answers.json` names a question this iteration already considers settled.
- `blank` — an open question `answers.json` never covered. Routine, not an error — it stays open
  for a later iteration.
- `unknown` — an `answers.json` id matching no question in this iteration's store at all. Report
  any as an anomaly rather than dropping it, since a stable `qN` should never go missing between
  the seed and the answer.

Exit `3` → `<FEEDBACK_DIR>/answers.json` could not be read (the path-exists check above should have
already ruled this out). Exit `4` → it is not valid JSON, or not a flat object of `{qid: text}`.
Exit `5` → `<ARTIFACTS_DIR>/review-questions.yaml` itself could not be read — the seed did not land
as expected. Report the printed message and stop on any non-zero exit; none of these degrade to
"nothing to apply".

Then invoke `process-os-review-answer-application`, which folds every landed answer into the
matching `.md`, updates `gap-analysis.md`, flips answered questions to `[RESOLVED]` in the BPMN, and
returns a `STRUCTURAL_CHANGES` list:

```
process-os-review-answer-application --dir "<ARTIFACTS_DIR>"
```

Pass `--dir` explicitly rather than a bare `review-questions.yaml` path: `<BPMN_DIR>` and the
gate-key derivation both resolve from `--dir`, and this skill's own default is `process-discovery`
— the phase directory, which under the iteration layout holds no `.bpmn` or `question-targets.json`
directly any more.

Carry **`STRUCTURAL_CHANGES`** and the list of `.md` files this step touched into the per-file
fold-in below.

## AI: Fold every other feedback file into the matching `.md` *(gate: `processDiscoveryGate.nonMd`)*

Every file in `<FEEDBACK_DIR>`, minus `answers.json` (handled above) and minus any raw
answer-source export — an `.xlsx` in the shape `process-os-questions-xlsx-export` produces, or a
`.md` in the shape `process-os-questions-md-export` produces. Folding one here would invent
narrative prose from an answers table, or apply an answer already in the store a second time.

**An export is excluded from folding whether or not its answers ever reached the store, so confirm
that they did.** `process-os-sme-feedback` reconciles an export it finds in `<FEEDBACK_DIR>` into
`answers.json` — but a standalone run where no intake ran can hold one nothing has read. Compare
each export's question ids against `answers.json`: any id absent from it is unreconciled, and that
export belongs in this phase's own report below as **Unhandled feedback**, with the reason
`answers not reconciled — run /process-os-sme-feedback`. Dropping it from the fold and saying
nothing would lose those answers with no trace anywhere.

For everything else — reviewer notes, exported docs, spreadsheets, PDFs, a hand-edited `.bpmn`, even
a scanned image — nothing is silently dropped. First make it *readable*, then fold whatever it
carries into the matching `<ARTIFACTS_DIR>/*.md`.

### Make each file readable

- **Text already** (`.txt`, `.csv`, `.tsv`, `.json`, `.yaml`, `.xml`, `.rtf`, source files, …) →
  read it directly, in bounded chunks (~25 KB per read) if it is large.
- **Binary / non-narrative** (`.pdf`, `.docx`, `.xlsx`, `.pptx`, `.doc`, `.xls`, images, …) → make a
  genuine effort to extract its text before giving up — do not skip it on sight. There is no fixed
  toolchain to prescribe: what's available depends entirely on the local runtime. Discover what
  *this* environment actually offers and use your judgement — probe for a converter or library that
  can pull text out of the format at hand, then try it. Only if the format is genuinely opaque, or
  nothing on the box can read it, fall through to "Report what you couldn't" below.
- **A hand-edited `.bpmn`** → extract its element names and structure rather than reading the XML
  whole:
  ```bash
  node ".github/skills/process-os-process-discovery/scripts/bpmn-extract.cjs" "<that .bpmn file>" --names
  ```
  Fold the diagram change into the matching phase `.md`'s prose, exactly like any other input — do
  not write the `.bpmn` file itself. `SKILL.md`'s AS-IS BPMN step regenerates it from the updated
  `.md` when that step runs.

### GATE: honour `processDiscoveryGate.nonMd`

```bash
node ".github/skills/process-os-process-discovery/scripts/read-run-config.cjs" processDiscoveryGate.nonMd
```

Exit 2 → hard error: report stderr and stop; it means the reader failed, not that the key is
unset.

- `true` (attended, default) → present each proposed fold for approve/reject before writing.
- `false` (unattended) → apply the unambiguous folds directly; still list anything ambiguous for
  the ProcessOS user rather than guessing.
- `mode: unattended` in `run.config.yaml` forces unattended regardless of this key's own value.

### Fold in what you could read

For every file you got usable text out of, fan out a sub-agent that:

- treats the extracted text as **additional documentation**,
- cross-checks it against the existing `<ARTIFACTS_DIR>/*.md`,
- folds the relevant content **into the matching `.md`** (the source of truth) — do not treat the
  feedback file itself as canonical, subject to the gate above.

**Even when a feedback file's content turns out to already be reflected in the `.md`** (two
reviewers independently describing the same change), still fold in — never silently skip a file
just because it looks redundant. Append the source's own wording (or its distinguishing detail, e.g.
a compliance/tracking reference it carries) next to the existing content so the `.md` shows both
sources agree.

Record every `.md` you folded into — this, together with `STRUCTURAL_CHANGES` above, is the touched
set `SKILL.md`'s integrity-check step validates next.

### Report what you couldn't — never discard silently

Collect every feedback file that was **not** folded in — no extractor was available, extraction
yielded no usable text, or the content is a pure binary asset — and report it now as **Unhandled
feedback**, one line each with the reason (`no extractor`, `no text extracted`, `binary asset`).
These files are not staged or moved — they stay exactly where the reviewer put them, in
`<FEEDBACK_DIR>`, already committed.

## Output

```
Feedback folded into iteration <N>.

Answers applied: [written]/[open questions in the seed]
Files folded: [list of .md touched]
Unhandled feedback: [list with reasons, or "none"]
```

## Error handling

Any step that fails outright (a hard error from a script, an unreadable store) → report it and
stop; do not continue the fold-in on a partial result.
