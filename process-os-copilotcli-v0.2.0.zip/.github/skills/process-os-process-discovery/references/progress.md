# Progress record (`data/progress.json`)

`data/progress.json` is the machine-readable record of a discovery run. The agent writes it;
`scripts/check-coverage-gate.cjs` and `/process-os-lifecycle-status` read it.

## Writing Progress Updates

After every meaningful event, write `data/progress.json` in the project root using the `Write` tool.

Schema:
```json
{
  "process": "<process name>",
  "org": "<org name>",
  "started": "<ISO 8601 timestamp>",
  "round": <current research round number, running across iterations>,
  "iterationStartRound": <the round this iteration opened at>,
  "maxRounds": <max from config, the budget for one iteration>,
  "phase": "<bootstrap|gathering|analyzing|documenting|complete>",
  "stats": {
    "documentsAnalyzed": <int>,
    "findingsRecorded": <int>,
    "openHypotheses": <int>,
    "queriesRun": <int>,
    "contradictions": <int>
  },
  "specialists": [
    { "id": "<name>", "status": "<pending|running|done|failed>", "progress": <0-100>, "itemsProcessed": <int> }
  ],
  "coverage": [
    { "area": "<area name>", "pct": <0-100> }
  ],
  "recentFindings": [
    { "specialist": "<name>", "text": "<one-line finding>" }
  ],
  "hypotheses": [
    { "id": "H<N>", "text": "<hypothesis>", "status": "<open|confirmed|refuted|contradiction>" }
  ]
}
```

`round` keeps running across iterations so that each round's findings file
(`data/<specialist>-round<N>.md`) stays addressable — `data/` holds the evidence for the run as a
whole, so a number that restarted would have a later iteration overwrite an earlier one's findings.
`maxRounds` is the budget for a single iteration, and `iterationStartRound` is what makes the two
work together: `scripts/check-coverage-gate.cjs` counts `round - iterationStartRound + 1` against
it. Set `iterationStartRound` to this iteration's first round when the iteration opens, and leave
it alone afterwards. Omitting it reads as the first iteration.

Update `data/progress.json`:
- When bootstrap completes: set phase to "gathering", populate specialists list with status "pending"
- When each specialist starts: set its status to "running"
- When each specialist completes: set status to "done", set progress to 100, set itemsProcessed
- When a finding is recorded: prepend to recentFindings (keep last 5)
- When a hypothesis is formed: append to hypotheses
- When coverage is computed: update coverage array
- When analysis completes: set phase to "analyzing"
- When output starts: set phase to "documenting"
- When complete: set phase to "complete"

`round` must be a positive integer, and every `coverage` entry must carry both a non-empty
`area` and a numeric `pct` in 0–100. `scripts/check-coverage-gate.cjs` reads this file and rejects
it (exit 2) if either is malformed, rather than guessing a default — a wrong round number or a
skipped coverage row would silently change the coverage-loop exit decision.

`stats.findingsRecorded` is **cumulative across research rounds**, not per-round — see
[the analyze sub-skill](references/analyze.md) Step 5.

You do not write `data/.coverage-gate-history.json`. That hidden sidecar is owned by
`scripts/check-coverage-gate.cjs`, which uses it to remember the previous round's
`findingsRecorded` for the diminishing-returns trigger. Leave it alone; it self-heals when a run
restarts at round 1.
