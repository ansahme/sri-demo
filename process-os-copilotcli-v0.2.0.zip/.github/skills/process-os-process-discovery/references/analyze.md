# Phase 2: Synthesize + Coverage

You are running the analysis phase of process discovery. This phase merges all specialist findings and evaluates coverage.

## Step 1: Read All Findings

Read the current research round number from `data/bootstrap.md` (the `Research round:` field). Then read every `data/*-round[N].md` file where [N] is that number — e.g., `data/web-round2.md`, `data/filesystem-round2.md`.
Also read all findings from prior research rounds for context.

## Step 2: Synthesize — Think Outside the Box

Everything this step produces is a lead for the next research round or a reviewer question —
never content for the as-is. A path, variant, or hypothesis found here reaches the as-is
documents only once a specialist finding or reviewer feedback shows it.

Do NOT just summarize what was found. Actively look for:

1. **Missing information** — what phase, actor, or system has no coverage? Why?
2. **Contradictions** — does specialist A say X while specialist B implies not-X? Flag these. They are more valuable than simple confirmations.
3. **Volume/timing anomalies** — if HDP or any data source shows timing gaps, lags, or unexpected counts, these suggest undocumented manual steps.
4. **Undocumented paths** — what exception cases, edge flows, or variant processes are hinted at but not documented? Turn each into a gap instruction or a reviewer question, never into a path.
5. **Tacit knowledge gaps** — what would a domain expert know that no document says?
6. **Missing performance baseline** — is there *measured* (not just estimated) data for cycle time, throughput/volume, error/rework rate, and manual-vs-automated effort? An unmeasured baseline is a gap even when the flow is fully mapped.

Form 2-3 hypotheses about things probably true but not confirmed by any single source.

## Step 3: Compute Coverage

For each major process area identified, estimate confidence 0–100% based on:
- Number of independent sources confirming it
- Whether real data (not just docs) confirms it
- Whether contradictions exist (reduce confidence)
- Whether edge cases are documented

Always include a **Performance baseline** area in the coverage table, scored on whether *measured* metrics exist (not just estimates). Keep it low while the baseline is estimated-only or `[GAP]` — this keeps the loop chasing real numbers across research rounds.

**Coverage gate — triggers human review when ANY of:**
- All areas ≥ 70% confidence
- Current research round = maxRounds
- Total new findings this research round < 5% of total findings (diminishing returns)

These are the ONLY three triggers. They are evaluated deterministically in Step 6 by
`scripts/check-coverage-gate.cjs` from `data/progress.json` — never assess them freehand, and
never substitute another condition (run mode, sample process, time pressure, …) for a trigger.

## Step 4: Write `data/coverage-roundN.md`

```markdown
# Coverage Report — Round N
Analysis timestamp: [ISO timestamp]

## Process Area Coverage
| Area | Confidence | Primary Sources | Gaps Remaining |
|------|-----------|-----------------|----------------|
| [area] | ★★★★☆ [N]% | [source1, source2] | [specific gap] |

## Cross-Source Analysis
### Confirmations
- [fact confirmed by multiple sources] *(sources: X, Y)*

### Contradictions
- [contradiction description] *(source A says X, source B says Y)*

## Hypotheses
| ID | Hypothesis | Evidence | Status |
|----|-----------|----------|--------|
| H1 | [hypothesis] | [evidence for/against] | open/confirmed/refuted/contradiction |

## Coverage Decision
<!-- Placeholder only — Step 6 overwrites this section with the verbatim output of
     scripts/check-coverage-gate.cjs. Never fill it in freehand. -->
- Ready for human review: [filled by Step 6: YES on GATE / NO on CONTINUE]
- Reason: [filled by Step 6: the script's GATE:/below-threshold lines, verbatim]

## Recommended Gap Instructions for Round N+1
- [specialist]: [specific query or investigation]
- [specialist]: [specific query or investigation]
```

## Step 5: Update progress.json

Update `data/progress.json` ([schema](references/progress.md)):
- phase: "analyzing"
- coverage: array of {area, pct} from coverage report
- stats.openHypotheses: count of open hypotheses
- stats.contradictions: count of contradictions found
- Also update `stats.findingsRecorded` — the **cumulative** count of finding bullets across the specialist files of **all research rounds so far** (`data/*-round1.md` through `data/*-roundN.md`), not just the current one; `scripts/check-coverage-gate.cjs` diffs this value against the previous round's to compute "new findings" for the diminishing-returns trigger, so a per-round count would mis-trigger the gate — plus `stats.queriesRun` (sum of query table rows across all specialist files) and `stats.documentsAnalyzed` (sum of files/items scanned from filesystem and github specialist files).

## Step 6: Run the Coverage Gate Check

Run the deterministic gate check (it reads the `data/progress.json` you just updated):

```bash
node ".github/skills/process-os-process-discovery/scripts/check-coverage-gate.cjs"
```

- **Exit 0** — gate triggered. stdout has one `GATE: <trigger>` line per satisfied trigger.
- **Exit 1** — gate NOT triggered. stdout has `CONTINUE` plus the areas still below 70%.
- **Exit 2** — `data/progress.json` is missing or invalid; fix it (Step 5) and re-run. This is the
  only exit that writes to stderr.

Either verdict may be followed on stdout by one or more `warning:` lines — a trigger that could
not be evaluated at all (an empty coverage table, a missing `stats.findingsRecorded`), or a
history sidecar that could not be written. They do not change the verdict, but they mean the gate
decided on fewer than three triggers: fix the underlying `data/progress.json` field (Step 5) and
re-run before treating the result as final.

The script's verdict is authoritative. Update the `## Coverage Decision` section of
`data/coverage-roundN.md` to match: `Ready for human review: YES` only on exit 0, with the
`GATE:` line(s) as the reason; on exit 1 write `NO` with the below-threshold areas.

## Step 7: Present Coverage Report to Human

Output the coverage report clearly in the terminal. Then ask:

```
Coverage report for research round N:

[table of areas + confidence]

Open hypotheses: [count]
Contradictions found: [count]

---
Ready for human review: [YES/NO — verbatim from check-coverage-gate.cjs]

Decision needed:
  (a) APPROVE — proceed to documentation
  (b) MORE — request another research round (describe specific gaps below)

Your response:
```

## Step 8: Handle Human Response

**Unattended mode check — before waiting for input:**

```bash
node ".github/skills/process-os-process-discovery/scripts/read-run-config.cjs" mode
```

Exit 2 → hard error: report stderr and stop; it means the reader failed, not that the key is unset.

If it prints `unattended`, the gate still decides — unattended mode changes only WHO approves it,
never whether it triggered:

- Step 6 exited **0** (`GATE:`): output "Unattended mode — coverage gate triggered
  ([trigger]). Auto-approving." and follow the APPROVE path below without waiting for input.
- Step 6 exited **1** (`CONTINUE`): follow the MORE path below, using the coverage report's
  "Recommended Gap Instructions for Round N+1" as the gaps. Do NOT auto-approve, do NOT
  skip research rounds, and do NOT invent a substitute exit condition — the loop runs until the
  script prints `GATE:`.

If it prints `interactive` (the default): wait for the user response as described in Step 7. (A
human may APPROVE before the gate triggers — early approval is their call, not yours.)

If APPROVE (or no specific gaps given):
- Write gap instructions "none — approved" to bootstrap for next research round
- Proceed to Phase 3 (document.md)

If MORE:
- Write the specific gaps (human's, or on the unattended path the coverage report's
  recommendations) into `data/bootstrap.md` gap instructions section
- Increment research round counter in bootstrap.md
- Before returning control, complete Step 9 (append to state.md discovery log for this research round).
- Return control to orchestrator to loop back to Phase 1 (parallel gather)

## Step 9: Update state.md discovery log

Append to `## Discovery Log` in `.camunda/state.md`:
`- Round N: [active specialist count] specialists, coverage avg [N]%. [One sentence summary of key finding or remaining gap].`
