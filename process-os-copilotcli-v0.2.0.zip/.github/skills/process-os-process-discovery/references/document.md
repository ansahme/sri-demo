# Phase 3: Output — Write Documentation

You are running the output phase of process discovery.

## Before Starting

Do NOT read specialist findings or coverage reports yourself. They are large and accumulate fast — pulling them into the orchestrator context here causes API back-pressure on subsequent tool calls (the orchestrator's context is already heavy from Phase 1 dispatch and Phase 2 analysis).

Read only:
- `data/bootstrap.md` — process metadata (small)
- `.camunda/state.md` — discovery log (small)

Everything else (`data/*-round*.md`, `data/coverage-round*.md`) is loaded by the synthesizer subagent in Step 2, not by you.

## Documentation Principles

1. **Source every claim** — every factual statement must end with *(source: [specialist-roundN / human: round-N-gate / inferred])*. Readers must be able to trace each fact to its origin.
2. **Mark confidence** — claims confirmed by multiple sources get no marker. Claims from a single source: *(single source)*. Inferences: *(inferred — not verified)*. An inference may only qualify a step a specialist finding or reviewer feedback already shows — its actor, system, or timing, for example — and never introduces a step, path, or variant, whether the document is written fresh or revised.
3. **No invented facts** — if something is unknown, write "unknown" or mark as `[GAP]`.
4. **Process architecture decision** — decide whether this process is flat (one level) or hierarchical (main process + subprocesses). Document your reasoning in `<ARTIFACTS_DIR>/00-index.md`.
5. **Handle missing data** — if a specialist's findings file is missing or contains only an error note (e.g., 'gh CLI not available'), treat that specialist as providing no data for that research round. Do not reference it as a source.

## Step 1: Read config flags (one short Bash)

Read `<ARTIFACTS_DIR>` from `data/bootstrap.md`'s `- **Artifacts dir:**` line first —
`bootstrap.md` Step 2 resolved it once; every writer below reuses that value rather than
re-resolving it.

```bash
node ".github/skills/process-os-process-discovery/scripts/read-run-config.cjs" decomposition
node ".github/skills/process-os-process-discovery/scripts/read-run-config.cjs" edge-cases
node ".github/skills/process-os-process-discovery/scripts/read-run-config.cjs" skip-provenance
```

Exit 2 from any of the three reads above → hard error: report stderr and stop; it means the reader failed, not that the key is unset.

Each prints the configured value or its schema default (`per-phase`, `standalone`, `false`). Treat any decomposition value outside the enum as `per-phase`, and any edge-cases value outside the enum as `standalone`. Capture all three; you will pass them to the synthesizer.

## Step 2: Dispatch the synthesizer subagent

Do NOT do the pre-writing analysis inline. The orchestrator's context is already large after specialist dispatch and analyze.md; emitting even a small tool call against that context hits API back-pressure. Push the work to a fresh subagent with its own context window.

Dispatch a single subagent (Claude Code: one `Agent()` call; other platforms: invoke the sub-skill directly): the subagent reads `data/bootstrap.md`, every `data/*-round*.md`, every `data/coverage-round*.md`, and writes `data/doc-context.md`.

**Agent prompt:**

```
You are the documentation-context synthesizer for /process-os-process-discovery.

Working directory: <CWD>
ARTIFACTS_DIR:     <value from Step 1>
DECOMPOSITION:     <value from Step 1>
EDGE_CASES:        <value from Step 1>

Steps:
1. Read data/bootstrap.md, all data/*-round*.md, all data/coverage-round*.md, and every
   document already in ARTIFACTS_DIR — seeded from the previous iteration, with reviewer
   feedback already folded in. A flow those documents attribute to reviewer feedback is sourced
   and belongs in the lists below.
2. Make the architecture decision:
   - If DECOMPOSITION == single: architecture is "flat — single phase file (decomposition: single configured)".
   - Else: flat vs. hierarchical — do all phases describe steps of one process instance, or do some have independent triggers that would make them separate deployable processes? One-sentence rationale.
3. Build the Phase List:
   - If DECOMPOSITION == single: exactly one entry — `process-01-asis: As-Is End-to-End Flow`.
   - Else: one entry per distinct phase found in findings. Slug `process-NN-[name]` + title.
4. Build the Subprocess List:
   - If architecture is flat OR DECOMPOSITION == single: write `none`.
   - If architecture is hierarchical: one entry per independently callable child flow. Use slug
    `subprocess-[name]`, process ID equal to that slug, and list every parent phase that calls it.
    Include only flows the findings establish as a distinct child process or reusable business
    capability; do not create a subprocess document for contained work that belongs in an embedded
    BPMN subprocess.
5. Build the Edge Case List:
   - If EDGE_CASES == skip OR DECOMPOSITION == single: write `none`. Inline variants into phase files.
   - Else: one entry per edge case warranting a standalone file. Slug `edge-NN-[name]` + title.
6. Build the Reviewer Questions block. Scan findings/coverage for gaps in:
   - **System gaps**: business function category, integration method, owner, system of record
   - **Business object gaps**: business explanation, owning system, lifecycle states, aliases
   For each gap, write one specific answerable question for the SME. Group into "### System Questions" and "### Business Object Questions". Write "none" if no gaps.
7. Build Key Facts: 8–12 most important findings, each sourced. These ground downstream writers.
8. Derive the Scope Boundary:
   - **Start trigger:** the business event that kicks off the first phase (from the Phase List / findings).
   - **Done when:** the business condition that ends the last phase, in business terms.
   - **Out of scope:** activities, variants, or systems explicitly excluded per `process-scope.md`'s `process-description`, absent when the scope never supplied one. If no source states any exclusion, write `[GAP]` and add an "Is anything explicitly out of scope?" entry to the Reviewer Questions block.
9. Every phase, subprocess, and edge case you list must be one a
   specialist finding (or folded-in reviewer feedback) shows the source exhibiting. Do not add a
   flow, variant, or edge case to make the process more complete, and do not carry a proposed
   change into the AS-IS; record what is unknown as a Reviewer Question or `[GAP]` instead.

Write data/doc-context.md in this exact format:

# Documentation Context
Generated: [date] | Process: [process name]

## Config flags
- artifacts-dir: <ARTIFACTS_DIR>
- decomposition: <DECOMPOSITION>
- edge-cases: <EDGE_CASES>

## Architecture
[flat | hierarchical] — [one sentence reason]

## Scope Boundary
- Start trigger: [event] *(source: [X])*
- Done when: [condition] *(source: [X])*
- Out of scope: [items, or [GAP]]

## Phase List
- process-01-[name]: [Phase Title]
- process-02-[name]: [Phase Title]
...

## Subprocess List
- subprocess-[name]: [Child Process Title] | process ID: subprocess-[name] | called by: process-NN-[parent], process-NN-[other-parent]
(or single line: `none`)

## Edge Case List
- edge-01-[name]: [Edge Title]
(or single line: `none`)

## Reviewer Questions
### System Questions
- [question]
### Business Object Questions
- [question]
(or: `none`)

## Key Facts (writer context)
- [fact] *(source: [specialist-roundN])*
...

Hard limits:
- Total file ≤ 200 lines.
- Each Key Fact ≤ 2 lines.
- Reviewer Questions section ≤ 30 questions; if you have more, keep the highest-impact ones.

Stop after writing the file. Do not explain.
```

Wait for the subagent to complete and verify `data/doc-context.md` exists.

## Step 3: Dispatch all file writers in parallel

**Dispatch all file writers simultaneously** — run each as an independent subagent:

- **Claude Code:** issue ALL `Agent()` calls in a **single assistant turn** (one tool-message with N `tool_use` blocks). Do not emit agents one-by-one across turns — that serialises execution. If one writer is slow, dispatching one-per-turn lets that single writer block the whole flow. Results are awaited together before continuing.
- **Other platforms:** invoke each writer sub-skill sequentially if parallel dispatch is not available.

Decide the full list of writers first (built from `data/doc-context.md`):

- `as-is-process` (always)
- `gap-analysis` (always)
- `00-index` (always)
- `participants-and-systems` (always)
- `data-objects` (always)
- One agent per `process-NN-[name]` entry in the Phase List
- One agent per `subprocess-[name]` entry in the Subprocess List (skip if list is `none`)
- One agent per `edge-NN-[name]` entry in the Edge Case List (skip if list is `none`)
- `provenance` (skip if Step 1 reported `skip-provenance: yes`)

Then emit ALL those `Agent()` calls in a single assistant turn. If you find yourself emitting an Agent, waiting for it, then emitting the next, you are doing it wrong — stop, batch the rest into one turn.

Each agent reads:
- `data/doc-context.md` — architecture decision, phase list, reviewer questions, key facts, `<ARTIFACTS_DIR>`
- All `data/*-round*.md` and `data/coverage-round*.md` — source material
- The relevant `Spec:` section in `references/document.md` — format rules
- **its own target file, when one already exists** — see below

**A target that already exists is a base to revise, not a path to overwrite.** An iteration opened
after a completed one is seeded from it, and a reviewer's corrections have already been folded into
those documents by the time this step runs. A writer that regenerates from the round findings alone
discards them silently — the documents still look well-formed, so nothing downstream can tell.

Each writer therefore reads its target first, and where it exists:

- keep every statement the findings neither contradict nor supersede, **in the reviewer's own
  wording** — a rewording that preserves the meaning still destroys the correction's provenance
  and reads to that reviewer as having been ignored;
- revise only what this round's findings actually bear on, and re-source those lines normally;
- never drop a section the spec does not require just because this round found nothing for it.

**The base is kept only where a source exhibits it.** A seeded document may carry a path, variant,
or improvement an earlier iteration wrote without a source. Drop any seeded statement that
describes a path, variant, or change no specialist finding or reviewer feedback shows — or, where
it names a genuine unknown, turn it into a `[GAP]` — rather than keeping it merely because
nothing contradicts it. Reviewer feedback already folded in is a source and stays. Hypotheses
from `data/coverage-round*.md` never become as-is content.

A target that does not exist is written fresh, exactly as the spec describes.

---

**Agent: as-is-process**

Prompt:
```
Read data/doc-context.md. Read all data/*-round*.md and data/coverage-round*.md files.
Read the section "### Spec: as-is-process.md" in references/document.md and follow it exactly.
Write <ARTIFACTS_DIR>/as-is-process.md. Use the Reviewer Questions block from doc-context.md verbatim.
Source every claim.
```

**Agent: gap-analysis**

Prompt:
```
Read data/doc-context.md. Read all data/*-round*.md and data/coverage-round*.md files.
Read the section "### Spec: gap-analysis.md" in references/document.md and follow it exactly.
Write <ARTIFACTS_DIR>/gap-analysis.md. Source every gap to its specialist and research round.
```

**Agent: 00-index**

Prompt:
```
Read data/doc-context.md.
Read the section "### Spec: 00-index.md" in references/document.md and follow it exactly.
Write <ARTIFACTS_DIR>/00-index.md. Use the architecture decision and phase/subprocess/edge lists from doc-context.md exactly.
```

**Agent: participants-and-systems**

Prompt:
```
Read data/doc-context.md. Read all data/*-round*.md files.
Read the section "### Spec: participants-and-systems.md" in references/document.md and follow it exactly.
Write <ARTIFACTS_DIR>/participants-and-systems.md.
```

**Agent: data-objects**

Prompt:
```
Read data/doc-context.md. Read all data/*-round*.md and data/coverage-round*.md files.
Read the section "### Spec: data-objects.md" in references/document.md and follow it exactly.
Write <ARTIFACTS_DIR>/data-objects.md. De-duplicate objects before writing.
```

**Phase agents — one per phase in the Phase List:**

For each phase `process-NN-[name]` listed in `data/doc-context.md`, dispatch one agent.

When `decomposition == single`, the Phase List has exactly one entry (`process-01-asis`); dispatch a single agent and instruct it to cover the entire end-to-end flow as sequential sections inside the BPMN-Ready Description block.

Prompt:
```
Read data/doc-context.md. Read all data/*-round*.md and data/coverage-round*.md files.
Read the section "### Spec: process-NN-[phase].md" in references/document.md and follow it exactly.
Write <ARTIFACTS_DIR>/process-NN-[name].md covering the phase "[Phase Title]".
Source every claim. Use BPMN-ready task type tags.

If this is the single end-to-end phase file (slug `process-01-asis` under decomposition=single):
cover the entire happy path as one continuous BPMN-Ready Description, with each former phase
appearing as a sequential block of tasks/gateways. Inline any variants and exceptions
under "Error Paths" / "Known Issues" — do not produce or reference separate edge files.

If `edge-cases == skip` (per data/doc-context.md or run.config.yaml): inline any variants
and exceptions you discover into this file's "Error Paths" / "Known Issues" sections. Do not
expect a separate edge file to cover them.

For each Subprocess List entry whose `called by` value includes this phase, add a
`[CallActivity]` entry at its calling point. State the child title, its exact `process ID`, and
the child source file `subprocess-[name].md`. Do not write or modify that child file.
```

**Subprocess agents — one per child in the Subprocess List (skip entirely if list is `none`):**

Prompt:
```
Read data/doc-context.md. Read all data/*-round*.md and data/coverage-round*.md files.
Read the section "### Spec: subprocess-[name].md" in references/document.md and follow it exactly.
Write <ARTIFACTS_DIR>/subprocess-[name].md covering the child process "[Child Process Title]".
Use the exact process ID and parent phases from the Subprocess List. Source every claim.
```

**Edge agents — one per edge in the Edge Case List (skip entirely if list is `none`, including when `decomposition == single` or `edge-cases == skip`):**

Prompt:
```
Read data/doc-context.md. Read all data/*-round*.md files.
Read the section "### Spec: edge-NN.md" in references/document.md and follow it exactly.
Write <ARTIFACTS_DIR>/edge-NN-[name].md covering the edge case "[Edge Title]".
```

**Provenance agent — skip entirely if skip-provenance = yes:**

Prompt:
```
Read data/doc-context.md. Read all data/*-round*.md and data/coverage-round*.md files.
Read the section "### Spec: provenance.md" in references/document.md and follow it exactly.
Write <ARTIFACTS_DIR>/provenance.md.
```

---

Wait for all agents to complete before proceeding.

## After All Files Written

**Generate review questions** — check skip-review first:
```bash
node ".github/skills/process-os-process-discovery/scripts/read-run-config.cjs" skip-review
```
Exit 2 → hard error: report stderr and stop; it means the reader failed, not that the key is unset.

If skip-review = true: skip review-questions entirely. Update `data/progress.json` phase → `"review-ready"` directly.
If skip-review = false: Read [the review-questions sub-skill](references/review-questions.md) and follow it inline. This produces `<ARTIFACTS_DIR>/review-questions.yaml` — the questions store — and updates `data/progress.json` phase to `"review-ready"`. If the file cannot be read, update `data/progress.json` phase → `"review-ready"` directly.

Review-questions must be produced **here**, before the optional AS-IS BPMN (Phase 3a): Phase 3a's
`question-targets.json` binds its `qN` to the ids already written in `review-questions.yaml`.

**Then return control to the orchestrator — do NOT finalize here.** Marking discovery Done,
appending the audit entry, writing the memory entry, and printing the
final summary all belong to the finalize phase ([the finalize reference](references/finalize.md)), which runs **after** the optional
AS-IS BPMN step so completion fires exactly once, last, and the final summary can include the
BPMN output.

## Format Specs (used by subagents)

Subagents read the relevant spec section below and follow it exactly.

**Output size budgets (hard caps).** Each writer must stay within its budget. If your draft would exceed the cap, cut lower-confidence claims or merge sourced items — do not emit a longer file. Unbounded emission causes a single writer to dominate the wall-time of the whole step.

| File | Max lines |
|------|-----------|
| `as-is-process.md` | 350 |
| `gap-analysis.md` | 200 |
| `00-index.md` | 80 |
| `participants-and-systems.md` | 200 |
| `data-objects.md` | 250 |
| `process-NN-[phase].md` | 200 per file |
| `subprocess-[name].md` | 200 per file |
| `edge-NN-[name].md` | 150 per file |
| `provenance.md` | 250 |

### Spec: as-is-process.md

```markdown
# [Process Name] — As-Is Process
*Generated by /process-os-process-discovery on [date]. Discovery: [N] research rounds, [N] specialists.*

## Questions for Reviewers
*(Include this section only when system or business object gaps exist — paste from doc-context.md. Omit entirely if none.)*

---

## Overview
[2-3 sentences: business goal, who runs it, what it produces, which systems it touches]

**Scope boundary:** *(from doc-context.md Scope Boundary)*
- **Start trigger:** [the business event that starts the process] *(source: [X])*
- **Done when:** [the business condition that means "finished", in business terms] *(source: [X])*
- **Out of scope:** [activities, variants, or systems explicitly excluded — or `[GAP]`]

## Process Phases
### Phase N: [Name]
**Trigger:** [what starts this phase] *(source: [X])*
**Actor:** [who does it] *(source: [X])*
**Steps:**
1. [step] *(source: [X])*
**Output:** [what this phase produces] *(source: [X])*
**Systems:** [which systems] *(source: [X])*
**Duration:** [typical time, if known] *(source: [X])*
**Known issues:** [gaps, workarounds, errors]

## Performance Baseline
Quantitative baseline for the end-to-end process. Label every metric's **basis** — `measured` (system data / multi-source), `estimated` (single-source or inferred), or `[GAP]` (unknown → raise as a reviewer question). This mirrors the sourcing discipline: `measured` ≈ confirmed, `estimated` ≈ *(single source)* / *(inferred)*.

| Metric | Value | Basis | Source |
|--------|-------|-------|--------|
| End-to-end cycle time | [value + unit] | measured / estimated / [GAP] | [X] |
| Processing vs waiting time | [split] | measured / estimated / [GAP] | [X] |
| Throughput / volume (incl. peak) | [value + unit] | measured / estimated / [GAP] | [X] |
| Error / rework rate | [value] | measured / estimated / [GAP] | [X] |
| Manual vs automated effort | [split] | measured / estimated / [GAP] | [X] |

## Cross-cutting Concerns
[data sync, error handling, notifications, reporting]

## Open Questions
[things that could not be verified from available data]

## Sources
[list of all data sources used: specialists, research rounds, human gates]
```

### Spec: gap-analysis.md

Order gaps by **business impact** (highest first); tie-break by severity. The Executive Summary's top-3 follows that same ranking.

```markdown
# [Process Name] — Gap Analysis
*Generated by /process-os-process-discovery on [date].*

## Executive Summary
[2-3 sentences: overall process health, top 3 gaps ranked by business impact]

## Gaps

### Gap N: [Title]
**Category:** Bottleneck / waiting time · Manual-effort hotspot · Handover / ownership gap · Compliance risk · Scalability ceiling · System limitation · Data / discovery gap
**Severity:** High / Medium / Low
**Business impact:** High / Medium / Low — [what it costs the business: delay, cost, risk, lost volume]
**Phase:** [which process phase]
**Description:** [what is missing or broken]
**Evidence:** [which specialist, which research round, what data showed this]
**Surfaced:** Round [N] by [specialist]
**Recommendation:** [what should be done]
```

### Spec: 00-index.md

```markdown
# Process Discovery Index: [Process Name]

## Architecture Decision
[Why flat vs. hierarchical. How many phase files. Which edge cases get standalone files.
 If hierarchical, name the called subprocess documents and their parent phases.
 If `decomposition: single` is configured, state "flat — single phase file (decomposition: single)" and skip the flat-vs-hierarchical reasoning.
 Always note the active config flags: `decomposition: <value>` and `edge-cases: <value>`.
 Under `edge-cases: skip` or `decomposition: single`, note that variants and exceptions are inlined in the phase file(s) rather than split into edge files.]

## Reading Order
1. participants-and-systems.md
2. data-objects.md
3. process-NN-[phase].md — in phase order
4. subprocess-[name].md — called child processes
5. edge-NN.md — variants and exceptions

## File Map
[table: file → what it covers]

## Discovery Metadata
- Research rounds: [N]
- Specialists: [list]
- Final coverage: [per-area summary]
- Human gates: [N] conducted
```

### Spec: participants-and-systems.md

All actors, roles, systems, integration points.

#### Actors & Ownership

For each human actor/role in the process, capture what they do and their responsibility level. Identify the single **Process Owner** — the role accountable for the end-to-end outcome — explicitly. If no source names one, write `[GAP: process owner unnamed]` and raise it as a reviewer question rather than guessing.

```
**[Role name]** — [what they do in the process]
- **Responsibility:** Owner / Accountable / Consulted / Informed / Performer
- **Decisions / handovers owned:** [key decision points or handovers this role controls]
*(source: [X])*
```

#### Systems

Every named system must be assigned a **business function category**. Use standard labels where they apply; add a custom label when none fits:

| Category | Examples |
|----------|---------|
| CRM | Salesforce, HubSpot, Microsoft Dynamics |
| ERP | SAP, Oracle EBS, Microsoft Dynamics 365 FO |
| BPM / Workflow | Camunda, ServiceNow, Appian |
| Workload Automation | Control-M, AutoSys, Apache Airflow |
| ITSM | ServiceNow, Jira Service Management, BMC Helix ITSM |
| HCM | Workday, SAP SuccessFactors |
| SCM | SAP SCM, Oracle SCM |
| WMS | SAP EWM, Manhattan |
| MDM | Informatica MDM, SAP MDG |
| DMS / ECM | SharePoint, OpenText, Documentum |
| BI / Analytics | Tableau, Power BI, SAP BW |
| ESB / Integration | MuleSoft, Dell Boomi, Azure Integration Services |
| Messaging | Kafka, RabbitMQ, Azure Service Bus |
| Identity / IAM | Active Directory, Okta, Keycloak |
| Custom / Internal | Internal-built system with no standard category |

Format each system entry as:

```
**[System Name]** — [Business Function Category]
[One-sentence description of what it does in this process]
Integration points: [APIs, file transfers, DB connections, etc.]
```

If a system's business function cannot be determined from available data, mark it `[GAP: business function unknown]` rather than omitting the field.

### Spec: data-objects.md

Key data objects, their states, transitions, and which systems own them.

**De-duplication:** before writing, collect every business object name mentioned across all specialist findings and coverage reports. Group names that refer to the same real-world concept. Produce one canonical entry per unique object. Discard duplicates; do not create separate entries for aliases.

Use this structure for each object:

```markdown
## [Canonical Object Name]

**Business explanation:** [One paragraph: what this object represents in business terms, why it exists, what business event creates it, and what happens to it over its lifecycle. No technical jargon.]

**Also known as:** [comma-separated list of all aliases found across findings]
*(If only one name was found, omit this field.)*

**Systems:** [table of every business system where this object exists]

| System | Business Function | Role | Notes |
|--------|------------------|------|-------|
| [System name] | [CRM / ERP / …] | Owner / Consumer / Reference | [e.g. "master record"] |

**States / lifecycle:** [ordered list of states this object moves through]

**Key fields:** [bullet list of the most business-relevant fields]

**Data gaps:** [anything unknown — mark as `[GAP]`]
```

After all objects, append:

```markdown
## Glossary — Commonly Used Terms

| Term | Canonical Object | Definition |
|------|-----------------|-----------|
| [alias or term] | [canonical object name] | [one-sentence definition] |
```

Include every alias and abbreviation from "Also known as" fields plus domain-specific terms. Sort alphabetically.

### Spec: process-NN-[phase].md

BPMN-ready description for one process phase. Include: start trigger, tasks with type tags ([UserTask]/[ServiceTask]/[ManualTask]), gateways with conditions, error paths, variables set and consumed.

Structure:

```markdown
# Phase N: [Phase Name]
*Part of: [Process Name] — process-discovery*

## Overview
[2-3 sentences describing this phase's purpose, primary actor, and systems involved]

## BPMN-Ready Description

### [Gateway/Task identifier]: [Name] [[TaskType]]
- **Type:** [UserTask / ServiceTask / ManualTask]
- **Actor / System:** [who or what executes this]
- **Inputs:** [variables consumed]
- **Outputs:** [variables set]
- [Other relevant details]
*(source: [X])*

[Continue for each element in phase order]

### Phase N End
- **Output:** [what this phase produces for the next phase]
- **Systems:** [systems touched in this phase]

## Error Paths
| Error | Handling |
|-------|----------|
| [error condition] | [how it is handled] |

## Known Issues / Gaps
- [Gap N]: [description] *(source: [X])*
```

### Spec: subprocess-[name].md

BPMN-ready description for one independently callable child process. It becomes its own BPMN
resource and is invoked by the parent phase(s) named in the Subprocess List — it is not an
embedded subprocess.

```markdown
# Subprocess: [Child Process Title]
*Part of: [Process Name] — process-discovery*

**Process ID:** `subprocess-[name]`
**Called by:** process-NN-[parent][, process-NN-[other-parent]]

## Overview
[1-2 sentences: the reusable child capability and when each parent invokes it]

## BPMN-Ready Description

### [Task identifier]: [Name] [[TaskType]]
- **Type:** [UserTask / ServiceTask / ManualTask]
- **Actor / System:** [who or what executes this]
- **Inputs:** [variables consumed]
- **Outputs:** [variables set]
- [Other relevant details]
*(source: [X])*

[Continue for each element in child-process order]

### Subprocess End
- **Output:** [result returned to each parent]
- **Systems:** [systems touched]

## Error Paths
| Error | Handling |
|-------|----------|
| [error condition] | [how the child handles or returns it] |

## Known Issues / Gaps
- [Gap N]: [description] *(source: [X])*
```

### Spec: edge-NN.md

For a variant or exception flow warranting its own file. Same structure as a phase file but focused on the exception path: what triggers the divergence from the main flow, the exception-specific steps, and how/whether it rejoins the main flow.

### Spec: provenance.md

Drop the `Organization: [org]` segment when the scope supplied no organization — a bare label asserts a value of nothing, which a reader cannot tell from a fact.

```markdown
# Discovery Provenance

## Session
Process: [name] | Organization: [org] | Dates: [start – end] | Research rounds: [N]

## All Queries Run
[table: research round, specialist, query, results count, used count]

## All Hypotheses
[table: ID, hypothesis, research round formed, final status, evidence]

## Human Gate Responses
### Gate N (Round N — [date])
Questions asked: [N]
Key answers:
- [Q]: [A]

## Coverage Progression
| Round | Area | Confidence |
|-----------|------|-----------|
```
