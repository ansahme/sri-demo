# Phase 0: Bootstrap

You are running the bootstrap phase of process discovery. This phase builds the initial knowledge base that all specialists will use.

## Step 1: Classify the run

Decide fresh start vs. resume vs. new iteration from the **iteration directory resolver**, not
from `.camunda/state.md` or the presence of any generated file. This step only classifies — it
opens nothing.

```bash
node ".github/skills/process-os-process-discovery/scripts/iteration-dir.cjs" current process-discovery --json
```

Check in this order:
- **Exit `3`** — nothing has run yet: this is a fresh start, research round 1. Continue to Step 2.
- **`inProgress: true` and `data/bootstrap.md` exists** — an iteration is in flight and its Steps
  2–4 output survives from the prior pass. Note the current research round from
  `data/bootstrap.md`. Skip directly to Step 5 to update gap instructions and hypotheses from the
  latest coverage report (`data/coverage-round*.md`). Then continue to Steps 6–7.
- **`inProgress: true` and `data/bootstrap.md` absent** — an iteration is in flight, but its
  working state is gone (a fresh clone, a `git clean -x`, or an interruption between `open` and
  Step 5). `data/bootstrap.md` *is* the Steps 2–4 output, so its absence means those steps never
  landed: run Steps 2–7 in full inside this same iteration.
- **`inProgress: false`** — the highest iteration finished. This is a **new** iteration, gated
  below before anything is created and seeded from it. Its first research round is
  `data/progress.json`'s `round` **plus one** (`1` when no record exists), and
  `iterationStartRound` is set to that same number. The count runs on rather than restarting:
  `data/` is the project-root directory holding this run's evidence as a whole, so reusing or
  resetting the number would overwrite the previous iteration's `data/*-round<N>.md` and
  `data/coverage-round<N>.md`.

## Step 2: Load Configuration

Read `process-scope.md` if it exists. Extract:
- `process-name` → processName
- `process-description` → processDescription

A header line the scope never supplied is absent rather than empty: treat a missing
`process-description:` as "no description", never as an empty description.

`run.config.yaml` must exist before it can be read — a from-scratch discovery run (no prior
`/process-os-project-initialization`) will not have created it yet, and `read-run-config.cjs`
hard-errors on a missing file rather than defaulting. Check for it,
and create it with schema defaults if absent, via the generator:

```bash
node ".github/skills/process-os-process-discovery/scripts/path-exists.cjs" run.config.yaml
```

If it reports `NOT FOUND`, materialize it at schema defaults:

```bash
node ".github/skills/process-os-process-discovery/scripts/run-config-build.cjs"
```

This writes every key at its schema default. `process-scope.md` is untouched either way —
the paragraph below still owns creating it. A non-zero exit here shares the same
`DEPS_MISSING` cause as the reads below — report it and stop.

Read the technical settings from `run.config.yaml`. Each read prints the configured value,
or the schema default when the key is absent — there is no need for a fallback of your own:

```bash
node ".github/skills/process-os-process-discovery/scripts/read-run-config.cjs" specialists
node ".github/skills/process-os-process-discovery/scripts/read-run-config.cjs" max-research-rounds
node ".github/skills/process-os-process-discovery/scripts/read-run-config.cjs" source-mode
```

`specialists` prints one name per line. `max-research-rounds` defaults to `5`, `source-mode` to
`hint` (the other valid value is `allowlist`). An exit of 2 means `run.config.yaml` is
missing or unreadable, or the project's Node deps are not installed — report it and stop.

Also extract every entry from the `## Data sources` (or `## Filesystem specialist hints`)
section of `process-scope.md`. Categorize each entry:
- starts with `https://github.com/` or `http://github.com/` → **github**
- starts with `http://` or `https://` (any other host) → **web**
- everything else (relative paths, absolute paths, glob patterns) → **filesystem**

Persist counts in the bootstrap output as `Source mode: <mode> (filesystem: N, web: N, github: N)`. Specialists read this line so they don't have to re-categorize.

If `process-scope.md` does not exist, ask the user:
1. "What is the process name?"
2. "Describe the process in 1-2 sentences."
Then write a minimal `process-scope.md` with the answers: a `# Process Scope` heading, a
`process-name:` line, and a `process-description:` line **only if question 2 was answered** —
an unanswered one leaves no line rather than a bare label. Technical settings are not written
here — an absent `run.config.yaml` key already resolves to its schema default.

### Confirm and open the iteration

`run.config.yaml` is now guaranteed to exist, which is why this gate lives here and not in
Step 1 — Step 1 classifies before that is assured, and `read-run-config.cjs` hard-errors on a
missing file.

If Step 1 classified this run as a **new iteration** (`inProgress: false`), confirm before
creating anything — re-running the whole pipeline is expensive:

```bash
node ".github/skills/process-os-process-discovery/scripts/read-run-config.cjs" mode
```

Exit 2 → hard error: report stderr and stop; it means the reader failed, not that the key is unset.

- `unattended` → proceed silently.
- `interactive` (default) → ask "Start iteration `<N+1>`? [Y/n]" (`<N+1>` is the next iteration
  number). `n` → stop here; nothing has been created.

On the other two Step 1 classifications (fresh start, or an iteration already in flight), there is
nothing to confirm — continue directly.

Then, on every classification, make the single call that resolves the iteration to write into —
creating it if this is a fresh start or a confirmed new iteration, or returning the existing
in-flight one unchanged otherwise — seeded from the previous iteration's `artifacts/` whenever one
exists:

```bash
node ".github/skills/process-os-process-discovery/scripts/iteration-dir.cjs" open process-discovery --seed --json
```

- **Exit `6`** (`NO_SEED_SOURCE`) — there is no previous iteration to seed from: this **is** the
  first iteration. Re-run the identical call without `--seed`, which creates it:
  ```bash
  node ".github/skills/process-os-process-discovery/scripts/iteration-dir.cjs" open process-discovery --json
  ```
- **Exit `0`** — `<ITERATION_DIR>` exists, its `artifacts/` seeded from the previous iteration's
  whenever this call created it. On a resume (the highest iteration was already `inProgress`),
  `--seed` is a no-op — the in-flight iteration keeps whatever copy it already has rather than
  taking a second one over work already in progress.

Capture `dir` as `<ITERATION_DIR>`, `artifacts` as `<ARTIFACTS_DIR>`, and `iteration` as `<N>`.
Step 5 below persists `<ARTIFACTS_DIR>` into `data/bootstrap.md`, so every later phase reads it
from there rather than re-resolving it. `SKILL.md`'s next step states the run using `<N>` (and
`<N> - 1` as the seed source whenever `<N> > 1`) before any further work happens.

## Step 3: Detect Active Specialists

The `specialists` list read above decides which specialists may run. It is the **whole**
whitelist, not a set of extras added to a fixed core: a name the list does not carry is
inactive and is never dispatched, however much that specialist could have contributed. Its
absence is the operator's decision, so it is not recorded as a data gap.

An unset key resolves to the schema default — `web`, `filesystem`, `github` — so a project that
never configured the key still gets all three. A project that narrowed the list gets
exactly what it asked for, which is the point of narrowing it.

For each name the list **does** carry, availability still has to be established:

- `web`, `filesystem` — no external dependency; active whenever listed.
- `github` — run `gh auth status` via Bash. Active if exit code 0; otherwise inactive with reason
  "gh not authenticated".
- `enterprise` — active only if an enterprise-search tool / MCP (e.g. Glean, Confluence,
  SharePoint, internal wiki) is reachable. If none is available, mark inactive with reason "no
  enterprise-search tool"; the specialist body degrades to a one-line no-sources findings file if
  dispatched anyway.
- any other name — attempt `Skill("<specialist-name>")`. Success → active; failure or error →
  inactive, noted as a data gap, since a configured specialist that cannot load is a real loss.

Write the active specialist list to memory for use in Phase 1.

### Plugin specialists

Load every specialist from every installed plugin via `list-active-plugins.cjs`:

```bash
node ".github/skills/process-os-process-discovery/scripts/list-active-plugins.cjs" | node ".github/skills/process-os-process-discovery/scripts/strip-bom.cjs" | node -e "
const o = JSON.parse(require('fs').readFileSync(0,'utf8'));
const out = [];
for (const p of o.plugins) {
  if (!p.installed) continue;
  for (const s of p.specialists) {
    out.push({
      qualified: p.name + ':' + s.name,
      plugin: p.name,
      name: s.name,
      path: s.path,
      model: s.model,
      env: s.env,
    });
  }
}
for (const e of o.errors || []) {
  if (e.plugin) console.error('- Plugin ' + e.plugin + ' reported: ' + e.kind + ' — ' + e.message);
}
process.stdout.write(JSON.stringify(out, null, 2));
" > data/plugin-specialists.json
```

Each entry in `data/plugin-specialists.json` is a plugin specialist that Phase 1 will dispatch alongside the built-ins. Use the `qualified` name (`<plugin>:<specialist>`) in the active specialist list to disambiguate from built-ins (which have unqualified names like `web`, `filesystem`).

Installing the plugin is what opts these in: they are **not** filtered against `specialists`, whose default names only the built-ins and so would exclude every plugin specialist. Narrowing `specialists` therefore constrains the built-ins without disabling an installed plugin's specialists; removing those means uninstalling the plugin.

Plugin-scoped entries from the script's `errors` array are printed to stderr in that same step, one per line — surface each in the bootstrap output as a data-gap note, verbatim (`"- Plugin <name> reported: <kind> — <message>"`). Do not block bootstrap on plugin errors.

## Step 4: Bootstrap Process Knowledge

If research round 1:
- Use web search (if available) to find public information about the process and named systems
- Look for: typical phases, common actors, well-known systems used for this type of process
- If `glean` or similar internal search skill is active, search for the process name internally

If research round 2+:
- Read the previous `data/coverage-round<N>.md` (highest N)
- Extract gap instructions and open hypotheses

## Step 5: Write `data/bootstrap.md`

On research round 2+: read the existing `data/bootstrap.md` first. Preserve the `Artifacts dir`,
`Known Phases`, `Known Actors`, and `Known Systems` fields/sections from the prior round. Only
update `Research round:`, `Active specialists:`, `Gap Instructions`, and `Open Hypotheses`.

Drop the `- **Description:**` line entirely when `processDescription` has no value — a bare label asserts a value of nothing, which a reader cannot tell from a fact.

```markdown
# Process Bootstrap: [processName]
- **Process:** [processName]
- **Description:** [processDescription]
- **Artifacts dir:** [ARTIFACTS_DIR]
- **Research round:** [N]
- **Max research rounds:** [maxResearchRounds]
- **Active specialists:** [comma-separated list of built-ins + qualified plugin specialists, e.g. `web, filesystem, acme:sap`]
- **Inactive specialists:** [list and reason]
- **Source mode:** [hint | allowlist] (filesystem: N, web: N, github: N)

## Known Phases
[bullet list — from config, web search, or prior coverage]

## Known Actors
[bullet list]

## Known Systems
[bullet list]

## Gap Instructions (Round N)
[empty on round 1]
[on round 2+: specific gaps from coverage-round(N-1).md, formatted as: "- [specialist]: investigate [specific gap]"]

## Open Hypotheses (from round N-1)
[empty on round 1]
[on round 2+: copy hypothesis list from coverage-round(N-1).md]
```

## Step 6: Initialize progress.json

Write `data/progress.json` with:
- phase: "bootstrap"
- round: N
- iterationStartRound: N when this run opened a new iteration; the value already in
  `data/progress.json` when it resumed one still in flight. `maxRounds` is a per-iteration
  budget and `round` keeps running across iterations, so this is what
  `scripts/check-coverage-gate.cjs` counts the budget from — set it wrong and a later iteration
  either loses its rounds or never stops
- maxRounds from config
- specialists array with all active specialists at status "pending", progress 0
- stats all zeros
- coverage: empty array (will populate after first analysis)

See [the progress-record reference](references/progress.md) for the full schema and validity rules.

Note: After bootstrap.md completes, the orchestrator updates `data/progress.json` phase to `"gathering"` before Phase 1. See the orchestrator instructions.

## Step 7: Update state.md

Update `.camunda/state.md`: set process-os-process-discovery phase to `🔄 In Progress`.
