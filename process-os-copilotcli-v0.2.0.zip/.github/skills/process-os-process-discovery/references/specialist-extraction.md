# Specialist rule: extraction

This block is appended to every specialist's prompt — built-in and plugin alike — so each one
applies the same extraction rule without carrying its own copy.

## Extraction

Record what the sources literally show: existing steps, branches, systems, forms, rules, and the
order and structure they appear in. Report a step whose logic is not visible anywhere as a `[GAP]`.

A hypothesis — something probably true that no source confirms — is a research lead, not a
finding. Write it only under `## Hypotheses`, never in `## Findings`, and phrase it as something to
verify. Do not propose alternate paths or improvements as findings.
