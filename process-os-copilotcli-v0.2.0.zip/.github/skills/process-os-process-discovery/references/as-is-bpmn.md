# Sub-Skill: Generate Annotated AS-IS BPMN

You produce the renderable AS-IS BPMN for a completed discovery session. This sub-skill runs inline inside the orchestrator's session, after `<ARTIFACTS_DIR>/00-index.md` and the per-phase process files have been written. `<ARTIFACTS_DIR>` throughout this file is `data/bootstrap.md`'s `- **Artifacts dir:**` line — resolved once by `bootstrap.md` Step 2; reuse that value rather than re-resolving it.

**Two stages, in order:**

1. **Generate the base BPMN by invoking `/process-os-bpmn-generation`** — do not hand-author BPMN XML here. `process-os-bpmn-generation` owns element mapping, the XML skeleton, and deterministic layout. See *Stage 1*.
2. **Overlay discovery uncertainty metadata** — tag every uncertain element and emit the question-binding side-files the review screen consumes. `process-os-bpmn-generation` does not produce these. See *Stage 2*.

The result is a documentation-grade (`isExecutable="false"`) BPMN set an SME can review visually and answer questions against.

## What to Read

Before generating, read all of these:

1. `<ARTIFACTS_DIR>/00-index.md` — phase ordering and architecture decision (flat vs hierarchical)
2. `<ARTIFACTS_DIR>/process-NN-*.md` files — every per-phase process file in order
3. `<ARTIFACTS_DIR>/edge-NN.md` files (if any) — variant flows
4. `<ARTIFACTS_DIR>/participants-and-systems.md` — actors and systems
5. All `data/coverage-round*.md` files — for confidence scores and open hypotheses
6. `<ARTIFACTS_DIR>/gap-analysis.md` — for severity-ranked gaps
7. `<ARTIFACTS_DIR>/review-questions.yaml` — the questions store, whose `q<N>` ids Stage 2 binds `question-targets.json` to (already written by `document.md`)

The per-phase `process-NN-*.md` docs are also the **input to `process-os-bpmn-generation`** in Stage 1 — you read them here to map uncertainty back onto the generated elements in Stage 2.

## Stage 1 — Generate the base BPMN via `/process-os-bpmn-generation`

Invoke the `process-os-bpmn-generation` skill explicitly. Do not build BPMN XML by hand — element
mapping, the XML skeleton, and deterministic layout all live in `process-os-bpmn-generation`.

Invocation:

```
/process-os-bpmn-generation --input <ARTIFACTS_DIR> --output <ARTIFACTS_DIR> --bpmn-mode strategic --embedded --no-snapshot

Run unattended — no questions, just generate.
```

- `--input <ARTIFACTS_DIR>` — `process-os-bpmn-generation` reads the `process-NN-*.md` / `edge-*.md` /
  `subprocess-*.md` phase docs. Its inclusion allowlist ignores the discovery metadata docs
  (`00-index.md`, `gap-analysis.md`, `participants-and-systems.md`, `annotations.md`, …), so no
  extra BPMNs are emitted for them. The questions store is a `.yaml`, so it is outside that
  allowlist by extension.
- `--output <ARTIFACTS_DIR>` — the BPMN lands alongside the discovery docs. `process-os-bpmn-generation`
  writes `process-NN-*.bpmn` (one per phase), `00-overview.bpmn` (the master overview), and
  `PROCESSES.md`.
- `--bpmn-mode strategic` — documentation-grade output: `isExecutable="false"`, no Zeebe
  extensions or connectors, except that a call activity keeps its `zeebe:calledElement` link.
  No width or depth is passed, so every documented step becomes its own element — unless the
  project sets a non-`auto` `size`, `width` or `depth` in `run.config.yaml`. That is an explicit
  size, and `process-os-bpmn-generation` honours it: an explicit S or M may fold steps, and an
  explicit depth S combines phases and abstracts subprocesses. It is how a project asks for a
  deliberately small diagram.
- The **Run unattended** line auto-resolves `process-os-bpmn-generation`'s size-confirmation GATE so the
  discovery flow is not blocked on an interactive prompt.
- `--embedded` — this is a sub-invocation inside discovery Phase 3a, so `process-os-bpmn-generation` must NOT
  write the shared provenance records: it skips its `process-os-bpmn-generation` audit line and its
  `## BPMN Decisions` memory entry. Discovery's Phase 4 (`finalize.md`) owns that bookkeeping.
  (`process-os-bpmn-generation` owns no `.camunda/state.md` lifecycle row on any path — it is an internal
  engine — so this flag only prevents duplicate audit/memory entries.)
- `--no-snapshot` — `<ARTIFACTS_DIR>` lives under the current iteration directory, whose parent
  phase directory is never allowed a `.snapshots/` subtree; the iteration directory is discovery's
  version history instead.

`decomposition` no longer branches here — `document.md` already emitted the phase docs in the
chosen shape (`single` → one `process-01-asis.md`; `per-phase` → one file per phase), and
`process-os-bpmn-generation` derives structure from whatever phase docs exist.

After `process-os-bpmn-generation` returns, list the element ids it assigned — Stage 2 binds
questions to those ids. Extract them; do not Read the `.bpmn` files:

```bash
node ".github/skills/process-os-process-discovery/scripts/bpmn-extract.cjs" <ARTIFACTS_DIR> --names
```

Exit `2` → bad input (missing path, no `.bpmn` files, a dangling `--exclude`, or a malformed `--max-bytes`) — report stderr and stop.
Exit `3` means the report is over the cap — re-run it one file at a time.

## Stage 2 — Overlay discovery uncertainty metadata

The generated BPMN stays clean. **Do NOT emit `<bpmn:textAnnotation>` or `<bpmn:association>` elements.** Severity + question linkage live in `<bpmn:documentation>` plus two side files.

Your job here is the **judgment**: which element is uncertain, at what severity, bound to which question. You write that down once, in `<ARTIFACTS_DIR>/question-targets.json`. A script then materializes it — **never hand-edit the `.bpmn` and never hand-write `annotations.md`.**

1. **Write `<ARTIFACTS_DIR>/question-targets.json`** — the contract the UI uses to bind question cards to elements, and the injector's input. Schema:

   ```json
   [
     {
       "id": "q3",
       "severity": "OPEN",
       "summary": "Who approves invoices when the manager is out of office?",
       "targets": {
         "bpmn": ["task_managerApproval"],
         "form": []
       }
     }
   ]
   ```

   - One entry per question (`q1`, `q2`, …) matching the `id` values already written in `<ARTIFACTS_DIR>/review-questions.yaml` (produced by `document.md` before this step). Bind to those existing ids — do not renumber.
   - `targets.bpmn` lists the element ids the question relates to. Multiple ids allowed (e.g. a gateway + the task it guards), and two questions may name the same element — bind whatever the review needs. A `<bpmn:documentation>` child holds one tag, so an element named by several questions is tagged with the lowest-numbered one and the injector reports the rest; the UI still binds every card from `question-targets.json`.
   - `targets.form` is empty for as-is review; populated only by the process-os-artifact-generation forms review.
   - Write this file via the `Write` tool. Use `JSON.stringify(targets, null, 2)`.

   `severity` values, identical to the questionnaire's enum:

   | Severity | Use when |
   |----------|----------|
   | `OPEN` | The fact is unknown — appears as `[GAP]` in a process file, or no specialist found data |
   | `RISK` | A claim is marked `*(single source)*` for a load-bearing fact (gateway condition, actor, integration) |
   | `CONFIRM` | A claim is marked `*(inferred — not verified)*` — likely correct but unvalidated |
   | `CONFLICT` | Two specialists contradict each other on this fact |

   The UI reads `question-targets.json` and renders the bidirectional highlight: hover a question card → element flashes; click an element → scrolls to the matching question.

2. **Run the injector** — it writes the `<bpmn:documentation>` tags into every `<ARTIFACTS_DIR>/*.bpmn` and emits `<ARTIFACTS_DIR>/annotations.md`:

   ```bash
   node ".github/skills/process-os-process-discovery/scripts/bpmn-question-tags.cjs" --dir <ARTIFACTS_DIR>
   ```

   Each tagged element gets read-only metadata, invisible in viewers:

   ```xml
   <bpmn:userTask id="task_managerApproval" name="Approve invoice">
     <bpmn:documentation>[OPEN] (q3)</bpmn:documentation>
   </bpmn:userTask>
   ```

   Exit `0` means every target landed. Exit `1` prints the failures on stderr — fix the cause and re-run (the script is idempotent):

   - `unresolved: no taggable element "<id>"` — the id is wrong. Re-extract the element ids with the `bpmn-extract.cjs --names` command above and correct `targets.bpmn`; never add the element by hand, and never Read the `.bpmn` to look the id up.
   - `conflict: <id> already documents prose` — that element's `<bpmn:documentation>` holds real content, so the tag was **not** written. Bind the question to a different element.

   A `shared:` line on stdout is not a failure: it names an element several questions point at, and which one won the tag.

   Exit `2` means `question-targets.json` is invalid (bad severity, non-`qN` id, malformed JSON) — the message names the offending entry.

**The tags live in the `.bpmn`, so regeneration drops them.** Any later re-run of a
`<file>.bpmn.gen.mjs` — including `process-os-bpmn-generation --target/--from` in the feedback
cycle's Regen phase — rewrites the file from the generator, which knows nothing about the tags.
Re-run the injector command above afterwards; it is idempotent and restores whatever severity
`question-targets.json` currently holds (including `RESOLVED` for answered questions).

## Where the files land

Stage 1 wrote the BPMN into `<ARTIFACTS_DIR>` via `process-os-bpmn-generation`:

- `<ARTIFACTS_DIR>/00-overview.bpmn` — master overview (main phases)
- `<ARTIFACTS_DIR>/process-NN-<phase>.bpmn` — one per phase doc
- `<ARTIFACTS_DIR>/PROCESSES.md` — human-readable companion

`process-os-bpmn-generation` already validated and laid out every file (bpmnkit layout + bpmnlint). Do
not re-run a separate layout pass — Stage 2 only adds `<bpmn:documentation>` metadata, which
does not affect geometry.

The injector also emits `<ARTIFACTS_DIR>/annotations.md` — the index of every tagged element, sorted by question number. It is generated output: do not write or edit it by hand. `process-os-review-answer-application` re-emits it from the same code once answers land.

## Output

After Stage 2 completes, append to the discovery summary that Phase 4 (`finalize.md`) prints at the end:

```
AS-IS BPMN written (via /process-os-bpmn-generation --bpmn-mode strategic):
  <ARTIFACTS_DIR>/00-overview.bpmn        — master overview (canonical entry point)
  <ARTIFACTS_DIR>/process-NN-<phase>.bpmn — per-phase diagrams
  <ARTIFACTS_DIR>/question-targets.json   — question → element bindings ([N] open questions)
  <ARTIFACTS_DIR>/annotations.md          — annotation index
```

When `process-os-bpmn-generation` combines the phases into one `<ARTIFACTS_DIR>/process-main.bpmn`
instead of the overview + per-phase set above, report that filename in their place. List the
files the generation actually wrote, not the ones this template names.
