# Sub-Skill: Generate Discovery Review Questions

You are generating a structured review question file from completed discovery output. This sub-skill runs inline inside the orchestrator's session, after all documentation files have been written — `document.md` has already resolved `<ARTIFACTS_DIR>` from `data/bootstrap.md`; reuse that value rather than re-resolving it.


**An existing store's answered questions survive.** An iteration seeded from a completed one
carries that store forward, and the fold-in step has already written this cycle's answers into it.
Read `<ARTIFACTS_DIR>/review-questions.yaml` before writing: carry every question that still
applies across with its `answer` and `status` intact, drop only those this iteration's findings
have made moot, and add the new ones as `answer: ""` / `status: open`. Writing the store fresh
re-asks what a reviewer has already answered, which reads to them as the answer having been lost.

## What to Read

Read the following files before generating any questions. Do not skip any category — each covers a different signal type.

**Coverage files** — read all `data/coverage-round*.md` files (all research rounds):
- Look for: any process area with confidence < 70%
- Look for: hypotheses with status `open` or `contradiction`
- Look for: "Recommended Gap Instructions" that were never resolved

**Process files** — read all `<ARTIFACTS_DIR>/process-NN-*.md` files:
- Look for: lines marked `[GAP]`
- Look for: claims marked `*(single source)*`
- Look for: claims marked `*(inferred — not verified)*`

**Participants and systems** — read `<ARTIFACTS_DIR>/participants-and-systems.md`:
- Look for: systems listed without a confirmed API or integration source
- Look for: actors whose role is described as unknown or inferred

**All specialist findings** — read all `data/*-round*.md` files (all specialists, all research rounds):
- Look for: contradictions where specialist A states X and specialist B states not-X
- Look for: findings flagged as hypotheses that were never confirmed or refuted
- Look for: "Gaps & Failed Attempts" sections — queries that returned no results across multiple research rounds

**Known phases** — read `data/bootstrap.md`'s `## Known Phases` list:
- Look for: which phases are most central to the process outcome, to pick Section 5's case-anchored
  questions (see [Section 5](#section-5-real-world-exception-handling) below)

## What to Write

Write `<ARTIFACTS_DIR>/review-questions.yaml` using the `Write` tool. This YAML document is the
**questions store** — the source of truth for this phase's questions. Markdown, spreadsheet and
Camunda Form views of it are projections, generated on request by their own skills; do **not** write
any of them here.

Use this exact format:

```yaml
schema: 1
kind: review
process: [Process Name]
generated: [YYYY-MM-DD]
sections:
  - title: "Section 1: Unclear Process Steps"
    questions:
      - id: q1
        text: |-
          [question text]
        confidence: |-
          Low — [reason: which source, which research round, why uncertain]
        impact: |-
          High | Medium | Low — [what breaks or degrades if this stays unanswered]
        proposed: |-
          [a one-line best-inference answer based on the discovery data above]
        answer: ""
        status: open
  - title: "Section 2: Missing System Information"
    questions:
      - id: qN
        text: |-
          [question text]
        confidence: |-
          Low — [reason: system name, which specialist noted it, what is missing]
        impact: |-
          High | Medium | Low — [what cannot be modeled or automated without this]
        proposed: |-
          [a one-line best-inference answer based on the discovery data above]
        answer: ""
        status: open
  - title: "Section 3: Contradictions"
    questions:
      - id: qN
        text: |-
          [question text]
        confidence: |-
          Low — [source A says X (specialist-roundN); source B says Y (specialist-roundN)]
        impact: |-
          High | Medium | Low — [which downstream output is affected by the contradiction]
        proposed: |-
          [a one-line best-inference answer based on the discovery data above]
        answer: ""
        status: open
  - title: "Section 4: Coverage Gaps"
    questions:
      - id: qN
        text: |-
          [question text]
        confidence: |-
          Low — [area name, confidence score, which research round, why it stayed low]
        impact: |-
          High | Medium | Low — [which part of the process model is incomplete without this]
        proposed: |-
          [a one-line best-inference answer based on the discovery data above]
        answer: ""
        status: open
  - title: "Section 5: Real-World Exception Handling"
    questions:
      - id: qN
        text: |-
          [a case-anchored question — see the rule below]
        impact: |-
          High | Medium | Low — [what breaks or degrades if this stays unanswered]
        answer: ""
        status: open
```

Replace `[Process Name]` with the process name from `data/bootstrap.md`. Replace `[YYYY-MM-DD]` with
today's date.

**Format rules that are not style preferences** — each closes a real defect, so follow them exactly:

- **Every QUESTION-level prose value is a literal block scalar (`|-`)**, including a single-line
  one — `text`, `confidence`, `impact`, `proposed`, `answer`, `updated`. A bare
  YAML scalar is *typed*: an answer of `no` reads back as boolean `false` to a YAML 1.1 parser, and
  `1.0`, `08` and `12:30` come back as numbers. A literal block is a string whatever it contains.
  The document-level `process` and `generated` are single-line labels rather than prose, so they
  stay plain scalars — as the template above shows.
- **`answer: ""` for an unanswered question**, and `status: open`. An empty string has no block form.
- **`id` is `q` + a 1-based number with no leading zero**, numbered sequentially across all sections
  (`q1`, `q2`, `q3` … `qN` — do **not** restart at 1 per section). It is the stable key every
  projection joins on.
- **Continuation lines of a block scalar are indented to the same column as the first**, and no line
  carries trailing whitespace.
- `id` and `status` stay bare — they are constrained vocabularies, not free text. `status` is a
  closed set: `open` | `partially_answered` | `answered`, and anything else is rejected when the
  store is read. A settling date is not part of it — that goes in `updated` (`YYYY-MM-DD`, and a
  block scalar like every other value, because a bare date reads back as a timestamp).

**Fill in `proposed` for every Section 1–4 question** (Section 5 omits it — see its own rule below).
It is a real one-line best-inference
answer based on the discovery data you just read (specialist findings, coverage tables,
single-source claims, contradictions) — the reviewer sees it pre-populated in the UI textarea and
can edit or accept it. Never leave a bracketed placeholder in the file. Omit the field entirely
rather than writing a non-answer into it.

### Then validate what you wrote

Hand-authored YAML is the one writer in the system that does not go through the store's own
serializer, so canonicalise and validate it in one step:

```bash
node ".github/skills/process-os-process-discovery/scripts/questions-yaml.cjs" format "<ARTIFACTS_DIR>/review-questions.yaml"
```

- Exit `0` → the store is valid. The command rewrites it into canonical form (a value you wrote bare
  becomes a block scalar) and says whether it changed anything.
- Exit `4` → the document parses but does not match the schema; every problem is listed by path.
  Fix them and re-run.
- Exit `5` → the YAML itself is broken and the message names the line. Tabs used as indentation and
  a duplicated `q<N>` land here.

Do not report the phase complete until this exits `0`.

## Rules for Question Generation (Sections 1–4)

Only generate a question when you have concrete evidence of one of these conditions:

1. **Low confidence score** — a process area in any `data/coverage-round*.md` has confidence below 70%. Name the exact area and the research round.
2. **[GAP] marker** — a `[GAP]` appears in a process or edge file. Quote the surrounding context so the human knows exactly what is unknown.
3. **Single source** — a claim is marked `*(single source)*` for a fact that is load-bearing (appears in a gateway condition, actor assignment, or system integration). Name the source and the claim.
4. **Inferred, not verified** — a claim is marked `*(inferred — not verified)*`. Name what was inferred and from what.
5. **Named contradiction** — two specialist findings directly conflict on the same fact. Name both sources, both research rounds, and the conflicting claims.
6. **Unresolved hypothesis** — a hypothesis in any coverage file has status `open` or `contradiction` in the final research round. Quote the hypothesis ID and text.
7. **System without confirmed API access** — `participants-and-systems.md` lists a system that no specialist confirmed access to (no URL, no API docs, no direct data). Name the system.

Each Section 1–4 question must:
- Name the specific source file and research round number
- State what the human needs to provide (a fact, a decision, a confirmation)
- Be answerable by a domain expert in 1-5 sentences

Do NOT generate Section 1–4 questions for:
- Things that are well-documented and confirmed by multiple sources
- Speculative gaps not evidenced in any file
- Stylistic or formatting improvements to the output
- Systems or actors that are mentioned but not relevant to process flow

Keep all sections even when one has no questions — write it with an empty `questions: []` list
rather than dropping it, so the section numbering stays stable across cycles.

### Section 5: Real-World Exception Handling

Sections 1–4 only ask about what the discovery data already flags as uncertain. That misses
undocumented reality: a written process can read as confident and complete while still omitting an
exception path nobody happened to write down. Section 5 exists to probe for exactly that, so it is
the one place in this file where the "concrete evidence required" rule above does not apply.

From `data/bootstrap.md`'s `## Known Phases`, pick up to **5** phases, prioritizing whichever are
most central to the process outcome — gate the most downstream steps, or involve money, compliance,
or an external party. For each, write one question anchored on a specific recent case rather than the
idealized process: ask the reader to walk through the last real instance of that phase, not how it is
supposed to work.

- Weak: "How are missed payments handled?"
- Anchored: "When a customer misses a payment, what is the exact sequence of events? Who is notified first?"

Each Section 5 question must:
- Name the phase it targets
- Ask for a specific recent instance, not a general description
- Carry an `impact` estimate (High | Medium | Low); omit `confidence` and `proposed` — there is no
  citation to hang a confidence reason on, and no discovery-derived guess to propose

Cap Section 5 at 5 questions even if more phases would qualify. This section deliberately trades the
"only ask what's evidenced" discipline of Sections 1–4 for open-ended coverage; an unbounded list
would erode that trade rather than pay for it.

## After Writing

1. Update `data/progress.json`: set `"phase"` to `"review-ready"`.

2. Output a summary:

```
Review questions written: <ARTIFACTS_DIR>/review-questions.yaml

  Section 1 (Unclear Process Steps):     [N] question(s)
  Section 2 (Missing System Info):       [N] question(s)
  Section 3 (Contradictions):            [N] question(s)
  Section 4 (Coverage Gaps):             [N] question(s)
  Section 5 (Real-World Exception Handling): [N] question(s)
  Total:                                 [N] question(s)

Next step: answer the questions, then run:
  /process-os-review-answer-application --dir "<ARTIFACTS_DIR>"

  Answer directly in the .yaml (fill each `answer:` as a `|-` block), or take a copy in
  another format:
    /process-os-questions-md-export <ARTIFACTS_DIR>/review-questions.yaml     (Markdown)
    /process-os-questions-xlsx-export <ARTIFACTS_DIR>/review-questions.yaml … (spreadsheet)
  and fold it back with /process-os-md-response-application or
  /process-os-xlsx-response-application when it comes home.
```

`--dir` is required, not optional decoration: `process-os-review-answer-application` resolves
`<BPMN_DIR>` and its gate-config key from `--dir`, independently of any positional review-file
argument, and this iteration is still in flight — its own default would resolve the last
*completed* iteration instead (or fail outright on iteration 1, before one exists).
