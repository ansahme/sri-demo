# Sub-Skill: Finalize discovery

Runs **once, last** — after the file writers (`document.md`, which already produced
`review-questions.yaml`) **and** after the optional AS-IS BPMN step (Phase 3a, `as-is-bpmn.md`).
Owning completion here (not in `document.md`'s tail) guarantees it fires a single time after
Phase 3a, so the final summary reflects the BPMN and "Done" never fires prematurely.

Assume `data/progress.json` phase is already `"review-ready"` (set by `document.md`).

## EXEC: Resolve the iteration

```bash
node ".github/skills/process-os-process-discovery/scripts/iteration-dir.cjs" current process-discovery --json
```

Capture `dir` as `<ITERATION_DIR>`, `artifacts` as `<ARTIFACTS_DIR>`, and `iteration` as `<N>` — the
outer iteration number this run is completing. This is a writer resolve (no `--complete`): the
iteration finalize.md operates on is still open until the `close` call below.

## Update `.camunda/state.md`

- process-os-process-discovery Status → ✅ Done
- Completed → today's date
- Research rounds → [K], the number this iteration ran: `round - iterationStartRound + 1` from
  `data/progress.json`, or `0` when the iteration was not entitled to the loop. `round` itself is
  a running count across iterations, so it is not this figure
- Specialists Used → [list]
- Key Output → "`<ITERATION_DIR>`/artifacts/ ([M] files)" — if Phase 3a ran, note the AS-IS BPMN too,
  e.g. "`<ITERATION_DIR>`/artifacts/ ([M] files, incl. [P] AS-IS BPMN)"
- process-os-process-transformation Status → ⏳ Next
- Next Step → "Answer `<ARTIFACTS_DIR>/review-questions.yaml` (or, under governance, answer the Process Gaps Questionnaire in Tasklist), then run `/process-os-review-answer-application --dir <ARTIFACTS_DIR>`" — `--dir` is
  required here: this line is read from `.camunda/state.md`, possibly after a later iteration has
  already opened, and only an explicit `--dir` names *this* iteration rather than whichever one the
  skill's own default would resolve to at read time.

## Append audit entry

```bash
node ".github/skills/process-os-process-discovery/scripts/append-audit.cjs" process-os-process-discovery "Discovery complete — iteration <N>, [M] phases, [K] research rounds this iteration"
```

## Write memory entry

Read `.camunda/memory.md`. Locate `## Discovery Decisions`. Synthesize 3–6 bullets capturing:
- Which specialists contributed the most valuable findings
- The most important as-is observations (named processes, actors, systems)
- Major gaps identified (named — e.g., "no data on approval step actor")
- Structural decision: flat vs. hierarchical phase files, and why

Append to the section, preceded by `<!-- [today YYYY-MM-DD] -->`. Polish: remove duplicates, merge closely related bullets. Write the updated file back.

## EXEC: Close the iteration

```bash
node ".github/skills/process-os-process-discovery/scripts/iteration-dir.cjs" close process-discovery
```

## Output

```
Discovery complete.

Files written:
  <ITERATION_DIR>/artifacts/ ([M] files)

Review questions: <ARTIFACTS_DIR>/review-questions.yaml (read-only — this
iteration is closed)

Next step: collect the answers, then run:
  /process-os-sme-feedback
  /process-os-process-discovery

Answers and any other returned material go in <ITERATION_DIR>/feedback/ —
see its README.md. The next run reads that directory and folds what it finds
into a new iteration's own copy of the store; nothing writes back into this
iteration's artifacts/.

To send the questions out in another format, take a copy and return the
filled file to <ITERATION_DIR>/feedback/:
  /process-os-questions-md-export    → a .md
  /process-os-questions-xlsx-export  → a .xlsx

Under governance, the questions are also surfaced as the "Process Gaps
Questionnaire" Camunda form (the "Set discovery questions" service task
dispatches /process-os-question-form-generation to stage the discoveryQuestions variable);
answering and submitting it in Tasklist folds the answers back in
automatically on the next /process-os-process-discovery run (process-os-sme-feedback intake).
```

If Phase 3a generated the AS-IS BPMN, include the BPMN block that `as-is-bpmn.md` produced
(00-overview.bpmn / per-phase diagrams / question-targets.json / annotations.md, all under
`<ARTIFACTS_DIR>`) in this summary.
