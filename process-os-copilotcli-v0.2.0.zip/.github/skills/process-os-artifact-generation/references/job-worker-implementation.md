# Job Worker Implementation Best Practices

Source: `templates/solution/project-blueprints/java/engagement-blueprint/`

## Worker Structure

Workers are thin orchestrators. Business logic lives in a `@Service`, not the worker.

```
workers/     ← @JobWorker methods only
services/    ← business logic, external API calls
clients/     ← HTTP exchange interfaces
models/      ← process variables, DTOs
config/      ← @ConfigurationProperties, HTTP client registration
exceptions/  ← custom exception types
```

## Minimal Worker Pattern

```java
import io.camunda.client.annotation.JobWorker;
import io.camunda.client.annotation.VariablesAsType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class TaskAWorker {

    private final ExternalApiAService externalApiAService;

    @JobWorker(type = "A")
    public ProcessVariables processA(@VariablesAsType ProcessVariables processVariables) {
        ObjectA a = processVariables.getA();
        log.info("Received A: {}", a);

        String result = externalApiAService.processA(a);

        processVariables.setConcatenatedResult(result);
        return processVariables;
    }
}
```

### Rules

| Rule | Reason |
|------|--------|
| `@Component` on every `*Worker` class | Spring bean required for `@JobWorker` scan |
| Constructor injection via `@RequiredArgsConstructor` | Field injection (`@Autowired`) is forbidden by ArchUnit |
| `@JobWorker(type = "XYZ")` explicit type | Explicit type makes navigation from BPMN to code trivial |
| `@VariablesAsType` on process variable parameter | Compile-time type safety; avoids manual deserialization |
| Return updated `ProcessVariables` | Framework sets variables automatically on job completion |
| `@Slf4j` for logging | Consistent logging across all workers |
| Delegate logic to `@Service` | Workers stay testable in isolation; services stay reusable |

## Process Variable Model

```java
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ProcessVariables {
    private ObjectA a;
    private ObjectB b;
    private String concatenatedResult;
}
```

- One `ProcessVariables` class per process (or bounded context)
- `@Builder` enables clean construction in tests
- Field names match BPMN variable names exactly

## Service Layer

```java
@Service
@RequiredArgsConstructor
public class ExternalApiAService {
    private final ExternalApiAClient client;
    private final BlueprintProperties blueprintProperties;

    public String processA(ObjectA objectA) {
        ApiResponse response = client.get(objectA.a());
        if (response != null && response.success()) {
            return blueprintProperties.resultPrefix() + objectA.a() + response.suffix();
        }
        throw new ExternalApiException("Failed to process via external API A");
    }
}
```

- `@Service` (not `@Component`) on service classes — enforced by ArchUnit
- Services throw typed exceptions (`ExternalApiException`), not raw `RuntimeException`
- Services are unit-testable independently of job execution

## HTTP Clients

Use Spring 6.1+ declarative exchange interfaces:

```java
@HttpExchange(url = "/api/service-a", accept = MediaType.APPLICATION_JSON_VALUE)
public interface ExternalApiAClient {
    @GetExchange
    ApiResponse get(@RequestParam String input);
}
```

Register via configuration:

```java
@Configuration
@ImportHttpServices(group = "external-a", types = ExternalApiAClient.class)
@ImportHttpServices(group = "external-b", types = ExternalApiBClient.class)
public class HttpClientsConfig {}
```

Base URLs defined per profile in `application-{profile}.yaml`:

```yaml
spring:
  http:
    serviceclient:
      external-a:
        base-url: http://localhost:8089
```

## Configuration Properties

Use records, not `@Value`:

```java
@ConfigurationProperties(prefix = "blueprint")
public record BlueprintProperties(@NotBlank String resultPrefix) {}
```

Enable scanning in main class:

```java
@SpringBootApplication
@ConfigurationPropertiesScan
public class BlueprintApplication { ... }
```

## BPMN ↔ Worker Mapping

BPMN service task declares job type via Zeebe extension:

```xml
<bpmn:serviceTask id="Activity_A" name="do A">
    <bpmn:extensionElements>
        <zeebe:taskDefinition type="A" />
    </bpmn:extensionElements>
</bpmn:serviceTask>
```

Worker annotation must match exactly:

```java
@JobWorker(type = "A")  // must equal zeebe:taskDefinition type
```

## Idempotency

Zeebe uses **at-least-once** delivery — a worker may receive the same job more than once (e.g., after a restart or timeout). Every handler must be idempotent. Choose a strategy:

- **Natural idempotency**: the operation is inherently safe to repeat (e.g., setting a flag, writing a value that's already correct)
- **Business idempotency**: check a domain identifier before acting (e.g., check if the order already has an invoice before creating one)
- **Unique-ID idempotency**: derive a stable key from `job.getKey()` and pass it to the external system

```java
// Unique-ID pattern
String idempotencyKey = "payment-" + job.getKey();
paymentService.charge(amount, idempotencyKey); // external system deduplicates by key
```

## Async Workers (High-Throughput)

For high-performance use cases, accept `ActivatedJob` and `JobClient` and complete asynchronously:

```java
@JobWorker(type = "A", autoComplete = false)
public void processA(JobClient client, ActivatedJob job) {
    // submit work asynchronously
    executor.submit(() -> {
        try {
            // do work
            client.newCompleteCommand(job.getKey()).send().join();
        } catch (Exception e) {
            client.newFailCommand(job.getKey()).retries(job.getRetries() - 1).send().join();
        }
    });
}
```

## Dependencies (pom.xml)

```xml
<dependency>
    <groupId>io.camunda</groupId>
    <artifactId>camunda-spring-boot-starter</artifactId>
    <version>${camunda.version}</version>
</dependency>
```

Tested against Camunda 8.8.x.

## Multi-Environment Configuration

| Profile | Mode | Auth |
|---------|------|------|
| `local` | `selfmanaged` | basic (username/password) |
| `saas` | `saas` | OAuth (client-id/client-secret) |

```yaml
# application-saas.yaml
camunda:
  client:
    mode: saas
    auth:
      client-id: ${CAMUNDA_CLIENT_ID}
      client-secret: ${CAMUNDA_CLIENT_SECRET}
    cloud:
      cluster-id: ${CAMUNDA_CLOUD_CLUSTER_ID}
      region: ${CAMUNDA_CLOUD_REGION}
```

Secrets loaded from `.env` file via `spring.config.import: "optional:file:.env[.properties]"`.

## Metrics

Expose via Spring Actuator:

```yaml
management:
  endpoints:
    web:
      exposure:
        include: metrics
```

Key metrics:
- `camunda.job.invocations` — total invocations
- `camunda.job.invocations?tag=action:activated` — activated count
- `camunda.job.invocations?tag=type:A` — per-type breakdown
