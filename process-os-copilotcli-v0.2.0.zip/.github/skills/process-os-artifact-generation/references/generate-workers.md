# Sub-Skill: Generate Workers

Generate the executable worker module: scaffold the project by copying the engagement
blueprint, then run the target SDK's worker layer.

Step 1 is the same for every SDK. Everything after it is per SDK, selected by the routing table below.

## Inputs

- `MANIFEST` — path to `process-implementation/artifacts/.manifest.json`
- `TIMING_DIR` — directory for the per-event timing record. Every `timing.cjs` invocation MUST pass `--dir "<TIMING_DIR>"` (the Bash tool starts a fresh shell per call; an exported var would not survive).
- `BASENAME` — `workers` (names this agent's timing record).

## Timing instrumentation

Canonical bash form for event emission:

```bash
node ".github/skills/process-os-artifact-generation/scripts/timing.cjs" --dir "<TIMING_DIR>" event "<BASENAME>" <event-name>
```

Event vocabulary:

| Event | When |
|-------|------|
| `start` | Once, very first action — before reading `MANIFEST` |
| `sdk_build` | After the overlay's own build/compile invocation, if it has one (success or failure) |
| `end` (via `end` subcommand) | Once, very last action |

Emit on every path including failure — partial records still aggregate.

This vocabulary is fixed for every SDK: an overlay emits these names and adds none of its own, so a new
SDK needs no row here and the aggregate keeps one shape across SDKs. The orchestrator runs its own build
gate after this sub-skill returns, and marks it with a phase-boundary event on the `orchestrator` record.
That is a different gate from `sdk_build`, deliberately: this one is inside the worker step, the
orchestrator's runs on the assembled bundle.

## Step 1: Scaffold by copying the blueprint (deterministic, no LLM)

**Emit `start` first**, before any other action.

The project shape is scaffolded by `skills/process-os-artifact-generation/scripts/scaffold-workers.cjs`,
which **copies the engagement blueprint** (`blueprints/<targetSdk>/`) — no network, no Spring
Initializr. It:

1. Reads `<MANIFEST>` for `meta` (`packageBase`, `processSlug`, `processCamel`, and `targetSdk` — the
   SDK selector; defaults to `java-spring-boot`).
2. Selects the blueprint dir `blueprints/<targetSdk>/` (`--blueprint-path <dir>` overrides).
   Only `java-spring-boot` and `typescript` are implemented; any other SDK exits 2.
3. **java-spring-boot** — copies the reusable scaffold with package/coordinate/class-name substitution
   (`com.camunda.consulting.blueprint` → `packageBase`, pom `groupId`/`artifactId`/`name`,
   `BlueprintApplication` → `<processCamel>Application`, and the pom `<camunda.version>` → the stable
   Camunda Java **client** patch for the project's cluster minor — see the note after this list): `pom.xml` (the canonical blueprint pom —
   camunda-spring-boot-starter, camunda-process-test-spring, spotless, jacoco, ArchUnit already
   declared), `lombok.config`, `application.yaml`/`-local`/`-saas` + `src/test/resources/application.yaml`,
   `<processCamel>Application.java`, and the three ArchUnit tests (`LayerArchitectureTest`,
   `AnnotationUsageTest`, `StereotypeConventionTest`) under `architecture/`. It **drops** the blueprint's
   example domain (`clients`/`services`/`workers`/demo `models`) and its example-coupled `config`/
   `exceptions` classes (`HttpClientsConfig` imports the example clients), creates the empty package tree
   (`workers`, `services`, `clients`, `models`, `config`, `config/properties`, `exceptions`), and then
   **generates** `models/ProcessVariables.java` from the manifest variable union (one Lombok field per
   unique `inputVariables[]`+`outputVariables[]` name; type disagreements → `Object`).
4. **typescript** — copies the build manifests + `src/` skeleton (minus the example
   workers/services/clients, the demo model, the demo properties config, the demo HTTP error class,
   all `*.test.ts`, the `test/` dir and the two pnpm-only files), applies post-copy patches, and
   emits **no** `.java`. The worker layer itself is Step 2's job.

**Pinned client version.** The bundle pom's `<camunda.version>` is set to the stable Camunda Java
**client** patch for the project's TO-BE cluster minor (`manifest.meta.camundaClusterVersion`, from
SKILL.md step 1.2), mapped via `versions.json` (`8.8`→`8.8.32`, `8.9`→`8.9.13`). The client is pinned
independently of the cluster and may lag it — an older client against a newer cluster is a supported
skew. A cluster minor with no GA client yet (`8.10`, alphas only) falls back to the newest stable client
and the scaffold logs the lag. When `camundaClusterVersion` is absent the blueprint's own pin is kept.

`versions.json` holds **only** this per-cluster-minor client map. All other pinned versions
(Spring Boot, Java, ArchUnit, …) live in the **blueprint pom** (`blueprints/java-spring-boot/pom.xml`)
and blueprint `package.json` — the source of truth, maintained directly in this repository, not by
Renovate. To dump the pinned versions as machine-readable JSON, pass `--summary <path.json>` — it
covers the project dependencies, the Maven **build plugins**, the Maven wrapper's distribution URL, and
the TypeScript blueprint's `engines` toolchain floor, i.e. everything a fresh machine must fetch to
build and test the project (`scripts/emit-dep-snapshot.cjs` consumes it). The summary's
`packageManager` is always `null`: the generated project drops the blueprint's pnpm pin and builds via
plain npm, so it names no dependency a fresh machine needs to fetch.

```bash
node ".github/skills/process-os-artifact-generation/scripts/scaffold-workers.cjs" process-implementation/artifacts --summary process-implementation/artifacts/.dep-summary.json
```

```bash
node ".github/skills/process-os-artifact-generation/scripts/scaffold-workers.cjs" process-implementation/artifacts
```

This step is **purely mechanical** — no LLM, no network. **Do not dispatch a subagent for this step.**
`scaffold-workers.cjs` has a unit-test suite covering substitution, the scaffold-vs-example split,
ProcessVariables generation, TS scaffold-only, unsupported-SDK, and idempotency.

After this step (java) the project is ready for the batched worker fan-out: `workers/`, `services/`,
`exceptions/` exist (empty); `models/ProcessVariables.java` is in place; `pom.xml` is the canonical
blueprint pom. When the blueprint ships a Maven wrapper (`mvnw`, `mvnw.cmd`,
`.mvn/wrapper/maven-wrapper.properties`), the scaffold copies it verbatim so the project builds
standalone with `./mvnw` on a machine with no preinstalled Maven — the wrapper downloads the pinned
Maven version on first use. A blueprint that carries no wrapper is not an error: every caller that
runs Maven against a scaffold (`scripts/run-maven.cjs`, `spring-worker-app.cjs`) falls back to
an installed `mvn` on PATH.

**`config/` and `clients/` are a durable hand-edit surface.** Scaffold only creates the package tree
(`workers/`, `services/`, `exceptions/`, `models/`, `config/`, `config/properties`, `clients/`); it
never writes into `config/` or `clients/` themselves, on a generation pass or an edit pass alike. Hand-written
`@ConfigurationProperties` / `@HttpExchange` code there is untouched by any later run.

## Step 2: The SDK's worker layer

Read the capability row's `workerInstructions` field:

```bash
node ".github/skills/process-os-artifact-generation/scripts/sdk-capabilities.cjs" --from-manifest process-implementation/artifacts
```

| `workerInstructions` | Follow |
|---|---|
| `references/workers-java-spring-boot.md` | [the Java Spring Boot overlay](references/workers-java-spring-boot.md) |
| `references/workers-typescript.md` | [the TypeScript overlay](references/workers-typescript.md) |
| `references/workers-python.md` | [the Python overlay](references/workers-python.md) |
| `null` | Nothing. Report `worker layer: skipped — no worker generator for SDK <sdk>` and go to the report. Do not stop the skill. |

Read the file as an **overlay on this spine**, not as an exclusive handoff: come back here for the
next sections. The worker layer is one step inside Phase 3, not a whole-skill takeover,
so "follow this file exclusively, then stop" would skip the SDK-independent steps on either
side of it.

**Gate contract.** Every SDK's worker layer is followed by a build gate. Where that gate runs differs:
`java-spring-boot`'s overlay carries its own `mvn -q test` gate, and SKILL.md additionally runs a
compile at the orchestrator level, because a subagent can return before reaching its own gate.
`typescript` has no subagent, so its gate is the orchestrator-level one only. Either way, **a gate that
did not run is never green** — see SKILL.md's Build gate step.

## Report

Report what the SDK's overlay wrote, then the shared TODO summary below. The bundle's own file tree,
and exactly which generated files carry a `TODO`, are in the per-SDK report file the capability row
names (`reportFile`) — do not restate either here.

TODO items in:
  - Each service's stub (implement the domain logic) — see the per-SDK report for whether the worker
    itself also has one.
  - Any hand-written HTTP/API client code the process needs, under the `clients/` package/directory
    (the durable hand-edit surface at the end of Step 1) — never generated, always a manual
    addition.

## Finalize timing

Last action of this skill — after the report:

```bash
node ".github/skills/process-os-artifact-generation/scripts/timing.cjs" --dir "<TIMING_DIR>" end "<BASENAME>"
```
