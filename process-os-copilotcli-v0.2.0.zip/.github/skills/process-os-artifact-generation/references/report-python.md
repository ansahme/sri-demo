# Report: python

The bundle report for a `python` target. SKILL.md renders both sections below, substituting every
`<…>` placeholder.

The bundle carries the application and one worker for each unique job type in the manifest. Each
generated service holds a TODO stub, which is the remaining engagement work. Both sections below
reflect that state.

## Deployability — manual validation

Automated deployability validation is not available for the `python` target SDK:
`/process-os-deployment` boots the worker application with Maven under a Spring profile resolved from
an `application-*.yaml`, and a Python bundle has neither. **No step in this run validated this bundle
against a cluster** — no green verdict, no red one.

What the steps below confirm is that the bundle installs, passes its own checks, starts, and
subscribes to every generated job type.

**1. Install the pinned environment.** `--frozen` is what asserts `uv.lock` still satisfies
`pyproject.toml`. Without it uv re-resolves silently, and the pinned graph stops meaning anything:

```bash
uv sync --frozen --directory process-implementation/artifacts
```

**2. Run the bundle's own checks**, one command at a time. A failure here is a defect in the bundle
rather than a missing cluster:

```bash
uv run --directory process-implementation/artifacts ruff check .
```

```bash
uv run --directory process-implementation/artifacts ruff format --check .
```

```bash
uv run --directory process-implementation/artifacts mypy
```

```bash
uv run --directory process-implementation/artifacts lint-imports
```

`lint-imports` is the layering gate — the five contracts in `pyproject.toml`, the counterpart of the
Java bundle's ArchUnit tests. `pytest` is deliberately absent. The only test the scaffold carries is
the architecture test that shells out to `lint-imports`, already run above, and the blueprint's
`--cov-fail-under=80` fails a bundle that holds no other test.

**3. Point the application at a cluster.** It reads its connection from the process environment
through the Camunda 8 SDK, not from a config file. `process-implementation/artifacts/.env.example` lists every variable with
its default. Copy it to `process-implementation/artifacts/.env` and fill in what your cluster needs:

| Variable | Value |
|---|---|
| `CAMUNDA_REST_ADDRESS` | the cluster's REST endpoint, e.g. `http://localhost:8080` |
| `CAMUNDA_AUTH_STRATEGY` | `NONE`, `BASIC`, or `OAUTH` |
| `CAMUNDA_BASIC_AUTH_USERNAME`, `CAMUNDA_BASIC_AUTH_PASSWORD` | required when the strategy is `BASIC` |
| `CAMUNDA_CLIENT_ID`, `CAMUNDA_CLIENT_SECRET`, `CAMUNDA_OAUTH_URL` | required when the strategy is `OAUTH` |

**4. Deploy the generated resources.** The application does not deploy its own resources, because the
blueprint's deploy-on-start is removed at scaffold time and deploying belongs to
process-os-deployment. Deploy the BPMN, DMN and form files under
`process-implementation/artifacts/src/main/resources/{processes,decisions,forms}` yourself, for example through `c8ctl deploy`
(see [the c8ctl reference](c8ctl.md) for the exact command and profile setup).

**5. Start the application** (`<package>` is this project's processSlug converted to a legal Python
identifier — see the Output block's file tree below):

```bash
uv run --directory process-implementation/artifacts python -m <package>.main
```

**A healthy start** logs `Camunda 8 reachable`, then `Blueprint workers started`, serves `/healthz`
and `/readyz` on `MONITORING_PORT`, and stays running. It subscribes to every job type the manifest
declares, one worker each. `Ctrl-C` exercises the graceful drain and should log `Shutdown complete`.

**The failure you are most likely to hit** is `Failed to reach Camunda 8 cluster` at startup. That is
the connection values in step 3, not a defect in the generated code.

**What "runnable" means here.** The application starts, validates its environment, connects, serves
its health endpoints, and subscribes to every generated job type. A dispatched job reaches its worker,
which validates the job's variables against that job type's model and calls its service. Each
generated service returns an empty output model behind a `# TODO: implement` comment, so a task
completes and sets no output variable.

Two consequences follow, and neither is a defect at this phase. A task whose required inputs an
upstream stub was supposed to produce fails validation with a named `JobFailure` on that exact task,
which is preferable to an undefined value reaching a stub body. A process instance therefore walks as
far as the first such task rather than to the end.

## Output

```
Artifact generation complete.

Generated: <W> workers, <D> decisions, <F> forms

process-implementation/artifacts/
  pyproject.toml            deps, tool config, and the five import-linter contracts
  uv.lock                   the pinned resolution, installed by `uv sync --frozen`
  .python-version           interpreter floor uv provisions against
  .env.example              every variable with its default (demo-only keys removed)
  .venv/                    created by `uv sync` (gitignored)
  <package>/                processSlug converted to a legal Python identifier
    main.py                 startup, signal handling, graceful shutdown
    app.py                  generated: one service per job type, and the worker registry
    shutdown.py             the worker drain
    models/
      process_variables.py  generated: the all-optional union, plus one input and one
                            output model per job type, aliased to the manifest names
    errors/
      service_error.py      generated: the error a service raises, carrying a code
      bpmn_errors.py        generated: the declared BPMN error codes (absent when none)
      external_api_error.py raised by http_client
    services/               generated: one async stub per job type, behind a TODO
    workers/                generated: one worker per job type, plus worker_defaults.py
    clients/
      http_client.py        typed httpx wrapper, for services to build on
    observability/          logger + /healthz and /readyz server
    config/                 env.py (patched: demo-only keys removed)
  tests/
    architecture/           test_layers.py — runs the import-linter contracts
  src/main/resources/
    processes/    ← execution-ready BPMNs
    decisions/    ← DMN tables
    forms/        ← Camunda Forms

Deployability: manual validation required — see "Deployability — manual validation" above

Next steps:
  1. Validate the bundle by hand (steps 1–5 above)
  2. Implement the service stubs under <package>/services/ — each one returns an empty
     output model behind a `# TODO: implement` comment
  3. Run /process-os-test-suite — generate and run the CPT test suite
  4. Run /process-os-deployment — the production deployment (after test-suite)

TODO items are marked in generated files where manual input is needed.
Environment setup: run /process-os-environment-setup if you don't have a local Camunda cluster yet.
```
