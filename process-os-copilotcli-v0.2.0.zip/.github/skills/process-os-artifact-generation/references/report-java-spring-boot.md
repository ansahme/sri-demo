# Report: java-spring-boot

The bundle report for a `java-spring-boot` target. SKILL.md renders the `## Output` section below,
substituting every `<…>` placeholder.

## Output

```
Artifact generation complete.

Generated: <W> workers, <D> decisions, <F> forms

process-implementation/artifacts/
  pom.xml
  src/main/java/[package]/
    [ProcessName]Application.java
    workers/
      [list of *Worker.java]
  src/main/resources/
    application.yaml
    processes/    ← execution-ready BPMNs
    decisions/    ← DMN tables
    forms/        ← Camunda Forms
  src/test/java/[package]/
    workers/      ← @CamundaSpringProcessTest stubs

Deployability: <validated against <profile> in Phase 5 | not validated — no reachable cluster>

Next steps:
  1. If Phase 5 could not validate (no reachable cluster): run
     /process-os-environment-setup, then /process-os-deployment --validate —
     confirms the bundle deploys + every worker connects, WITHOUT advancing the
     lifecycle
  2. Run /process-os-test-suite — generate and run the CPT test suite
  3. Run /process-os-deployment — the production deployment (after test-suite)

TODO items are marked in generated files where manual input is needed.
Environment setup: run /process-os-environment-setup if you don't have a local Camunda cluster yet.
```
