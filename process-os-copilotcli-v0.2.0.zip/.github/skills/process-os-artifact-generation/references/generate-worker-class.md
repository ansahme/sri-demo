# Sub-Skill: Generate Java Worker Class (Per-Worker)

Generate the three Java files for **one** worker entry: `*Worker.java` + matching `*Service.java` + typed `*Exception.java` for each declared error code. Followed once per worker index inside a batch agent, per [the Java Spring Boot overlay](references/workers-java-spring-boot.md)'s Step 2 batched fan-out — not one subagent per worker.

## Inputs

- `WORKER_INDEX` — zero-based index into `manifest.workers[]` (selects exactly one worker entry).
- `MANIFEST` — path to `process-implementation/artifacts/.manifest.json`.
- `TIMING_DIR` — directory for the per-worker timing record.
- `BASENAME` — `worker-<className>` (one timing record per worker; `className` from manifest).

## Step 0: Read your worker entry

```bash
node -e '
const m = JSON.parse(require("fs").readFileSync(process.argv[1], "utf8"));
const w = m.workers[parseInt(process.argv[2], 10)];
if (!w) { console.error("no worker at index"); process.exit(2); }
console.log(JSON.stringify(w));
' "<MANIFEST>" "<WORKER_INDEX>"
```

Capture the worker JSON. Read `meta.packageBase` from the same manifest (you'll need it for package + import paths).

**Emit `start`.**

## Step 1: Naming derivations (from worker entry)

| Variable | Source | Example |
|----------|--------|---------|
| `<className>` | `worker.className` | `SendQuoteToCustomerWorker` |
| `<jobType>` | `worker.jobType` | `send-quote-to-customer` |
| `<handlerName>` | `className` minus `Worker` suffix, first letter lowered | `sendQuoteToCustomer` |
| `<DomainService>` | `className` minus `Worker` suffix + `Service` | `SendQuoteToCustomerService` |
| `<serviceVar>` | `<DomainService>` first-letter-lowered | `sendQuoteToCustomerService` |
| `<PACKAGE_PATH>` | `meta.packageBase` with dots → slashes | `com/acme/quotetocash` |

## Step 2: Write the Worker class

**Regenerated on a generation pass.** Write this file whether or not one already exists at this
path, whenever this step runs — the Worker class is not a hand-edit surface, so overwrite it
unconditionally. An edit pass never reaches this step.

Path: `process-implementation/artifacts/src/main/java/<PACKAGE_PATH>/workers/<className>.java`.

```java
package <packageBase>.workers;

import io.camunda.client.annotation.JobWorker;
import io.camunda.client.annotation.VariablesAsType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import <packageBase>.models.ProcessVariables;
import <packageBase>.services.<DomainService>;
<for each error in worker.errors:>
import <packageBase>.exceptions.<ErrorClassName>Exception;
</for>

@Slf4j
@Component
@RequiredArgsConstructor
public class <className> {

    private final <DomainService> <serviceVar>;

    @JobWorker(type = "<jobType>")
    public ProcessVariables <handlerName>(@VariablesAsType ProcessVariables variables) {
        log.info("Executing <jobType>: {}", variables);

        // TODO: extract inputs from `variables`, call `<serviceVar>`, set outputs.
        <for each output in worker.outputVariables:>
        // variables.set<OutputCamel>(...);
        </for>

        return variables;
    }
}
```

`@Component` is mandatory; `@RequiredArgsConstructor` is mandatory (no `@Autowired` field injection — ArchUnit will fail the build); `@JobWorker(type=…)` must literally match the BPMN's `zeebe:taskDefinition type` value.

## Step 3: Write the Service stub

Path: `process-implementation/artifacts/src/main/java/<PACKAGE_PATH>/services/<DomainService>.java`.

```java
package <packageBase>.services;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class <DomainService> {

    // TODO: inject HTTP client, repository, or other dependencies via constructor.

    public void execute(/* TODO: domain inputs */) {
        // TODO: implement business logic.
        // Throw typed exceptions from <packageBase>.exceptions on failure
        // (e.g. throw new SendFailedException("..."); )
    }
}
```

`@Service` (not `@Component`) is mandatory — ArchUnit's `StereotypeConventionTest` enforces it. Constructor injection only.

**If a service file with the same path already exists, skip — for either of two reasons, and both
leave the file untouched.** Within one generation run's batched fan-out, a service file that already
exists was written earlier in this same fan-out by another worker agent whose job type maps to the
same `<DomainService>` (two service tasks recurring across phases): that is same-run deduplication,
not a hand edit, and it is safe to just verify the existing file's class name matches
`<DomainService>` before moving on. Across runs, the file may instead be a developer's own
implementation from an earlier generation pass — this is the file this skill's Report section names
as manual work ("implement the domain logic"), so a later pass leaves it exactly as it is rather than
overwriting it. Either way the action is identical: leave the file alone. Only write the Service stub
above when no file exists at this path yet.

## Step 4: Write typed exception classes

For each entry in `worker.errors[]`, write `process-implementation/artifacts/src/main/java/<PACKAGE_PATH>/exceptions/<ErrorClassName>Exception.java` where `ErrorClassName` is the error code in PascalCase (e.g. `SEND_FAILED` → `SendFailed`):

```java
package <packageBase>.exceptions;

public class <ErrorClassName>Exception extends RuntimeException {
    public <ErrorClassName>Exception(String message) { super(message); }
    public <ErrorClassName>Exception(String message, Throwable cause) { super(message, cause); }
}
```

If `worker.errors` is empty, skip this step. Other worker agents may write the same exception file (multiple workers can declare the same error code) — write idempotently: if the file exists with the same class declaration, skip; otherwise overwrite. Unlike the Service stub in Step 3, an exception class is not a hand-edit surface: "skip if identical, otherwise overwrite" is same-run deduplication only, and this file is regenerated the same as the Worker class in Step 2.

## Step 5: Report

```
Worker generated: <className> (jobType=<jobType>, errors=<N>)
```

## Finalize timing

```bash
node ".github/skills/process-os-artifact-generation/scripts/timing.cjs" --dir "<TIMING_DIR>" end "<BASENAME>"
```
