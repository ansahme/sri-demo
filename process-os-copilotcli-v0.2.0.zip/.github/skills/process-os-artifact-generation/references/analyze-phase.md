# Sub-Skill: Per-Phase Artifact Inference

Infer worker, form, decision, and connector-binding metadata for **one** phase BPMN. One subagent per phase; all run in parallel from `SKILL.md` Phase 1.

This sub-skill carries the per-element inference rules. It is intentionally scoped to a single phase so per-phase contexts stay small and parallel agents don't interfere. The orchestration (parse, dispatch, join, manifest write) lives in `SKILL.md` Phase 1 — at the top level, where Claude Code reliably dispatches subagents.

## Inputs (provided by the orchestrator)

- `PHASE_STEM` — basename without `.bpmn` (e.g. `process-01-quoting`).
- `BPMN_FILE` — full path (e.g. `process-transformation/iteration-1/artifacts/process-01-quoting.bpmn`).
- `PHASE_DOC` — full path to the phase markdown, `<stem>.md` next to `BPMN_FILE` in the same resolved iteration's `artifacts/` directory (e.g. `process-transformation/iteration-1/artifacts/process-01-quoting.md`). The orchestrator resolves this path the same way for every tier and emits it unconditionally — every tier writes a per-phase `.md` companion. Treat a missing file defensively (see Step 1) rather than as an expected per-tier case.
- `ELEMENTS_PATH` — path to pre-parsed structural data for this phase, written by the orchestrator to `process-implementation/artifacts/.analyze-phase/<PHASE_STEM>.bpmn.json`. Format: a single JSON line — `{file, processId, elements: [{id, type, name, note, businessRule, bpmnErrors}]}` — the same shape the parser script emits.
- `OUTPUT_PATH` — where to write this phase's manifest slice (e.g. `process-implementation/artifacts/.analyze-phase/<PHASE_STEM>.json`).

## Step 1: Read inputs

Read `ELEMENTS_PATH` (small JSON file — Bash `cat` or Read tool both fine). If `PHASE_DOC` exists, read it for human-readable context; if it is unexpectedly missing or unreadable, infer entirely from the BPMN element inventory in `ELEMENTS_PATH` — do NOT stop or error. The BPMN is always the authoritative source; `PHASE_DOC` only adds naming/context hints when present. This is a defensive safety net, not a per-tier branch — no tier is expected to lack a companion.

```bash
cat "<ELEMENTS_PATH>"
```

Parse the JSON. You now have the phase's `processId` and the element list. Each element carries:

- `id` — BPMN element id
- `type` — one of `serviceTask`, `userTask`, `businessRuleTask`, `task`, `sendTask`, `receiveTask`, `manualTask`, `scriptTask`, `exclusiveGateway`
- `name` — BPMN `name` attribute
- `note` — text annotation associated with this element via `bpmn:association` (often carries `Implementation: …` hints)
- `businessRule` — `true` when the element is a `businessRuleTask` or its annotation contains `[BusinessRule]`
- `bpmnErrors` — `[{code, name}]` extracted from boundary error events attached to this element

The phase doc gives semantic context (input/output variable names, error scenarios, business rules). Use it to fill in details the structural data alone can't reveal.

## Step 2: Infer per element

Every manifest entry is a **wiring-plan entry**, not a topology request. It must point at an existing BPMN element by id and describe only execution metadata that can be added to that element or to its existing outgoing sequence flows. Do not create manifest entries that require creating BPMN flow nodes, changing `sourceRef`/`targetRef`, or editing DI.

### Service tasks / abstract tasks / send tasks

For each element with `type ∈ {serviceTask, task, sendTask}` AND no `modelerTemplate` attribute (those become connector bindings — see below) AND no `nestedInConnectorContainer: true` flag (a tool child of an AI-Agent sub-process that is itself connector-bound — either it carries its own `zeebe:modelerTemplate`, or its `zeebe:taskDefinition` type is namespace-qualified, e.g. `io.camunda:http-json:1` — driven by the agent via `fromAi()`, not a job worker, so emitting a worker for it produces a dead, never-invoked class. A tool child with a bare, non-colon `taskDefinition` type, e.g. `read-case`, is a real job-worker tool and is NOT flagged — emit a worker for it as normal):

- `jobType` = element name in kebab-case (e.g. `Send Quote to Customer` → `send-quote-to-customer`).
- `className` = PascalCase + `Worker` (e.g. `SendQuoteToCustomerWorker`).
- `wiring`:
  - `targetElementId` = element id
  - `zeebeTaskDefinitionType` = same as `jobType`
  - `preserveExistingConnectorBinding` = `false`
- `inputVariables`: scan the element's `note` and the matching step text in `PHASE_DOC` for camelCase words, words preceding `Id` / `Amount` / `Name` / `Date` / `Status`, and any explicitly-named variable. Default type `String`; use `Double` / `Long` for amounts/counts; `Boolean` for flags.
- `outputVariables`: look for past-tense results in step text ("sets X", "returns X", "stores X"), annotation text after the task, and end-event names that imply an output.
- `errors`: prefer `bpmnErrors` from the parsed BPMN — these get `confidence: high`, `source: "bpmn"`, and the `code` comes straight from the BPMN model. If `bpmnErrors` is empty, fall back to inferring from negative gateway branches in the phase doc (`rejected`, `failed`, `error`, …) — derive `SCREAMING_SNAKE_CASE` codes and mark `confidence: medium`, `source: "inferred"`.
- `confidence`: `high` if inference is clear; `medium` if uncertain.

### Message throw events (`intermediateThrowEvent` / `endEvent` with `messageEventDefinition`)

For each element with `type ∈ {intermediateThrowEvent, endEvent}` AND `publishesMessage == true`:

These are publish-message events. Zeebe runs them as job workers — the broker needs a `<zeebe:taskDefinition type="…">` on the event so the publish operation can be picked up by an external worker that calls the message-publish API. Without a worker, the audit fails with "jobType not declared in manifest.workers" and deployment incidents at runtime.

- `jobType` = `publish-` + element name in kebab-case (e.g. `Quote approved` → `publish-quote-approved`). When the element has no name, fall back to `messageRef` (e.g. `Message_QuoteApproved` → `publish-quote-approved`).
- `className` = PascalCase of `jobType` + `Worker` (e.g. `PublishQuoteApprovedWorker`).
- `sourceElementType` = `intermediateThrowEvent` or `endEvent` — records that this worker targets a publish-message event, whose `<zeebe:taskDefinition>` is authored by the transformation BPMN (process-flow wiring), not synthesized by `wire-execution-bpmn.mts`.
- `wiring`:
  - `targetElementId` = element id
  - `zeebeTaskDefinitionType` = `jobType`
  - `preserveExistingConnectorBinding` = `false`
- `inputVariables`: any FEEL variables referenced in the matching `<bpmn:message>` correlation key (look at the corresponding `messageSubscriptions[]` entry's `correlationKey` for hints; otherwise empty).
- `outputVariables`: empty — publish-message events don't return data to the process.
- `errors`: empty unless the element has boundary error events attached (rare).
- `confidence`: `high` when `messageRef` resolves to an existing `<bpmn:message>`; `medium` when `messageRef` is empty or unresolved.

Emit these as **worker entries** (same shape as serviceTask workers). Do NOT also emit a `messageSubscription` for the same element — those are for the catching side.

### User tasks

For each element with `type == userTask`:

- `formId` = `form-` + element id without `t-` / `Task_` / `task-` prefix (kebab-case).
- `wiring`:
  - `targetElementId` = element id
  - `formDefinitionFormId` = `formId`
- `fields`: from phase-doc step text + `note`, look for data mentioned (names, amounts, dates, status choices). Map to Camunda Form types: text → `textfield`, number → `number`, date → `datetime`, yes/no → `checkbox` or `select`, long text → `textarea`, multiple choice → `taglist`.
- `required: true` when the step implies mandatory input.

### Business rule tasks

For each element with `type == businessRuleTask`:

Treat existing `businessRuleTask` elements as the authoritative DMN seam created by `/process-os-bpmn-generation`. Do **not** synthesize new ones.

- `taskId` = element id.
- `taskName` = element name.
- `decisionId` = `decision-` + task id without `Task_` / `task-` prefix, kebab-cased.
- `decisionName` = task name.
- `resultVariable` = task name in camelCase + `Result` (e.g. "Check legal trigger thresholds" → `checkLegalTriggerThresholdsResult`).
- `wiring`:
  - `targetElementId` = task id
  - `calledDecisionId` = `decisionId`
  - `resultVariable` = `resultVariable`
  - `gatewayElementId` = **only set if a matching `exclusiveGateway` exists in this phase's parsed `elements[]`**. Look up the immediately-following exclusive gateway in the BPMN flow; if its id appears as `{type: "exclusiveGateway", id: …}` in `elements[]`, set `gatewayElementId` to that id. If no such element exists, leave `gatewayElementId` null and add a review question naming the decision and the missing gateway. **Never invent a gateway id**. The wiring step (`wire-execution-bpmn.mts`) hard-fails on a manifest gatewayId that's not in the BPMN, so a hallucinated id would break the run.

  Mirror the same rule on the top-level `gatewayId` / `gatewayName` fields if you populate them — they must reference an element that is in `elements[]`.

- `inputs` / `outputs`:
  - Prefer the task's `note` (especially `Implementation: Camunda DMN engine; inputs ...; outputs ...`). Fall back to phase-doc context.
  - Each `inputs[].name` must be **grounded** — it has to appear somewhere in the phase's evidence (the task's annotation, the phase doc, an upstream element's annotation in `elements[].note`, or a connector's input target on a preceding `serviceTask`). If you cannot point to evidence, mark `confidence: medium` and add a numbered review question naming the decision and the unresolved input.
  - Inputs default to grounded `confidence: high`. Drop to `medium` only when the variable name is plausible but unsourced.
  - `outputs[].name` must be the DMN output column names. Generation promotes each to a top-level process variable via a `<zeebe:output source="=<resultVariable>.<name>" target="<name>">` mapping — so downstream consumers that read the field top-level (a later worker's input, the next phase's handoff) resolve, not only gateway conditions that read `<resultVariable>.<name>`. Record every output field the process consumes; a missing one leaves that variable null at runtime.

- `branches`: when a downstream `exclusiveGateway` exists in `elements[]`, capture its outgoing sequence flow names and derive FEEL. Skip when no gateway is grounded — never produce branches without a real gateway.

Do not infer new DMN decisions from gateways. Gateways describe branching over data that already exists; if a gateway appears to need a missing DMN evaluation task, surface a review question instead of adding a manifest decision that would require rewriting BPMN topology.

### Connector bindings

For each element whose `note` references a `[Connector:<id>]` marker, or — more reliably — whose source BPMN carries `zeebe:modelerTemplate="<id>"` and `zeebe:modelerTemplateVersion="<version>"` attributes:

(The structural parser doesn't surface these attributes today. If you need them, search the BPMN file directly, substituting the phase's `<BPMN_FILE>` path:
```bash
node ".github/skills/process-os-artifact-generation/scripts/search-files.mts" --pattern 'zeebe:modelerTemplate(Version)?="' "<BPMN_FILE>"
```
Exit `1` means the file has no template-bound element; exit `2` means the search could not run — a
substituted path that does not exist — and is never the same answer. Match by element id from the
structural data.)

- `templateId`, `templateVersion` — captured from the attributes.
- `annotationText` — the linked `<bpmn:textAnnotation>` text for this element (the same string that Phase 1 captured in `elements[].note`). Surfacing it here as a top-level field eliminates a re-parse in Phase 2.5's reconciler and gives the per-template Haiku subagent vendor / operation / field hints when manifest sources are ambiguous. Empty string when the element has no annotation.
- `wiring`:
  - `targetElementId` = element id
  - `preserveTemplateBinding` = `true` (the already-bound connector is preserved as-is; `wire-execution-bpmn.mts` records any still-unresolved input to `process-implementation/artifacts/.review/<phase>.json` rather than fabricating a value — it never rebuilds the connector block)
  - `unresolvedInputs`: list `{target, source, confidence}` for **any** template-bound value the phase doc doesn't pin down — `<zeebe:input>` properties AND `<zeebe:taskHeader>` bindings (`resultExpression`, `errorExpression`, etc.) AND `<zeebe:output>` shape. The reconciler routes each entry to the right XML location based on the template's binding type — your job is to surface the target/source pair regardless of whether it lands in `ioMapping` or `taskHeaders`. Each entry's `target` is your best guess at the connector property path or header key; `source` is the FEEL expression / variable / literal that should fill it.

  **Source rules — read carefully.** Phase 2.5's deterministic Stage 1 fast-paths a clean source; Stage 2 (Haiku) burns tokens on dirty ones. Help the deterministic stage by emitting parseable values:

  - ✅ `source: "=case_id"` — FEEL variable reference, passes through verbatim.
  - ✅ `source: "\"Awaiting Customer\""` — quoted string literal, becomes `="Awaiting Customer"`.
  - ✅ `source: "false"`, `source: "30"` — boolean / numeric literal, becomes `=false` / `=30`.
  - ✅ `source: "GET"`, `source: "bearer"` — bare literal for Dropdown/Hidden bindings (e.g. HttpJson `method`, `authentication.type`). The reconciler keeps these literal — do **not** wrap them in quotes.
  - ✅ `source: ""` (empty) — when you genuinely cannot resolve the value. Stage 2 may still pin it via the annotation; if not, it lands as a review marker. Far better than fabricating prose.
  - ❌ `source: "Order Service GET /orders/{order_id} (mock http://localhost:8001)"` — descriptive prose. The reconciler's classifier rejects this (`kind: 'todo'`) and emits a review marker, but the bad guess waste tokens. Leave the source empty and let the annotation carry the implementation hint.
  - ❌ `source: "PATCH /sobjects/Case"` — verb + path is descriptive, not a value. Leave empty; annotation harvest can pin `method=PATCH` and `objectType=Case`.
  - ❌ `source: "secret/env-injected bearer token (unresolved)"` — natural language prefix `secret/env-injected ...` is not a FEEL expression. Use `source: "=secrets.AUTH_TOKEN"` if the secret name is known; otherwise leave empty.

  **Response output mapping (HttpJson family + any connector with a `resultExpression` header binding).** When the element's `note` describes the response shape — typical phrasings are `outputs A, B, C`, `returns A, B, C`, `computes Z = …`, `response: {…}` — emit a single `unresolvedInputs[]` entry with `target: "resultExpression"` and `source` set to a FEEL map literal: `={ A: body.A, B: body.B, C: body.C }`. The reconciler will recognise `resultExpression` as a `zeebe:taskHeader` binding and lift it into `<zeebe:taskHeaders>` automatically — do NOT also emit a separate input. If only field *names* are listed (no body-vs-process-variable hint), default each value to `body.<name>` for HttpJson; rename mismatched names that the phase doc explicitly aliases (e.g. annotation says `customer_email` but the doc renames it to `customerMail` → emit `customerMail: body.customer_email`).

  Same pattern applies to `errorExpression` when the annotation describes how non-2xx responses become BPMN errors (e.g. `5xx → bpmn:Error PAYMENT_DOWN`); emit `target: "errorExpression"` with the FEEL conditional. When the annotation is silent, leave both headers absent — better an empty result than a guess.

When an element has BOTH `zeebe:modelerTemplate` AND looks like a service-task worker candidate by name, prefer the connector binding — `preserveExistingConnectorBinding: true` on the worker side, or just emit a connector binding entry and skip the worker.

### Subprocess connector containers (`subProcess` / `adHocSubProcess` with `modelerTemplate`)

For each element with `type ∈ {subProcess, adHocSubProcess}` AND `modelerTemplate != null`:

These are template-bound containers — the canonical case is the AI Agent Sub-process (`io.camunda.connectors.agenticai.aiagent.jobworker.v1`). The parser surfaces `modelerTemplate` and `modelerTemplateVersion` directly on the element record (no need to grep the BPMN file). Emit a `connectorBindings[]` entry exactly as for `serviceTask`-bound connectors:

- `templateId` = `elements[i].modelerTemplate`
- `templateVersion` = `elements[i].modelerTemplateVersion` (numeric)
- `annotationText` = `elements[i].note`
- `sourceElementType` = `subProcess` or `adHocSubProcess` — preserved so Phase 3 doesn't accidentally rewrite the element as a `serviceTask`
- `wiring`:
  - `targetElementId` = element id
  - `preserveTemplateBinding` = `true`
  - `unresolvedInputs` — same shape as for serviceTask connectors (template inputs + taskHeader bindings + outputs)

No worker entry, no form entry. Phase 2.5 reconciles the template's inputs/outputs/headers like any other connector; the BPMN-side wiring helper preserves the existing XML structure (children of the subprocess are not touched).

### Exclusive gateways

Exclusive gateways are **not** independently translated to manifest entries. They are referenced from the matching `businessRuleTask` entry's `wiring.gatewayElementId` so `wire-execution-bpmn.mts` can **hard-fail if the gateway is missing**. The gateway's branch conditions themselves are authored by the transformation BPMN (process-flow logic); `wire-execution-bpmn.mts` does not synthesize them (§3.6's consolidated lint carries the guard that a diverging gateway has conditions or a default). If a gateway has no preceding `businessRuleTask` and the phase doc indicates a decision is needed, raise a review question rather than fabricating a decision.

### Receive tasks and message-correlation events

For each element with `type ∈ {receiveTask, intermediateCatchEvent, startEvent}` whose source BPMN carries (or whose semantics imply) a message reference, emit a `messageSubscription` entry. Only the receive/correlation cases need entries — a plain none-typed `startEvent` is irrelevant here.

Detection signals (any one of these):
- The element's name or `note` mentions waiting / receiving / correlating / arrival of a message (e.g. "Wait for customer reply", "Customer dispute email arrived").
- The source BPMN already declares a `<bpmn:messageEventDefinition>` child under the event, or a `messageRef` on a `<bpmn:receiveTask>`.
- The phase doc explicitly names a correlation key (e.g. "key: case_id", "correlate by orderId").

Emit a `messageSubscription` entry with the `correlationKey` when you can ground one — `wire-execution-bpmn.mts` adds the `<zeebe:subscription correlationKey>` to the referenced `<bpmn:message>`. The `<bpmn:message>` definition and the element's `messageRef` MUST already exist in the transformation BPMN (message-flow wiring is authored upstream); if the message is absent, surface a review question and skip the entry (never synthesize new top-level message elements).

Schema:

- `phase` = `PHASE_STEM`
- `elementId` = receive task / event id
- `sourceElementType` = one of `receiveTask` / `intermediateCatchEvent` / `startEvent`
- `messageRef` = id of the `<bpmn:message>` this element correlates against. Look it up via `messageRef=` already on the element, or via `<bpmn:messageEventDefinition messageRef="…">`. Must point at an existing top-level `<bpmn:message>` in the source BPMN.
- `messageName` = `name` attribute of the `<bpmn:message>` (human-readable label).
- `correlationKey` = the FEEL expression that selects the right process instance (e.g. `case_id`, `orderId`). Source it from the phase doc, the task's `note`, or the upstream event's annotation. **Do not invent a key** — if no evidence pins one, leave the field empty and add a review question.
- `confidence` = `high` when the correlation key is named explicitly in evidence; `medium` when inferred from context (e.g. only one upstream variable plausibly serves as a key); `low` when guessed.

Example:

```json
{
  "phase": "process-04-clarification",
  "elementId": "Task_WaitForCustomerReply",
  "sourceElementType": "receiveTask",
  "messageRef": "Message_CustomerReply",
  "messageName": "Customer reply",
  "correlationKey": "case_id",
  "confidence": "high"
}
```

## Step 3: Write output

Write `OUTPUT_PATH` with this shape — exactly one JSON object, no extra keys:

```json
{
  "phase": "<PHASE_STEM>",
  "bpmnFile": "<BPMN_FILE>",
  "processId": "<from ELEMENTS_PATH>",
  "workers": [
    {
      "phase": "<PHASE_STEM>",
      "bpmnFile": "<BPMN_FILE>",
      "elementId": "...",
      "elementName": "...",
      "sourceElementType": "serviceTask",
      "jobType": "...",
      "className": "...Worker",
      "wiring": { ... },
      "inputVariables": [{"name": "...", "type": "...", "confidence": "high|medium"}],
      "outputVariables": [{"name": "...", "type": "...", "confidence": "high|medium"}],
      "errors": [{"code": "...", "description": "...", "confidence": "high|medium", "source": "bpmn|inferred"}]
    }
  ],
  "forms": [ ... ],
  "decisions": [ ... ],
  "connectorBindings": [
    {
      "phase": "<PHASE_STEM>",
      "bpmnFile": "<BPMN_FILE>",
      "elementId": "...",
      "elementName": "...",
      "templateId": "io.camunda.connectors.aws.bedrock.v1",
      "templateVersion": 3,
      "annotationText": "<linked textAnnotation text or empty string>",
      "wiring": {
        "targetElementId": "...",
        "preserveTemplateBinding": true,
        "unresolvedInputs": [
          {"target": "data.modelId", "source": "\"anthropic.claude-3-5-sonnet-20241022\"", "confidence": "high"}
        ]
      }
    }
  ],
  "messageSubscriptions": [
    {
      "phase": "<PHASE_STEM>",
      "elementId": "Task_WaitForCustomerReply",
      "sourceElementType": "receiveTask",
      "messageRef": "Message_CustomerReply",
      "messageName": "Customer reply",
      "correlationKey": "case_id",
      "confidence": "high"
    }
  ]
}
```

Empty arrays are fine — write `[]` rather than omitting the key. The orchestrator's join step assumes all five arrays are present.

## Step 4: Report

```
Phase analysis: <PHASE_STEM>
  workers:    <N>
  forms:      <N>
  decisions:  <N>
  connectors: <N>
  written → <OUTPUT_PATH>
```

Be terse. The orchestrator surfaces the aggregated proposal to the user; per-phase output noise just delays the join step.
