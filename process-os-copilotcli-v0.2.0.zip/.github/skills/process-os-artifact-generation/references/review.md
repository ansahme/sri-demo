# Sub-Skill: Artifact Proposal Review

Present the artifact proposal to the user and iterate until they approve.

## Inputs

- `PROPOSAL` — path to the artifact proposal file (`process-implementation/artifacts/artifact-proposal.md`)
- `MANIFEST` — path to the manifest file (e.g. `process-implementation/artifacts/.manifest.json`)
- `UNATTENDED_MODE` — `unattended` or `normal` (passed by the orchestrator; overrides the config check when set to `unattended`)

## Unattended Mode Check

If `UNATTENDED_MODE=unattended` (passed by the orchestrator): output "Unattended mode active — skipping artifact review. Proceeding with generation." and return immediately. Do not execute Steps 1–3.

Otherwise check config:

```bash
node ".github/skills/process-os-artifact-generation/scripts/read-run-config.cjs" mode
```

Exit 2 → hard error: report stderr and stop; it means the reader failed, not that the key is unset.

If it prints `unattended`: output "Unattended mode active — skipping artifact review. Proceeding with generation." and return immediately.

## Step 1: Present proposal

Read `[PROPOSAL]` and output its full contents to the user.

Then add:

```
---
Review this proposal. You can:
  - Answer the numbered questions above
  - Correct any worker name, job type, variable name, or type
  - Change the proposed structure (single / call activities)
  - Add missing variables, fields, or error codes
  - Ask any question

Reply "proceed" (or just press Enter with no corrections) to start generation.
```

## Step 2: Process user response

Read the user's reply.

**If "proceed" (or equivalent approval):** Done. Return to orchestrator to start Phase 3.

**If corrections or questions:**

Apply each correction to `[MANIFEST]`:
- Renamed variable → find all occurrences in workers/forms/decisions, update name
- Type change → update `type` field on that variable/field
- Structural change (single ↔ call-activities) → update `structure.type` and `structure.reasoning`
- Added variable/field → append to the relevant worker/form
- Removed item → delete from manifest
- Question from user → answer it directly, then ask if the answer changes anything

After applying, regenerate the affected sections of `[PROPOSAL]` (keep the unchanged sections, update only what changed) and re-present to the user with a short summary:

```
Updated:
  - [list what changed]

Here is the revised proposal:
[updated sections only]

Anything else to adjust, or shall we proceed?
```

## Step 3: Loop

Repeat Step 2 until the user approves. There is no loop limit — take as many rounds as needed.
