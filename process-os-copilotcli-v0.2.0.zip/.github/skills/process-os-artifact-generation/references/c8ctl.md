# c8ctl — Camunda 8 CLI for Agents

`c8ctl` (alias `c8`) is the agent-friendly Camunda 8 control plane: install/start a local cluster, deploy resources, run process instances, query state, resolve incidents — all with structured output the agent can parse.

Source: <https://github.com/camunda/c8ctl>

## Install

```bash
npm install -g @camunda8/cli
```

Requires Node.js >= 22.18.0. The binary is on `PATH` as both `c8ctl` and `c8`. Throughout the plugin's skills we use `c8ctl` for clarity.

## Set output mode once per session

```bash
c8ctl output json
```

Switches the persisted preference to JSON. Every subsequent `list`, `get`, `search`, `create`, `await`, etc. returns JSON to stdout — agent-parseable. Switch back with `c8ctl output text`.

Always set this before invoking c8ctl from a skill so downstream `node -e` parsing works without surprises.

## Stream contract — read this before parsing any c8ctl output

**c8ctl writes progress and status to stderr even when a call succeeds.** Three rules follow, and breaking any of them turns a healthy call into a reported failure:

1. **The exit code is the only success signal.** Never treat non-empty stderr as failure. `c8ctl deploy` narrating what it uploaded is not an error.
2. **Never merge the streams.** No `2>&1` into a pipe or a capture: the progress lines land in front of the JSON and the parse fails, or worse, succeeds on the wrong thing. Capture stdout and stderr separately (`stdio: ['ignore', 'pipe', 'pipe']`) and parse stdout alone. When you don't need to parse at all, inherit stdio and let both streams through untouched.
3. **A call that did not launch is neither success nor failure.** `result.error`, `result.status === null`, or empty stdout *and* stderr on a non-zero exit means c8ctl never ran. Report that as its own outcome — never as the tool's own exit code, and never as "no results". On native Windows this is the common case for a naive spawn: c8ctl installs as a global npm bin, so the executable is `c8ctl.cmd`, which `spawnSync`/`execFileSync` cannot exec without a shell. Use the `runShellCli` helper in [`scripts/resolve-node-cli.cjs`](../scripts/resolve-node-cli.cjs), which resolves it per platform and still reports "not on PATH" itself.

There is one more trap that is not c8ctl's doing. **Windows PowerShell 5.1 treats *any* native-command stderr output as an error record** — with `$ErrorActionPreference = 'Stop'` a successful c8ctl call surfaces as `NativeCommandError` and exit 255. And a 5.1 pipe encodes with `$OutputEncoding`, whose standard remedy emits a UTF-8 byte-order mark that makes `JSON.parse` throw on the leading `﻿`.

**`c8ctl --version` is the one command whose stream flips with the persisted output preference.** In text mode it prints the version to stdout; when the preference is JSON (`c8ctl output json`), it prints the version to stderr and leaves stdout empty — still exiting 0. So a version check must read stdout *and* stderr, preferring stdout and falling back to stderr, rather than keying off stdout alone. [`scripts/check-c8ctl-version.cjs`](../scripts/check-c8ctl-version.cjs) does exactly this. This is specific to `--version`; the data commands still emit their JSON to stdout, so rule 2 above stands for everything you parse.

So **prefer running c8ctl from inside a `.cjs` script over piping it in a shell step.** A script owns both streams, keys off the exit code, and puts no shell in the pipeline. [`scripts/c8ctl-wait-state-support.cjs`](../scripts/c8ctl-wait-state-support.cjs) is the worked example — it replaced a `c8ctl --json get topology | node -e "…"` prose pipe that failed both ways. When a pipe is genuinely unavoidable, strip a leading BOM with [`scripts/strip-bom.cjs`](../scripts/strip-bom.cjs).

## Passing `--variables` safely

Every command that takes `--variables` (`create pi`, `await pi`, `complete job`, `complete ut`, `publish msg`, `correlate msg`, `set variable`) accepts three forms:

- Inline JSON: `--variables '{"x": 1}'` — fine for a short, known-safe payload typed directly into the command.
- A file reference: `--variables @path/to/vars.json` — c8ctl reads, parses, and validates the file itself.
- Stdin: `--variables @-`.

**Prefer `@path` whenever the payload already exists as a file**, e.g. a job skill's outbound-variables file under `.camunda/job-outputs/`. It reads the JSON from disk and validates it is an object, so there is nothing to quote or escape — no single- vs double-quote choice, no per-shell rule for a literal `'` inside a free-text value. Building the JSON inline and substituting it into `--variables '<json>'` is the pattern to avoid once a file already holds the payload; `process-os-governance-job-completion` uses `@path` for exactly this reason.

## Cluster plugin (default; manages local C8 Run)

| Command | What it does |
|---------|-------------|
| `c8ctl cluster start [version]` | Start the latest stable (or specific version like `8.9`, `alpha`) |
| `c8ctl cluster stop` | Stop the running cluster |
| `c8ctl cluster status` | Is anything running, and on which version |
| `c8ctl cluster logs` | Stream broker logs |
| `c8ctl cluster install <version>` | Pre-download a version |
| `c8ctl cluster delete <version>` | Remove a cached version |
| `c8ctl cluster list` | Locally-cached versions |
| `c8ctl cluster list-remote` | Available versions |

Version aliases: `stable`, `alpha`, or `<major>.<minor>` (e.g. `8.9`).

The cluster plugin is active by default — no install/load step needed.

## Deploy + run

```bash
c8ctl deploy <folder-or-file>     # deploy BPMN/DMN/Forms; atomic
c8ctl run <bpmn-file>             # deploy + start an instance in one shot
```

`c8ctl deploy process-implementation/artifacts/src/main/resources/processes process-implementation/artifacts/src/main/resources/forms process-implementation/artifacts/src/main/resources/decisions` is the typical path after `/process-os-artifact-generation`. Do NOT pass `process-implementation/artifacts/src/main/resources` as a single argument: Spring Boot starter projects keep `application*.yaml` at the resources root, and c8ctl rejects those as "unknown resource type" — atomic deploy then fails for the whole call.

For a Spring Boot bundle that auto-deploys on app startup, `c8ctl deploy` is redundant — start the app instead. Use c8ctl deploy when there's no app context (e.g. just the BPMN files, no Java module).

## Process instances

| Command | Purpose |
|---------|---------|
| `c8ctl create pi --id <bpmnProcessId>` | Start an instance, return immediately |
| `c8ctl create pi --id <bpmnProcessId> --variables '{...}'` | …with starting variables |
| `c8ctl await pi --id <bpmnProcessId>` | Start an instance and block until it terminates |
| `c8ctl get pi <key>` | Snapshot of a single instance (state, variables, current activities) |
| `c8ctl list pi` | All instances (use `--fields` to trim) |
| `c8ctl search pi --filter '...'` | Server-side filtered list |
| `c8ctl cancel pi <key>` | Terminate a stuck instance |

`--id` is the `<bpmn:process id="…">` value (BPMN process ID), not the numeric process-definition key. Use `--processDefinitionId` / `--processDefinitionKey` for the numeric form.

`c8ctl await pi` is the autonomous-loop friendly verb: one call returns the terminal state.

## Incidents (debugging stuck instances)

| Command | Purpose |
|---------|---------|
| `c8ctl list inc` | All open incidents across the cluster |
| `c8ctl list inc --filter '{"processInstanceKey": "<key>"}'` | Incidents on one instance |
| `c8ctl get inc <key>` | Full incident detail (error message, type, element instance) |
| `c8ctl resolve inc <key>` | Mark resolved after fixing the underlying job |

Typical loop: start an instance with `c8ctl await pi --id …`; on FAILED state, `c8ctl list inc --fields processInstanceKey,errorMessage,elementId` to find the culprit; trace `elementId` back to a `*Worker.java` and fix; restart the worker process; `c8ctl resolve inc <key>`; the instance retries.

## Other commands worth knowing

| Command | Purpose |
|---------|---------|
| `c8ctl list ut` / `search ut` / `complete ut` | User tasks |
| `c8ctl list jobs` / `activate jobs` / `complete job` / `fail job` | Direct job management (rare; workers normally do this) |
| `c8ctl get topology` | Broker topology |
| `c8ctl publish msg --name <name> --correlationKey <ck>` | Publish a message |
| `c8ctl correlate msg --name <name>` | Synchronous message correlation |
| `c8ctl set variable <pi-key> --variables '{...}'` | Mutate variables on a running instance |
| `c8ctl open operate \| tasklist \| modeler \| optimize` | Open the right UI for the active profile |

## Job activation (governance job skills)

`c8ctl activate jobs <jobType>` pulls pending jobs from the broker. The governance bridge
(`process-os-governance-job-activation`) relies on these flags:

| Flag | Purpose |
|------|---------|
| `--maxJobsToActivate <n>` | Cap how many jobs are activated in one call (governance uses `1`) |
| `--timeout <ms>` | Job-lock duration in milliseconds |
| `--worker <name>` | Worker identity recorded on the activated job |
| `--customHeaders` | Include each service task's `zeebe:taskHeaders` in the output (this is how `skillName` reaches the activator). |
| `--fetchVariable <names>` | Server-side variable filter — return only the named process variables, not the whole payload. Takes **one comma-separated value** (`--fetchVariable skillInput,runConfig`). A job without a named variable simply omits it (not an error). |

```bash
c8ctl --json activate jobs <jobType> --maxJobsToActivate 1 --timeout 3600000 \
  --worker process-os --customHeaders --fetchVariable skillInput,runConfig [--profile <name>]
```

**Never repeat `--fetchVariable` to request several variables.** c8ctl does not accumulate repeated
occurrences of the flag — each overwrites the last, so three occurrences send only the third name
and the rest are dropped before the request leaves the CLI. The failure is silent and looks like
missing data: the response omits the variables that were never asked for, which is indistinguishable
from a job that genuinely does not carry them. `--dry-run` prints the exact request body without
executing, and is how to confirm a multi-variable fetch really asked for all of them:

```bash
c8ctl --json activate jobs <jobType> … --fetchVariable skillInput,runConfig,skillMode --dry-run
# body.fetchVariable must list every name: ["skillInput","runConfig","skillMode"]
```

Note the singular spelling: `create process-instance` takes a plural `--fetchVariables` instead.

## Agent flags

Two flags designed for programmatic use; both work on every command.

`--dry-run` — print the planned API request as JSON without executing:

```bash
c8ctl create pi --id Process_Foo --variables '{"x": 1}' --dry-run
```

Returns `{ "dryRun": true, "command": "create process-instance", "method": "POST", "url": "…", "body": { … } }`. Useful for verifying flag interpretation before committing.

`--fields <comma-list>` — trim the response to just the named fields (case-insensitive). Cuts context-window cost on large list responses:

```bash
c8ctl list pi --fields processInstanceKey,bpmnProcessId,state
c8ctl list inc --fields key,errorMessage,elementId,processInstanceKey
```

## Profile resolution

Credential and endpoint resolution order:

1. `--profile <name>` flag override
2. Active session profile (`c8ctl use profile <name>`)
3. Environment variables (`CAMUNDA_*`)
4. Default `local` profile pointing at `http://localhost:8080/v2`

For local C8 Run started via `c8ctl cluster start`, the default profile already points at the right place — no setup needed.

For SaaS, set up a profile once with `c8ctl add profile <name>` (interactive prompts for cluster ID, client ID, secret), then `c8ctl use profile <name>`. See `env-saas.md`.

## Open the right UI

Each profile knows its companion URLs. From a running session:

```bash
c8ctl open operate     # process inspection
c8ctl open tasklist    # user task UI
c8ctl open modeler     # web modeler (SaaS) — no-op for local
c8ctl open optimize    # KPI dashboards
```
