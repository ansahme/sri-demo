# Job Worker Architecture & Conventions

Source: `templates/solution/project-blueprints/java/engagement-blueprint/`

All rules below are enforced automatically via ArchUnit. Violations fail the build.

## Package Structure

```
com.<customer>.blueprint/
├── workers/       @Component classes with @JobWorker methods
├── services/      @Service classes with business logic
├── clients/       @HttpExchange interfaces (HTTP clients)
├── models/        POJOs / records for process variables and DTOs
├── config/        @Configuration and @ConfigurationProperties
│   └── properties/  @ConfigurationProperties records
└── exceptions/    Custom exception types
```

## Layer Dependency Rules

```
Workers  →  Services, Models, Config, Exceptions
Services →  Clients, Models, Config, Exceptions
Clients  →  Models
Config   →  Services, Clients, Models
Models   →  (nothing internal)
```

- Workers are not accessible by any other layer
- Services are only accessed by Workers and Config
- Clients are only accessed by Services and Config

Enforced by `LayerArchitectureTest.java`:

```java
layeredArchitecture()
    .layer("Workers").definedBy("..workers..")
    .layer("Services").definedBy("..services..")
    ...
    .whereLayer("Workers").mayNotBeAccessedByAnyLayer()
    .whereLayer("Services").mayOnlyBeAccessedByLayers("Workers", "Config")
    .whereLayer("Clients").mayOnlyBeAccessedByLayers("Services", "Config")
```

## Annotation Conventions (Enforced)

| Class naming | Required annotation | Package |
|-------------|--------------------|---------| 
| `*Worker` | `@Component` | `..workers..` |
| `*Service` | `@Service` | `..services..` |
| `*Client` | — | `..clients..` |
| `*Properties` | `@ConfigurationProperties` | `..config..properties..` |

Enforced by `StereotypeConventionTest.java`.

## Forbidden Patterns (Enforced)

### No Field Injection

```java
// FORBIDDEN
@Autowired
private ExternalApiAService service;

// REQUIRED
@RequiredArgsConstructor
public class TaskAWorker {
    private final ExternalApiAService service;  // constructor-injected
}
```

Enforced by `AnnotationUsageTest.java`:

```java
fields().should().notBeAnnotatedWith(Autowired.class)
```

### @JobWorker Only in workers Package

`@JobWorker` methods must reside in classes within `..workers..` package.

```java
// FORBIDDEN in services/, config/, etc.
@JobWorker(type = "A")
public void handleA(...) { }

// REQUIRED: only in workers/ package
```

### @ConfigurationProperties Only in config Package

```java
// FORBIDDEN in workers/, services/
@ConfigurationProperties(prefix = "blueprint")
public record SomeProps(...) {}

// REQUIRED: only in config/ or config/properties/
```

## Naming Conventions

- Worker classes: `<TaskName>Worker` (e.g., `TaskAWorker`, `InvoiceWorker`)
- Service classes: `<Domain>Service` (e.g., `ExternalApiAService`, `InvoiceService`)
- Client interfaces: `<Domain>Client` (e.g., `ExternalApiAClient`)
- Properties records: `<Domain>Properties` (e.g., `BlueprintProperties`)
- Process variable DTOs: `ProcessVariables` (one per process / bounded context)

## ArchUnit Test Classes

| Test Class | Enforces |
|-----------|---------|
| `AnnotationUsageTest` | @JobWorker placement, no @Autowired field injection, @ConfigurationProperties placement |
| `LayerArchitectureTest` | Allowed dependencies between layers |
| `StereotypeConventionTest` | @Component on *Worker, @Service on *Service, @ConfigurationProperties on *Properties |

All tests use `@ArchTest` static fields — no test method needed, just field declaration.

## Spring Boot Entry Point

```java
@SpringBootApplication
@ConfigurationPropertiesScan   // required for @ConfigurationProperties records
public class BlueprintApplication {
    public static void main(String[] args) {
        SpringApplication.run(BlueprintApplication.class, args);
    }
}
```

`@ConfigurationPropertiesScan` must be present or properties records are not registered.

## Virtual Threads

```yaml
spring:
  threads:
    virtual:
      enabled: true
```

Enable virtual threads (Java 21+) for better throughput under blocking I/O in workers.

## Error Handling Pattern

Services throw typed exceptions:

```java
throw new ExternalApiException("Failed to process via external API A");
```

Workers do not catch exceptions — the Zeebe client retries the job on failure according to retry configuration in the BPMN `<zeebe:taskDefinition retries="3" />`.

For explicit failure handling (e.g., permanent errors):

```java
@JobWorker(type = "A", autoComplete = false)
public void processA(JobClient client, ActivatedJob job) {
    try {
        // ...
        client.newCompleteCommand(job.getKey()).variables(result).send().join();
    } catch (PermanentException e) {
        client.newFailCommand(job.getKey())
            .retries(0)                   // no more retries
            .errorMessage(e.getMessage())
            .send().join();
    }
}
```
