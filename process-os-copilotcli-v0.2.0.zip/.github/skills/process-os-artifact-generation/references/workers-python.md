# Sub-Skill: Generate Python Workers

The `python` overlay on [the workers spine](references/generate-workers.md). Read the spine first — it
owns the inputs, the timing instrumentation, Step 1's scaffold, and the report.

**No subagent runs for this SDK.** The per-SDK content is one script invocation, so nothing here needs
an agent's judgement, and dispatching one reintroduces the failure mode SKILL.md documents: a subagent
can return before it reaches its own gate. Whoever executes Phase 3 runs the command below directly.

## Step 2: Generate the worker layer (script, no agent)

```bash
node ".github/skills/process-os-artifact-generation/scripts/generate-workers-python.cjs" process-implementation/artifacts
```

One deterministic pass over `process-implementation/artifacts/.manifest.json`. The script groups `manifest.workers[]` by
unique `jobType`, because Camunda dispatches work by job type and exactly one worker may subscribe to
one job type. The manifest legitimately carries several entries for one job type, since the same
service task recurs across process phases. Each group's inputs, outputs and declared BPMN error codes
combine.

The script writes:

```text
process-implementation/artifacts/<package>/
  app.py                          regenerated: the registry main.py consumes
  models/process_variables.py     regenerated: the all-optional union, plus one input
                                   and one output model per job type
  errors/
    bpmn_errors.py                regenerated: omitted when no job type declares an error code
    service_error.py              regenerated: the error a service raises, carrying a code
  services/<job>_service.py       preserved: an async stub behind a TODO, written once per
                                   job type and left exactly as a developer leaves it after that
  workers/<job>_worker.py         regenerated: one per job type: validate, call, complete, translate
```

`<package>` is the manifest's `processSlug` converted to a legal Python identifier, so two generated
bundles never both install as the same generic top-level package.

Three blueprint-owned files sit beside the generated layer and never change: `workers/worker_defaults.py`,
`clients/http_client.py`, and `errors/external_api_error.py`. `main.py`, `shutdown.py`, `config/` and
`observability/` are the blueprint's too. Every `__init__.py` survives.

An input is required only when every manifest entry for that job type declares it. Every output is
optional, which is what lets the generated stub return an empty output model.

A generated field name follows Python convention, and a Pydantic alias carries the manifest's own
variable name. `case-id` becomes `case_id` with `alias="case-id"`, so the process contract does not
move: the model validates and serializes under the name the BPMN declares.

### Re-running is safe

Every `regenerated` file above is removed and rewritten on each pass, so a job type that leaves the
manifest takes its worker with it; the script reports each removal. `services/<job>_service.py` is
the one exception: it is the file the skill's own Report section names as manual work ("implement the
domain logic"), so the script writes it only when it is absent and leaves it exactly as it finds it
otherwise. A job type that leaves the manifest still takes its stale service stub with it, the same as
its worker — a stub with no job type behind it registers nothing and would read as real. A second run
over an unchanged manifest, with no service stub hand-edited, produces byte-identical output; run it
again after hand-editing a stub, and that file survives byte-for-byte while every regenerated file
around it still gets rewritten from the current manifest.

**Exit codes** (the script's own `EXIT` constants):

| Code | Constant | Meaning and what to do |
|---|---|---|
| `0` | `EXIT.OK` | Every file written. Continue. |
| `2` | `EXIT.USAGE` | `process-implementation/artifacts/.manifest.json` is absent or does not parse, or two entries for one job type disagree on `className`. Nothing was written. Stop: either the run sits at the wrong point, or the manifest needs a fix. |
| `3` | `EXIT.ILLEGAL_STEM` | A job type derives no legal Python identifier, because it holds no alphanumeric content or it starts with a digit (`2fa-check`). The message names every offender. Nothing was written. Rename the BPMN element or the manifest `jobType`, then run the script again. |
| `4` | `EXIT.STEM_COLLISION` | Two distinct job types collapse onto one Python stem. The message names every colliding pair. Nothing was written. Rename one of each pair, then run the script again. Generated output would otherwise carry one worker for two job types and leave the second permanently without a subscriber. |
| `5` | `EXIT.VARIABLE_NAME` | A variable name derives no Python field name, or two distinct variable names derive one field name in the same model. One Python attribute carries one alias, so the script does not pick a name the process never declares. The message names every offending variable and the field they collide on. Nothing was written. Rename the process variable, then run the script again. |
| `6` | `EXIT.STUB_UNREADABLE` | An existing `services/<job>_service.py` could not be read (a permission error, or another kind of I/O failure). This is not the same state as an absent stub, which the script writes normally — nothing was written or removed here. Fix the file (or its permissions) and run the script again. |

Any non-zero exit is a **stop**, not a skip. Every check runs — including a read of every service
stub's on-disk state — before the first write or deletion, so a rejected manifest, or an unreadable
stub, leaves the tree exactly as it was.

## Step 3: The build gate

There is no automated build gate for Python yet — `python.buildGate` is `null` in the capability
table, so SKILL.md's build-gate step reports `build gate: skipped — no build gate for SDK python` and
continues. Until that lands, verify the generated bundle by hand with these five commands, each read on
its own exit code:

```bash
node ".github/skills/process-os-artifact-generation/scripts/run-uv.cjs" process-implementation/artifacts sync --frozen
```

```bash
node ".github/skills/process-os-artifact-generation/scripts/run-uv.cjs" process-implementation/artifacts run ruff check .
```

```bash
node ".github/skills/process-os-artifact-generation/scripts/run-uv.cjs" process-implementation/artifacts run ruff format --check .
```

```bash
node ".github/skills/process-os-artifact-generation/scripts/run-uv.cjs" process-implementation/artifacts run mypy
```

```bash
node ".github/skills/process-os-artifact-generation/scripts/run-uv.cjs" process-implementation/artifacts run lint-imports
```

Every command goes through the runner rather than a bare `uv`, and the runner passes the project
directory to the child as its cwd, so a caller never repeats uv's own `--directory` flag. A bare `uv`
in a chained shell command breaks on native Windows twice over, at the `cd X && Y` subshell and at the
`&&` itself. Each command is its own invocation, because one chained call collapses five verdicts into
one.

`pyproject.toml` and `uv.lock` stay the dependency anchors, and `--frozen` fails rather than
re-resolving them.

There is deliberately **no toolchain-absent skip**. A python target installs its bundle with uv, and
`pyproject.toml` and `uv.lock` are a locked unit no other tool installs, so a missing uv leaves no way
to run the gate at all. A gate that reported green on a machine where it never ran would describe
a bundle nobody observed.

`pytest` is deliberately absent from this list. The scaffold drops the blueprint's example-domain
tests, so a generated project holds no test of its own, and the one test that travels with the scaffold
shells out to `lint-imports`, which the list above already runs.
