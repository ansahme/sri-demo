# Sub-Skill: Generate TypeScript Workers

The `typescript` overlay on [the workers spine](references/generate-workers.md). Read the spine first —
it owns the inputs, the timing instrumentation, Step 1's scaffold, and the report.

**No subagent runs for this SDK.** The per-SDK content is one script invocation, so there is nothing
for an agent to decide, and dispatching one would reintroduce the failure mode SKILL.md documents: a
subagent can return before reaching its own gate. Whoever executes Phase 3 runs the command below
directly.

## Step 2: Generate the worker layer (script, no agent)

```bash
node ".github/skills/process-os-artifact-generation/scripts/generate-workers-typescript.cjs" process-implementation/artifacts
```

One deterministic pass over `process-implementation/artifacts/.manifest.json`. It groups `manifest.workers[]` by unique job
type — Camunda dispatches work by job type, so exactly one worker implementation may exist per job
type, and the manifest legitimately carries several entries for one because the same service task
recurs across phases — and writes:

```text
process-implementation/artifacts/src/
  app.ts                        regenerated: the worker registry main.ts consumes
  models/process-variables.ts   regenerated: the all-optional union schema plus one
                                 required input schema per job type
  errors/
    bpmn-errors.ts              regenerated: omitted when no job type declares an error code
    service-error.ts            regenerated: one error class carrying a code
  services/<job>-service.ts     preserved: output type + `// TODO: implement` stub, written
                                 once per job type and left exactly as a developer leaves it
                                 after that
  workers/<job>-worker.ts       regenerated: one per job type: validate, call, complete,
                                 translate errors
```

`src/clients` receives nothing — neither generated files nor an empty directory. `job-handler.ts` and
`worker-defaults.ts` under `src/workers/` come from the blueprint copy, not from this script.

### Re-running is safe

Every `regenerated` file above is rewritten on each pass. `services/<job>-service.ts` is the one
exception: it is the file the skill's own Report section names as manual work ("implement the domain
logic"), so the script writes it only when it is absent for that job type and leaves it exactly as it
finds it otherwise. A second run over an unchanged manifest, with no service stub hand-edited,
produces byte-identical output; run it again after hand-editing a stub, and that file survives
byte-for-byte while every regenerated file around it — `app.ts`, `models/process-variables.ts`, the
worker classes, the error types — still gets rewritten from the current manifest.

**Exit codes** (the script's own `EXIT` constants):

| Code | Constant | Meaning and what to do |
|---|---|---|
| `0` | `EXIT.OK` | Every file written. Continue. |
| `2` | `EXIT.USAGE` | `process-implementation/artifacts/.manifest.json` is missing or does not parse. Nothing was written. Stop — the run is at the wrong point, or the manifest is corrupt. |
| `3` | `EXIT.ILLEGAL_STEM` | A job type does not derive a legal TypeScript identifier — it has no alphanumeric content, or it starts with a digit (`2fa-check` → `2faCheck`). The message names every offender. Nothing was written. Rename the BPMN element or the manifest `jobType`, then re-run. |
| `4` | `EXIT.STEM_COLLISION` | Two distinct job types collapse onto one generated file name or identifier. The message names every colliding pair. Nothing was written. Rename one of each pair, then re-run — writing anyway would emit one worker for two job types and leave the second permanently without a subscriber. |
| `5` | `EXIT.STUB_UNREADABLE` | An existing `services/<job>-service.ts` could not be read (a permission error, or another kind of I/O failure). This is not the same state as an absent stub, which the script writes normally — nothing was written here. Fix the file (or its permissions) and re-run. |

Any non-zero exit is a **stop**, not a skip. Every service stub's on-disk state is read before the
first write, so a rejected manifest, or an unreadable stub, leaves the tree exactly as it was.

## Step 3: The build gate

The gate runs at the **orchestrator level**, not here — see SKILL.md's Build gate step, which owns the
single readable per-SDK branch. It is four commands: install, typecheck, build, and the blueprint's
dependency-cruiser rules. There is deliberately **no toolchain-absent skip**: npm ships with Node, and
this skill already requires Node to run its own `.cjs` scripts, so a missing npm is never a legitimate
toolchain gap — only a broken Node install, which is exactly the state Phase 3 should stop on.

Two of the blueprint's scripts are deliberately **not** in the gate, both because they would pass
without asserting anything about the generated bundle. `npm test` is a vacuous success: a generated
project contains no test files, and the scaffold patches `passWithNoTests: true` into `vitest.config.ts`
so a user who runs it does not hit a hard failure. `npm run check` is the blueprint's non-mutating lint
pass (`biome check .`, as against the mutating `npm run fix`), and the generator already emits to
`biome.json`'s formatting — a formatting drift is not a reason to red-light a build.

**Known gap: `test:arch` currently passes vacuously.** The blueprint pins `dependency-cruiser@18.1.0`,
which supports `typescript<7.0.0`, alongside `typescript@7.0.2`. Depcruise degrades instead of failing:
it cruises 0 modules and exits `0`, printing a `missing-typescript-transpiler` warning on stderr. Treat
that warning as expected, not as a new failure — the layering rules in `.dependency-cruiser.mjs` are not
actually verified until the blueprint's pins are fixed. This is a version-pin mismatch in the
blueprint itself, not something to fix per-generation.
