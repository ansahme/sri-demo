# Edit pass: resolve feedback into targeted edits

This is the edit-pass path of `/process-os-artifact-generation`, reached only when `<PASS_KIND>` is
`EDIT` — an earlier generation pass ran to completion, so `process-implementation/artifacts/` holds
a tree worth editing and the design behind it has not changed. `SKILL.md`'s Setup step has already
listed what is pending in `process-implementation/feedback/` with `scripts/feedback-ledger.cjs` and
captured that count as `<PENDING_COUNT>`; this file starts from that listing rather than re-running
it.

The listing holds only entries no earlier pass resolved (`NEW`) and entries whose content has
changed since one did (`CHANGED`). An entry an earlier pass resolved is not in it at all, so
nothing here re-applies a request a developer may have since edited away.

Regenerating the tree from the manifest would reproduce the same output the feedback is reacting to
and discard whatever this pass edits into it, so nothing here runs Phase 1's analysis or Phase 3's
generators. Every change in this phase is a direct edit to an existing file, scoped to exactly what
a feedback entry names — nothing else under `process-implementation/artifacts/` is opened.

## AI: Step 1 — Nothing to resolve

`<PENDING_COUNT>` of `0` means every entry a reviewer has left is already resolved — an ordinary
outcome for an edit pass, not an error. Print:

```
Edit pass. No feedback to resolve.
```

and stop; there is nothing further for this run to do.

## AI: Step 2 — Read every feedback entry

For each entry Setup listed as pending, read `process-implementation/feedback/<entry>`:

- Already text (`.md`, `.txt`, `.json`, `.yaml`, source files, a hand-edited `.bpmn`, …) → read it
  directly.
- Binary or non-narrative (`.pdf`, `.docx`, `.pptx`, images, …) → make a genuine effort to extract
  its text before treating it as unreadable — the toolchain available depends on the runtime, so
  probe for a converter or library and try it rather than skipping the file on sight.
- A **read failure** — a permission error, an unreadable encoding, an I/O error on a file the
  listing just confirmed exists — is not "no feedback," the same as `feedback-ledger.cjs`'s own
  exit `5` for an entry it cannot read: stop the whole run and report the entry and the error,
  rather than silently excluding it from resolution.
- A file that reads fine but carries nothing actionable (a genuinely opaque binary, an empty file)
  is not a read failure — carry it into Step 3 as its own case rather than stopping here.

A `CHANGED` entry is a note an earlier pass resolved and a reviewer has since added to. It is read
whole, because the request they added is not separable from the rest, so treat what is already
satisfied in the tree as satisfied: resolve what the entry asks for now, and leave a span that
already reads the way it asks alone.

## AI: Step 3 — Resolve each entry to what it implicates

For each entry read in Step 2, work out what it is about and which file, if any, in
`process-implementation/artifacts/` that maps to.

**Identify the subject.** A feedback entry names things by business meaning, not by file path — a
job type, a BPMN element or task name, a decision or form's own label, a config or client value, or
a note about `artifact-proposal.md`'s own wording. Cross-reference the name against
`process-implementation/artifacts/artifact-proposal.md`'s tables (Service Tasks → Workers, Business
Rule Tasks → DMN Decisions, User Tasks → Forms) and `process-implementation/artifacts/.manifest.json`
(`workers[].jobType`/`className`, `decisions[].decisionId`, `forms[].formId`) to recover the
matching identifier.

**Locate the file.** Search `process-implementation/artifacts/` for that identifier in whichever
form the bundle's own file and class names already use (kebab, snake, or Pascal) under `services/`,
`workers/`, `decisions/`, `forms/`, `config/`, or `clients/`. A request whose only ask is a
correction to `artifact-proposal.md`'s own wording resolves to that file directly — with Phase 1
skipped, nothing later regenerates its prose out from under a hand edit.

**When nothing matches, or the request asks for more than a hand edit can express**, do not guess
and do not force a resolution:

- No identifiable subject, or the entry is acknowledgment with no requested change → not
  actionable; nothing to edit for it.
- A change that needs more than an edit to a generated file or to a service stub's own body — a new
  dependency, a different framework or persistence layer, a refactor spanning several service
  stubs, a hand-written class that is not a service stub, or a change to a worker's own structure
  rather than to what its service does — is more than this pass can carry out. From here the
  generated project is maintained the way any other software project is, through its own commits
  and review in its own repository. Report it as out of scope for an edit pass rather than
  attempting it.

Carry the resolution for every entry — the file(s) to edit, or the reason it has none — into Step 4.

## EXEC: Step 4 — Apply the edits, touching nothing else

Apply every resolution from Step 3 with your file-editing tool, one entry at a time, changing only
the span each one implicates. A file no entry's resolution named is not opened at all, let alone
rewritten — this is the property that distinguishes an edit pass from a generation pass.

**Never invoke a Phase 1 or Phase 3 script from this pass** — `scripts/analyze-proposal.cjs`,
`scripts/generate-dmn.cjs`, `scripts/generate-forms.cjs`, `scripts/wire-execution-bpmn.mts`,
`scripts/generate-parent-bpmn.ts`, and `scripts/scaffold-workers.cjs` (directly or through the
workers spine) all write their whole output class unconditionally from the current manifest —
exactly the behavior this pass exists to avoid.

## EXEC: Step 5 — Record what this pass resolved

Mark every entry Step 2 read as resolved, naming each one — those Step 4 edited, and those Step 3
judged not actionable or out of an edit pass's scope alike. All of them have had their verdict, and
an entry left unrecorded is resolved again by the next pass.

One quoted argument per entry name, in a single call:

```bash
node ".github/skills/process-os-artifact-generation/scripts/feedback-ledger.cjs" record "<ENTRY-1>" "<ENTRY-2>"
```

`RESOLVED <name>` per entry, or `ALREADY <name>` for one already on record at that content. Exit
`2` names an entry the feedback listing does not hold; exit `5` means the ledger or the completion
marker is there but unusable. Either way, stop and report it — the edits are already applied, and a
pass that cannot record them would re-resolve the same entries next time.

A reviewer who disagrees with how an entry was resolved re-raises it by editing that entry, which
brings it back as `CHANGED` on the next pass.

## AI: Step 6 — Report what changed

Print the run's own report — a silent edit pass is indistinguishable from one that did nothing:

```
Edit pass complete.

Feedback resolved: <PENDING_COUNT> file(s)
Files edited: <list of paths, or "none">
Not actionable: <list of entry names, each with its one-line reason, or "none">
```

List every entry from Step 2 in one of the two lists, never dropped silently — an entry Step 3
judged not actionable, or out of an edit pass's scope, belongs in "Not actionable" with its reason.
