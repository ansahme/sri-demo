# Sub-Skill: Generate Java Spring Boot Workers

The `java-spring-boot` overlay on [the workers spine](references/generate-workers.md). Read the spine
first — it owns the inputs, the timing instrumentation, Step 1's scaffold, and the report. This file
owns the fan-out and the gate.

The two reference files in this directory describe the canonical patterns:

- **[Worker layering / ArchUnit rules](references/job-worker-architecture.md)** — package structure,
  layer dependency rules, ArchUnit constraints, naming conventions. **All rules below are enforced by
  the ArchUnit tests this skill generates.**
- **[Worker implementation guidance](references/job-worker-implementation.md)** — worker / service /
  client / configuration patterns with full code examples. Treat as the source of truth for class
  shape.

## Step 2: Batched worker fan-out (parallel)

Each `worker` in `manifest.workers[]` needs its `*Worker.java`, `*Service.java`, and typed `*Exception.java` files. The worker entry is self-contained, so the work is embarrassingly parallel — **but do NOT dispatch one agent per worker.** A worker is a tiny fixed template; one-agent-per-worker floods the harness's per-session subagent cap (`CLAUDE_CODE_MAX_SUBAGENTS_PER_SESSION`, default 200): a single large process (80+ workers) plus the Phase-1 analyze and Phase-3 BPMN fan-outs already approaches it, and a multi-tier run blows past it — later phases then get zero agents and silently fall back to serial in-agent generation. Batch instead.

Skip the fan-out entirely when `manifest.workers` is empty — Step 3 mvn gate still runs.

**Batching.** Split the `N` workers into `min(8, N)` contiguous index slices (so at most 8 agents regardless of worker count). Dispatch one agent per non-empty slice, all in a single tool message; each agent loops the [Worker class template](references/generate-worker-class.md) over every index in its slice. Wait for all to return before proceeding.

Per-batch prompt:

```
Read references/generate-worker-class.md and follow it for EACH worker index below, in order.
WORKER_INDICES: <comma-separated indices, e.g. 0,1,2,3,4,5,6,7,8,9>
MANIFEST:       process-implementation/artifacts/.manifest.json
TIMING_DIR:     <TIMING_DIR>
BASENAME:       workers-batch-<k>
```

At most ~10–12 workers per batch keeps each agent's context small. For a small manifest (`N` ≤ 8) this is still one agent per worker, which is fine — the cap only bites at scale. **If the per-session cap is nonetheless hit** (the dispatch returns a spawn-limit error), generate the remaining slices directly with your own tools by following `generate-worker-class.md` per index — do not keep retrying `Agent()`.

**Concurrent-write coordination.** Multiple workers may declare the same error code (typed exception) — `generate-worker-class.md` writes idempotently (skip if a file with the same class name exists; otherwise overwrite), so concurrent batches never clobber a shared `*Exception.java`. Service files are 1:1 with workers, so no contention.

**Cost visibility.** Batching also makes worker-generation cost legible: each batch agent's token usage rolls up to one visible `workers-batch-<k>` record, instead of the per-worker sub-agents' cost being hidden under the single workers-domain orchestrator (QA finding F9/F10 — nested fan-out cost wasn't surfaced).

The schemas each agent writes — Worker class, Service stub, typed exceptions — are documented inline in `generate-worker-class.md`. Naming derivations table also lives there.

## Step 3: Compile/test gate

Run Maven through the shared helper, which prefers the scaffold's own wrapper and falls back to an
installed `mvn` — the same resolution every other Maven caller in this repo uses:

```bash
node ".github/skills/process-os-artifact-generation/scripts/run-maven.cjs" process-implementation/artifacts -q test
```

**Emit `sdk_build`** after this invocation regardless of outcome (success or failure). The event name is
the spine's, not Maven's, so the aggregate's shape does not change per SDK.

Exit `2` means **no build ran at all**, and stderr says which case it was. `No Maven wrapper in … and
no mvn on PATH` is a missing toolchain (a hermetic/CI sandbox without Java) — skip the gate with a
logged note rather than failing the skill. Any other exit-`2` message is a real failure: report it.
Any other non-zero exit is Maven's own — stop worker generation, report the Maven output, and fix the
generated scaffolding before continuing, since those are real compile/ArchUnit errors.
