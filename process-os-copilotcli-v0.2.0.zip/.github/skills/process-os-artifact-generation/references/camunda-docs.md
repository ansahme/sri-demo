# Camunda Docs MCP

The `camunda-docs` MCP server provides semantic search over Camunda 8 documentation, forum posts, repos, and product blogs.

**Server:** `https://camunda-docs.mcp.kapa.ai`  
**Tool:** `search_camunda_knowledge_sources`  
**Auth:** Google sign-in required on first use. Rate limit: 40 req/hour, 200 req/day.

## When to use

Call `search_camunda_knowledge_sources` before making any decision about:

- BPMN 2.0 element types, attributes, or required fields
- Gateway rules (exclusive, parallel, inclusive, event-based)
- Event definitions (timer, message, signal, error, escalation, boundary)
- Camunda 8 / Zeebe-specific behavior or extensions
- Process modeling best practices or constraints
- Any BPMN rule you are uncertain about

## How to call

Pass a short, specific natural-language query:

```
search_camunda_knowledge_sources("exclusive gateway default flow bpmn 2.0")
search_camunda_knowledge_sources("boundary event interrupting vs non-interrupting")
search_camunda_knowledge_sources("zeebe job worker service task configuration")
```

Do not guess or rely on training data alone for BPMN rules — always verify against the docs.

## Using camunda-docs

**Preferred (any MCP-enabled platform):** Use the `camunda-docs` MCP server tool.
For Claude Code this is registered automatically via `.mcp.json`.
For other platforms, register it using your platform's MCP config with the endpoint
in `.env.example` (`CAMUNDA_DOCS_MCP_URL`).

**Fallback (any platform, no MCP):** Retrieve docs via HTTP, substituting your `+`-joined query:

```bash
node ".github/skills/process-os-artifact-generation/scripts/http-request.cjs" --header "Accept: application/json" "https://camunda-docs.mcp.kapa.ai/search?q=<YOUR+QUERY>"
```

On exit `0` the JSON response is on stdout — read `results[].content` from it, and keep each result's
source URL for the citation. Every other exit code means there is no result set to read, and they are
not interchangeable: `1` is a non-2xx (a 404 or a 401 is a broken endpoint or a bad request, never an
empty search), `2` means the endpoint was unreachable, and `3` means the call was malformed. Report
which one it was rather than treating any of them as "the docs had nothing".

Skills must attempt MCP first, then fall back to HTTP. Never fail silently — if
neither is available, tell the user and pause.
