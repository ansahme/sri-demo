---
name: process-os-artifact-generation
description: >-
  Use when BPMN files are ready and you want to generate execution-ready BPMN
  with Zeebe extensions, job workers, DMN decision tables, and Camunda Forms for
  the full process. Builds ONE transformation tier into a deployable artifact /
  bundle, then validates deployability — automated against a cluster where the
  target SDK supports it, manual instructions otherwise.

  USE FOR: generate execution artifacts from reviewed BPMN, scaffold job workers
  + DMN tables + Camunda Forms, build a transformation tier into a deployable
  bundle, produce the process-implementation/artifacts/ tree after
  transformation.

  DO NOT USE FOR: authoring or editing the BPMN itself (use
  process-os-bpmn-generation), deploying to a cluster (use
  process-os-deployment), generating the CPT test suite (use
  process-os-test-suite).
license: >-
  Camunda License 1.0. See the NOTICE and LICENSE files distributed with this
  work.
---
# /process-os-artifact-generation

Generate a complete, deployable artifact bundle from BPMN and process documentation.

## Camunda Docs

For any question about Zeebe extensions, worker patterns, DMN format, or form schema, call `search_camunda_knowledge_sources` (camunda-docs MCP) before deciding. See `references/camunda-docs.md` for the HTTP fallback when MCP is unavailable.

## EXEC: Reject the retired `--tier` argument

`--tier <name>` is retired: several iterations can produce the same tier, so a tier no longer
names a candidate to build — picking one of its iterations for the user would be a guess with a
deployable artifact at the end of it. If the skill is invoked with `--tier`, reject it before
doing anything else: stop with "the --tier argument is retired — pass --iteration <N> instead. Run
`node ".github/skills/process-os-artifact-generation/scripts/resolve-transformation-iteration.cjs" detect` to see which iterations exist
and which tier each recorded."

## EXEC: Setup: phase directory, feedback, and the pass kind

Resolve whether this run generates the artifact tree or edits the one an earlier run left, and
read what feedback there is to resolve. Everything in this section applies to either kind of
pass; anything that does not belongs below the branch.

```bash
node ".github/skills/process-os-artifact-generation/scripts/pass-kind.cjs" resolve process-implementation/artifacts
```

Capture the printed word as `<PASS_KIND>`: `GENERATION` (no pass has finished here, so this run
writes the whole tree) or `EDIT` (one has, so a tree worth editing is in place). Exit `5` means
the marker it reads is there but unusable — stop and report it rather than guessing a pass kind.
A generation pass writes that marker as its last act, so a run that stops earlier — at the Phase 2
review gate, or on any script failure below — resumes as a generation pass rather than editing a
tree nothing vouches for.

Then open the phase's two directories:

```bash
node ".github/skills/process-os-artifact-generation/scripts/make-dir.cjs" process-implementation/artifacts process-implementation/feedback
```

Write the feedback directory's own `README.md` — a constant this skill owns (`FEEDBACK_README` in
`scripts/write-feedback-readme.cjs`), written only when the file is absent and never committed to
this repository:

```bash
node ".github/skills/process-os-artifact-generation/scripts/write-feedback-readme.cjs" process-implementation/feedback
```

List what is pending — every entry there no earlier pass resolved, and every entry a reviewer has
changed since one did:

```bash
node ".github/skills/process-os-artifact-generation/scripts/feedback-ledger.cjs" pending
```

One entry per line, `NEW` or `CHANGED` then the name, the `README.md` scaffold excluded. Exit `5`
means the directory, an entry, or the ledger a pass records is there but unusable — stop and report
it rather than counting it as no feedback. Otherwise count the printed lines as `<PENDING_COUNT>` —
`0` is ordinary for either pass kind, not an error.

**A generation pass does not resolve feedback, however much of it is there** — every generator
below writes its whole output from the current transformation source and manifest, so an edit
made ahead of one would not survive it. Leave the entries where they are; the run after this one
is an edit pass and resolves them then.

**State the pass in one line before any other action** — `<PASS_KIND>` and `<PENDING_COUNT>`,
and on a generation pass with feedback waiting, that the next run resolves it. For example:
"Generation pass. No feedback to resolve.", "Generation pass. 2 feedback files, which the next
edit pass resolves.", or "Edit pass. 2 feedback files to resolve."

## EXEC: Branch on `<PASS_KIND>`

**`<PASS_KIND>` = `EDIT`** → the design behind `process-implementation/artifacts/` has not changed
since it was generated, so there is nothing new to analyze or regenerate. Read [the edit-pass
reference](references/edit-pass.md) and follow it in place of every phase below, Output section
included — it resolves each pending entry to the file(s) it implicates, edits exactly those, and
records them so the next pass leaves them alone. Once it reports, the run is done: do not continue
to "Resolve transformation iteration" or any heading past this point.

**`<PASS_KIND>` = `GENERATION`** → continue to "Resolve transformation iteration" below and run
every phase from there on.

## EXEC: Resolve transformation iteration

Everything from here on belongs to a generation pass. An edit pass reads no transformation BPMN,
so resolving an iteration for one would both stop a run over a perfectly good tree when no
iteration exists, and repoint `artifact-iteration:` on a pass that never reads it.

This skill builds ONE transformation iteration's BPMN into executable artifacts.
Resolve which iteration (precedence `--iteration` > `artifact-iteration:` in
`transformation.config.md` > the last completed iteration > prompt). `<ITERATION_ARG>` is the
value of a `--iteration <N>` argument passed to the skill, or the empty string when none was —
an empty value falls through to the next precedence tier, so the flag is always passed.

```bash
node ".github/skills/process-os-artifact-generation/scripts/resolve-transformation-iteration.cjs" resolve --iteration "<ITERATION_ARG>"
```

Read the exit code and stdout from the command result:

- exit `0` → stdout is the resolved iteration's `artifacts/` path. Hold it as `<ARTIFACTS_DIR>`;
  every `<ARTIFACTS_DIR>` below is that literal. `<N>` is the iteration number embedded in it —
  the digits between `iteration-` and the trailing `/artifacts`.
- exit `2` → the requested or configured iteration does not exist, or holds no executable BPMN;
  stderr holds the error message. Stop and tell the user which iterations exist (run
  `node ".github/skills/process-os-artifact-generation/scripts/resolve-transformation-iteration.cjs" detect`) or to run
  `/process-os-process-transformation --bpmn` to produce one.
- exit `3` → stdout is `PROMPT_REQUIRED {json}`. This fires only when no completed
  transformation iteration exists at all — `resolve` already falls back to the last completed
  iteration on its own whenever one exists, so a prompt never interrupts a run once a single
  iteration has completed. Stop with: "No transformation BPMN found. Run
  `/process-os-process-transformation --bpmn` first."

After resolving, persist the choice:

```bash
node ".github/skills/process-os-artifact-generation/scripts/resolve-transformation-iteration.cjs" persist "<N>"
```

BPMN and its phase-doc `.md` companions are siblings inside `<ARTIFACTS_DIR>` — there is no
separate BPMN directory to derive.

Executable inputs in `<ARTIFACTS_DIR>`: `process-NN-*.bpmn` (linear phases),
`edge-*.bpmn` (independent edge-case processes), and `subprocess-*.bpmn`
(processes invoked by a call activity from inside a phase — reached from the
phase, not chained by `main-<slug>.bpmn`, so they stay out of
`structure.phases`). `00-overview.bpmn` is a non-executable landscape diagram
and is intentionally ignored downstream. Gate on real files (never on
`.camunda/state.md`):

```bash
node ".github/skills/process-os-artifact-generation/scripts/list-files.mts" --count "<ARTIFACTS_DIR>/process-[0-9]*-*.bpmn" "<ARTIFACTS_DIR>/edge-*.bpmn" "<ARTIFACTS_DIR>/subprocess-*.bpmn"
```

`0` → stop: "No executable BPMN in `<ARTIFACTS_DIR>`. Run `/process-os-process-transformation --bpmn`."

## EXEC: Name this run's timing directory

Derive it from the run's start timestamp — there is no snapshot left for a version label to pair
with:

```bash
node -e "process.stdout.write(String(Date.now()))"
```

Capture the printed value as `<RUN_TS>`, then derive `<TIMING_DIR>` as
`.camunda/timing/<RUN_TS>-artifact` (created automatically by the first `timing.cjs event` call
below — no separate `mkdir` needed).

Capture `<TIMING_DIR>`. Each Phase 3 subagent writes a record at `<TIMING_DIR>/<BASENAME>.json`.
The aggregator runs at the end of Phase 3. Earlier runs' timing directories stay in place, each
its own historical record.

## Orchestrator timing instrumentation

The orchestrator (this SKILL.md, running at the top level) writes its own timing record at `<TIMING_DIR>/orchestrator.json` so per-phase wall-clock can be measured independently of the per-agent records. BASENAME is fixed: **`orchestrator`**. Canonical form, used at every phase-boundary emit:

```bash
node ".github/skills/process-os-artifact-generation/scripts/timing.cjs" --dir "<TIMING_DIR>" event "orchestrator" <event-name>
```

End-of-skill finalize (last action of Phase 4):

```bash
node ".github/skills/process-os-artifact-generation/scripts/timing.cjs" --dir "<TIMING_DIR>" end "orchestrator"
```

Every event is appended to `orchestrator.json` with both `ts_ms` (epoch) and `dt_ms` (delta from `phase_1_start`). After the run, `node ".github/skills/process-os-artifact-generation/scripts/timing-phase-breakdown.cjs" "<TIMING_DIR>"` prints a per-phase wall table.

> **Reading the numbers.** Orchestrator phase-boundary `dt_ms` are wall-clock between the orchestrator's own tool calls, so they **include model inter-call latency**, not just script time — treat them as coarse phase bounds, not script benchmarks. In particular, on Claude Code the `Agent()` batch and the following `Bash` emit are separate steps, so `phase_*_fanout_dispatched` / `phase_*_agents_dispatched` cannot bracket a running fan-out: the "dispatch" segment absorbs the whole fan-out wall and the "wall" segment reads ~0. For the **true fan-out wall**, use the **max per-agent `duration_ms`** from `timing.cjs aggregate` (the slowest agent), not the orchestrator dispatch→complete delta.

The 25 events fired across Phases 1–4 (24 phase-boundary events + the `end` finalizer) are listed inline at each phase boundary below. The aggregate view (`timing.cjs aggregate`) shows `orchestrator` as one extra row — the existing per-agent records are unaffected; no double-counting (the column set covers `mcp` / `connector_resolved` / `http` / `lint_run` / `lint_fix`, and the orchestrator emits only phase-boundary names that aren't in that set).

## EXEC: Setup

> **No lint prerequisites to set up.** The §3.5 parent-BPMN lint and the §3.6 cross-phase sweep both run `scripts/lint-processes.cjs`, which resolves the centrally-installed bpmnlint itself (`.camunda/node_modules`, provisioned by `c8 os install`, then the project root) and falls back to `npx --yes bpmnlint` only when neither has it. `process-os-camunda-compatibility-check` likewise resolves the bpmnlint binary + camunda-compat plugin from `.camunda/node_modules` and sets its own `NODE_PATH` internally.

## EXEC: Connector binding handoff

Connector bindings from the transformation BPMN (produced by `/process-os-process-transformation --bpmn`) are authoritative. When a source BPMN element already carries `zeebe:modelerTemplate` / `zeebe:modelerTemplateVersion`, artifact generation must preserve that binding and its existing `zeebe:taskDefinition`, `zeebe:ioMapping`, `zeebe:taskHeaders`, and `zeebe:modelerTemplateIcon` structure.

Artifact generation only fills unresolved connector input values where the BPMN already exposes empty or placeholder `<zeebe:input>` entries. It may use process documentation, template defaults already present in the BPMN, and explicit review answers to replace empty values with concrete FEEL or literal values.

Do not re-run connector matching, do not change template IDs or versions, and do not rebuild connector extension blocks from the element-template cache unless the source BPMN explicitly contains an unresolved connector warning annotation. If a connector-bound element is missing required template metadata, stop with a review question that asks whether to re-run `/process-os-process-transformation --bpmn` or manually repair the BPMN.

## AI: Phase 1: Analysis

Per-phase inference is **fanned out into parallel subagents** (`analyze-phase.md`) so wall-clock scales with `max(per-phase time)` instead of `sum(per-phase time)`. The dispatch happens here, at SKILL.md level — same pattern as `process-os-bpmn-generation`'s Phase Generation. **Do not delegate this phase to a wrapping subagent that then tries to dispatch further** — Claude Code subagents reliably do not re-dispatch nested subagents. The orchestration must run at the top level.

Outputs when done: `process-implementation/artifacts/.manifest.json` and `process-implementation/artifacts/artifact-proposal.md`.

**Emit `phase_1_start`** before any other Phase 1 action — this is the very first orchestrator timing event and seeds `start_ms` for the whole run.

### EXEC: 1.1 Setup

```bash
node ".github/skills/process-os-artifact-generation/scripts/make-dir.cjs" process-implementation/artifacts process-implementation/artifacts/.analyze-phase
```

`process-implementation/artifacts/.analyze-phase/` is the per-phase scratch directory: structural data goes in as `<stem>.bpmn.json`, inference output comes back as `<stem>.json`. Cleaned up at end of Phase 1.

**Emit `phase_1_setup_done`.**

### EXEC: 1.2 Read process metadata + write _meta.json

Read `.camunda/state.md`. Extract:
- `Name:` → processName (e.g. `Quote to Cash`)

Read the **package group** — the namespace prefix the generated worker layer compiles under. It is a
run-configuration key, not a business-identity one, so it comes from `run.config.yaml`:

```bash
node ".github/skills/process-os-artifact-generation/scripts/read-run-config.cjs" package-group
```

Capture the printed value as `PACKAGE_GROUP`. The key carries a schema default, so the reader always
prints one — exit 1 or 2 means the reader failed, not that the key is unset: report stderr and stop.

Derive:
- `processSlug` — lowercase kebab (e.g. `quote-to-cash`)
- `processCamel` — PascalCase (e.g. `QuoteToCash`)
- `packageBase` — `<PACKAGE_GROUP>.<processSlug with no dashes>` (e.g. `com.acme.quotetocash`)

Every segment of `packageBase` must start with a letter and hold only letters, digits and
underscores. `scaffold-workers.cjs` rejects a value that does not (exit 2) and names the offending
segment, so report what it names rather than guessing which input produced it.

Resolve the **target SDK** (the blueprint selector — a closed enum of official Camunda client SDKs).
`<TARGET_SDK_ARG>` is the value of a `--target-sdk <sdk>` argument passed to the skill, or the empty
string when none was — an empty value falls through to the next precedence tier, so the flag is
always passed. Precedence:
`--target-sdk` > `skillInput["process-os-artifact-generation"].targetSdk` (governance
run, from `.camunda/job-input.json`) > `target-sdk` in `run.config.yaml` > default
`java-spring-boot`:

```bash
node ".github/skills/process-os-artifact-generation/scripts/resolve-target-sdk.cjs" --target-sdk "<TARGET_SDK_ARG>"
```

Omit the flag entirely when the skill was invoked without one. Capture the printed value as
`TARGET_SDK`. Exit `2` means the value is not an official Camunda SDK — stop and report the enum.
`java-spring-boot` and `typescript` are fully implemented — blueprint, worker layer and build gate.
`python` has a blueprint and a worker layer, and declares no dependency-audit probe or build gate yet.
The remaining official SDKs (`java`, `csharp`) resolve, and Phase 3 reports each missing capability by
name rather than stopping the skill, so no worker application is generated for them (the
SDK-independent BPMN/DMN/forms bundle still is). The capability table is the authority on which is
which — this paragraph does not restate a row.

Resolve the project's **TO-BE cluster minor** (`8.8` | `8.9` | `8.10`, default `8.10`). `scaffold-workers.cjs`
maps this to the stable Camunda Java **client** patch it pins into the bundle pom (via `versions.json`;
the client may lag the cluster minor — a supported skew — and `8.10` has no GA client yet, so it falls
back to the newest stable client). Kept non-fatal here so an analysis run never blocks on a config typo —
if the value is unsupported the resolver prints nothing **on stdout**, explains why on stderr, and the
scaffold falls back to its default pin; the version is re-resolved and validated (exit 2) later in Phase 5:

```bash
node ".github/skills/process-os-artifact-generation/scripts/resolve-camunda-version.cjs" run.config.yaml
```

Capture the printed value as `CAMUNDA_CLUSTER_VERSION`; a non-zero exit here is non-fatal — treat
the value as empty and carry on. The resolver writes nothing to stderr when it succeeds, so the
capture is safe however stderr is routed — do not add `2>/dev/null` (it has no PowerShell
equivalent) or `2>&1` (it would fold the error explanation into the value).

Persist these to `process-implementation/artifacts/.analyze-phase/_meta.json` so the join script in step 1.5 can read them without re-deriving (the join spreads `_meta.json` into `manifest.meta`, so `targetSdk` and `camundaClusterVersion` reach `scaffold-workers.cjs`). Substitute every placeholder with the value derived above. Write it **with your file-writing tool, not a shell redirect** — `>` writes UTF-16 in Windows PowerShell 5.1 and the JSON read below then fails:

```json
{
  "processName": "<processName>",
  "packageBase": "<packageBase>",
  "processCamel": "<processCamel>",
  "processSlug": "<processSlug>",
  "targetSdk": "<TARGET_SDK>",
  "camundaClusterVersion": "<CAMUNDA_CLUSTER_VERSION>",
  "artifactDir": "process-implementation/artifacts"
}
```

**Emit `phase_1_metadata_done`.**

### EXEC: 1.3 Parse all BPMNs structurally + write per-phase splits

Run the parser once for the whole `<ARTIFACTS_DIR>` directory, then split the JSONL output into per-phase files so each subagent reads only its slice. The stems printed to stdout are the canonical phase list — capture them:

```bash
node ".github/skills/process-os-artifact-generation/scripts/split-phase-elements.cjs" "<ARTIFACTS_DIR>"
```

Fast (regex parsing); typical 7-phase project finishes in <1 s. Writes
`process-implementation/artifacts/.analyze-phase/<stem>.bpmn.json` per phase and prints one stem per line. Exit `2` means
no phases were split — the parser failed, or the directory held nothing parseable; stop rather than
dispatching an empty fan-out.

**Emit `phase_1_parse_done`.**

### AI: 1.4 Dispatch one subagent per phase, simultaneously, in a single batch

**Dispatch all phase agents simultaneously** — run one subagent per phase stem as an independent agent:

- **Claude Code:** issue ALL `Agent()` calls in a **single assistant tool-message** (one tool-message with N `tool_use` blocks) — that's how Claude Code runs them concurrently. Do not emit agents one-by-one across turns — that serialises execution. Results are awaited together before continuing.
- **Other platforms:** invoke each phase's analyze sub-skill sequentially if parallel dispatch is not available.

Per-phase prompt — emit ONLY these canonical fields, **no tail notes/hints/paragraphs** (see Phase 3's dispatch prompt shape note for the rationale; analyze-phase has the same hazard):

```
Read references/analyze-phase.md and follow it.

PHASE_STEM:    <stem>
BPMN_FILE:     <ARTIFACTS_DIR>/<stem>.bpmn
PHASE_DOC:     <ARTIFACTS_DIR>/<stem>.md
ELEMENTS_PATH: process-implementation/artifacts/.analyze-phase/<stem>.bpmn.json
OUTPUT_PATH:   process-implementation/artifacts/.analyze-phase/<stem>.json
```

Every phase writes a per-phase `.md` companion alongside its `.bpmn` in `<ARTIFACTS_DIR>`, so the
`PHASE_DOC:` line is emitted unconditionally for every phase. `analyze-phase.md` still tolerates a
missing companion defensively (BPMN remains authoritative), but no phase is expected to lack one.

Defaults: standard `general-purpose` `subagent_type`, default model — no `model` override.

Each agent writes its slice to `process-implementation/artifacts/.analyze-phase/<stem>.json` with `{phase, bpmnFile, processId, workers, forms, decisions, connectorBindings}`. Empty arrays are fine.

**Emit `phase_1_fanout_dispatched`** immediately after the batch fires (before waiting). The `dt_ms` between this and `phase_1_parse_done` is pure parent-side dispatch overhead.

Wait for all agents to complete before proceeding.

**Emit `phase_1_fanout_complete`** once every per-phase agent has returned. The `dt_ms` between this and `phase_1_fanout_dispatched` is the wall of the slowest per-phase agent.

### EXEC: 1.5 Run the join script

```bash
node ".github/skills/process-os-artifact-generation/scripts/analyze-join.mts" process-implementation/artifacts
```

Reads `_meta.json` and every per-phase slice from `process-implementation/artifacts/.analyze-phase/`, runs variable reconciliation across slices, determines `structure.type` (single vs call-activities) from worker output→input handoffs, concatenates the four manifest arrays in phase order, and writes:

- `process-implementation/artifacts/.manifest.json` — canonical manifest
- `process-implementation/artifacts/.analyze-phase/_disagreements.json` — variable-type disagreement list (consumed by step 1.6)

This step is **purely mechanical** — pure node, no LLM. Runs in <1 s on a 7-phase project. **Do not dispatch a subagent for this step.** Earlier runs that delegated the join to a Claude subagent paid 500+ s for what is `Array.concat` plus a few `Set` operations; the script does the same work in 30 ms.

Schemas (worker, form, decision, connector binding) are unchanged from the per-phase slice contract — see `analyze-phase.md`. Every manifest entry is a wiring-plan entry; the script just merges what the per-phase agents produced.

**Emit `phase_1_join_done`.** Should be < 100 ms — proves the join replaced the prior 9-min finalize subagent.

### EXEC: 1.6 Generate the proposal

```bash
node ".github/skills/process-os-artifact-generation/scripts/analyze-proposal.cjs" process-implementation/artifacts
```

Templates `process-implementation/artifacts/artifact-proposal.md` from the manifest plus the disagreements file:

- Header (Process / Package / Artifact dir)
- Proposed Structure (with parent process + handoff list when call-activities)
- Service Tasks → Workers table
- Business Rule Tasks → DMN Decisions table
- User Tasks → Forms table
- Connector Bindings table (with unresolved-input targets surfaced)
- "Questions for Review" with two subsections:
  - Variable type disagreements (cross-phase) — from step 1.5
  - Per-element review questions — auto-derived from `confidence != "high"` flags on workers / forms / decisions, plus connector `unresolvedInputs` whose `source` is empty, plus decisions with no grounded gatewayId

This step is also **purely mechanical**. Runs in <1 s. **Do not dispatch a subagent for this step.**

If you want narrative polish (consolidating closely-related questions, suggesting defaults), do a small focused Edit pass on `process-implementation/artifacts/artifact-proposal.md` after the script writes it — but never a full rewrite. The template covers the structural content; an LLM polish pass should add a few sentences, not regenerate the file.

**Emit `phase_1_proposal_done`.**

### EXEC: 1.7 Cleanup

```bash
node ".github/skills/process-os-artifact-generation/scripts/remove-path.cjs" --recursive process-implementation/artifacts/.analyze-phase
```

The scratch directory is temporary and not part of the artifact bundle — nothing later in the run reads it.

**Emit `phase_1_cleanup_done`** — marks the end of Phase 1 wall.

## GATE: Phase 2: Review

**Emit `phase_2_review_started`** before invoking the review sub-skill.

Read and follow [the review reference](references/review.md).

**Do not proceed to Phase 3 until the user explicitly approves.** The review phase may loop multiple times.

**Emit `phase_2_approved`** once the user replies "proceed". The `dt_ms` between started→approved is human-paced (out of automation budget) but useful to subtract from total wall.

Connector input values are no longer reconciled in a separate phase. `wire-execution-bpmn.mts`
(Step 3.4) preserves each already-bound connector as-is, writes the `source` Phase 1 already resolved
for each `unresolvedInputs[]` entry into its matching `<zeebe:input target="...">`, and records any
entry still empty to `process-implementation/artifacts/.review/<phase>.json` rather than fabricating a value — see the
"Connector binding handoff" section above for the contract (bindings authoritative; never rebuilt; a
value that can't be resolved becomes a review marker, not a guess). This currently covers plain
`<zeebe:input>` targets only — `resultExpression`/`errorExpression` `zeebe:taskHeader` bindings are
not yet written by this step.

## AI: Phase 3: Generate (scripted BPMN/DMN/forms + workers agent)

**Emit `phase_3_start`.**

Phase 3 carries no chain of `targetSdk` conditionals. A single capability table, keyed on
`manifest.meta.targetSdk`, declares per SDK whether it has a blueprint, a worker generator, a
dependency-audit worker probe, a build gate, and deployability validation. Read the row once, here,
and treat it as `<CAPS>` for the rest of this phase:

```bash
node ".github/skills/process-os-artifact-generation/scripts/sdk-capabilities.cjs" --from-manifest process-implementation/artifacts
```

Exit `2` means the manifest names an SDK the table does not know, or the manifest is unreadable —
**stop** and report it. Otherwise capture the printed JSON as `<CAPS>`; every per-SDK branch below
reads one of its fields by name.

**Runs for every target:** the scaffold (as far as a blueprint exists), DMN generation and its linting,
forms generation and its linting, execution-BPMN wiring, the parent BPMN, the lint sweep, and
dependency-audit checks #2 to #4. Each is a deterministic script writing SDK-independent paths.

**Per SDK:** the worker layer, dependency-audit check #1, the build gate, and Phase-5 deployability
validation. Where the table says a capability is absent, the step reports a skip that names the SDK. It
never stops the skill and never passes silently.

Phase 3 is mostly scripted: DMN, forms, and **execution-BPMN wiring** are deterministic scripts — no
agents. Whether the workers domain runs as an agent is per SDK (`<CAPS>.workerGenerator`, step 3.4).
The orchestrator runs setup/scaffolding/audit/gate at top level.

`TIMING_DIR` semantics: every `timing.cjs` invocation in any subagent MUST pass `--dir "<TIMING_DIR>"` (the Bash tool starts a fresh shell per call; an exported var would not survive).

**Dispatch prompt shape — no per-phase tail hints.** The dispatch prompt for any subagent MUST contain only the canonical fields named in the per-domain prompt template below (e.g. `PHASE_STEM`, `MANIFEST`, `ARTIFACTS_DIR`, …). **Do NOT append "Note:" / "Hint:" / context paragraphs after the field block.** Tail notes are read by agents as response material rather than context — observed three runs in a row on `process-04` (a phase BPMN with a receiveTask), where the orchestrator tacked on `"Note: receiveTask Task_WaitForCustomerReply needs message correlation key=case_id"` and the agent echoed it verbatim instead of executing the sub-skill.

If a BPMN element type or wiring case isn't covered by the sub-skill, fix the sub-skill — don't paper over the gap with a tail hint. Each per-domain sub-skill is the canonical contract for what gets written; everything an agent needs to handle a phase must live inside that file (or be reachable via files it explicitly reads). Any per-phase context the orchestrator needs to convey belongs in the manifest as a structured field, not as a prose tail in the dispatch prompt.

### EXEC: 3.2 Generate DMN tables (script, no agent)

```bash
node ".github/skills/process-os-artifact-generation/scripts/generate-dmn.cjs" process-implementation/artifacts
```

Pure templating from `manifest.decisions[]`. Writes one `.dmn` per decision under `process-implementation/artifacts/src/main/resources/decisions/`. Invoke the **process-os-dmn-linting** skill for the generated files; fix any errors.

**Regenerated on a generation pass.** Every `.dmn` file is written unconditionally from the current
manifest whenever this phase runs — a hand edit to one does not survive it. An edit pass never
reaches this phase; see the Setup section above.

### EXEC: 3.3 Generate Camunda Forms (script, no agent)

```bash
node ".github/skills/process-os-artifact-generation/scripts/generate-forms.cjs" process-implementation/artifacts
```

Pure templating from `manifest.forms[]`. Writes one `.form` per form under `process-implementation/artifacts/src/main/resources/forms/`. Invoke the **process-os-forms-linting** skill for the generated files; fix any errors.

**Regenerated on a generation pass.** Every `.form` file is written unconditionally from the
current manifest whenever this phase runs — a hand edit to one does not survive it. An edit pass
never reaches this phase; see the Setup section above.

### AI: 3.4 Generate execution BPMN (script) + workers domain (agent)

Execution-BPMN wiring is **fully scripted** — no per-phase fan-out. Because `analyze-join` preserves each worker's source `taskDefinition` type verbatim, the copied transformation BPMN already carries correct worker wiring; the script only adds what the source lacks (form bindings, DMN output promotion, a `sourceTypeMissing` plain-`<bpmn:task>` refine, message correlation) and runs the per-phase self-check. Run it at the top level:

```bash
node ".github/skills/process-os-artifact-generation/scripts/wire-execution-bpmn.mts" process-implementation/artifacts "<ARTIFACTS_DIR>"
```

It reads `structure.phases` ∪ `structure.edgeCases` from the manifest, writes each `processes/<stem>.bpmn`, and writes `process-implementation/artifacts/.review/<stem>.json` for any unresolved connector input (empty source — never fabricated). It reports its own hard wiring errors (a form/decision/gateway target missing from the BPMN). **On non-zero exit: stop** — read the `wiring error` lines and fix before proceeding. Manifest↔BPMN consistency (every declared wiring actually landed) is verified later by the §3.6 dependency audit, not here. A genuinely unresolvable connector value is the one case that may warrant a narrow agent; everything else is a bug in the script or the manifest, not something to paper over.

**Regenerated on a generation pass.** Each `processes/<stem>.bpmn` is rewritten wholesale from the
current transformation-tier source whenever this phase runs — a hand edit made directly to it does
not survive it. An edit pass never reaches this phase; see the Setup section above.

Then run the worker layer for this SDK. `<CAPS>.blueprint` is `false` → report
`worker layer: skipped — no blueprint for SDK <sdk>` and go to step 3.5; there is nothing to scaffold
and nothing to generate. Otherwise branch on `<CAPS>.workerGenerator`:

**`"agent-fan-out"`** — dispatch the workers domain as a single agent. It reads the spine, which routes
it to the Java overlay:

```
Read references/generate-workers.md and follow it.
MANIFEST:   process-implementation/artifacts/.manifest.json
TIMING_DIR: <TIMING_DIR>
BASENAME:   workers
```

Defaults: standard `general-purpose` `subagent_type`, default model.

**`"script"`** — **do NOT dispatch an agent.** Read [the workers spine](references/generate-workers.md)
yourself and follow it, including its own `start` (Step 1, before the scaffold) and `end` (Finalize,
last action) timing events for the `workers` `BASENAME` — do not emit a second `start`/`end` pair here;
`timing.cjs aggregate` flags a repeated `start` as a restart anomaly. The spine routes you to the
per-SDK overlay, which is a script invocation.

Dispatching an agent here would reintroduce the failure mode documented at the build gate below: a
subagent can return before reaching its own gate, and there is nothing for an agent to decide when the
per-SDK content is one script invocation.

**`null` (with a blueprint present)** — scaffold without generating workers. **Do NOT dispatch an
agent.** Read [the workers spine](references/generate-workers.md) yourself and follow it through to
its Finalize step, including both its `start` (Step 1, before the scaffold) and its `end` (Finalize,
last action) timing events for the `workers` `BASENAME`. What the `null` capability skips is the
per-SDK overlay, not the spine: the spine's own `workerInstructions` table routes `null` from the
scaffold to the report as `worker layer: skipped — no worker generator for SDK <sdk>`. Stopping after
Step 1 emits `start` with no `end`, and a record with no `end` carries no duration at all — the
`workers` row aggregates as `—` and contributes nothing to the Phase 3 total, which no anomaly check
catches. No SDK sits in this state today; an SDK reaches it whenever a blueprint lands before its
generator, and the scaffold is then a complete, installable application skeleton — a real
deliverable, not a failed run.

**Emit `phase_3_agents_dispatched`** after the workers step begins; **emit
`phase_3_agents_complete`** once it finishes. The exec-BPMN script is synchronous, so its wall is
captured in the surrounding Bash step, not a per-agent timing record; only the `workers` record is
written under `<TIMING_DIR>/`.

### EXEC: 3.5 Generate parent BPMN (call-activities only)

**MANDATORY — do not skip.** This step writes `main-<slug>.bpmn`, the call-activity orchestrator that ties the per-phase children together. Without it, deployment of a call-activities project has no entry point. The bpmnkit source is the skill's `scripts/generate-parent-bpmn.ts`; it is invoked directly and no copied `.gen.mjs` is persisted in the artifact.

```bash
node "scripts/generate-parent-bpmn.ts" process-implementation/artifacts
```

No-op when `manifest.structure.type != "call-activities"` — the script exits 0 with `no parent process needed`. Otherwise writes `main-<slug>.bpmn` from manifest data with linear topology + ioMapping + simple DI.

**Regenerated on a generation pass.** `main-<slug>.bpmn` is written unconditionally from the
current manifest whenever it applies and this phase runs — a hand edit to it does not survive it.
An edit pass never reaches this phase; see the Setup section above. Run a single bpmnlint pass over
the parent file, but only when it actually exists:

```bash
node ".github/skills/process-os-artifact-generation/scripts/path-exists.cjs" "process-implementation/artifacts/src/main/resources/processes/main-<PROCESS_SLUG>.bpmn"
```

`NOT FOUND` → skip the lint. `EXISTS` → lint that one file.

```bash
node ".github/skills/process-os-artifact-generation/scripts/lint-processes.cjs" --skip-missing "process-implementation/artifacts/src/main/resources/processes/main-<PROCESS_SLUG>.bpmn"
```

`--skip-missing` covers the no-op case above: no parent file means nothing to lint, exit `0`.
The script resolves bpmnlint itself and runs it with `node`, never as an executable.

**Emit `phase_3_parent_bpmn_done`** — confirms the script ran. Skipping the emit means skipping the step.

### EXEC: 3.6 Consolidated cross-phase lint sweep

The exec-BPMN script (Step 3.4) self-checks each phase but does not lint. Do one consolidated pass over every `processes/*.bpmn` file to catch cross-file inconsistencies (call activities pointing at non-existent child process IDs, etc.). Lint **per file** — bpmnlint errors `EISDIR` on a directory argument, and piping a run through `tail`/`head` masks its exit code, so a broken sweep looks green. Enumerate the files first:

```bash
node ".github/skills/process-os-artifact-generation/scripts/list-files.mts" "process-implementation/artifacts/src/main/resources/processes/*.bpmn"
```

Then lint each listed file in its own command, reading each exit code from its own result:

```bash
node ".github/skills/process-os-artifact-generation/scripts/lint-processes.cjs" process-implementation/artifacts/src/main/resources/processes
```

It lints each file separately and reports the real status: exit `1` names the files with findings,
exit `2` means some file was never linted (bpmnlint could not start, or the directory held no
`.bpmn` at all) — never read that as clean.

Invoke the **process-os-camunda-compatibility-check** skill for `process-implementation/artifacts/src/main/resources/processes`.

Fix any reported errors via `Edit` and re-run until clean.

**Emit `phase_3_consolidated_lint_done`.**

**Icons — nothing to do.** The scripted exec-BPMN (Step 3.4) copies the source BPMN without stripping icon attributes, so there is nothing to restore. Connector icons are already complete in the source (`c8ctl element-template apply` writes the full `zeebe:modelerTemplateIcon` data URL at bind time in `process-os-bpmn-generation`).

**Emit `phase_3_icon_sweep_done`** — retained as a post-lint checkpoint marker (no icon work runs here anymore).

**Aggregate timing.** Each Phase 3 subagent has emitted its events to `<TIMING_DIR>/<BASENAME>.json`. Aggregate now:

```bash
node ".github/skills/process-os-artifact-generation/scripts/timing.cjs" --dir "<TIMING_DIR>" aggregate
```

Prints a per-record table — duration plus the counter columns `timing.cjs` itself defines (`cmdAggregate`) — and writes `<TIMING_DIR>/_summary.json`. Surface the table to the user. Names outside that column set are recorded per event in `<TIMING_DIR>/<basename>.json` and read there, not from the table.

**Emit `phase_3_aggregate_done`.**

**Implicit-dependency audit.** The Phase 3 domains (scripted execution-BPMN / DMN / forms plus the workers agent) are produced independently and don't see each other's outputs. Cross-check the manifest's claims against what actually got written:

```bash
node ".github/skills/process-os-artifact-generation/scripts/audit-artifact-deps.cjs" process-implementation/artifacts
```

The script verifies four classes of cross-agent dependency:

1. Each `manifest.workers[].jobType` is wired by some `*Worker.java` carrying `@JobWorker(type = "<jobType>")`.
2. Each `manifest.forms[].formId` has a `forms/<formId>.form` file whose JSON `id` matches.
3. Each `manifest.decisions[].decisionId` is implemented by some `decisions/*.dmn` containing `<decision id="<decisionId>">`.
4. Every BPMN-side reference (`zeebe:formDefinition formId`, `zeebe:calledDecision decisionId`, non-connector `zeebe:taskDefinition type`) points at an entry the manifest declared.

Connector-typed `taskDefinition` values (those containing a colon, e.g. `io.camunda:slack:1`) are recognised and skipped — those are wired by element templates, not by workers.

**On non-zero exit:** stop. Re-dispatch the agent that produced the missing artifact (the failure message names which one) with the context of which manifest entry is unsatisfied. Do not proceed to the build gate with a half-wired bundle.

**Emit `phase_3_audit_done`.**

**Build gate (per SDK).** The dependency audit above checks *wiring*, not *compilation*. Run the real
build at the orchestrator level — do **not** rely on a workers sub-agent's own gate, which runs inside
a sub-agent that can return before reaching it (observed: a bundle with invalid `ProcessVariables.java`
field names reported "done" but did not compile). Branch on `<CAPS>.buildGate`:

**`"maven"`:**

```bash
node ".github/skills/process-os-artifact-generation/scripts/run-maven.cjs" process-implementation/artifacts -B -q -DskipTests compile
```

`spotless:apply` runs in `process-sources`, so this also normalises generated formatting.

**`"npm"`** — four commands, each read on its own exit code. The compiler and dependency-cruiser both
run fully offline; only the install needs the network:

```bash
node ".github/skills/process-os-artifact-generation/scripts/run-npm.cjs" process-implementation/artifacts install
```

```bash
node ".github/skills/process-os-artifact-generation/scripts/run-npm.cjs" process-implementation/artifacts run typecheck
```

```bash
node ".github/skills/process-os-artifact-generation/scripts/run-npm.cjs" process-implementation/artifacts run build
```

```bash
node ".github/skills/process-os-artifact-generation/scripts/run-npm.cjs" process-implementation/artifacts run test:arch
```

Two of the blueprint's scripts are deliberately absent, both because they would pass without asserting
anything about the generated bundle. `npm test` is a vacuous success: a generated project contains no
test files, and the scaffold patches `passWithNoTests: true` into `vitest.config.ts` so that a user who
runs it does not hit a hard failure. `npm run check` is the blueprint's non-mutating lint pass
(`biome check .`, as against the mutating `npm run fix`), and generated formatting is emitted to match
`biome.json` already — a formatting drift is not a reason to red-light a build.

**`"uv"`** — five commands, each read on its own exit code. Only the sync touches the network:

```bash
node ".github/skills/process-os-artifact-generation/scripts/run-uv.cjs" process-implementation/artifacts sync --frozen
```

```bash
node ".github/skills/process-os-artifact-generation/scripts/run-uv.cjs" process-implementation/artifacts run ruff check .
```

```bash
node ".github/skills/process-os-artifact-generation/scripts/run-uv.cjs" process-implementation/artifacts run ruff format --check .
```

```bash
node ".github/skills/process-os-artifact-generation/scripts/run-uv.cjs" process-implementation/artifacts run mypy
```

```bash
node ".github/skills/process-os-artifact-generation/scripts/run-uv.cjs" process-implementation/artifacts run lint-imports
```

`--frozen` is what asserts `uv.lock` still satisfies `pyproject.toml`. Without it uv re-resolves
silently, and the pinned graph stops meaning anything.

`pytest` is deliberately absent, and for a different reason than the TypeScript gate's omissions. The
scaffold drops the blueprint's example-domain tests, so a generated project holds no test of its own,
and the one test that travels with the scaffold shells out to `lint-imports`, which this gate already
runs. The blueprint's own `--cov-fail-under=80` would fail a bundle that holds no other test.

**`null`:** report `build gate: skipped — no build gate for SDK <sdk>` and continue.

**On any non-zero exit: stop.** No exit is a green build. Exit `2` is not on its own proof the tool
never started — the runner passes through the tool's own exit code unchanged when it does launch, and a
launched tool can legitimately exit `2` itself. Tell the two apart by the runner's own stderr message: a
"did not run" exit (usage error, tool not found on PATH, tool could not be started) always prints one;
a launched tool's own failure prints only the tool's own output, with no extra message from the runner.
Neither `npm` nor `uv` has a toolchain-absent skip, for different reasons. npm ships with Node and
this skill already requires Node to run its own `.cjs` scripts, so a missing npm is never a legitimate
toolchain gap, only a broken Node install. uv ships with nothing, and a missing uv still stops the run:
a python target installs its bundle with uv, and `pyproject.toml` and `uv.lock` are a locked unit no
other tool installs, so no other tool can run the gate. Read the errors, fix the offending generated file (or re-run the generator), and re-run until
clean. Never finish a pass with a bundle that does not build.

**Emit `phase_3_build_gate_done`.** One orchestrator phase boundary for every SDK, the `null` branch
above included: it marks that the orchestrator reached this point, not that a gate ran. The gate's
cost is the `phase_3_audit_done` → `phase_3_build_gate_done` segment — the last segment of Phase 3's
wall, now that nothing runs after it. A multi-command gate is one segment, not one per command (for
`npm`, `install` is the only command that touches the network, and it dominates). Like every
orchestrator phase-boundary event it lands in `<TIMING_DIR>/orchestrator.json`, not in the
aggregate table's columns.

## EXEC: Phase 4: Finalize

**Emit `phase_4_start`.**

Count generated artifacts. The worker-file suffix is per SDK — a `Worker.java` count on a TypeScript
bundle reports zero workers for a bundle full of them, and that zero is what reaches `.camunda/state.md`
and `.camunda/audit.md` below:

```bash
node ".github/skills/process-os-artifact-generation/scripts/count-artifacts.cjs" process-implementation/artifacts
```

Prints exactly three lines — `workers=<W>`, `decisions=<D>`, `forms=<F>`. Exit `2` means the manifest is
unreadable or names an SDK the capability table does not know; stop and report it rather than writing a
zero count into the lifecycle mirror.

Update `.camunda/state.md`:
- process-os-artifact-generation Status → `✅ Done`
- Completed → today's date
- Key Output → `"process-implementation/artifacts/ ([W] workers, [D] decisions, [F] forms)"`
- process-os-test-suite Status → `⏳ Next`
- Next Step → `"Run /process-os-test-suite to generate and run the CPT test suite"`

**Emit `phase_4_state_updated`.**

Append audit entry:
```bash
node ".github/skills/process-os-artifact-generation/scripts/append-audit.cjs" process-os-artifact-generation "Generated <W> workers, <D> decisions, <F> forms"
```

**Emit `phase_4_audit_appended`.**

**Write memory entry:**

Read `.camunda/memory.md`. Locate `## Artifact Decisions`. Synthesize 3–6 bullets capturing:
- Project structure chosen (single / call-activities) and the reasoning
- Job types used (list in kebab-case)
- Key variable names and their types (especially handoff variables in call-activities)
- DMN decisions: table names, input/output variable names
- Any corrections made during the review step (renamed variables, type changes, structural changes)

Append to the section, preceded by `<!-- [today YYYY-MM-DD] -->`. Polish and write the updated file back.

**Record that this generation pass completed** — the last thing a generation pass does, and what
makes the next run an edit pass:

```bash
node ".github/skills/process-os-artifact-generation/scripts/pass-kind.cjs" record process-implementation/artifacts
```

**Emit `phase_4_memory_done`** — marks the end of Phase 4 wall.

## EXEC: Finalize orchestrator timing

Final generation action — after the memory write, before the deployability gate (Phase 5) and the Output block:

```bash
node ".github/skills/process-os-artifact-generation/scripts/timing.cjs" --dir "<TIMING_DIR>" end "orchestrator"
```

Stamps `end_ms` / `duration_ms` and finalizes the orchestrator record. Then run the breakdown helper to surface the per-phase wall:

```bash
node ".github/skills/process-os-artifact-generation/scripts/timing-phase-breakdown.cjs" "<TIMING_DIR>"
```

Surface the table in the final Output block.

## AI: Phase 5 — Validate deployability (cluster-gated)

After a successful generation, confirm the bundle actually **deploys** — but only
against a cluster that is **already reachable**. Never start a cluster here (that
is the user's decision); this is a non-fatal quality gate, not the deployment
milestone.

**0. Branch on the SDK, before any cluster work.** Run `node ".github/skills/process-os-artifact-generation/scripts/sdk-capabilities.cjs" --from-manifest process-implementation/artifacts` to get `<CAPS>` fresh (don't rely on a copy from previous phases) and read `.deployabilityValidation`:

| Value | What Phase 5 does |
|---|---|
| `"automated"` | Run steps 1 to 4 below, unchanged. |
| `"manual"` | **Skip steps 1 to 4 entirely** — no version resolve, no profile enumeration, no topology probe, no deployment skill. Print the `## Deployability — manual validation` section of the file `<CAPS>.reportFile` names, substituting its placeholders, and set the Output block's `Deployability:` line to `manual validation required — see "Deployability — manual validation" above`. |
| `"none"` | Skip steps 1 to 4 and report `Deployability: not applicable — no blueprint for SDK <sdk>`. |

The branch is here rather than inside step 4a because for an SDK with no automated validation there is
no cluster work to do at all: resolving a version and probing profiles would be wasted work whose only
possible outcome is the skip. The `"manual"` path never reaches the reachable/unreachable branch, so
neither 4a nor 4b applies and there is no such thing as a red deployability check on such a run — the
user is asked to validate, given the commands to do it with, and never handed a verdict the skill did
not observe.

`java-spring-boot` is `"automated"`, so **its behaviour is unchanged**: steps 1 through 3 and the
existing cluster-reachability branch with 4a's validation handoff and 4b's non-fatal skip. Nothing about
the Java path's semantics changes; it becomes the body of one SDK branch rather than the whole phase.

**1. Resolve the target version and enumerate profiles** (c8ctl for all cluster
ops — no raw REST):

```bash
node ".github/skills/process-os-artifact-generation/scripts/resolve-camunda-version.cjs" run.config.yaml
c8ctl list profile --json
```

Stdout of the first is `<CAMUNDA_VERSION>`; the second lists `[{ "Name", "URL", "Source" }, ...]`.

**2. Pick a candidate**, preferring an exact `Camunda<CAMUNDA_VERSION>` match,
then any other profile (a `modeler:`-prefixed profile is fine to probe).

**3. Probe REAL availability** (existence in the list is not enough):

```bash
c8ctl get topology --profile "<name>" --json
```

A profile is usable iff `brokers` is non-empty. Prefer a cluster whose
`gatewayVersion` starts with `<CAMUNDA_VERSION>`; a reachable non-matching cluster
is still fine for a deployability check — note the version mismatch.

**4a. Reachable cluster found** → invoke `/process-os-deployment --validate`, naming the
reachable profile explicitly in the invocation. That skill honours a caller-supplied profile;
state the name rather than exporting a shell variable, which does not carry across platforms.
It deploys the bundle + boots the
workers against that profile **without** advancing the lifecycle. Surface any
**Class B** defect it triages — a Class B here means the artifacts you just
generated are broken (fix the generator, regenerate, re-validate).

**4b. No reachable cluster** → skip (non-fatal). Note in the Output:
"Deployability not validated — no reachable cluster. Run
`/process-os-environment-setup`, then `/process-os-deployment --validate`."

This phase never advances lifecycle state and never fails generation.

## Output

Print the `## Output` section of the per-SDK report file `<CAPS>.reportFile` names, substituting every
`<…>` placeholder — including the `Deployability:` line resolved in Phase 5 and the `<W>`/`<D>`/`<F>`
counts from Phase 4. When `<CAPS>.reportFile` is `null` (an SDK with no blueprint), print instead:

```
Artifact generation complete — partially.

No blueprint exists for target SDK <sdk>, so no worker application was generated. Written:
  process-implementation/artifacts/src/main/resources/{processes,decisions,forms}   (<D> decisions, <F> forms)

Changing `target-sdk` will not produce one: every later run over this tree is an edit pass, which
resolves feedback into targeted edits and never runs a generator. Building for another SDK means
starting the phase over — remove process-implementation/artifacts/, having preserved anything
hand-written in it, so the next run is a generation pass again.

Next steps:
  1. Run /process-os-test-suite — generate and run the CPT test suite
```

The bundle's file tree, its `Next steps` and its `Deployability:` line are all per SDK, which is why
they live in the report file rather than here.

## References

Detail the orchestrator and its Phase 3 workers sub-agent load on demand:

- [Edit-pass procedure](references/edit-pass.md) — resolves feedback into targeted file edits;
  reached instead of Phase 1 through Phase 5 whenever `<PASS_KIND>` is `EDIT`
- [Phase 1 per-phase inference](references/analyze-phase.md) — dispatched analysis sub-agents
- [Phase 2 review gate](references/review.md)
- [Phase 3 workers spine](references/generate-workers.md) — the SDK-agnostic procedure and the routing table
- [Java Spring Boot worker overlay](references/workers-java-spring-boot.md) — the batched fan-out and its Maven gate
- [TypeScript worker overlay](references/workers-typescript.md) — the generator invocation and its exit codes
- [Python worker overlay](references/workers-python.md) — the generator invocation, its exit codes, and the re-run contract
- [Worker class template](references/generate-worker-class.md) — reached from the Java overlay
- [Worker implementation guidance](references/job-worker-implementation.md)
- [Worker layering / ArchUnit rules](references/job-worker-architecture.md)
- [Report: java-spring-boot](references/report-java-spring-boot.md) — that SDK's Output block
- [Report: typescript](references/report-typescript.md) — that SDK's manual-validation prompt and Output block
- [Report: python](references/report-python.md) — that SDK's manual-validation steps and Output block
