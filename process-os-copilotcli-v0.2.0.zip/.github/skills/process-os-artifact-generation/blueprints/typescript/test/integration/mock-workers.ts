import type { CamundaClient, JobWorker } from "@camunda8/orchestration-cluster-api"
import { WORKER_DEFAULTS } from "../../src/workers/worker-defaults.js"

const MOCK_JOB_TYPES = ["A", "B"] as const

export interface CompletedJob {
  processInstanceKey: string
  type: string
}

export interface MockWorkerSetup {
  workers: JobWorker[]
  completedJobs: CompletedJob[]
}

export const registerMockWorkers = (client: CamundaClient): MockWorkerSetup => {
  const completedJobs: CompletedJob[] = []
  const workers = MOCK_JOB_TYPES.map((type) =>
    client.createJobWorker({
      ...WORKER_DEFAULTS,
      jobType: type,
      workerName: `mock-${type.toLowerCase()}-worker`,
      jobHandler: (job) => {
        completedJobs.push({ processInstanceKey: job.processInstanceKey, type })
        return job.complete()
      },
    }),
  )
  return { workers, completedJobs }
}
