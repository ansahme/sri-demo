export const CAMUNDA_RUNTIME_VERSION = "8.9.5"
export const WIREMOCK_VERSION = "3.13.2"
