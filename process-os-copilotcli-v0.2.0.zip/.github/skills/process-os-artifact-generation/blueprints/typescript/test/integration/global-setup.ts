import path from "node:path"
import { fileURLToPath } from "node:url"
import { GenericContainer, type StartedTestContainer, Wait } from "testcontainers"
import { CAMUNDA_RUNTIME_VERSION, WIREMOCK_VERSION } from "./runtime-versions.js"

const HERE = path.dirname(fileURLToPath(import.meta.url))
const PROJECT_ROOT = path.resolve(HERE, "..", "..")

const CAMUNDA_IMAGE = `camunda/camunda:${CAMUNDA_RUNTIME_VERSION}`
const WIREMOCK_IMAGE = `wiremock/wiremock:${WIREMOCK_VERSION}`

let camunda: StartedTestContainer | undefined
let wiremock: StartedTestContainer | undefined

export default async function setup(): Promise<() => Promise<void>> {
  camunda = await new GenericContainer(CAMUNDA_IMAGE)
    .withExposedPorts(8080, 26500)
    .withEnvironment({
      SPRING_PROFILES_ACTIVE: "broker,standalone",
      CAMUNDA_DATA_SECONDARYSTORAGE_TYPE: "none",
      CAMUNDA_SECURITY_AUTHENTICATION_METHOD: "basic",
      CAMUNDA_SECURITY_AUTHENTICATION_UNPROTECTEDAPI: "true",
      CAMUNDA_SECURITY_AUTHORIZATIONS_ENABLED: "false",
    })
    .withWaitStrategy(Wait.forHttp("/v2/topology", 8080).forStatusCode(200))
    .withStartupTimeout(180_000)
    .start()

  // WireMock with the project's mappings mounted read-only.
  wiremock = await new GenericContainer(WIREMOCK_IMAGE)
    .withExposedPorts(8080)
    .withBindMounts([
      {
        source: path.join(PROJECT_ROOT, "wiremock"),
        target: "/home/wiremock",
        mode: "ro",
      },
    ])
    .withCommand(["--global-response-templating"])
    .withWaitStrategy(Wait.forHttp("/__admin/health", 8080))
    .withStartupTimeout(60_000)
    .start()

  const camundaHost = camunda.getHost()
  const wiremockHost = wiremock.getHost()
  const camundaRestPort = camunda.getMappedPort(8080)
  const wiremockPort = wiremock.getMappedPort(8080)

  process.env.CAMUNDA_REST_ADDRESS = `http://${camundaHost}:${camundaRestPort}`
  process.env.CAMUNDA_AUTH_STRATEGY = "NONE"
  process.env.CAMUNDA_WORKER_REQUEST_TIMEOUT = "2000"
  delete process.env.CAMUNDA_BASIC_AUTH_USERNAME
  delete process.env.CAMUNDA_BASIC_AUTH_PASSWORD
  process.env.EXTERNAL_API_A_BASE_URL = `http://${wiremockHost}:${wiremockPort}`
  process.env.EXTERNAL_API_B_BASE_URL = `http://${wiremockHost}:${wiremockPort}`

  console.log(`[integration setup] Camunda REST=${process.env.CAMUNDA_REST_ADDRESS}`)
  console.log(`[integration setup] WireMock=${process.env.EXTERNAL_API_A_BASE_URL}`)

  return async () => {
    await Promise.allSettled([camunda?.stop(), wiremock?.stop()])
  }
}
