import path from "node:path"
import {
  type CamundaClient,
  createCamundaClient,
  type ProcessDefinitionId,
} from "@camunda8/orchestration-cluster-api"
import { afterAll, beforeAll, describe, expect, it } from "vitest"

import type { RoutingDecision } from "../../src/models/process-variables.js"
import { type MockWorkerSetup, registerMockWorkers } from "./mock-workers.js"

const BPMN_PATH = path.resolve(
  import.meta.dirname,
  "..",
  "..",
  "resources",
  "blueprint-process.bpmn",
)
const PROCESS_ID = "Blueprint_Process" as ProcessDefinitionId

describe("Blueprint process: BPMN structure (mocked workers)", () => {
  let client: CamundaClient
  let setup: MockWorkerSetup

  beforeAll(async () => {
    client = createCamundaClient()
    await client.deployResourcesFromFiles([BPMN_PATH])
    setup = registerMockWorkers(client)
  })

  afterAll(async () => {
    if (!setup) return
    await Promise.allSettled(setup.workers.map((w) => w.stopGracefully({ waitUpToMs: 5_000 })))
  })

  it.each<{
    label: string
    routingDecision?: RoutingDecision
    expectedJobOrder: string[]
  }>([
    { label: "applyB branch", routingDecision: "applyB", expectedJobOrder: ["A", "B"] },
    { label: "skipB branch", routingDecision: "skipB", expectedJobOrder: ["A"] },
    { label: "default flow when routingDecision is missing", expectedJobOrder: ["A"] },
  ])(
    "completes service tasks in order via the $label",
    async ({ routingDecision, expectedJobOrder }) => {
      const result = await client.createProcessInstance({
        processDefinitionId: PROCESS_ID,
        variables: {
          a: { a: "valueA" },
          b: { b: "valueB" },
          ...(routingDecision && { routingDecision }),
        },
        awaitCompletion: true,
        requestTimeout: 60_000,
      })

      const observedJobOrder = setup.completedJobs
        .filter((job) => job.processInstanceKey === result.processInstanceKey)
        .map((job) => job.type)

      expect(result.processInstanceKey).toBeDefined()
      expect(observedJobOrder).toEqual(expectedJobOrder)
    },
  )
})
