import path from "node:path"
import {
  type CamundaClient,
  createCamundaClient,
  type ProcessDefinitionId,
} from "@camunda8/orchestration-cluster-api"
import { pino } from "pino"
import { afterAll, beforeAll, describe, expect, it } from "vitest"

import { composeApp, type RegisteredWorkers, registerWorkers } from "../../src/app.js"
import { loadEnv } from "../../src/config/env.js"
import type { RoutingDecision } from "../../src/models/process-variables.js"

const BPMN_PATH = path.resolve(
  import.meta.dirname,
  "..",
  "..",
  "resources",
  "blueprint-process.bpmn",
)
const PROCESS_ID = "Blueprint_Process" as ProcessDefinitionId

describe("Blueprint process end-to-end", () => {
  let client: CamundaClient
  let workers: RegisteredWorkers

  beforeAll(async () => {
    const env = loadEnv({ ...process.env, BLUEPRINT_RESULT_PREFIX: "[TEST]_" })
    const services = composeApp(env)
    const log = pino({ level: "silent" })

    client = createCamundaClient()

    await client.deployResourcesFromFiles([BPMN_PATH])

    workers = registerWorkers(client, services, log)
  })

  afterAll(async () => {
    if (!workers) return
    await Promise.allSettled(
      Object.values(workers).map((worker) => worker.stopGracefully({ waitUpToMs: 5_000 })),
    )
  })

  it.each<{ routingDecision: RoutingDecision; expected: string }>([
    {
      routingDecision: "applyB",
      expected: "[TEST]_valueA_byServiceA_valueB_byServiceB",
    },
    {
      routingDecision: "skipB",
      expected: "[TEST]_valueA_byServiceA_",
    },
  ])(
    "routes via '$routingDecision' and produces concatenatedResult '$expected'",
    async ({ routingDecision, expected }) => {
      const result = await client.createProcessInstance({
        processDefinitionId: PROCESS_ID,
        variables: { a: { a: "valueA" }, b: { b: "valueB" }, routingDecision },
        awaitCompletion: true,
        requestTimeout: 60_000,
      })

      const variables = result.variables as { concatenatedResult?: string }
      expect(variables.concatenatedResult).toBe(expected)
    },
  )
})
