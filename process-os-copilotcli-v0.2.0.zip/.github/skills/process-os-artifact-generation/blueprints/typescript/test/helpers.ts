import { vi } from "vitest"
import type { ProcessVariables, ProcessVariablesSchema } from "../src/models/process-variables.js"
import type { Logger } from "../src/observability/logger.js"
import type { JobHandler } from "../src/workers/job-handler.js"

type Job = Parameters<JobHandler<typeof ProcessVariablesSchema>>[0]

export const buildVariables = (extra: Partial<ProcessVariables> = {}): ProcessVariables => ({
  a: { a: "valueA" },
  b: { b: "valueB" },
  ...extra,
})

export const createMockLogger = (): Logger =>
  ({
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
    debug: vi.fn(),
    trace: vi.fn(),
  }) as unknown as Logger

export const createMockJob = (variables: ProcessVariables): Job => {
  const job = {
    jobKey: "test-job-key",
    type: "test",
    processInstanceKey: "test-pi",
    bpmnProcessId: "Blueprint_Process",
    processDefinitionVersion: 1,
    elementId: "Activity_Test",
    elementInstanceKey: "test-elem",
    customHeaders: {},
    worker: "test-worker",
    retries: 1,
    deadline: new Date().toISOString(),
    variables,
    tenantId: "<default>",
    complete: vi.fn(),
    fail: vi.fn(),
    error: vi.fn(),
    cancelWorkflow: vi.fn(),
    ignore: vi.fn(),
  }
  return job as unknown as Job
}
