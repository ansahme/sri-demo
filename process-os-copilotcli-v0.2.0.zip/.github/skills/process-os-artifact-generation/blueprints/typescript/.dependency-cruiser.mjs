/** @type {import("dependency-cruiser").IConfiguration} */
export default {
  forbidden: [
    {
      name: "no-circular",
      severity: "error",
      comment: "Circular dependencies between modules are forbidden.",
      from: {},
      to: { circular: true },
    },
    {
      name: "workers-only-down",
      severity: "error",
      comment: "Workers may only depend on services, models, config, errors, observability.",
      from: { path: "^src/workers" },
      to: { path: "^src/", pathNot: "^src/(workers|services|models|config|errors|observability)" },
    },
    {
      name: "services-only-down",
      severity: "error",
      comment: "Services may only depend on clients, models, config, errors.",
      from: { path: "^src/services" },
      to: { path: "^src/", pathNot: "^src/(services|clients|models|config|errors)" },
    },
    {
      name: "clients-only-down",
      severity: "error",
      comment: "Clients may only depend on models, config, errors.",
      from: { path: "^src/clients" },
      to: { path: "^src/", pathNot: "^src/(clients|models|config|errors)" },
    },
    {
      name: "models-leaf",
      severity: "error",
      comment: "Models is a leaf layer; must not depend on any other internal layer.",
      from: { path: "^src/models" },
      to: { path: "^src/", pathNot: "^src/models" },
    },
    {
      name: "errors-leaf",
      severity: "error",
      comment: "Errors is a leaf layer; must not depend on any other internal layer.",
      from: { path: "^src/errors" },
      to: { path: "^src/", pathNot: "^src/errors" },
    },
    {
      name: "config-no-upward-deps",
      severity: "error",
      comment: "Config may not depend on workers, services, or clients.",
      from: { path: "^src/config" },
      to: { path: "^src/(workers|services|clients)" },
    },
    {
      name: "observability-only-down",
      severity: "error",
      comment: "Observability may only depend on config (logger consumes Env).",
      from: { path: "^src/observability" },
      to: { path: "^src/", pathNot: "^src/(observability|config)" },
    },
  ],
  options: {
    tsConfig: { fileName: "tsconfig.json" },
    tsPreCompilationDeps: true,
    doNotFollow: { path: "node_modules" },
    includeOnly: "^src/",
    exclude: { path: "\\.test\\.ts$" },
    enhancedResolveOptions: {
      exportsFields: ["exports"],
      conditionNames: ["import", "require", "node", "default"],
      mainFields: ["main", "types"],
    },
    reporterOptions: {
      text: { highlightFocused: true },
    },
  },
}
