import { describe, expect, it, vi } from "vitest"

import { createExternalApiBClient } from "./external-api-b-client.js"
import { createHttpClient } from "./http-client.js"

const BASE_URL = "http://wiremock:8080"

describe("createExternalApiBClient", () => {
  it("calls the service-b URL with the encoded input", async () => {
    const body = { success: true, suffix: "_byServiceB" }
    const fetch = vi.fn().mockResolvedValue(new Response(JSON.stringify(body)))
    const client = createExternalApiBClient(createHttpClient({ baseUrl: BASE_URL, fetch }))

    const result = await client.get("alpha&beta")

    expect(fetch).toHaveBeenCalledWith(
      `${BASE_URL}/api/service-b?input=alpha%26beta`,
      expect.objectContaining({ signal: expect.any(AbortSignal) }),
    )
    expect(result).toEqual(body)
  })
})
