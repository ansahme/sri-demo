import { describe, expect, it, vi } from "vitest"

import { createExternalApiAClient } from "./external-api-a-client.js"
import { createHttpClient } from "./http-client.js"

const BASE_URL = "http://wiremock:8080"

describe("createExternalApiAClient", () => {
  it("calls the service-a URL with the encoded input", async () => {
    const body = { success: true, suffix: "_byServiceA_" }
    const fetch = vi.fn().mockResolvedValue(new Response(JSON.stringify(body)))
    const client = createExternalApiAClient(createHttpClient({ baseUrl: BASE_URL, fetch }))

    const result = await client.get("hello world")

    expect(fetch).toHaveBeenCalledWith(
      `${BASE_URL}/api/service-a?input=hello+world`,
      expect.objectContaining({ signal: expect.any(AbortSignal) }),
    )
    expect(result).toEqual(body)
  })
})
