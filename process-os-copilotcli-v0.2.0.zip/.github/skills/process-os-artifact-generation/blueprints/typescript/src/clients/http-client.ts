import type { ZodType } from "zod"

import { ExternalApiError } from "../errors/external-api-error.js"

export const DEFAULT_HTTP_TIMEOUT_MS = 10_000

export type Fetch = (url: string, init: RequestInit) => Promise<Response>

export interface HttpClientOptions {
  baseUrl: string
  timeoutMs?: number
  fetch?: Fetch
}

export interface HttpRequest {
  query?: Record<string, string>
}

export interface HttpClient {
  getJson<T>(path: string, schema: ZodType<T>, request?: HttpRequest): Promise<T>
}

export const createHttpClient = ({
  baseUrl,
  timeoutMs = DEFAULT_HTTP_TIMEOUT_MS,
  fetch = (url, init) => globalThis.fetch(url, init),
}: HttpClientOptions): HttpClient => ({
  async getJson(path, schema, request = {}) {
    const url = buildUrl(baseUrl, path, request.query)

    const response = await fetchOrThrow(fetch, url, timeoutMs)
    if (!response.ok) {
      throw apiError(url, `returned HTTP ${response.status}`)
    }

    const payload = await readJsonOrThrow(response, url)
    const parsed = schema.safeParse(payload)
    if (!parsed.success) {
      throw apiError(url, "returned an unexpected response shape", parsed.error)
    }

    return parsed.data
  },
})

const buildUrl = (baseUrl: string, path: string, query?: Record<string, string>): string => {
  const url = new URL(path, ensureTrailingSlash(baseUrl))
  if (query) {
    url.search = new URLSearchParams(query).toString()
  }
  return url.toString()
}

const fetchOrThrow = async (fetch: Fetch, url: string, timeoutMs: number): Promise<Response> => {
  try {
    return await fetch(url, { signal: AbortSignal.timeout(timeoutMs) })
  } catch (cause) {
    throw apiError(url, isTimeout(cause) ? "timed out" : "failed", cause)
  }
}

const readJsonOrThrow = async (response: Response, url: string): Promise<unknown> => {
  try {
    return await response.json()
  } catch (cause) {
    throw apiError(url, "returned invalid JSON", cause)
  }
}

const apiError = (url: string, detail: string, cause?: unknown): ExternalApiError =>
  cause === undefined
    ? new ExternalApiError(`GET ${url} ${detail}`)
    : new ExternalApiError(`GET ${url} ${detail}`, { cause })

const isTimeout = (cause: unknown): boolean =>
  cause instanceof Error && cause.name === "TimeoutError"

const ensureTrailingSlash = (baseUrl: string): string =>
  baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`
