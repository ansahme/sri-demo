import { type ApiResponse, ApiResponseSchema } from "../models/api-response.js"
import type { HttpClient } from "./http-client.js"

export interface ExternalApiAClient {
  get(input: string): Promise<ApiResponse>
}

export const createExternalApiAClient = (http: HttpClient): ExternalApiAClient => ({
  async get(input) {
    return http.getJson("api/service-a", ApiResponseSchema, { query: { input } })
  },
})
