import { describe, expect, it, vi } from "vitest"
import { z } from "zod"

import { ExternalApiError } from "../errors/external-api-error.js"
import { createHttpClient, type Fetch } from "./http-client.js"

const Schema = z.object({ ok: z.boolean() })
const BASE_URL = "http://example.test"
const TARGET_URL = "http://example.test/resource"

const clientWith = (fetch: Fetch) => createHttpClient({ baseUrl: BASE_URL, fetch })

describe("createHttpClient", () => {
  it("returns the parsed JSON on 2xx with a matching schema", async () => {
    const fetch = vi.fn().mockResolvedValue(new Response(JSON.stringify({ ok: true })))

    await expect(clientWith(fetch).getJson("resource", Schema)).resolves.toEqual({ ok: true })
  })

  it("builds the request URL from the base URL, path, and query", async () => {
    const fetch = vi.fn().mockResolvedValue(new Response(JSON.stringify({ ok: true })))

    await clientWith(fetch).getJson("resource", Schema, { query: { a: "1", b: "x y" } })

    expect(fetch).toHaveBeenCalledWith(
      "http://example.test/resource?a=1&b=x+y",
      expect.objectContaining({ signal: expect.any(AbortSignal) }),
    )
  })

  it("throws ExternalApiError with the HTTP status on non-2xx responses", async () => {
    const fetch = vi.fn().mockResolvedValue(new Response("nope", { status: 503 }))

    await expect(clientWith(fetch).getJson("resource", Schema)).rejects.toThrow(
      new ExternalApiError(`GET ${TARGET_URL} returned HTTP 503`),
    )
  })

  it("throws ExternalApiError when the response does not match the schema", async () => {
    const fetch = vi.fn().mockResolvedValue(new Response(JSON.stringify({ unexpected: true })))

    await expect(clientWith(fetch).getJson("resource", Schema)).rejects.toThrow(
      new ExternalApiError(`GET ${TARGET_URL} returned an unexpected response shape`),
    )
  })

  it("throws ExternalApiError when the response body is not valid JSON", async () => {
    const fetch = vi.fn().mockResolvedValue(new Response("not json"))

    await expect(clientWith(fetch).getJson("resource", Schema)).rejects.toThrow(
      new ExternalApiError(`GET ${TARGET_URL} returned invalid JSON`),
    )
  })

  it("wraps generic network errors as 'failed'", async () => {
    const fetch = vi.fn().mockRejectedValue(new Error("ECONNREFUSED"))

    await expect(clientWith(fetch).getJson("resource", Schema)).rejects.toThrow(
      new ExternalApiError(`GET ${TARGET_URL} failed`),
    )
  })

  it("wraps AbortSignal timeouts as 'timed out'", async () => {
    const cause = Object.assign(new Error("aborted"), { name: "TimeoutError" })
    const fetch = vi.fn().mockRejectedValue(cause)

    await expect(clientWith(fetch).getJson("resource", Schema)).rejects.toThrow(
      new ExternalApiError(`GET ${TARGET_URL} timed out`),
    )
  })
})
