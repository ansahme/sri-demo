import { type ApiResponse, ApiResponseSchema } from "../models/api-response.js"
import type { HttpClient } from "./http-client.js"

export interface ExternalApiBClient {
  get(input: string): Promise<ApiResponse>
}

export const createExternalApiBClient = (http: HttpClient): ExternalApiBClient => ({
  async get(input) {
    return http.getJson("api/service-b", ApiResponseSchema, { query: { input } })
  },
})
