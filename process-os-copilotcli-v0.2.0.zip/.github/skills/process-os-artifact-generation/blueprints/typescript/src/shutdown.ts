import type { RegisteredWorkers } from "./app.js"
import type { Logger } from "./observability/logger.js"

const CLEANUP_HEADROOM_MS = 2_000
const CLEANUP_HEADROOM_FRACTION = 0.2

export const calculateWorkerDrainTimeoutMs = (shutdownTimeoutMs: number): number => {
  const cleanupReserveMs = Math.min(
    CLEANUP_HEADROOM_MS,
    Math.floor(shutdownTimeoutMs * CLEANUP_HEADROOM_FRACTION),
  )
  return shutdownTimeoutMs - cleanupReserveMs
}

export const drainWorkers = async (
  workers: RegisteredWorkers,
  waitUpToMs: number,
  log: Logger,
): Promise<void> => {
  await Promise.allSettled(
    Object.entries(workers).map(async ([name, worker]) => {
      try {
        const { timedOut, remainingJobs } = await worker.stopGracefully({ waitUpToMs })
        if (timedOut) {
          log.warn(
            { worker: name, remainingJobs },
            "worker drain timeout, force-stopping with jobs still running",
          )
        }
      } catch (err) {
        log.error({ worker: name, err }, "worker failed to stop gracefully")
      }
    }),
  )
}
