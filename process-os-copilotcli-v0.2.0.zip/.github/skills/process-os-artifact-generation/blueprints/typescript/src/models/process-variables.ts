import { z } from "zod"

export const ObjectASchema = z.object({ a: z.string() })
export const ObjectBSchema = z.object({ b: z.string() })

export type ObjectA = z.infer<typeof ObjectASchema>
export type ObjectB = z.infer<typeof ObjectBSchema>

export const RoutingDecisionSchema = z.enum(["applyB", "skipB"])
export type RoutingDecision = z.infer<typeof RoutingDecisionSchema>

export const TaskBInputSchema = z.object({
  b: ObjectBSchema,
  concatenatedResult: z.string(),
})

export const ProcessVariablesSchema = z.object({
  a: ObjectASchema.optional(),
  b: ObjectBSchema.optional(),
  routingDecision: RoutingDecisionSchema.optional(),
  concatenatedResult: z.string().optional(),
})

export type ProcessVariables = z.infer<typeof ProcessVariablesSchema>
