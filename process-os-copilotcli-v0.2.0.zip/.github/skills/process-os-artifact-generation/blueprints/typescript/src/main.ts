import path from "node:path"
import { type CamundaClient, createCamundaClient } from "@camunda8/orchestration-cluster-api"
import closeWithGrace from "close-with-grace"
import { pino } from "pino"

import { composeApp, type RegisteredWorkers, registerWorkers } from "./app.js"
import { loadEnv } from "./config/env.js"
import { createLogger, type Logger, pinoSdkTransport, sdkLogLevel } from "./observability/logger.js"
import {
  createMonitoringServer,
  type Lifecycle,
  type MonitoringServer,
} from "./observability/monitoring-server.js"
import { prometheusExporter, shutdownTelemetry } from "./observability/telemetry.js"
import { calculateWorkerDrainTimeoutMs, drainWorkers } from "./shutdown.js"

const BPMN_PATH = path.resolve(import.meta.dirname, "..", "resources", "blueprint-process.bpmn")

const deployBpmn = async (client: CamundaClient, log: Logger): Promise<void> => {
  log.info({ path: BPMN_PATH }, "deploying BPMN process")
  const { processes } = await client.deployResourcesFromFiles([BPMN_PATH])
  log.info({ processes }, "BPMN deployment succeeded")
}

interface ShutdownContext {
  workers: RegisteredWorkers
  monitoringServer: MonitoringServer
  lifecycle: Lifecycle
  log: Logger
  shutdownTimeoutMs: number
}

const installShutdown = ({
  workers,
  monitoringServer,
  lifecycle,
  log,
  shutdownTimeoutMs,
}: ShutdownContext): void => {
  closeWithGrace({ delay: shutdownTimeoutMs }, async ({ signal, err }) => {
    if (err) {
      log.error({ err }, "uncaught error, shutting down")
    } else {
      log.info({ signal }, "shutting down workers")
    }

    lifecycle.ready = false

    await drainWorkers(workers, calculateWorkerDrainTimeoutMs(shutdownTimeoutMs), log)
    await monitoringServer.stop()
    await shutdownTelemetry()

    log.info("shutdown complete")
  })
}

const start = async (): Promise<void> => {
  const env = loadEnv()
  const log = createLogger(env)
  const lifecycle: Lifecycle = { ready: false }
  const monitoringServer = createMonitoringServer({
    prometheusExporter,
    lifecycle,
    port: env.MONITORING_PORT,
    log,
  })
  await monitoringServer.start()

  const client = createCamundaClient({
    log: { level: sdkLogLevel(env.LOG_LEVEL), transport: pinoSdkTransport(log) },
  })

  log.info("verifying Camunda 8 connectivity")
  try {
    await client.getTopology()
  } catch (cause) {
    throw new Error("Failed to reach Camunda 8 cluster", { cause })
  }
  log.info("Camunda 8 reachable")

  if (env.BLUEPRINT_DEPLOY_ON_START) {
    await deployBpmn(client, log)
  }

  const services = composeApp(env)
  const workers = registerWorkers(client, services, log)
  lifecycle.ready = true
  installShutdown({
    workers,
    monitoringServer,
    lifecycle,
    log,
    shutdownTimeoutMs: env.SHUTDOWN_TIMEOUT_MS,
  })

  log.info("blueprint workers started")
}

start().catch((error: unknown) => {
  pino().fatal({ err: error }, "Failed to start blueprint")
  process.exit(1)
})
