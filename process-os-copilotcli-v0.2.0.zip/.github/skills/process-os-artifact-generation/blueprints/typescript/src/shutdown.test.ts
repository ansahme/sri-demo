import { describe, expect, it, vi } from "vitest"

import { createMockLogger } from "#test/helpers.js"
import type { RegisteredWorkers } from "./app.js"
import { calculateWorkerDrainTimeoutMs, drainWorkers } from "./shutdown.js"

type StubWorker = RegisteredWorkers[string]

interface StopResult {
  timedOut: boolean
  remainingJobs: number
}

const stoppingWorker = (result: StopResult): StubWorker =>
  ({ stopGracefully: vi.fn().mockResolvedValue(result) }) as unknown as StubWorker

const failingWorker = (error: Error): StubWorker =>
  ({ stopGracefully: vi.fn().mockRejectedValue(error) }) as unknown as StubWorker

describe("calculateWorkerDrainTimeoutMs", () => {
  it("reserves only the fixed buffer for budgets above the cap threshold", () => {
    expect(calculateWorkerDrainTimeoutMs(30_000)).toBe(28_000)
  })

  it("reserves a proportional share for budgets below the cap threshold", () => {
    expect(calculateWorkerDrainTimeoutMs(5_000)).toBe(4_000)
  })
})

describe("drainWorkers", () => {
  it("stops every worker with the given timeout", async () => {
    const a = stoppingWorker({ timedOut: false, remainingJobs: 0 })
    const b = stoppingWorker({ timedOut: false, remainingJobs: 0 })

    await drainWorkers({ a, b }, 8_000, createMockLogger())

    expect(a.stopGracefully).toHaveBeenCalledWith({ waitUpToMs: 8_000 })
    expect(b.stopGracefully).toHaveBeenCalledWith({ waitUpToMs: 8_000 })
  })

  it("warns with the worker name and remaining jobs when a worker times out", async () => {
    const log = createMockLogger()

    await drainWorkers({ slow: stoppingWorker({ timedOut: true, remainingJobs: 3 }) }, 8_000, log)

    expect(log.warn).toHaveBeenCalledTimes(1)
    expect(log.warn).toHaveBeenCalledWith(
      { worker: "slow", remainingJobs: 3 },
      "worker drain timeout, force-stopping with jobs still running",
    )
  })

  it("does not warn for workers that drain cleanly", async () => {
    const log = createMockLogger()

    await drainWorkers({ clean: stoppingWorker({ timedOut: false, remainingJobs: 0 }) }, 8_000, log)

    expect(log.warn).not.toHaveBeenCalled()
  })

  it("logs the failure and still drains the rest when a worker fails to stop", async () => {
    const surviving = stoppingWorker({ timedOut: true, remainingJobs: 1 })
    const error = new Error("stop failed")
    const log = createMockLogger()

    await drainWorkers({ failing: failingWorker(error), surviving }, 8_000, log)

    expect(surviving.stopGracefully).toHaveBeenCalledWith({ waitUpToMs: 8_000 })
    expect(log.error).toHaveBeenCalledWith(
      { worker: "failing", err: error },
      "worker failed to stop gracefully",
    )
    expect(log.warn).toHaveBeenCalledWith(
      { worker: "surviving", remainingJobs: 1 },
      "worker drain timeout, force-stopping with jobs still running",
    )
  })
})
