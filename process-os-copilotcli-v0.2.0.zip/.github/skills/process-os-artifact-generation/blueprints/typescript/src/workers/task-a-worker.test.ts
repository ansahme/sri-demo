import { describe, expect, it, vi } from "vitest"
import { buildVariables, createMockJob, createMockLogger } from "#test/helpers.js"
import type { ExternalApiAService } from "../services/external-api-a-service.js"
import { createTaskAWorker } from "./task-a-worker.js"

describe("createTaskAWorker", () => {
  it("calls processA and completes the job with the concatenated result", async () => {
    const service: ExternalApiAService = {
      processA: vi.fn().mockResolvedValue("[TEST]_valueA_byServiceA_"),
    }
    const { jobHandler } = createTaskAWorker(service, createMockLogger())
    const job = createMockJob(buildVariables())

    await jobHandler(job)

    expect(service.processA).toHaveBeenCalledWith({ a: "valueA" })
    expect(job.complete).toHaveBeenCalledWith({
      concatenatedResult: "[TEST]_valueA_byServiceA_",
    })
  })

  it("propagates errors from the service", async () => {
    const service: ExternalApiAService = {
      processA: vi.fn().mockRejectedValue(new Error("service failed")),
    }
    const { jobHandler } = createTaskAWorker(service, createMockLogger())
    const job = createMockJob(buildVariables())

    await expect(jobHandler(job)).rejects.toThrow("service failed")
    expect(job.complete).not.toHaveBeenCalled()
  })

  it("fails the job without consuming retries when the input variable is missing", async () => {
    const service: ExternalApiAService = { processA: vi.fn() }
    const { jobHandler } = createTaskAWorker(service, createMockLogger())
    const job = createMockJob(buildVariables({ a: undefined }))

    await jobHandler(job)

    expect(job.fail).toHaveBeenCalledWith(
      expect.objectContaining({
        retries: 0,
        errorMessage: expect.stringMatching(/Worker A received malformed input/),
      }),
    )
    expect(service.processA).not.toHaveBeenCalled()
    expect(job.complete).not.toHaveBeenCalled()
  })

  it("fails the job without consuming retries when the input variable has the wrong shape", async () => {
    const service: ExternalApiAService = { processA: vi.fn() }
    const { jobHandler } = createTaskAWorker(service, createMockLogger())
    // biome-ignore lint/suspicious/noExplicitAny: simulating an upstream caller that violates the schema
    const job = createMockJob(buildVariables({ a: "not-an-object" as any }))

    await jobHandler(job)

    expect(job.fail).toHaveBeenCalledWith(expect.objectContaining({ retries: 0 }))
    expect(service.processA).not.toHaveBeenCalled()
  })
})
