import { type ProcessVariablesSchema, TaskBInputSchema } from "../models/process-variables.js"
import type { Logger } from "../observability/logger.js"
import type { ExternalApiBService } from "../services/external-api-b-service.js"
import type { WorkerConfig } from "./job-handler.js"
import { WORKER_DEFAULTS } from "./worker-defaults.js"

export const createTaskBWorker = (
  service: ExternalApiBService,
  log: Logger,
): WorkerConfig<typeof ProcessVariablesSchema> => ({
  ...WORKER_DEFAULTS,
  jobType: "B",
  workerName: "task-b-worker",
  jobHandler: async (job) => {
    const parsed = TaskBInputSchema.safeParse(job.variables)
    if (!parsed.success) {
      return job.fail({
        retries: 0,
        errorMessage: `Worker B received malformed input: ${parsed.error.message}`,
      })
    }

    const { b, concatenatedResult: priorResult } = parsed.data
    log.info({ input: b }, "Worker B received input")

    const bResult = await service.processB(b)
    const concatenatedResult = `${priorResult}${bResult}`

    return job.complete({ concatenatedResult })
  },
})
