export const WORKER_DEFAULTS = {
  jobTimeoutMs: 30_000,
  maxParallelJobs: 5,
} as const
