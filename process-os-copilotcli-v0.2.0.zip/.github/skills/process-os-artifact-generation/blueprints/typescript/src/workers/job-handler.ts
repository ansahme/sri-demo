import type { JobWorkerConfig } from "@camunda8/orchestration-cluster-api"
import type { z } from "zod"

export type WorkerConfig<TVariablesSchema extends z.ZodTypeAny> = JobWorkerConfig<TVariablesSchema>

export type JobHandler<TVariablesSchema extends z.ZodTypeAny> =
  WorkerConfig<TVariablesSchema>["jobHandler"]
