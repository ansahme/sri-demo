import { describe, expect, it, vi } from "vitest"
import { buildVariables, createMockJob, createMockLogger } from "#test/helpers.js"
import type { ExternalApiBService } from "../services/external-api-b-service.js"
import { createTaskBWorker } from "./task-b-worker.js"

describe("createTaskBWorker", () => {
  it("appends processB result to the existing concatenatedResult", async () => {
    const service: ExternalApiBService = {
      processB: vi.fn().mockResolvedValue("valueB_byServiceB"),
    }
    const { jobHandler } = createTaskBWorker(service, createMockLogger())
    const job = createMockJob(buildVariables({ concatenatedResult: "[TEST]_valueA_byServiceA_" }))

    await jobHandler(job)

    expect(service.processB).toHaveBeenCalledWith({ b: "valueB" })
    expect(job.complete).toHaveBeenCalledWith({
      concatenatedResult: "[TEST]_valueA_byServiceA_valueB_byServiceB",
    })
  })

  it("fails the job without consuming retries when concatenatedResult from Worker A is missing", async () => {
    const service: ExternalApiBService = { processB: vi.fn() }
    const { jobHandler } = createTaskBWorker(service, createMockLogger())
    const job = createMockJob(buildVariables())

    await jobHandler(job)

    expect(job.fail).toHaveBeenCalledWith(
      expect.objectContaining({
        retries: 0,
        errorMessage: expect.stringMatching(/Worker B received malformed input/),
      }),
    )
    expect(service.processB).not.toHaveBeenCalled()
    expect(job.complete).not.toHaveBeenCalled()
  })

  it("fails the job without consuming retries when the input variable is missing", async () => {
    const service: ExternalApiBService = { processB: vi.fn() }
    const { jobHandler } = createTaskBWorker(service, createMockLogger())
    const job = createMockJob(buildVariables({ b: undefined }))

    await jobHandler(job)

    expect(job.fail).toHaveBeenCalledWith(expect.objectContaining({ retries: 0 }))
    expect(service.processB).not.toHaveBeenCalled()
    expect(job.complete).not.toHaveBeenCalled()
  })

  it("fails the job without consuming retries when the input variable has the wrong shape", async () => {
    const service: ExternalApiBService = { processB: vi.fn() }
    const { jobHandler } = createTaskBWorker(service, createMockLogger())
    // biome-ignore lint/suspicious/noExplicitAny: simulating an upstream caller that violates the schema
    const job = createMockJob(buildVariables({ b: { wrong: "field" } as any }))

    await jobHandler(job)

    expect(job.fail).toHaveBeenCalledWith(expect.objectContaining({ retries: 0 }))
    expect(service.processB).not.toHaveBeenCalled()
  })
})
