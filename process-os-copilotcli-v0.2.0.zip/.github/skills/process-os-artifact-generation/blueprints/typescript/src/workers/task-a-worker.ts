import { ObjectASchema, type ProcessVariablesSchema } from "../models/process-variables.js"
import type { Logger } from "../observability/logger.js"
import type { ExternalApiAService } from "../services/external-api-a-service.js"
import type { WorkerConfig } from "./job-handler.js"
import { WORKER_DEFAULTS } from "./worker-defaults.js"

export const createTaskAWorker = (
  service: ExternalApiAService,
  log: Logger,
): WorkerConfig<typeof ProcessVariablesSchema> => ({
  ...WORKER_DEFAULTS,
  jobType: "A",
  workerName: "task-a-worker",
  jobHandler: async (job) => {
    const parsed = ObjectASchema.safeParse(job.variables.a)
    if (!parsed.success) {
      return job.fail({
        retries: 0,
        errorMessage: `Worker A received malformed input: ${parsed.error.message}`,
      })
    }

    log.info({ input: parsed.data }, "Worker A received input")

    const concatenatedResult = await service.processA(parsed.data)

    return job.complete({ concatenatedResult })
  },
})
