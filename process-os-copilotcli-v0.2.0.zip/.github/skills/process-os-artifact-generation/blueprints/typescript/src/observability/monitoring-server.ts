import { type PrometheusExporter, PrometheusSerializer } from "@opentelemetry/exporter-prometheus"
import { fastify } from "fastify"

import type { Logger } from "./logger.js"

export interface Lifecycle {
  ready: boolean
}

export interface MonitoringServerOptions {
  prometheusExporter: PrometheusExporter
  lifecycle: Lifecycle
  port: number
  log: Logger
}

export type MonitoringServer = ReturnType<typeof createMonitoringServer>

const PROMETHEUS_CONTENT_TYPE = "text/plain; version=0.0.4; charset=utf-8"
const SUPPRESS_TARGET_INFO = true
const SUPPRESS_SCOPE_INFO = true
const serializer = new PrometheusSerializer(
  undefined,
  false,
  undefined,
  SUPPRESS_TARGET_INFO,
  SUPPRESS_SCOPE_INFO,
)

export const createMonitoringServer = (options: MonitoringServerOptions) => {
  const { prometheusExporter, lifecycle, port, log } = options
  const app = fastify({ logger: false })

  app.get("/healthz", async () => ({ status: "ok" }))

  app.get("/readyz", async (_req, reply) => {
    if (!lifecycle.ready) {
      reply.code(503)
      return { status: "starting" }
    }
    return { status: "ready" }
  })

  app.get("/metrics", async (_req, reply) => {
    const { resourceMetrics, errors } = await prometheusExporter.collect()
    if (errors.length > 0) {
      log.error({ errors }, "metric collection failed")
      reply.code(500)
      return "metric collection error"
    }
    reply.type(PROMETHEUS_CONTENT_TYPE)
    return serializer.serialize(resourceMetrics)
  })

  return {
    app,
    start: async (): Promise<void> => {
      await app.listen({ port, host: "0.0.0.0" })
    },
    stop: async (): Promise<void> => {
      await app.close()
    },
  }
}
