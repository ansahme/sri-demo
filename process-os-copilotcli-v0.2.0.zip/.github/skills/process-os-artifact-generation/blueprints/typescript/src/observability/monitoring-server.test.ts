import { PrometheusExporter } from "@opentelemetry/exporter-prometheus"
import { MeterProvider } from "@opentelemetry/sdk-metrics"
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest"

import { createMockLogger } from "#test/helpers.js"
import type { Logger } from "./logger.js"
import {
  createMonitoringServer,
  type Lifecycle,
  type MonitoringServer,
} from "./monitoring-server.js"

describe("createMonitoringServer", () => {
  let server: MonitoringServer
  let lifecycle: Lifecycle
  let meterProvider: MeterProvider
  let prometheusExporter: PrometheusExporter
  let log: Logger

  beforeEach(async () => {
    prometheusExporter = new PrometheusExporter({ preventServerStart: true })
    meterProvider = new MeterProvider({ readers: [prometheusExporter] })

    lifecycle = { ready: false }
    log = createMockLogger()
    server = createMonitoringServer({
      prometheusExporter,
      lifecycle,
      port: 0,
      log,
    })
    await server.start()
  })

  afterEach(async () => {
    vi.restoreAllMocks()
    await server.stop()
    await meterProvider.shutdown()
  })

  it("returns 200 on /healthz", async () => {
    const response = await server.app.inject({ method: "GET", url: "/healthz" })

    expect(response.statusCode).toBe(200)
    expect(response.json()).toEqual({ status: "ok" })
  })

  it("returns 503 on /readyz before lifecycle.ready is flipped", async () => {
    const response = await server.app.inject({ method: "GET", url: "/readyz" })

    expect(response.statusCode).toBe(503)
    expect(response.json()).toEqual({ status: "starting" })
  })

  it("returns 200 on /readyz once lifecycle.ready is true", async () => {
    lifecycle.ready = true

    const response = await server.app.inject({ method: "GET", url: "/readyz" })

    expect(response.statusCode).toBe(200)
    expect(response.json()).toEqual({ status: "ready" })
  })

  it("serves Prometheus exposition on /metrics", async () => {
    meterProvider.getMeter("test").createCounter("blueprint_test_counter").add(1)

    const response = await server.app.inject({ method: "GET", url: "/metrics" })

    expect(response.statusCode).toBe(200)
    expect(response.headers["content-type"]).toMatch(/text\/plain.*version=0\.0\.4/)
    expect(response.body).toContain("blueprint_test_counter")
  })

  it("returns 500 on /metrics when metric collection produces errors", async () => {
    vi.spyOn(prometheusExporter, "collect").mockResolvedValueOnce({
      resourceMetrics: { resource: undefined, scopeMetrics: [] },
      errors: [new Error("boom")],
    } as never)

    const response = await server.app.inject({ method: "GET", url: "/metrics" })

    expect(response.statusCode).toBe(500)
    expect(response.body).toBe("metric collection error")
    expect(log.error).toHaveBeenCalledWith(
      expect.objectContaining({ errors: expect.any(Array) }),
      "metric collection failed",
    )
  })
})
