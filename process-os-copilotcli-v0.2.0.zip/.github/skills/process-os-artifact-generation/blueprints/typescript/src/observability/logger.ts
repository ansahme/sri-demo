import type { LogLevel, LogTransport } from "@camunda8/orchestration-cluster-api/logger"
import { type Logger as PinoLogger, pino } from "pino"

import type { Env } from "../config/env.js"

export type Logger = PinoLogger

export const createLogger = (env: Pick<Env, "LOG_LEVEL" | "LOG_PRETTY">): Logger =>
  pino({
    level: env.LOG_LEVEL,
    ...(env.LOG_PRETTY && {
      transport: {
        target: "pino-pretty",
        options: { colorize: true, translateTime: "SYS:HH:MM:ss.l", ignore: "pid,hostname" },
      },
    }),
  })

export const sdkLogLevel = (level: Env["LOG_LEVEL"]): LogLevel =>
  level === "fatal" ? "error" : level

export const pinoSdkTransport =
  (log: Logger): LogTransport =>
  (event) => {
    if (event.level === "silent") {
      return
    }

    const pinoLevel = event.level === "silly" ? "trace" : event.level

    const messageParts: string[] = []
    const bindings: Record<string, unknown> = {}
    const errors: Error[] = []
    for (const arg of event.args) {
      if (arg instanceof Error) {
        errors.push(arg)
      } else if (typeof arg === "string") {
        messageParts.push(arg)
      } else if (arg !== null && typeof arg === "object") {
        Object.assign(bindings, arg)
      } else {
        messageParts.push(String(arg))
      }
    }

    if (errors.length > 0) {
      bindings.err = errors.length === 1 ? errors[0] : new AggregateError(errors)
    }

    bindings.scope = event.scope
    if (event.code) {
      bindings.code = event.code
    }
    if (event.data !== undefined) {
      bindings.data = event.data
    }

    log[pinoLevel](bindings, messageParts.join(" "))
  }
