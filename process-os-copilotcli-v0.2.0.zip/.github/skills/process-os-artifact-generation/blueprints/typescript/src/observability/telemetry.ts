import { PrometheusExporter } from "@opentelemetry/exporter-prometheus"
import { RuntimeNodeInstrumentation } from "@opentelemetry/instrumentation-runtime-node"
import { UndiciInstrumentation } from "@opentelemetry/instrumentation-undici"
import { NodeSDK } from "@opentelemetry/sdk-node"

process.env.OTEL_TRACES_EXPORTER ??= "none"

export const prometheusExporter = new PrometheusExporter({ preventServerStart: true })

const sdk = new NodeSDK({
  serviceName: process.env.OTEL_SERVICE_NAME ?? "engagement-blueprint",
  metricReaders: [prometheusExporter],
  instrumentations: [new UndiciInstrumentation(), new RuntimeNodeInstrumentation()],
})

sdk.start()

let shutdownPromise: Promise<void> | undefined
export const shutdownTelemetry = (): Promise<void> => {
  shutdownPromise ??= sdk.shutdown()
  return shutdownPromise
}
