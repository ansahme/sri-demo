import { Writable } from "node:stream"
import type { LogEvent } from "@camunda8/orchestration-cluster-api/logger"
import { pino } from "pino"
import { describe, expect, it } from "vitest"

import { type Logger, pinoSdkTransport, sdkLogLevel } from "./logger.js"

const capture = () => {
  const lines: Record<string, unknown>[] = []
  const stream = new Writable({
    write(chunk, _encoding, callback) {
      for (const line of chunk.toString().split("\n").filter(Boolean)) {
        lines.push(JSON.parse(line))
      }
      callback()
    },
  })
  const log: Logger = pino({ level: "trace" }, stream)
  return { transport: pinoSdkTransport(log), lines }
}

const event = (level: LogEvent["level"], extras: Partial<LogEvent> = {}): LogEvent => ({
  level,
  scope: "sdk",
  ts: Date.now(),
  args: ["hello"],
  ...extras,
})

describe("pinoSdkTransport", () => {
  it("routes each SDK level to the corresponding Pino level", () => {
    const { transport, lines } = capture()

    transport(event("trace"))
    transport(event("debug"))
    transport(event("info"))
    transport(event("warn"))
    transport(event("error"))

    expect(lines.map((line) => line.level)).toEqual([10, 20, 30, 40, 50])
  })

  it("maps the SDK 'silly' level to Pino 'trace'", () => {
    const { transport, lines } = capture()

    transport(event("silly"))

    expect(lines[0]).toMatchObject({ level: 10 })
  })

  it("drops events at the 'silent' level", () => {
    const { transport, lines } = capture()

    transport(event("silent"))

    expect(lines).toHaveLength(0)
  })

  it("attaches scope, code, and data to the structured log record", () => {
    const { transport, lines } = capture()

    transport(event("info", { scope: "worker:A", code: "JOB_001", data: { jobKey: "k1" } }))

    expect(lines[0]).toMatchObject({
      level: 30,
      scope: "worker:A",
      code: "JOB_001",
      data: { jobKey: "k1" },
      msg: "hello",
    })
  })

  it("omits code and data when absent", () => {
    const { transport, lines } = capture()

    transport(event("info"))

    expect(lines[0]).toMatchObject({ scope: "sdk", msg: "hello" })
    expect(lines[0]).not.toHaveProperty("code")
    expect(lines[0]).not.toHaveProperty("data")
  })

  it("routes Error args to 'err' with message, type, and stack preserved", () => {
    const { transport, lines } = capture()
    const boom = new Error("malformed input")

    transport(event("error", { scope: "worker:A", args: ["job.handler.error", boom] }))

    const [line] = lines
    expect(line).toMatchObject({
      level: 50,
      scope: "worker:A",
      msg: "job.handler.error",
      err: { type: "Error", message: "malformed input" },
    })
    const err = line?.err as { stack: string }
    expect(err.stack).toContain("malformed input")
  })

  it("aggregates multiple Error args under err.aggregateErrors in order", () => {
    const { transport, lines } = capture()
    const primary = new Error("primary cause")
    const secondary = new Error("secondary cause")

    transport(event("error", { args: ["job.handler.error", primary, secondary] }))

    expect(lines[0]).toMatchObject({
      level: 50,
      msg: "job.handler.error",
      err: {
        type: "AggregateError",
        aggregateErrors: [
          { type: "Error", message: "primary cause" },
          { type: "Error", message: "secondary cause" },
        ],
      },
    })
  })

  it("merges plain object args into the structured record", () => {
    const { transport, lines } = capture()

    transport(event("warn", { args: ["job.handler.noAction", { jobKey: "k1" }] }))

    expect(lines[0]).toMatchObject({
      level: 40,
      scope: "sdk",
      jobKey: "k1",
      msg: "job.handler.noAction",
    })
  })
})

describe("sdkLogLevel", () => {
  it("collapses Pino 'fatal' to the SDK 'error' level", () => {
    expect(sdkLogLevel("fatal")).toBe("error")
  })

  it("passes through levels the SDK shares with Pino", () => {
    expect(sdkLogLevel("warn")).toBe("warn")
    expect(sdkLogLevel("info")).toBe("info")
    expect(sdkLogLevel("debug")).toBe("debug")
    expect(sdkLogLevel("trace")).toBe("trace")
    expect(sdkLogLevel("silent")).toBe("silent")
  })
})
