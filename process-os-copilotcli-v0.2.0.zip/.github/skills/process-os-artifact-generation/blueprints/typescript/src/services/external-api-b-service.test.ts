import { describe, expect, it, vi } from "vitest"

import type { ExternalApiBClient } from "../clients/external-api-b-client.js"
import { ExternalApiError } from "../errors/external-api-error.js"
import { createExternalApiBService } from "./external-api-b-service.js"

const SUCCESS_RESPONSE = { success: true, suffix: "_byServiceB" }

const createMockClient = (): ExternalApiBClient => ({ get: vi.fn() })

describe("createExternalApiBService", () => {
  it("appends the API suffix to the input", async () => {
    const client = createMockClient()
    vi.mocked(client.get).mockResolvedValue(SUCCESS_RESPONSE)
    const subject = createExternalApiBService(client)

    const result = await subject.processB({ b: "valueB" })

    expect(client.get).toHaveBeenCalledWith("valueB")
    expect(result).toBe("valueB_byServiceB")
  })

  it("throws ExternalApiError when the response is unsuccessful", async () => {
    const client = createMockClient()
    vi.mocked(client.get).mockResolvedValue({ success: false, suffix: "_byServiceB" })
    const subject = createExternalApiBService(client)

    await expect(subject.processB({ b: "valueB" })).rejects.toThrow(
      new ExternalApiError('API B rejected input "valueB"'),
    )
  })

  it("propagates client errors", async () => {
    const client = createMockClient()
    const cause = new Error("boom")
    vi.mocked(client.get).mockRejectedValue(cause)
    const subject = createExternalApiBService(client)

    await expect(subject.processB({ b: "valueB" })).rejects.toBe(cause)
  })
})
