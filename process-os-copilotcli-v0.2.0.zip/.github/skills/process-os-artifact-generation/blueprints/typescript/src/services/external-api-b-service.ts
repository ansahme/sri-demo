import type { ExternalApiBClient } from "../clients/external-api-b-client.js"
import { ExternalApiError } from "../errors/external-api-error.js"
import type { ObjectB } from "../models/process-variables.js"

export const createExternalApiBService = (client: ExternalApiBClient) => ({
  async processB(input: ObjectB): Promise<string> {
    const response = await client.get(input.b)
    if (!response.success) {
      throw new ExternalApiError(`API B rejected input "${input.b}"`)
    }
    return `${input.b}${response.suffix}`
  },
})

export type ExternalApiBService = ReturnType<typeof createExternalApiBService>
