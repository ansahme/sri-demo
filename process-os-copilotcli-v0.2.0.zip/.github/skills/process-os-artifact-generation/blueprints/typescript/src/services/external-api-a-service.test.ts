import { describe, expect, it, vi } from "vitest"

import type { ExternalApiAClient } from "../clients/external-api-a-client.js"
import type { BlueprintProperties } from "../config/blueprint-properties.js"
import { ExternalApiError } from "../errors/external-api-error.js"
import { createExternalApiAService } from "./external-api-a-service.js"

const PROPERTIES: BlueprintProperties = { resultPrefix: "[TEST]_" }
const SUCCESS_RESPONSE = { success: true, suffix: "_byServiceA_" }

const createMockClient = (): ExternalApiAClient => ({ get: vi.fn() })

describe("createExternalApiAService", () => {
  it("prepends the configured prefix and appends the API suffix", async () => {
    const client = createMockClient()
    vi.mocked(client.get).mockResolvedValue(SUCCESS_RESPONSE)
    const subject = createExternalApiAService(client, PROPERTIES)

    const result = await subject.processA({ a: "valueA" })

    expect(client.get).toHaveBeenCalledWith("valueA")
    expect(result).toBe("[TEST]_valueA_byServiceA_")
  })

  it("handles an empty input string", async () => {
    const client = createMockClient()
    vi.mocked(client.get).mockResolvedValue(SUCCESS_RESPONSE)
    const subject = createExternalApiAService(client, PROPERTIES)

    const result = await subject.processA({ a: "" })

    expect(result).toBe("[TEST]__byServiceA_")
  })

  it("throws ExternalApiError when the response is unsuccessful", async () => {
    const client = createMockClient()
    vi.mocked(client.get).mockResolvedValue({ success: false, suffix: "_byServiceA_" })
    const subject = createExternalApiAService(client, PROPERTIES)

    await expect(subject.processA({ a: "valueA" })).rejects.toThrow(
      new ExternalApiError('API A rejected input "valueA"'),
    )
  })

  it("propagates client errors", async () => {
    const client = createMockClient()
    const cause = new Error("boom")
    vi.mocked(client.get).mockRejectedValue(cause)
    const subject = createExternalApiAService(client, PROPERTIES)

    await expect(subject.processA({ a: "valueA" })).rejects.toBe(cause)
  })
})
