import type { ExternalApiAClient } from "../clients/external-api-a-client.js"
import type { BlueprintProperties } from "../config/blueprint-properties.js"
import { ExternalApiError } from "../errors/external-api-error.js"
import type { ObjectA } from "../models/process-variables.js"

export const createExternalApiAService = (
  client: ExternalApiAClient,
  properties: BlueprintProperties,
) => ({
  async processA(input: ObjectA): Promise<string> {
    const response = await client.get(input.a)
    if (!response.success) {
      throw new ExternalApiError(`API A rejected input "${input.a}"`)
    }
    return `${properties.resultPrefix}${input.a}${response.suffix}`
  },
})

export type ExternalApiAService = ReturnType<typeof createExternalApiAService>
