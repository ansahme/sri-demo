import { z } from "zod"

const DEFAULT_EXTERNAL_API_BASE_URL = "http://localhost:8089"

const LOG_LEVELS = ["fatal", "error", "warn", "info", "debug", "trace", "silent"] as const

const EnvSchema = z.object({
  EXTERNAL_API_A_BASE_URL: z.url().default(DEFAULT_EXTERNAL_API_BASE_URL),
  EXTERNAL_API_B_BASE_URL: z.url().default(DEFAULT_EXTERNAL_API_BASE_URL),
  BLUEPRINT_RESULT_PREFIX: z.string().default("[DEMO]_"),
  BLUEPRINT_DEPLOY_ON_START: z.stringbool().default(false),
  LOG_LEVEL: z.enum(LOG_LEVELS).default("info"),
  LOG_PRETTY: z.stringbool().default(false),
  MONITORING_PORT: z.coerce.number().int().min(1).max(65_535).default(9464),
  HTTP_TIMEOUT_MS: z.coerce.number().int().positive().default(10_000),
  SHUTDOWN_TIMEOUT_MS: z.coerce.number().int().positive().default(10_000),
})

export type Env = z.infer<typeof EnvSchema>

export const loadEnv = (raw: NodeJS.ProcessEnv = process.env): Env => EnvSchema.parse(raw)
