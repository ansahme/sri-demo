import type { Env } from "./env.js"

export interface BlueprintProperties {
  resultPrefix: string
}

export const blueprintPropertiesFrom = (env: Env): BlueprintProperties => ({
  resultPrefix: env.BLUEPRINT_RESULT_PREFIX,
})
