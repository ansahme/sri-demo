import { describe, expect, it } from "vitest"

import { loadEnv } from "./env.js"

describe("loadEnv", () => {
  it("falls back to local defaults when no env vars are set", () => {
    const env = loadEnv({})

    expect(env.EXTERNAL_API_A_BASE_URL).toBe("http://localhost:8089")
    expect(env.EXTERNAL_API_B_BASE_URL).toBe("http://localhost:8089")
    expect(env.BLUEPRINT_RESULT_PREFIX).toBe("[DEMO]_")
    expect(env.BLUEPRINT_DEPLOY_ON_START).toBe(false)
    expect(env.LOG_LEVEL).toBe("info")
    expect(env.LOG_PRETTY).toBe(false)
    expect(env.MONITORING_PORT).toBe(9464)
    expect(env.HTTP_TIMEOUT_MS).toBe(10_000)
    expect(env.SHUTDOWN_TIMEOUT_MS).toBe(10_000)
  })

  it("coerces numeric env vars from strings", () => {
    const env = loadEnv({
      MONITORING_PORT: "9000",
      HTTP_TIMEOUT_MS: "5000",
      SHUTDOWN_TIMEOUT_MS: "30000",
    })

    expect(env.MONITORING_PORT).toBe(9000)
    expect(env.HTTP_TIMEOUT_MS).toBe(5_000)
    expect(env.SHUTDOWN_TIMEOUT_MS).toBe(30_000)
  })

  it("rejects non-positive timeouts", () => {
    expect(() => loadEnv({ HTTP_TIMEOUT_MS: "0" })).toThrow()
    expect(() => loadEnv({ SHUTDOWN_TIMEOUT_MS: "-1" })).toThrow()
  })

  it("rejects an out-of-range monitoring port", () => {
    expect(() => loadEnv({ MONITORING_PORT: "0" })).toThrow()
    expect(() => loadEnv({ MONITORING_PORT: "70000" })).toThrow()
  })

  it("reads values from the environment", () => {
    const env = loadEnv({
      EXTERNAL_API_A_BASE_URL: "http://wiremock:8080",
      EXTERNAL_API_B_BASE_URL: "http://other:9000",
      BLUEPRINT_RESULT_PREFIX: "[TEST]_",
      BLUEPRINT_DEPLOY_ON_START: "true",
      LOG_LEVEL: "debug",
      LOG_PRETTY: "true",
    })

    expect(env.EXTERNAL_API_A_BASE_URL).toBe("http://wiremock:8080")
    expect(env.EXTERNAL_API_B_BASE_URL).toBe("http://other:9000")
    expect(env.BLUEPRINT_RESULT_PREFIX).toBe("[TEST]_")
    expect(env.BLUEPRINT_DEPLOY_ON_START).toBe(true)
    expect(env.LOG_LEVEL).toBe("debug")
    expect(env.LOG_PRETTY).toBe(true)
  })

  it("throws when an external API URL is malformed", () => {
    expect(() => loadEnv({ EXTERNAL_API_A_BASE_URL: "not-a-url" })).toThrow()
  })

  it("throws when LOG_LEVEL is unknown", () => {
    expect(() => loadEnv({ LOG_LEVEL: "loud" })).toThrow()
  })
})
