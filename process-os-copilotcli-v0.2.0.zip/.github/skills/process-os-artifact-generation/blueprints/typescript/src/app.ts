import type { CamundaClient, JobWorker } from "@camunda8/orchestration-cluster-api"

import { createExternalApiAClient } from "./clients/external-api-a-client.js"
import { createExternalApiBClient } from "./clients/external-api-b-client.js"
import { createHttpClient } from "./clients/http-client.js"
import { blueprintPropertiesFrom } from "./config/blueprint-properties.js"
import type { Env } from "./config/env.js"
import type { Logger } from "./observability/logger.js"
import {
  createExternalApiAService,
  type ExternalApiAService,
} from "./services/external-api-a-service.js"
import {
  createExternalApiBService,
  type ExternalApiBService,
} from "./services/external-api-b-service.js"
import { createTaskAWorker } from "./workers/task-a-worker.js"
import { createTaskBWorker } from "./workers/task-b-worker.js"

export interface AppServices {
  apiAService: ExternalApiAService
  apiBService: ExternalApiBService
}

export const composeApp = (env: Env): AppServices => {
  const properties = blueprintPropertiesFrom(env)
  const apiAClient = createExternalApiAClient(
    createHttpClient({ baseUrl: env.EXTERNAL_API_A_BASE_URL, timeoutMs: env.HTTP_TIMEOUT_MS }),
  )
  const apiBClient = createExternalApiBClient(
    createHttpClient({ baseUrl: env.EXTERNAL_API_B_BASE_URL, timeoutMs: env.HTTP_TIMEOUT_MS }),
  )
  return {
    apiAService: createExternalApiAService(apiAClient, properties),
    apiBService: createExternalApiBService(apiBClient),
  }
}

export type RegisteredWorkers = Record<string, JobWorker>

export const registerWorkers = (
  client: CamundaClient,
  services: AppServices,
  log: Logger,
): RegisteredWorkers => ({
  A: client.createJobWorker(createTaskAWorker(services.apiAService, log)),
  B: client.createJobWorker(createTaskBWorker(services.apiBService, log)),
})
