import type { CamundaClient, JobWorker } from "@camunda8/orchestration-cluster-api"
import { beforeEach, describe, expect, it, vi } from "vitest"

import { createMockLogger } from "#test/helpers.js"

const mocks = vi.hoisted(() => ({
  createHttpClient: vi.fn(() => ({ getJson: vi.fn() })),
  createExternalApiAClient: vi.fn(() => ({ get: vi.fn() })),
  createExternalApiBClient: vi.fn(() => ({ get: vi.fn() })),
  createExternalApiAService: vi.fn(() => ({ processA: vi.fn() })),
  createExternalApiBService: vi.fn(() => ({ processB: vi.fn() })),
}))

vi.mock("./clients/http-client.js", () => ({
  createHttpClient: mocks.createHttpClient,
}))
vi.mock("./clients/external-api-a-client.js", () => ({
  createExternalApiAClient: mocks.createExternalApiAClient,
}))
vi.mock("./clients/external-api-b-client.js", () => ({
  createExternalApiBClient: mocks.createExternalApiBClient,
}))
vi.mock("./services/external-api-a-service.js", () => ({
  createExternalApiAService: mocks.createExternalApiAService,
}))
vi.mock("./services/external-api-b-service.js", () => ({
  createExternalApiBService: mocks.createExternalApiBService,
}))

import { composeApp, registerWorkers } from "./app.js"
import { loadEnv } from "./config/env.js"

beforeEach(() => {
  vi.clearAllMocks()
})

describe("composeApp", () => {
  it("flows the configured HTTP timeout into both API clients", () => {
    const env = loadEnv({ HTTP_TIMEOUT_MS: "1234" })

    composeApp(env)

    expect(mocks.createHttpClient).toHaveBeenCalledWith({
      baseUrl: env.EXTERNAL_API_A_BASE_URL,
      timeoutMs: 1234,
    })
    expect(mocks.createHttpClient).toHaveBeenCalledWith({
      baseUrl: env.EXTERNAL_API_B_BASE_URL,
      timeoutMs: 1234,
    })
  })

  it("injects blueprint properties into service A but not service B", () => {
    const env = loadEnv({ BLUEPRINT_RESULT_PREFIX: "[X]_" })

    composeApp(env)

    expect(mocks.createExternalApiAService).toHaveBeenCalledWith(expect.anything(), {
      resultPrefix: "[X]_",
    })
    expect(mocks.createExternalApiBService).toHaveBeenCalledWith(expect.anything())
    expect(mocks.createExternalApiBService.mock.calls[0]).toHaveLength(1)
  })

  it("exposes both services on AppServices", () => {
    const services = composeApp(loadEnv({}))

    expect(services.apiAService).toHaveProperty("processA")
    expect(services.apiBService).toHaveProperty("processB")
  })
})

describe("registerWorkers", () => {
  it("binds job type A to service A and job type B to service B", () => {
    const services = composeApp(loadEnv({}))
    const configs: Array<{ jobType: string }> = []
    const client = {
      createJobWorker: (cfg: { jobType: string }) => {
        configs.push(cfg)
        return {} as JobWorker
      },
    } as unknown as CamundaClient

    const workers = registerWorkers(client, services, createMockLogger())

    expect(Object.keys(workers)).toEqual(["A", "B"])
    expect(configs.map((config) => config.jobType)).toEqual(["A", "B"])
  })
})
