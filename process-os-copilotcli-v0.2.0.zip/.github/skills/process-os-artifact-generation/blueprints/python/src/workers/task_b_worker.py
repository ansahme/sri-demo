"""Worker B — composite validation, calls service."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from camunda_orchestration_sdk.runtime.job_worker import JobFailure, WorkerConfig
from pydantic import ValidationError

from src.models.process_variables import TaskBInput
from src.workers.worker_defaults import WORKER_DEFAULTS

if TYPE_CHECKING:
    import logging
    from collections.abc import Callable

    from src.services.external_api_b_service import ExternalApiBService


def create_task_b_worker(
    service: ExternalApiBService,
    log: logging.Logger,
) -> tuple[WorkerConfig, Callable[..., Any]]:
    """Factory: returns (config, handler) for worker registration."""

    async def handler(job: Any) -> dict[str, Any]:
        raw_vars = job.variables.additional_properties

        try:
            input_data = TaskBInput.model_validate(
                {
                    "b": raw_vars.get("b"),
                    "concatenated_result": raw_vars.get("concatenatedResult"),
                }
            )
        except ValidationError as e:
            raise JobFailure(message=f"Worker B received malformed input: {e}", retries=0) from e

        log.info("Worker B received input: %s", input_data)

        final_result = await service.process_b(input_data.b, input_data.concatenated_result)

        return {"finalResult": final_result}

    config = WorkerConfig(
        job_type="B",
        worker_name="task-b-worker",
        **WORKER_DEFAULTS,
    )
    return config, handler
