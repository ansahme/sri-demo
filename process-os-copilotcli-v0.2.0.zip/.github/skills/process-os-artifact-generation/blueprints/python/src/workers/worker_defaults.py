"""Default worker configuration values.

Declared as a TypedDict rather than a plain dict so that `**WORKER_DEFAULTS` keeps its
key names under strict type checking; a bare dict widens to `dict[str, int]` and mypy
can no longer match the unpacked keys against `WorkerConfig`'s parameters.
"""

from __future__ import annotations

from typing import TypedDict


class WorkerDefaults(TypedDict):
    """Shared tuning applied to every worker unless overridden per worker."""

    job_timeout_milliseconds: int
    max_concurrent_jobs: int


WORKER_DEFAULTS: WorkerDefaults = {
    "job_timeout_milliseconds": 30_000,
    "max_concurrent_jobs": 5,
}
