"""Worker A — validates input, calls service, returns result.

Follows the factory-function pattern from the TypeScript blueprint.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from camunda_orchestration_sdk.runtime.job_worker import JobFailure, WorkerConfig
from pydantic import ValidationError

from src.models.process_variables import ObjectA
from src.workers.worker_defaults import WORKER_DEFAULTS

if TYPE_CHECKING:
    import logging
    from collections.abc import Callable

    from src.services.external_api_a_service import ExternalApiAService


def create_task_a_worker(
    service: ExternalApiAService,
    log: logging.Logger,
) -> tuple[WorkerConfig, Callable[..., Any]]:
    """Factory: returns (config, handler) for worker registration."""

    async def handler(job: Any) -> dict[str, Any]:
        raw_vars = job.variables.additional_properties

        try:
            input_data = ObjectA.model_validate({"a": raw_vars.get("a")})
        except ValidationError as e:
            raise JobFailure(message=f"Worker A received malformed input: {e}", retries=0) from e

        log.info("Worker A received input: %s", input_data)

        concatenated_result = await service.process_a(input_data)

        # Return variables as dict — SDK auto-completes the job with these
        return {"concatenatedResult": concatenated_result}

    config = WorkerConfig(
        job_type="A",
        worker_name="task-a-worker",
        **WORKER_DEFAULTS,
    )
    return config, handler
