"""Client for External API A."""

from __future__ import annotations

from typing import TYPE_CHECKING

from src.models.api_response import ExternalApiAResponse

if TYPE_CHECKING:
    from src.clients.http_client import HttpClient


class ExternalApiAClient:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def get(self, input_value: str) -> ExternalApiAResponse:
        return await self._http.get_json(f"/api/a/{input_value}", ExternalApiAResponse)
