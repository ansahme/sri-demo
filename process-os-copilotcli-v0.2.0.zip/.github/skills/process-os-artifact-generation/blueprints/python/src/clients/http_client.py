"""Typed HTTP client wrapper around httpx.

Equivalent of the TypeScript blueprint's http-client.ts.
"""

from __future__ import annotations

from typing import TypeVar

import httpx
from pydantic import BaseModel, ValidationError

from src.errors.external_api_error import ExternalApiError

T = TypeVar("T", bound=BaseModel)

DEFAULT_HTTP_TIMEOUT_MS = 10_000


class HttpClient:
    """Async HTTP client with timeout, error handling, and Pydantic validation."""

    def __init__(self, *, base_url: str, timeout_ms: int = DEFAULT_HTTP_TIMEOUT_MS) -> None:
        self._client = httpx.AsyncClient(
            base_url=base_url,
            timeout=httpx.Timeout(timeout_ms / 1000),
        )

    async def get_json(self, path: str, model: type[T], *, params: dict[str, str] | None = None) -> T:
        """GET a JSON endpoint and validate the response against a Pydantic model."""
        url = path
        try:
            response = await self._client.get(url, params=params)
        except httpx.TimeoutException as exc:
            raise ExternalApiError(f"GET {url} timed out") from exc
        except httpx.HTTPError as exc:
            raise ExternalApiError(f"GET {url} failed: {exc}") from exc

        if not response.is_success:
            raise ExternalApiError(f"GET {url} returned HTTP {response.status_code}")

        try:
            data = response.json()
        except ValueError as exc:
            raise ExternalApiError(f"GET {url} returned invalid JSON") from exc

        try:
            return model.model_validate(data)
        except ValidationError as exc:
            raise ExternalApiError(f"GET {url} returned an unexpected response shape") from exc

    async def close(self) -> None:
        await self._client.aclose()
