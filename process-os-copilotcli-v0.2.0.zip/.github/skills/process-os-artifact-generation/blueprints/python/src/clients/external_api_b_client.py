"""Client for External API B."""

from __future__ import annotations

from typing import TYPE_CHECKING

from src.models.api_response import ExternalApiBResponse

if TYPE_CHECKING:
    from src.clients.http_client import HttpClient


class ExternalApiBClient:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def transform(self, input_value: str) -> ExternalApiBResponse:
        return await self._http.get_json(f"/api/b/{input_value}", ExternalApiBResponse)
