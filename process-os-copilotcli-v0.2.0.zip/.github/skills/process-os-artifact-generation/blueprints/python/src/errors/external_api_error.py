"""Custom exception for external API failures (transient — broker will retry)."""


class ExternalApiError(Exception):
    """Raised when an external HTTP call fails.

    Unhandled by the worker callback, so the SDK fails the job
    with the broker's default retry count — matching the TypeScript
    and Java blueprint pattern for transient failures.
    """
