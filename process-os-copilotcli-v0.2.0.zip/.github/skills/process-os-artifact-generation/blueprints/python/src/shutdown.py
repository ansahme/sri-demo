"""Graceful worker drain: stop polling, wait out in-flight jobs, release resources.

Equivalent of the TypeScript blueprint's shutdown.ts.

`JobWorker.stop()` is a hard stop — it cancels the polling task, stops the worker's
event loop and joins its thread with a fixed 1s timeout, without waiting for handlers
that are already running. Draining is therefore the caller's responsibility, in three
phases: stop activating new jobs, wait for `active_jobs` to reach zero, then stop the
worker. `running`, `polling_task`, `active_jobs` and `lock` are the SDK attributes that
make those phases observable; `DrainableWorker` pins the surface this module depends on.
"""

from __future__ import annotations

import asyncio
import contextlib
from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    import logging
    import threading

# Held back from the shutdown budget so post-drain cleanup (HTTP clients, monitoring
# server) still has time to run inside the orchestrator's termination grace period.
CLEANUP_HEADROOM_MS = 2_000
CLEANUP_HEADROOM_FRACTION = 0.2

DRAIN_POLL_INTERVAL_MS = 50


class DrainableWorker(Protocol):
    """The `JobWorker` surface a drain depends on."""

    running: bool
    active_jobs: int
    lock: threading.Lock

    # Read-only: the drain cancels the polling task but never replaces it. Declaring it
    # mutable would also make the protocol invariant in this member, which no longer
    # matches `JobWorker`, where the attribute is initialised to a bare `None`.
    @property
    def polling_task(self) -> asyncio.Task[None] | None: ...

    def stop(self) -> None: ...


RegisteredWorkers = dict[str, DrainableWorker]


def calculate_worker_drain_timeout_ms(shutdown_timeout_ms: int) -> int:
    """Split the shutdown budget into a drain allowance and a cleanup reserve."""
    cleanup_reserve_ms = min(
        CLEANUP_HEADROOM_MS,
        int(shutdown_timeout_ms * CLEANUP_HEADROOM_FRACTION),
    )
    return shutdown_timeout_ms - cleanup_reserve_ms


def _active_jobs(worker: DrainableWorker) -> int:
    with worker.lock:
        return worker.active_jobs


async def _stop_polling(worker: DrainableWorker) -> None:
    """Stop activating new jobs, leaving in-flight handlers to finish."""
    worker.running = False

    task = worker.polling_task
    if task is not None and not task.done():
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task


async def _await_idle(worker: DrainableWorker, wait_up_to_ms: int) -> int:
    """Wait for in-flight jobs to finish. Returns how many are still running at the deadline."""
    loop = asyncio.get_running_loop()
    deadline = loop.time() + wait_up_to_ms / 1000
    interval = DRAIN_POLL_INTERVAL_MS / 1000

    while (remaining := _active_jobs(worker)) > 0:
        if loop.time() >= deadline:
            return remaining
        await asyncio.sleep(interval)

    return 0


async def _drain_worker(
    name: str,
    worker: DrainableWorker,
    wait_up_to_ms: int,
    log: logging.Logger,
) -> None:
    try:
        await _stop_polling(worker)

        remaining = await _await_idle(worker, wait_up_to_ms)
        if remaining:
            log.warning(
                "Worker %s drain timeout, force-stopping with %d job(s) still running",
                name,
                remaining,
            )
    except Exception:
        log.exception("Worker %s failed to drain gracefully", name)
    finally:
        # stop() releases the worker's loop, thread and executor, so it runs
        # even when the drain above raised — skipping it leaks all three.
        # JobWorker.stop() only releases them while `running` is true, and
        # _stop_polling() cleared it, so restore it first. Its own failure is
        # logged rather than raised: drain_workers gathers with
        # return_exceptions=True, which would swallow it silently.
        try:
            worker.running = True
            worker.stop()
        except Exception:
            log.exception("Worker %s failed to stop", name)


async def drain_workers(
    workers: RegisteredWorkers,
    wait_up_to_ms: int,
    log: logging.Logger,
) -> None:
    """Drain every worker concurrently. One worker's failure never blocks the others."""
    await asyncio.gather(
        *(_drain_worker(name, worker, wait_up_to_ms, log) for name, worker in workers.items()),
        return_exceptions=True,
    )
