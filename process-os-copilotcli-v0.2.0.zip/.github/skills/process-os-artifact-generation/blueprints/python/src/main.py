"""Entry point: env validation, client setup, worker registration, graceful shutdown.

Equivalent of the TypeScript blueprint's main.ts.
"""

from __future__ import annotations

import asyncio
import contextlib
import signal
from pathlib import Path
from typing import TYPE_CHECKING

from camunda_orchestration_sdk import CamundaAsyncClient

from src.app import compose_app, register_workers
from src.config.env import load_env
from src.observability.logger import create_logger
from src.observability.monitoring_server import MonitoringServer
from src.shutdown import calculate_worker_drain_timeout_ms, drain_workers

if TYPE_CHECKING:
    import logging

    from src.app import AppServices
    from src.shutdown import RegisteredWorkers

BPMN_PATH = Path(__file__).parent.parent / "resources" / "blueprint-process.bpmn"


async def deploy_bpmn(client: CamundaAsyncClient, log: logging.Logger) -> None:
    log.info("Deploying BPMN process: %s", BPMN_PATH)
    await client.deploy_resources_from_files([str(BPMN_PATH)])
    log.info("BPMN deployment succeeded")


async def wait_for_shutdown_signal(log: logging.Logger) -> None:
    """Block until SIGTERM or SIGINT arrives."""
    shutdown_event = asyncio.Event()

    def _signal_handler() -> None:
        log.info("Shutdown signal received")
        shutdown_event.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, _signal_handler)
        except NotImplementedError:
            # ProactorEventLoop — Windows' default since Python 3.8 — never
            # implements add_signal_handler. signal.signal()'s handler runs
            # outside the loop, at the interpreter's own signal-check point,
            # so hand the event-set back in with call_soon_threadsafe rather
            # than touching asyncio state from it directly.
            signal.signal(sig, lambda *_args: loop.call_soon_threadsafe(_signal_handler))

    await shutdown_event.wait()


async def shutdown(
    workers: RegisteredWorkers,
    services: AppServices,
    monitoring: MonitoringServer,
    shutdown_timeout_ms: int,
    log: logging.Logger,
) -> None:
    """Tear down in dependency order, within the SHUTDOWN_TIMEOUT_MS budget.

    Readiness drops first so the orchestrator stops routing to this instance. Workers
    drain next, while the resources their handlers still hold — the outbound HTTP
    clients, and the SDK client owned by the caller's `async with` — remain open.
    """
    log.info("Shutting down workers")
    monitoring.ready = False

    await drain_workers(workers, calculate_worker_drain_timeout_ms(shutdown_timeout_ms), log)

    for http_client in services.http_clients:
        try:
            await http_client.close()
        except Exception:
            log.exception("Failed to close outbound HTTP client")

    try:
        await monitoring.stop()
    except Exception:
        log.exception("Failed to stop monitoring server")
    log.info("Shutdown complete")


async def start() -> None:
    env = load_env()
    log = create_logger(level=env.LOG_LEVEL)

    # Start monitoring server
    monitoring = MonitoringServer(port=env.MONITORING_PORT, log=log)
    await monitoring.start()

    # Connect to Camunda
    async with CamundaAsyncClient() as client:
        log.info("Verifying Camunda 8 connectivity")
        try:
            topology = await client.get_topology()
            log.info("Camunda 8 reachable: %d broker(s)", topology.cluster_size)
        except Exception as exc:
            raise RuntimeError("Failed to reach Camunda 8 cluster") from exc

        # Optional BPMN deployment
        if env.BLUEPRINT_DEPLOY_ON_START:
            await deploy_bpmn(client, log)

        # Compose application and register workers
        services = compose_app(env)
        workers = register_workers(client, services, log)
        monitoring.ready = True

        log.info("Blueprint workers started")

        await wait_for_shutdown_signal(log)

        await shutdown(workers, services, monitoring, env.SHUTDOWN_TIMEOUT_MS, log)


def main() -> None:
    with contextlib.suppress(KeyboardInterrupt):
        asyncio.run(start())


if __name__ == "__main__":
    main()
