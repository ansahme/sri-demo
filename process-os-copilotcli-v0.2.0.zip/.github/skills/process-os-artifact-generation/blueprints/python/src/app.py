"""Composition root: build clients → services → worker configs.

Equivalent of the TypeScript blueprint's app.ts.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from src.clients.external_api_a_client import ExternalApiAClient
from src.clients.external_api_b_client import ExternalApiBClient
from src.clients.http_client import HttpClient
from src.config.blueprint_properties import blueprint_properties_from
from src.services.external_api_a_service import ExternalApiAService
from src.services.external_api_b_service import ExternalApiBService
from src.workers.task_a_worker import create_task_a_worker
from src.workers.task_b_worker import create_task_b_worker

if TYPE_CHECKING:
    import logging

    from camunda_orchestration_sdk import CamundaAsyncClient

    from src.config.env import Env
    from src.shutdown import RegisteredWorkers


@dataclass
class AppServices:
    api_a_service: ExternalApiAService
    api_b_service: ExternalApiBService
    http_clients: list[HttpClient]


def compose_app(env: Env) -> AppServices:
    """Wire up all dependencies. No DI framework — explicit composition."""
    properties = blueprint_properties_from(env)

    http_a = HttpClient(base_url=env.EXTERNAL_API_A_BASE_URL, timeout_ms=env.HTTP_TIMEOUT_MS)
    http_b = HttpClient(base_url=env.EXTERNAL_API_B_BASE_URL, timeout_ms=env.HTTP_TIMEOUT_MS)

    api_a_client = ExternalApiAClient(http_a)
    api_b_client = ExternalApiBClient(http_b)

    return AppServices(
        api_a_service=ExternalApiAService(api_a_client, properties),
        api_b_service=ExternalApiBService(api_b_client),
        http_clients=[http_a, http_b],
    )


def register_workers(
    client: CamundaAsyncClient,
    services: AppServices,
    log: logging.Logger,
) -> RegisteredWorkers:
    """Register all job workers, keyed by job type.

    `create_job_worker` starts each worker, so the returned handles are the only way to
    stop one again. Callers must keep them and drain them on shutdown (see shutdown.py).
    """
    worker_factories = [
        create_task_a_worker(services.api_a_service, log),
        create_task_b_worker(services.api_b_service, log),
    ]

    workers: RegisteredWorkers = {}
    for config, handler in worker_factories:
        workers[config.job_type] = client.create_job_worker(config=config, callback=handler)

    return workers
