"""Pydantic models for external API responses."""

from __future__ import annotations

from pydantic import BaseModel


class ExternalApiAResponse(BaseModel):
    success: bool
    suffix: str


class ExternalApiBResponse(BaseModel):
    success: bool
    transformed: str
