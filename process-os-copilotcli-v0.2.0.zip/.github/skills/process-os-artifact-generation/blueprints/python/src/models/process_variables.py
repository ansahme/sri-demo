"""Pydantic models for process variable validation.

Equivalent of the TypeScript blueprint's process-variables.ts (Zod schemas).
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict


class ObjectA(BaseModel):
    a: str


class ObjectB(BaseModel):
    b: str


class RoutingDecision(StrEnum):
    APPLY_B = "applyB"
    SKIP_B = "skipB"


class TaskBInput(BaseModel):
    b: ObjectB
    concatenated_result: str


class ProcessVariables(BaseModel):
    """Union of all process variables across workers.

    extra="allow" ensures forward-compatibility: variables added
    between workers won't cause validation failures.
    """

    model_config = ConfigDict(extra="allow")

    a: ObjectA | None = None
    b: ObjectB | None = None
    routing_decision: RoutingDecision | None = None
    concatenated_result: str | None = None
