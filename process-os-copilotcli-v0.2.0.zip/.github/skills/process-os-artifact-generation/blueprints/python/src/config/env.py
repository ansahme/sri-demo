"""Environment-based configuration with Pydantic validation.

Equivalent of the TypeScript blueprint's env.ts (Zod schema).
"""

from __future__ import annotations

from enum import StrEnum
from typing import Literal

from dotenv import load_dotenv
from pydantic import Field
from pydantic_settings import BaseSettings

load_dotenv()


class AuthStrategy(StrEnum):
    NONE = "NONE"
    BASIC = "BASIC"
    OAUTH = "OAUTH"


class Env(BaseSettings):
    """Validated environment configuration.

    All fields have defaults matching .env.example so the blueprint
    works out-of-the-box with a local c8run instance.
    """

    CAMUNDA_REST_ADDRESS: str = "http://localhost:8080"
    CAMUNDA_AUTH_STRATEGY: AuthStrategy = AuthStrategy.NONE

    # BASIC auth
    CAMUNDA_BASIC_AUTH_USERNAME: str = ""
    CAMUNDA_BASIC_AUTH_PASSWORD: str = ""

    # OAuth
    CAMUNDA_CLIENT_ID: str = ""
    CAMUNDA_CLIENT_SECRET: str = ""
    CAMUNDA_OAUTH_URL: str = ""

    # Blueprint properties
    BLUEPRINT_RESULT_PREFIX: str = "[DEMO]_"
    BLUEPRINT_DEPLOY_ON_START: bool = False
    LOG_LEVEL: Literal["debug", "info", "warning", "error", "critical"] = "info"

    # External services
    EXTERNAL_API_A_BASE_URL: str = "http://localhost:8089"
    EXTERNAL_API_B_BASE_URL: str = "http://localhost:8089"

    # Observability
    MONITORING_PORT: int = Field(default=9464, ge=1, le=65535)

    # Timeouts
    HTTP_TIMEOUT_MS: int = Field(default=10_000, gt=0)
    SHUTDOWN_TIMEOUT_MS: int = Field(default=10_000, gt=0)

    model_config = {"env_file": ".env", "extra": "ignore"}


def load_env() -> Env:
    """Parse and validate environment variables."""
    return Env()
