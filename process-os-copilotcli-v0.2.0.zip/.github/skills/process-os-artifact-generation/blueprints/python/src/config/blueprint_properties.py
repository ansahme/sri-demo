"""Domain-specific blueprint configuration."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from src.config.env import Env


@dataclass(frozen=True)
class BlueprintProperties:
    result_prefix: str


def blueprint_properties_from(env: Env) -> BlueprintProperties:
    return BlueprintProperties(result_prefix=env.BLUEPRINT_RESULT_PREFIX)
