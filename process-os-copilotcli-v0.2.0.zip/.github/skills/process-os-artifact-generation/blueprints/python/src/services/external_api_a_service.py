"""Service wrapping External API A."""

from __future__ import annotations

from typing import TYPE_CHECKING

from src.errors.external_api_error import ExternalApiError

if TYPE_CHECKING:
    from src.clients.external_api_a_client import ExternalApiAClient
    from src.config.blueprint_properties import BlueprintProperties
    from src.models.process_variables import ObjectA


class ExternalApiAService:
    def __init__(self, client: ExternalApiAClient, properties: BlueprintProperties) -> None:
        self._client = client
        self._properties = properties

    async def process_a(self, input_data: ObjectA) -> str:
        response = await self._client.get(input_data.a)
        if not response.success:
            raise ExternalApiError(f'API A rejected input "{input_data.a}"')
        return f"{self._properties.result_prefix}{input_data.a}{response.suffix}"
