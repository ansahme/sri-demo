"""Service wrapping External API B."""

from __future__ import annotations

from typing import TYPE_CHECKING

from src.errors.external_api_error import ExternalApiError

if TYPE_CHECKING:
    from src.clients.external_api_b_client import ExternalApiBClient
    from src.models.process_variables import ObjectB


class ExternalApiBService:
    def __init__(self, client: ExternalApiBClient) -> None:
        self._client = client

    async def process_b(self, input_data: ObjectB, concatenated_result: str) -> str:
        response = await self._client.transform(input_data.b)
        if not response.success:
            raise ExternalApiError(f'API B rejected input "{input_data.b}"')
        return f"{concatenated_result}_{response.transformed}"
