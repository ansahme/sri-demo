"""Minimal HTTP server for health/readiness endpoints.

Equivalent of the TypeScript blueprint's monitoring-server.ts.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from aiohttp import web

if TYPE_CHECKING:
    import logging


class MonitoringServer:
    """Serves /healthz and /readyz on a dedicated port."""

    def __init__(self, *, port: int, log: logging.Logger) -> None:
        self._port = port
        self._log = log
        self._ready = False
        self._app = web.Application()
        self._app.router.add_get("/healthz", self._healthz)
        self._app.router.add_get("/readyz", self._readyz)
        self._runner: web.AppRunner | None = None

    @property
    def ready(self) -> bool:
        return self._ready

    @ready.setter
    def ready(self, value: bool) -> None:
        self._ready = value

    async def start(self) -> None:
        self._runner = web.AppRunner(self._app)
        await self._runner.setup()
        site = web.TCPSite(self._runner, "0.0.0.0", self._port)
        await site.start()
        self._log.info("Monitoring server listening on port %d", self._port)

    async def stop(self) -> None:
        if self._runner:
            await self._runner.cleanup()

    async def _healthz(self, _request: web.Request) -> web.Response:
        return web.Response(text="ok")

    async def _readyz(self, _request: web.Request) -> web.Response:
        if self._ready:
            return web.Response(text="ready")
        return web.Response(status=503, text="not ready")
