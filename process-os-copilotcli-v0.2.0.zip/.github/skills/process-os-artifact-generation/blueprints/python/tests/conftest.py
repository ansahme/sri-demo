"""Shared test fixtures."""

from __future__ import annotations

import logging
from unittest.mock import AsyncMock, MagicMock

import pytest

from src.config.blueprint_properties import BlueprintProperties
from src.models.api_response import ExternalApiAResponse, ExternalApiBResponse


@pytest.fixture
def log() -> MagicMock:
    return MagicMock(spec=logging.Logger)


@pytest.fixture
def blueprint_properties() -> BlueprintProperties:
    return BlueprintProperties(result_prefix="[TEST]_")


@pytest.fixture
def mock_api_a_client() -> AsyncMock:
    client = AsyncMock()
    client.get.return_value = ExternalApiAResponse(success=True, suffix="_result")
    return client


@pytest.fixture
def mock_api_b_client() -> AsyncMock:
    client = AsyncMock()
    client.transform.return_value = ExternalApiBResponse(success=True, transformed="transformed")
    return client


@pytest.fixture
def mock_http_client() -> AsyncMock:
    """Stand-in for HttpClient, injected into the API clients."""
    return AsyncMock()
