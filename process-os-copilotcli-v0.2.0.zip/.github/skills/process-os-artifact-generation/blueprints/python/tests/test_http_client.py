"""Tests for the HttpClient wrapper.

Uses httpx's MockTransport so the real request/response pipeline (timeouts, status
handling, JSON decoding, Pydantic validation) is exercised without a network.
"""

from __future__ import annotations

import httpx
import pytest
from pydantic import BaseModel

from src.clients.http_client import HttpClient
from src.errors.external_api_error import ExternalApiError


class _Payload(BaseModel):
    value: str


def _client_with(handler: object) -> HttpClient:
    client = HttpClient(base_url="http://test.local", timeout_ms=1_000)
    client._client = httpx.AsyncClient(  # noqa: SLF001 - swapping transport for the test
        base_url="http://test.local",
        transport=httpx.MockTransport(handler),  # type: ignore[arg-type]
    )
    return client


class TestHttpClientGetJson:
    async def test_returns_validated_model(self) -> None:
        client = _client_with(lambda _request: httpx.Response(200, json={"value": "ok"}))

        result = await client.get_json("/thing", _Payload)

        assert result == _Payload(value="ok")
        await client.close()

    async def test_passes_query_params(self) -> None:
        seen: dict[str, str] = {}

        def handler(request: httpx.Request) -> httpx.Response:
            seen.update(dict(request.url.params))
            return httpx.Response(200, json={"value": "ok"})

        client = _client_with(handler)

        await client.get_json("/thing", _Payload, params={"input": "abc"})

        assert seen == {"input": "abc"}
        await client.close()

    async def test_raises_on_error_status(self) -> None:
        client = _client_with(lambda _request: httpx.Response(500, json={}))

        with pytest.raises(ExternalApiError, match="returned HTTP 500"):
            await client.get_json("/thing", _Payload)
        await client.close()

    async def test_raises_on_invalid_json(self) -> None:
        client = _client_with(lambda _request: httpx.Response(200, content=b"not json"))

        with pytest.raises(ExternalApiError, match="invalid JSON"):
            await client.get_json("/thing", _Payload)
        await client.close()

    async def test_raises_on_timeout(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.TimeoutException("too slow", request=request)

        client = _client_with(handler)

        with pytest.raises(ExternalApiError, match="timed out"):
            await client.get_json("/thing", _Payload)
        await client.close()

    async def test_raises_on_transport_error(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            raise httpx.ConnectError("no route", request=request)

        client = _client_with(handler)

        with pytest.raises(ExternalApiError, match="failed"):
            await client.get_json("/thing", _Payload)
        await client.close()
