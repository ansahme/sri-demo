"""Tests for Worker A."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from camunda_orchestration_sdk.runtime.job_worker import JobFailure

from src.services.external_api_a_service import ExternalApiAService
from src.workers.task_a_worker import create_task_a_worker


def _make_job(variables: dict) -> MagicMock:
    """Create a mock job with the SDK's additional_properties pattern."""
    job = MagicMock()
    job.variables.additional_properties = dict(variables)
    return job


@pytest.fixture
def service(mock_api_a_client: AsyncMock, blueprint_properties) -> ExternalApiAService:
    return ExternalApiAService(mock_api_a_client, blueprint_properties)


class TestTaskAWorker:
    async def test_valid_input_completes_job(self, service: ExternalApiAService, log: MagicMock) -> None:
        _config, handler = create_task_a_worker(service, log)
        job = _make_job({"a": "hello"})

        result = await handler(job)

        assert result == {"concatenatedResult": "[TEST]_hello_result"}

    async def test_missing_input_raises_job_failure(self, service: ExternalApiAService, log: MagicMock) -> None:
        _config, handler = create_task_a_worker(service, log)
        job = _make_job({})

        with pytest.raises(JobFailure):
            await handler(job)

    async def test_worker_config(self, service: ExternalApiAService, log: MagicMock) -> None:
        config, _handler = create_task_a_worker(service, log)

        assert config.job_type == "A"
        assert config.job_timeout_milliseconds == 30_000
        assert config.max_concurrent_jobs == 5
