"""Tests for the entry point's deployable units.

`start()` itself is an integration concern (it needs a live cluster), so these cases cover only
the pieces that can be unit-tested in isolation.
"""

from __future__ import annotations

import asyncio
import signal
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from src import main as main_module
from src.shutdown import calculate_worker_drain_timeout_ms


class _FakeMonitoring:
    """Records readiness flips and its own stop, so shutdown ordering is observable."""

    def __init__(self, order: list[str]) -> None:
        self._order = order
        self._ready = True
        self.stopped = False

    @property
    def ready(self) -> bool:
        return self._ready

    @ready.setter
    def ready(self, value: bool) -> None:
        self._ready = value
        self._order.append(f"ready={value}")

    async def stop(self) -> None:
        self.stopped = True
        self._order.append("monitoring-stopped")


def _services(order: list[str], count: int = 1) -> MagicMock:
    services = MagicMock()
    services.http_clients = []
    for index in range(count):
        http_client = AsyncMock()
        http_client.close.side_effect = lambda i=index: order.append(f"http-{i}-closed")
        services.http_clients.append(http_client)
    return services


class TestBpmnPath:
    def test_points_at_a_file_that_exists(self) -> None:
        assert main_module.BPMN_PATH.is_file()

    def test_is_the_blueprint_process(self) -> None:
        assert main_module.BPMN_PATH.name == "blueprint-process.bpmn"
        assert "blueprint-process" in main_module.BPMN_PATH.read_text()


class TestDeployBpmn:
    async def test_deploys_the_bundled_resource(self, log: MagicMock) -> None:
        client = AsyncMock()

        await main_module.deploy_bpmn(client, log)

        client.deploy_resources_from_files.assert_awaited_once_with([str(main_module.BPMN_PATH)])

    async def test_logs_before_and_after(self, log: MagicMock) -> None:
        await main_module.deploy_bpmn(AsyncMock(), log)

        assert log.info.call_count == 2

    async def test_propagates_deployment_failures(self, log: MagicMock) -> None:
        client = AsyncMock()
        client.deploy_resources_from_files.side_effect = RuntimeError("rejected")

        with pytest.raises(RuntimeError, match="rejected"):
            await main_module.deploy_bpmn(client, log)


class TestShutdown:
    """The ordering contract: readiness → worker drain → HTTP clients → monitoring."""

    async def test_tears_down_in_dependency_order(self, log: MagicMock) -> None:
        order: list[str] = []
        monitoring = _FakeMonitoring(order)
        services = _services(order)
        drain = AsyncMock(side_effect=lambda *_a, **_k: order.append("workers-drained"))

        with patch.object(main_module, "drain_workers", drain):
            await main_module.shutdown({}, services, monitoring, 10_000, log)  # type: ignore[arg-type]

        assert order == [
            "ready=False",
            "workers-drained",
            "http-0-closed",
            "monitoring-stopped",
        ]

    async def test_spends_the_shutdown_budget_on_the_drain(self, log: MagicMock) -> None:
        drain = AsyncMock()

        with patch.object(main_module, "drain_workers", drain):
            await main_module.shutdown({}, _services([]), _FakeMonitoring([]), 10_000, log)  # type: ignore[arg-type]

        assert drain.await_args is not None
        assert drain.await_args.args[1] == calculate_worker_drain_timeout_ms(10_000)

    async def test_passes_the_registered_workers_to_the_drain(self, log: MagicMock) -> None:
        workers = {"A": MagicMock(), "B": MagicMock()}
        drain = AsyncMock()

        with patch.object(main_module, "drain_workers", drain):
            await main_module.shutdown(workers, _services([]), _FakeMonitoring([]), 10_000, log)  # type: ignore[arg-type]

        assert drain.await_args is not None
        assert drain.await_args.args[0] is workers

    async def test_closes_every_http_client(self, log: MagicMock) -> None:
        order: list[str] = []
        services = _services(order, count=2)

        with patch.object(main_module, "drain_workers", AsyncMock()):
            await main_module.shutdown({}, services, _FakeMonitoring(order), 10_000, log)  # type: ignore[arg-type]

        for http_client in services.http_clients:
            http_client.close.assert_awaited_once()


class TestWaitForShutdownSignal:
    async def test_returns_once_a_termination_signal_arrives(self, log: MagicMock) -> None:
        waiting = asyncio.create_task(main_module.wait_for_shutdown_signal(log))
        await asyncio.sleep(0)

        signal.raise_signal(signal.SIGTERM)

        await asyncio.wait_for(waiting, timeout=1)

    async def test_registers_a_handler_for_both_termination_signals(self, log: MagicMock) -> None:
        loop = asyncio.get_running_loop()

        with patch.object(loop, "add_signal_handler") as add_signal_handler:
            waiting = asyncio.create_task(main_module.wait_for_shutdown_signal(log))
            await asyncio.sleep(0)
            waiting.cancel()

        registered = {call.args[0] for call in add_signal_handler.call_args_list}
        assert registered == {signal.SIGTERM, signal.SIGINT}

    async def test_falls_back_to_signal_signal_when_add_signal_handler_is_unavailable(self, log: MagicMock) -> None:
        """ProactorEventLoop's shape on Windows: add_signal_handler raises NotImplementedError."""
        loop = asyncio.get_running_loop()

        with (
            patch.object(loop, "add_signal_handler", side_effect=NotImplementedError),
            patch.object(main_module.signal, "signal") as signal_signal,
        ):
            waiting = asyncio.create_task(main_module.wait_for_shutdown_signal(log))
            await asyncio.sleep(0)

            registered = {call.args[0] for call in signal_signal.call_args_list}
            assert registered == {signal.SIGTERM, signal.SIGINT}

            # Invoke the fallback handler as the interpreter would, and confirm it
            # completes the wait via call_soon_threadsafe rather than raising.
            handler = signal_signal.call_args_list[0].args[1]
            handler(signal.SIGTERM, None)

        await asyncio.wait_for(waiting, timeout=1)


class TestMain:
    """`start` is replaced with a plain MagicMock so no orphan coroutine is created.

    Mocking only `asyncio.run` would still evaluate `start()`, leaving an un-awaited
    coroutine to be garbage collected and emitting a RuntimeWarning. Letting
    `patch.object` autospec `start` does not help either: it produces an `AsyncMock`,
    whose call also returns a coroutine. An explicit `MagicMock` returns a sentinel.
    """

    def test_runs_the_async_entry_point(self) -> None:
        coroutine = object()

        with (
            patch.object(main_module, "start", MagicMock(return_value=coroutine)),
            patch.object(main_module.asyncio, "run") as run,
        ):
            main_module.main()

        run.assert_called_once_with(coroutine)

    def test_suppresses_keyboard_interrupt(self) -> None:
        with (
            patch.object(main_module, "start", MagicMock()),
            patch.object(main_module.asyncio, "run", side_effect=KeyboardInterrupt),
        ):
            main_module.main()  # must not raise
