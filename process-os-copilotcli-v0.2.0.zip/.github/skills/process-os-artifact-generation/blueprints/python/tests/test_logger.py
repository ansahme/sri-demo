"""Tests for the logger factory."""

from __future__ import annotations

import logging

from src.observability.logger import create_logger


class TestCreateLogger:
    def test_sets_requested_level(self) -> None:
        log = create_logger(name="test-level", level="debug")

        assert log.level == logging.DEBUG

    def test_falls_back_to_info_for_unknown_level(self) -> None:
        log = create_logger(name="test-unknown", level="nonsense")

        assert log.level == logging.INFO

    def test_attaches_exactly_one_handler(self) -> None:
        log = create_logger(name="test-handlers")
        create_logger(name="test-handlers")

        assert len(log.handlers) == 1

    def test_emits_formatted_output(self, capsys: object) -> None:
        log = create_logger(name="test-output", level="info")

        log.info("hello %s", "world")

        captured = capsys.readouterr()  # type: ignore[attr-defined]
        assert "hello world" in captured.out
        assert "INFO" in captured.out
