"""Tests for the External API clients (thin wrappers over HttpClient)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from src.clients.external_api_a_client import ExternalApiAClient
from src.clients.external_api_b_client import ExternalApiBClient
from src.models.api_response import ExternalApiAResponse, ExternalApiBResponse

if TYPE_CHECKING:
    from unittest.mock import AsyncMock


class TestExternalApiAClient:
    async def test_delegates_to_http_client_with_model(self, mock_http_client: AsyncMock) -> None:
        expected = ExternalApiAResponse(success=True, suffix="_x")
        mock_http_client.get_json.return_value = expected

        result = await ExternalApiAClient(mock_http_client).get("hello")

        assert result is expected
        mock_http_client.get_json.assert_awaited_once_with("/api/a/hello", ExternalApiAResponse)


class TestExternalApiBClient:
    async def test_delegates_to_http_client_with_model(self, mock_http_client: AsyncMock) -> None:
        expected = ExternalApiBResponse(success=True, transformed="X")
        mock_http_client.get_json.return_value = expected

        result = await ExternalApiBClient(mock_http_client).transform("world")

        assert result is expected
        mock_http_client.get_json.assert_awaited_once_with("/api/b/world", ExternalApiBResponse)
