"""Tests for the graceful worker drain."""

from __future__ import annotations

import asyncio
import threading
from typing import TYPE_CHECKING

import pytest

from src.shutdown import (
    CLEANUP_HEADROOM_MS,
    calculate_worker_drain_timeout_ms,
    drain_workers,
)

if TYPE_CHECKING:
    from unittest.mock import MagicMock


class FakeWorker:
    """Stands in for `JobWorker`, exposing only the `DrainableWorker` surface."""

    def __init__(self, active_jobs: int = 0, stop_error: Exception | None = None) -> None:
        self.running = True
        self.polling_task: asyncio.Task[None] | None = None
        self.active_jobs = active_jobs
        self.lock = threading.Lock()
        self.stop_error = stop_error
        self.stopped = False

    def stop(self) -> None:
        # Mirror the real SDK: stop() only acts when running is True, and clears it.
        if self.running:
            self.running = False
            self.stopped = True
        if self.stop_error is not None:
            raise self.stop_error

    def start_polling(self) -> asyncio.Task[None]:
        async def _poll() -> None:
            await asyncio.sleep(3600)

        self.polling_task = asyncio.create_task(_poll())
        return self.polling_task

    def start_polling_that_fails_on_cancel(self) -> asyncio.Task[None]:
        """A polling task whose cancellation surfaces a non-CancelledError."""

        async def _poll() -> None:
            try:
                await asyncio.sleep(3600)
            except asyncio.CancelledError:
                raise RuntimeError("cleanup hook exploded") from None

        self.polling_task = asyncio.create_task(_poll())
        return self.polling_task


class TestCalculateWorkerDrainTimeoutMs:
    def test_reserves_the_flat_headroom_on_a_generous_budget(self) -> None:
        assert calculate_worker_drain_timeout_ms(10_000) == 10_000 - CLEANUP_HEADROOM_MS

    def test_reserves_a_fraction_on_a_tight_budget(self) -> None:
        # 20% of 1000 is below the flat headroom, so the fraction wins.
        assert calculate_worker_drain_timeout_ms(1_000) == 800

    @pytest.mark.parametrize("budget", [5, 100, 1_000, 10_000, 60_000])
    def test_reserves_headroom_without_overspending_the_budget(self, budget: int) -> None:
        drain = calculate_worker_drain_timeout_ms(budget)

        assert 0 < drain < budget

    @pytest.mark.parametrize("budget", [1, 2, 3, 4])
    def test_reserves_nothing_from_a_budget_too_small_to_split(self, budget: int) -> None:
        # A sub-5ms budget floors the fraction to zero, so the whole budget goes to the
        # drain. `SHUTDOWN_TIMEOUT_MS` is validated `> 0` but not floored any higher, and
        # the TypeScript blueprint's `Math.floor` behaves the same way — kept in step.
        assert calculate_worker_drain_timeout_ms(budget) == budget


class TestDrainWorkers:
    async def test_stops_polling_for_new_jobs(self, log: MagicMock) -> None:
        worker = FakeWorker()
        task = worker.start_polling()

        await drain_workers({"A": worker}, 1_000, log)

        assert worker.running is False
        assert task.cancelled()

    async def test_releases_worker_resources(self, log: MagicMock) -> None:
        worker = FakeWorker()

        await drain_workers({"A": worker}, 1_000, log)

        assert worker.stopped is True

    async def test_tolerates_a_worker_that_never_started_polling(self, log: MagicMock) -> None:
        worker = FakeWorker()

        await drain_workers({"A": worker}, 1_000, log)

        assert worker.polling_task is None
        assert worker.stopped is True

    async def test_waits_for_in_flight_jobs_to_finish(self, log: MagicMock) -> None:
        worker = FakeWorker(active_jobs=1)

        async def _finish_job() -> None:
            await asyncio.sleep(0.02)
            with worker.lock:
                worker.active_jobs = 0

        finishing = asyncio.create_task(_finish_job())
        await drain_workers({"A": worker}, 5_000, log)
        await finishing

        assert worker.active_jobs == 0
        assert worker.stopped is True
        log.warning.assert_not_called()

    async def test_force_stops_and_warns_when_the_drain_budget_runs_out(self, log: MagicMock) -> None:
        worker = FakeWorker(active_jobs=2)

        await drain_workers({"A": worker}, 0, log)

        assert worker.stopped is True
        log.warning.assert_called_once()
        assert 2 in log.warning.call_args.args

    async def test_drains_every_worker(self, log: MagicMock) -> None:
        workers = {"A": FakeWorker(), "B": FakeWorker()}

        await drain_workers(workers, 1_000, log)

        assert all(worker.stopped for worker in workers.values())

    async def test_a_failed_drain_still_releases_worker_resources(self, log: MagicMock) -> None:
        # stop() releases the worker's loop, thread and executor, so a failure
        # in the drain phase must not skip it.
        worker = FakeWorker()
        worker.start_polling_that_fails_on_cancel()

        await drain_workers({"A": worker}, 1_000, log)

        assert worker.stopped is True
        log.exception.assert_called_once()

    async def test_one_worker_failing_does_not_block_the_others(self, log: MagicMock) -> None:
        failing = FakeWorker(stop_error=RuntimeError("pool already closed"))
        healthy = FakeWorker()

        await drain_workers({"A": failing, "B": healthy}, 1_000, log)

        assert healthy.stopped is True
        log.exception.assert_called_once()

    async def test_is_a_no_op_with_no_workers(self, log: MagicMock) -> None:
        await drain_workers({}, 1_000, log)

        log.warning.assert_not_called()
        log.exception.assert_not_called()
