"""Architecture enforcement via import-linter.

Run with: lint-imports
Or as a pytest test that shells out to the linter.
"""

from __future__ import annotations

import subprocess


def test_layer_boundaries() -> None:
    """Verify import-linter contracts pass."""
    result = subprocess.run(
        ["lint-imports"],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, f"Import linter violations:\n{result.stdout}\n{result.stderr}"
