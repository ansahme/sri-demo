"""Tests for the External API B service."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from src.errors.external_api_error import ExternalApiError
from src.models.api_response import ExternalApiBResponse
from src.models.process_variables import ObjectB
from src.services.external_api_b_service import ExternalApiBService

if TYPE_CHECKING:
    from unittest.mock import AsyncMock


class TestExternalApiBService:
    async def test_appends_to_upstream_result(self, mock_api_b_client: AsyncMock) -> None:
        service = ExternalApiBService(mock_api_b_client)

        result = await service.process_b(ObjectB(b="world"), "prefix")

        assert result == "prefix_transformed"
        mock_api_b_client.transform.assert_awaited_once_with("world")

    async def test_raises_when_api_reports_failure(self, mock_api_b_client: AsyncMock) -> None:
        mock_api_b_client.transform.return_value = ExternalApiBResponse(success=False, transformed="")
        service = ExternalApiBService(mock_api_b_client)

        with pytest.raises(ExternalApiError, match="API B rejected input"):
            await service.process_b(ObjectB(b="world"), "prefix")
