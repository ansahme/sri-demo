"""Tests for the operational HTTP endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest
from aiohttp.test_utils import TestClient, TestServer

from src.observability.monitoring_server import MonitoringServer

if TYPE_CHECKING:
    from collections.abc import AsyncIterator
    from unittest.mock import MagicMock


@pytest.fixture
def server(log: MagicMock) -> MonitoringServer:
    return MonitoringServer(port=0, log=log)


@pytest.fixture
async def client(server: MonitoringServer) -> AsyncIterator[TestClient]:
    test_client = TestClient(TestServer(server._app))  # noqa: SLF001 - inspecting the wired app
    await test_client.start_server()
    yield test_client
    await test_client.close()


class TestMonitoringServer:
    async def test_healthz_is_always_ok(self, client: TestClient) -> None:
        response = await client.get("/healthz")

        assert response.status == 200
        assert await response.text() == "ok"

    async def test_readyz_is_503_before_ready(self, client: TestClient) -> None:
        response = await client.get("/readyz")

        assert response.status == 503
        assert await response.text() == "not ready"

    async def test_readyz_is_200_once_ready(self, client: TestClient, server: MonitoringServer) -> None:
        server.ready = True

        response = await client.get("/readyz")

        assert response.status == 200
        assert await response.text() == "ready"

    async def test_readyz_flips_back_to_503(self, client: TestClient, server: MonitoringServer) -> None:
        server.ready = True
        server.ready = False

        response = await client.get("/readyz")

        assert response.status == 503

    async def test_ready_property_round_trips(self, server: MonitoringServer) -> None:
        assert server.ready is False
        server.ready = True
        assert server.ready is True

    async def test_start_and_stop_bind_a_real_socket(self, log: MagicMock) -> None:
        server = MonitoringServer(port=0, log=log)

        await server.start()
        await server.stop()

        log.info.assert_called_once()

    async def test_stop_is_safe_before_start(self, log: MagicMock) -> None:
        await MonitoringServer(port=0, log=log).stop()
