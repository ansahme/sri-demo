"""Tests for the External API A service."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from src.errors.external_api_error import ExternalApiError
from src.models.api_response import ExternalApiAResponse
from src.models.process_variables import ObjectA
from src.services.external_api_a_service import ExternalApiAService

if TYPE_CHECKING:
    from unittest.mock import AsyncMock

    from src.config.blueprint_properties import BlueprintProperties


class TestExternalApiAService:
    async def test_returns_prefixed_concatenation(
        self, mock_api_a_client: AsyncMock, blueprint_properties: BlueprintProperties
    ) -> None:
        service = ExternalApiAService(mock_api_a_client, blueprint_properties)

        result = await service.process_a(ObjectA(a="hello"))

        assert result == "[TEST]_hello_result"
        mock_api_a_client.get.assert_awaited_once_with("hello")

    async def test_raises_when_api_reports_failure(
        self, mock_api_a_client: AsyncMock, blueprint_properties: BlueprintProperties
    ) -> None:
        mock_api_a_client.get.return_value = ExternalApiAResponse(success=False, suffix="")
        service = ExternalApiAService(mock_api_a_client, blueprint_properties)

        with pytest.raises(ExternalApiError, match="API A rejected input"):
            await service.process_a(ObjectA(a="hello"))

    async def test_propagates_client_errors(
        self, mock_api_a_client: AsyncMock, blueprint_properties: BlueprintProperties
    ) -> None:
        mock_api_a_client.get.side_effect = ExternalApiError("boom")
        service = ExternalApiAService(mock_api_a_client, blueprint_properties)

        with pytest.raises(ExternalApiError, match="boom"):
            await service.process_a(ObjectA(a="hello"))
