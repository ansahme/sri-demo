"""Tests for the composition root."""

from __future__ import annotations

from typing import TYPE_CHECKING
from unittest.mock import MagicMock

from src.app import compose_app, register_workers
from src.clients.http_client import HttpClient
from src.config.env import Env
from src.services.external_api_a_service import ExternalApiAService
from src.services.external_api_b_service import ExternalApiBService

if TYPE_CHECKING:
    import pytest


def _env() -> Env:
    """Build Env ignoring any on-disk .env file."""
    return Env(_env_file=None)  # type: ignore[call-arg]


class TestComposeApp:
    def test_builds_both_services(self) -> None:
        services = compose_app(_env())

        assert isinstance(services.api_a_service, ExternalApiAService)
        assert isinstance(services.api_b_service, ExternalApiBService)

    def test_tracks_http_clients_for_shutdown(self) -> None:
        services = compose_app(_env())

        assert len(services.http_clients) == 2
        assert all(isinstance(c, HttpClient) for c in services.http_clients)

    def test_threads_result_prefix_through_to_the_service(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("BLUEPRINT_RESULT_PREFIX", "[WIRED]_")

        services = compose_app(_env())

        assert services.api_a_service._properties.result_prefix == "[WIRED]_"  # noqa: SLF001


class TestRegisterWorkers:
    def test_registers_one_worker_per_factory(self) -> None:
        client = MagicMock()
        services = compose_app(_env())
        log = MagicMock()

        workers = register_workers(client, services, log)

        assert len(workers) == 2
        assert client.create_job_worker.call_count == 2

    def test_registers_job_types_a_and_b(self) -> None:
        client = MagicMock()
        services = compose_app(_env())

        register_workers(client, services, MagicMock())

        job_types = [call.kwargs["config"].job_type for call in client.create_job_worker.call_args_list]
        assert sorted(job_types) == ["A", "B"]

    def test_passes_a_callable_handler(self) -> None:
        client = MagicMock()
        services = compose_app(_env())

        register_workers(client, services, MagicMock())

        for call in client.create_job_worker.call_args_list:
            assert callable(call.kwargs["callback"])
