"""Tests for Worker B."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from camunda_orchestration_sdk.runtime.job_worker import JobFailure

from src.services.external_api_b_service import ExternalApiBService
from src.workers.task_b_worker import create_task_b_worker


def _make_job(variables: dict) -> MagicMock:
    job = MagicMock()
    job.variables.additional_properties = dict(variables)
    return job


@pytest.fixture
def service(mock_api_b_client: AsyncMock) -> ExternalApiBService:
    return ExternalApiBService(mock_api_b_client)


class TestTaskBWorker:
    async def test_valid_input_completes_job(self, service: ExternalApiBService, log: MagicMock) -> None:
        _config, handler = create_task_b_worker(service, log)
        job = _make_job({"b": {"b": "world"}, "concatenatedResult": "prefix"})

        result = await handler(job)

        assert result == {"finalResult": "prefix_transformed"}

    async def test_missing_input_raises_job_failure(self, service: ExternalApiBService, log: MagicMock) -> None:
        _config, handler = create_task_b_worker(service, log)
        job = _make_job({})

        with pytest.raises(JobFailure):
            await handler(job)
