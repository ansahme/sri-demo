"""Tests for environment configuration loading and validation.

`src.config.env` calls `load_dotenv()` at import time, so a developer's local `.env`
would otherwise leak into these tests. Every case clears the blueprint-owned variables
first via the `clean_env` fixture.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest
from pydantic import ValidationError

from src.config.blueprint_properties import blueprint_properties_from
from src.config.env import AuthStrategy, Env

if TYPE_CHECKING:
    from collections.abc import Iterator

_MANAGED_VARS = (
    "CAMUNDA_REST_ADDRESS",
    "CAMUNDA_AUTH_STRATEGY",
    "CAMUNDA_BASIC_AUTH_USERNAME",
    "CAMUNDA_BASIC_AUTH_PASSWORD",
    "CAMUNDA_CLIENT_ID",
    "CAMUNDA_CLIENT_SECRET",
    "CAMUNDA_OAUTH_URL",
    "BLUEPRINT_RESULT_PREFIX",
    "BLUEPRINT_DEPLOY_ON_START",
    "LOG_LEVEL",
    "EXTERNAL_API_A_BASE_URL",
    "EXTERNAL_API_B_BASE_URL",
    "MONITORING_PORT",
    "HTTP_TIMEOUT_MS",
    "SHUTDOWN_TIMEOUT_MS",
)


@pytest.fixture(autouse=True)
def clean_env(monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    for name in _MANAGED_VARS:
        monkeypatch.delenv(name, raising=False)
    yield


def _load() -> Env:
    """Build Env ignoring any on-disk .env file."""
    return Env(_env_file=None)  # type: ignore[call-arg]


class TestEnvDefaults:
    def test_camunda_defaults_match_c8run(self) -> None:
        env = _load()

        assert env.CAMUNDA_REST_ADDRESS == "http://localhost:8080"
        assert env.CAMUNDA_AUTH_STRATEGY is AuthStrategy.NONE

    def test_blueprint_defaults(self) -> None:
        env = _load()

        assert env.BLUEPRINT_RESULT_PREFIX == "[DEMO]_"
        assert env.BLUEPRINT_DEPLOY_ON_START is False
        assert env.LOG_LEVEL == "info"

    def test_operational_defaults(self) -> None:
        env = _load()

        assert env.MONITORING_PORT == 9464
        assert env.HTTP_TIMEOUT_MS == 10_000
        assert env.SHUTDOWN_TIMEOUT_MS == 10_000

    def test_no_credentials_are_baked_in(self) -> None:
        env = _load()

        assert env.CAMUNDA_BASIC_AUTH_USERNAME == ""
        assert env.CAMUNDA_BASIC_AUTH_PASSWORD == ""
        assert env.CAMUNDA_CLIENT_ID == ""
        assert env.CAMUNDA_CLIENT_SECRET == ""


class TestEnvOverrides:
    def test_reads_overrides_from_environment(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("CAMUNDA_REST_ADDRESS", "http://cluster:9999")
        monkeypatch.setenv("CAMUNDA_AUTH_STRATEGY", "BASIC")
        monkeypatch.setenv("BLUEPRINT_DEPLOY_ON_START", "true")

        env = _load()

        assert env.CAMUNDA_REST_ADDRESS == "http://cluster:9999"
        assert env.CAMUNDA_AUTH_STRATEGY is AuthStrategy.BASIC
        assert env.BLUEPRINT_DEPLOY_ON_START is True

    def test_accepts_oauth_strategy(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("CAMUNDA_AUTH_STRATEGY", "OAUTH")

        assert _load().CAMUNDA_AUTH_STRATEGY is AuthStrategy.OAUTH

    def test_ignores_unrelated_environment_variables(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SOMETHING_UNRELATED", "x")

        assert _load().CAMUNDA_REST_ADDRESS == "http://localhost:8080"


class TestEnvValidation:
    def test_rejects_out_of_range_port(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("MONITORING_PORT", "70000")

        with pytest.raises(ValidationError):
            _load()

    def test_rejects_non_positive_timeout(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("HTTP_TIMEOUT_MS", "0")

        with pytest.raises(ValidationError):
            _load()

    def test_rejects_unknown_log_level(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("LOG_LEVEL", "verbose")

        with pytest.raises(ValidationError):
            _load()

    def test_rejects_unknown_auth_strategy(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("CAMUNDA_AUTH_STRATEGY", "KERBEROS")

        with pytest.raises(ValidationError):
            _load()


class TestBlueprintProperties:
    def test_extracts_result_prefix_from_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("BLUEPRINT_RESULT_PREFIX", "[X]_")

        assert blueprint_properties_from(_load()).result_prefix == "[X]_"

    def test_is_immutable(self) -> None:
        properties = blueprint_properties_from(_load())

        with pytest.raises(Exception, match="frozen|immutable|cannot assign"):
            properties.result_prefix = "nope"  # type: ignore[misc]
