package com.camunda.consulting.blueprint.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

import com.camunda.consulting.blueprint.clients.ExternalApiAClient;
import com.camunda.consulting.blueprint.config.properties.BlueprintProperties;
import com.camunda.consulting.blueprint.exceptions.ExternalApiException;
import com.camunda.consulting.blueprint.models.ApiResponse;
import com.camunda.consulting.blueprint.models.ObjectA;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ExternalApiAServiceTest {

    private static final ObjectA OBJECT_A = new ObjectA("testValue");
    private static final ApiResponse SUCCESS_RESPONSE = new ApiResponse(true, "_byServiceA_");

    @Mock ExternalApiAClient client;
    @Mock BlueprintProperties blueprintProperties;

    @InjectMocks ExternalApiAService subject;

    @Test
    void shouldProcessA() {
        // given
        when(blueprintProperties.resultPrefix()).thenReturn("[TEST]_");
        when(client.get("testValue")).thenReturn(SUCCESS_RESPONSE);

        // when
        var result = subject.processA(OBJECT_A);

        // then
        assertThat(result).isEqualTo("[TEST]_testValue_byServiceA_");
    }

    @Test
    void shouldHandleEmptyString() {
        // given
        when(blueprintProperties.resultPrefix()).thenReturn("[TEST]_");
        when(client.get("")).thenReturn(SUCCESS_RESPONSE);

        // when
        var result = subject.processA(new ObjectA(""));

        // then
        assertThat(result).isEqualTo("[TEST]__byServiceA_");
    }

    @Test
    void shouldThrowExternalApiExceptionWhenResponseIsNull() {
        // given
        when(client.get("testValue")).thenReturn(null);

        // when / then
        assertThatThrownBy(() -> subject.processA(OBJECT_A))
                .isInstanceOf(ExternalApiException.class)
                .hasMessage("Failed to process via external API A");
    }

    @Test
    void shouldThrowExternalApiExceptionWhenResponseIndicatesFailure() {
        // given
        when(client.get("testValue")).thenReturn(new ApiResponse(false, "_byServiceA_"));

        // when / then
        assertThatThrownBy(() -> subject.processA(OBJECT_A))
                .isInstanceOf(ExternalApiException.class)
                .hasMessage("Failed to process via external API A");
    }
}
