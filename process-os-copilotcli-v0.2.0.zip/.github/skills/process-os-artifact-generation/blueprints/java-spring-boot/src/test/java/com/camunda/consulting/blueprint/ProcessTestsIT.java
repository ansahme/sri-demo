package com.camunda.consulting.blueprint;

import com.camunda.consulting.blueprint.models.ObjectA;
import com.camunda.consulting.blueprint.models.ObjectB;
import com.camunda.consulting.blueprint.models.ProcessVariables;
import io.camunda.client.CamundaClient;
import io.camunda.client.api.response.ProcessInstanceEvent;
import io.camunda.process.test.api.CamundaAssert;
import io.camunda.process.test.api.CamundaProcessTestContext;
import io.camunda.process.test.api.CamundaSpringProcessTest;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@CamundaSpringProcessTest
@ActiveProfiles("wiremock-test")
public class ProcessTestsIT {

    @Autowired private CamundaClient client;
    @Autowired private CamundaProcessTestContext processTestContext;

    @Test
    void shouldProcessLinearFlow() {
        // given: the processes are deployed
        client.newDeployResourceCommand()
                .addResourceFromClasspath("blueprint-process.bpmn")
                .send()
                .join();

        // when
        ProcessVariables processVars =
                ProcessVariables.builder()
                        .a(new ObjectA("valueA"))
                        .b(new ObjectB("valueB"))
                        .build();

        final ProcessInstanceEvent processInstance =
                client.newCreateInstanceCommand()
                        .bpmnProcessId("Blueprint_Process")
                        .latestVersion()
                        .variables(processVars)
                        .send()
                        .join();
        // then
        CamundaAssert.assertThat(processInstance)
                .hasVariables(
                        Map.of(
                                "a", new ObjectA("valueA"),
                                "b", new ObjectB("valueB"),
                                "concatenatedResult", "[TEST]_valueA_byServiceA_valueB_byServiceB"))
                .isCompleted();
    }
}
