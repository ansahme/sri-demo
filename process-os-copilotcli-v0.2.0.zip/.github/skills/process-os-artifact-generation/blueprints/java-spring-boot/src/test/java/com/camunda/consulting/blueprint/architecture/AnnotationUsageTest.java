package com.camunda.consulting.blueprint.architecture;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.fields;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.methods;

import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;
import io.camunda.client.annotation.JobWorker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Verifies correct annotation usage: forbidden patterns (e.g. field injection) and annotations
 * confined to expected packages.
 */
@AnalyzeClasses(
        packages = "com.camunda.consulting.blueprint",
        importOptions = ImportOption.DoNotIncludeTests.class)
class AnnotationUsageTest {

    @ArchTest
    static final ArchRule noAutowiredFieldInjection =
            fields().should().notBeAnnotatedWith(Autowired.class);

    @ArchTest
    static final ArchRule jobWorkerAnnotationShouldOnlyBeInWorkersPackage =
            methods()
                    .that()
                    .areAnnotatedWith(JobWorker.class)
                    .should()
                    .beDeclaredInClassesThat()
                    .resideInAPackage("..workers..")
                    .allowEmptyShould(true);

    @ArchTest
    static final ArchRule configurationPropertiesClassesShouldResideInConfigPackage =
            classes()
                    .that()
                    .areAnnotatedWith(ConfigurationProperties.class)
                    .should()
                    .resideInAPackage("..config..")
                    .allowEmptyShould(true);
}
