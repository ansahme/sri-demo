package com.camunda.consulting.blueprint.architecture;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;
import static com.tngtech.archunit.library.Architectures.layeredArchitecture;

import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;

/**
 * Verifies allowed dependencies between architecture layers (Workers, Services, Models, Config).
 */
@AnalyzeClasses(
        packages = "com.camunda.consulting.blueprint",
        importOptions = ImportOption.DoNotIncludeTests.class)
class LayerArchitectureTest {

    @ArchTest
    static final ArchRule workersShouldOnlyDependOnServicesAndModels =
            classes()
                    .that()
                    .resideInAPackage("..workers..")
                    .should()
                    .onlyDependOnClassesThat()
                    .resideInAnyPackage(
                            "..workers..",
                            "..services..",
                            "..models..",
                            "..config..",
                            "..exceptions..",
                            "java..",
                            "org.springframework..",
                            "io.camunda..",
                            "org.slf4j..",
                            "lombok..")
                    .allowEmptyShould(true);

    @ArchTest
    static final ArchRule servicesShouldOnlyDependOnModels =
            classes()
                    .that()
                    .resideInAPackage("..services..")
                    .should()
                    .onlyDependOnClassesThat()
                    .resideInAnyPackage(
                            "..services..",
                            "..models..",
                            "..config..",
                            "..clients..",
                            "..exceptions..",
                            "java..",
                            "org.springframework..",
                            "org.slf4j..",
                            "lombok..")
                    .allowEmptyShould(true);

    @ArchTest
    static final ArchRule modelsShouldNotDependOnWorkersOrServices =
            classes()
                    .that()
                    .resideInAPackage("..models..")
                    .should()
                    .onlyDependOnClassesThat()
                    .resideInAnyPackage(
                            "..models..", "java..", "com.fasterxml.jackson..", "lombok..")
                    .allowEmptyShould(true);

    @ArchTest
    static final ArchRule layeredArchitectureShouldBeRespected =
            layeredArchitecture()
                    .consideringAllDependencies()
                    .withOptionalLayers(true)
                    .layer("Workers")
                    .definedBy("..workers..")
                    .layer("Services")
                    .definedBy("..services..")
                    .layer("Models")
                    .definedBy("..models..")
                    .layer("Config")
                    .definedBy("..config..")
                    .layer("Clients")
                    .definedBy("..clients..")
                    .layer("Exceptions")
                    .definedBy("..exceptions..")
                    .whereLayer("Workers")
                    .mayNotBeAccessedByAnyLayer()
                    .whereLayer("Services")
                    .mayOnlyBeAccessedByLayers("Workers", "Config")
                    .whereLayer("Clients")
                    .mayOnlyBeAccessedByLayers("Services", "Config")
                    .whereLayer("Models")
                    .mayOnlyBeAccessedByLayers("Workers", "Services", "Config", "Clients")
                    .whereLayer("Exceptions")
                    .mayOnlyBeAccessedByLayers("Workers", "Services", "Config");
}
