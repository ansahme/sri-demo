package com.camunda.consulting.blueprint.workers;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import com.camunda.consulting.blueprint.models.ObjectA;
import com.camunda.consulting.blueprint.models.ProcessVariables;
import com.camunda.consulting.blueprint.services.ExternalApiAService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TaskAWorkerTest {

    @Mock private ExternalApiAService externalApiAService;

    @InjectMocks private TaskAWorker taskAWorker;

    @Test
    void shouldProcessAAndSetConcatenatedResult() {
        // given
        ObjectA objectA = new ObjectA("testValue");
        ProcessVariables processVariables = new ProcessVariables();
        processVariables.setA(objectA);

        when(externalApiAService.processA(objectA)).thenReturn("testValue_byServiceA_");

        // when
        ProcessVariables result = taskAWorker.processA(processVariables);

        // then
        assertThat(result.getConcatenatedResult()).isEqualTo("testValue_byServiceA_");
    }

    @Test
    void shouldHandleEmptyObjectA() {
        // given
        ObjectA objectA = new ObjectA("");
        ProcessVariables processVariables = new ProcessVariables();
        processVariables.setA(objectA);

        when(externalApiAService.processA(objectA)).thenReturn("_byServiceA_");

        // when
        ProcessVariables result = taskAWorker.processA(processVariables);

        // then
        assertThat(result.getConcatenatedResult()).isEqualTo("_byServiceA_");
    }
}
