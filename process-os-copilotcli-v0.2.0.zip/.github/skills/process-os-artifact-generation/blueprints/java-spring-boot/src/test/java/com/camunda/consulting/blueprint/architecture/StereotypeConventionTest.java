package com.camunda.consulting.blueprint.architecture;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;

import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * Verifies that Spring stereotype annotations are applied where required (@Component on
 * workers, @Service on services).
 */
@AnalyzeClasses(
        packages = "com.camunda.consulting.blueprint",
        importOptions = ImportOption.DoNotIncludeTests.class)
class StereotypeConventionTest {

    @ArchTest
    static final ArchRule workersShouldBeAnnotatedWithComponent =
            classes()
                    .that()
                    .resideInAPackage("..workers..")
                    .and()
                    .haveSimpleNameEndingWith("Worker")
                    .should()
                    .beAnnotatedWith(Component.class)
                    .allowEmptyShould(true);

    @ArchTest
    static final ArchRule servicesShouldBeAnnotatedWithService =
            classes()
                    .that()
                    .resideInAPackage("..services..")
                    .and()
                    .haveSimpleNameEndingWith("Service")
                    .should()
                    .beAnnotatedWith(Service.class)
                    .allowEmptyShould(true);
}
