package com.camunda.consulting.blueprint.clients;

import com.camunda.consulting.blueprint.models.ApiResponse;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.service.annotation.GetExchange;
import org.springframework.web.service.annotation.HttpExchange;

@HttpExchange(url = "/api/service-a", accept = MediaType.APPLICATION_JSON_VALUE)
public interface ExternalApiAClient {
    @GetExchange
    ApiResponse get(@RequestParam String input);
}
