package com.camunda.consulting.blueprint.models;

public record ObjectA(String a) {}
