package com.camunda.consulting.blueprint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class BlueprintApplication {

    static void main(String[] args) {
        SpringApplication.run(BlueprintApplication.class, args);
    }
}
