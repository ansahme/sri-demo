package com.camunda.consulting.blueprint.config;

import com.camunda.consulting.blueprint.clients.ExternalApiAClient;
import com.camunda.consulting.blueprint.clients.ExternalApiBClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.service.registry.ImportHttpServices;

@Configuration
@ImportHttpServices(group = "external-a", types = ExternalApiAClient.class)
@ImportHttpServices(group = "external-b", types = ExternalApiBClient.class)
public class HttpClientsConfig {}
