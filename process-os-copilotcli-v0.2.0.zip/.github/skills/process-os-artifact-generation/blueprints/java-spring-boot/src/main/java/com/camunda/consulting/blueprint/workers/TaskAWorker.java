package com.camunda.consulting.blueprint.workers;

import com.camunda.consulting.blueprint.models.ObjectA;
import com.camunda.consulting.blueprint.models.ProcessVariables;
import com.camunda.consulting.blueprint.services.ExternalApiAService;
import io.camunda.client.annotation.JobWorker;
import io.camunda.client.annotation.VariablesAsType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class TaskAWorker {

    private final ExternalApiAService externalApiAService;

    @JobWorker(type = "A")
    public ProcessVariables processA(@VariablesAsType ProcessVariables processVariables) {
        // Retrieve relevant process variables
        ObjectA a = processVariables.getA();
        log.info("Received A: {}", a);

        // call external service
        String aResult = externalApiAService.processA(a);

        // add to process variables for further processing
        processVariables.setConcatenatedResult(aResult);
        return processVariables;
    }
}
