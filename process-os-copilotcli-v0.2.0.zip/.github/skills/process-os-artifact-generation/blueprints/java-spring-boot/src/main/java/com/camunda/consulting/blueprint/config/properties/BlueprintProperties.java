package com.camunda.consulting.blueprint.config.properties;

import jakarta.validation.constraints.NotBlank;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "blueprint")
public record BlueprintProperties(@NotBlank String resultPrefix) {}
