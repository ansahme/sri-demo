package com.camunda.consulting.blueprint.models;

public record ObjectB(String b) {}
