package com.camunda.consulting.blueprint.services;

import com.camunda.consulting.blueprint.clients.ExternalApiAClient;
import com.camunda.consulting.blueprint.config.properties.BlueprintProperties;
import com.camunda.consulting.blueprint.exceptions.ExternalApiException;
import com.camunda.consulting.blueprint.models.ApiResponse;
import com.camunda.consulting.blueprint.models.ObjectA;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ExternalApiAService {

    private final ExternalApiAClient client;
    private final BlueprintProperties blueprintProperties;

    public String processA(ObjectA objectA) {
        ApiResponse response = client.get(objectA.a());
        if (response != null && response.success()) {
            return blueprintProperties.resultPrefix() + objectA.a() + response.suffix();
        }
        throw new ExternalApiException("Failed to process via external API A");
    }
}
