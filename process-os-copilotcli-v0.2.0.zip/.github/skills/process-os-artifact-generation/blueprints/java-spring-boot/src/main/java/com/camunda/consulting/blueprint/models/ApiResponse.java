package com.camunda.consulting.blueprint.models;

// DTO for API response
public record ApiResponse(boolean success, String suffix) {}
