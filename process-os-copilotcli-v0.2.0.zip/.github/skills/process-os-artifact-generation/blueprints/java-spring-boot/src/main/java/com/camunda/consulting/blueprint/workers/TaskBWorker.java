package com.camunda.consulting.blueprint.workers;

import com.camunda.consulting.blueprint.models.ObjectB;
import com.camunda.consulting.blueprint.models.ProcessVariables;
import com.camunda.consulting.blueprint.services.ExternalApiBService;
import io.camunda.client.annotation.JobWorker;
import io.camunda.client.annotation.VariablesAsType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class TaskBWorker {

    private final ExternalApiBService externalApiBService;

    @JobWorker(type = "B")
    public ProcessVariables processB(@VariablesAsType ProcessVariables processVariables) {
        // Retrieve relevant process variables
        ObjectB b = processVariables.getB();
        log.info("Received B: {}", b);

        // call external service
        String bResult = externalApiBService.processB(b);

        // add to process variables for further processing
        String newConcatenatedResult = processVariables.getConcatenatedResult() + bResult;
        processVariables.setConcatenatedResult(newConcatenatedResult);
        return processVariables;
    }
}
