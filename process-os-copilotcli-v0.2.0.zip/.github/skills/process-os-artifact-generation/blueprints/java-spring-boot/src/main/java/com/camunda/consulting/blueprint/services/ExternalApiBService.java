package com.camunda.consulting.blueprint.services;

import com.camunda.consulting.blueprint.clients.ExternalApiBClient;
import com.camunda.consulting.blueprint.exceptions.ExternalApiException;
import com.camunda.consulting.blueprint.models.ApiResponse;
import com.camunda.consulting.blueprint.models.ObjectB;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ExternalApiBService {

    private final ExternalApiBClient client;

    public String processB(ObjectB objectB) {
        ApiResponse response = client.get(objectB.b());
        if (response != null && response.success()) {
            return objectB.b() + response.suffix();
        }
        throw new ExternalApiException("Failed to process via external API B");
    }
}
