#!/bin/bash
# Local Docker build script for engagement-blueprint
# This script builds the Docker image the same way as GitHub Actions

set -e

# Configuration
IMAGE_NAME="registry.camunda.cloud/team-consulting/engagement-blueprint"
VERSION="${1:-latest}"

echo "Building Docker image: ${IMAGE_NAME}:${VERSION}"

# Build the image
docker build \
  --tag "${IMAGE_NAME}:${VERSION}" \
  --tag "${IMAGE_NAME}:latest" \
  --build-arg BUILDKIT_INLINE_CACHE=1 \
  .

echo ""
echo "✅ Build complete!"
echo ""
echo "Image tags created:"
echo "  - ${IMAGE_NAME}:${VERSION}"
echo "  - ${IMAGE_NAME}:latest"
echo ""
echo "To run the container:"
echo "  docker run -p 8080:8080 ${IMAGE_NAME}:${VERSION}"
echo ""