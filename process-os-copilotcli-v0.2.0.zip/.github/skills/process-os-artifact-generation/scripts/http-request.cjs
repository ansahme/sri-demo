#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Make one HTTP request — the portable replacement for `curl`.
//
// In Windows PowerShell 5.1 `curl` is an ALIAS for Invoke-WebRequest, and the
// alias shadows a `curl.exe` that ships with the OS. So every `curl` call breaks
// there, not only the ones using flags PowerShell has no equivalent for: the
// step runs, binds `-s`/`-X` to the wrong cmdlet parameters, and fails on
// arguments that look perfectly ordinary.
//
// Usage:
//   node "http-request.cjs" [--method <verb>] [--header <line>]...
//        [--body-file <path>] [--status-only] [--timeout <ms>] <url>
//
//   --method <verb>   HTTP verb; defaults to GET.
//   --header <line>   one `Name: value` header. Repeatable, and repeating a name
//                     sends both values combined, as HTTP defines.
//   --body-file <p>   send this file's bytes as the request body. A body always
//                     arrives as a FILE, never as an inline argument: a
//                     single-quoted JSON literal is one string in bash and a
//                     parse error in PowerShell, where `{` opens a script block
//                     and `"` is not a literal quote. There is no spelling of
//                     `-d '{"a":1}'` that survives both shells.
//   --status-only     print just the response status code and nothing else,
//                     replacing `-o /dev/null -w "%{http_code}"`.
//   --timeout <ms>    abort after this many milliseconds; defaults to 30000. A
//                     request to a port nobody is listening on is refused at once,
//                     but one to a host that accepts and never answers would
//                     otherwise hang the agent's shell indefinitely.
//
// Redirects are followed, as `curl -L` does. The response body goes to stdout
// verbatim; nothing else ever does, so a caller may parse it.
//
// Exit codes:
//   0  the request completed. With --status-only this is the ONLY successful
//      code: a probe asking "is anything listening" is answered by `UNREACHABLE`
//      just as much as by `200`, the way probe-tools.cjs answers `NOT FOUND`.
//   1  a non-2xx response. The body is still printed, since an error body is
//      what says why; the status line goes to stderr. Without this a 404's
//      "not found" JSON would be read as the document that was asked for.
//   2  the request never reached a server — DNS, refused connection, TLS, or the
//      timeout. Never folded into 1: "there is no server" and "the server said
//      no" are different answers, and only one of them means retry later.
//   3  a usage error.
const fs = require('node:fs');

const EXIT = { OK: 0, HTTP_ERROR: 1, UNREACHABLE: 2, USAGE: 3 };

const USAGE =
  'usage: http-request.cjs [--method <verb>] [--header <line>]... ' +
  '[--body-file <path>] [--status-only] [--timeout <ms>] <url>\n';

const DEFAULT_TIMEOUT_MS = 30000;

/**
 * Split one `Name: value` header argument.
 *
 * The value keeps its own colons (`Authorization: Bearer a:b`) and is trimmed of
 * the single space that conventionally follows the colon.
 *
 * @param {string} line The `--header` argument.
 * @returns {[string, string] | null} The pair, or null when there is no colon.
 */
function parseHeader(line) {
  const at = line.indexOf(':');
  if (at <= 0) return null;
  return [line.slice(0, at).trim(), line.slice(at + 1).trim()];
}

/**
 * Split argv into flags and the URL.
 *
 * @param {string[]} argv Arguments after the script path.
 * @returns {{url: string, method: string, headers: [string, string][],
 *   bodyFile: string | null, statusOnly: boolean, timeout: number} | null}
 *   The parsed call, or null when the arguments do not form a valid one.
 */
function parseArgs(argv) {
  let method = 'GET';
  let bodyFile = null;
  let statusOnly = false;
  let timeout = DEFAULT_TIMEOUT_MS;
  /** @type {[string, string][]} */
  const headers = [];
  const positional = [];

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--status-only') statusOnly = true;
    else if (arg === '--method') {
      const value = argv[++i];
      // A flag-shaped value means the verb was left out. Taken literally,
      // `--method --status-only` sends the verb "--STATUS-ONLY" and drops the
      // probe flag; fetch then throws, and the throw is indistinguishable from a
      // dead host, so the reader is sent to debug a server that was never asked.
      if (value === undefined || value.startsWith('--')) return null;
      method = value.toUpperCase();
    } else if (arg === '--header') {
      const value = argv[++i];
      const pair = value === undefined ? null : parseHeader(value);
      // A header with no colon cannot be sent as anything. Accepting it would
      // drop the header and complete the request looking successful, which for
      // a missing `Content-Type` or `Authorization` is a silent 4xx later.
      if (pair === null) return null;
      headers.push(pair);
    } else if (arg === '--body-file') {
      const value = argv[++i];
      // Flag-shaped for the same reason: no body file is named `--status-only`,
      // and swallowing one drops the flag that followed it.
      if (value === undefined || value.startsWith('--')) return null;
      bodyFile = value;
    } else if (arg === '--timeout') {
      const value = argv[++i];
      if (value === undefined || !/^[1-9]\d*$/.test(value)) return null;
      timeout = Number(value);
    } else if (arg.startsWith('--')) {
      // An unrecognised option is a usage error, never the URL. Swallowed as one,
      // `--status` would leave two positionals and `--statusonly` would print a
      // whole body where the caller expects three digits.
      return null;
    } else positional.push(arg);
  }

  // Checked here rather than left to fetch: GET/HEAD with a body throws a
  // TypeError that lands in the same catch as a network failure, so a missing
  // `--method POST` would be misreported as UNREACHABLE instead of a usage error.
  if (bodyFile !== null && (method === 'GET' || method === 'HEAD')) return null;

  if (positional.length !== 1) return null;
  const url = positional[0];
  // Caught here rather than by fetch: an unusable URL raises the same TypeError
  // as a network failure, which would report a typo as UNREACHABLE and send the
  // reader looking for a server that was never addressed. The scheme has to be
  // checked too, not just parseability — `new URL` reads a scheme-less
  // `localhost:8080/v2/topology` as the scheme `localhost:`, so it parses
  // cleanly and only fetch discovers there is no such protocol.
  try {
    if (!/^https?:$/.test(new URL(url).protocol)) return null;
  } catch {
    return null;
  }
  return { url, method, headers, bodyFile, statusOnly, timeout };
}

/**
 * Perform the request.
 *
 * The body arrives already read. Reading it here would put a permission or IO
 * failure on the body file inside the same catch as a network failure, and it
 * would be reported as UNREACHABLE — "there is no server" — for a file the
 * caller could not open.
 *
 * @param {ReturnType<typeof parseArgs> & {}} call The parsed call.
 * @param {Buffer | undefined} body The request body, or undefined for none.
 * @returns {Promise<{status: number, body: string, statusText: string}>}
 * @throws {Error} When no response was received at all.
 */
async function request(call, body) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), call.timeout);
  try {
    const response = await fetch(call.url, {
      method: call.method,
      // The pair array, not an object built from it: an object keeps only the
      // last value for a repeated name, so two `--header Cookie: …` flags would
      // send one and drop the other with nothing to show for it. Handed the
      // array, fetch combines same-name values the way HTTP defines.
      headers: call.headers,
      body,
      redirect: 'follow',
      signal: controller.signal,
    });
    return { status: response.status, statusText: response.statusText, body: await response.text() };
  } finally {
    clearTimeout(timer);
  }
}

/**
 * The exit code is set rather than taken with `process.exit`, and the process is
 * left to end on its own. A write to a pipe is asynchronous, and `process.exit`
 * does not drain it — a response body long enough to matter is exactly the one
 * that gets truncated, and the caller parses a short answer as a complete one.
 *
 * @param {string[]} argv Arguments after the script path.
 */
async function main(argv) {
  const call = parseArgs(argv);
  if (call === null) {
    process.stderr.write(USAGE);
    process.exitCode = EXIT.USAGE;
    return;
  }

  // Read before the request, with its own message: a body file the caller meant
  // to send and misspelled must not go out as an empty POST that the server
  // answers 400 to, leaving the reader debugging the endpoint.
  let body;
  if (call.bodyFile !== null) {
    try {
      body = fs.readFileSync(call.bodyFile);
    } catch (e) {
      process.stderr.write(`http-request: cannot read body file ${call.bodyFile}: ${(e && e.message) || e}\n`);
      process.exitCode = EXIT.USAGE;
      return;
    }
  }

  let response;
  try {
    response = await request(call, body);
  } catch (e) {
    // A probe is asking whether anything is there; "nothing is" is its answer,
    // not its failure. Every other caller wants the distinct exit code.
    if (call.statusOnly) {
      process.stdout.write('UNREACHABLE\n');
      return;
    }
    process.stderr.write(`http-request: ${call.method} ${call.url}: ${(e && e.message) || e}\n`);
    process.exitCode = EXIT.UNREACHABLE;
    return;
  }

  if (call.statusOnly) {
    process.stdout.write(`${response.status}\n`);
    return;
  }
  process.stdout.write(response.body);
  if (response.status < 200 || response.status >= 300) {
    process.stderr.write(`http-request: ${response.status} ${response.statusText}\n`);
    process.exitCode = EXIT.HTTP_ERROR;
  }
}

module.exports = { EXIT, parseArgs, parseHeader, request };

if (require.main === module) main(process.argv.slice(2));
