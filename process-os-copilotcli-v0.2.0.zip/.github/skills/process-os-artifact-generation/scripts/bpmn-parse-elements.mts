#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Parses BPMN files in the given directory (e.g. a resolved transformation
// tier dir) and outputs one JSON line per file with processId and extracted
// elements (tasks, gateways, errors, annotations).

import * as fs from 'node:fs';
import * as path from 'node:path';

interface BpmnError {
  code: string;
  name: string;
}

interface Element {
  id: string;
  type: string;
  name: string;
  note: string;
  businessRule: boolean;
  bpmnErrors: BpmnError[];
  publishesMessage?: boolean;
  messageRef?: string;
  taskDefinition?: string;
  modelerTemplate?: string;
  modelerTemplateVersion?: string;
  nestedInConnectorContainer?: boolean;
}

type Attrs = Record<string, string>;

// Every `?? ''` below is a type-level fallback only: each regex group it guards is
// non-optional in its pattern, so it always participates in a successful match. The
// pre-TypeScript version passed the same values through unguarded.
const dec = (s: string): string =>
  s
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&');

const at = (s: string): Attrs =>
  Object.fromEntries([...s.matchAll(/(\w+)="([^"]*)"/g)].map((m) => [m[1] ?? '', dec(m[2] ?? '')]));

function load(filePath: string): { pid: string; elements: Element[] } | null {
  const xml = fs.readFileSync(filePath, 'utf8');
  const pm = xml.match(/<bpmn:process\b([^>]*)>([\s\S]*?)<\/bpmn:process>/);
  if (!pm) return null;
  const pid = at(pm[1] ?? '').id ?? '';
  const body = pm[2] ?? '';

  const ann: Record<string, string> = {};
  for (const m of body.matchAll(/<bpmn:textAnnotation\b([^>]*)>([\s\S]*?)<\/bpmn:textAnnotation>/g)) {
    const a = at(m[1] ?? '');
    const t = (m[2] ?? '').match(/<bpmn:text>([\s\S]*?)<\/bpmn:text>/);
    ann[a.id ?? ''] = (t ? dec(t[1] ?? '') : '').trim();
  }

  const assoc: Record<string, string> = {};
  for (const m of body.matchAll(/<bpmn:association\b([^>]*?)\/>/g)) {
    const a = at(m[1] ?? '');
    if (a.sourceRef) assoc[a.sourceRef] = a.targetRef || '';
  }

  // Resolve errorRef → errorCode via root-level <bpmn:error> elements
  const errs: Record<string, string> = {};
  for (const m of xml.matchAll(/<bpmn:error\b([^>]*?)\/>/g)) {
    const a = at(m[1] ?? '');
    if (a.id) errs[a.id] = a.errorCode || a.name || a.id;
  }

  // Map task id → list of error codes from attached boundary error events
  const errMap: Record<string, BpmnError[]> = {};
  for (const m of body.matchAll(/<bpmn:boundaryEvent\b([^>]*)>([\s\S]*?)<\/bpmn:boundaryEvent>/g)) {
    const a = at(m[1] ?? '');
    const host = a.attachedToRef || '';
    for (const em of (m[2] ?? '').matchAll(/<bpmn:errorEventDefinition\b([^>]*?)\/>/g)) {
      const ea = at(em[1] ?? '');
      const code = errs[ea.errorRef || ''] || ea.errorRef || '';
      (errMap[host] = errMap[host] || []).push({ code, name: a.name || '' });
    }
  }

  const elements: Element[] = [];
  // `intermediateThrowEvent` + `endEvent` are surfaced ONLY when they carry a
  // <bpmn:messageEventDefinition> child — those are publish-message events
  // that Zeebe runs as job workers (jobType from the element name) and that
  // analyze-phase must propose a worker for. Plain end events, terminate end
  // events, and error end events are filtered out below so they don't
  // pollute the elements[] list (catch events likewise — they're handled by
  // the receiveTask / messageSubscription path).
  // Ranges of template-bound subprocess containers (the AI Agent sub-process).
  // A nested serviceTask/task "tool" child is only NOT a worker when the tool
  // itself is connector-bound — either it carries its own zeebe:modelerTemplate,
  // or its taskDefinition type is namespace-qualified (e.g. "io.camunda:http-
  // json:1", the AI-Agent connector's `fromAi()` tool shape). A bare, non-colon
  // taskDefinition type (e.g. "read-case") is a real job-worker tool and MUST
  // still get a worker entry — nesting inside a templated container alone is
  // not sufficient (a moonshot-tier run surfaced job-worker tools this way;
  // flagging them as connector-only silently dropped their worker classes).
  // Such elements are still surfaced (other logic references the inventory),
  // but flagged `nestedInConnectorContainer` so analyze-phase does NOT emit a
  // worker for them. userTasks / businessRuleTasks nested inside (e.g. a
  // human-in-the-loop approval tool) are intentionally NOT flagged — they wire
  // as forms/decisions.
  const agentRanges: Array<[number, number]> = [];
  for (const m of body.matchAll(/<bpmn:(subProcess|adHocSubProcess)\b([^>]*?)>([\s\S]*?)<\/bpmn:\1>/g)) {
    if (at(m[2] ?? '').modelerTemplate) agentRanges.push([m.index, m.index + m[0].length]);
  }
  const taskDefinitionType = (inner: string): string => {
    const m = inner.match(/<zeebe:taskDefinition\b([^>]*?)\/?>/);
    return m ? at(m[1] ?? '').type || '' : '';
  };

  const re =
    /<bpmn:(serviceTask|userTask|businessRuleTask|task|sendTask|receiveTask|manualTask|scriptTask|intermediateThrowEvent|endEvent|exclusiveGateway)\b([^>]*?)(?:\/>|>([\s\S]*?)<\/bpmn:\1>)/g;
  for (const m of body.matchAll(re)) {
    const t = m[1] ?? '';
    const a = at(m[2] ?? '');
    const inner = m[3] || '';
    const id = a.id || '';
    const nestedInAgent = agentRanges.some(([s, e]) => m.index > s && m.index < e);
    const tdType = taskDefinitionType(inner);
    const isConnectorBound = Boolean(a.modelerTemplate) || tdType.includes(':');
    const nestedInConnectorContainer =
      /^(serviceTask|sendTask|scriptTask|task)$/.test(t) && nestedInAgent && isConnectorBound;
    const note = ann[assoc[id] || ''] || '';

    if (t === 'intermediateThrowEvent' || t === 'endEvent') {
      const med = inner.match(/<bpmn:messageEventDefinition\b([^>]*)\/?>/);
      if (!med) continue; // drop plain / terminate / error events
      const medAttrs = at(med[1] ?? '');
      elements.push({
        id,
        type: t,
        name: a.name || '',
        note,
        publishesMessage: true,
        messageRef: medAttrs.messageRef || '',
        businessRule: false,
        bpmnErrors: errMap[id] || [],
      });
      continue;
    }

    elements.push({
      id,
      type: t,
      name: a.name || '',
      note,
      businessRule: note.includes('[BusinessRule]') || t === 'businessRuleTask',
      bpmnErrors: errMap[id] || [],
      // Source wiring, surfaced so analyze-join can act deterministically:
      //  - `modelerTemplate` → the element is connector-bound; join drops it
      //    from workers[] (Zeebe's connector runtime services it, not a worker).
      //  - `taskDefinition` → the source job type; join preserves it verbatim as
      //    the worker jobType instead of the LLM re-deriving a divergent name.
      ...(tdType ? { taskDefinition: tdType } : {}),
      ...(a.modelerTemplate
        ? { modelerTemplate: a.modelerTemplate, modelerTemplateVersion: a.modelerTemplateVersion || '' }
        : {}),
      ...(nestedInConnectorContainer ? { nestedInConnectorContainer: true } : {}),
    });
  }

  // Second pass — templated subprocess containers (`subProcess` /
  // `adHocSubProcess` with `zeebe:modelerTemplate=`). Done as a separate
  // scan so the main task regex never consumes a subprocess body and loses
  // its children; this scan only inspects the OPEN tag, not the body, and
  // self-closing forms are also handled. Plain (non-templated) subprocesses
  // are intentionally NOT surfaced — they're organisational containers and
  // analyze-phase has nothing to wire on them.
  // `at()`'s pattern (\w+)="..." drops the `zeebe:` namespace, so the
  // attribute keys land as `modelerTemplate` / `modelerTemplateVersion`.
  const subRe = /<bpmn:(subProcess|adHocSubProcess)\b([^>]*?)(?:\/>|>)/g;
  for (const m of body.matchAll(subRe)) {
    const t = m[1] ?? '';
    const a = at(m[2] ?? '');
    if (!a.modelerTemplate) continue;
    const id = a.id || '';
    const note = ann[assoc[id] || ''] || '';
    elements.push({
      id,
      type: t,
      name: a.name || '',
      note,
      modelerTemplate: a.modelerTemplate,
      modelerTemplateVersion: a.modelerTemplateVersion || '',
      businessRule: false,
      bpmnErrors: errMap[id] || [],
    });
  }

  return { pid, elements };
}

const bpmnDir = process.argv[2];
if (!bpmnDir) {
  process.stderr.write('usage: bpmn-parse-elements.mts <bpmn-dir>\n');
  process.exit(1);
}
// Three prefixes are real, deployable BPMNs:
//   process-NN-*.bpmn — linear phase children (chained by main-<slug>.bpmn)
//   edge-NN-*.bpmn    — independent edge-case processes (error/escalation paths)
//   subprocess-*.bpmn — processes invoked by a callActivity from inside a phase.
//                       These carry NO NN number, unlike the other two shapes, so
//                       they need their own alternation rather than joining the
//                       `(?:process|edge)-\d{2}-` group.
// 00-overview.bpmn is a landscape diagram only — non-executable, no Zeebe
// elements — and is intentionally NOT picked up here. Adding it would inject
// a no-op into Phase 3 generation. Anything else (other-*, ad-hoc-*, …) is
// also dropped on purpose; widen this regex deliberately if a new prefix is
// introduced upstream.
const files = fs
  .readdirSync(bpmnDir)
  .filter((f) => /^(?:(?:process|edge)-\d{2}-.*|subprocess-.*)\.bpmn$/.test(f))
  .sort();
for (const f of files) {
  const filePath = path.join(bpmnDir, f);
  const r = load(filePath);
  if (r) console.log(JSON.stringify({ file: filePath, processId: r.pid, elements: r.elements }));
}
