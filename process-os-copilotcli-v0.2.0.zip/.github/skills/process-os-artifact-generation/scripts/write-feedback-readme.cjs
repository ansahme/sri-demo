#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Write process-implementation/feedback/'s own README.md, once, the way
// iteration-dir.cjs's FEEDBACK_README constant does for the
// other two phases' iteration/feedback/ directories.
//
// This skill owns a separate constant rather than reusing iteration-dir.cjs
// because the implementation phase's feedback directory differs from theirs
// in the ways that matter to a reviewer: no iteration level (there is one
// feedback/ for the whole phase, not one per iteration), no questionnaire
// (implementation has the out-of-band channel only), and the closing rule is
// the opposite — an edit pass edits process-implementation/artifacts/ in
// place, so a hand edit there survives instead of being discarded.
//
// Usage:
//   node "scripts/write-feedback-readme.cjs" <feedback-dir>
//
// Prints one line:
//   WRITTEN  <feedback-dir>/README.md
//   PRESENT  <feedback-dir>/README.md
//
// <feedback-dir> is created first if it does not exist yet — same idempotence
// as make-dir.cjs. The README is written only when absent, so a
// reviewer's own edits to it (or its deletion) are never overwritten by a later
// pass. Relative paths resolve against the current working directory, which is
// the ProcessOS project root. Exits 0 either way; exits 2 on a usage error. An
// unexpected filesystem error (e.g. a plain file already occupies the README
// path) is left to throw.

const fs = require('fs');
const path = require('path');

const FEEDBACK_README = `# Feedback on the generated solution

Put feedback on the generated solution here. Anything a reviewer sends belongs in this
directory:

- reviewer notes from email, chat, or a workshop
- marked-up exports, PDFs, transcripts, screenshots
- a hand-edited \`.bpmn\`, as a file of its own

**Commit what you add.** The next edit pass reads this directory and edits the tree under
\`../artifacts/\` in place to address what it finds.

You may edit the files under \`../artifacts/\` directly — an edit pass works with your edits
rather than discarding them. It keeps the service stubs you have filled in and anything you
have written under \`config/\` or \`clients/\`, and edits only the file or files each note here
points it to — nothing else changes.
`;

const USAGE = 'usage: write-feedback-readme.cjs <feedback-dir>\n';

/**
 * Write `FEEDBACK_README` into `feedbackDir/README.md`, creating `feedbackDir`
 * first if needed, but only when the file is not already there.
 *
 * @param {string} feedbackDir Path to the phase's feedback directory.
 * @returns {'WRITTEN'|'PRESENT'} Whether this call is what wrote the file.
 */
function writeFeedbackReadme(feedbackDir) {
  fs.mkdirSync(feedbackDir, { recursive: true });
  const readmePath = path.join(feedbackDir, 'README.md');
  if (fs.existsSync(readmePath)) return 'PRESENT';
  fs.writeFileSync(readmePath, FEEDBACK_README);
  return 'WRITTEN';
}

module.exports = { FEEDBACK_README, writeFeedbackReadme };

if (require.main === module) {
  const [feedbackDir] = process.argv.slice(2);
  if (!feedbackDir) {
    process.stderr.write(USAGE);
    process.exit(2);
  }
  const outcome = writeFeedbackReadme(feedbackDir);
  process.stdout.write(`${outcome.padEnd(8)} ${path.join(feedbackDir, 'README.md')}\n`);
}
