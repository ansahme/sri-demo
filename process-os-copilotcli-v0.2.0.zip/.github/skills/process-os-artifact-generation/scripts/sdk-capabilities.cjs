#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// The per-SDK capability table Phase 3, Phase 4 and Phase 5 of
// process-os-artifact-generation read instead of branching on the target-SDK
// string. Adding an SDK is a row here, a blueprint tree, one worker-instruction
// file and one report file — no edit to the skill's phase logic. One prose
// exception: generate-workers.md's Step 2 table still needs its own row for
// the new `workerInstructions` path: link/orphan validation only sees a real
// markdown link in prose, not a value read out of this file.
//
// It lives in code rather than as a markdown table in SKILL.md because two of
// its readers are scripts, not agents: audit-artifact-deps.cjs needs the
// worker-probe answer programmatically, and count-artifacts.cjs needs the
// worker-file suffix. A prose copy would exist twice and drift.
//
// Column meanings:
//   blueprint               a blueprints/<sdk>/ tree exists, so the scaffold can run
//   workerGenerator         how the worker layer is produced:
//                             'agent-fan-out' — dispatch the workers agent
//                             'script'        — the orchestrator runs a generator
//                             null            — reported capability gap
//   workerInstructions      skill-relative path to the per-SDK worker file
//   dependencyAuditProbe    which check-#1 branch audit-artifact-deps.cjs takes
//   buildGate               which Phase-3 build gate runs
//   deployabilityValidation Phase 5: 'automated' | 'manual' | 'none'
//   workerFileSuffix        the filename suffix count-artifacts.cjs counts
//   reportFile              skill-relative path to the per-SDK report/Output file
//
// STAGED DUPLICATION: scaffold-workers.cjs keeps its own SUPPORTED_SDKS list,
// which is one column of this table (`blueprint`). Collapsing it here would put a
// behaviour change to the Java scaffold path inside an unrelated change, so it is
// deliberately deferred, not overlooked. Until it collapses, adding an SDK with a
// blueprint means editing BOTH lists — the tables' agreement is asserted by
// sdk-capabilities.test.cjs so the two cannot drift silently.
//
// Usage:
//   node "scripts/sdk-capabilities.cjs" <sdk>
//   node "scripts/sdk-capabilities.cjs" --from-manifest <artifact-dir>
//
// stdout: the row as JSON, with a `targetSdk` key added. Nothing on stderr on
// success. Exit 0 on success; 2 on a usage error, an unknown SDK, or a missing
// or unparseable manifest.

const fs = require('fs');
const path = require('path');
// Source import of the shared reader; the bundler rewrites it to a local sibling
// require when it copies the peer into this skill's scripts/ dir.
const { RUN_DEFAULTS } = require(path.join(__dirname, 'run-config-schema.cjs'));

const EXIT = { OK: 0, USAGE: 2 };

// Taken from the schema, not restated: resolve-target-sdk.cjs applies the same
// default, and a second literal here could drift from it.
const DEFAULT_SDK = RUN_DEFAULTS['target-sdk'];

const NO_CAPABILITIES = {
  blueprint: false,
  workerGenerator: null,
  workerInstructions: null,
  dependencyAuditProbe: null,
  buildGate: null,
  deployabilityValidation: 'none',
  workerFileSuffix: null,
  reportFile: null,
};

const CAPABILITIES = {
  'java-spring-boot': {
    blueprint: true,
    workerGenerator: 'agent-fan-out',
    workerInstructions: 'references/workers-java-spring-boot.md',
    dependencyAuditProbe: 'java',
    buildGate: 'maven',
    deployabilityValidation: 'automated',
    workerFileSuffix: 'Worker.java',
    reportFile: 'references/report-java-spring-boot.md',
  },
  typescript: {
    blueprint: true,
    workerGenerator: 'script',
    workerInstructions: 'references/workers-typescript.md',
    dependencyAuditProbe: 'typescript',
    buildGate: 'npm',
    deployabilityValidation: 'manual',
    workerFileSuffix: '-worker.ts',
    reportFile: 'references/report-typescript.md',
  },
  python: {
    blueprint: true,
    workerGenerator: 'script',
    workerInstructions: 'references/workers-python.md',
    dependencyAuditProbe: 'python',
    buildGate: 'uv',
    deployabilityValidation: 'manual',
    workerFileSuffix: '_worker.py',
    reportFile: 'references/report-python.md',
  },
  // Official Camunda SDKs with no blueprint yet. Present so a run reports a
  // named capability gap instead of hitting an unknown-SDK error.
  java: { ...NO_CAPABILITIES },
  csharp: { ...NO_CAPABILITIES },
};

/**
 * The capability row for `sdk`, or null when the table does not know it.
 *
 * @param {string} sdk
 * @returns {object|null}
 */
function lookup(sdk) {
  if (typeof sdk !== 'string' || sdk === '') return null;
  return Object.prototype.hasOwnProperty.call(CAPABILITIES, sdk) ? CAPABILITIES[sdk] : null;
}

/**
 * Resolve the SDK from a manifest and return its row.
 *
 * An absent `meta.targetSdk` is the documented "not there" state and defaults to
 * DEFAULT_SDK — the same convention scaffold-workers.cjs:118 uses, and what keeps
 * the shipped fixture (taken before the metadata merge) working. A manifest that
 * exists but names an SDK off the table is "there but broken" and throws.
 *
 * @param {string} artifactDir
 * @returns {{sdk: string, row: object, meta: object}}
 * @throws {Error & {code: 'NO_MANIFEST'|'UNKNOWN_SDK'}}
 */
function fromManifest(artifactDir) {
  const manifestPath = path.join(artifactDir, '.manifest.json');
  let manifest;
  try {
    manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  } catch (cause) {
    const err = new Error(`sdk-capabilities: cannot read ${manifestPath}: ${cause.message}`);
    err.code = 'NO_MANIFEST';
    throw err;
  }
  const meta = (manifest && manifest.meta) || {};
  const sdk = meta.targetSdk === undefined ? DEFAULT_SDK : meta.targetSdk;
  const row = lookup(sdk);
  if (!row) {
    const err = new Error(
      `sdk-capabilities: manifest.meta.targetSdk '${sdk}' is not in the capability table ` +
        `(one of: ${Object.keys(CAPABILITIES).join(', ')})`,
    );
    err.code = 'UNKNOWN_SDK';
    throw err;
  }
  return { sdk, row, meta };
}

module.exports = { EXIT, DEFAULT_SDK, CAPABILITIES, NO_CAPABILITIES, lookup, fromManifest };

if (require.main === module) {
  const argv = process.argv.slice(2);
  let sdk = null;
  let row = null;
  if (argv[0] === '--from-manifest') {
    if (!argv[1]) {
      process.stderr.write('usage: sdk-capabilities.cjs --from-manifest <artifact-dir>\n');
      process.exit(EXIT.USAGE);
    }
    try {
      ({ sdk, row } = fromManifest(argv[1]));
    } catch (err) {
      process.stderr.write(`${err.message}\n`);
      process.exit(EXIT.USAGE);
    }
  } else if (argv.length === 1 && !argv[0].startsWith('-')) {
    sdk = argv[0];
    row = lookup(sdk);
    if (!row) {
      process.stderr.write(
        `sdk-capabilities: '${sdk}' is not in the capability table ` +
          `(one of: ${Object.keys(CAPABILITIES).join(', ')})\n`,
      );
      process.exit(EXIT.USAGE);
    }
  } else {
    process.stderr.write(
      'usage: sdk-capabilities.cjs <sdk>\n' +
        '       sdk-capabilities.cjs --from-manifest <artifact-dir>\n',
    );
    process.exit(EXIT.USAGE);
  }
  process.stdout.write(`${JSON.stringify({ targetSdk: sdk, ...row }, null, 2)}\n`);
}
