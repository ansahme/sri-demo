#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Emit the entire TypeScript worker layer in one pass from process-implementation/artifacts/.manifest.json.
//
// Run by the Phase-3 orchestrator with NO subagent: the per-worker work is
// mechanical templating with stub bodies and zero judgement, so subagents buy
// nothing and cost three things a script does not — run-to-run reproducibility,
// unit-testability, and a subagent budget that references/workers-java-spring-boot.md
// documents as already near its cap. Determinism also dissolves the write race on
// the shared app.ts registry, which is a single hand-maintained file in the
// blueprint and has no Java analogue (Java workers self-register through an
// annotation).
//
// Workers group by unique job type, unioning each group's input variables, output
// variables and error codes: Camunda dispatches by job type, so exactly one
// implementation may exist per job type, and the manifest legitimately carries
// several entries for one because the same service task recurs across phases.
//
// Every emitted file name and identifier derives from the job type. Two inputs
// are hard failures rather than best-effort, both writing NOTHING and naming
// every offending job type — see EXIT below. This is deliberately stricter than
// the Java path, which runs the same pascal() to build className
// (analyze-join.mts:255) and reports a digit-leading job type as a javac error on
// generated code rather than as a named generator failure. Fixing that is its own
// change; this generator does not inherit the defect in the meantime.
//
// Usage:
//   node "scripts/generate-workers-typescript.cjs" [<artifact-dir>]
//
//   <artifact-dir>  Default `process-implementation/artifacts`.
//
// stdout: one `wrote <path>` or `skipped <path> (<reason>)` line per file, then a
// summary. Nothing on stderr on the success path.
//
// Exit codes:
//   0  every file written
//   2  usage error, or the manifest is missing / unparseable — "there but broken"
//      is not "nothing to do", so nothing is written
//   3  a derived identifier stem is not a legal identifier
//   4  two distinct job types collapse onto one stem
//   5  an existing service stub cannot be read (EACCES, EISDIR, an I/O error) —
//      distinct from an absent one, which is written normally

const fs = require('fs');
const path = require('path');
// Sibling in this same scripts/ dir — the documented exemption to the
// self-contained-scripts rule.
const emit = require('./generate-workers-typescript-emit.cjs');

const EXIT = { OK: 0, USAGE: 2, ILLEGAL_STEM: 3, STEM_COLLISION: 4, STUB_UNREADABLE: 5 };

const DEFAULT_ARTIFACT_DIR = 'process-implementation/artifacts';

/**
 * Whether an existing service-stub file is there and readable, or there and
 * broken. Absence is not an error here — it is the ordinary "write it" state.
 *
 * @param {string} abs
 * @returns {boolean} true when the file exists and can be read.
 * @throws {Error & {exit: number}} when the file exists but cannot be read.
 */
function stubIsPresent(abs) {
  try {
    fs.readFileSync(abs);
    return true;
  } catch (err) {
    if (err.code === 'ENOENT') return false;
    const wrapped = new Error(
      `generate-workers-typescript: ${abs} exists but could not be read (${err.code || err.message}). ` +
        'A service stub is where a developer implements the domain logic, so this generator never ' +
        'overwrites one it cannot verify. Nothing was written. Fix the file and run again.',
    );
    wrapped.exit = EXIT.STUB_UNREADABLE;
    throw wrapped;
  }
}

/**
 * Read and parse the manifest, or throw with a `code` a caller can map to an exit.
 *
 * A missing manifest and an unparseable one are the same outcome here: the
 * generator's whole input is the manifest, so "not there" is not a legitimate
 * "nothing to do" state — it means the caller is at the wrong point in the run.
 *
 * @param {string} artifactDir
 * @returns {object}
 */
function readManifest(artifactDir) {
  const manifestPath = path.join(artifactDir, '.manifest.json');
  if (!fs.existsSync(manifestPath)) {
    const err = new Error(`generate-workers-typescript: missing ${manifestPath}`);
    err.exit = EXIT.USAGE;
    throw err;
  }
  try {
    return JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  } catch (cause) {
    const err = new Error(
      `generate-workers-typescript: ${manifestPath} exists but does not parse: ${cause.message}`,
    );
    err.exit = EXIT.USAGE;
    throw err;
  }
}

/** @param {string} file @param {string} text */
function write(file, text) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, text);
}

/**
 * Generate the whole layer. Validation happens BEFORE the first write, so a
 * rejected manifest leaves the tree exactly as it was. Reading each service
 * stub's on-disk presence happens before the first write too, for the same
 * reason: a stub this run cannot verify must not be silently overwritten by
 * a run that gets partway through before finding out.
 *
 * @param {string} [artifactDir]
 * @returns {{written: string[], skipped: string[], kept: string[]}}
 */
function generate(artifactDir = DEFAULT_ARTIFACT_DIR) {
  const manifest = readManifest(artifactDir);
  const groups = emit.groupWorkers(manifest.workers);

  const { illegal, collisions } = emit.validateGroups(groups);
  if (illegal.length > 0) {
    const err = new Error(
      'generate-workers-typescript: these job types do not derive a legal TypeScript ' +
        `identifier (a job type with no alphanumeric content, or a digit-leading one): ${illegal.join(', ')}. ` +
        'Rename the BPMN element, or the jobType in the manifest, and re-run.',
    );
    err.exit = EXIT.ILLEGAL_STEM;
    throw err;
  }
  if (collisions.length > 0) {
    const err = new Error(
      'generate-workers-typescript: these job types collapse onto one generated name, ' +
        'which would leave all but one permanently without a subscriber: ' +
        `${collisions.map((c) => c.join(' + ')).join('; ')}. Rename one of each pair and re-run.`,
    );
    err.exit = EXIT.STEM_COLLISION;
    throw err;
  }

  const src = path.join(artifactDir, 'src');

  // Service stubs are the file class this skill names as manual work
  // ("implement the domain logic"): written once, then left exactly as they
  // are. Every group's stub presence is decided here, before any write below.
  const serviceFiles = new Map(groups.map((g) => [g, path.join(src, 'services', `${g.file}-service.ts`)]));
  const stubPresent = new Map();
  for (const [group, file] of serviceFiles) {
    stubPresent.set(group, stubIsPresent(file));
  }

  const written = [];
  const kept = [];
  const skipped = [];
  const record = (file, text) => {
    write(file, text);
    written.push(path.relative(artifactDir, file));
  };

  record(path.join(src, 'models', 'process-variables.ts'), emit.renderProcessVariables(groups));
  record(path.join(src, 'errors', 'service-error.ts'), emit.renderServiceError());

  const allCodes = groups.flatMap((g) => g.errorCodes);
  const bpmnErrors = emit.renderBpmnErrors(allCodes);
  const bpmnErrorsPath = path.join(src, 'errors', 'bpmn-errors.ts');
  if (bpmnErrors === null) {
    // A stale module from a prior run whose manifest DID declare codes would be
    // typechecked (the blueprint's tsconfig includes every file under src/) and
    // is dead code that reads as real.
    fs.rmSync(bpmnErrorsPath, { force: true });
    skipped.push(`${path.relative(artifactDir, bpmnErrorsPath)} (no job type declares an error code)`);
  } else {
    record(bpmnErrorsPath, bpmnErrors);
  }

  for (const group of groups) {
    const serviceFile = serviceFiles.get(group);
    if (stubPresent.get(group)) {
      kept.push(path.relative(artifactDir, serviceFile));
    } else {
      record(serviceFile, emit.renderService(group));
    }
    record(path.join(src, 'workers', `${group.file}-worker.ts`), emit.renderWorker(group));
  }

  record(path.join(src, 'app.ts'), emit.renderApp(groups));

  written.sort();
  skipped.sort();
  kept.sort();
  return { written, skipped, kept };
}

module.exports = { EXIT, DEFAULT_ARTIFACT_DIR, generate };

if (require.main === module) {
  const artifactDir = process.argv[2] || DEFAULT_ARTIFACT_DIR;
  let result;
  try {
    result = generate(artifactDir);
  } catch (err) {
    process.stderr.write(`${err.message}\n`);
    process.exit(err.exit || EXIT.USAGE);
  }
  const lines = [
    ...result.written.map((p) => `wrote   ${p}`),
    ...result.kept.map((p) => `kept    ${p} (existing service stub left as-is)`),
    ...result.skipped.map((s) => `skipped ${s}`),
    `generate-workers-typescript: ${result.written.length} file(s) written under ${artifactDir}/`,
  ];
  process.stdout.write(`${lines.join('\n')}\n`);
}
