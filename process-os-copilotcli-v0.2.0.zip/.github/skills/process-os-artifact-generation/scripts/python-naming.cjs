#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// The Python field-name conversion and the manifest type map, shared by the two
// writers of a generated project's src/models/process_variables.py:
// scaffold-workers.cjs writes the scaffold's union model, and the Python worker
// generator overwrites it with the aliased union plus one input and one output
// model per job-type group.
//
// One copy, because two would diverge without a symptom: each file stays valid
// Python and the quality gate passes while the two models disagree about a field
// name, which surfaces later as a variable that never reaches a worker.
//
// This module is data and pure functions only. It reads no files, spawns
// nothing, and has no CLI.

// A field name that equals a Python keyword is a syntax error at the point of
// use: `class: str | None = None` in a class body does not parse. Only the
// lowercase keywords can collide, because toPyField lowercases every segment —
// `False`, `None` and `True` become the legal identifiers `false`, `none` and
// `true`. Soft keywords (`_`, `case`, `match`, `type`) stay out: Python permits
// them as identifiers, so suffixing them would rename a variable for no reason.
const PY_KEYWORDS = new Set([
  'and', 'as', 'assert', 'async', 'await', 'break', 'class', 'continue',
  'def', 'del', 'elif', 'else', 'except', 'finally', 'for', 'from',
  'global', 'if', 'import', 'in', 'is', 'lambda', 'nonlocal', 'not',
  'or', 'pass', 'raise', 'return', 'try', 'while', 'with', 'yield',
]);

/**
 * Convert a manifest variable name to a Python field name.
 *
 * Nested FEEL context paths ("client.jurisdiction") and camelCase manifest names
 * ("quoteId") both flatten to snake_case ("client_jurisdiction", "quote_id") so
 * the generated module is importable and reads as Python.
 *
 * The two substitutions below are the standard camel-to-snake pair, and the
 * second one is what keeps an acronym whole. A break before every capital would
 * turn "IBAN" into "i_b_a_n", which is a legal identifier that no reader
 * recognises. So the first substitution breaks between a lowercase character or
 * a digit and a following capital, and the second breaks between a run of
 * capitals and a following capitalised word: "IBAN" stays "iban", and
 * "HTTPResponse" becomes "http_response".
 *
 * Returns null when the name carries no alphanumeric content, because there is
 * no identifier to derive. Both callers reject the manifest and name the offending
 * variable rather than drop it: a dropped variable leaves a required input absent
 * at runtime with no named cause.
 *
 * @param {unknown} name
 * @returns {string|null} a legal, non-keyword Python identifier, or null
 */
function toPyField(name) {
  const parts = String(name == null ? '' : name).split(/[^A-Za-z0-9]+/).filter(Boolean);
  if (!parts.length) return null;
  let id = parts
    .map((part) => part
      .replace(/([a-z0-9])([A-Z])/g, '$1_$2')
      .replace(/([A-Z]+)([A-Z][a-z])/g, '$1_$2'))
    .join('_')
    .toLowerCase();
  if (/^[0-9]/.test(id)) id = `v_${id}`;
  if (PY_KEYWORDS.has(id)) id = `${id}_`;
  return id;
}

/**
 * Map a manifest variable type to a Python type name.
 *
 * An unknown or absent type resolves to `object` rather than failing: the
 * manifest's type vocabulary is advisory, and a variable whose type the analysis
 * phase could not determine still belongs in the model.
 *
 * @param {unknown} t
 * @returns {string}
 */
function mapPyType(t) {
  const map = {
    String: 'str', string: 'str',
    Long: 'int', long: 'int', Integer: 'int', int: 'int',
    Double: 'float', double: 'float', Float: 'float', float: 'float',
    Boolean: 'bool', boolean: 'bool',
    Number: 'float',
  };
  return map[t] || 'object';
}

// The same identifier rules a field name needs — snake_case, no leading digit,
// no keyword collision — apply unchanged to the top-level package name scaffold
// and generate-workers-python derive from `meta.processSlug`, so this is a name,
// not a second implementation.
const toPyPackageName = toPyField;

module.exports = { PY_KEYWORDS, toPyField, mapPyType, toPyPackageName };
