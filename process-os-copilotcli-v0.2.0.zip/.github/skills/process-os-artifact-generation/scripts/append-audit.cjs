#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Append one row to `.camunda/audit.md`.
//
// Replaces the `printf "| %s | %-26s | %s |\n" "$(date '+%Y-%m-%d %H:%M')" …
// >> .camunda/audit.md` line. PowerShell has no `printf` and no `date` — `$(date
// …)` there resolves to nothing and the row lands with an empty timestamp, which
// is worse than an error because the ledger still looks written.
//
// Usage:
//   node "append-audit.cjs" <skill-name> <event text>
//
// Everything after the skill name is joined with spaces as the event, so the
// caller does not have to quote a sentence as one argument.
//
// The row matches what the shell form produced, including the 26-column skill
// padding that keeps the table readable in a plain-text diff:
//
//   | 2026-08-11 14:32 | process-os-discovery-plugin | Installed plugin 'x' |
//
// A `|` inside the event text is escaped, so an event mentioning a shell pipe
// cannot silently add a column to the table.
//
// Exit codes:
//   0  appended
//   1  the ledger exists but could not be read or written (EACCES, I/O). Distinct
//      from 2 on purpose: a caller told to carry on when there is no ledger must
//      not carry on when the row it wrote went nowhere
//   2  usage error, or there is no `.camunda/audit.md` to append to — the ledger
//      is created by project initialization, so its absence means this is not an
//      initialized project rather than "nothing to record"

const fs = require('fs');
const path = require('path');

const EXIT = { OK: 0, FAILED: 1, USAGE: 2, NO_LEDGER: 2 };

const AUDIT_FILE = path.join('.camunda', 'audit.md');
const SKILL_COLUMN_WIDTH = 26;

const USAGE = 'usage: append-audit.cjs <skill-name> <event text>\n';

/**
 * Format `date` as the ledger's `YYYY-MM-DD HH:MM`, in local time — same as the
 * `date '+%Y-%m-%d %H:%M'` it replaces.
 *
 * @param {Date} date
 * @returns {string}
 */
function formatTimestamp(date) {
  const pad = (n) => String(n).padStart(2, '0');
  return (
    `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ` +
    `${pad(date.getHours())}:${pad(date.getMinutes())}`
  );
}

/**
 * Build one audit row.
 *
 * @param {string} skill Skill name.
 * @param {string} event What happened.
 * @param {Date} [now]
 * @returns {string} The row, without a trailing newline.
 */
function formatRow(skill, event, now = new Date()) {
  const cell = (text) => String(text).replace(/\|/g, '\\|');
  return `| ${formatTimestamp(now)} | ${cell(skill).padEnd(SKILL_COLUMN_WIDTH)} | ${cell(event)} |`;
}

/**
 * Append one row to the audit ledger.
 *
 * @param {string} skill Skill name.
 * @param {string} event What happened.
 * @param {object} [opts]
 * @param {string} [opts.file] Ledger path.
 * @param {Date} [opts.now]
 * @returns {string} The row that was appended.
 * @throws {Error} When the ledger does not exist.
 */
function appendAudit(skill, event, { file = AUDIT_FILE, now = new Date() } = {}) {
  let existing;
  try {
    existing = fs.readFileSync(file, 'utf8');
  } catch (err) {
    // Absence is the documented exit-2 case a caller may carry on from; anything
    // else (EACCES, EISDIR, an I/O error) is a failed write dressed as a missing
    // ledger, and a skill told to "carry on for exit 2" would hide it.
    if (err.code !== 'ENOENT') {
      throw Object.assign(new Error(`could not read ${file}: ${err.message}`), { exitCode: EXIT.FAILED });
    }
    throw Object.assign(new Error(`no ${file} — run /process-os-project-initialization first`), {
      exitCode: EXIT.NO_LEDGER,
    });
  }
  const row = formatRow(skill, event, now);
  // Match the ledger's own line endings rather than the platform's. The file is
  // seeded with `\n` literals, so `os.EOL` would append CRLF rows into an LF
  // file on Windows — mixed endings in a committed file, and a noisy diff.
  const eol = existing.includes('\r\n') ? '\r\n' : '\n';
  // A ledger whose last line lacks its newline would otherwise absorb the new
  // row into the previous one, silently corrupting the table.
  const separator = !existing || existing.endsWith('\n') ? '' : eol;
  fs.appendFileSync(file, `${separator}${row}${eol}`);
  return row;
}

module.exports = { AUDIT_FILE, EXIT, appendAudit, formatRow, formatTimestamp };

if (require.main === module) {
  const [skill, ...event] = process.argv.slice(2);
  if (!skill || event.length === 0) {
    process.stderr.write(USAGE);
    process.exit(EXIT.USAGE);
  }
  try {
    process.stdout.write(`${appendAudit(skill, event.join(' '))}\n`);
  } catch (err) {
    process.stderr.write(`append-audit.cjs: ${err.message}\n`);
    process.exit(err.exitCode || EXIT.FAILED);
  }
}
