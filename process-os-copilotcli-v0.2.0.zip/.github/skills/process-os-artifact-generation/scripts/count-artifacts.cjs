#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Count the generated artifacts Phase 4 writes into .camunda/state.md's Key
// Output and the .camunda/audit.md entry.
//
// Replaces the `node -e` one-liner that counted files ending in `Worker.java`
// unconditionally, so a TypeScript run reported `workers=0` for a bundle full of
// workers — and that zero was what reached the lifecycle mirror and the audit
// ledger. The per-SDK worker-file suffix comes from the capability table, so
// adding an SDK is a data change with no edit here or in SKILL.md.
//
// Decisions and forms are SDK-independent: generate-dmn.cjs and
// generate-forms.cjs write the same paths for every target.
//
// Usage:
//   node "scripts/count-artifacts.cjs" [<artifact-dir>]
//
//   <artifact-dir>  Default `process-implementation/artifacts`.
//
// stdout: exactly three lines — `workers=<N>`, `decisions=<N>`, `forms=<N>`.
// Nothing on stderr on the success path.
//
// Exit codes: 0 counted; 2 the manifest is missing, unparseable, or names an SDK
// the capability table does not know. An absent output directory is NOT an error
// — it legitimately means nothing of that kind was generated — but an unreadable
// manifest is, because the suffix cannot be resolved without it.

const fs = require('fs');
const path = require('path');
const { fromManifest } = require('./sdk-capabilities.cjs');
const { toPyPackageName } = require('./python-naming.cjs');

const EXIT = { OK: 0, USAGE: 2 };

const DEFAULT_ARTIFACT_DIR = 'process-implementation/artifacts';

/**
 * Count files under `dir` (recursively) whose name ends with `suffix`.
 *
 * @param {string} dir
 * @param {string|null} suffix null means "this SDK has no worker files".
 * @returns {number}
 */
function countBySuffix(dir, suffix) {
  if (!suffix) return 0;
  let total = 0;
  const walk = (current) => {
    if (!fs.existsSync(current)) return; // absent directory: nothing of that kind was generated
    for (const entry of fs.readdirSync(current, { withFileTypes: true })) {
      const abs = path.join(current, entry.name);
      if (entry.isDirectory()) walk(abs);
      else if (entry.name.endsWith(suffix)) total += 1;
    }
  };
  walk(dir);
  return total;
}

/**
 * @param {string} [artifactDir]
 * @returns {{workers: number, decisions: number, forms: number}}
 */
function count(artifactDir = DEFAULT_ARTIFACT_DIR) {
  const { sdk, row, meta } = fromManifest(artifactDir);
  // Resources are SDK-neutral and always live under src/main/resources. Generated
  // sources do not: the python scaffolder renames src/ to the package it derives
  // from meta.processSlug, so counting under a fixed src/ finds no worker and
  // reports 0 for a bundle that carries them.
  const sourceRoot =
    sdk === 'python' ? toPyPackageName(meta && meta.processSlug) || 'src' : 'src';
  const resources = path.join(artifactDir, 'src', 'main', 'resources');
  return {
    workers: countBySuffix(path.join(artifactDir, sourceRoot), row.workerFileSuffix),
    decisions: countBySuffix(path.join(resources, 'decisions'), '.dmn'),
    forms: countBySuffix(path.join(resources, 'forms'), '.form'),
  };
}

module.exports = { EXIT, DEFAULT_ARTIFACT_DIR, count, countBySuffix };

if (require.main === module) {
  const artifactDir = process.argv[2] || DEFAULT_ARTIFACT_DIR;
  let counts;
  try {
    counts = count(artifactDir);
  } catch (err) {
    process.stderr.write(`${err.message}\n`);
    process.exit(EXIT.USAGE);
  }
  process.stdout.write(
    `workers=${counts.workers}\ndecisions=${counts.decisions}\nforms=${counts.forms}\n`,
  );
}
