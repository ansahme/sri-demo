#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// resolve-node-cli.cjs — spawn a packaged Node CLI portably (incl. native Windows).
//
// Never spawn `node_modules/.bin/<tool>` or `npx` directly: on Windows the real
// executable is `<tool>.cmd`, the extensionless `.bin` file is a shell script, and
// Node ≥18.20/20.12 refuses to spawn a `.cmd` without `shell: true`
// (CVE-2024-27980 hardening). Such a spawn fails with `ENOENT` / `status: null`
// and no output.
//
// Instead: resolve the package's declared `bin` entrypoint (a plain .js file)
// and run it with `process.execPath`. No shell, no `.cmd` lookup, no quoting,
// identical on every platform.
//
// Contract for callers — a spawn that did NOT launch is neither "clean" nor
// "found problems"; treated as either, it becomes a validator that silently
// passes. Always branch on `launched` before looking at `status`, and report a
// non-launch as its own outcome (this repo uses exit code 2).
//
// Usage:
//   const { resolveNodeCliEntry, runNodeCli } = require(path.join(
//     __dirname, '../../..', 'resolve-node-cli.cjs'));
//   const entry = resolveNodeCliEntry('bpmnlint');
//   if (!entry) { /* exit 2: run `c8 os install` */ }
//   const r = runNodeCli(entry, ['--config', rc, file], { cwd, env, stdio: 'inherit' });
//   if (!r.launched) { /* exit 2 */ }
//   process.exit(r.status);

'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

/**
 * @typedef {Object} CliRunResult
 * @property {boolean} launched  False when the child could not be started at all
 *   (ENOENT, EINVAL, bad cwd, killed by a signal). Callers MUST treat this as
 *   "the tool did not run" — never as success or as the tool's own exit status.
 * @property {number|null} status Child exit code; null when it never ran or was signalled.
 * @property {Error|undefined} error Why it did not launch, when `launched` is false.
 * @property {string|null} signal Signal that killed the child, if any.
 * @property {Buffer|string|null} stdout Captured stdout (null with stdio: 'inherit').
 * @property {Buffer|string|null} stderr Captured stderr (null with stdio: 'inherit').
 */

/**
 * Default resolution roots: the project's centrally-installed deps first
 * (`.camunda/node_modules`, provisioned by `c8 os install`), then the project root.
 *
 * @returns {string[]} Directories to resolve from.
 */
function defaultSearchPaths() {
  return [path.join(process.cwd(), '.camunda'), process.cwd()];
}

/**
 * Pick one entry out of a package.json `bin` field (string or object form).
 *
 * @param {string|Object.<string,string>|undefined} bin The manifest's `bin` value.
 * @param {string} binName Which command to pick from the object form.
 * @returns {string|undefined} The package-relative entry path.
 */
function binEntryPath(bin, binName) {
  if (typeof bin === 'string') return bin;
  if (bin && typeof bin === 'object' && typeof bin[binName] === 'string') return bin[binName];
  return undefined;
}

/**
 * The `node_modules` directories a search path stands for. Deliberately does NOT
 * walk upward the way Node's own resolver does: these skills must run the version
 * pinned in the root package.json and installed into `.camunda/node_modules`, so
 * an unrelated package of the same name in an ancestor directory (a stray
 * `~/node_modules/bpmnlint`, a monorepo hoist) must NOT satisfy the lookup. It is
 * better to fail with "run `c8 os install`" than to lint with an unpinned version.
 *
 * @param {string[]} searchPaths Caller-supplied roots.
 * @returns {string[]} Directories to look for `<pkg>/package.json` in, in order.
 */
function candidateModuleDirs(searchPaths) {
  const dirs = [];
  for (const p of searchPaths) {
    if (path.basename(p) === 'node_modules') dirs.push(p);
    else dirs.push(path.join(p, 'node_modules'));
  }
  return dirs.filter((d, i) => dirs.indexOf(d) === i);
}

/**
 * Resolve a package's `bin` entrypoint to an absolute .js path.
 *
 * Reads the entry out of the manifest rather than hardcoding e.g.
 * `bpmnlint/bin/bpmnlint.js`, so an upstream `bin` rename cannot silently break
 * the spawn. Reads the manifest straight off disk rather than through
 * `require.resolve`, which would both walk out of the project (see
 * candidateModuleDirs) and refuse `<pkg>/package.json` on packages whose
 * `exports` map omits that subpath.
 *
 * @param {string} pkg npm package name, e.g. 'bpmnlint' or '@scope/tool'.
 * @param {Object} [opts]
 * @param {string} [opts.binName] Key in the manifest's `bin` object (default: `pkg`).
 * @param {string[]} [opts.searchPaths] Roots to look under (default:
 *   `[cwd/.camunda, cwd]`). Each is interpreted as `<p>/node_modules`; a path that
 *   already ends in `node_modules` is used as-is.
 * @returns {string|null} Absolute path to the JS entry, or null when unresolvable.
 */
function resolveNodeCliEntry(pkg, opts = {}) {
  const binName = opts.binName || pkg;
  const searchPaths = (opts.searchPaths || defaultSearchPaths()).filter(Boolean);

  for (const dir of candidateModuleDirs(searchPaths)) {
    const manifestPath = path.join(dir, ...pkg.split('/'), 'package.json');
    if (!fs.existsSync(manifestPath)) continue;
    let manifest;
    try {
      manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    } catch {
      continue;
    }
    const rel = binEntryPath(manifest.bin, binName);
    if (!rel) continue;
    const entry = path.resolve(path.dirname(manifestPath), rel);
    if (fs.existsSync(entry)) return entry;
  }
  return null;
}

/**
 * Run a resolved JS entrypoint with the current Node binary. Never uses a shell.
 *
 * @param {string} entry Absolute path to the CLI's JS entry (from resolveNodeCliEntry).
 * @param {string[]} [args] Arguments passed to the CLI.
 * @param {Object} [spawnOpts] spawnSync options (cwd, env, stdio, encoding, …).
 * @param {typeof spawnSync} [runner] Test runner override.
 * @returns {CliRunResult}
 */
function runNodeCli(entry, args = [], spawnOpts = {}, runner = spawnSync) {
  return describe(runner(process.execPath, [entry, ...args], { windowsHide: true, ...spawnOpts }));
}

/**
 * Quote one argument for cmd.exe. Node's `shell: true` uses cmd.exe on Windows
 * regardless of the parent shell, so cmd's rules apply — not PowerShell's.
 * A literal `%` cannot be protected inside a quoted cmd argument; paths
 * containing one are not supported on this fallback path.
 *
 * @param {string} arg Raw argument.
 * @returns {string} Quoted argument.
 */
function quoteForCmd(arg) {
  const s = String(arg);
  return /[\s"&|<>^()]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/**
 * Exit codes a shell uses for "command not found" — a secondary net only; the
 * primary check is findOnPath below. Not authoritative: cmd.exe does not reliably
 * use these for an unknown command, so classification must not depend on it.
 *
 * `9009` is cmd.exe ("'x' is not recognized as an internal or external command"),
 * `127` the POSIX-shell equivalent.
 */
const COMMAND_NOT_FOUND_STATUS = new Set([9009, 127]);

/**
 * Locate an executable on PATH without invoking a shell, honouring PATHEXT on
 * Windows. This is what makes "the command does not exist" deterministic: once a
 * shell is in play the shell itself starts successfully, so spawnSync reports a
 * successful run and the caller has only an exit code and a locale-dependent
 * error message to go on. cmd.exe's wording ("is not recognized as an internal or
 * external command") matches none of the findings keywords a linter caller greps
 * for, so a misclassification here surfaces as a clean lint.
 *
 * @param {string} cmd Bare command name, e.g. 'npx'.
 * @param {string} [pathEnv] PATH value to search (defaults to process.env.PATH).
 * @returns {string|null} Absolute path to the executable, or null.
 */
function findOnPath(cmd, pathEnv = process.env.PATH) {
  if (path.isAbsolute(cmd)) return fs.existsSync(cmd) ? cmd : null;
  const exts = process.platform === 'win32'
    ? (process.env.PATHEXT || '.COM;.EXE;.BAT;.CMD').split(';').filter(Boolean)
    : [''];
  for (const dir of String(pathEnv || '').split(path.delimiter).filter(Boolean)) {
    for (const ext of exts) {
      const candidate = path.join(dir, cmd + ext);
      if (fs.existsSync(candidate)) return candidate;
    }
  }
  return null;
}

/**
 * Last-resort runner for a command that only exists as a shell wrapper (`npx`).
 * Uses a shell **only on Windows**, where the wrapper is `npx.cmd` and cannot be
 * exec'd directly; POSIX keeps the exact no-shell behaviour it always had.
 *
 * Prefer resolveNodeCliEntry + runNodeCli. This exists for the zero-install
 * `npx --yes <tool>` fallback, where there is no local package to resolve.
 *
 * @param {string} cmd Command name, e.g. 'npx'.
 * @param {string[]} [args] Arguments.
 * @param {Object} [spawnOpts] spawnSync options.
 * @returns {CliRunResult}
 */
function runShellCli(cmd, args = [], spawnOpts = {}) {
  const opts = { windowsHide: true, ...spawnOpts };
  const env = opts.env || process.env;
  // Decide "does not exist" ourselves, before any shell can absorb it.
  if (!findOnPath(cmd, env.PATH ?? env.Path)) {
    return { launched: false, status: null, error: new Error(`${cmd} not found on PATH`), signal: null, stdout: null, stderr: null };
  }
  const r = describe(process.platform === 'win32'
    ? spawnSync(quoteForCmd(cmd), args.map(quoteForCmd), { ...opts, shell: true })
    : spawnSync(cmd, args, opts));
  if (r.launched && COMMAND_NOT_FOUND_STATUS.has(r.status)) {
    return { ...r, launched: false, error: new Error(`${cmd} not found (shell exit ${r.status})`) };
  }
  return r;
}

/**
 * Normalise a spawnSync return into the CliRunResult contract.
 *
 * @param {import('node:child_process').SpawnSyncReturns<Buffer|string>} r
 * @returns {CliRunResult}
 */
function describe(r) {
  const launched = !r.error && r.status !== null;
  let error = r.error;
  if (!launched && !error) error = new Error(`terminated by signal ${r.signal}`);
  return {
    launched,
    status: r.status === undefined ? null : r.status,
    error,
    signal: r.signal || null,
    stdout: r.stdout === undefined ? null : r.stdout,
    stderr: r.stderr === undefined ? null : r.stderr,
  };
}

module.exports = {
  resolveNodeCliEntry,
  runNodeCli,
  runShellCli,
  // exported for tests
  COMMAND_NOT_FOUND_STATUS,
  binEntryPath,
  findOnPath,
  candidateModuleDirs,
  defaultSearchPaths,
  quoteForCmd,
};
