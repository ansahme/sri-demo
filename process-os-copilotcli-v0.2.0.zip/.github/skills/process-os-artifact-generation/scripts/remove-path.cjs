#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Delete each given path if present, portably.
//
// Replaces the `rm -f X` / `rm -rf X` idiom that skills used to discard one-shot
// staging files and regenerated trees. Neither flag exists in PowerShell 5.1, so
// a native Windows agent had to improvise a translation every time.
//
// Usage:
//   node "remove-path.cjs" [--recursive] <path>...
//
//   --recursive   also delete directories and their contents (the `rm -rf`
//                 case). Default is files only, matching `rm -f`: a directory
//                 is reported as SKIPPED rather than removed.
//
// Prints one line per path, in the order given:
//   REMOVED  .camunda/job-variables.json
//   ABSENT   .camunda/init-block.json
//
// Relative paths resolve against the current working directory, which is the
// ProcessOS project root. Always exits 0 when the paths are gone by the time it
// returns — "was not there" is the same outcome as "deleted it", which is the
// whole point of `-f`. Exits 2 on a usage error, and 1 when a directory was
// given without --recursive (the caller asked for something it did not get) or when
// a path exists but cannot be examined — an EACCES reported as ABSENT would claim a
// payload was cleaned up while it is still there.

const fs = require('fs');

/**
 * Delete one path.
 *
 * @param {string} p Path to delete, absolute or project-relative.
 * @param {boolean} recursive Allow deleting a directory and its contents.
 * @param {object} [deps]
 * @param {typeof fs.lstatSync} [deps.lstatSync] Injectable stat, for tests — an
 *   EACCES is not reproducible from a test on every platform.
 * @returns {'REMOVED'|'ABSENT'|'SKIPPED'} What happened. SKIPPED means the path
 *   is a directory and recursive was not requested.
 * @throws {Error} When the path exists but cannot be examined.
 */
function remove(p, recursive, deps = {}) {
  const lstatSync = deps.lstatSync || fs.lstatSync;
  let stat;
  try {
    // lstatSync, not statSync: a dangling symlink must still be removable, and
    // `rm` operates on the link itself rather than on what it points at.
    stat = lstatSync(p);
  } catch (err) {
    // Only genuine absence is ABSENT. An EACCES or I/O failure reported as
    // "already gone" exits 0 and tells the caller a one-shot payload was cleaned
    // up when it is still sitting there.
    if (err.code !== 'ENOENT' && err.code !== 'ENOTDIR') throw err;
    return 'ABSENT';
  }
  if (stat.isDirectory() && !recursive) return 'SKIPPED';
  fs.rmSync(p, { recursive, force: true });
  return 'REMOVED';
}

/**
 * @param {string[]} argv Arguments after the script name.
 * @returns {{recursive: boolean, paths: string[]}|null} null on an unknown flag.
 */
function parseArgs(argv) {
  // An unknown flag is a usage error, not a path. Deleting whatever `--recursve`
  // names reports `ABSENT --recursve` and exits 0, so a typo reads as a clean run
  // while the directory it was meant to remove is still there.
  if (argv.some((a) => a.startsWith('--') && a !== '--recursive')) return null;
  const recursive = argv.includes('--recursive');
  return { recursive, paths: argv.filter((a) => a !== '--recursive') };
}

/**
 * Format one outcome line. Padded so a multi-path report stays column-aligned.
 *
 * @param {string} p Path as the caller wrote it.
 * @param {'REMOVED'|'ABSENT'|'SKIPPED'} outcome Result of the delete.
 * @returns {string} Line without its trailing newline.
 */
function formatLine(p, outcome) {
  return `${outcome.padEnd(8)} ${p}`;
}

module.exports = { remove, parseArgs, formatLine };

if (require.main === module) {
  const args = parseArgs(process.argv.slice(2));
  if (!args || args.paths.length === 0) {
    process.stderr.write('usage: remove-path.cjs [--recursive] <path>...\n');
    process.exit(2);
  }
  const { recursive, paths } = args;
  let skipped = false;
  for (const p of paths) {
    let outcome;
    try {
      outcome = remove(p, recursive);
    } catch (err) {
      // The path is there and could not be dealt with. Reporting it as ABSENT
      // would tell the caller a one-shot payload is gone while it still sits in
      // the workspace for the next cycle to read.
      process.stderr.write(`remove-path.cjs: ${p}: ${err.message}\n`);
      process.exit(1);
    }
    if (outcome === 'SKIPPED') skipped = true;
    process.stdout.write(`${formatLine(p, outcome)}\n`);
  }
  if (skipped) {
    process.stderr.write('a directory was given without --recursive; nothing was deleted for it\n');
    process.exit(1);
  }
}
