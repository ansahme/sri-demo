#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Compare a Python dependency specifier against the range a cluster minor
// expects, for the scaffold's report-only SDK pin check.
//
// The blueprint declares an exact pin (`==9.0.1`) so that pyproject.toml and
// uv.lock stay one reproducible unit, while versions.json declares a major range
// (`>=9.0.0,<10.0.0`) per cluster minor. A string comparison between the two can
// never agree, so it reports a mismatch on a pin that is in fact correct and
// tells every operator to re-pin a dependency that needs no change.
//
// Scope: the operators that appear in these two files, over numeric release
// segments. This is not a PEP 440 implementation — it handles no epochs, no
// pre-release or post-release suffixes, no local versions, and no `~=`. Anything
// it cannot parse returns UNVERIFIABLE rather than a verdict, because reporting a
// parse failure as a version mismatch sends the operator to fix the wrong thing.

const VERDICT = {
  SATISFIED: 'satisfied',
  VIOLATED: 'violated',
  UNVERIFIABLE: 'unverifiable',
};

// One clause: an optional operator and a dotted numeric release.
const CLAUSE = /^(==|!=|>=|<=|>|<)?\s*([0-9]+(?:\.[0-9]+)*)$/;

/**
 * Parse a dotted numeric release into its segments.
 *
 * @param {string} release
 * @returns {number[]}
 */
function parseRelease(release) {
  return release.split('.').map((segment) => Number(segment));
}

/**
 * Compare two releases segment by segment, padding the shorter with zeros so
 * `9.0` and `9.0.0` compare equal.
 *
 * @param {number[]} a
 * @param {number[]} b
 * @returns {-1|0|1}
 */
function compareRelease(a, b) {
  const width = Math.max(a.length, b.length);
  for (let i = 0; i < width; i += 1) {
    const left = a[i] ?? 0;
    const right = b[i] ?? 0;
    if (left < right) return -1;
    if (left > right) return 1;
  }
  return 0;
}

/**
 * Parse a comma-separated specifier into its clauses, or null when any clause
 * falls outside the supported grammar — an empty clause included.
 *
 * @param {string} spec
 * @returns {Array<{op: string, release: number[]}>|null}
 */
function parseClauses(spec) {
  if (typeof spec !== 'string') return null;
  // An empty piece is a stray comma (`>=9.0.0,`), not a clause to skip. Skipping
  // it would answer over part of the specifier the caller wrote while reporting a
  // verdict on the whole. CLAUSE rejects the empty string, so the loop refuses
  // one — which also covers an empty or whitespace-only spec.
  const parts = spec.trim().split(',').map((part) => part.trim());
  const clauses = [];
  for (const part of parts) {
    const match = CLAUSE.exec(part);
    if (!match) return null;
    clauses.push({ op: match[1] || '==', release: parseRelease(match[2]) });
  }
  return clauses;
}

/**
 * The single exact version a specifier pins, or null when it pins none.
 *
 * @param {string} spec
 * @returns {number[]|null}
 */
function exactVersion(spec) {
  const clauses = parseClauses(spec);
  if (!clauses || clauses.length !== 1) return null;
  return clauses[0].op === '==' ? clauses[0].release : null;
}

/**
 * Does one release satisfy one clause?
 *
 * @param {number[]} release
 * @param {{op: string, release: number[]}} clause
 * @returns {boolean}
 */
function satisfiesClause(release, clause) {
  const order = compareRelease(release, clause.release);
  switch (clause.op) {
    case '==': return order === 0;
    case '!=': return order !== 0;
    case '>=': return order >= 0;
    case '<=': return order <= 0;
    case '>': return order > 0;
    case '<': return order < 0;
    default: return false;
  }
}

/**
 * Does the declared pin satisfy the expected range?
 *
 * Returns UNVERIFIABLE, never VIOLATED, when either side falls outside the
 * supported grammar or when the pin is a range rather than an exact version. A
 * range-against-range comparison needs interval arithmetic this module does not
 * implement, and guessing would report a verdict nothing checked.
 *
 * @param {string} pin the specifier the blueprint declares, e.g. `==9.0.1`
 * @param {string} range the specifier versions.json expects, e.g. `>=9.0.0,<10.0.0`
 * @returns {'satisfied'|'violated'|'unverifiable'}
 */
function satisfies(pin, range) {
  if (typeof pin !== 'string' || typeof range !== 'string') return VERDICT.UNVERIFIABLE;
  // An identical declaration needs no version arithmetic, and this is the one
  // case a range-shaped pin resolves cleanly. It still has to parse: two
  // identical specifiers the grammar rejects are unverifiable, not satisfied.
  const declared = pin.trim();
  if (declared !== '' && declared === range.trim() && parseClauses(declared) !== null) {
    return VERDICT.SATISFIED;
  }

  const pinned = exactVersion(pin);
  const clauses = parseClauses(range);
  if (pinned === null || clauses === null) return VERDICT.UNVERIFIABLE;

  return clauses.every((clause) => satisfiesClause(pinned, clause))
    ? VERDICT.SATISFIED
    : VERDICT.VIOLATED;
}

module.exports = { VERDICT, parseRelease, compareRelease, parseClauses, exactVersion, satisfies };
