#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// wire-execution-bpmn.mts — deterministic execution-BPMN wiring (all phases, one pass).
//
// Replaces the Phase-3 exec-BPMN LLM fan-out (one agent per phase). Because
// analyze-join now preserves the source `taskDefinition` type verbatim as the
// worker jobType, the source BPMN's worker wiring already matches the manifest —
// so this script does NOT rewrite worker task definitions. Its substantive work
// is the wiring the transformation BPMN genuinely lacks:
//
//   • bind Camunda Forms   — source userTasks carry no <zeebe:formDefinition>
//   • promote DMN outputs  — F11: lift result-context fields to top-level vars
//   • refine a plain task  — a <bpmn:task> flagged sourceTypeMissing → serviceTask
//   • message correlation  — add <zeebe:subscription correlationKey> where needed
//   • executable/namespace — ensure isExecutable + xmlns:zeebe (usually present)
//
// It reports its own hard wiring errors (a form/decision/gateway target missing
// from the BPMN). Manifest↔BPMN consistency, lint, compat, audit, and compile all
// stay with the orchestrator (SKILL.md §3.6). Icon attributes are copied through
// untouched: this script reads the BPMN, not the agent, so the ~25 KB Read
// cap never applies.
//
// Usage:
//   node scripts/wire-execution-bpmn.mts [<artifactRoot>] <bpmnDir>
//     artifactRoot default "process-implementation/artifacts"; bpmnDir e.g. process-transformation/iteration-1/artifacts
//
// Exit codes: 0 all phases wired; 1 a hard wiring error (a form/decision/gateway
// target missing from the BPMN); 2 bad inputs. Manifest↔BPMN consistency (that
// every declared wiring landed) is verified separately by audit-artifact-deps.cjs.

import * as fs from 'node:fs';
import * as path from 'node:path';
import { pathToFileURL } from 'node:url';

/** A located element's span within the XML, plus its body. */
interface Located {
  tag: string;
  openStart: number;
  openEnd: number;
  closeStart: number;
  closeEnd: number;
  openTag: string;
  inner: string;
  selfClosed: boolean;
}

// A mutator either succeeds with new XML or fails with a reason. Modelled as a
// discriminated union so `if (r.ok) xml = r.xml` narrows `xml` to string at the call
// sites, while the optional-undefined members keep `r.err` readable on both arms (the
// tests assert with `assert.ok(r.ok, r.err)`).
type MutationResult =
  | { ok: true; xml: string; err?: undefined }
  | { ok: false; err: string; xml?: undefined };

// `ensureRetries` is deliberately not a MutationResult: retries are a safety net rather
// than required wiring, so it has no failure arm — it always returns usable XML and
// reports a missing element via `notFound` for the caller to warn about.
interface RetriesResult {
  xml: string;
  notFound?: boolean;
}

interface NamedValue {
  name?: string;
  target?: string;
  source?: string;
}

interface Wiring {
  targetElementId?: string;
  formDefinitionFormId?: string;
  gatewayElementId?: string;
  sourceTypeMissing?: boolean;
  unresolvedInputs?: NamedValue[];
}

interface ManifestEntry {
  phase?: string;
  wiring?: Wiring;
  [k: string]: unknown;
}

interface WorkerEntry extends ManifestEntry {
  jobType?: string;
}

interface FormEntry extends ManifestEntry {
  formId?: string;
}

interface DecisionEntry extends ManifestEntry {
  decisionId?: string;
  resultVariable?: string;
  inputs?: NamedValue[];
  outputs?: NamedValue[];
}

interface SubscriptionEntry extends ManifestEntry {
  messageRef?: string;
  correlationKey?: string;
}

interface BindingEntry extends ManifestEntry {
  elementId?: string;
  unresolvedInputs?: NamedValue[];
}

interface Manifest {
  structure?: {
    phases?: string[];
    edgeCases?: string[];
    subprocesses?: string[];
  };
  workers?: WorkerEntry[];
  forms?: FormEntry[];
  decisions?: DecisionEntry[];
  messageSubscriptions?: SubscriptionEntry[];
  connectorBindings?: BindingEntry[];
}

function main(): void {
const ROOT = process.argv[2] && !process.argv[2].startsWith('-') ? process.argv[2] : 'process-implementation/artifacts';
const BPMN_DIR = process.argv[3] || process.argv[2 + (ROOT === process.argv[2] ? 1 : 0)];
if (!BPMN_DIR) {
  console.error('wire-execution-bpmn: usage: node wire-execution-bpmn.mts [<artifactRoot>] <bpmnDir>');
  process.exit(2);
}
const MANIFEST_PATH = path.join(ROOT, '.manifest.json');
if (!fs.existsSync(MANIFEST_PATH)) {
  console.error(`wire-execution-bpmn: missing ${MANIFEST_PATH}`);
  process.exit(2);
}
const manifest = JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf8')) as Manifest;
const OUT_DIR = path.join(ROOT, 'src', 'main', 'resources', 'processes');
const REVIEW_DIR = path.join(ROOT, '.review');
fs.mkdirSync(OUT_DIR, { recursive: true });

// Every deployable process definition, whatever its role in the topology: linear phase
// children, independent edge cases, and subprocesses invoked by a callActivity from
// inside a phase. All three need the same wiring and all three must reach `processes/`.
const phases = [
  ...((manifest.structure && manifest.structure.phases) || []),
  ...((manifest.structure && manifest.structure.edgeCases) || []),
  ...((manifest.structure && manifest.structure.subprocesses) || []),
].sort();

const byPhase = <T extends ManifestEntry>(arr: T[] | undefined): Record<string, T[]> => {
  const m: Record<string, T[]> = {};
  for (const x of (arr || [])) {
    const k = x.phase ?? '';
    (m[k] = m[k] || []).push(x);
  }
  return m;
};
const workersByPhase = byPhase(manifest.workers);
const formsByPhase = byPhase(manifest.forms);
const decisionsByPhase = byPhase(manifest.decisions);
const subsByPhase = byPhase(manifest.messageSubscriptions);
const bindingsByPhase = byPhase(manifest.connectorBindings);

let hardErrors = 0;
let selfCheckFails = 0;
const summary = [];

for (const stem of phases) {
  const srcPath = path.join(BPMN_DIR, `${stem}.bpmn`);
  const destPath = path.join(OUT_DIR, `${stem}.bpmn`);
  if (!fs.existsSync(srcPath)) {
    console.error(`  ${stem}: source BPMN not found at ${srcPath}`);
    hardErrors++;
    continue;
  }
  let xml = fs.readFileSync(srcPath, 'utf8');

  // 3a — namespace + executable (usually already present).
  if (!/xmlns:zeebe=/.test(xml)) {
    xml = xml.replace(/<bpmn:definitions\b/, '<bpmn:definitions xmlns:zeebe="http://camunda.org/schema/zeebe/1.0"');
  }
  xml = xml.replace(/<bpmn:process\b([^>]*)>/g, (mm, attrs) => {
    if (/isExecutable="true"/.test(attrs)) return mm;
    if (/isExecutable="false"/.test(attrs)) return mm.replace('isExecutable="false"', 'isExecutable="true"');
    return `<bpmn:process${attrs} isExecutable="true">`;
  });

  const errs = [];

  // Workers — only the sourceTypeMissing case needs action: refine the plain
  // <bpmn:task> to a <serviceTask> and give it its taskDefinition. Every other
  // worker's taskDefinition already lives in the source (preserved by analyze-join).
  for (const w of (workersByPhase[stem] || [])) {
    const id = w.wiring && w.wiring.targetElementId;
    if (!id) continue;
    if (w.wiring?.sourceTypeMissing) {
      const r = refinePlainTaskToWorker(xml, id, w.jobType);
      if (r.ok) xml = r.xml; else errs.push(`worker refine failed for ${id}: ${r.err}`);
    } else {
      // Idempotent safety net: ensure retries on an existing taskDefinition.
      const r = ensureRetries(xml, id);
      xml = r.xml;
      if (r.notFound) console.error(`  ${stem}: warning — worker target ${id} not found in BPMN; retries not applied`);
    }
  }

  // Forms — insert <zeebe:formDefinition> into each userTask (source has none).
  for (const f of (formsByPhase[stem] || [])) {
    const id = f.wiring && f.wiring.targetElementId;
    const formId = f.formId || (f.wiring && f.wiring.formDefinitionFormId);
    if (!id || !formId) continue;
    const r = addFormDefinition(xml, id, formId);
    if (r.ok) xml = r.xml; else errs.push(`form binding failed for ${id}: ${r.err}`);
  }

  // Decisions — ensure ioMapping. Agent-tool DMN (resultVariable === toolCallResult)
  // gets inputs-only (output promotion would fight the ad-hoc outputElement
  // collection); a standalone DMN promotes its outputs to top-level (F11).
  for (const d of (decisionsByPhase[stem] || [])) {
    const id = d.wiring && d.wiring.targetElementId;
    if (!id) continue;
    const gw = d.wiring && d.wiring.gatewayElementId;
    if (gw && !new RegExp(`\\bid="${escapeRe(gw)}"`).test(xml)) {
      errs.push(`decision ${d.decisionId} names gatewayId "${gw}" not present in BPMN`);
      continue;
    }
    const agentTool = (d.resultVariable === 'toolCallResult');
    const r = addDecisionIoMapping(xml, id, d.resultVariable, d.inputs || [], agentTool ? [] : (d.outputs || []));
    if (r.ok) xml = r.xml; else errs.push(`decision ioMapping failed for ${id}: ${r.err}`);
  }

  // Message correlation — ensure the referenced <bpmn:message> carries a FEEL
  // <zeebe:subscription correlationKey>. Start-event subscriptions have none.
  for (const s of (subsByPhase[stem] || [])) {
    if (!s.messageRef || !s.correlationKey) continue;
    const r = addMessageSubscription(xml, s.messageRef, s.correlationKey);
    if (r.ok) xml = r.xml; else errs.push(`message subscription failed for ${s.messageRef}: ${r.err}`);
  }

  // Connector inputs — write any unresolvedInputs[] entry analyze-phase already
  // resolved a non-empty `source` for; surface only the still-empty ones as
  // review markers instead of fabricating a value. `resultExpression` /
  // `errorExpression` targets are a zeebe:taskHeader binding living in a
  // different XML location (<zeebe:taskHeaders>) and are left untouched here:
  // this pass does not cover them.
  const review = [];
  for (const b of (bindingsByPhase[stem] || [])) {
    const id = b.wiring ? b.wiring.targetElementId : b.elementId;
    for (const u of ((b.wiring && b.wiring.unresolvedInputs) || b.unresolvedInputs || [])) {
      if (!u.source) { review.push({ element: id, target: u.target, reason: 'unresolved connector input (empty source)' }); continue; }
      if (u.target === 'resultExpression' || u.target === 'errorExpression') continue;
      // A binding naming neither an element nor a target cannot be written; surface it as a
      // review marker rather than building a regex out of `undefined`.
      if (!id || !u.target) { review.push({ element: id, target: u.target, reason: 'connector input missing element id or target' }); continue; }
      const r = setConnectorInputSource(xml, id, u.target, u.source);
      if (r.ok) xml = r.xml; else errs.push(`connector input write failed for ${id}.${u.target}: ${r.err}`);
    }
  }
  if (review.length) {
    fs.mkdirSync(REVIEW_DIR, { recursive: true });
    fs.writeFileSync(path.join(REVIEW_DIR, `${stem}.json`), JSON.stringify(review, null, 2));
  }

  fs.writeFileSync(destPath, xml);

  if (errs.length) { hardErrors += errs.length; errs.forEach(e => console.error(`  ${stem}: ${e}`)); }

  // Manifest↔BPMN consistency (that every declared wiring landed on its target)
  // is verified once at the orchestrator level by audit-artifact-deps.cjs — not
  // re-checked per phase here.
  summary.push(`  ${stem}: forms=${(formsByPhase[stem] || []).length} decisions=${(decisionsByPhase[stem] || []).length} review=${review.length} ${errs.length ? '✗' : '✓'}`);
}

console.log(`wire-execution-bpmn: wired ${phases.length} phase(s) into ${OUT_DIR}`);
summary.forEach(s => console.log(s));
if (hardErrors) console.error(`wire-execution-bpmn: ${hardErrors} wiring error(s) — fix before the audit`);
process.exit(hardErrors ? 1 : 0);
}

if (import.meta.url === pathToFileURL(process.argv[1] ?? '').href) main();

export {
  locate, insertIntoExtensions, addFormDefinition, addDecisionIoMapping,
  ensureRetries, refinePlainTaskToWorker, addMessageSubscription,
  formatConnectorSource, setConnectorInputSource,
};

// ── element-scoped helpers (regex, consistent with generate-parent-bpmn.ts) ──
function escapeRe(s: string): string { return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

// Return {tag, openStart, openEnd, closeStart, closeEnd, inner, selfClosed} for the
// element carrying id="ID", or null.
//
// Handles BOTH forms, because this script consumes whatever sits in the source
// BPMN dir — the bpmnkit generator emits <tag …>…</tag> with incoming/outgoing
// children, but a hand-authored fallback file, a modeler round-trip or a
// Web-Modeler export can perfectly well ship <serviceTask …/>.
//
// The self-closed case needs explicit handling rather than falling out of the
// regex: `[^>]*>` also matches the `/>` of a self-closed tag, so without the
// branch below the first `</bpmn:tag>` found further down the document is taken as
// this element's close — `inner` then spans the following siblings and every
// mutator splices its fragment outside the element, producing invalid XML while
// still reporting ok.
function locate(xml: string, id: string): Located | null {
  const idRe = new RegExp(`<bpmn:(\\w+)\\b[^>]*\\bid="${escapeRe(id)}"[^>]*>`);
  const m = idRe.exec(xml);
  if (!m) return null;
  const tag = m[1] ?? "";
  const openStart = m.index;
  const openEnd = m.index + m[0].length;
  if (m[0].endsWith('/>')) {
    // Empty element: no body to read, nothing between openEnd and closeStart.
    return { tag, openStart, openEnd, closeStart: openEnd, closeEnd: openEnd, openTag: m[0], inner: '', selfClosed: true };
  }
  const closeTag = `</bpmn:${tag}>`;
  const closeStart = xml.indexOf(closeTag, openEnd);
  if (closeStart < 0) return null;
  const inner = xml.slice(openEnd, closeStart);
  // Same-tag nesting (a subProcess inside a subProcess) would make the first
  // close tag belong to the inner element, so this span is not ours. Bail rather
  // than splice across an element boundary — callers report a hard error.
  if (new RegExp(`<bpmn:${tag}\\b`).test(inner)) return null;
  return { tag, openStart, openEnd, closeStart, closeEnd: closeStart + closeTag.length, openTag: m[0], inner, selfClosed: false };
}

// Replace an element's body, expanding `<tag …/>` into `<tag …>body</tag>` when the
// element is self-closed. Every mutator goes through this so the expansion lives
// in exactly one place (same trick addMessageSubscription already used for
// self-closed <bpmn:message/>).
function replaceInner(xml: string, el: Located, newInner: string): string {
  if (el.selfClosed) {
    const open = el.openTag.slice(0, -2).replace(/\s+$/, '') + '>';
    return xml.slice(0, el.openStart) + open + newInner + `</bpmn:${el.tag}>` + xml.slice(el.closeEnd);
  }
  return xml.slice(0, el.openEnd) + newInner + xml.slice(el.closeStart);
}

// Insert `frag` as the first child of the element's <bpmn:extensionElements>,
// creating the extensionElements block if absent. Idempotent via `guardRe`.
function insertIntoExtensions(xml: string, id: string, frag: string, guardRe: RegExp): MutationResult {
  const el = locate(xml, id);
  if (!el) return { ok: false, err: 'element not found' };
  if (guardRe && guardRe.test(el.inner)) return { ok: true, xml }; // already present
  const extOpen = el.inner.match(/<bpmn:extensionElements\b[^>]*>/);
  let newInner;
  if (extOpen) {
    const at = el.inner.indexOf(extOpen[0]) + extOpen[0].length;
    newInner = el.inner.slice(0, at) + `\n        ${frag}` + el.inner.slice(at);
  } else {
    newInner = `\n      <bpmn:extensionElements>\n        ${frag}\n      </bpmn:extensionElements>` + el.inner;
  }
  return { ok: true, xml: replaceInner(xml, el, newInner) };
}

function addFormDefinition(xml: string, id: string, formId: string): MutationResult {
  return insertIntoExtensions(xml, id,
    `<zeebe:formDefinition formId="${formId}" />`,
    /<zeebe:formDefinition\b/);
}

function addDecisionIoMapping(xml: string, id: string, resultVariable: string | undefined, inputs: NamedValue[], outputs: NamedValue[]): MutationResult {
  const el = locate(xml, id);
  if (!el) return { ok: false, err: 'element not found' };
  // (insertIntoExtensions below re-locates and handles the self-closed expansion.)
  if (/<zeebe:ioMapping\b/.test(el.inner)) return { ok: true, xml }; // idempotent
  const ins = (inputs || []).map(i => `<zeebe:input source="=${i.name}" target="${i.name}" />`);
  const outs = (outputs || []).map(o => `<zeebe:output source="=${resultVariable}.${o.name}" target="${o.name}" />`);
  if (!ins.length && !outs.length) return { ok: true, xml }; // nothing to map
  const frag = `<zeebe:ioMapping>\n          ${[...ins, ...outs].join('\n          ')}\n        </zeebe:ioMapping>`;
  return insertIntoExtensions(xml, id, frag, /<zeebe:ioMapping\b/);
}

// Ensure an existing worker <zeebe:taskDefinition> carries retries (default 3).
// Returns the XML unchanged when the element has no taskDefinition to amend (a
// self-closed task has no body at all) — retries are a safety net, not a required
// wiring, so this is not a hard error. `notFound` is reported by the caller so an
// element the manifest names but the BPMN lacks is not invisible.
function ensureRetries(xml: string, id: string): RetriesResult {
  const el = locate(xml, id);
  if (!el) return { xml, notFound: true };
  if (!/<zeebe:taskDefinition\b/.test(el.inner) || /<zeebe:taskDefinition\b[^>]*\bretries=/.test(el.inner)) return { xml };
  const newInner = el.inner.replace(/<zeebe:taskDefinition\b([^>]*?)(\/?)>/,
    (mm, attrs, sc) => `<zeebe:taskDefinition${attrs} retries="3"${sc}>`);
  return { xml: replaceInner(xml, el, newInner) };
}

// Refine a plain <bpmn:task id="ID">…</bpmn:task> (or <bpmn:task id="ID"/>) into a
// serviceTask worker.
function refinePlainTaskToWorker(xml: string, id: string, jobType: string | undefined): MutationResult {
  const el = locate(xml, id);
  if (!el) return { ok: false, err: 'element not found' };
  if (el.tag !== 'task') {
    // already a serviceTask etc. — just make sure it has a taskDefinition
    if (/<zeebe:taskDefinition\b/.test(el.inner)) return { ok: true, xml };
    return insertIntoExtensions(xml, id, `<zeebe:taskDefinition type="${jobType}" retries="3" />`, /<zeebe:taskDefinition\b/);
  }
  const openTag = el.selfClosed ? el.openTag.slice(0, -2).replace(/\s+$/, '') + '>' : el.openTag;
  const newOpen = openTag.replace(/^<bpmn:task\b/, '<bpmn:serviceTask');
  const td = `\n      <bpmn:extensionElements>\n        <zeebe:taskDefinition type="${jobType}" retries="3" />\n      </bpmn:extensionElements>`;
  const rebuilt = newOpen + td + el.inner + `</bpmn:serviceTask>`;
  return { ok: true, xml: xml.slice(0, el.openStart) + rebuilt + xml.slice(el.closeEnd) };
}

function escapeAttr(s: string): string {
  return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
}

// Format a manifest `unresolvedInputs[].source` value per the "Source rules"
// in analyze-phase.md: a FEEL variable reference is used verbatim; a quoted
// string literal or a boolean/numeric literal gets the `=` FEEL prefix added;
// a bare literal (Dropdown/Hidden bindings such as HttpJson `method`) is kept
// exactly as-is — it is a Zeebe literal binding, not a FEEL expression.
function formatConnectorSource(raw: string): string {
  if (/^=/.test(raw)) return raw;
  if (/^".*"$/.test(raw)) return `=${raw}`;
  if (raw === 'true' || raw === 'false' || /^-?\d+(\.\d+)?$/.test(raw)) return `=${raw}`;
  return raw;
}

// Rewrite the `source` attribute of the <zeebe:input target="target"> inside
// element `id`'s ioMapping. Connector bindings are preserved as-is elsewhere in
// this script (never rebuilt) — this only fills a value analyze-phase already
// resolved into unresolvedInputs[]; it neither adds nor removes zeebe:input
// entries, so a target absent from the source BPMN is reported, not created.
function setConnectorInputSource(xml: string, id: string, target: string, rawSource: string): MutationResult {
  const el = locate(xml, id);
  if (!el) return { ok: false, err: 'element not found' };
  const tagRe = new RegExp(`<zeebe:input\\b[^>]*\\btarget="${escapeRe(target)}"[^>]*/>`);
  const m = tagRe.exec(el.inner);
  if (!m) return { ok: false, err: `no zeebe:input target="${target}" found` };
  const value = escapeAttr(formatConnectorSource(rawSource));
  const tag = /\bsource="[^"]*"/.test(m[0])
    ? m[0].replace(/\bsource="[^"]*"/, `source="${value}"`)
    : m[0].replace(/^<zeebe:input\b/, `<zeebe:input source="${value}"`);
  const newInner = el.inner.slice(0, m.index) + tag + el.inner.slice(m.index + m[0].length);
  return { ok: true, xml: replaceInner(xml, el, newInner) };
}

function addMessageSubscription(xml: string, messageRef: string, correlationKey: string): MutationResult {
  const re = new RegExp(`(<bpmn:message\\b[^>]*\\bid="${escapeRe(messageRef)}"[^>]*?)(/>|>[\\s\\S]*?</bpmn:message>)`);
  const m = re.exec(xml);
  if (!m) return { ok: false, err: 'message definition not found' };
  if (/<zeebe:subscription\b/.test(m[0])) return { ok: true, xml };
  const key = correlationKey.startsWith('=') ? correlationKey : `=${correlationKey}`;
  const sub = `<bpmn:extensionElements><zeebe:subscription correlationKey="${key}" /></bpmn:extensionElements>`;
  const replaced = (m[2] ?? "") === "/>"
    ? `${m[1]}>${sub}</bpmn:message>`
    : `${m[1]}>${sub}${(m[2] ?? "").slice(1)}`;
  return { ok: true, xml: xml.slice(0, m.index) + replaced + xml.slice(m.index + m[0].length) };
}
