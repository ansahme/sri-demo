#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Emit the entire Python worker layer in one pass from process-implementation/artifacts/.manifest.json.
//
// Run by the Phase-3 orchestrator with no subagent: the per-worker work is
// mechanical templating with stub bodies and zero judgement, so subagents buy
// nothing and cost run-to-run reproducibility, unit-testability, and a subagent
// budget the worker spine documents as already near its cap. One writer also
// dissolves the write race on src/app.py, which is the single registry every
// generated worker has to appear in.
//
// This wrapper owns the filesystem, the command line and the exit codes.
// generate-workers-python-emit.cjs owns every mapping from manifest data to
// Python source, and holds no filesystem or process state.
//
// Usage:
//   node "scripts/generate-workers-python.cjs" [<artifact-dir>]
//
//   <artifact-dir>  Default `process-implementation/artifacts`.
//
// stdout: one `wrote`, `removed` or `skipped` line per file, then a summary.
// Nothing on stderr on the success path.
//
// Exit codes:
//   0  every file written
//   2  usage error, an absent or unparseable manifest, or two entries for one job
//      type that disagree on className
//   3  a job type derives no legal Python identifier, or a digit-leading one
//   4  two distinct job types collapse onto one Python stem
//   5  a variable name derives no Python field name, or two distinct variable
//      names derive one field name in the same generated model
//   6  an existing service stub cannot be read (EACCES, EISDIR, an I/O error) —
//      distinct from an absent one, which is written normally
//
// Every check runs before the first write or deletion, and each failure names
// every offending job type and variable name, so one run reports the whole
// problem. A rejected manifest leaves the artifact tree exactly as it was.

const fs = require('fs');
const path = require('path');
// Sibling in this same scripts/ dir — the documented exemption to the
// self-contained-scripts rule.
const emit = require('./generate-workers-python-emit.cjs');
const { toPyPackageName } = require('./python-naming.cjs');

const EXIT = {
  OK: 0,
  USAGE: 2,
  ILLEGAL_STEM: 3,
  STEM_COLLISION: 4,
  VARIABLE_NAME: 5,
  STUB_UNREADABLE: 6,
};

const DEFAULT_ARTIFACT_DIR = 'process-implementation/artifacts';

// Suffixes this generator deletes and rewrites unconditionally on every pass.
// Nothing under these paths is a sanctioned hand-edit surface.
function regeneratedSuffixes(pyPackage) {
  return [{ dir: [pyPackage, 'workers'], suffix: '_worker.py' }];
}

// Suffixes written once and left exactly as they are on every later pass —
// the file class the skill's own Report section names as manual work
// ("implement the domain logic"). A job type that leaves the manifest still
// takes its stale stub with it; a job type that survives keeps whatever a
// developer put there.
function preservedSuffixes(pyPackage) {
  return [{ dir: [pyPackage, 'services'], suffix: '_service.py' }];
}

// The paths this generator owns and therefore may delete or preserve, under
// `pyPackage` — the top-level package name scaffold-workers.cjs derives from
// processSlug. Everything else there belongs to the blueprint: __init__.py,
// worker_defaults.py, http_client.py, external_api_error.py, config/,
// observability/, main.py and shutdown.py all survive a re-run untouched.
function ownedSuffixes(pyPackage) {
  return [...regeneratedSuffixes(pyPackage), ...preservedSuffixes(pyPackage)];
}
function ownedFiles(pyPackage) {
  return [
    [pyPackage, 'errors', 'service_error.py'],
    [pyPackage, 'errors', 'bpmn_errors.py'],
    [pyPackage, 'models', 'process_variables.py'],
    [pyPackage, 'app.py'],
  ];
}

/**
 * Every file under `artifactDir` matching one of `suffixGroups`.
 *
 * @param {string} artifactDir
 * @param {Array<{dir: string[], suffix: string}>} suffixGroups
 * @returns {string[]} paths relative to artifactDir, forward-slashed
 */
function findBySuffixes(artifactDir, suffixGroups) {
  const found = [];
  for (const { dir, suffix } of suffixGroups) {
    const abs = path.join(artifactDir, ...dir);
    if (!fs.existsSync(abs)) continue;
    for (const entry of fs.readdirSync(abs, { withFileTypes: true })) {
      if (entry.isFile() && entry.name.endsWith(suffix)) found.push(path.join(...dir, entry.name));
    }
  }
  return found;
}

/**
 * Whether `relPath` (forward-slashed, relative to `artifactDir`) falls under
 * one of `pyPackage`'s preserved suffixes (currently: the services package).
 *
 * @param {string} relPath
 * @param {string} pyPackage
 * @returns {boolean}
 */
function isPreservedPath(relPath, pyPackage) {
  return preservedSuffixes(pyPackage).some(
    ({ dir, suffix }) => path.dirname(relPath) === path.join(...dir) && relPath.endsWith(suffix),
  );
}

/**
 * Read and parse the manifest, or throw with an `exit` a caller maps to a status.
 *
 * An absent manifest and an unparseable one are one outcome here. The manifest is
 * this generator's whole input, so "not there" is not a legitimate "nothing to do"
 * state — it means the caller sits at the wrong point in the run.
 *
 * @param {string} artifactDir
 * @returns {object}
 */
function readManifest(artifactDir) {
  const manifestPath = path.join(artifactDir, '.manifest.json');
  if (!fs.existsSync(manifestPath)) {
    const err = new Error(`generate-workers-python: missing ${manifestPath}`);
    err.exit = EXIT.USAGE;
    throw err;
  }
  try {
    return JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  } catch (cause) {
    const err = new Error(
      `generate-workers-python: ${manifestPath} exists but does not parse: ${cause.message}`,
    );
    err.exit = EXIT.USAGE;
    throw err;
  }
}

/**
 * Every generated Python file currently under the artifact tree.
 *
 * Read before any write, so the caller can tell a file that survives this run
 * from one whose job type has disappeared.
 *
 * @param {string} artifactDir
 * @param {string} [pyPackage] defaults to `src`, the blueprint's own name —
 *   see renderAll's matching default in generate-workers-python-emit.cjs.
 * @returns {string[]} paths relative to artifactDir, forward-slashed
 */
function findOwnedFiles(artifactDir, pyPackage = 'src') {
  const found = findBySuffixes(artifactDir, ownedSuffixes(pyPackage));
  for (const parts of ownedFiles(pyPackage)) {
    if (fs.existsSync(path.join(artifactDir, ...parts))) found.push(path.join(...parts));
  }
  return found;
}

/**
 * Turn each validation result into the error the operator acts on.
 *
 * @param {object} problems from emit.validateGroups
 * @throws {Error & {exit: number}}
 */
function rejectOnProblems(problems) {
  const { illegalStems, stemCollisions, classNameConflicts, variableProblems } = problems;

  if (illegalStems.length > 0) {
    const err = new Error(
      'generate-workers-python: these job types derive no legal Python identifier (a job type with ' +
        `no alphanumeric content, or a digit-leading one): ${illegalStems.join(', ')}. ` +
        'Rename the BPMN element, or the jobType in the manifest, and run this again.',
    );
    err.exit = EXIT.ILLEGAL_STEM;
    throw err;
  }

  if (stemCollisions.length > 0) {
    const err = new Error(
      'generate-workers-python: these job types collapse onto one generated name, which leaves all ' +
        'but one permanently without a subscriber: ' +
        `${stemCollisions.map((c) => c.join(' + ')).join('; ')}. Rename one of each pair and run this again.`,
    );
    err.exit = EXIT.STEM_COLLISION;
    throw err;
  }

  if (classNameConflicts.length > 0) {
    const err = new Error(
      'generate-workers-python: these job types carry disagreeing className values across their ' +
        'manifest entries, and one job type has one worker: ' +
        `${classNameConflicts.map((c) => `${c.jobType} (${c.classNames.join(' vs ')})`).join('; ')}. ` +
        'Make the entries agree and run this again.',
    );
    err.exit = EXIT.USAGE;
    throw err;
  }

  if (variableProblems.length > 0) {
    const lines = variableProblems.map((p) => (p.reason === 'no-identifier'
      ? `${p.model}: ${p.sources.join(', ')} derives no Python field name`
      : `${p.model}: ${p.sources.join(' + ')} all derive the field name ${p.field}`));
    const err = new Error(
      'generate-workers-python: these variable names cannot become Python fields. One Python ' +
        'attribute carries one alias, so the generator does not choose a name the process never ' +
        `declares: ${lines.join('; ')}. Rename the process variable and run this again.`,
    );
    err.exit = EXIT.VARIABLE_NAME;
    throw err;
  }
}

/**
 * Whether an existing preserved-path file (a service stub) is there and
 * readable, there and absent, or there and broken.
 *
 * Reading happens before any deletion or write anywhere in `generate`, so a
 * stub this run cannot verify never gets silently destroyed by the removal
 * pass further down — the same "every check before the first write" ordering
 * `rejectOnProblems` already gives the manifest checks.
 *
 * @param {string} abs
 * @returns {boolean} true when the file exists and can be read.
 * @throws {Error & {exit: number}} when the file exists but cannot be read.
 */
function stubIsPresent(abs) {
  try {
    fs.readFileSync(abs);
    return true;
  } catch (err) {
    if (err.code === 'ENOENT') return false;
    const wrapped = new Error(
      `generate-workers-python: ${abs} exists but could not be read (${err.code || err.message}). ` +
        'A service stub is where a developer implements the domain logic, so this generator never ' +
        'overwrites one it cannot verify. Nothing was written or removed. Fix the file and run again.',
    );
    wrapped.exit = EXIT.STUB_UNREADABLE;
    throw wrapped;
  }
}

/**
 * Generate the whole layer.
 *
 * Order matters. Validation runs first, so a rejected manifest leaves the tree
 * untouched. Reading each planned service stub's presence runs next, before any
 * deletion or write, for the same reason. Removal follows, so a job type that
 * disappeared from the manifest takes its worker and its (possibly stale) service
 * stub with it rather than leaving a file that registers nothing and reads as
 * real. Writes run last, and skip every service stub this run found present.
 *
 * @param {string} [artifactDir]
 * @returns {{written: string[], removed: string[], skipped: string[], kept: string[]}}
 */
function generate(artifactDir = DEFAULT_ARTIFACT_DIR) {
  const manifest = readManifest(artifactDir);
  const groups = emit.groupWorkers(manifest.workers);
  rejectOnProblems(emit.validateGroups(groups));

  // Falls back to `src` rather than rejecting: a real run always reaches this
  // generator through scaffold-workers.cjs, which already requires and
  // validates processSlug on the same manifest, so an absent one here means a
  // caller that never cares about the package name.
  const pyPackage = toPyPackageName(manifest.meta && manifest.meta.processSlug) || 'src';

  const plan = emit.renderAll(groups, pyPackage);
  const planned = new Set(plan.map((f) => f.path));

  // Every planned service stub's on-disk state, decided before any deletion or
  // write below. `false` means absent (write it); a present-but-unreadable one
  // throws and stops the run before anything else changes.
  const stubPresent = new Map();
  for (const file of plan) {
    if (isPreservedPath(file.path, pyPackage)) {
      stubPresent.set(file.path, stubIsPresent(path.join(artifactDir, file.path)));
    }
  }

  // Regenerated files (currently: the worker classes, plus the exact-named
  // errors/models/app.py files) go unconditionally. `removed` reports only
  // those the new plan does not replace, which is the signal an operator
  // needs: a job type left the manifest.
  const existingRegenerated = findBySuffixes(artifactDir, regeneratedSuffixes(pyPackage));
  const existingOwnedFiles = ownedFiles(pyPackage)
    .map((parts) => path.join(...parts))
    .filter((rel) => fs.existsSync(path.join(artifactDir, rel)));
  const removed = [];
  for (const rel of [...existingRegenerated, ...existingOwnedFiles]) {
    fs.rmSync(path.join(artifactDir, rel), { force: true });
    if (!planned.has(rel)) removed.push(rel);
  }

  // Preserved files (service stubs): a stale one — its job type left the
  // manifest — goes with its worker. A surviving one is left exactly as the
  // presence check above found it; the write loop below skips it.
  for (const rel of findBySuffixes(artifactDir, preservedSuffixes(pyPackage))) {
    if (!planned.has(rel)) {
      fs.rmSync(path.join(artifactDir, rel), { force: true });
      removed.push(rel);
    }
  }

  const written = [];
  const kept = [];
  for (const file of plan) {
    if (stubPresent.get(file.path)) {
      kept.push(file.path);
      continue;
    }
    const abs = path.join(artifactDir, file.path);
    fs.mkdirSync(path.dirname(abs), { recursive: true });
    fs.writeFileSync(abs, file.text);
    written.push(file.path);
  }

  const skipped = groups.some((g) => g.errorCodes.length > 0)
    ? []
    : [`${path.join(pyPackage, 'errors', 'bpmn_errors.py')} (no job type declares an error code)`];

  written.sort();
  removed.sort();
  kept.sort();
  return { written, removed, skipped, kept };
}

module.exports = {
  EXIT,
  DEFAULT_ARTIFACT_DIR,
  ownedSuffixes,
  ownedFiles,
  regeneratedSuffixes,
  preservedSuffixes,
  readManifest,
  findOwnedFiles,
  generate,
};

if (require.main === module) {
  const artifactDir = process.argv[2] || DEFAULT_ARTIFACT_DIR;
  let result;
  try {
    result = generate(artifactDir);
  } catch (err) {
    process.stderr.write(`${err.message}\n`);
    process.exit(err.exit || EXIT.USAGE);
  }
  const lines = [
    ...result.written.map((p) => `wrote   ${p}`),
    ...result.kept.map((p) => `kept    ${p} (existing service stub left as-is)`),
    ...result.removed.map((p) => `removed ${p} (no manifest job type derives it)`),
    ...result.skipped.map((s) => `skipped ${s}`),
    `generate-workers-python: ${result.written.length} file(s) written under ${artifactDir}/`,
  ];
  process.stdout.write(`${lines.join('\n')}\n`);
}
