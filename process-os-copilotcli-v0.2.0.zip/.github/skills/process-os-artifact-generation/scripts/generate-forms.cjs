#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Generate one Camunda Form JSON file per entry in manifest.forms[].
// Pure templating — no LLM reasoning. Replaces the v3 generate-forms agent.
//
// The Camunda Forms envelope + per-field component shape comes from
// camunda-form.cjs (shared with questions-to-form). Field types, the
// validate.required rule, and select/taglist/radio value mapping all live
// there; this script only walks manifest.forms[] and writes the files.
//
// Usage:
//   node scripts/generate-forms.cjs [<artifactRoot>]    (default: "process-implementation/artifacts")
//
// Reads:  <root>/.manifest.json
// Writes: <root>/src/main/resources/forms/<formId>.form  (one per form)

'use strict';

const fs = require('fs');
const path = require('path');
const { buildComponent, formEnvelope, resetFieldIdState } = require(path.join(__dirname, 'camunda-form.cjs'));

const ROOT = process.argv[2] || 'process-implementation/artifacts';
const MANIFEST_PATH = path.join(ROOT, '.manifest.json');
const OUT_DIR = path.join(ROOT, 'src', 'main', 'resources', 'forms');

if (!fs.existsSync(MANIFEST_PATH)) {
  console.error(`generate-forms: missing ${MANIFEST_PATH}`);
  process.exit(2);
}

const manifest = JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf8'));
const forms = manifest.forms || [];

if (forms.length === 0) {
  console.log('generate-forms: no forms in manifest — nothing to generate.');
  process.exit(0);
}

fs.mkdirSync(OUT_DIR, { recursive: true });

// Cleared once for the whole run: ids are derived from each field's own (formId, identity)
// composite, so this only guards against stale state from a prior run in the same process (e.g.
// under a test harness) rather than anything order-dependent across forms.
resetFieldIdState();

const writtenFiles = [];

for (const f of forms) {
  const formId = f.formId;
  if (!formId) {
    console.error(`generate-forms: skipping entry without formId: ${JSON.stringify(f)}`);
    continue;
  }
  const fields = f.fields || [];
  const components = fields.map((field) => buildComponent(field, { formId }));
  const form = formEnvelope(formId, components);

  const fp = path.join(OUT_DIR, `${formId}.form`);
  fs.writeFileSync(fp, JSON.stringify(form, null, 2) + '\n');
  writtenFiles.push(fp);
}

console.log(`generate-forms: wrote ${writtenFiles.length} form file(s) to ${OUT_DIR}`);
for (const fp of writtenFiles) console.log(`  ${fp}`);
