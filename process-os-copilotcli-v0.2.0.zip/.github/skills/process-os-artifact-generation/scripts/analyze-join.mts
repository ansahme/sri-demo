#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Mechanical join of per-phase analyze slices into the canonical manifest.
//
// Replaces SKILL.md Phase 1 steps 1.5 (collect + reconcile + structure) and
// 1.6 (write manifest). Pure deterministic node — no LLM reasoning. Runs in
// <1 s on a typical 7-phase project; the prior LLM-driven finalize subagent
// was taking 500+ s for the same work.
//
// Inputs (read from disk):
//   <root>/.analyze-phase/_meta.json            — written by SKILL.md step 1.2
//   <root>/.analyze-phase/<stem>.json           — per-phase slices (one per dispatched agent)
//
// Outputs:
//   <root>/.manifest.json                       — canonical artifact manifest
//   <root>/.analyze-phase/_disagreements.json   — variable type disagreement list
//
// Usage:
//   node scripts/analyze-join.mts [<artifactRoot>]    (default: "process-implementation/artifacts")
//
// Exit codes: 0 success, 2 missing inputs.

import * as fs from 'node:fs';
import * as path from 'node:path';

interface Variable {
  name: string;
  type?: string;
  confidence?: string;
}

interface Wiring {
  targetElementId?: string;
  zeebeTaskDefinitionType?: string;
  sourceTypeMissing?: boolean;
}

interface Worker {
  jobType?: string;
  className?: string;
  wiring?: Wiring;
  inputVariables?: Variable[];
  outputVariables?: Variable[];
}

interface Slice {
  phase: string;
  workers?: Worker[];
  decisions?: unknown[];
  forms?: unknown[];
  connectorBindings?: unknown[];
  messageSubscriptions?: unknown[];
}

interface ParsedElement {
  id: string;
  modelerTemplate?: string;
  taskDefinition?: string;
}

interface Handoff {
  from: string;
  to: string;
  vars: string[];
}

interface Structure {
  type: 'single' | 'call-activities';
  reasoning: string;
  phases: string[];
  edgeCases?: string[];
  subprocesses?: string[];
  ioMapping?: Handoff[];
  handoffs?: Handoff[];
}

interface VarEntry {
  phase: string;
  type: string | undefined;
  ref: Variable;
}

const ROOT = process.argv[2] || 'process-implementation/artifacts';
const SCRATCH = path.join(ROOT, '.analyze-phase');
const META_PATH = path.join(SCRATCH, '_meta.json');
const MANIFEST_PATH = path.join(ROOT, '.manifest.json');
const DISAGREE_PATH = path.join(SCRATCH, '_disagreements.json');

if (!fs.existsSync(META_PATH)) {
  console.error(`analyze-join: missing ${META_PATH}`);
  console.error('  SKILL.md step 1.2 must write _meta.json with processName/packageBase/processCamel/processSlug before this script runs.');
  process.exit(2);
}

const meta: unknown = JSON.parse(fs.readFileSync(META_PATH, 'utf8'));

const sliceFiles = fs.readdirSync(SCRATCH)
  .filter(f => f.endsWith('.json') && !f.endsWith('.bpmn.json') && !f.startsWith('_'))
  .sort();

if (sliceFiles.length === 0) {
  console.error(`analyze-join: no per-phase slices in ${SCRATCH}`);
  process.exit(2);
}

const slices: Slice[] = sliceFiles.map(f => JSON.parse(fs.readFileSync(path.join(SCRATCH, f), 'utf8')) as Slice);

// ── Worker reconciliation against the parser output (BPMN is authoritative) ──
// The parser wrote <stem>.bpmn.json alongside each slice; it now surfaces each
// task element's `modelerTemplate` and source `taskDefinition` type. Two
// deterministic passes over every slice's workers, BEFORE variable
// reconciliation and concatenation so both see the corrected set:
//
//   (1) Drop connector-bound workers. A worker whose target element carries a
//       `modelerTemplate` is serviced by Zeebe's connector runtime, not a job
//       worker — emitting one produces a dead class. This is the mechanical
//       guarantee behind "an element with zeebe:modelerTemplate is never a
//       worker", independent of whether the analyze LLM classified it right.
//
//   (2) Preserve the source job type verbatim. The worker registers on exactly
//       the `taskDefinition type` the diagram already carries, so downstream
//       exec-BPMN needs no taskDefinition rewrite and the two can never drift.
//       className is recomputed from that type. When the target element has no
//       taskDefinition (a plain <bpmn:task>), there is nothing to preserve — a
//       worker cannot fire on it as authored; keep the derived jobType but flag
//       it as a transformation defect for exec-BPMN to refine + verify.
const droppedConnectorWorkers: string[] = [];
const workersMissingSourceType: string[] = [];
for (const s of slices) {
  const idx = loadElementIndex(s.phase);
  if (!idx) continue; // no parser output for this phase — leave slice as authored
  s.workers = (s.workers || []).filter(w => {
    const el = idx.get(w.wiring?.targetElementId ?? '');
    if (el && el.modelerTemplate) {
      droppedConnectorWorkers.push(`${s.phase}/${w.wiring?.targetElementId} (${el.modelerTemplate})`);
      return false;
    }
    return true;
  });
  for (const w of s.workers) {
    const el = idx.get(w.wiring?.targetElementId ?? '');
    if (el && el.taskDefinition) {
      w.jobType = el.taskDefinition;
      w.className = classNameFor(el.taskDefinition);
      if (w.wiring) w.wiring.zeebeTaskDefinitionType = el.taskDefinition;
    } else if (el) {
      if (w.wiring) w.wiring.sourceTypeMissing = true;
      workersMissingSourceType.push(`${s.phase}/${w.wiring?.targetElementId} → derived jobType="${w.jobType}"`);
    }
  }
}

// Variable reconciliation: walk every worker.inputVariables / outputVariables
// across all slices, group by name, flag type disagreements.
const groups = new Map<string, VarEntry[]>();
for (const s of slices) {
  for (const w of (s.workers || [])) {
    for (const v of (w.inputVariables || [])) recordVar(groups, s.phase, v);
    for (const v of (w.outputVariables || [])) recordVar(groups, s.phase, v);
  }
}

const disagreements: Array<{ name: string; phases: string[]; types: Array<string | undefined> }> = [];
for (const [name, entries] of groups) {
  const types = uniq(entries.map(e => e.type));
  if (types.length > 1) {
    disagreements.push({
      name,
      phases: uniq(entries.map(e => e.phase)),
      types,
    });
    // Mark every entry medium-confidence — the user must resolve in review.
    for (const e of entries) e.ref.confidence = 'medium';
  }
}

// Structure determination.
//
// Three stem prefixes are valid (parser already enforces this):
//   process-NN-* → linear phase children of the parent BPMN
//   edge-NN-*    → independent edge-case processes (error/escalation paths)
//   subprocess-* → processes invoked by a callActivity from inside a phase
//
// Only `process-*` participates in handoff/structure detection. Edges are
// triggered by error events or message correlation rather than chained
// linearly; subprocesses are reached from inside a phase rather than from the
// parent. All three are surfaced in the manifest so Phase 3 fan-out can
// dispatch over their union; `generate-parent-bpmn.ts` continues to read only
// `structure.phases`, which keeps edges and subprocesses out of the linear
// call-activity chain.
const allStems = slices.map(s => s.phase);
const phaseStems = allStems.filter(s => s.startsWith('process-'));
const edgeStems = allStems.filter(s => s.startsWith('edge-'));
const subprocessStems = allStems.filter(s => s.startsWith('subprocess-'));
const phaseSlices = slices.filter(s => s.phase.startsWith('process-'));
const structure = determineStructure(phaseSlices, phaseStems);
structure.edgeCases = edgeStems;
structure.subprocesses = subprocessStems;

// Concatenate slice arrays in phase order.
const manifest = {
  meta,
  structure,
  workers: slices.flatMap(s => s.workers || []),
  decisions: slices.flatMap(s => s.decisions || []),
  forms: slices.flatMap(s => s.forms || []),
  connectorBindings: slices.flatMap(s => s.connectorBindings || []),
  messageSubscriptions: slices.flatMap(s => s.messageSubscriptions || []),
};

fs.writeFileSync(MANIFEST_PATH, JSON.stringify(manifest, null, 2));
fs.writeFileSync(DISAGREE_PATH, JSON.stringify(disagreements, null, 2));

console.log(`analyze-join: wrote ${MANIFEST_PATH}`);
console.log(`  workers=${manifest.workers.length} decisions=${manifest.decisions.length} forms=${manifest.forms.length} connectorBindings=${manifest.connectorBindings.length} messageSubscriptions=${manifest.messageSubscriptions.length}`);
console.log(`  structure=${structure.type} phases=${phaseStems.length} edgeCases=${edgeStems.length} subprocesses=${subprocessStems.length}`);
console.log(`  variable type disagreements: ${disagreements.length}`);
if (droppedConnectorWorkers.length) {
  console.log(`  dropped ${droppedConnectorWorkers.length} connector-bound worker(s) (serviced by the connector runtime, not a job worker):`);
  droppedConnectorWorkers.forEach(d => console.log(`    - ${d}`));
}
if (workersMissingSourceType.length) {
  console.log(`  ${workersMissingSourceType.length} worker(s) with no source taskDefinition (transformation defect — exec-BPMN must refine to a serviceTask and the job type is unverified):`);
  workersMissingSourceType.forEach(d => console.log(`    - ${d}`));
}

// ── helpers ──────────────────────────────────────────────────────────────
// Load the parser's per-phase output (<stem>.bpmn.json, written by SKILL.md
// step 1.3) as an id→element index. Returns null when absent so callers can
// fall back to the slice as authored.
function loadElementIndex(phase: string): Map<string, ParsedElement> | null {
  const p = path.join(SCRATCH, `${phase}.bpmn.json`);
  if (!fs.existsSync(p)) return null;
  const line = fs.readFileSync(p, 'utf8').trim();
  if (!line) return null;
  let rec: { elements?: ParsedElement[] };
  try {
    rec = JSON.parse(line) as { elements?: ParsedElement[] };
  } catch {
    return null;
  }
  const idx = new Map<string, ParsedElement>();
  for (const el of (rec.elements || [])) idx.set(el.id, el);
  return idx;
}

function pascal(s: string): string {
  return String(s).split(/[^A-Za-z0-9]+/).filter(Boolean)
    .map(w => (w[0] ?? '').toUpperCase() + w.slice(1)).join('');
}

// Worker class name from a job type. Strips a trailing "Worker" first so a
// source type that already ends in "-worker" (e.g. "case-platform-write-worker")
// yields "CasePlatformWriteWorker", not a doubled "…WorkerWorker".
function classNameFor(jobType: string): string {
  return pascal(jobType).replace(/Worker$/, '') + 'Worker';
}

function recordVar(groups: Map<string, VarEntry[]>, phase: string, v: Variable | undefined): void {
  if (!v || !v.name) return;
  if (!groups.has(v.name)) groups.set(v.name, []);
  groups.get(v.name)?.push({ phase, type: v.type, ref: v });
}

function uniq<T>(arr: T[]): T[] {
  return [...new Set(arr)];
}

function determineStructure(slices: Slice[], phases: string[]): Structure {
  if (phases.length <= 1) {
    return {
      type: 'single',
      reasoning: phases.length === 1 ? 'Single phase BPMN.' : 'No phases parsed.',
      phases,
    };
  }
  const handoffs: Handoff[] = [];
  for (let i = 0; i < slices.length - 1; i++) {
    const outs = collectVarNames(slices[i]?.workers || [], 'outputVariables');
    const ins = collectVarNames(slices[i + 1]?.workers || [], 'inputVariables');
    const shared = [...outs].filter(n => ins.has(n));
    handoffs.push({ from: slices[i]?.phase ?? '', to: slices[i + 1]?.phase ?? '', vars: shared });
  }
  const allHaveHandoff = handoffs.every(h => h.vars.length > 0);
  if (allHaveHandoff) {
    return {
      type: 'call-activities',
      reasoning: 'Each phase boundary has at least one variable output→input handoff.',
      phases,
      ioMapping: handoffs.map(h => ({ from: h.from, to: h.to, vars: h.vars })),
    };
  }
  return {
    type: 'single',
    reasoning: `Multiple phases (${phases.length}) but at least one boundary has no handoff variable; variable passing may need manual wiring.`,
    phases,
    handoffs,
  };
}

function collectVarNames(workers: Worker[], key: 'inputVariables' | 'outputVariables'): Set<string> {
  const out = new Set<string>();
  for (const w of workers) for (const v of (w[key] || [])) out.add(v.name);
  return out;
}
