#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Append lines to `.gitignore`, creating it if absent and never duplicating.
//
// Replaces the `if [[ ! -f "$GITIGNORE" ]]; then printf … > …; elif ! grep -Fxq
// …; then printf … >> …; fi` block `process-os-project-initialization` repeated
// three times, and the `existsSync(g) && !readFileSync(g).includes(e)` one-liner
// `process-os-artifact-generation` used for the same job. `[[ ]]`, `grep -Fxq`
// and the `printf` redirect are all unavailable or wrong in native PowerShell 5.1
// — `>` there writes UTF-16, which is not a `.gitignore` git can read.
//
// Usage:
//   node "append-gitignore.cjs" <line>...
//
// Matching is exact and whole-line, as `grep -Fxq` was: `.camunda/plugins/`
// does not count as already present because `.camunda/plugins/foo` is there.
//
// Idempotent by construction — running init twice adds nothing the second time.
// Prints one line per entry so a re-run visibly does nothing:
//   added    .camunda/plugins/
//   present  .camunda/governance.json
//
// Exit codes: 0 done, 2 usage error (no lines given).

const fs = require('fs');

const EXIT = { OK: 0, USAGE: 2 };

const GITIGNORE = '.gitignore';

/**
 * Append each missing line to the ignore file.
 *
 * @param {string[]} lines Entries to ensure are present.
 * @param {string} [file] Ignore file path.
 * @returns {{line: string, added: boolean}[]} One result per input line, in order.
 */
function appendLines(lines, file = GITIGNORE) {
  let existing = '';
  try {
    existing = fs.readFileSync(file, 'utf8');
  } catch {
    // Absent is the create case, not an error.
  }
  // Split on either ending so a CRLF .gitignore written by a Windows editor
  // still matches — otherwise every entry looks missing and gets re-appended.
  const present = new Set(existing.split(/\r?\n/));
  // Write back in the file's own style rather than the platform's: os.EOL would
  // append CRLF entries into an LF .gitignore on Windows, giving a committed
  // file mixed endings. A new file starts LF, as git conventionally stores it.
  const eol = existing.includes('\r\n') ? '\r\n' : '\n';
  const results = [];
  let out = existing;
  for (const line of lines) {
    if (present.has(line)) {
      results.push({ line, added: false });
      continue;
    }
    if (out && !out.endsWith('\n')) out += eol;
    out += `${line}${eol}`;
    present.add(line);
    results.push({ line, added: true });
  }
  if (results.some((r) => r.added)) fs.writeFileSync(file, out);
  return results;
}

module.exports = { EXIT, GITIGNORE, appendLines };

if (require.main === module) {
  const lines = process.argv.slice(2);
  if (lines.length === 0) {
    process.stderr.write('usage: append-gitignore.cjs <line>...\n');
    process.exit(EXIT.USAGE);
  }
  for (const { line, added } of appendLines(lines)) {
    process.stdout.write(`${(added ? 'added' : 'present').padEnd(8)} ${line}\n`);
  }
}
