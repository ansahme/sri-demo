#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Lint generated BPMN with the PROJECT `.bpmnlintrc`, one file per bpmnlint run.
//
// Replaces two bash blocks in SKILL.md: the `LINT_CMD=( … )` array plus
// `[ -f "$PARENT_FILE" ] && …` guard in §3.5, and the `LINT_RC=0; for f in …;
// do … || LINT_RC=1; done` sweep in §3.6. Bash arrays, `[ -f … ]`, `||` and
// shell glob expansion are all unavailable in native PowerShell 5.1.
//
// This deliberately does NOT call process-os-bpmn-linting's validate.cjs: that
// wrapper applies its own stricter config (recommended + the process-os plugin),
// while these steps lint against the project-root `.bpmnlintrc` written during
// setup. Same binary, different rule set — swapping them would change what
// passes, not just how it is invoked.
//
// Per file, never per directory: bpmnlint errors `EISDIR` on a directory
// argument, and one run over many files makes a single findings exit code stand
// for all of them.
//
// bpmnlint itself is resolved from `.camunda/node_modules` (where `c8 os install`
// puts the pinned version) and then the project root, both relative to the cwd.
// `npx --yes bpmnlint` is the fallback when neither has it. Callers pass no bin
// path.
//
// This script does not verify the cwd: run it from anywhere but the project root
// and it finds no pinned install and takes the npx path silently, unpinned.
// Callers are expected to run from the project root, which is where every agent
// session starts.
//
// Usage:
//   node "scripts/lint-processes.cjs" [--config <path>] [--skip-missing]
//                                     <file-or-dir>...
//
//   <file-or-dir>   A directory contributes its immediate `*.bpmn` children.
//   --config        bpmnlint config. Default `.bpmnlintrc` (project root).
//   --skip-missing  A named file that does not exist is skipped instead of being
//                   an error — for §3.5, where the parent BPMN only exists for a
//                   call-activities structure.
//
// Exit codes:
//   0  every file clean
//   1  lint findings — the offending files are named on stdout
//   2  usage error, a missing input without --skip-missing, nothing to lint, or
//      bpmnlint could not be started. In all of those the files were NOT linted,
//      so this must never be read as clean.

const fs = require('fs');
const path = require('path');
const { resolveNodeCliEntry, runNodeCli, runShellCli } = require(path.join(__dirname, 'resolve-node-cli.cjs'));

const EXIT = { CLEAN: 0, FINDINGS: 1, DID_NOT_RUN: 2 };

const DEFAULT_CONFIG = '.bpmnlintrc';

const USAGE =
  'usage: lint-processes.cjs [--config <path>] [--skip-missing] <file-or-dir>...\n';

/**
 * Parse argv into options.
 *
 * @param {string[]} argv Arguments after the script path.
 * @returns {{targets: string[], config: string, skipMissing: boolean}}
 * @throws {Error} On an unknown flag, a flag with no value, or no targets.
 */
function parseArgs(argv) {
  const targets = [];
  let config = DEFAULT_CONFIG;
  let skipMissing = false;
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--skip-missing') {
      skipMissing = true;
    } else if (arg === '--config') {
      // A flag with no value would otherwise swallow the first target.
      const value = argv[++i];
      if (value === undefined) throw new Error(`${arg} requires a value`);
      config = value;
    } else if (arg.startsWith('--')) {
      throw new Error(`unknown flag: ${arg}`);
    } else {
      targets.push(arg);
    }
  }
  if (targets.length === 0) throw new Error('at least one file or directory is required');
  return { targets, config, skipMissing };
}

/**
 * Expand targets into the BPMN files to lint.
 *
 * @param {string[]} targets Files and/or directories.
 * @param {boolean} skipMissing Tolerate a named file that is not there.
 * @returns {string[]} Files, de-duplicated and sorted.
 * @throws {Error} On a missing target when `skipMissing` is false.
 */
function collectFiles(targets, skipMissing) {
  const files = new Set();
  for (const target of targets) {
    let stat = null;
    try {
      stat = fs.statSync(target);
    } catch {
      // Absent.
    }
    if (!stat) {
      if (skipMissing) continue;
      throw new Error(`not found: ${target}`);
    }
    if (stat.isDirectory()) {
      for (const entry of fs.readdirSync(target)) {
        if (!entry.endsWith('.bpmn')) continue;
        const file = path.join(target, entry);
        if (fs.statSync(file).isFile()) files.add(file);
      }
    } else {
      files.add(target);
    }
  }
  return [...files].sort();
}

/**
 * Lint one file.
 *
 * @param {string} file
 * @param {object} opts
 * @param {string} opts.config bpmnlint config path.
 * @param {string|null} opts.entry bpmnlint's JS entry, or null for the npx fallback.
 * @returns {{launched: boolean, status: number}}
 */
function lintOne(file, { config, entry }) {
  const args = ['--config', config, file];
  // stdio inherit: bpmnlint's report is for the agent to read and act on. Unlike
  // process-os-bpmn-generation's per-file redirect, these files are small and
  // few, so the harness stdout buffer is not a concern here.
  const opts = { stdio: 'inherit' };
  const result = entry
    ? runNodeCli(entry, args, opts)
    // Zero-install fallback: npx exists only as a shell wrapper (npx.cmd on
    // Windows), hence runShellCli.
    : runShellCli('npx', ['--yes', 'bpmnlint', ...args], opts);
  return { launched: result.launched, status: result.status };
}

/**
 * Lint every file the targets resolve to.
 *
 * @param {ReturnType<typeof parseArgs>} options
 * @param {object} [deps]
 * @param {(file: string, opts: object) => {launched: boolean, status: number}} [deps.lint]
 *   Injectable single-file linter, for tests.
 * @param {(pkg: string, opts: object) => string|null} [deps.resolveEntry] Injectable
 *   resolver, for tests.
 * @returns {{lines: string[], exitCode: number}}
 */
function lintProcesses(options, deps = {}) {
  const { targets, config, skipMissing } = options;
  const lint = deps.lint || lintOne;
  const resolveEntry = deps.resolveEntry || resolveNodeCliEntry;

  let files;
  try {
    files = collectFiles(targets, skipMissing);
  } catch (err) {
    return { lines: [err.message], exitCode: EXIT.DID_NOT_RUN };
  }
  if (files.length === 0) {
    // With --skip-missing this is the legitimate "no parent BPMN for this
    // structure" case; without it, it means the caller pointed at an empty tree.
    return {
      lines: skipMissing ? ['nothing to lint'] : ['no .bpmn file among the given targets — nothing was linted'],
      exitCode: skipMissing ? EXIT.CLEAN : EXIT.DID_NOT_RUN,
    };
  }

  // Resolves the JS entry of the bpmnlint installed under .camunda/node_modules,
  // then the project root; null when neither has it (npx fallback in lintOne).
  const entry = resolveEntry('bpmnlint');

  const lines = [];
  let exitCode = EXIT.CLEAN;
  for (const file of files) {
    const { launched, status } = lint(file, { config, entry });
    if (!launched) {
      // Never folded into bpmnlint's own findings code: reported as exit 1 with
      // no output, a lint that never ran reads as a clean pass.
      lines.push(`LINT DID NOT RUN  ${file}`);
      exitCode = EXIT.DID_NOT_RUN;
      continue;
    }
    if (status !== EXIT.CLEAN) {
      lines.push(`findings  ${file}`);
      if (exitCode === EXIT.CLEAN) exitCode = EXIT.FINDINGS;
    }
  }
  if (exitCode === EXIT.FINDINGS) lines.push('consolidated lint found errors — fix before proceeding');
  if (exitCode === EXIT.CLEAN) lines.push(`clean  ${files.length} file(s)`);
  return { lines, exitCode };
}

module.exports = { EXIT, collectFiles, lintOne, lintProcesses, parseArgs };

if (require.main === module) {
  let options;
  try {
    options = parseArgs(process.argv.slice(2));
  } catch (err) {
    process.stderr.write(`lint-processes.cjs: ${err.message}\n${USAGE}`);
    process.exit(EXIT.DID_NOT_RUN);
  }
  const { lines, exitCode } = lintProcesses(options);
  process.stdout.write(`${lines.join('\n')}\n`);
  process.exit(exitCode);
}
