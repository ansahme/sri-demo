#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Run Maven in a project directory, preferring that project's wrapper.
//
// Replaces the `( cd process-implementation/artifacts && ./mvnw -B -q -DskipTests compile )` idiom.
// Three separate things break there on native Windows:
// the `cd X && Y` subshell chain, `./mvnw` (the POSIX wrapper script — Windows
// ships `mvnw.cmd` beside it), and a bare `mvn`, which exists only as `mvn.cmd`
// and so cannot be spawned without a shell.
//
// Both the wrapper and the PATH `mvn` fallback go through `runShellCli`, which
// applies a shell on Windows only. That matters for the wrapper too: Node
// refuses to spawn a `.cmd` without `shell: true` even when handed its absolute
// path, and the failure is an EINVAL that a caller could mistake for a build
// error rather than a build that never started.
//
// The working directory of the calling process is never changed: the project
// directory is passed to the child as its `cwd`.
//
// Usage:
//   node "run-maven.cjs" <project-dir> <goal-or-flag>...
//
// Maven's own output is inherited, and its exit code is this script's, so a
// caller gates on the build exactly as before.
//
// Exit codes:
//   0    the build succeeded
//   2    usage error, no Maven available, or Maven could not be started at all —
//        in none of those did a build run, so this is never a green build
//   else Maven's own exit code

const fs = require('fs');
const path = require('path');
const { findOnPath, runShellCli } = require('./resolve-node-cli.cjs');

const EXIT = { OK: 0, DID_NOT_RUN: 2 };

const USAGE = 'usage: run-maven.cjs <project-dir> <goal-or-flag>...\n';

/**
 * The wrapper script to use in `dir`, if the project ships one.
 *
 * Windows gets `mvnw.cmd`; everywhere else the POSIX `mvnw`. A project shipping
 * only one of the pair is respected as-is rather than guessed at.
 *
 * @param {string} dir Project directory.
 * @param {string} [platform] Overridable for tests.
 * @returns {string|null} Absolute path to the wrapper, or null.
 */
function wrapperIn(dir, platform = process.platform) {
  const name = platform === 'win32' ? 'mvnw.cmd' : 'mvnw';
  const candidate = path.resolve(dir, name);
  return fs.existsSync(candidate) ? candidate : null;
}

/**
 * Run Maven.
 *
 * @param {string} dir Project directory; becomes the child's cwd.
 * @param {string[]} args Goals and flags.
 * @param {object} [deps]
 * @param {typeof runShellCli} [deps.runShell] Injectable runner, for tests.
 * @param {typeof findOnPath} [deps.onPath] Injectable PATH probe, for tests.
 * @param {string} [deps.platform] Overridable platform, for tests.
 * @returns {{status: number, message: string|null, command: string}}
 */
function runMaven(dir, args, deps = {}) {
  const runShell = deps.runShell || runShellCli;
  const onPath = deps.onPath || findOnPath;
  const platform = deps.platform || process.platform;

  const wrapper = wrapperIn(dir, platform);
  // No wrapper: fall back to an installed mvn. Settling "is it on PATH" up front
  // keeps a real absence distinguishable from a shell's own failure exit.
  if (!wrapper && !onPath('mvn')) {
    return {
      status: EXIT.DID_NOT_RUN,
      message: `No Maven wrapper in ${dir} and no mvn on PATH — nothing was built.`,
      command: 'mvn',
    };
  }

  const command = wrapper || 'mvn';
  const result = runShell(command, args, { cwd: dir, stdio: 'inherit' });
  if (!result.launched) {
    return {
      status: EXIT.DID_NOT_RUN,
      message: `${command} could not be started: ${
        result.error ? result.error.message : 'no exit status'
      }`,
      command,
    };
  }
  return { status: result.status, message: null, command };
}

module.exports = { EXIT, runMaven, wrapperIn };

if (require.main === module) {
  const [dir, ...args] = process.argv.slice(2);
  if (!dir || args.length === 0) {
    process.stderr.write(USAGE);
    process.exit(EXIT.DID_NOT_RUN);
  }
  if (!fs.existsSync(dir)) {
    process.stderr.write(`Project directory not found: ${dir}\n`);
    process.exit(EXIT.DID_NOT_RUN);
  }
  const { status, message } = runMaven(dir, args);
  if (message) process.stderr.write(`${message}\n`);
  process.exit(status);
}
