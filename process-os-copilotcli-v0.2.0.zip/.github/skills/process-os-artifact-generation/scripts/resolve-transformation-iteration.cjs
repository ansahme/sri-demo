#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Picks which `process-transformation` ITERATION a caller should read or implement — never
// which tier, because a single project can run several iterations of the same or different
// tiers, and the iteration number is what tells them apart on disk now that the tier no longer
// appears in any path. `artifact-tier:` (the pre-single-tier config key) is deliberately never
// read here as a fallback: a tier does not name one of several iterations that generated it, so
// there is no sense in which it could stand in for `artifact-iteration:`.
//
// Usage:
//   node "resolve-transformation-iteration.cjs" detect
//   node "resolve-transformation-iteration.cjs" resolve [--iteration <N>]
//   node "resolve-transformation-iteration.cjs" tier    [--iteration <N>]
//   node "resolve-transformation-iteration.cjs" persist <N>
//
// detect   Prints JSON: one entry per completed iteration (`iteration`, `tier` — null when
//          that iteration has no manifest — and `executable`), plus `configIteration` (the
//          `artifact-iteration:` value in transformation.config.md, or null).
// resolve  Prints the target iteration's `artifacts/` path, `/`-separated. Precedence:
//          --iteration > transformation.config.md's `artifact-iteration:` > the last
//          completed iteration. An in-progress iteration (one holding `.in-progress`) is
//          never a candidate, whether as that fallback or as an explicit --iteration target —
//          the same filtered set of completed iterations backs every decision this script
//          makes, so an in-progress number is indistinguishable from one that never existed.
// tier     Same target-selection precedence as resolve, but prints that iteration's recorded
//          tier instead of its path, and does not require the target to have executable BPMN.
// persist  Writes `artifact-iteration: <N>` into transformation.config.md, collapsing any
//          pre-existing duplicate `artifact-iteration:` lines to the one just written.
//
// Exit codes:
//   0  resolved. `resolve` -> the artifacts/ path; `tier` -> the tier token; `detect` -> JSON;
//      `persist` -> nothing. All end with exactly one newline.
//   2  a usage error (bad flags, a missing command); an explicit or configured --iteration
//      that names no completed iteration; a resolve target with no executable BPMN; or
//      ProcessOS Node deps missing — never a "nothing to resolve" outcome, because in every
//      one of these cases a signal WAS given (or the project's own state could not be read),
//      it just could not be honored. Nothing on stdout.
//   3  nothing to resolve: no --iteration, no configured one, and no completed iteration to
//      fall back to. `resolve` prints `PROMPT_REQUIRED <json>` (the same shape `detect`
//      prints) on stdout; `tier` prints nothing.
//
// A present iteration.yaml that fails to parse, or parses but does not carry the field being
// read, is a different state from no iteration.yaml at all — "there but broken" is never
// folded into "not there" — so it takes the project-state failure path (exit 2) rather than
// NOTHING_TO_RESOLVE (exit 3) or a silently null tier.

const fs = require('node:fs');
const path = require('node:path');
// Sibling imports spelled so the bundler's dependency-closure grep sees a literal
// <shared dir>/<file> path. This file already lives in that directory, so the requires
// round-trip via '../..' purely to put that literal in the text: it resolves correctly
// in source, and once copied as a peer into a consuming skill's scripts/ dir the
// bundler strips the up-nav to path.join(__dirname, '<file>').
//
// Write that prefix ONLY inside these require() calls, where a real filename follows.
// The rewriter keys on <dir>/<name>.<ext>, so a bare prose mention of the directory
// survives into the bundled copy and trips bundler-compat.test.cjs.
const { listIterations } = require(path.join(__dirname, 'iteration-dir.cjs'));
const { readManifest } = require(path.join(__dirname, 'iteration-manifest.cjs'));

const EXIT = { OK: 0, USAGE: 2, NOTHING_TO_RESOLVE: 3 };
const PHASE = 'process-transformation';
const CONFIG = 'transformation.config.md';
// A task definition or a template binding proves a .bpmn came out of `automatable` mode. A
// `zeebe:calledElement` does not on its own: `strategic` keeps it as the structural link from a
// call activity to the process it calls. It counts only in a process marked isExecutable="true".
const ZEEBE_EXEC_RE = /<zeebe:taskDefinition\b|modelerTemplate=/;
// The opening tag must not be self-closing, or an empty process would swallow the next one's body.
const PROCESS_BLOCK_RE = /<bpmn:process\b([^>]*?)(?<!\/)>([\s\S]*?)<\/bpmn:process>/g;
const EXECUTABLE_ATTR_RE = /\bisExecutable\s*=\s*(?:"true"|'true')/;
// A landscape diagram: never executable, regardless of content.
const OVERVIEW_BPMN = '00-overview.bpmn';

/**
 * @param {string} xml
 * @returns {boolean}
 */
function carriesExecution(xml) {
  if (ZEEBE_EXEC_RE.test(xml)) return true;
  for (const [, attrs, body] of xml.matchAll(PROCESS_BLOCK_RE)) {
    if (EXECUTABLE_ATTR_RE.test(attrs) && /<zeebe:calledElement\b/.test(body)) return true;
  }
  return false;
}

const USAGE =
  'usage:\n' +
  '  resolve-transformation-iteration.cjs detect\n' +
  '  resolve-transformation-iteration.cjs resolve [--iteration <N>]\n' +
  '  resolve-transformation-iteration.cjs tier    [--iteration <N>]\n' +
  '  resolve-transformation-iteration.cjs persist <N>\n';

/**
 * @param {string} message
 * @param {'NOT_FOUND'|'NO_EXECUTABLE_BPMN'} code
 * @returns {Error}
 */
function taggedError(message, code) {
  const err = new Error(message);
  err.code = code;
  return err;
}

/**
 * @param {string} name A filename, not a path.
 * @returns {boolean} Whether `name` matches the executable-BPMN naming convention. Content is
 *   not considered here — see {@link isExecutable}.
 */
// The same document classes process-os-bpmn-generation generates from, so whatever it produced
// is whatever is recognised here. One-or-more digits rather than exactly two, and `subprocess-`
// included: both match the seed and flatten allowlists, and a stem those accept but this rejects
// would make a populated iteration report as holding no executable BPMN at all.
const EXECUTABLE_NAME_RE = /^(?:process-\d+-.*|edge-.*|subprocess-.*)\.bpmn$/;

function isExecutableName(name) {
  if (name === OVERVIEW_BPMN) return false;
  return EXECUTABLE_NAME_RE.test(name);
}

/**
 * @param {string} artifactsDir
 * @param {string} name A filename, not a path.
 * @returns {boolean} Whether `<artifactsDir>/<name>` is an executable BPMN: its name matches
 *   the convention AND it carries a Zeebe execution extension.
 */
function isExecutable(artifactsDir, name) {
  if (!isExecutableName(name)) return false;
  let txt;
  try {
    txt = fs.readFileSync(path.join(artifactsDir, name), 'utf8');
  } catch {
    return false;
  }
  return carriesExecution(txt);
}

/**
 * @param {string} artifactsDir
 * @returns {boolean} Whether any file directly under `artifactsDir` is executable BPMN.
 */
function hasExecutableBpmn(artifactsDir) {
  let names;
  try {
    names = fs.readdirSync(artifactsDir);
  } catch {
    return false;
  }
  return names.some((n) => isExecutable(artifactsDir, n));
}

/**
 * @returns {number|null} The `artifact-iteration:` value recorded in transformation.config.md,
 *   or null when the file is missing, unreadable, carries no such line, or that line's value
 *   is not an integer. Absent or unparseable config is not an error: both the config's own
 *   creation and every earlier phase legitimately run before it exists.
 */
function readConfigIteration() {
  let txt;
  try {
    txt = fs.readFileSync(path.join(process.cwd(), CONFIG), 'utf8');
  } catch {
    return null;
  }
  const m = txt.match(/^\s*artifact-iteration:\s*(\S+)\s*$/m);
  if (!m) return null;
  const n = Number(m[1]);
  return Number.isInteger(n) ? n : null;
}

/**
 * @returns {{iteration: number, tier: string|null, executable: boolean}[]} One entry per
 *   completed (non-in-progress) `process-transformation` iteration, lowest first.
 * @throws {Error} Untagged `DEPS_MISSING` when `yaml.cjs` cannot resolve the `yaml` package;
 *   untagged `INVALID`-carrying (from iteration-manifest.cjs) when a present iteration.yaml
 *   fails to parse. Both propagate rather than reading as "no manifest" for that entry.
 */
function completedEntries() {
  return listIterations(PHASE).filter((e) => !e.inProgress);
}

/**
 * @param {{artifacts: string}} entry
 * @returns {string|null} That iteration's recorded tier, or null when it has no manifest.
 * @throws {Error} Propagated as-is when `readManifest` reports anything other than `MISSING`
 *   (a broken manifest is a different state from an absent one, and must not read as either).
 */
function tierOf(entry) {
  let manifest;
  try {
    manifest = readManifest(entry.artifacts);
  } catch (err) {
    if (err.code === 'MISSING') return null;
    throw err;
  }
  if (!Object.hasOwn(manifest, 'tier')) {
    throw taggedError(`${entry.artifacts} iteration.yaml carries no tier field`, 'INVALID');
  }
  // Present is not the same as usable. A hand-edited manifest can carry `tier:` with no value, a
  // list, or a map; each parses fine and none names a tier. Reporting any of them as the tier
  // would print a non-tier value to a caller interpolating it, and treating them as absent would
  // call a broken manifest an unwritten one.
  const tier = manifest.tier;
  if (typeof tier !== 'string' || tier.trim() === '') {
    throw taggedError(
      `${entry.artifacts} iteration.yaml's tier is not a non-empty string`,
      'INVALID',
    );
  }
  return tier;
}

/**
 * @returns {{iterations: {iteration: number, tier: string|null, executable: boolean}[], configIteration: number|null}}
 */
function detect() {
  const iterations = completedEntries().map((e) => ({
    iteration: e.iteration,
    tier: tierOf(e),
    executable: hasExecutableBpmn(e.artifacts),
  }));
  return { iterations, configIteration: readConfigIteration() };
}

/**
 * Choose the completed iteration a caller should act on.
 *
 * @param {number|null} argIteration From --iteration; takes precedence over everything.
 * @returns {{iteration: number, dir: string, artifacts: string, feedback: string}|null} `null`
 *   means nothing to resolve — no signal was given at all, and there is no completed iteration
 *   to fall back to.
 * @throws {Error} Tagged `NOT_FOUND` when --iteration, or the configured `artifact-iteration:`,
 *   names a number with no matching completed entry.
 */
function pickTarget(argIteration) {
  const entries = completedEntries();
  const find = (n) => entries.find((e) => e.iteration === n);

  if (argIteration !== null) {
    const found = find(argIteration);
    if (!found) throw taggedError(`no completed iteration ${argIteration} under ${PHASE}/`, 'NOT_FOUND');
    return found;
  }

  const configIteration = readConfigIteration();
  if (configIteration !== null) {
    const found = find(configIteration);
    if (!found) {
      throw taggedError(
        `${CONFIG}'s artifact-iteration: ${configIteration} names no completed iteration under ${PHASE}/`,
        'NOT_FOUND',
      );
    }
    return found;
  }

  if (entries.length === 0) return null;
  return entries[entries.length - 1];
}

/**
 * @param {string[]} argv Arguments after `resolve` or `tier`.
 * @returns {number|null|undefined} The parsed --iteration value, null when not given, or
 *   undefined on a usage error (an unknown flag, a flag with no value, or a non-integer value).
 */
function parseIterationFlag(argv) {
  let iteration = null;
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--iteration') {
      const value = argv[i + 1];
      if (value === undefined) return undefined;
      // An empty value means the caller passed the flag with nothing to put in it — skill prose
      // interpolates `--iteration "<ITERATION_ARG>"` whether or not the user supplied one. Read
      // it as omitted, so resolution falls through to the configured iteration and then the last
      // completed one. `Number('')` is 0, which would otherwise become an explicit request for
      // an iteration that cannot exist.
      if (value.trim() === '') {
        i++;
        continue;
      }
      const n = Number(value);
      if (!Number.isInteger(n)) return undefined;
      iteration = n;
      i++;
    } else {
      return undefined;
    }
  }
  return iteration;
}

/**
 * @param {string} rawIteration
 */
function persist(rawIteration) {
  const n = Number(rawIteration);
  if (!Number.isInteger(n) || n < 1) {
    process.stderr.write(`invalid iteration: ${rawIteration}\n`);
    process.exit(EXIT.USAGE);
  }
  const p = path.join(process.cwd(), CONFIG);
  let txt = '';
  try {
    txt = fs.readFileSync(p, 'utf8');
  } catch {
    txt = '# Transformation Config\n';
  }
  // Strip every existing artifact-iteration line (not just the first) so a file with
  // duplicate keys (manual edit, merge conflict) converges on a single authoritative value.
  txt = txt.replace(/^\s*artifact-iteration:.*\n?/gm, '');
  if (!txt.endsWith('\n')) txt += '\n';
  txt += `artifact-iteration: ${n}\n`;
  fs.writeFileSync(p, txt);
}

/**
 * Exit 2 on `DEPS_MISSING` or `NOT_FOUND`; rethrow anything else (including a bare `INVALID`
 * from {@link tierOf}, which reports as exit 2 too — a broken manifest is a project-state
 * failure, not a usage mistake, but this script has no code of its own to spend on that
 * distinction and 2 is the only one of its three that fits a signal that could not be honored).
 *
 * @param {Error} err
 */
function exitOnProjectStateError(err) {
  if (err.code === 'DEPS_MISSING' || err.code === 'NOT_FOUND' || err.code === 'INVALID') {
    process.stderr.write(`${err.message}\n`);
    process.exit(EXIT.USAGE);
  }
  throw err;
}

/**
 * @param {string[]} argv `process.argv.slice(2)`.
 */
function main(argv) {
  const [cmd, ...rest] = argv;

  if (cmd === 'detect') {
    let result;
    try {
      result = detect();
    } catch (err) {
      exitOnProjectStateError(err);
      return;
    }
    process.stdout.write(`${JSON.stringify(result)}\n`);
    process.exit(EXIT.OK);
  }

  if (cmd === 'resolve' || cmd === 'tier') {
    const argIteration = parseIterationFlag(rest);
    if (argIteration === undefined) {
      process.stderr.write(USAGE);
      process.exit(EXIT.USAGE);
    }

    let target;
    try {
      target = pickTarget(argIteration);
    } catch (err) {
      exitOnProjectStateError(err);
      return;
    }

    if (target === null) {
      if (cmd === 'tier') process.exit(EXIT.NOTHING_TO_RESOLVE);
      let result;
      try {
        result = detect();
      } catch (err) {
        exitOnProjectStateError(err);
        return;
      }
      process.stdout.write(`PROMPT_REQUIRED ${JSON.stringify(result)}\n`);
      process.exit(EXIT.NOTHING_TO_RESOLVE);
    }

    if (cmd === 'tier') {
      let tier;
      try {
        tier = tierOf(target);
      } catch (err) {
        exitOnProjectStateError(err);
        return;
      }
      if (tier === null) process.exit(EXIT.NOTHING_TO_RESOLVE);
      process.stdout.write(`${tier}\n`);
      process.exit(EXIT.OK);
    }

    // resolve: the target must have executable BPMN, or there is nothing to hand the caller.
    if (!hasExecutableBpmn(target.artifacts)) {
      process.stderr.write(`iteration ${target.iteration} has no executable BPMN under ${target.artifacts}\n`);
      process.exit(EXIT.USAGE);
    }
    process.stdout.write(`${target.artifacts}\n`);
    process.exit(EXIT.OK);
  }

  if (cmd === 'persist') {
    persist(rest[0] ?? '');
    process.exit(EXIT.OK);
  }

  process.stderr.write(USAGE);
  process.exit(EXIT.USAGE);
}

module.exports = { EXIT };

if (require.main === module) main(process.argv.slice(2));
