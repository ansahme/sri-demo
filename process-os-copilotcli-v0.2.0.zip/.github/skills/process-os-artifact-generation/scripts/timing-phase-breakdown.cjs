#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Reads $TIMING_DIR/orchestrator.json and prints a per-phase wall table.
//
// Companion to scripts/timing.cjs's per-record aggregate. The aggregate
// shows one duration_s per record; this helper splits the orchestrator
// record's wall into the four phases and the named sub-step boundaries
// emitted by SKILL.md.
//
// Usage:
//   node scripts/timing-phase-breakdown.cjs <timing-dir>
//
// TIMING_DIR is read as a fallback only when no positional arg is given —
// kept for existing callers, but the `VAR=value cmd` env-prefix form some of
// them still use is a PowerShell 5.1 parse error; always prefer the
// positional argument above.
//
// Output: a small table listing phase, segment, dt(s) since previous event,
// and cumulative dt(s) since phase_1_start. Missing events become "—" and
// produce a clear footnote.
//
// Exit codes: 0 always (warnings are surfaced inline); 2 if no record found.

'use strict';

const fs = require('fs');
const path = require('path');

const TIMING_DIR = process.argv[2]
  || process.env.TIMING_DIR
  || path.join(process.cwd(), '.camunda', 'timing');

const RECORD_PATH = path.join(TIMING_DIR, 'orchestrator.json');

if (!fs.existsSync(RECORD_PATH)) {
  console.error(`timing-phase-breakdown: missing ${RECORD_PATH}`);
  console.error('  Run /artifact-generate end-to-end first; the orchestrator emits 22 events + end.');
  process.exit(2);
}

const rec = JSON.parse(fs.readFileSync(RECORD_PATH, 'utf8'));
const events = rec.events || [];

// First-occurrence dt lookup (skip duplicates if any).
const seen = new Map();
for (const e of events) if (!seen.has(e.name)) seen.set(e.name, e.dt_ms);

// Phase segment definitions. Each row: [phase label, segment label, from event, to event].
const segments = [
  ['Phase 1', 'setup',          'phase_1_start',              'phase_1_setup_done'],
  ['Phase 1', 'metadata',       'phase_1_setup_done',         'phase_1_metadata_done'],
  ['Phase 1', 'parse',          'phase_1_metadata_done',      'phase_1_parse_done'],
  ['Phase 1', 'fanout dispatch','phase_1_parse_done',         'phase_1_fanout_dispatched'],
  ['Phase 1', 'fanout wall',    'phase_1_fanout_dispatched',  'phase_1_fanout_complete'],
  ['Phase 1', 'join script',    'phase_1_fanout_complete',    'phase_1_join_done'],
  ['Phase 1', 'proposal script','phase_1_join_done',          'phase_1_proposal_done'],
  ['Phase 1', 'cleanup',        'phase_1_proposal_done',      'phase_1_cleanup_done'],
  ['Phase 2', 'review wall*',   'phase_2_review_started',     'phase_2_approved'],
  ['Phase 3', 'pre-dispatch',   'phase_3_start',                  'phase_3_agents_dispatched'],
  ['Phase 3', 'agents wall',    'phase_3_agents_dispatched',      'phase_3_agents_complete'],
  ['Phase 3', 'parent BPMN',    'phase_3_agents_complete',        'phase_3_parent_bpmn_done'],
  ['Phase 3', 'consol. lint',   'phase_3_parent_bpmn_done',       'phase_3_consolidated_lint_done'],
  ['Phase 3', 'icon sweep',     'phase_3_consolidated_lint_done', 'phase_3_icon_sweep_done'],
  ['Phase 3', 'aggregate',      'phase_3_icon_sweep_done',        'phase_3_aggregate_done'],
  ['Phase 3', 'audit',          'phase_3_aggregate_done',         'phase_3_audit_done'],
  ['Phase 3', 'build gate',     'phase_3_audit_done',             'phase_3_build_gate_done'],
  ['Phase 4', 'state update',   'phase_4_start',              'phase_4_state_updated'],
  ['Phase 4', 'audit append',   'phase_4_state_updated',      'phase_4_audit_appended'],
  ['Phase 4', 'memory write',   'phase_4_audit_appended',     'phase_4_memory_done'],
];

// Phase totals: from first event of phase to last event of phase.
const phaseRanges = {
  'Phase 1': ['phase_1_start',         'phase_1_cleanup_done'],
  'Phase 2': ['phase_2_review_started','phase_2_approved'],
  'Phase 3': ['phase_3_start',         'phase_3_build_gate_done'],
  'Phase 4': ['phase_4_start',         'phase_4_memory_done'],
};

const fmt = ms => (ms == null) ? '—' : (ms / 1000).toFixed(1).padStart(6) + ' s';

function dt(from, to) {
  const a = seen.get(from);
  const b = seen.get(to);
  if (a == null || b == null) return null;
  return b - a;
}

const missing = [];
for (const seg of segments) {
  const [, , from, to] = seg;
  if (!seen.has(from)) missing.push(from);
  if (!seen.has(to)) missing.push(to);
}
const missingUniq = [...new Set(missing)];

const pad = (s, n) => String(s).padEnd(n);

console.log('');
console.log('Orchestrator phase breakdown');
console.log('  record:   ' + RECORD_PATH);
console.log('  start:    ' + (rec.start_iso || '—'));
console.log('  end:      ' + (rec.end_iso   || '— (record not finalized; run timing.cjs end orchestrator)'));
console.log('  duration: ' + fmt(rec.duration_ms));
console.log('');
console.log(pad('phase', 9), pad('segment', 20), pad('dt', 10), pad('cum from phase_1_start', 24));
console.log('-'.repeat(67));

let lastPhase = null;
for (const [phase, segName, from, to] of segments) {
  if (phase !== lastPhase) {
    const [pStart, pEnd] = phaseRanges[phase];
    const phaseDt = dt(pStart, pEnd);
    const cum = seen.has(pEnd) ? seen.get(pEnd) : null;
    console.log(pad(phase, 9), pad('— total —', 20), pad(fmt(phaseDt), 10), pad(fmt(cum), 24));
    lastPhase = phase;
  }
  const segDt = dt(from, to);
  const cum = seen.has(to) ? seen.get(to) : null;
  console.log(pad('', 9), pad('  ' + segName, 20), pad(fmt(segDt), 10), pad(fmt(cum), 24));
}

console.log('');
if (missingUniq.length > 0) {
  console.log('warning: ' + missingUniq.length + ' expected event(s) missing from orchestrator.json:');
  for (const m of missingUniq) console.log('  - ' + m);
  console.log('  Segments touching them are reported as "—". Likely cause: the orchestrator skipped the emit, or the run aborted mid-phase.');
} else {
  console.log('all 24 phase-boundary events present');
}
console.log('');
console.log('* Phase 2 review wall is human-paced; subtract from total to get the automation cost.');
