#!/usr/bin/env node
// Generate the parent main-<slug>.bpmn for a call-activities artifact with
// bpmnkit. Linear topology: startEvent -> callActivity(phase-01) ->
// callActivity(phase-02) -> ... -> endEvent.
//
// Usage:
//   node scripts/generate-parent-bpmn.ts [<artifactRoot>]    (default: "process-implementation/artifacts")
//
// Reads:  <root>/.manifest.json
//         <root>/src/main/resources/processes/<phase>.bpmn
// Writes: <root>/src/main/resources/processes/main-<slug>.bpmn
//
// Exit codes: 0 success or no-op; 2 invalid inputs or generation failure.

import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import * as path from 'node:path';
import { pathToFileURL } from 'node:url';

interface IoMapping {
  from: string;
  vars?: string[];
}

interface Manifest {
  meta?: {
    processSlug?: string;
    processCamel?: string;
  };
  structure?: {
    type?: string;
    phases?: string[];
    ioMapping?: IoMapping[];
  };
}

interface PhaseSpec {
  id: string;
  stem: string;
  processId: string;
  inputs: string[];
  outputs: string[];
}

interface FlowSpec {
  id: string;
  sourceRef: string;
  targetRef: string;
}

async function main(): Promise<void> {
  const artifactRoot = path.resolve(process.argv[2] ?? 'process-implementation/artifacts');
  const manifestPath = path.join(artifactRoot, '.manifest.json');

  if (!existsSync(manifestPath)) {
    throw new Error(`generate-parent-bpmn: missing ${manifestPath}`);
  }

  const manifest = JSON.parse(readFileSync(manifestPath, 'utf8')) as Manifest;
  if (manifest.structure?.type !== 'call-activities') {
    console.log('generate-parent-bpmn: structure.type != "call-activities" — no parent process needed.');
    return;
  }

  const slug = manifest.meta?.processSlug ?? 'process';
  const processCamel = manifest.meta?.processCamel ?? 'Process';
  const phases = manifest.structure.phases ?? [];
  const ioMapping = manifest.structure.ioMapping ?? [];
  const processesDir = path.join(artifactRoot, 'src', 'main', 'resources', 'processes');
  const outputPath = path.join(processesDir, `main-${slug}.bpmn`);

  if (phases.length === 0) {
    throw new Error('generate-parent-bpmn: structure.type == "call-activities" but no phases listed.');
  }
  if (!existsSync(processesDir)) {
    throw new Error(`generate-parent-bpmn: ${processesDir} does not exist — phase BPMNs must be generated before this script runs.`);
  }

  const bpmnkitEntry = path.join(
    process.cwd(),
    '.camunda',
    'node_modules',
    '@bpmnkit',
    'core',
    'dist',
    'index.js',
  );
  if (!existsSync(bpmnkitEntry)) {
    throw new Error(`ProcessOS runtime dep missing: @bpmnkit/core at ${bpmnkitEntry}. Run \`c8 os update\` — or \`c8 os install <target>\` (e.g. claudecode) if ProcessOS is not installed here.`);
  }

  const { Bpmn, zeebeExtensionsToXmlElements } = await import(pathToFileURL(bpmnkitEntry).href);
  const childProcessIds = phases.map((stem) => childProcessId(processesDir, stem));
  const ioByFrom = new Map(ioMapping.map((mapping) => [mapping.from, mapping.vars ?? []]));
  const callActivityId = (index: number): string => `ca-${phases[index]}`;
  const phaseSpecs: PhaseSpec[] = phases.map((stem, index) => ({
    id: callActivityId(index),
    stem,
    processId: childProcessIds[index],
    inputs: index === 0 ? [] : (ioByFrom.get(phases[index - 1]) ?? []),
    outputs: ioByFrom.get(stem) ?? [],
  }));
  const flowSpecs: FlowSpec[] = [
    { id: `sf-start-${callActivityId(0)}`, sourceRef: 'StartEvent_Main', targetRef: callActivityId(0) },
    ...phases.slice(0, -1).map((_, index) => ({
      id: `sf-${callActivityId(index)}-${callActivityId(index + 1)}`,
      sourceRef: callActivityId(index),
      targetRef: callActivityId(index + 1),
    })),
    { id: `sf-${callActivityId(phases.length - 1)}-end`, sourceRef: callActivityId(phases.length - 1), targetRef: 'EndEvent_Main' },
  ];

  const builder = Bpmn.createProcess(`Main${processCamel}Process`)
    .name(`Main ${processCamel}`)
    .startEvent('StartEvent_Main', { name: 'Start' });

  for (const phase of phaseSpecs) {
    builder.callActivity(phase.id, {
      name: phase.stem,
      processId: phase.processId,
      propagateAllChildVariables: false,
    });
  }

  const definitions = builder
    .endEvent('EndEvent_Main', { name: 'End' })
    .executable(true)
    .executionPlatformVersion('8.9.0')
    .withAutoLayout()
    .build();
  const bpmnProcess = definitions.processes[0];

  for (const phase of phaseSpecs) {
    if (phase.inputs.length === 0 && phase.outputs.length === 0) continue;
    const activity = bpmnProcess.flowElements.find((element) => element.id === phase.id);
    if (!activity) throw new Error(`generate-parent-bpmn: missing call activity ${phase.id}`);
    activity.extensionElements.push(...zeebeExtensionsToXmlElements({
      ioMapping: {
        inputs: phase.inputs.map((name) => ({ source: `=${name}`, target: name })),
        outputs: phase.outputs.map((name) => ({ source: `=${name}`, target: name })),
      },
    }));
  }

  const flowIdByGeneratedId = new Map<string, string>();
  for (const flow of bpmnProcess.sequenceFlows) {
    const expected = flowSpecs.find((spec) =>
      spec.sourceRef === flow.sourceRef && spec.targetRef === flow.targetRef,
    );
    if (!expected) {
      throw new Error(`generate-parent-bpmn: unexpected sequence flow ${flow.sourceRef} -> ${flow.targetRef}`);
    }
    flowIdByGeneratedId.set(flow.id, expected.id);
    flow.id = expected.id;
  }

  for (const element of bpmnProcess.flowElements) {
    element.incoming = element.incoming.map((id) => flowIdByGeneratedId.get(id) ?? id);
    element.outgoing = element.outgoing.map((id) => flowIdByGeneratedId.get(id) ?? id);
  }

  for (const diagram of definitions.diagrams) {
    for (const edge of diagram.plane.edges) {
      const stableFlowId = flowIdByGeneratedId.get(edge.bpmnElement);
      if (!stableFlowId) continue;
      edge.bpmnElement = stableFlowId;
      edge.id = `${stableFlowId}_di`;
    }
  }

  writeFileSync(outputPath, Bpmn.export(definitions));
  console.log(`generate-parent-bpmn: wrote ${outputPath}`);
}

function childProcessId(processesDir: string, stem: string): string {
  const phasePath = path.join(processesDir, `${stem}.bpmn`);
  if (!existsSync(phasePath)) {
    throw new Error(`generate-parent-bpmn: missing phase BPMN ${phasePath}`);
  }
  const xml = readFileSync(phasePath, 'utf8');
  const match = xml.match(/<bpmn:process\b[^>]*\bid="([^"]+)"/);
  if (!match) {
    throw new Error(`generate-parent-bpmn: ${phasePath} has no <bpmn:process id="...">`);
  }
  return match[1];
}

try {
  await main();
} catch (error) {
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(2);
}
