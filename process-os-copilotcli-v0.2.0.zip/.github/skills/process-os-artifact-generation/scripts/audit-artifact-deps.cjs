#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Cross-checks the process-os-artifact-generation Phase 3 outputs for implicit dependencies
// that span the 4 parallel agents:
//
//   1. Each manifest.workers[].jobType is implemented by the target SDK's worker
//      code — for java-spring-boot a *Worker.java carrying @JobWorker(type=…);
//      for typescript a src/workers/*.ts setting jobType AND a src/app.ts entry
//      registering it. An SDK with no worker generator reports a named skip.
//      Which branch runs comes from scripts/sdk-capabilities.cjs, not from a
//      conditional on the SDK string.
//   2. Each manifest.forms[].formId     → forms/<formId>.form (with matching id field)
//   3. Each manifest.decisions[].decisionId → some decisions/*.dmn containing <decision id="...">
//   4. Every BPMN reference in process-implementation/artifacts/src/main/resources/processes/*.bpmn
//      (formDefinition formId, calledDecision decisionId, non-connector taskDefinition type)
//      must point at an entry that the manifest declared.
//
// Connector-typed taskDefinitions (e.g. type="io.camunda:slack:1") are recognised
// by the colon and skipped — those are wired by element templates, not by workers.
//
// Also (the reverse of #4): every manifest workers/forms/decisions wiring must
// actually land on its target element in processes/*.bpmn — the target element
// carries the taskDefinition / formDefinition / calledDecision it declares. This
// folds in the former verify-execution-bpmn.cjs self-check: with wiring now
// deterministic (wire-execution-bpmn.mts), that check stops being an LLM-omission
// gate and becomes an independent regression tripwire, which belongs here beside
// the other manifest↔BPMN cross-checks rather than in a separate per-phase script.
//
// Exits 0 on PASS (no errors), 1 on FAIL (at least one mismatch).
//
// Usage:
//   node scripts/audit-artifact-deps.cjs [<artifactRoot>]
//
// <artifactRoot> defaults to "process-implementation/artifacts" relative to cwd.

const fs = require('fs');
const path = require('path');

const ROOT = process.argv[2] || 'process-implementation/artifacts';
const MANIFEST = path.join(ROOT, '.manifest.json');

if (!fs.existsSync(MANIFEST)) {
  console.error(`audit: missing ${MANIFEST}`);
  process.exit(2);
}

const manifest = JSON.parse(fs.readFileSync(MANIFEST, 'utf8'));
const errors = [];
const notes = [];

// The worker check's shape comes from the capability table, not from a
// conditional on the SDK string. An absent meta.targetSdk is the documented
// "not there" state and defaults to java-spring-boot (the same convention
// scaffold-workers.cjs:118 applies); a manifest that NAMES an SDK the table does
// not know is "there but broken" and fails.
const { fromManifest } = require('./sdk-capabilities.cjs');
let targetSdk = null;
let caps = null;
try {
  ({ sdk: targetSdk, row: caps } = fromManifest(ROOT));
} catch (e) {
  errors.push(`${e.message}`);
}

const escape = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

function walk(dir, suffix, out) {
  if (!fs.existsSync(dir)) return;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, suffix, out);
    else if (e.name.endsWith(suffix)) out.push(p);
  }
}

// --- 1. Workers (per SDK, from the capability table) ---
const uniqueJobTypes = [...new Set((manifest.workers || []).map((w) => w.jobType).filter(Boolean))];

if (caps && caps.dependencyAuditProbe === 'java') {
  const workerFiles = [];
  walk(path.join(ROOT, 'src', 'main', 'java'), 'Worker.java', workerFiles);
  const workerSrc = workerFiles.map(f => ({ file: f, src: fs.readFileSync(f, 'utf8') }));

  for (const w of (manifest.workers || [])) {
    const re = new RegExp(`@JobWorker\\([^)]*\\btype\\s*=\\s*"${escape(w.jobType)}"`);
    if (!workerSrc.some(ws => re.test(ws.src))) {
      errors.push(`worker missing: jobType="${w.jobType}" (no *Worker.java has @JobWorker(type = "${w.jobType}"))`);
    }
  }
} else if (caps && caps.dependencyAuditProbe === 'typescript') {
  const workerFiles = [];
  walk(path.join(ROOT, 'src', 'workers'), '.ts', workerFiles);
  const workerSrc = workerFiles.map(f => ({ file: f, src: fs.readFileSync(f, 'utf8') }));

  // The registration probe has no Java counterpart because Java workers
  // self-register through an annotation. A declared but unregistered TypeScript
  // worker leaves the process instance stalled on that task with no subscriber.
  const appPath = path.join(ROOT, 'src', 'app.ts');
  const appSrc = fs.existsSync(appPath) ? fs.readFileSync(appPath, 'utf8') : null;
  if (appSrc === null) {
    errors.push(`worker registry missing: ${appPath} not found (nothing registers any worker)`);
  }

  for (const jobType of uniqueJobTypes) {
    const setsType = new RegExp(`jobType:\\s*"${escape(jobType)}"`);
    if (!workerSrc.some(ws => setsType.test(ws.src))) {
      errors.push(`worker missing: jobType="${jobType}" (no src/workers/*.ts sets jobType: "${jobType}")`);
    }
    const registered = new RegExp(`"${escape(jobType)}"\\s*:|\\["${escape(jobType)}"\\]\\s*:`);
    if (appSrc !== null && !registered.test(appSrc)) {
      errors.push(`worker not registered: jobType="${jobType}" (src/app.ts registers no worker under "${jobType}")`);
    }
  }
} else if (caps && caps.dependencyAuditProbe === 'python') {
  // The Python probe lives in its own module: it carries eleven rules where the
  // other two carry two, and a pure function over already-read sources is what
  // lets each rule have a unit test.
  const { auditPythonWorkers } = require('./python-worker-audit.cjs');
  const { toPyPackageName } = require('./python-naming.cjs');
  // The scaffolder renames the blueprint's src/ to the slug-derived package, and
  // the generator writes into that package. Reading a fixed src/ finds an empty
  // tree and reports every worker missing on a bundle that is in fact correct.
  const pyPackage = toPyPackageName(manifest.meta && manifest.meta.processSlug) || 'src';
  const workerDir = path.join(ROOT, pyPackage, 'workers');
  const workerPaths = [];
  walk(workerDir, '_worker.py', workerPaths);
  const appPath = path.join(ROOT, pyPackage, 'app.py');
  const result = auditPythonWorkers({
    jobTypes: uniqueJobTypes,
    workerFiles: workerPaths.map((f) => ({ name: path.basename(f), src: fs.readFileSync(f, 'utf8') })),
    appSrc: fs.existsSync(appPath) ? fs.readFileSync(appPath, 'utf8') : null,
    pyPackage,
  });
  errors.push(...result.errors);
  notes.push(...result.notes);
} else if (caps) {
  // A reported capability gap, never a silent pass and never a hard stop.
  notes.push(`worker check: skipped — SDK '${targetSdk}' has no worker generator, so no worker code is expected`);
}

// --- 2. Forms ---
for (const f of (manifest.forms || [])) {
  const fp = path.join(ROOT, 'src', 'main', 'resources', 'forms', f.formId + '.form');
  if (!fs.existsSync(fp)) {
    errors.push(`form missing: ${fp}`);
    continue;
  }
  let j;
  try { j = JSON.parse(fs.readFileSync(fp, 'utf8')); }
  catch (e) { errors.push(`form unparseable: ${fp} (${e.message})`); continue; }
  if (j.id !== f.formId) {
    errors.push(`form id mismatch: ${fp} declares id="${j.id}", expected "${f.formId}"`);
  }
}

// --- 3. Decisions ---
const dmnFiles = [];
walk(path.join(ROOT, 'src', 'main', 'resources', 'decisions'), '.dmn', dmnFiles);
const dmnSrc = dmnFiles.map(f => ({ file: f, src: fs.readFileSync(f, 'utf8') }));

for (const d of (manifest.decisions || [])) {
  const re = new RegExp(`<decision\\b[^>]*\\bid="${escape(d.decisionId)}"`);
  if (!dmnSrc.some(ds => re.test(ds.src))) {
    errors.push(`decision missing: decisionId="${d.decisionId}" (no .dmn contains <decision id="${d.decisionId}">)`);
  }
}

// --- 4. BPMN-side references must point at manifest entries ---
const bpmnFiles = [];
walk(path.join(ROOT, 'src', 'main', 'resources', 'processes'), '.bpmn', bpmnFiles);

const formIds = new Set((manifest.forms || []).map(f => f.formId));
const decisionIds = new Set((manifest.decisions || []).map(d => d.decisionId));
const jobTypes = new Set((manifest.workers || []).map(w => w.jobType));

for (const bf of bpmnFiles) {
  const xml = fs.readFileSync(bf, 'utf8');
  const base = path.basename(bf);
  for (const m of xml.matchAll(/<zeebe:formDefinition\b[^>]*\bformId="([^"]+)"/g)) {
    if (!formIds.has(m[1])) errors.push(`${base}: formId="${m[1]}" not declared in manifest.forms`);
  }
  for (const m of xml.matchAll(/<zeebe:calledDecision\b[^>]*\bdecisionId="([^"]+)"/g)) {
    if (!decisionIds.has(m[1])) errors.push(`${base}: decisionId="${m[1]}" not declared in manifest.decisions`);
  }
  for (const m of xml.matchAll(/<zeebe:taskDefinition\b[^>]*\btype="([^"]+)"/g)) {
    if (m[1].includes(':')) continue; // connector type, not a worker
    if (!jobTypes.has(m[1])) errors.push(`${base}: jobType="${m[1]}" not declared in manifest.workers`);
  }
}

// --- 5. Each manifest.messageSubscriptions[] entry has matching wiring ---
// Per phase, find the BPMN that should carry the wiring (one phase BPMN per
// messageSubscription.phase). The wiring is two-fold: the named <bpmn:message>
// must exist AND must declare <zeebe:subscription correlationKey=...>.
function bpmnForPhase(phase) {
  const fn = path.join(ROOT, 'src', 'main', 'resources', 'processes', phase + '.bpmn');
  return fs.existsSync(fn) ? fs.readFileSync(fn, 'utf8') : null;
}

for (const sub of (manifest.messageSubscriptions || [])) {
  const phase = sub.phase;
  const xml = bpmnForPhase(phase);
  if (!xml) {
    errors.push(`messageSubscription on ${sub.elementId}: ${phase}.bpmn not found in processes/`);
    continue;
  }
  // Find the <bpmn:message id="<messageRef>"> — match either self-closing
  // (`<bpmn:message id="X" />`) or paired (`<bpmn:message id="X">…</bpmn:message>`).
  const msgRe = new RegExp(
    `<bpmn:message\\b[^>]*\\bid="${escape(sub.messageRef)}"(?:[^>]*\\/>|[^>]*>[\\s\\S]*?<\\/bpmn:message>)`,
  );
  const msgBlock = xml.match(msgRe);
  if (!msgBlock) {
    errors.push(`messageSubscription on ${sub.elementId}: <bpmn:message id="${sub.messageRef}"> not found in ${phase}.bpmn`);
    continue;
  }
  // Start events create new instances — no correlationKey required or meaningful.
  if (sub.sourceElementType === 'startEvent') continue;

  const subRe = /<zeebe:subscription\b[^>]*\bcorrelationKey="([^"]+)"/;
  const subMatch = msgBlock[0].match(subRe);
  if (!subMatch) {
    errors.push(`messageSubscription on ${sub.elementId}: <bpmn:message id="${sub.messageRef}"> has no <zeebe:subscription correlationKey="…"> in ${phase}.bpmn`);
    continue;
  }
  // Correlation key must be FEEL-prefixed (`=…`) — broker treats unprefixed
  // values as literal strings.
  const found = subMatch[1];
  if (!found.startsWith('=')) {
    errors.push(`messageSubscription on ${sub.elementId}: correlationKey="${found}" is not FEEL-prefixed (must start with '='); broker would treat as a literal string`);
  }
  // When the manifest entry pins a key, verify it matches.
  if (sub.correlationKey && found !== `=${sub.correlationKey}` && found !== sub.correlationKey) {
    errors.push(`messageSubscription on ${sub.elementId}: correlationKey="${found}" does not match manifest's "${sub.correlationKey}"`);
  }
}

// --- 6. Connector wiring shape — static-binding literals + resultExpression presence ---
//
// Two cross-checks the reconciler should make hard to regress:
//   (a) For each HttpJson connector binding whose annotation contains
//       "outputs …", "returns …", or "computes Z = …", the dest BPMN must
//       carry a non-empty <zeebe:header key="resultExpression"> on that
//       element. Catches both reconciler regressions AND silent gaps in the
//       analyze-phase extraction prompt (the LLM-instinct path for v7).
//   (b) For each manifest connector binding targeting a known static
//       binding (HttpJson `method`, `authentication.type`), the dest BPMN's
//       <zeebe:input source="…"> must NOT start with `=` and must NOT be
//       wrapped in quotes. Catches FEEL-coercion regressions on Dropdowns.
//
// Using a small static map of well-known Dropdown bindings keeps the audit
// independent of the cached templates — the audit runs after Phase 3 by
// which point the templates may not be re-fetched.
const KNOWN_STATIC_BINDINGS = {
  'io.camunda.connectors.HttpJson.v2': new Set(['method', 'authentication.type']),
  'io.camunda.connectors.HttpJson.v1': new Set(['method', 'authentication.type']),
  'io.camunda.connectors.aws.bedrock.v1': new Set(['authentication.type', 'action']),
  // Email connector (SMTP/IMAP/POP3) — every one of these is a Dropdown or
  // Hidden in the v4 template; the LLM-fronted reconciler kept FEEL-coercing
  // them in v7 snapshots, producing `="simple"` / `="smtp"` etc.
  'io.camunda.connectors.email.v1': new Set([
    'authentication.type',
    'protocol',
    'data.smtpActionDiscriminator',
    'smtpCryptographicProtocol',
    'contentType',
    'data.smtpAction',
  ]),
};

function readBpmnByPhase(phase) {
  const fn = path.join(ROOT, 'src', 'main', 'resources', 'processes', phase + '.bpmn');
  return fs.existsSync(fn) ? fs.readFileSync(fn, 'utf8') : null;
}

function findElementBlock(xml, elementId) {
  // Match opening + body + matching close. Backreference \2 ensures the
  // close tag matches the same BPMN element type.
  const re = new RegExp(
    `<bpmn:([a-zA-Z]+)\\b[^>]*\\bid="${escape(elementId)}"[^>]*>([\\s\\S]*?)</bpmn:\\1>`,
  );
  const m = xml.match(re);
  return m ? m[0] : '';
}

const RESPONSE_HINT_RE = /\b(?:outputs|returns|computes|response\s*:)\b/i;

for (const cb of (manifest.connectorBindings || [])) {
  const xml = readBpmnByPhase(cb.phase);
  if (!xml) continue; // missing-phase already surfaced earlier
  const block = findElementBlock(xml, cb.elementId);
  if (!block) continue;

  // (a) resultExpression presence when the annotation hints at a response shape.
  // Only enforced for templates that carry a resultExpression header binding —
  // hardcoding the HttpJson family covers the cases observed; widen as new
  // connectors with response mapping are introduced.
  if (cb.templateId && cb.templateId.startsWith('io.camunda.connectors.HttpJson')
      && cb.annotationText && RESPONSE_HINT_RE.test(cb.annotationText)) {
    const headerRe = /<zeebe:header\b[^>]*\bkey="resultExpression"[^>]*\bvalue="([^"]*)"/;
    const m = block.match(headerRe);
    if (!m || m[1].trim() === '' || m[1] === '=') {
      errors.push(`${cb.elementId}: annotation describes a response shape ("${cb.annotationText.slice(0, 80)}…") but BPMN has no non-empty <zeebe:header key="resultExpression">`);
    }
  }

  // (b) Static-binding literal shape — no leading `=`, no wrapping quotes.
  const staticTargets = KNOWN_STATIC_BINDINGS[cb.templateId];
  if (staticTargets) {
    for (const target of staticTargets) {
      const inputRe = new RegExp(
        `<zeebe:input\\b[^/]*?\\bsource="([^"]*)"[^/]*?\\btarget="${escape(target)}"|<zeebe:input\\b[^/]*?\\btarget="${escape(target)}"[^/]*?\\bsource="([^"]*)"`,
      );
      const m = block.match(inputRe);
      if (!m) continue;
      const raw = (m[1] || m[2] || '').trim();
      if (raw === '') continue;
      // The regex captured the raw XML attribute value — entities are still
      // encoded (`&quot;` for `"`, `&apos;` for `'`). Decode before testing
      // so both `="X"` (FEEL string) and `"X"` (wrapping quotes) are caught.
      const decoded = raw
        .replace(/&quot;/g, '"').replace(/&apos;/g, "'")
        .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
      const looksLikeFeelString = decoded.startsWith('=') || /^["'].*["']$/.test(decoded);
      if (looksLikeFeelString) {
        errors.push(`${cb.elementId}: static binding "${target}" has FEEL-coerced source ${JSON.stringify(decoded)} — must be a bare literal`);
      }
    }
  }
}

// --- 7. Manifest → BPMN presence (reverse of §4; folds in verify-execution-bpmn) ---
// Every declared wiring must actually land on its target element. Catches an
// analyze-join / wire-execution-bpmn regression where a manifest entry's target
// element silently lacks its taskDefinition / formDefinition / calledDecision —
// a case §4 (BPMN → manifest) cannot see, because there is no BPMN reference to
// check when the wiring is simply absent.
// A manifest entry with no target element id can't be presence-checked here
// (§1–3 still cover its file/class existence); skip rather than false-alarm.
const wid = x => (x.wiring && x.wiring.targetElementId) || x.elementId || x.taskId;

for (const w of (manifest.workers || [])) {
  const id = wid(w);
  if (!id) continue;
  const xml = readBpmnByPhase(w.phase);
  if (!xml) { errors.push(`worker "${w.jobType}": ${w.phase}.bpmn not found in processes/`); continue; }
  const block = findElementBlock(xml, id);
  if (!block) { errors.push(`worker "${w.jobType}": target element <${id}> not found in ${w.phase}.bpmn`); continue; }
  if (!/<zeebe:taskDefinition\b/.test(block)) {
    errors.push(`worker "${w.jobType}": target element <${id}> has no <zeebe:taskDefinition> in ${w.phase}.bpmn`);
  }
}
for (const f of (manifest.forms || [])) {
  const id = wid(f);
  if (!id) continue;
  const xml = readBpmnByPhase(f.phase);
  if (!xml) { errors.push(`form "${f.formId}": ${f.phase}.bpmn not found in processes/`); continue; }
  const block = findElementBlock(xml, id);
  if (!block) { errors.push(`form "${f.formId}": target userTask <${id}> not found in ${f.phase}.bpmn`); continue; }
  if (!new RegExp(`<zeebe:formDefinition\\b[^>]*\\bformId="${escape(f.formId)}"`).test(block)) {
    errors.push(`form "${f.formId}": target userTask <${id}> has no <zeebe:formDefinition formId="${f.formId}"> in ${f.phase}.bpmn`);
  }
}
for (const d of (manifest.decisions || [])) {
  const id = wid(d);
  if (!id) continue;
  const xml = readBpmnByPhase(d.phase);
  if (!xml) { errors.push(`decision "${d.decisionId}": ${d.phase}.bpmn not found in processes/`); continue; }
  const block = findElementBlock(xml, id);
  if (!block) { errors.push(`decision "${d.decisionId}": target businessRuleTask <${id}> not found in ${d.phase}.bpmn`); continue; }
  if (!new RegExp(`<zeebe:calledDecision\\b[^>]*\\bdecisionId="${escape(d.decisionId)}"`).test(block)) {
    errors.push(`decision "${d.decisionId}": target businessRuleTask <${id}> has no <zeebe:calledDecision decisionId="${d.decisionId}"> in ${d.phase}.bpmn`);
  }
}

// --- Report ---
for (const n of notes) console.log(`  · ${n}`);

if (errors.length === 0) {
  console.log('Implicit-dependency audit: PASS');
  process.exit(0);
}

console.log(`Implicit-dependency audit: FAIL (${errors.length} issue(s))`);
for (const e of errors) console.log(`  ✗ ${e}`);
process.exit(1);
