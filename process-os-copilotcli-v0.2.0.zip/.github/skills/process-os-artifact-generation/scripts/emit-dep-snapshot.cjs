#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Emit a normalized JSON snapshot of everything ProcessOS and its generated
// artifacts depend on — not just library versions, but every artifact that has to
// be downloaded before ProcessOS can generate, build, and TEST a solution. Four
// dependency universes:
//
//   - The ProcessOS-side npm tooling tree (root package.json), resolved with
//     `npm install --package-lock-only` and read back from package-lock.json.
//   - The generated worker project's deps, read from scaffold-workers'
//     `--summary` output: the java-spring-boot blueprint pom (parent +
//     resolved properties + declared dependency list + Maven BUILD PLUGINS +
//     the Maven wrapper distribution), the typescript blueprint package.json
//     (dependency lists + the `engines` floor it declares; `package_manager`
//     is always null — the generated project drops the blueprint's pnpm pin
//     and builds via plain npm, so it is never a floor of that project),
//     and the python blueprint pyproject.toml (requires-python floor +
//     dependency lists as declared ranges — uv.lock holds the resolution).
//   - `plugins` — the plugin universes ProcessOS depends on: c8ctl plugins
//     (bundled ones plus the ProcessOS distribution plugin, which is loaded from
//     GitHub), bpmnlint plugins, and the per-project discovery-plugin mechanism.
//   - `runtime_downloads` + `network_hosts` — artifacts fetched on demand at run
//     time (release archives, container images, the connector-template catalogue,
//     git clones) and the deduplicated host list they imply, which is what an
//     endpoint allowlist review actually needs.
//
// Scope boundary: HOST TOOLING an endpoint must provide on its own — IDE, browser,
// JDK vendor, container runtime, the acceptance-testing demo tools — is NOT
// enumerated here. Those are not ProcessOS dependencies; they stay with the
// handbook-focused consumer (team-fde), by design. The JDK / Node pins the
// blueprints declare do appear, but as what they are — blueprint pins inside the
// `java`, `typescript`, and `python` sections, not a machine-provisioning checklist. The
// TS blueprint's `packageManager` (pnpm) pin does NOT appear here: it never
// reaches a generated project (scaffold-workers drops it), so it names no
// dependency this snapshot needs to track.
//
// Source of truth: the blueprint pom.xml / package.json pin the versions.
// versions.json holds ONLY the Camunda per-cluster-minor CLIENT map,
// which scaffold-workers surfaces as `summary.camundaClientMap` and this script
// carries through verbatim.
//
// Interface with scaffold-workers:
//
//   This script does NOT parse the pom or package.json itself. It invokes
//   scaffold-workers with `--summary <path>` and reads the JSON contract that
//   comes out; all knowledge of pom / package.json shape lives inside
//   scaffold-workers. See
//   skills/process-os-artifact-generation/scripts/scaffold-workers.cjs.
//
// BOM-managed versions: blueprint java deps that inherit their version from the
// Spring Boot parent arrive in the summary as `version: null`. If `mvn` is
// present, we run `mvn dependency:list` against the scaffolded pom and stamp the
// resolved concrete versions onto those entries; without mvn they stay null and
// a consumer can render "(BOM-managed by <parent.groupId>:<parent.artifactId>:
// <parent.version>)". Build plugins get the same treatment via
// `mvn dependency:resolve-plugins` (plugins never appear in `dependency:list`).
//
// Declared vs derived: rows in the `plugins` and `runtime_downloads` tables below
// are DECLARED in this file, because the dependency they encode (the c8ctl plugin
// that ships `c8 os`, the container images CPT pulls) exists only as prose in a
// SKILL.md or README today. Every such row carries a `source` pointing at the file
// that documents it, so a reviewer can check the claim. Wherever a machine-readable
// pin does exist it is DERIVED at run time and never duplicated here — the Maven
// version + host from the wrapper's distributionUrl, the c8ctl floor from
// check-c8ctl-version.cjs, and bpmnlint plugin versions from the npm tree.
//
// Licenses: every dependency row carries a `license` + `license_note` pair, so
// the snapshot answers the OSS-compliance question ("what is the license of
// everything this pulls onto our machine?") alongside the endpoint-allowlist one
// it was built for. The npm side reads the declaration out of the lockfile; the
// java side needs a second mvn goal, because `dependency:list` carries none.
// Rows are the DECLARED top level, matching the rest of the snapshot — this is
// not a transitive license inventory. The TS and python blueprint sections carry
// no licenses at all: their deps are declared RANGES and no lockfile for them is
// resolved here, so there is nothing resolved to read a license off.
//
// Output is timestamp-free so the snapshot stays diffable — a change in the
// snapshot then means a real dependency moved, not just a re-run.
//
// Consumers (planned):
//   - camunda/team-fde  → daily refresh of the ProcessOS FDE access
//                          requirements handbook page (team-fde#5).
//   - docs/              → any reference doc listing resolved runtime versions
//                          can `require` this snapshot.
//   - CI                 → drift detection: an unexpected snapshot change flags
//                          that a transitive dep moved.
//
// Pipeline:
//   1. `npm install --package-lock-only --ignore-scripts` in cwd
//      (resolves the ProcessOS-side npm tree without downloading tarballs).
//   2. Invoke scaffold-workers.cjs --summary against a synthetic manifest,
//      capturing the blueprint parent, properties, dependency + plugin lists,
//      the Maven wrapper block, and the TS blueprint's `engines` pin.
//   3. If `mvn` is present, run `mvn -B -f <pom> dependency:list` and
//      `dependency:resolve-plugins`, stamping concrete versions onto java deps
//      and build plugins the summary emitted as `version: null`, then
//      `license:add-third-party` and stamp each java dep's declared license.
//   4. Parse package-lock.json for the npm top-level tree and its licenses.
//   5. Read the c8ctl version floor from check-c8ctl-version.cjs.
//   6. Build the plugins / runtime-downloads tables, deriving every version and
//      host that has a machine-readable source, then derive `network_hosts` from
//      the download rows.
//   7. Emit a single JSON document.
//
// Usage (from the ProcessOS project root, which is every agent session's cwd):
//
//   node emit-dep-snapshot.cjs \
//     [--work-dir <dir>] \
//     [--out <path.json>]
//
// Defaults: --work-dir .camunda/dep-snapshot, --out stdout.
//
// The work dir is scratch, never output: it holds the scaffolded projects and
// the target/ tree the mvn goals write into, and it is kept rather than deleted
// so a reviewer can check what mvn actually resolved. The snapshot is what goes
// to stdout or --out. Nothing reads the work dir back on a later run.
//
// Exit codes:
//   0 success
//   2 missing prerequisites (node/npm) or bad inputs
//   3 network / scaffold failure

'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { runNodeCli, runShellCli } = require('./resolve-node-cli.cjs');

// ── license reporting ───────────────────────────────────────────────────────
// Every dependency row carries two flat fields, because a compliance reader has
// to tell three states apart and a single string only tells two:
//
//   license      — the declaration verbatim, or null when there is none to read
//   license_note — null when that string stands on its own; otherwise what the
//                  reader has to do about it, or why there is nothing there
//
// The note is what keeps "declared, but not as an SPDX identifier" from reading
// as "unknown": several bpmn.io packages declare `SEE LICENSE IN LICENSE`, which
// is an instruction to open a file inside the package, not an absence. The
// classification is of the declaration's SHAPE — nothing here validates a string
// against the SPDX license list.
const LICENSE_NOTE_FILE_REF =
  'non-SPDX declaration — the file it names, inside the package, is authoritative';
const LICENSE_NOTE_NONE = 'the package declares no license';
const LICENSE_NOTE_MVN_UNAVAILABLE = 'not resolved — mvn was unavailable';
const LICENSE_NOTE_NO_REPORT = 'not resolved — the third-party report was not produced';
const LICENSE_NOTE_NOT_IN_REPORT = 'not resolved — absent from the resolved third-party list';
const LICENSE_NOTE_NOT_IN_TREE = 'not resolved — absent from the resolved npm tree';
const LICENSE_NOTE_NOT_NPM = 'not resolved — not delivered through the npm tree';

// license-maven-plugin writes `(Unknown license)` for an artifact whose POM
// declares none. That is the same state as a missing declaration, not a licence
// called "Unknown license".
const MAVEN_UNKNOWN_LICENSE = /^unknown licen[cs]e$/i;

// Pinned so the snapshot stays reproducible; `add-third-party` writes
// target/generated-sources/license/THIRD-PARTY.txt for the project it runs on.
const MAVEN_LICENSE_PLUGIN = 'org.codehaus.mojo:license-maven-plugin:2.6.0';
const MAVEN_THIRD_PARTY_REPORT = path.join('target', 'generated-sources', 'license', 'THIRD-PARTY.txt');

/**
 * Turn a declared licence string into the `license` / `license_note` pair.
 *
 * @param {unknown} declared The verbatim declaration, if there is one.
 * @returns {{license: string|null, license_note: string|null}}
 */
function classifyLicense(declared) {
  if (typeof declared !== 'string' || declared.trim() === '') {
    return { license: null, license_note: LICENSE_NOTE_NONE };
  }
  const value = declared.trim();
  if (/^SEE LICEN[CS]E IN\b/i.test(value)) {
    return { license: value, license_note: LICENSE_NOTE_FILE_REF };
  }
  return { license: value, license_note: null };
}

// ── subprocess steps (exported for unit tests) ─────────────────────────────
// Each returns a result instead of exiting, so a test can drive it with a fake
// runner and assert the outcome mapping. Both runners come from
// resolve-node-cli.cjs: `npm` and `mvn` are `npm.cmd` / `mvn.cmd` on Windows and
// cannot be exec'd without a shell, and a spawn that never launched is reported
// as its own outcome rather than folded into the tool's exit status.

/**
 * @typedef {Object} StepResult
 * @property {boolean} ok
 * @property {number} [code] Process exit code to use when `ok` is false.
 * @property {string} [message] Diagnostic for stderr when `ok` is false.
 */

/**
 * Resolve the ProcessOS-side npm tree into package-lock.json.
 *
 * @param {string} projectRoot Directory to run npm in.
 * @param {Function} [run] Injected runner (tests).
 * @returns {StepResult}
 */
function runNpmLockfileOnly(projectRoot, run = runShellCli) {
  const r = run('npm', ['install', '--package-lock-only', '--ignore-scripts'], {
    cwd: projectRoot,
    stdio: ['ignore', 'ignore', 'inherit'],
  });
  if (!r.launched) {
    return {
      ok: false,
      code: 2,
      message: `npm did not run (${r.error ? r.error.message : 'unknown reason'}) — install Node.js/npm and retry`,
    };
  }
  if (r.status !== 0) return { ok: false, code: 3, message: 'npm install --package-lock-only failed' };
  return { ok: true };
}

/**
 * Scaffold the blueprint projects and write the --summary JSON contract.
 *
 * @param {string} scriptPath Absolute path to scaffold-workers.cjs.
 * @param {string[]} args Arguments for the scaffold script.
 * @param {string} cwd Working directory.
 * @param {Function} [run] Injected runner (tests).
 * @returns {StepResult}
 */
function runScaffoldSummary(scriptPath, args, cwd, run = runNodeCli) {
  const r = run(scriptPath, args, { cwd, stdio: ['ignore', 'ignore', 'inherit'] });
  if (!r.launched) {
    return {
      ok: false,
      code: 2,
      message: `scaffold-workers.cjs did not run (${r.error ? r.error.message : 'unknown reason'})`,
    };
  }
  if (r.status !== 0) return { ok: false, code: 3, message: 'scaffold-workers.cjs failed' };
  return { ok: true };
}

/**
 * Ask mvn for the versions the Spring Boot BOM resolves to.
 *
 * A missing mvn is a documented, tolerated outcome — the caller leaves those
 * versions null. It is still reported, because "mvn was absent" and "mvn ran and
 * failed" are different facts and silently conflating them is how a snapshot
 * ends up quietly incomplete.
 *
 * @param {string} pom Absolute path to the scaffolded pom.xml.
 * @param {Function} [run] Injected runner (tests).
 * @returns {{stdout: string|null, note: string|null}}
 */
function runMvnDependencyList(pom, run = runShellCli) {
  // `-B` for batch/no-color output; do NOT use `-q`, which suppresses the
  // [INFO] lines carrying the resolved dependency triples.
  const r = run('mvn', ['-B', '-f', pom, 'dependency:list', '-DincludeScope=test'], { encoding: 'utf8' });
  if (!r.launched) return { stdout: null, note: 'mvn not available — BOM-managed versions left unresolved' };
  if (r.status !== 0) return { stdout: null, note: `mvn dependency:list exited ${r.status} — BOM-managed versions left unresolved` };
  return { stdout: r.stdout ? String(r.stdout) : null, note: null };
}

/**
 * Ask mvn for the versions pluginManagement resolves to — these never appear
 * in `dependency:list`, which only covers DEPS.
 *
 * @param {string} pom Absolute path to the scaffolded pom.xml.
 * @param {Function} [run] Injected runner (tests).
 * @returns {{stdout: string|null, note: string|null}}
 */
function runMvnDependencyResolvePlugins(pom, run = runShellCli) {
  const r = run('mvn', ['-B', '-f', pom, 'dependency:resolve-plugins'], { encoding: 'utf8' });
  if (!r.launched) return { stdout: null, note: 'mvn not available — BOM-managed plugin versions left unresolved' };
  if (r.status !== 0) return { stdout: null, note: `mvn dependency:resolve-plugins exited ${r.status} — BOM-managed plugin versions left unresolved` };
  return { stdout: r.stdout ? String(r.stdout) : null, note: null };
}

/**
 * Ask mvn what licence every resolved java dependency declares.
 *
 * `dependency:list` carries no licence data, so this is a second, separate
 * invocation. license-maven-plugin is pinned: an unpinned `license:` prefix
 * resolves whatever is newest at run time, which would let the snapshot's
 * java licences change without a dependency moving.
 *
 * A missing mvn is the same documented, tolerated outcome as everywhere else
 * here — the caller leaves the licences null with a note saying which of the
 * two reasons applies.
 *
 * @param {string} pom Absolute path to the scaffolded pom.xml.
 * @param {Function} [run] Injected runner (tests).
 * @returns {{ok: boolean, note: string|null}}
 */
function runMvnLicenses(pom, run = runShellCli) {
  const goal = `${MAVEN_LICENSE_PLUGIN}:add-third-party`;
  const r = run('mvn', ['-B', '-f', pom, goal], { encoding: 'utf8' });
  if (!r.launched) return { ok: false, note: 'mvn not available — java licenses left unresolved' };
  if (r.status !== 0) return { ok: false, note: `mvn ${goal} exited ${r.status} — java licenses left unresolved` };
  return { ok: true, note: null };
}

// ── declared dependency tables ──────────────────────────────────────────────
// Scope: what ProcessOS and its generated artifacts depend on. Host tooling an
// endpoint must provide on its own (IDE, browser, JDK vendor, container runtime,
// the acceptance-testing demo tools) is deliberately NOT enumerated here — that
// stays with the handbook-focused consumer.
//
// The tables below encode dependencies that live as prose in the repo, so each
// row names its `source` file and a reviewer can check the claim. Values that
// have a machine-readable pin are derived at run time instead (see main()).

// c8ctl and its plugins. ProcessOS drives Camunda through c8ctl, so its plugin
// set is a hard dependency: three ship with the CLI, the `os` plugin (the
// ProcessOS distribution manager) is loaded from npm at install time.
const C8CTL_PACKAGE = '@camunda8/cli';
const C8CTL_PLUGIN_PROCESS_OS_PACKAGE = '@camunda8/c8ctl-plugin-process-os';
const C8CTL_PLUGIN_PROCESS_OS_REPO = 'https://github.com/camunda/c8ctl-plugin-process-os';

const REQUIRED_C8CTL_PLUGINS = [
  {
    name: 'c8ctl-plugin-os',
    provides: 'os',
    bundled_with_c8ctl: false,
    install: `c8 load plugin ${C8CTL_PLUGIN_PROCESS_OS_PACKAGE}`,
    repo: C8CTL_PLUGIN_PROCESS_OS_REPO,
    purpose: 'the ProcessOS distribution manager — c8 os install / update / switch',
    used_by: ['install (c8 os install <platform>)'],
    source: 'README.md',
  },
  {
    name: 'c8ctl-plugin-cluster',
    provides: 'cluster',
    bundled_with_c8ctl: true,
    purpose: 'local Camunda 8 Run lifecycle — install, start, stop, logs',
    used_by: ['process-os-environment-setup'],
    source: 'shared/references/c8ctl.md, shared/references/env-c8run.md',
  },
  {
    name: 'c8ctl-plugin-element-template',
    provides: 'element-template',
    bundled_with_c8ctl: true,
    purpose: 'syncs the OOTB connector-template catalogue and applies templates to BPMN elements',
    used_by: ['process-os-project-initialization', 'process-os-bpmn-generation', 'process-os-artifact-generation'],
    source: 'skills/process-os-bpmn-generation/references/connectors.md',
  },
  {
    name: 'c8ctl-plugin-bpmn',
    provides: 'bpmn',
    bundled_with_c8ctl: true,
    purpose: 'c8ctl bpmn lint',
    used_by: ['shared/references/ai-in-bpmn.md'],
    source: 'shared/references/ai-in-bpmn.md',
  },
];

// bpmnlint plugins. `npm` delivery means the version comes from the resolved npm
// tree (attached in buildPluginSections); `bundled` means it ships inside the
// dist bundle and is loaded via NODE_PATH — nothing to download.
const BPMNLINT_PLUGINS = [
  {
    name: 'bpmnlint-plugin-camunda-compat',
    delivery: 'npm',
    purpose: 'Camunda 8 compatibility rules applied by process-os-bpmn-linting',
    source: 'package.json',
  },
  {
    name: 'bpmnlint-plugin-process-os',
    delivery: 'bundled',
    purpose: 'ProcessOS-authored bpmnlint rules — ships in the dist bundle, no download',
    source: 'skills/process-os-bpmn-linting/plugins/bpmnlint-plugin-process-os/package.json',
  },
];

// Discovery plugins are per-project, not per-install: the git remotes live in the
// project's own registry, so this section describes the mechanism and its access
// requirement rather than a fixed list.
const DISCOVERY_PLUGINS = {
  mechanism: 'git clone into .camunda/plugins/<name>/, declared per project in .camunda/registry/discovery/<name>.md (frontmatter: source + ref)',
  install: '/process-os-discovery-plugin install <source> [<ref>]',
  sources: 'project-declared — arbitrary git remotes, not fixed by ProcessOS',
  requires: ['network access to each declared git remote'],
  source: 'skills/process-os-discovery-plugin/SKILL.md',
};

// Artifacts fetched on demand at run time. `hosts: []` means the download exists
// but its location is chosen by the tool that performs it (c8ctl, Testcontainers)
// or by the project — deliberately not guessed here.
const NPM_REGISTRY_HOST = 'registry.npmjs.org';
const DOCKER_HUB_HOSTS = ['registry-1.docker.io', 'auth.docker.io', 'production.cloudflare.docker.com'];

const RUNTIME_DOWNLOADS = [
  {
    id: 'process-os-dist-bundle',
    kind: 'release-archive',
    what: 'the ProcessOS skill bundle for the target agent platform',
    trigger: 'c8 os install <platform> / c8 os update',
    hosts: ['github.com', 'objects.githubusercontent.com'],
    required: true,
    source: 'README.md',
  },
  {
    id: 'c8ctl-plugin-process-os',
    kind: 'npm-package',
    what: 'the c8ctl plugin that provides `c8 os`',
    trigger: `c8 load plugin ${C8CTL_PLUGIN_PROCESS_OS_PACKAGE}`,
    hosts: [NPM_REGISTRY_HOST],
    required: true,
    source: 'README.md',
  },
  {
    id: 'c8ctl-cli',
    kind: 'npm-package',
    what: `${C8CTL_PACKAGE} (global install)`,
    trigger: 'npm install -g @camunda8/cli',
    hosts: [NPM_REGISTRY_HOST],
    required: true,
    source: 'shared/references/c8ctl.md',
  },
  {
    id: 'process-os-skill-runtime-npm',
    kind: 'npm-package',
    what: 'the pinned skill runtime deps — the `npm` section of this snapshot',
    trigger: 'npm install --prefix .camunda (run by the c8 os plugin, and as a preflight by process-os-bpmn-generation)',
    hosts: [NPM_REGISTRY_HOST],
    required: true,
    source: 'package.json, skills/process-os-bpmn-generation/SKILL.md',
  },
  {
    id: 'bpmnlint-npx-fallback',
    kind: 'npm-package',
    what: 'bpmnlint, fetched per call when it is installed in neither .camunda/node_modules nor the project root',
    trigger: 'npx --yes bpmnlint',
    hosts: [NPM_REGISTRY_HOST],
    required: false,
    source: 'shared/references/lint-bpmn.md',
  },
  {
    id: 'maven-project-artifacts',
    kind: 'maven-artifact',
    what: 'the `java.dependencies` and `java.plugins` sections of this snapshot, plus their transitive closure — the blueprint pom declares no custom <repositories>, so Maven Central is the only source',
    trigger: 'mvn test / ./mvnw test in the generated project',
    hosts: ['repo.maven.apache.org'],
    required: true,
    source: 'skills/process-os-artifact-generation/blueprints/java-spring-boot/pom.xml',
  },
  {
    id: 'maven-distribution',
    kind: 'release-archive',
    what: 'Apache Maven itself, fetched by the wrapper (see java.maven_wrapper)',
    trigger: './mvnw <goal> on a machine with no cached wrapper distribution',
    derived_hosts_from: 'java.maven_wrapper.distributionUrl',
    hosts: [],
    required: false,
    source: 'skills/process-os-artifact-generation/blueprints/java-spring-boot/.mvn/wrapper/maven-wrapper.properties',
  },
  {
    id: 'camunda-run-distribution',
    kind: 'release-archive',
    what: 'the Camunda 8 Run distribution for the requested version',
    trigger: 'c8ctl cluster start / c8ctl cluster install <version>',
    hosts: [],
    resolved_by: 'c8ctl-plugin-cluster — download location is owned by c8ctl, not pinned by ProcessOS',
    required: true,
    source: 'shared/references/env-c8run.md',
  },
  {
    id: 'connector-template-catalogue',
    kind: 'catalogue',
    what: 'the OOTB Camunda connector element templates, cached in c8ctl\'s own config dir',
    trigger: 'c8ctl element-template sync',
    hosts: [],
    resolved_by: 'c8ctl-plugin-element-template',
    required: false,
    note: 'non-blocking: project initialization continues offline and downstream skills reuse a previously cached catalogue',
    source: 'skills/process-os-project-initialization/SKILL.md',
  },
  {
    id: 'cpt-engine-image',
    kind: 'container-image',
    what: 'the Camunda engine image CPT runs the process tests against (~500 MB, once per version)',
    trigger: 'mvn test (Camunda Process Test)',
    hosts: DOCKER_HUB_HOSTS,
    resolved_by: 'Testcontainers — image name and tag are pinned inside camunda-process-test-spring; do not pre-pull a guessed tag',
    required: true,
    source: 'shared/references/camunda-testing-guide.md',
  },
  {
    id: 'cpt-connector-runtime-image',
    kind: 'container-image',
    what: 'the Camunda connector runtime image started by CPT managed mode',
    trigger: 'mvn clean test -P integration-test with runtime-mode: managed and connectors-enabled: true',
    hosts: DOCKER_HUB_HOSTS,
    resolved_by: 'Camunda Process Test (managed mode)',
    required: false,
    source: 'shared/references/camunda-testing-guide.md',
  },
  {
    id: 'testcontainers-reaper-image',
    kind: 'container-image',
    what: 'the Testcontainers resource-reaper sidecar, pulled alongside any Testcontainers container',
    trigger: 'mvn test (Camunda Process Test)',
    hosts: DOCKER_HUB_HOSTS,
    resolved_by: 'Testcontainers',
    required: true,
    source: 'Testcontainers runtime behaviour — not declared in this repo',
  },
  {
    id: 'discovery-plugin-repos',
    kind: 'git-clone',
    what: 'each discovery plugin declared by the project',
    trigger: '/process-os-discovery-plugin install <source> [<ref>]',
    hosts: [],
    resolved_by: 'project-declared git remotes in .camunda/registry/discovery/',
    required: false,
    source: 'skills/process-os-discovery-plugin/SKILL.md',
  },
];

// ── pure helpers (exported for unit tests) ─────────────────────────────────
// These carry all of this script's transformation logic and are kept free of
// I/O and process state so they can be unit-tested directly. main() below wires
// them to the real npm/scaffold/mvn subprocesses and the filesystem.

// Parse `mvn dependency:list` output into a Map of "group:artifact" → version.
// mvn emits lines like:
//   [INFO]    org.springframework.boot:spring-boot-starter-web:jar:4.1.0:compile
function parseMvnResolvedVersions(stdout) {
  const resolved = new Map();
  for (const line of String(stdout || '').split('\n')) {
    const m = line.match(/\s([\w.-]+):([\w.-]+):(?:jar|pom):([\w.+-]+):(compile|test|runtime|provided)/);
    if (m) resolved.set(`${m[1]}:${m[2]}`, m[3]);
  }
  return resolved;
}

// Parse `mvn dependency:resolve-plugins` output into a Map of
// "group:artifact" → version. Build plugins never show up in `dependency:list`,
// so this is the only way to resolve the ones the Spring Boot parent manages.
// mvn indents the plugin itself by exactly four spaces and its transitive deps by
// more, so the indent is what separates the two:
//   [INFO]    org.jacoco:jacoco-maven-plugin:jar:0.8.15
//   [INFO]       org.jacoco:org.jacoco.agent:jar:runtime:0.8.15   ← transitive, skipped
// The version is the LAST colon-separated field, which also handles the
// classifier form (group:artifact:jar:<classifier>:version).
function parseMvnResolvedPluginVersions(stdout) {
  const resolved = new Map();
  for (const line of String(stdout || '').split('\n')) {
    const m = line.match(/^\[INFO\] {4}(\S+)\s*$/);
    if (!m) continue;
    const parts = m[1].split(':');
    if (parts.length < 4) continue;
    resolved.set(`${parts[0]}:${parts[1]}`, parts[parts.length - 1]);
  }
  return resolved;
}

// Stamp concrete versions onto java deps whose version came in as `null`
// (BOM-managed by the Spring Boot parent). Mutates `javaDeps` in place and
// returns the count of deps that were resolved.
function stampBomManagedVersions(javaDeps, resolved) {
  let count = 0;
  for (const dep of javaDeps) {
    if (dep.version != null) continue;
    const key = `${dep.groupId}:${dep.artifactId}`;
    if (resolved.has(key)) {
      dep.version = resolved.get(key);
      count++;
    }
  }
  return count;
}

// Parse a THIRD-PARTY.txt report into a Map of "group:artifact" → declared
// licence string (null where the artifact declares none). The plugin writes one
// line per artifact, licences first and coordinates last:
//   (The Apache Software License, Version 2.0) FindBugs-jsr305 (com.google.code.findbugs:jsr305:3.0.2 - http://…)
//   (Apache-2.0) (EPL-2.0) Dual-licensed thing (com.example:thing:1.0 - http://…)
// The artifact NAME can itself contain parentheses, so the coordinates are taken
// from the end of the line and the licence groups from the start; whatever sits
// between them is the human-readable name and is not parsed.
function parseThirdPartyLicenses(text) {
  const out = new Map();
  for (const raw of String(text || '').split('\n')) {
    const line = raw.trimEnd();
    const coords = line.match(/\(([\w.$-]+):([\w.$-]+):[^\s)]+(?:\s+-\s+[^)]*)?\)$/);
    if (!coords) continue;
    const names = [];
    let head = line.slice(0, coords.index).trimStart();
    let group;
    while ((group = head.match(/^\(([^)]*)\)\s*/))) {
      names.push(group[1].trim());
      head = head.slice(group[0].length);
    }
    if (names.length === 0) continue;
    const declared = names.filter((n) => n && !MAVEN_UNKNOWN_LICENSE.test(n));
    // Several licence groups on one line say the artifact is offered under more
    // than one; the report states no relationship between them, so neither does
    // this — they are joined, not turned into an SPDX `OR` expression.
    out.set(`${coords[1]}:${coords[2]}`, declared.length > 0 ? declared.join('; ') : null);
  }
  return out;
}

// Give every java dep a license/license_note pair: from `resolved` where the
// third-party report covered it, and `unresolvedNote` where it did not. Mutates
// `javaDeps` in place and returns the count that the report covered.
//
// Every dep is filled, not just the covered ones — a row missing the field
// entirely is indistinguishable, to a consumer, from a row whose licence is
// genuinely unknown.
function stampMavenLicenses(javaDeps, resolved, unresolvedNote = LICENSE_NOTE_NOT_IN_REPORT) {
  let count = 0;
  for (const dep of javaDeps) {
    const key = `${dep.groupId}:${dep.artifactId}`;
    if (resolved.has(key)) {
      Object.assign(dep, classifyLicense(resolved.get(key)));
      count++;
    } else {
      Object.assign(dep, { license: null, license_note: unresolvedNote });
    }
  }
  return count;
}

// A usable Camunda client map is a required section of the snapshot: it comes
// from versions.json via the summary. A null/empty map means versions.json is
// missing/corrupt or the summary contract regressed.
function clientMapUsable(summary) {
  return !!(summary && summary.camundaClientMap && Object.keys(summary.camundaClientMap).length > 0);
}

// package-lock.json v2/v3 exposes the root project's declared dependencies
// under `packages[""]`. That is what a handbook table lists ("top-level"),
// distinct from the resolved dep tree that npm ships in the same file. Throws
// if the lockfile has no `packages[""]` root.
function resolveNpmTopLevel(lock) {
  const rootPkg = lock.packages && lock.packages[''];
  if (!rootPkg) {
    throw new Error('package-lock.json has no packages[""] root');
  }
  const declared = { ...(rootPkg.dependencies || {}), ...(rootPkg.devDependencies || {}) };
  return Object.entries(declared)
    .map(([name, spec]) => {
      const entry = lock.packages?.[`node_modules/${name}`];
      const resolvedVersion = entry?.version ?? spec.replace(/^[\^~]/, '');
      // The lockfile's own `license` is the resolved declaration; the package's
      // package.json on disk is a second copy that a lockfile-only run has not
      // fetched and cannot check.
      return { name, version: resolvedVersion, ...classifyLicense(entry?.license) };
    })
    .sort((a, b) => a.name.localeCompare(b.name));
}

// ── derived requirement values ──────────────────────────────────────────────

// The c8ctl floor lives in exactly one place — MIN_C8CTL_VERSION in
// check-c8ctl-version.cjs — so read it from that file's source rather than
// restating it. (That script has no `require.main` guard and reads stdin on
// load, so it cannot be required.) Returns null if the constant is not found.
function parseMinC8ctlVersion(source) {
  return String(source || '').match(/MIN_C8CTL_VERSION\s*=\s*['"]([^'"]+)['"]/)?.[1] ?? null;
}

// The Maven wrapper pins an exact distribution by URL:
// ".../apache-maven-3.9.16-bin.zip" → "3.9.16". Lazy so a multi-dash qualifier
// (apache-maven-4.0.0-beta-5-bin.zip → "4.0.0-beta-5") comes through whole.
function parseMavenDistributionVersion(url) {
  return String(url || '').match(/apache-maven-([\w.-]+?)-bin/)?.[1] ?? null;
}

// Hostname of an absolute URL, or null when absent/unparseable. Used to derive
// download hosts from real URLs instead of restating them.
function hostFromUrl(url) {
  try {
    return new URL(String(url)).hostname;
  } catch {
    return null;
  }
}

// Assemble the `plugins` section. c8ctl's floor comes from
// check-c8ctl-version.cjs; npm-delivered bpmnlint plugin versions are looked up
// in the already-resolved npm tree so the version is stated once, in `npm`.
function buildPluginSections({ c8ctlMinVersion, npm } = {}) {
  const npmPackages = new Map((npm || []).map((p) => [p.name, p]));
  return {
    c8ctl: {
      package: C8CTL_PACKAGE,
      min_version: c8ctlMinVersion ?? null,
      install: `npm install -g ${C8CTL_PACKAGE}`,
      source: 'check-c8ctl-version.cjs',
    },
    c8ctl_plugins: REQUIRED_C8CTL_PLUGINS.map((p) => ({ ...p })),
    // Version and licence both come from the already-resolved npm tree, so each
    // is stated once. A plugin delivered any other way has neither here.
    bpmnlint_plugins: BPMNLINT_PLUGINS.map((p) => {
      const pkg = p.delivery === 'npm' ? npmPackages.get(p.name) : undefined;
      return {
        ...p,
        version: pkg?.version ?? null,
        license: pkg?.license ?? null,
        license_note: pkg
          ? pkg.license_note
          : p.delivery === 'npm'
            ? LICENSE_NOTE_NOT_IN_TREE
            : LICENSE_NOTE_NOT_NPM,
      };
    }),
    discovery_plugins: { ...DISCOVERY_PLUGINS },
  };
}

// Copy the runtime-download table, filling in what the Maven wrapper's
// distributionUrl pins: the exact Maven version the generated project fetches and
// the host it comes from. Rows keep an empty `hosts` when the location is owned by
// c8ctl, Testcontainers, or the project — a consumer should render those as
// "resolved by <resolved_by>", not invent a URL.
function buildRuntimeDownloads({ mavenWrapper } = {}) {
  const url = mavenWrapper?.distributionUrl;
  const mavenHost = hostFromUrl(url);
  return RUNTIME_DOWNLOADS.map((d) => {
    const row = { ...d, hosts: [...d.hosts] };
    if (row.id === 'maven-distribution') {
      if (mavenHost) row.hosts = [mavenHost];
      row.version = parseMavenDistributionVersion(url);
    }
    return row;
  });
}

// Derive the deduplicated host allowlist from the download rows — the question an
// endpoint review actually asks. A host is `required` if any required download
// needs it. Sorted by host so the section stays diffable.
function deriveNetworkHosts(downloads) {
  const byHost = new Map();
  for (const d of downloads || []) {
    for (const host of d.hosts || []) {
      if (!byHost.has(host)) byHost.set(host, { host, protocol: 'https', required: false, used_by: [] });
      const entry = byHost.get(host);
      if (d.required) entry.required = true;
      if (!entry.used_by.includes(d.id)) entry.used_by.push(d.id);
    }
  }
  return [...byHost.values()].sort((a, b) => a.host.localeCompare(b.host));
}

// Assemble the final snapshot document. Timestamp-free: identical inputs →
// identical bytes, so the snapshot is diffable and a change means a dependency
// actually moved.
function assembleSnapshot({
  summary,
  javaDeps,
  javaPlugins = [],
  npm,
  mvnResolvedCount,
  mvnResolvedPluginCount = 0,
  mvnResolvedLicenseCount = 0,
  hasNullVersions,
  hasNullPluginVersions = false,
  c8ctlMinVersion = null,
}) {
  const java = summary.javaSpringBoot || {};
  const mavenWrapper = java.mavenWrapper ?? null;
  const tsEngines = summary.typescript?.engines ?? {};
  const tsPackageManager = summary.typescript?.packageManager ?? null;
  const runtimeDownloads = buildRuntimeDownloads({ mavenWrapper });

  return {
    camunda_client_map: summary.camundaClientMap ?? null,
    npm,
    java: {
      parent: java.parent ?? null,
      properties: java.properties ?? {},
      dependencies: javaDeps,
      plugins: javaPlugins,
      maven_wrapper: mavenWrapper,
      mvn_resolved_bom_managed_count: mvnResolvedCount,
      mvn_resolved_plugin_count: mvnResolvedPluginCount,
      mvn_resolved_license_count: mvnResolvedLicenseCount,
      // mvn was either not needed (nothing came in null) or demonstrably ran.
      mvn_available:
        mvnResolvedCount > 0
        || mvnResolvedPluginCount > 0
        || (!hasNullVersions && !hasNullPluginVersions),
    },
    typescript: {
      engines: tsEngines,
      package_manager: tsPackageManager,
      dependencies: summary.typescript?.dependencies ?? [],
      devDependencies: summary.typescript?.devDependencies ?? [],
    },
    python: {
      requires_python: summary.python?.requiresPython ?? null,
      dependencies: summary.python?.dependencies ?? [],
      devDependencies: summary.python?.devDependencies ?? [],
    },
    plugins: buildPluginSections({ c8ctlMinVersion, npm }),
    runtime_downloads: runtimeDownloads,
    network_hosts: deriveNetworkHosts(runtimeDownloads),
  };
}

// ── main (CLI pipeline) ─────────────────────────────────────────────────────
function main() {
  // ── argv ──────────────────────────────────────────────────────────────────
  const argv = process.argv.slice(2);
  let WORK_DIR = '.camunda/dep-snapshot';
  let OUT = null;
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--work-dir') { WORK_DIR = argv[++i]; continue; }
    if (argv[i] === '--out') { OUT = argv[++i]; continue; }
    console.error(`emit-dep-snapshot: unknown arg ${argv[i]}`);
    process.exit(2);
  }

  // Scripts trust process.cwd() as the project root; they never search upward.
  const PROJECT_ROOT = process.cwd();
  const WORK = path.resolve(PROJECT_ROOT, WORK_DIR);
  const ARTIFACTS = path.join(WORK, 'artifacts');
  const SUMMARY_PATH = path.join(WORK, 'scaffold-summary.json');
  const LOCKFILE = path.join(PROJECT_ROOT, 'package-lock.json');
  const SCAFFOLD_SCRIPT = path.join(
    PROJECT_ROOT,
    'skills',
    'process-os-artifact-generation',
    'scripts',
    'scaffold-workers.cjs',
  );

  if (!fs.existsSync(SCAFFOLD_SCRIPT)) {
    console.error(`emit-dep-snapshot: missing ${SCAFFOLD_SCRIPT} (are you running from the process-os root?)`);
    process.exit(2);
  }

  // ── 1. resolve npm tree ───────────────────────────────────────────────────
  // --package-lock-only avoids populating node_modules/; the lockfile carries
  // the resolved versions we care about. --ignore-scripts is defence-in-depth
  // against a transitive dep running a postinstall on a CI runner.
  {
    const step = runNpmLockfileOnly(PROJECT_ROOT);
    if (!step.ok) {
      console.error(`emit-dep-snapshot: ${step.message}`);
      process.exit(step.code);
    }
  }

  // ── 2. scaffold + emit summary ────────────────────────────────────────────
  fs.mkdirSync(ARTIFACTS, { recursive: true });

  // scaffold-workers.cjs requires <artifactRoot>/.manifest.json with meta fields
  // it interpolates into package paths. Values here are inert — the summary reads
  // the blueprint sources, so the process name never affects dependency output.
  fs.writeFileSync(
    path.join(ARTIFACTS, '.manifest.json'),
    JSON.stringify(
      { meta: { packageBase: 'com.example.depsnapshot', processSlug: 'sample-process', processCamel: 'SampleProcess' } },
      null,
      2,
    ) + '\n',
  );

  {
    const step = runScaffoldSummary(
      SCAFFOLD_SCRIPT,
      [ARTIFACTS, '--summary', SUMMARY_PATH],
      PROJECT_ROOT,
    );
    if (!step.ok) {
      console.error(`emit-dep-snapshot: ${step.message}`);
      process.exit(step.code);
    }
  }

  if (!fs.existsSync(SUMMARY_PATH)) {
    console.error(`emit-dep-snapshot: scaffold-workers did not write ${SUMMARY_PATH}`);
    process.exit(3);
  }
  const summary = JSON.parse(fs.readFileSync(SUMMARY_PATH, 'utf8'));
  const java = summary.javaSpringBoot || {};
  const javaDeps = Array.isArray(java.dependencies) ? java.dependencies : [];
  const javaPlugins = Array.isArray(java.plugins) ? java.plugins : [];

  // Fail fast rather than emit a silently-unusable snapshot: the Camunda client
  // map is a required section (comes from versions.json via the summary).
  if (!clientMapUsable(summary)) {
    console.error('emit-dep-snapshot: summary carried no camundaClientMap (versions.json missing/corrupt or --summary contract regressed)');
    process.exit(3);
  }

  const POM = path.join(ARTIFACTS, 'pom.xml');
  if (!fs.existsSync(LOCKFILE) || !fs.existsSync(POM)) {
    console.error(`emit-dep-snapshot: expected outputs missing (lockfile=${LOCKFILE}, pom=${POM})`);
    process.exit(3);
  }

  // ── 3. parent-managed version resolution via mvn ──────────────────────────
  // Two goals, two goals-worth of mvn: `dependency:list` resolves BOM-managed
  // DEPS, `dependency:resolve-plugins` resolves pluginManagement-managed BUILD
  // PLUGINS (which never appear in dependency:list). Each runs only when the
  // summary actually left nulls behind. If mvn is unavailable, the nulls stay —
  // a consumer can render "(managed by <parent.groupId>:<parent.artifactId>:
  // <parent.version>)".
  let mvnResolvedCount = 0;
  let mvnResolvedPluginCount = 0;
  const hasNullVersions = javaDeps.some((d) => d.version == null);
  const hasNullPluginVersions = javaPlugins.some((p) => p.version == null);
  if (hasNullVersions) {
    const mvn = runMvnDependencyList(POM);
    if (mvn.stdout) {
      mvnResolvedCount = stampBomManagedVersions(javaDeps, parseMvnResolvedVersions(mvn.stdout));
    }
    if (mvn.note) console.error(`emit-dep-snapshot: ${mvn.note}`);
  }
  if (hasNullPluginVersions) {
    const mvn = runMvnDependencyResolvePlugins(POM);
    if (mvn.stdout) {
      mvnResolvedPluginCount = stampBomManagedVersions(javaPlugins, parseMvnResolvedPluginVersions(mvn.stdout));
    }
    if (mvn.note) console.error(`emit-dep-snapshot: ${mvn.note}`);
  }

  // ── 3b. java licences via mvn ─────────────────────────────────────────────
  // Unconditional, unlike the two version goals above: a dep with a concrete
  // version still has no licence until the third-party report is read. Every
  // dep is stamped either way, so the reason a licence is null — mvn absent vs.
  // the dep declaring none — stays visible in its own note.
  let mvnResolvedLicenseCount = 0;
  const licenses = runMvnLicenses(POM);
  if (licenses.ok) {
    const report = path.join(ARTIFACTS, MAVEN_THIRD_PARTY_REPORT);
    let text = null;
    try {
      text = fs.readFileSync(report, 'utf8');
    } catch {
      console.error(`emit-dep-snapshot: ${MAVEN_LICENSE_PLUGIN} reported success but wrote no ${report} — java licenses left unresolved`);
    }
    mvnResolvedLicenseCount = stampMavenLicenses(
      javaDeps,
      text == null ? new Map() : parseThirdPartyLicenses(text),
      text == null ? LICENSE_NOTE_NO_REPORT : LICENSE_NOTE_NOT_IN_REPORT,
    );
  } else {
    stampMavenLicenses(javaDeps, new Map(), LICENSE_NOTE_MVN_UNAVAILABLE);
    console.error(`emit-dep-snapshot: ${licenses.note}`);
  }

  // ── 4. npm — declared top-level deps → resolved versions ──────────────────
  const lock = JSON.parse(fs.readFileSync(LOCKFILE, 'utf8'));
  let npm;
  try {
    npm = resolveNpmTopLevel(lock);
  } catch (err) {
    console.error(`emit-dep-snapshot: ${err.message}`);
    process.exit(3);
  }

  // ── 5. c8ctl floor — read from its single source of truth ─────────────────
  // Non-fatal: a missing/renamed constant yields `plugins.c8ctl.min_version:
  // null` rather than killing the whole snapshot, but it is worth a warning
  // because it means the check script moved.
  const C8CTL_CHECK = path.join(PROJECT_ROOT, 'shared', 'scripts', 'check-c8ctl-version.cjs');
  let c8ctlMinVersion = null;
  try {
    c8ctlMinVersion = parseMinC8ctlVersion(fs.readFileSync(C8CTL_CHECK, 'utf8'));
  } catch { /* handled below */ }
  if (!c8ctlMinVersion) {
    console.error(`emit-dep-snapshot: could not read MIN_C8CTL_VERSION from ${C8CTL_CHECK} — plugins.c8ctl.min_version will be null`);
  }

  // ── 6. emit ───────────────────────────────────────────────────────────────
  const snapshot = assembleSnapshot({
    summary,
    javaDeps,
    javaPlugins,
    npm,
    mvnResolvedCount,
    mvnResolvedPluginCount,
    mvnResolvedLicenseCount,
    hasNullVersions,
    hasNullPluginVersions,
    c8ctlMinVersion,
  });

  const json = JSON.stringify(snapshot, null, 2) + '\n';
  if (OUT) {
    const outPath = path.resolve(PROJECT_ROOT, OUT);
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    fs.writeFileSync(outPath, json);
    console.error(`emit-dep-snapshot: wrote ${outPath}`);
  } else {
    process.stdout.write(json);
  }
}

module.exports = {
  runNpmLockfileOnly,
  runScaffoldSummary,
  runMvnDependencyList,
  runMvnDependencyResolvePlugins,
  parseMvnResolvedVersions,
  parseMvnResolvedPluginVersions,
  stampBomManagedVersions,
  classifyLicense,
  LICENSE_NOTE_FILE_REF,
  LICENSE_NOTE_NONE,
  runMvnLicenses,
  parseThirdPartyLicenses,
  stampMavenLicenses,
  clientMapUsable,
  resolveNpmTopLevel,
  parseMinC8ctlVersion,
  parseMavenDistributionVersion,
  hostFromUrl,
  buildPluginSections,
  buildRuntimeDownloads,
  deriveNetworkHosts,
  assembleSnapshot,
};

if (require.main === module) {
  main();
}
