/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

/**
 * run-config-build.cjs — build and serialize a `run.config.yaml` from schema defaults
 * plus optional overrides.
 *
 * This is the WRITE side of the schema in `run-config-schema.cjs` (that file is
 * read-only: defaults + which keys are non-scalar). Two call shapes matter:
 *   - process-os-project-initialization's generator merges genuine form/env overrides
 *     into the defaults (buildRunConfig({tech: {...}})) before writing process-scope.md
 *     alongside it — that pairing is why the CLI for that shape lives in
 *     generate-scope-and-config.cjs, not here.
 *   - Any skill that just needs a `run.config.yaml` to exist before it can read one
 *     (e.g. a from-scratch discovery run with no prior project-initialization) wants
 *     schema defaults and nothing else. This file's own CLI below covers exactly that,
 *     without depending on another skill's script.
 *
 * Kept out of run-config-schema.cjs itself: serializeRunConfig needs yaml.cjs, and three
 * of run-config-schema.cjs's four importers (resolve-camunda-version.cjs,
 * resolve-target-sdk.cjs, resolve-bpmn-mode.cjs) only want RUN_DEFAULTS — folding the
 * YAML dependency in would drag it into all of their require graphs.
 */

const fs = require('node:fs');
const path = require('node:path');
// Sibling imports round-trip via '../..' so the bundler's closure sees the literal
// path; see the matching comment in read-run-config.cjs.
const yaml = require(path.join(__dirname, 'yaml.cjs'));
const { RUN_DEFAULTS, ALL_KEYS, LIST_KEYS, BLOCK_KEYS, KEY_MAP, typeOf } = require(
  path.join(__dirname, 'run-config-schema.cjs'),
);

// The file records decisions and nothing else. It carries no commented-out keys: making a
// setting take effect by uncommenting a line puts the mechanism in the punctuation, where a
// stray `#` silently reverts a choice and a diff cannot show intent. Every unset key
// resolves to its schema default when read, so an absent line is already the complete and
// unambiguous way to say "not decided".
//
// The header names NO script path, and must not. This text is written into a project's
// run.config.yaml, and no path is correct in both trees: here the readers live in the shared
// scripts directory, while the bundler rewrites that prefix away when it copies them into each
// consuming skill — so a path written here reached the user as a bare filename that resolves
// nowhere from their project root. `--list` and `--set` are documented outside this header,
// where a path can stay accurate.
const RUN_CONFIG_HEADER =
  '# run.config.yaml — technical run config. Edit in-repo as needed.\n' +
  '# Only decided keys appear here; anything absent resolves to its schema default.\n';

function oneLine(v) {
  return String(v).trim().replace(/\s+/g, ' ');
}

// Normalise a list-ish value to a clean string[]. Every item is collapsed to a single
// line, so no item can break out of its markdown bullet or need YAML quoting.
//
// `commas: true` additionally splits a plain string on commas. That is a
// SPECIALISTS-ONLY shape — the interactive init path hands specialists over
// comma-joined. Free text (KPIs, pain points, transformation topics) must NOT be
// comma-split: "reduce handoffs, especially in finance" is one item, not two.
function asList(v, { commas = false } = {}) {
  if (v == null) return [];
  if (Array.isArray(v)) {
    return v
      .map((it) => (it && typeof it === 'object' ? (it.value ?? it.label ?? '') : it))
      .map((s) => oneLine(s))
      .filter(Boolean);
  }
  return String(v)
    .split(commas ? /[\n,]/ : /\n/)
    .map((s) => oneLine(s.replace(/^[-*]\s*/, '')))
    .filter(Boolean);
}

// Map a schema `type` onto the JS typeof it coerces toward. 'list' and 'block' are both
// objects to coerceToType, which only needs to know that they are not scalars.
const TYPE_TO_TYPEOF = {
  string: 'string',
  number: 'number',
  boolean: 'boolean',
  list: 'object',
  block: 'object',
};

// Coerce `v` toward a declared type — the schema is the type authority, because overrides
// arrive from env vars (always strings) and form-shaped JSON, where a number may show up
// as "8" and a boolean as "false". Only unambiguous literals are converted; anything else
// is returned unchanged, since Number('many') would put `.nan` in the file and a guessed
// boolean is worse than a visible bad value. An undeclared type (an unknown passthrough
// key) leaves the value exactly as given.
//
// Typed separately from the default because a key may declare a type and no default —
// `typeof undefined` would then coerce nothing.
function coerceToType(want, v, key) {
  // A scalar key can never accept an array/object override: writing one through
  // unchanged would emit a YAML node of the wrong shape for that key, silently
  // corrupting the file's structure rather than just its value.
  if (want !== 'object' && v !== null && typeof v === 'object') {
    const err = new Error(
      `Override for '${key}' must be a scalar, got ${Array.isArray(v) ? 'an array' : 'an object'}`,
    );
    err.code = 'INVALID_OVERRIDE_SHAPE';
    throw err;
  }
  if (want === typeof v) return v;
  if (want === 'number') {
    const s = String(v).trim();
    return /^-?\d+(\.\d+)?$/.test(s) ? Number(s) : v;
  }
  if (want === 'boolean') {
    const s = String(v).trim();
    if (/^true$/i.test(s)) return true;
    if (/^false$/i.test(s)) return false;
    return v;
  }
  // A number override for a string-typed key (e.g. camunda-version) is refused rather
  // than stringified: by the time it reaches here, JSON.parse has already collapsed a
  // trailing-zero literal like 8.10 into 8.1, so String(v) would faithfully re-quote
  // the wrong value. Callers must pass string-typed overrides as JSON strings.
  if (want === 'string' && typeof v === 'number') {
    const err = new Error(
      `Override for '${key}' must be a JSON string, not a number — a numeric literal like ` +
        '8.10 is silently collapsed to 8.1 by JSON.parse before this point',
    );
    err.code = 'INVALID_OVERRIDE_SHAPE';
    throw err;
  }
  if (want === 'string' && typeof v === 'boolean') return String(v);
  return v;
}

// Coerce toward the type a default value implies. Retained for callers that hold a
// default rather than a key — coerceToType is what the schema-driven path uses.
function coerceTo(def, v, key) {
  return coerceToType(def === undefined ? undefined : typeof def, v, key);
}

// The declared typeof for a key, falling back to whatever its default implies so an
// unknown passthrough key still coerces the way it always did.
function typeofFor(key) {
  const declared = typeOf(key);
  if (declared) return TYPE_TO_TYPEOF[declared];
  return RUN_DEFAULTS[key] === undefined ? undefined : typeof RUN_DEFAULTS[key];
}

// An override that carries no value is not an override: an unset env var arrives as '',
// which means "unspecified", not "set this key to empty".
function isBlank(v) {
  return typeof v === 'string' && !v.trim();
}

/**
 * Map a form-shaped override object onto the `tech` shape buildRunConfig reads.
 *
 * A Camunda form key cannot contain a hyphen, so a form offering a hyphenated
 * run-configuration key spells it with underscores; KEY_MAP carries the pairs that are
 * not a plain underscore-to-hyphen swap, and a lookup miss falls through to the key
 * itself. That is what lets a caller hand over a whole form group verbatim instead of
 * assembling a renamed context itself.
 *
 * `specialistsBuiltin` (a closed checklist over the built-in specialists) and
 * `specialistsExtra` (an open dynamiclist of extra names) collapse into the single flat
 * `specialists` list run.config.yaml expects. Both go through asList, which normalises
 * `{value, label}` dynamiclist rows and trims each entry, so ' sap' and 'sap' dedupe here
 * rather than reappearing as a literal duplicate once buildRunConfig trims them later.
 * The collapse only fires when at least one of the two keys is present — the interactive
 * init path's flat `specialists` string carries neither and passes through untouched.
 *
 * Unknown keys pass through verbatim; rejecting them here would fail a job over a form
 * field, so the guard against a stray key living in a form's runConfig group is a test
 * over the forms rather than a runtime error.
 *
 * @param {Record<string, unknown> | null | undefined} formOverrides
 * @returns {Record<string, unknown>}
 */
function toTechOverrides(formOverrides) {
  const tc = formOverrides || {};
  const overrides = {};
  for (const [formKey, value] of Object.entries(tc)) {
    if (formKey === 'specialistsBuiltin' || formKey === 'specialistsExtra') continue;
    overrides[KEY_MAP[formKey] || formKey] = value;
  }
  if ('specialistsBuiltin' in tc || 'specialistsExtra' in tc) {
    const builtin = asList(tc.specialistsBuiltin);
    const extra = asList(tc.specialistsExtra);
    overrides.specialists = [...new Set([...builtin, ...extra])];
  }
  return overrides;
}

/**
 * The keys an input actually provides — the ones that survive the null/blank filter
 * buildRunConfig applies. This is what makes a written file sparse: an effective value
 * exists for every declared key, but only a decided one is worth recording.
 *
 * @param {{tech?: Record<string, unknown>}} input
 * @returns {Set<string>}
 */
function providedKeys(input) {
  const tech = (input && input.tech) || {};
  const provided = new Set();
  for (const [k, v] of Object.entries(tech)) {
    if (v == null || isBlank(v)) continue;
    provided.add(k);
  }
  return provided;
}

function buildRunConfig(input) {
  const tech = (input && input.tech) || {};
  const cfg = { ...RUN_DEFAULTS };
  // Copy every non-scalar default so a returned config never aliases RUN_DEFAULTS —
  // a caller mutating cfg.specialists or a gate block must not poison later calls.
  for (const k of LIST_KEYS) cfg[k] = [...RUN_DEFAULTS[k]];
  for (const k of BLOCK_KEYS) cfg[k] = { ...RUN_DEFAULTS[k] };
  for (const [k, v] of Object.entries(tech)) {
    if (v == null || isBlank(v)) continue;
    if (LIST_KEYS.includes(k)) cfg[k] = asList(v, { commas: k === 'specialists' });
    // A gate override MERGES onto the defaults leaf-wise: consumers read the leaves
    // individually (read-run-config.cjs processDiscoveryGate.md), so a partial block
    // like {questions: false} must keep md/nonMd at their defaults rather than drop
    // them — an absent leaf reads as "not configured", not as the default value.
    else if (BLOCK_KEYS.includes(k)) {
      // Total in the block case: a gate is a mapping of leaves, so anything else is a
      // structural error rather than a value. Falling through to the scalar path would
      // write the scalar in place of the mapping, after which every leaf read resolves to
      // its schema default because the block is no longer a block.
      if (!v || typeof v !== 'object' || Array.isArray(v)) {
        const err = new Error(
          `Override for '${k}' must be a mapping of leaves, got ` +
            `${Array.isArray(v) ? 'an array' : `a ${typeof v}`}`,
        );
        err.code = 'INVALID_OVERRIDE_SHAPE';
        throw err;
      }
      const merged = { ...cfg[k] };
      for (const [leaf, lv] of Object.entries(v)) {
        if (lv == null || isBlank(lv)) continue;
        // The block's declared leaves are its schema. An undeclared one is written into a
        // shape every reader walks by name, so it would sit in the file consulted by
        // nothing — kept out here so no caller has to filter first.
        if (!Object.hasOwn(cfg[k], leaf)) continue;
        merged[leaf] = coerceTo(cfg[k][leaf], lv, `${k}.${leaf}`);
      }
      cfg[k] = merged;
    } else cfg[k] = coerceToType(typeofFor(k), v, k);
  }
  return cfg;
}

// Serialize only the keys the input provides. buildRunConfig still resolves the EFFECTIVE
// config — every declared key, defaults included — because that is what a consumer asking
// "what is this project's mode?" needs. The file records decisions, so a key nobody has
// decided is simply absent rather than written as a line asserting a choice. Reading it
// resolves to the same value either way, via read-run-config.cjs's schema fallback.
//
// A provided block key writes its MERGED value, not just the submitted leaves: consumers
// read gate leaves individually, and an absent leaf reads as "not configured" rather than
// as the default.
/**
 * Force the yaml dependency to load, so a missing one surfaces as DEPS_MISSING before a
 * caller writes anything.
 *
 * A decision-only file with nothing decided serialises to its header alone, without
 * touching yaml — so a caller that relies on `serializeRunConfig` to surface the missing
 * dependency is told the file was written and then fails on the first read. Callers that
 * can legitimately write an empty config call this first.
 *
 * @throws {Error} code DEPS_MISSING when the project's Node deps are not installed.
 */
function assertYamlAvailable() {
  yaml.stringify({ probe: true });
}

function serializeRunConfig(input) {
  const effective = buildRunConfig(input);
  const provided = providedKeys(input);
  const cfg = {};
  // Declaration order first, so the generated file is stable; then any unknown
  // passthrough key the caller supplied, which has no declared position.
  for (const key of ALL_KEYS) if (provided.has(key)) cfg[key] = effective[key];
  for (const key of provided) if (!Object.hasOwn(cfg, key)) cfg[key] = effective[key];
  const body = Object.keys(cfg).length ? yaml.stringify(cfg) : '';
  return RUN_CONFIG_HEADER + body;
}

module.exports = {
  asList,
  toTechOverrides,
  oneLine,
  coerceTo,
  coerceToType,
  isBlank,
  providedKeys,
  buildRunConfig,
  serializeRunConfig,
  assertYamlAvailable,
};

if (require.main === module) {
  const CONFIG_FILE = 'run.config.yaml';
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      process.stderr.write(
        `Refusing to overwrite existing ${CONFIG_FILE}. Delete it first if you want it ` +
          're-materialized, or use apply-run-config.cjs to merge into it.\n',
      );
      process.exit(4);
    }
    // This CLI exists so a project can READ its config, and it writes a file with nothing
    // decided — exactly the case that never reaches yaml on its own.
    assertYamlAvailable();
    fs.writeFileSync(CONFIG_FILE, serializeRunConfig({}));
    process.stdout.write(`Wrote ${CONFIG_FILE}\n`);
  } catch (e) {
    if (e.code === 'DEPS_MISSING') {
      process.stderr.write(e.message + '\n');
      process.exit(2);
    }
    throw e;
  }
}
