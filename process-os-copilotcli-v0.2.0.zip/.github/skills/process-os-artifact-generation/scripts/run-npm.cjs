#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Run npm scripts in a project directory.
//
// A `( cd <dir> && npm install && npm run build )` shell chain breaks on native
// Windows in three separate ways: the `cd X && Y` subshell chain, the `&&`
// chain itself (a parse error in PowerShell 5.1), and a bare `npm`, which
// exists only as `npm.cmd` and so cannot be spawned without a shell.
//
// The command literal stays `npm` and the shell decision belongs to
// `runShellCli`, which applies one on Windows only. "Is it on PATH" is settled
// first with `findOnPath` — pure Node, no shell — so a real absence stays
// distinguishable from a shell's own failure exit.
//
// npm ships bundled with Node, and every skill in this repo already requires
// Node to run its own .cjs scripts, so a missing npm is never a legitimate
// toolchain gap. That is why there is no "skip when the toolchain is absent"
// path here, unlike run-maven.cjs, where a Node-only sandbox can genuinely lack
// a JDK.
//
// The working directory of the calling process is never changed: the project
// directory is passed to the child as its `cwd`.
//
// Usage:
//   node "run-npm.cjs" <project-dir> <npm-arg>...
//
// npm's own output is inherited, and its exit code is this script's, so a caller
// gates on the build exactly as it would on the command line.
//
// Exit codes:
//   0    npm succeeded
//   2    usage error, npm unavailable, or npm could not be started at all — in
//        none of those did anything run, so this is never a green build
//   else npm's own exit code

const fs = require('fs');
const { findOnPath, runShellCli } = require('./resolve-node-cli.cjs');

const EXIT = { OK: 0, DID_NOT_RUN: 2 };

const USAGE = 'usage: run-npm.cjs <project-dir> <npm-arg>...\n';

/**
 * Run npm.
 *
 * @param {string} dir Project directory; becomes the child's cwd.
 * @param {string[]} args npm arguments, passed through verbatim.
 * @param {object} [deps]
 * @param {typeof runShellCli} [deps.runShell] Injectable runner, for tests.
 * @param {typeof findOnPath} [deps.onPath] Injectable PATH probe, for tests.
 * @returns {{status: number, message: string|null, command: string}}
 */
function runNpm(dir, args, deps = {}) {
  const runShell = deps.runShell || runShellCli;
  const onPath = deps.onPath || findOnPath;

  if (!onPath('npm')) {
    return {
      status: EXIT.DID_NOT_RUN,
      message: `no npm on PATH — nothing ran in ${dir}. npm ships with Node, so this is a broken Node install rather than a missing toolchain.`,
      command: 'npm',
    };
  }

  const result = runShell('npm', args, { cwd: dir, stdio: 'inherit' });
  if (!result.launched) {
    return {
      status: EXIT.DID_NOT_RUN,
      message: `npm could not be started: ${
        result.error ? result.error.message : 'no exit status'
      }`,
      command: 'npm',
    };
  }
  return { status: result.status, message: null, command: 'npm' };
}

module.exports = { EXIT, runNpm };

if (require.main === module) {
  const [dir, ...args] = process.argv.slice(2);
  if (!dir || args.length === 0) {
    process.stderr.write(USAGE);
    process.exit(EXIT.DID_NOT_RUN);
  }
  if (!fs.existsSync(dir)) {
    process.stderr.write(`Project directory not found: ${dir}\n`);
    process.exit(EXIT.DID_NOT_RUN);
  }
  const { status, message } = runNpm(dir, args);
  if (message) process.stderr.write(`${message}\n`);
  process.exit(status);
}
