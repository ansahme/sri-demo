/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Compare two strings with embedded numbers read as numbers, so `round9` sorts
// before `round10` and `iteration-2` sorts before `iteration-10`.
//
// Plain text order compares digit-by-digit as characters, so `round10` sorts
// before `round9` — wrong wherever the result is read as "the newest" or "the
// highest" entry in a list.

/**
 * @param {string} a Left string.
 * @param {string} b Right string.
 * @param {boolean} [ignoreCase] Compare non-numeric segments without regard to
 *   case. Without this, two segments equal under case-insensitive comparison
 *   would still be ordered by their raw case — contradicting the request to
 *   ignore it.
 * @returns {number} Negative, zero or positive, for Array#sort.
 */
function naturalCompare(a, b, ignoreCase = false) {
  const left = a.match(/\d+|\D+/g) ?? [];
  const right = b.match(/\d+|\D+/g) ?? [];
  for (let i = 0; i < Math.max(left.length, right.length); i++) {
    const l = left[i];
    const r = right[i];
    // A prefix sorts before the longer string it starts.
    if (l === undefined) return -1;
    if (r === undefined) return 1;
    if (/^\d/.test(l) && /^\d/.test(r)) {
      const diff = Number(l) - Number(r);
      if (diff !== 0) return diff;
      // Equal in value but written differently (`01` vs `1`). Falling through
      // as a tie would leave the pair in whatever order the caller already had
      // them in; comparing the text instead makes this a total order.
      if (l !== r) return l < r ? -1 : 1;
    } else {
      const lc = ignoreCase ? l.toLowerCase() : l;
      const rc = ignoreCase ? r.toLowerCase() : r;
      if (lc !== rc) return lc < rc ? -1 : 1;
    }
  }
  return 0;
}

module.exports = { naturalCompare };
