/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

/**
 * run-config-schema.cjs — the run.config.yaml schema.
 *
 * THE single place a run-configuration key is declared. Each entry names the key's
 * `type`, and a `default` where one applies. Every end of the file's life reads it here:
 *   - run-config-build.cjs uses `type` to coerce incoming overrides (env vars are always
 *     strings, form JSON turns a number into "8" and a boolean into "false") and to
 *     decide which keys are lists or blocks.
 *   - generate-scope-and-config.cjs writes provided values into a new run.config.yaml.
 *   - read-run-config.cjs serves `default` when the project's run.config.yaml has no
 *     entry for the key — which is what makes an existing project forward-compatible
 *     with a knob added by a later ProcessOS version.
 *   - resolve-camunda-version.cjs and resolve-target-sdk.cjs take their default here.
 *
 * Adding a knob means adding one line here — every reader picks it up, and no call site
 * restates the default (which is how defaults silently diverge).
 *
 * `type` is declared even for a key with no `default`, because coercion needs the type
 * and a default is not the only place to state it.
 *
 * A key carries a `default` when a consumer must have a value and no human is asked for
 * one. A key OMITS it when "unset" is semantically distinct from every concrete value:
 *   - `width`/`depth` derive from `size` when unset, so there is no literal to serve. A
 *     submitted `auto` removes the key instead of recording it (see AUTO_KEYS below).
 *   - `bpmn-mode` is defaulted PER CONSUMER, which a shared default cannot express. An
 *     entry here would be served to every reader — including process-os-bpmn-generation,
 *     whose "Specify a mode" hard error would then become unreachable. Its `automatable`
 *     fallback lives in process-os-process-transformation's scripts/resolve-bpmn-mode.cjs,
 *     which reads the file with resolveKey (no defaults) rather than resolveWithDefault.
 *   - `source` is an optional input-dir default read only by process-os-bpmn-generation;
 *     absent means "use the flag's own default", which a served value would erase.
 *   - `transformation-tier` has the same shape as `bpmn-mode`: an entry here would be
 *     served to every reader, making the resolver's interactive-prompt path unreachable.
 *     Its resolution (args > this key > an unattended-mode fallback) lives in
 *     process-os-process-transformation's scripts/resolve-run-tier.cjs, which also reads
 *     the file with resolveKey rather than resolveWithDefault.
 *
 * If a key's form field differs from a plain underscore-to-hyphen swap of its name, add
 * the matching entry to KEY_MAP below in the same change.
 */

// type: 'string' | 'number' | 'boolean' | 'list' | 'block'
const RUN_SCHEMA = {
  'mode': { type: 'string', default: 'interactive' },
  'specialists': { type: 'list', default: ['web', 'filesystem', 'github'] },
  'max-research-rounds': { type: 'number', default: 5 },
  'camunda-version': { type: 'string', default: '8.10' },
  'target-sdk': { type: 'string', default: 'java-spring-boot' },
  'package-group': { type: 'string', default: 'com.example' },
  'source-mode': { type: 'string', default: 'hint' },
  'decomposition': { type: 'string', default: 'per-phase' },
  'edge-cases': { type: 'string', default: 'standalone' },
  'transformation-aggressiveness': { type: 'number', default: 2 },
  'transformation-topics': { type: 'list', default: [] },
  'transformation-tier': { type: 'string' },
  'size': { type: 'string', default: 'auto' },
  'skip-review': { type: 'boolean', default: false },
  'skip-provenance': { type: 'boolean', default: false },
  'skip-bpmn-docs': { type: 'boolean', default: false },
  'compact-specialists': { type: 'boolean', default: false },
  'processDiscoveryGate': { type: 'block', default: { questions: true, md: true, nonMd: true } },
  'processTransformationGate': { type: 'block', default: { questions: true, md: true, nonMd: true } },
  'width': { type: 'string' },
  'depth': { type: 'string' },
  'bpmn-mode': { type: 'string' },
  'source': { type: 'string' },
};

// Every declared key, in declaration order. The serializer writes in this order so the
// generated file is stable across runs.
const ALL_KEYS = Object.keys(RUN_SCHEMA);

// The grammar a `package-group` value must satisfy, and so must the packageBase built from
// it: dot-separated segments, each an identifier starting with a letter.
//
// Declared beside the key because it has two enforcement points that must not drift — the
// implementation-phase governance form carries it as its field's `validate.pattern`, and
// process-os-artifact-generation's scaffold-workers.cjs checks the derived packageBase
// against it. governance-config-forms-parity.test.cjs asserts the form still carries this
// exact string. A string rather than a RegExp because the form JSON needs one, and a
// literal re-typed there is how the two would silently come apart.
const PACKAGE_GROUP_PATTERN = '^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)*$';

/**
 * True when `value` is a dot-separated chain of identifier segments — the shape a Java
 * package declaration, a Maven `<groupId>` and a source directory chain all need.
 *
 * @param {unknown} value
 * @returns {boolean}
 */
function isPackageName(value) {
  return typeof value === 'string' && new RegExp(PACKAGE_GROUP_PATTERN).test(value);
}

// The sizing scale `size`, `width` and `depth` share, and the exact option values the
// governance forms' sizing dropdowns offer (governance-config-forms-parity.test.cjs asserts
// both forms against this list). `auto` comes first because it is every dropdown's default.
const SIZE_VALUES = ['auto', 's', 'm', 'l', 'xl'];

// The value that hands a sizing key back to automatic resolution.
const AUTO = 'auto';

// The keys for which a submitted AUTO means "not decided": apply-run-config.cjs removes the key
// from run.config.yaml rather than recording it. This is how a form clears an explicit value an
// earlier iteration set, since a null or blank value never clears a key. For `width`/`depth`
// an absent key is the only way to say "derive from `size`"; for `size` removal is
// equivalent to recording `auto`, because `auto` is its schema default, and treating all
// three alike keeps the file a record of decisions only.
const AUTO_KEYS = ['size', 'width', 'depth'];

/**
 * True when `value` is AUTO for a key in AUTO_KEYS — a request to remove that key.
 * Case and surrounding whitespace are ignored, so `--set width=Auto` behaves like the form.
 *
 * @param {string} key A run-configuration key (already through KEY_MAP).
 * @param {unknown} value
 * @returns {boolean}
 */
function isAutoReset(key, value) {
  return (
    AUTO_KEYS.includes(key) && typeof value === 'string' && value.trim().toLowerCase() === AUTO
  );
}

const hasDefault = (key) =>
  Object.hasOwn(RUN_SCHEMA, key) && Object.hasOwn(RUN_SCHEMA[key], 'default');

// The defaults-only view. Kept exported and shaped exactly as before so read-run-config.cjs,
// resolve-camunda-version.cjs, resolve-target-sdk.cjs and resolve-bpmn-mode.cjs read a plain
// {key: value} map and need no awareness of the entry shape. A key with no default is
// absent here, which is what makes those readers report it absent.
const RUN_DEFAULTS = Object.fromEntries(
  ALL_KEYS.filter(hasDefault).map((k) => [k, RUN_SCHEMA[k].default]),
);

// Derived from `type` rather than from a default's runtime shape, so a list or block key
// is still recognised when it carries no default, and so neither list is hand-restated.
const LIST_KEYS = ALL_KEYS.filter((k) => RUN_SCHEMA[k].type === 'list');
const BLOCK_KEYS = ALL_KEYS.filter((k) => RUN_SCHEMA[k].type === 'block');

// The keys with no schema default (see the file-level comment for why each is absent).
const NO_DEFAULT_KEYS = ALL_KEYS.filter((k) => !hasDefault(k));

// The total count of documented run.config.yaml keys. Kept as its own hand-maintained
// constant, NOT derived from ALL_KEYS.length, so a defaults-parity test still catches an
// addition or removal instead of silently following it — bump it by hand alongside the
// change, in the same commit.
const DOCUMENTED_KEY_COUNT = 23;

// Camunda form component keys are snake_case (hyphens are illegal in a form key and in a
// Zeebe variable name); run.config.yaml keys are the RUN_SCHEMA keys above. Only the keys
// that actually differ from a plain underscore-to-hyphen swap are listed — a lookup miss
// falls back to the key itself, which is what lets keys with no underscore (mode,
// specialists, decomposition, size, width, depth, source, processDiscoveryGate,
// processTransformationGate) pass through with no entry here. Kept beside RUN_SCHEMA so a
// new hyphenated key added there and this map cannot drift apart. run-config-build.cjs's
// toTechOverrides is the reader, for both the init path (generate-scope-and-config.cjs) and
// a governance form's `runConfig` job variable (apply-run-config.cjs). A key that is already
// run-configuration-shaped falls through unchanged, unless a row here retargets it:
// `max_iterations`, `max-iterations` and `max_research_rounds` are all retained aliases for
// `max-research-rounds`, so an in-flight governance form's field keeps resolving. A key already
// written into a project's run.config.yaml is a second surface this map does not reach on its
// own — a file read goes through canonicalizeKeys below.
const KEY_MAP = {
  max_iterations: 'max-research-rounds',
  'max-iterations': 'max-research-rounds',
  max_research_rounds: 'max-research-rounds',
  camunda_version: 'camunda-version',
  target_sdk: 'target-sdk',
  package_group: 'package-group',
  source_mode: 'source-mode',
  edge_cases: 'edge-cases',
  transformation_aggressiveness: 'transformation-aggressiveness',
  transformation_topics: 'transformation-topics',
  transformation_tier: 'transformation-tier',
  skip_review: 'skip-review',
  skip_provenance: 'skip-provenance',
  skip_bpmn_docs: 'skip-bpmn-docs',
  compact_specialists: 'compact-specialists',
  bpmn_mode: 'bpmn-mode',
};

/**
 * Rewrite a parsed run.config.yaml's top-level legacy key spellings to their canonical
 * ones, so a reader resolving a renamed key finds the value a project already recorded
 * under the old name instead of falling through to the schema default.
 *
 * KEY_MAP alone does not achieve this: its only other reader converts a governance
 * form's overrides, which never sees the file. A renamed key therefore needs both — the
 * map for an in-flight form, this for a project that recorded the old spelling.
 *
 * The canonical spelling wins when a file carries both, and only top-level keys are
 * rewritten, matching KEY_MAP's own shape.
 *
 * @param {Record<string, unknown>} obj Parsed run.config.yaml, or {}.
 * @returns {Record<string, unknown>} A new object; `obj` is not mutated.
 */
function canonicalizeKeys(obj) {
  if (obj == null || typeof obj !== 'object' || Array.isArray(obj)) return obj;
  const out = {};
  for (const [key, value] of Object.entries(obj)) {
    const canonical = Object.hasOwn(KEY_MAP, key) ? KEY_MAP[key] : key;
    // A legacy spelling never overwrites the canonical one, whichever order they appear
    // in: a file carrying both has already decided under the current name.
    if (canonical !== key && Object.hasOwn(obj, canonical)) continue;
    out[canonical] = value;
  }
  return out;
}

/**
 * The declared type of a key, or undefined for an unknown passthrough key.
 *
 * @param {string} key
 * @returns {'string'|'number'|'boolean'|'list'|'block'|undefined}
 */
function typeOf(key) {
  return Object.hasOwn(RUN_SCHEMA, key) ? RUN_SCHEMA[key].type : undefined;
}

module.exports = {
  RUN_SCHEMA,
  ALL_KEYS,
  PACKAGE_GROUP_PATTERN,
  isPackageName,
  SIZE_VALUES,
  AUTO,
  AUTO_KEYS,
  isAutoReset,
  RUN_DEFAULTS,
  LIST_KEYS,
  BLOCK_KEYS,
  NO_DEFAULT_KEYS,
  DOCUMENTED_KEY_COUNT,
  KEY_MAP,
  canonicalizeKeys,
  typeOf,
};
