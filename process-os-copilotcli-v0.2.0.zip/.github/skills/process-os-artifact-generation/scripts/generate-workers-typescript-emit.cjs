/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Pure emitters for the TypeScript worker layer. No fs, no process.exit, no
// requires — everything here maps manifest data to text, which is what makes the
// generated code unit-testable without a filesystem.
//
// The emitted text must satisfy the blueprint's compiler settings on the FIRST
// pass, because the build gate typechecks the generator's own output
// (blueprints/typescript/tsconfig.json:3-15). The load-bearing constraints:
//
//   verbatimModuleSyntax      a type-only import must say `import type`
//   module: NodeNext          a relative import must carry an explicit `.js`
//   exactOptionalPropertyTypes an optional property needs `| undefined` spelled out
//   strict                    no implicit any anywhere
//
// Two shapes that look like style choices but are not:
//
//   * Output and AppServices are `export type … = { … }`, NEVER an interface. TS
//     infers an implicit index signature for an object TYPE ALIAS but not for an
//     interface, and `job.complete(variables?: { [k: string]: any })` requires
//     one. An interface is a compile error on our own output.
//   * A zero-field object type is `Record<string, never>`, not `{}`, which the
//     blueprint's linter bans.
//
// Formatting matches biome.json: 2-space indent, 100-column width, double quotes,
// no semicolons — so a user's first `npm run check` is quiet. Verified against a
// real `biome check` on the shipped 17-job-type fixture: exit 0, zero findings.
// The build gate does not run the linter (mutating files mid-gate would make it
// non-idempotent), so formatting is a courtesy rather than a gate, but the width
// and semicolon rules are asserted in the unit tests to keep it from drifting.
// Two emitted shapes legitimately exceed 100 columns and biome accepts both as
// already-formatted (see renderImport's and renderWorker's own comments): a
// single-specifier import, and the malformed-input error message's template
// literal — biome treats each as atomic and won't split it regardless of width.
//
// Lines that must contain a backtick or `${…}` in the OUTPUT are built from
// quoted JS strings, never from nested template literals — a nested template
// silently interpolates at generation time instead of emitting the placeholder.

const LEGAL_IDENTIFIER = /^[A-Za-z_$][A-Za-z0-9_$]*$/;

// A same-directory import specifier for the OUTPUT file, split so this source
// file never spells a quoted dot-slash-name substring for job-handler or
// worker-defaults. Such a substring reads as a real require() to the
// bundler's sibling-script scanner, which then expects a matching .cjs/.mjs
// to ship inside this skill's own scripts/ bundle — it never will, since the .ts
// counterparts are blueprint files copied into the user's project, not a
// dependency of this generator.
const sameDirImport = (filename) => `.${'/'}${filename}`;

/**
 * File stem for a job type: lowercase, every run of non-alphanumeric collapsed
 * to one `-`, no leading or trailing `-`. Identity for the kebab-case job types
 * the analysis phase produces (references/analyze-phase.md:42).
 *
 * @param {string} jobType
 * @returns {string}
 */
function fileStem(jobType) {
  return String(jobType == null ? '' : jobType)
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter(Boolean)
    .join('-');
}

/**
 * Identifier stem for a job type. Copied from analyze-join.mts:246-248 so the
 * TypeScript names and the manifest's own `className` derive from one function.
 *
 * @param {string} s
 * @returns {string}
 */
function pascal(s) {
  return String(s == null ? '' : s)
    .split(/[^A-Za-z0-9]+/)
    .filter(Boolean)
    .map((w) => (w[0] ?? '').toUpperCase() + w.slice(1))
    .join('');
}

/** @param {string} s @returns {string} */
function lowerFirst(s) {
  return s.length === 0 ? s : s[0].toLowerCase() + s.slice(1);
}

/**
 * Whether a derived stem is a legal JS/TS identifier. One regex covers both ways
 * pascal() produces an illegal one: no alphanumeric content at all yields the
 * empty string, and a digit-leading job type yields a digit-leading stem
 * (`2fa-check` → `2faCheck`), which the analysis phase can genuinely produce
 * from a task named "2FA Check".
 *
 * @param {string} id
 * @returns {boolean}
 */
function isLegalIdentifier(id) {
  return typeof id === 'string' && LEGAL_IDENTIFIER.test(id);
}

// `__proto__` names the prototype setter in a value-position object literal, in
// the bare AND the quoted spelling alike — only the computed form
// `["__proto__"]` creates an own enumerable property. A BPMN variable name, a
// BPMN error code and a job type may all legally carry it (nothing upstream
// reserves it, and it derives a legal stem: pascal('__proto__') === 'Proto'), so
// every value-position key goes through ownPropertyKey or ownStringKey.
//
// A TYPE-position key is exempt and must NOT use the computed form: a type
// member named `__proto__` is an ordinary member, and `["__proto__"]?: string`
// is not valid type-literal syntax.
const PROTO_KEY = '__proto__';

/**
 * A property key in a TYPE literal. Hyphenated BPMN variable names such as
 * `case-id` are ordinary, and unquoted would be a syntax error.
 *
 * @param {string} name
 * @returns {string}
 */
function quoteKey(name) {
  return isLegalIdentifier(name) ? name : JSON.stringify(name);
}

/**
 * A property key in a value-position object literal, spelled the way quoteKey
 * would except for `__proto__`.
 *
 * @param {string} name
 * @returns {string}
 */
function ownPropertyKey(name) {
  return name === PROTO_KEY ? `[${JSON.stringify(name)}]` : quoteKey(name);
}

/**
 * A value-position object-literal key that stays quoted whether or not it is a
 * legal identifier — the registry's keys are job type strings, which the
 * dependency audit's registration probe matches on in their quoted form.
 *
 * @param {string} name
 * @returns {string}
 */
function ownStringKey(name) {
  return name === PROTO_KEY ? `[${JSON.stringify(name)}]` : JSON.stringify(name);
}

/**
 * Member access on a generated constant map. Dot access when the key is a legal
 * identifier — biome's useLiteralKeys rule flags bracket access that did not
 * need to be one. `__proto__` takes the bracket form even though it is a legal
 * identifier: the own property it now reads exists only under a computed key,
 * and dot access on it reads as the prototype accessor.
 *
 * @param {string} object
 * @param {string} key
 * @returns {string}
 */
function memberAccess(object, key) {
  return isLegalIdentifier(key) && key !== PROTO_KEY
    ? `${object}.${key}`
    : `${object}[${JSON.stringify(key)}]`;
}

/**
 * Sort import specifiers the way biome's organizeImports assist action does:
 * by the specifier's bare name (the `type ` marker stripped for comparison
 * only), primarily case-insensitive with an exact-string tiebreak — verified
 * empirically against `biome check --write`, since the rule isn't otherwise
 * documented in a form this generator can rely on. A same-length prefix that
 * only differs in case (`bar` vs `Bar`) resolves to the exact-string order
 * (uppercase first); everything else sorts on the case-insensitive
 * comparison, which is why a `create<Stem>X`/`type <Stem>X` pair's order
 * flips with the stem itself (`type CloseCddCaseService` sorts before
 * `createCloseCddCaseService`, but `createSendCddRefreshRequestService`
 * sorts before `type SendCddRefreshRequestService` — "close" < "create" but
 * "create" < "send").
 *
 * @param {string[]} specifiers
 * @returns {string[]}
 */
function sortSpecifiers(specifiers) {
  const bareName = (s) => s.replace(/^type /, '');
  return [...specifiers].sort((a, b) => {
    const an = bareName(a);
    const bn = bareName(b);
    const ai = an.toLowerCase();
    const bi = bn.toLowerCase();
    if (ai !== bi) return ai < bi ? -1 : 1;
    return an < bn ? -1 : an > bn ? 1 : 0;
  });
}

/**
 * A named import, collapsed to one line when it fits the blueprint's 100-column
 * width and split biome-style (one specifier per line) when it doesn't. A long
 * job type's derived names (stem, file) are the only thing that pushes an
 * otherwise-short import over the limit, so the wrap is computed from the
 * actual rendered length rather than hand-cased for one known job type.
 *
 * The wrap decision measures the whole printed line, `import`/`import type`
 * keyword included — biome's own line width counts it, so a proxy
 * measurement that excludes it can pass an import through that biome would
 * still wrap. A single specifier is never wrapped regardless of length —
 * verified against `biome check --write` on a 124-column single-specifier
 * import: biome leaves it on one line, since splitting one item across
 * three lines doesn't distribute anything.
 *
 * @param {string[]} specifiers Already-formatted specifiers, e.g. `'X'` or `'type X'`.
 * @param {string} source
 * @param {{typeOnly?: boolean}} [opts]
 * @returns {string[]}
 */
function renderImport(specifiers, source, opts = {}) {
  const prefix = opts.typeOnly ? 'import type' : 'import';
  const sorted = sortSpecifiers(specifiers);
  const oneLine = `${prefix} { ${sorted.join(', ')} } from ${JSON.stringify(source)}`;
  if (sorted.length === 1 || oneLine.length <= 100) return [oneLine];
  return [`${prefix} {`, ...sorted.map((s) => `  ${s},`), `} from ${JSON.stringify(source)}`];
}

/**
 * BPMN variable type → Zod expression and inferred TS type.
 *
 * The key set mirrors mapJavaType (scaffold-workers.cjs:816-824) exactly, so
 * both SDKs read one manifest vocabulary. Matching is case-sensitive against
 * these spellings; anything else, including an absent or empty type, falls to
 * z.unknown(), mirroring the Java path's fall to Object.
 */
const ZOD_TYPES = {
  String: { zod: 'z.string()', ts: 'string' },
  string: { zod: 'z.string()', ts: 'string' },
  Long: { zod: 'z.number().int()', ts: 'number' },
  long: { zod: 'z.number().int()', ts: 'number' },
  Integer: { zod: 'z.number().int()', ts: 'number' },
  int: { zod: 'z.number().int()', ts: 'number' },
  Double: { zod: 'z.number()', ts: 'number' },
  double: { zod: 'z.number()', ts: 'number' },
  Float: { zod: 'z.number()', ts: 'number' },
  float: { zod: 'z.number()', ts: 'number' },
  Boolean: { zod: 'z.boolean()', ts: 'boolean' },
  boolean: { zod: 'z.boolean()', ts: 'boolean' },
  Number: { zod: 'z.number()', ts: 'number' },
};

const UNKNOWN_TYPE = { zod: 'z.unknown()', ts: 'unknown' };

/** @param {string|undefined|null} type @returns {string} */
function zodFor(type) {
  return (ZOD_TYPES[type] || UNKNOWN_TYPE).zod;
}

/** @param {string|undefined|null} type @returns {string} */
function tsTypeFor(type) {
  return (ZOD_TYPES[type] || UNKNOWN_TYPE).ts;
}

/**
 * The right-hand side of an optional property. `unknown` already includes
 * undefined; every other type needs it spelled out, because
 * exactOptionalPropertyTypes makes `?: string` reject an explicit undefined.
 *
 * @param {string} tsType
 * @returns {string}
 */
function optionalPropertyType(tsType) {
  return tsType === 'unknown' ? 'unknown' : `${tsType} | undefined`;
}

/**
 * Merge one declaration of `name` into a group's input or output field map,
 * collapsing a type disagreement to unknown.
 *
 * Keeping the first type instead would emit a per-job-type input schema that
 * rejects every job dispatched from the other declaration, and a service output
 * type narrower than what the job can actually carry. The collapse mirrors
 * renderProcessVariables' cross-job-type union and the Java path's collapse to
 * Object. Reachable, not theoretical: analyze-join.mts flags a type disagreement
 * as a review question and marks the entries medium-confidence, but leaves both
 * spellings in the manifest.
 *
 * Comparison is on the RESOLVED zod expression, not the raw manifest string, so
 * two spellings of one type (`String` / `string`) are not a disagreement.
 *
 * @param {Map<string, {zod: string, ts: string, count: number}>} map
 * @param {string} name
 * @param {string|undefined|null} type
 * @returns {{zod: string, ts: string, count: number}} The merged field.
 */
function mergeDeclaredType(map, name, type) {
  const zod = zodFor(type);
  const existing = map.get(name);
  if (!existing) {
    const field = { zod, ts: tsTypeFor(type), count: 0 };
    map.set(name, field);
    return field;
  }
  if (existing.zod !== zod) {
    existing.zod = UNKNOWN_TYPE.zod;
    existing.ts = UNKNOWN_TYPE.ts;
  }
  return existing;
}

/**
 * Group manifest worker entries by unique job type, unioning each group's input
 * variables, output variables and error codes.
 *
 * Camunda dispatches work by job type, so exactly one worker implementation may
 * exist per job type — several implementations is not implementable, whichever
 * polls first wins non-deterministically. The manifest legitimately carries
 * several entries for one job type because the same service task recurs across
 * process phases, and those entries do not always agree on inputs (the shipped
 * `cdd-refresh` fixture's `set-edd-required` is one input in one phase, three in
 * another).
 *
 * An input field is `required: true` only when it appears in every entry sharing
 * the job type; a field present in some but not all entries is `required: false`.
 * Marking it required unconditionally (a plain union) would make the generated
 * worker's own validation reject every job dispatched from the entry that omits
 * it — a permanent failure baked into the schema, not a transient gap that
 * resolves once the underlying service is implemented. A job type appearing once
 * has every input required, matching literal union-required behaviour.
 *
 * Two entries disagreeing on one field's TYPE collapse that field to unknown for
 * the same reason (see mergeDeclaredType).
 *
 * Groups come back in manifest first-appearance order and fields in
 * first-appearance order within a group, so a rerun over the same manifest emits
 * byte-identical output.
 *
 * @param {object[]} [workers] manifest.workers
 * @returns {object[]}
 */
function groupWorkers(workers) {
  const byJobType = new Map();
  for (const entry of workers || []) {
    const jobType = entry && entry.jobType;
    if (!jobType) continue;
    if (!byJobType.has(jobType)) {
      byJobType.set(jobType, {
        jobType,
        className: entry.className || `${pascal(jobType).replace(/Worker$/, '')}Worker`,
        stem: pascal(jobType),
        file: fileStem(jobType),
        entryCount: 0,
        inputs: new Map(), // name -> { zod, ts, count }
        outputs: new Map(), // name -> { zod, ts }
        errorCodes: new Set(),
      });
    }
    const group = byJobType.get(jobType);
    group.entryCount += 1;
    // A name repeated inside ONE entry still merges its type but counts once, so
    // `required` keeps meaning "declared by every entry".
    const seenInEntry = new Set();
    for (const variable of entry.inputVariables || []) {
      if (!variable || !variable.name) continue;
      const field = mergeDeclaredType(group.inputs, variable.name, variable.type);
      if (seenInEntry.has(variable.name)) continue;
      seenInEntry.add(variable.name);
      field.count += 1;
    }
    for (const variable of entry.outputVariables || []) {
      if (!variable || !variable.name) continue;
      mergeDeclaredType(group.outputs, variable.name, variable.type);
    }
    for (const declared of entry.errors || []) {
      if (declared && declared.code) group.errorCodes.add(declared.code);
    }
  }

  const toInputFields = (map, entryCount) =>
    [...map.entries()].map(([name, { zod, ts, count }]) => ({
      name,
      zod,
      ts,
      required: count === entryCount,
    }));

  const toOutputFields = (map) => [...map.entries()].map(([name, { zod, ts }]) => ({ name, zod, ts }));

  return [...byJobType.values()].map((group) => ({
    jobType: group.jobType,
    className: group.className,
    stem: group.stem,
    file: group.file,
    inputs: toInputFields(group.inputs, group.entryCount),
    outputs: toOutputFields(group.outputs),
    errorCodes: [...group.errorCodes].sort(),
  }));
}

/**
 * The two input states that are hard failures rather than best-effort.
 *
 * Both stems are checked for collisions, not just the identifier: pascal()
 * preserves inner case while fileStem lowercases, so `a-fA` and `a-Fa` differ as
 * identifiers and collide as filenames. Writing the file anyway would emit one
 * worker for two job types and leave the second permanently without a
 * subscriber, which surfaces later as a stalled process instance one step
 * removed from its cause.
 *
 * @param {object[]} groups
 * @returns {{illegal: string[], collisions: string[][]}}
 */
function validateGroups(groups) {
  const illegal = groups.filter((g) => !isLegalIdentifier(g.stem)).map((g) => g.jobType);

  const collisions = [];
  for (const key of ['stem', 'file']) {
    const seen = new Map();
    for (const group of groups) {
      if (!seen.has(group[key])) seen.set(group[key], []);
      seen.get(group[key]).push(group.jobType);
    }
    for (const jobTypes of seen.values()) {
      if (jobTypes.length > 1 && !collisions.some((c) => c.join(' ') === jobTypes.join(' '))) {
        collisions.push(jobTypes);
      }
    }
  }
  return { illegal, collisions };
}

/**
 * models/process-variables.ts — the all-optional union schema over every input
 * and output variable name (each worker's activation-scope type parameter: a job
 * only sees the variables in its own scope), plus one per-job-type input schema
 * whose fields are required when the field is present in every manifest entry
 * for that job type, and `.optional()` when it is not (see groupWorkers).
 *
 * The required input schema is what makes the generated code compile at all:
 * under exactOptionalPropertyTypes, handing the all-optional union straight to a
 * service's required parameter is a compile error.
 *
 * @param {object[]} groups
 * @returns {string}
 */
function renderProcessVariables(groups) {
  const union = new Map();
  for (const group of groups) {
    for (const field of [...group.inputs, ...group.outputs]) {
      if (union.has(field.name) && union.get(field.name) !== field.zod) {
        // Type disagreement collapses to unknown, mirroring the Java path's
        // collapse to Object. analyze-join already flags disagreements as review
        // questions, so this is a fallback, not a silent decision.
        union.set(field.name, UNKNOWN_TYPE.zod);
      } else if (!union.has(field.name)) {
        union.set(field.name, field.zod);
      }
    }
  }

  const objectLiteral = (entries) =>
    entries.length === 0
      ? 'z.object({})'
      : ['z.object({', ...entries.map(([k, v]) => `  ${ownPropertyKey(k)}: ${v},`), '})'].join('\n');

  const lines = ['import { z } from "zod"', ''];
  const sorted = [...union.entries()].sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0));
  lines.push(
    `export const ProcessVariablesSchema = ${objectLiteral(sorted.map(([k, v]) => [k, `${v}.optional()`]))}`,
    '',
    'export type ProcessVariables = z.infer<typeof ProcessVariablesSchema>',
  );
  for (const group of groups) {
    const sortedInputs = [...group.inputs].sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));
    const inputTypeAlias = `export type ${group.stem}Input = z.infer<typeof ${group.stem}InputSchema>`;
    lines.push(
      '',
      `export const ${group.stem}InputSchema = ${objectLiteral(
        sortedInputs.map((f) => [f.name, f.required ? f.zod : `${f.zod}.optional()`]),
      )}`,
      '',
      ...(inputTypeAlias.length <= 100
        ? [inputTypeAlias]
        : [
            `export type ${group.stem}Input = z.infer<`,
            `  typeof ${group.stem}InputSchema`,
            '>',
          ]),
    );
  }
  return `${lines.join('\n')}\n`;
}

/**
 * errors/bpmn-errors.ts — a constant map of every declared BPMN error code with a
 * union type over it. Returns null when nothing declares a code, so no module is
 * written at all.
 *
 * @param {string[]} allCodes
 * @returns {string|null}
 */
function renderBpmnErrors(allCodes) {
  const codes = [...new Set(allCodes)].sort();
  if (codes.length === 0) return null;
  const lines = [
    'export const BPMN_ERROR_CODES = {',
    ...codes.map((code) => `  ${ownPropertyKey(code)}: ${JSON.stringify(code)},`),
    '} as const',
    '',
    'export type BpmnErrorCode = (typeof BPMN_ERROR_CODES)[keyof typeof BPMN_ERROR_CODES]',
  ];
  return `${lines.join('\n')}\n`;
}

/**
 * errors/service-error.ts — one error class carrying a code. The TypeScript SDK
 * routes BPMN errors on a code string, unlike Java which routes on exception
 * type, so one class carrying a code is the faithful shape rather than one class
 * per code.
 *
 * `code` is a plain `string`, not `BpmnErrorCode`: bpmn-errors.ts is absent when
 * nothing declares a code, and this file must exist either way. errors/ is also a
 * dependency-cruiser leaf layer, so it imports nothing at all.
 *
 * @returns {string}
 */
function renderServiceError() {
  const lines = [
    'export class ServiceError extends Error {',
    '  readonly code: string',
    '',
    '  constructor(code: string, message: string, options?: { cause?: unknown }) {',
    '    super(message, options)',
    '    this.name = "ServiceError"',
    '    this.code = code',
    '  }',
    '}',
  ];
  return `${lines.join('\n')}\n`;
}

/**
 * services/<job>-service.ts — an all-optional output type and a stub body
 * returning an empty object beneath a `// TODO: implement` comment.
 *
 * The output type lives beside its consumer rather than in models/ because the
 * blueprint's import rules permit services to import models but forbid the
 * reverse (.dependency-cruiser.mjs:19-24, :32-38).
 *
 * The parameter is `_input`, not `input`: nothing in a stub body uses it, and the
 * blueprint's linter treats an unused variable as an error while honouring the
 * leading-underscore convention. The TODO tells the implementer to rename it.
 *
 * The throw-a-ServiceError sentence only applies when this job type declares at
 * least one BPMN error code: that's the only case where renderWorker() emits a
 * try/catch to translate the throw into `job.error(...)` (see hasErrors there).
 * For every other job type the worker has no catch at all, so following this
 * TODO's advice literally would just fail the job instead of raising a BPMN
 * error.
 *
 * @param {object} group
 * @returns {string}
 */
function renderService(group) {
  const hasErrors = group.errorCodes.length > 0;
  const outputType =
    group.outputs.length === 0
      ? `export type ${group.stem}Output = Record<string, never>`
      : [
          `export type ${group.stem}Output = {`,
          ...group.outputs.map((f) => `  ${quoteKey(f.name)}?: ${optionalPropertyType(f.ts)}`),
          '}',
        ].join('\n');

  const serviceTypeAlias = `export type ${group.stem}Service = ReturnType<typeof create${group.stem}Service>`;
  const executeSignature = `  async execute(_input: ${group.stem}Input): Promise<${group.stem}Output> {`;

  const todoLines = hasErrors
    ? [
        `  // TODO: implement. Rename \`_input\` to \`input\` once the body uses it. Return the`,
        '  // declared output variables, or throw ServiceError with one of this job type\'s',
        '  // declared BPMN error codes to raise a BPMN error on the calling task.',
      ]
    : [
        `  // TODO: implement. Rename \`_input\` to \`input\` once the body uses it. Return`,
        '  // the declared output variables.',
      ];

  const lines = [
    ...renderImport([`${group.stem}Input`], '../models/process-variables.js', { typeOnly: true }),
    '',
    outputType,
    '',
    `export const create${group.stem}Service = () => ({`,
    ...todoLines,
    ...(executeSignature.length <= 100
      ? [executeSignature]
      : [
          '  async execute(',
          `    _input: ${group.stem}Input,`,
          `  ): Promise<${group.stem}Output> {`,
        ]),
    '    return {}',
    '  },',
    '})',
    '',
    ...(serviceTypeAlias.length <= 100
      ? [serviceTypeAlias]
      : [
          `export type ${group.stem}Service = ReturnType<`,
          `  typeof create${group.stem}Service`,
          '>',
        ]),
  ];
  return `${lines.join('\n')}\n`;
}

/**
 * workers/<job>-worker.ts — validate the activated job's variables against this
 * job type's input schema, fail the job without retries on a mismatch, call the
 * service, complete with its output, and translate the service's error class into
 * a BPMN error call carrying the declared code.
 *
 * Logging happens here, never in the service.
 *
 * A job type declaring no error code omits the error imports, the declared-codes
 * list and the try/catch entirely — the shipped fixture has 15 of 17 job types in
 * that state, and the blueprint's linter treats an unused import as an error.
 *
 * DECLARED_ERROR_CODES is a list rather than a pinned literal at the catch site,
 * so every code the manifest declares for this job type is actually raisable. An
 * unraisable code is worse than no error handling: the BPMN looks wired and a
 * boundary error event on that task can never fire.
 *
 * @param {object} group
 * @returns {string}
 */
function renderWorker(group) {
  const hasErrors = group.errorCodes.length > 0;
  const imports = [];
  if (hasErrors) {
    imports.push(
      'import { BPMN_ERROR_CODES } from "../errors/bpmn-errors.js"',
      'import { ServiceError } from "../errors/service-error.js"',
    );
  }
  imports.push(
    ...renderImport(
      [`${group.stem}InputSchema`, 'type ProcessVariablesSchema'],
      '../models/process-variables.js',
    ),
    'import type { Logger } from "../observability/logger.js"',
    ...renderImport([`${group.stem}Service`], `../services/${group.file}-service.js`, { typeOnly: true }),
    `import type { WorkerConfig } from "${sameDirImport('job-handler.js')}"`,
    `import { WORKER_DEFAULTS } from "${sameDirImport('worker-defaults.js')}"`,
  );

  const lines = [...imports, ''];

  if (hasErrors) {
    lines.push(
      'const DECLARED_ERROR_CODES: readonly string[] = [',
      ...group.errorCodes.map((code) => `  ${memberAccess('BPMN_ERROR_CODES', code)},`),
      ']',
      '',
    );
  }

  // JSON.stringify the whole prefix (not just interpolate group.jobType raw) so a
  // backtick or ${…} inside the job type lands as literal text in the OUTPUT
  // string, not as template-literal syntax that terminates or interpolates early.
  const failMessageLine =
    `        errorMessage: ${JSON.stringify(`${group.jobType} received malformed input: `)} + parsed.error.message,`;

  lines.push(
    `export const create${group.stem}Worker = (`,
    `  service: ${group.stem}Service,`,
    '  log: Logger,',
    '): WorkerConfig<typeof ProcessVariablesSchema> => ({',
    '  ...WORKER_DEFAULTS,',
    `  jobType: ${JSON.stringify(group.jobType)},`,
    `  workerName: ${JSON.stringify(group.className)},`,
    '  jobHandler: async (job) => {',
    `    const parsed = ${group.stem}InputSchema.safeParse(job.variables)`,
    '    if (!parsed.success) {',
    '      return job.fail({',
    '        retries: 0,',
    failMessageLine,
    '      })',
    '    }',
    '',
    `    log.info({ input: parsed.data }, ${JSON.stringify(`${group.jobType} received input`)})`,
    '',
  );

  if (hasErrors) {
    const warnLine = `        log.warn({ errorCode: error.code, err: error }, ${JSON.stringify(`${group.jobType} raised a BPMN error`)})`;
    lines.push(
      '    try {',
      '      return job.complete(await service.execute(parsed.data))',
      '    } catch (error) {',
      '      if (error instanceof ServiceError && DECLARED_ERROR_CODES.includes(error.code)) {',
      ...(warnLine.length <= 100
        ? [warnLine]
        : [
            '        log.warn(',
            '          { errorCode: error.code, err: error },',
            `          ${JSON.stringify(`${group.jobType} raised a BPMN error`)},`,
            '        )',
          ]),
      '        return job.error({ errorCode: error.code, errorMessage: error.message })',
      '      }',
      '      throw error',
      '    }',
    );
  } else {
    lines.push('    return job.complete(await service.execute(parsed.data))');
  }

  lines.push('  },', '})');
  return `${lines.join('\n')}\n`;
}

/**
 * app.ts — regenerated, not patched. It is a single hand-maintained registry in
 * the blueprint (blueprints/typescript/src/app.ts:41-48), which the Java path has
 * no analogue for because Java workers self-register through an annotation.
 *
 * Its two consumers, main.ts and shutdown.ts, need exactly four exports between
 * them: AppServices, composeApp, RegisteredWorkers, registerWorkers. Emitting
 * that contract leaves both files typechecking untouched.
 *
 * The registry key is the job type string, which is also what the dependency
 * audit's registration probe looks for; `workerName` in the worker config carries
 * the manifest's className.
 *
 * @param {object[]} groups
 * @returns {string}
 */
function renderApp(groups) {
  const byImportOrder = [...groups].sort((a, b) => (a.file < b.file ? -1 : a.file > b.file ? 1 : 0));

  const lines = [
    'import type { CamundaClient, JobWorker } from "@camunda8/orchestration-cluster-api"',
    '',
    'import type { Env } from "./config/env.js"',
    'import type { Logger } from "./observability/logger.js"',
  ];
  for (const group of byImportOrder) {
    lines.push(
      ...renderImport(
        [`create${group.stem}Service`, `type ${group.stem}Service`],
        `./services/${group.file}-service.js`,
      ),
    );
  }
  for (const group of byImportOrder) {
    lines.push(...renderImport([`create${group.stem}Worker`], `./workers/${group.file}-worker.js`));
  }

  const field = (group) => lowerFirst(group.stem);

  lines.push('');
  if (groups.length === 0) {
    lines.push(
      'export type AppServices = Record<string, never>',
      '',
      'export const composeApp = (_env: Env): AppServices => ({})',
      '',
      'export type RegisteredWorkers = Record<string, JobWorker>',
      '',
      'export const registerWorkers = (',
      '  _client: CamundaClient,',
      '  _services: AppServices,',
      '  _log: Logger,',
      '): RegisteredWorkers => ({})',
    );
    return `${lines.join('\n')}\n`;
  }

  lines.push(
    'export type AppServices = {',
    ...groups.map((g) => `  ${field(g)}: ${g.stem}Service`),
    '}',
    '',
    'export const composeApp = (_env: Env): AppServices => ({',
    ...groups.map((g) => `  ${field(g)}: create${g.stem}Service(),`),
    '})',
    '',
    'export type RegisteredWorkers = Record<string, JobWorker>',
    '',
    'export const registerWorkers = (',
    '  client: CamundaClient,',
    '  services: AppServices,',
    '  log: Logger,',
    '): RegisteredWorkers => ({',
    ...groups.flatMap((g) => {
      // The printed line is `  ${expr},` — the wrap decision has to measure
      // that whole line, 2-space indent and trailing comma included, or an
      // expr that fits its own budget can still push the real line over 100.
      const expr = `${ownStringKey(g.jobType)}: client.createJobWorker(create${g.stem}Worker(services.${field(g)}, log))`;
      if (`  ${expr},`.length <= 100) return [`  ${expr},`];
      return [
        `  ${ownStringKey(g.jobType)}: client.createJobWorker(`,
        `    create${g.stem}Worker(services.${field(g)}, log),`,
        '  ),',
      ];
    }),
    '})',
  );
  return `${lines.join('\n')}\n`;
}

module.exports = {
  fileStem,
  pascal,
  lowerFirst,
  isLegalIdentifier,
  quoteKey,
  ownPropertyKey,
  ownStringKey,
  memberAccess,
  ZOD_TYPES,
  zodFor,
  tsTypeFor,
  optionalPropertyType,
  groupWorkers,
  validateGroups,
  renderProcessVariables,
  renderBpmnErrors,
  renderServiceError,
  renderService,
  renderWorker,
  renderApp,
};
