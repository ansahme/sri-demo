#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// The Python worker-probe adapter for audit-artifact-deps.cjs check #1.
//
// It compares the unique manifest job types with the generated Python layer in
// both directions: every job type reaches exactly one worker and exactly one
// registration, and every generated worker traces back to a job type.
//
// The function takes already-read sources rather than a directory, so the audit
// script owns the filesystem and every rule here has a unit test. The expected
// file stem comes from the generator's own `snakeStem`, because a probe that
// derived names by a second rule would pass a bundle whose names disagree.
//
// A Java worker self-registers through an annotation, so the Java probe needs no
// registration check. Python registers in one central ${pyPackage}/app.py`, and a worker
// that exists but never registers leaves its task without a subscriber — a
// stalled process instance one step removed from its cause. That is the failure
// this adapter exists to catch.

const { snakeStem } = require('./generate-workers-python-emit.cjs');

const escape = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/**
 * Audit the generated Python worker layer against the manifest's job types.
 *
 * @param {object} input
 * @param {string[]} input.jobTypes unique manifest job types, in manifest order
 * @param {Array<{name: string, src: string}>} input.workerFiles every `*_worker.py`
 *   under `<pyPackage>/workers/`, as a base name and its source
 * @param {string|null} input.appSrc `<pyPackage>/app.py`, or null when it does not exist
 * @param {string} [input.pyPackage] the generated top-level package, which the
 *   scaffolder derives from `meta.processSlug`. Only a manifest carrying no slug
 *   leaves the generic `src`, so a hardcoded `src` names a path that does not
 *   exist for any real bundle and reports every worker missing.
 * @returns {{errors: string[], notes: string[]}}
 */
function auditPythonWorkers({ jobTypes = [], workerFiles = [], appSrc = null, pyPackage = 'src' } = {}) {
  const errors = [];
  const notes = [];

  if (appSrc === null) {
    errors.push(`worker registry missing: ${pyPackage}/app.py not found (nothing registers any worker)`);
  }

  const expected = new Map(jobTypes.map((jobType) => [`${snakeStem(jobType)}_worker.py`, jobType]));

  for (const jobType of jobTypes) {
    const stem = snakeStem(jobType);
    const fileName = `${stem}_worker.py`;
    const matches = workerFiles.filter((f) => f.name === fileName);

    if (matches.length === 0) {
      errors.push(`worker missing: jobType="${jobType}" (no ${pyPackage}/workers/${fileName})`);
      continue;
    }
    if (matches.length > 1) {
      // Two files cannot share one name on one filesystem, so this only fires
      // when a caller hands in a duplicated list. Reported rather than ignored,
      // because silently taking the first would audit half the input.
      errors.push(`worker duplicated: jobType="${jobType}" (${matches.length} entries for ${pyPackage}/workers/${fileName})`);
      continue;
    }

    const { src } = matches[0];

    // The WorkerConfig has to carry the exact manifest job type. A worker whose
    // config drifted from its file name subscribes to a job type nothing
    // dispatches, and the file name alone would still look right.
    const declares = new RegExp(`job_type=(["'])${escape(jobType)}\\1`);
    if (!declares.test(src)) {
      const found = src.match(/job_type=(["'])([^"']*)\1/);
      errors.push(
        `worker job type mismatch: ${pyPackage}/workers/${fileName} declares `
        + `job_type=${found ? JSON.stringify(found[2]) : '(none)'}, expected "${jobType}"`,
      );
    }

    if (appSrc === null) continue;

    // The factory call, tolerant of the line wrapping ruff format applies to a
    // long name.
    const factory = new RegExp(`create_${escape(stem)}_worker\\(`, 'g');
    const factoryCount = (appSrc.match(factory) || []).length;
    if (factoryCount === 0) {
      errors.push(`worker not registered: jobType="${jobType}" (${pyPackage}/app.py never calls create_${stem}_worker)`);
      continue;
    }
    if (factoryCount > 1) {
      errors.push(
        `worker registered more than once: jobType="${jobType}" `
        + `(${pyPackage}/app.py calls create_${stem}_worker ${factoryCount} times)`,
      );
    }

    const wired = new RegExp(`create_${escape(stem)}_worker\\(\\s*services\\.${escape(stem)}_service\\s*,\\s*log\\s*\\)`);
    if (!wired.test(appSrc)) {
      errors.push(
        `worker wired to the wrong service: jobType="${jobType}" `
        + `(${pyPackage}/app.py does not pass services.${stem}_service to create_${stem}_worker)`,
      );
    }
  }

  // Every generated worker traces back to a job type. An extra file registers
  // nothing and reads as real work.
  for (const file of workerFiles) {
    if (!expected.has(file.name)) {
      errors.push(`extra worker file: ${pyPackage}/workers/${file.name} matches no manifest job type`);
    }
  }

  if (appSrc !== null && jobTypes.length > 0) {
    // The registry key must come from the config, not from a literal. A literal
    // key that disagrees with the config's job_type registers the worker under a
    // name Camunda never dispatches, and both strings look plausible in review.
    if (!/workers\[config\.job_type\]\s*=/.test(appSrc)) {
      errors.push(
        `worker registry key: ${pyPackage}/app.py does not key RegisteredWorkers by config.job_type `
        + '(a literal or derived key can disagree with the job type the worker subscribes to)',
      );
    }
    const literalKey = appSrc.match(/workers\[(["'])([^"']+)\1\]\s*=/);
    if (literalKey) {
      errors.push(`worker registry key: ${pyPackage}/app.py keys RegisteredWorkers by the literal "${literalKey[2]}"`);
    }

    // Explicit async execution keeps every handler on ConnectedJobContext. The
    // SDK's default is `auto`, which infers the context type from the callback.
    if (!/execution_strategy=(["'])async\1/.test(appSrc)) {
      errors.push(`worker execution strategy: ${pyPackage}/app.py does not pass execution_strategy="async" to create_job_worker`);
    }
  }

  if (jobTypes.length === 0 && workerFiles.length === 0) {
    notes.push('worker check: the manifest declares no job type, and no worker file exists');
  }

  return { errors, notes };
}

module.exports = { auditPythonWorkers };
