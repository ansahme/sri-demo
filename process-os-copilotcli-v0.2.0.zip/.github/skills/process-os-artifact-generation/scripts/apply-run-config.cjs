#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

/**
 * apply-run-config.cjs — merge run-configuration overrides into the project's
 * run.config.yaml.
 *
 * The write counterpart to read-run-config.cjs, and the only way the file grows after
 * initialization. process-os-governance-job-activation calls it with the `runConfig` job
 * variable a governance step carries, so a phase's configuration reaches the project
 * before the job skill runs and no skill needs merge logic of its own.
 *
 * KEYS ARE FORM-SHAPED OR RUN-CONFIGURATION KEYS — both work. A Camunda form key cannot
 * contain a hyphen, so a form group offering a hyphenated run-configuration key spells it
 * with underscores; every override therefore goes through `toTechOverrides`, which applies
 * KEY_MAP and collapses `specialistsBuiltin`/`specialistsExtra` into `specialists`. A key
 * that is already run-configuration-shaped falls through the map unchanged, unless a row
 * retargets it — `max_iterations`, `max-iterations` and `max_research_rounds` are all
 * retained aliases that land on `max-research-rounds`.
 *
 * That is what lets a governance form hand over its whole `runConfig` group verbatim,
 * rather than a FEEL expression restating every key.
 *
 * An unrecognised key is dropped rather than written, and named in the status line. The
 * guard against a stray key living in a form's `runConfig` group is a test over the forms,
 * because failing here would fail a governance job over a form field.
 *
 * Usage:
 *   node apply-run-config.cjs <overrides.json>
 *   node apply-run-config.cjs --stdin < overrides.json
 *   node apply-run-config.cjs --set <key>=<value> [--set <key>=<value> …]
 *
 * The overrides document is a JSON object. A `{"runConfig": {...}}` wrapper is unwrapped,
 * so the file activation stages can be passed as-is. `--set` is the hand-editing path: it
 * takes `key=value` pairs and merges them exactly as a form submission would, so changing
 * a setting never means editing YAML punctuation.
 *
 * Semantics:
 *   - An absent run.config.yaml is materialized rather than treated as an error. A
 *     from-scratch phase run may legitimately precede any project initialization.
 *   - `null` and blank values are ignored. A FEEL context serializes a
 *     referenced-but-unset variable as `null`, so `null` means "not provided", never
 *     "clear this key".
 *   - `auto` for a sizing key (`size`, `width`, `depth` — AUTO_KEYS in
 *     run-config-schema.cjs) removes that key, handing it back to automatic resolution. It is
 *     the one value that clears a key, and it is an explicit choice: a form's sizing dropdowns
 *     default to it, so submitting them untouched resets an earlier explicit value. `auto` on
 *     a key the file does not carry changes nothing.
 *   - A block key (a gate) merges leaf-wise onto whatever the file already carries, so
 *     submitting one leaf does not drop the others.
 *   - Applying the same overrides twice leaves the file BYTE-IDENTICAL and reports a
 *     no-op. The gate lives here rather than in callers because a governance job can be
 *     re-activated, and rewriting an unchanged file would misreport when it last changed.
 *
 * stdout: one line — `applied: <keys>`, `no-op: <keys>` or `nothing to apply`.
 *
 * Exit codes:
 *   0  applied, or a no-op because nothing changed
 *   2  usage error, or the project's Node deps are missing
 *   3  nothing to apply — the overrides document carries no usable key (routine)
 *   4  the existing run.config.yaml is present but unparseable — nothing is written
 *
 * Runs from the project WD; reads and writes ./run.config.yaml.
 */

const fs = require('node:fs');
const path = require('node:path');
// Sibling imports round-trip via '../..' so the bundler's dependency-closure grep sees a
// literal <shared dir>/<file> path; see the matching comment in read-run-config.cjs.
const yaml = require(path.join(__dirname, 'yaml.cjs'));
const { serializeRunConfig, isBlank, toTechOverrides } = require(
  path.join(__dirname, 'run-config-build.cjs'),
);
const { BLOCK_KEYS, ALL_KEYS, RUN_DEFAULTS, isAutoReset } = require(
  path.join(__dirname, 'run-config-schema.cjs'),
);
const { stripBOM } = require(path.join(__dirname, 'strip-bom.cjs'));

const CONFIG_FILE = 'run.config.yaml';

const EXIT = { OK: 0, USAGE: 2, NOTHING_TO_APPLY: 3, UNPARSEABLE: 4 };

const USAGE =
  'usage: apply-run-config.cjs <overrides.json> | --stdin | --set <key>=<value> [--set …]\n';

/**
 * Drop keys carrying no value. A FEEL context reports an unset source variable as `null`,
 * and an unset env var arrives as '' — neither is an instruction to clear the key.
 *
 * @param {Record<string, unknown>} overrides
 * @returns {Record<string, unknown>}
 */
function usableOverrides(overrides) {
  const out = {};
  for (const [key, value] of Object.entries(overrides || {})) {
    if (value == null || isBlank(value)) continue;
    // An empty list is the same non-answer: an untouched checklist submits [], and the
    // specialists collapse yields [] when both of its source lists were empty. Recorded,
    // it would read as the decision "run no specialists" and wipe a real earlier one.
    if (Array.isArray(value) && !value.length) continue;
    out[key] = value;
  }
  return out;
}

/**
 * Merge overrides onto what the file already carries.
 *
 * The parsed file IS its provided-key set, because the serializer writes only decided
 * keys — so spreading it forward preserves every earlier decision. A block key merges
 * leaf-wise onto the file's own block rather than replacing it, so a submission naming
 * one leaf keeps the rest. A block leaf reaches this in either of two shapes: nested
 * under its block, or as a dotted path from `--set`.
 *
 * @param {Record<string, unknown>} existing Parsed run.config.yaml, or {}.
 * @param {Record<string, unknown>} overrides Already filtered by usableOverrides.
 * @returns {Record<string, unknown>}
 */
function mergeOverrides(existing, overrides) {
  const merged = { ...existing };
  const isMap = (v) => Boolean(v) && typeof v === 'object' && !Array.isArray(v);
  // Merge decided leaves onto whatever the block already holds. A null or blank leaf is
  // filtered HERE rather than left to buildRunConfig: it drops such a leaf too, but by
  // then the existing decision has already been overwritten, so the leaf would resolve to
  // the schema default instead of the value the file recorded.
  const mergeBlock = (key, leaves) => {
    const usable = {};
    for (const [leaf, lv] of Object.entries(leaves)) {
      if (lv == null || isBlank(lv)) continue;
      usable[leaf] = lv;
    }
    if (!Object.keys(usable).length) return;
    merged[key] = { ...(isMap(merged[key]) ? merged[key] : {}), ...usable };
  };
  for (const [key, value] of Object.entries(overrides)) {
    const dot = key.indexOf('.');
    if (dot > 0) {
      mergeBlock(key.slice(0, dot), { [key.slice(dot + 1)]: value });
      continue;
    }
    if (BLOCK_KEYS.includes(key) && isMap(value)) {
      mergeBlock(key, value);
      continue;
    }
    // `auto` on a sizing key is a decision to stop deciding: the key leaves the file, so its
    // reader resolves it automatically again (`width`/`depth` from `size`, `size` from its
    // schema default).
    if (isAutoReset(key, value)) {
      delete merged[key];
      continue;
    }
    merged[key] = value;
  }
  return merged;
}

/**
 * Read and parse the project's run.config.yaml.
 *
 * An absent file is `{}` — a legitimate "nothing decided yet". A file that exists and
 * does not parse is a distinct state and throws: emitting `{}` there would silently
 * discard a real configuration on the next write.
 *
 * @param {string} [file]
 * @returns {Record<string, unknown>}
 */
function readExisting(file = CONFIG_FILE) {
  if (!fs.existsSync(file)) return {};
  const raw = fs.readFileSync(file, 'utf8');
  let parsed;
  try {
    parsed = yaml.parse(raw);
  } catch (e) {
    if (e.code === 'DEPS_MISSING') throw e;
    const err = new Error(`Cannot parse ${file}: ${e.message}`);
    err.code = 'RUN_CONFIG_UNPARSEABLE';
    throw err;
  }
  if (parsed != null && (typeof parsed !== 'object' || Array.isArray(parsed))) {
    const err = new Error(`${file} is not a YAML mapping`);
    err.code = 'RUN_CONFIG_UNPARSEABLE';
    throw err;
  }
  return parsed || {};
}

/**
 * Split mapped overrides into the ones the schema knows and the ones it does not.
 *
 * An unrecognised key would otherwise be written verbatim: buildRunConfig passes an
 * unknown key straight through, so a form field that does not belong in a `runConfig`
 * group would end up as a line in the project's config.
 *
 * @param {Record<string, unknown>} mapped Already through toTechOverrides.
 * @returns {{known: Record<string, unknown>, unknown: string[]}}
 */
function partitionKnown(mapped) {
  const known = {};
  const strays = [];
  const isMap = (v) => Boolean(v) && typeof v === 'object' && !Array.isArray(v);
  for (const [key, value] of Object.entries(mapped)) {
    const parts = key.split('.');
    // A dotted path addresses ONE leaf of a block key (processDiscoveryGate.questions), and
    // only a leaf that block actually declares. A deeper path, a dotted path under a scalar
    // or list key, or an undeclared leaf names nothing the writer can place — accepting it
    // would report the key as applied while writing a flat key with a dot in its name, which
    // no reader ever resolves.
    if (parts.length > 1) {
      const placeable =
        parts.length === 2 &&
        BLOCK_KEYS.includes(parts[0]) &&
        Object.hasOwn(RUN_DEFAULTS[parts[0]] || {}, parts[1]);
      if (placeable) known[key] = value;
      else strays.push(key);
      continue;
    }
    if (!ALL_KEYS.includes(key)) {
      strays.push(key);
      continue;
    }
    // A block submitted as a mapping is filtered leaf by leaf against the same declared set,
    // so both ways of addressing a leaf accept and reject the same names. Left unfiltered,
    // an undeclared leaf is written into the block, where every reader walking a declared
    // path steps straight past it.
    if (BLOCK_KEYS.includes(key) && isMap(value)) {
      const declared = RUN_DEFAULTS[key] || {};
      const keep = {};
      for (const [leaf, lv] of Object.entries(value)) {
        if (Object.hasOwn(declared, leaf)) keep[leaf] = lv;
        else strays.push(`${key}.${leaf}`);
      }
      if (Object.keys(keep).length) known[key] = keep;
      continue;
    }
    known[key] = value;
  }
  return { known, unknown: strays };
}

/**
 * Apply overrides to the project's run.config.yaml.
 *
 * @param {Record<string, unknown>} rawOverrides
 * @param {string} [file]
 * @returns {{status: 'applied'|'no-op'|'nothing', keys: string[], ignored: string[]}}
 */
function applyRunConfig(rawOverrides, file = CONFIG_FILE) {
  const mapped = toTechOverrides(usableOverrides(rawOverrides));
  // Re-filtered after mapping: a collapsed `specialists` can come out empty when both
  // source lists were, and that is not a decision to record.
  const { known, unknown } = partitionKnown(usableOverrides(mapped));
  const keys = Object.keys(known);
  if (!keys.length) return { status: 'nothing', keys, ignored: unknown };

  const existing = readExisting(file);
  const merged = mergeOverrides(existing, known);
  const current = fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : null;
  // Only removals (`auto` on a sizing key) against an absent file decide nothing that is not
  // already true, so no header-only file is materialized for them.
  if (current === null && !Object.keys(merged).length) {
    return { status: 'no-op', keys, ignored: unknown };
  }
  const next = serializeRunConfig({ tech: merged });
  if (current === next) return { status: 'no-op', keys, ignored: unknown };

  fs.writeFileSync(file, next);
  return { status: 'applied', keys, ignored: unknown };
}

/**
 * Parse `--set key=value` pairs into an overrides object.
 *
 * Values stay strings; the schema's declared type is what coerces them, exactly as it
 * does for a form submission or an env var.
 *
 * @param {string[]} argv
 * @returns {Record<string, string>}
 * @throws {Error} On a pair with no `=`, or an empty key.
 */
function parseSetArgs(argv) {
  const overrides = {};
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] !== '--set') continue;
    const pair = argv[++i];
    if (pair === undefined) throw new Error('--set requires a <key>=<value> argument');
    const eq = pair.indexOf('=');
    if (eq < 1) throw new Error(`--set expects <key>=<value>, got '${pair}'`);
    overrides[pair.slice(0, eq)] = pair.slice(eq + 1);
  }
  return overrides;
}

/**
 * Unwrap the `{runConfig: {...}}` envelope activation stages, so its file can be passed
 * without reshaping.
 *
 * @param {unknown} doc
 * @returns {Record<string, unknown>}
 */
function unwrap(doc) {
  if (doc && typeof doc === 'object' && !Array.isArray(doc)) {
    if (Object.hasOwn(doc, 'runConfig')) {
      const inner = doc.runConfig;
      return inner && typeof inner === 'object' && !Array.isArray(inner) ? inner : {};
    }
    return doc;
  }
  return {};
}

module.exports = {
  CONFIG_FILE,
  EXIT,
  applyRunConfig,
  mergeOverrides,
  parseSetArgs,
  partitionKnown,
  readExisting,
  unwrap,
  usableOverrides,
};

if (require.main === module) {
  const argv = process.argv.slice(2);
  const arg = argv[0];
  if (!arg) {
    process.stderr.write(USAGE);
    process.exit(EXIT.USAGE);
  }
  let doc;
  if (arg === '--set') {
    try {
      doc = parseSetArgs(argv);
    } catch (e) {
      process.stderr.write(`${e.message}\n${USAGE}`);
      process.exit(EXIT.USAGE);
    }
  } else {
    let raw;
    try {
      raw = arg === '--stdin' ? fs.readFileSync(0, 'utf8') : fs.readFileSync(arg, 'utf8');
    } catch (e) {
      process.stderr.write(`Cannot read ${arg === '--stdin' ? 'stdin' : arg}: ${e.message}\n`);
      process.exit(EXIT.USAGE);
    }
    try {
      // A BOM can be prepended when PowerShell pipes between two native commands, and it
      // makes a bare JSON.parse throw.
      doc = unwrap(JSON.parse(stripBOM(raw)));
    } catch (e) {
      process.stderr.write(`Cannot parse overrides JSON: ${e.message}\n`);
      process.exit(EXIT.USAGE);
    }
  }
  try {
    const { status, keys, ignored } = applyRunConfig(doc);
    // Named, not silently dropped: a stray key means a form and the schema disagree, and
    // the operator is the only one who can see both.
    const tail = ignored.length ? ` (ignored unknown: ${ignored.join(', ')})` : '';
    if (status === 'nothing') {
      process.stdout.write(`nothing to apply${tail}\n`);
      process.exit(EXIT.NOTHING_TO_APPLY);
    }
    process.stdout.write(`${status}: ${keys.join(', ')}${tail}\n`);
    process.exit(EXIT.OK);
  } catch (e) {
    if (e.code === 'RUN_CONFIG_UNPARSEABLE') {
      process.stderr.write(`${e.message}\n`);
      process.exit(EXIT.UNPARSEABLE);
    }
    if (e.code === 'DEPS_MISSING' || e.code === 'INVALID_OVERRIDE_SHAPE') {
      process.stderr.write(`${e.message}\n`);
      process.exit(EXIT.USAGE);
    }
    throw e;
  }
}
