#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Decide whether a /process-os-artifact-generation run generates the artifact
// tree or edits the one an earlier run left behind.
//
// The question the answer has to settle is "did an earlier pass leave a tree
// worth editing?" — not "does the directory exist?". A run can stop at the
// review gate, or at any of the script failures the skill documents, and
// whatever it created up to that point is still on disk. So the tree's own
// existence, and the existence of anything the generation phases write into it
// part-way through, are all states an interrupted first pass produces; none of
// them distinguishes a finished tree from an abandoned one.
//
// A generation pass therefore records its completion explicitly, as its last
// act, and this script reads that record and nothing else. An interrupted pass
// never gets that far, so the next run generates again — over whatever the
// interrupted one left, which every generator rewrites unconditionally.
//
// Usage:
//   node "scripts/pass-kind.cjs" resolve [<artifact-dir>]
//   node "scripts/pass-kind.cjs" record  [<artifact-dir>]
//
//   <artifact-dir>  Default `process-implementation/artifacts`.
//
// `resolve` prints exactly one line, `GENERATION` or `EDIT`. `record` writes
// the marker and prints `RECORDED <path>`; it is safe to re-run, and re-dating
// the marker on a pass that really did regenerate the tree is the truth, not
// drift. Nothing is written to stderr on either success path.
//
// Exit codes:
//   0  resolved or recorded.
//   2  usage error (unknown subcommand, extra argument).
//   5  the marker is there but cannot be read, or does not hold what this
//      script writes — a `completedAt` that is an ISO-8601 instant, not merely
//      a string. That is not the same state as an absent marker: silently
//      answering GENERATION would rebuild a tree over a reviewer's edits, and
//      silently answering EDIT would look for a tree nothing vouches for.

const fs = require('fs');
const path = require('path');

const EXIT = { OK: 0, USAGE: 2, MARKER_UNREADABLE: 5 };

const DEFAULT_ARTIFACT_DIR = path.join('process-implementation', 'artifacts');

// Kept inside the generated tree on purpose: removing the tree to start the
// phase over removes the record of it with the same gesture.
const MARKER_FILE = '.generation-complete.json';

// The shape `recordGenerationPass` writes, via `Date#toISOString`: an ISO-8601
// instant, in UTC or with an explicit offset. A value outside it did not come
// from a completed pass, so it is a malformed marker rather than a record of
// one — and a marker that says nothing readable about when the pass finished
// vouches for nothing.
const INSTANT = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})$/;

const USAGE = 'usage:\n  pass-kind.cjs resolve [<artifact-dir>]\n  pass-kind.cjs record [<artifact-dir>]\n';

/**
 * Whether `value` is an ISO-8601 instant. The shape check rejects a calendar
 * date or a local time with no zone; the parse rejects an in-shape value whose
 * fields are out of range (`2026-13-45T00:00:00Z`).
 *
 * @param {unknown} value
 * @returns {boolean}
 */
function isInstant(value) {
  return typeof value === 'string' && INSTANT.test(value) && Number.isFinite(Date.parse(value));
}

/**
 * @param {string} artifactDir
 * @returns {string} Path to the completion marker inside that tree.
 */
function markerPath(artifactDir) {
  return path.join(artifactDir, MARKER_FILE);
}

/**
 * The completion marker a generation pass over `artifactDir` left, validated.
 *
 * @param {string} [artifactDir]
 * @returns {{completedAt: string}|null} `null` when no marker is there at all.
 * @throws {Error} Tagged `.code = 'MARKER_UNREADABLE'` when a marker is present
 *   but unreadable or malformed.
 */
function readMarker(artifactDir = DEFAULT_ARTIFACT_DIR) {
  const marker = markerPath(artifactDir);
  let raw;
  try {
    raw = fs.readFileSync(marker, 'utf8');
  } catch (err) {
    if (err && err.code === 'ENOENT') return null;
    throw unreadable(marker, err && err.message);
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    throw unreadable(marker, err && err.message);
  }
  if (!parsed || typeof parsed !== 'object' || typeof parsed.completedAt !== 'string') {
    throw unreadable(marker, 'no completedAt string');
  }
  if (!isInstant(parsed.completedAt)) {
    throw unreadable(marker, `completedAt is not an ISO-8601 instant: ${JSON.stringify(parsed.completedAt)}`);
  }
  return parsed;
}

/**
 * Which kind of pass a run over `artifactDir` is.
 *
 * @param {string} [artifactDir]
 * @returns {'GENERATION'|'EDIT'}
 * @throws {Error} Tagged `.code = 'MARKER_UNREADABLE'` when a marker is present
 *   but unreadable or malformed.
 */
function passKind(artifactDir = DEFAULT_ARTIFACT_DIR) {
  return readMarker(artifactDir) === null ? 'GENERATION' : 'EDIT';
}

/**
 * @param {string} marker
 * @param {string} reason
 * @returns {Error}
 */
function unreadable(marker, reason) {
  const err = new Error(`${marker} is present but unusable (${reason}); repair or delete it`);
  err.code = 'MARKER_UNREADABLE';
  return err;
}

/**
 * Record that a generation pass over `artifactDir` completed.
 *
 * @param {string} [artifactDir]
 * @param {string} [completedAt] ISO-8601 instant; defaults to now.
 * @returns {string} The marker's path.
 * @throws {Error} Tagged `.code = 'MARKER_UNREADABLE'` when `completedAt` is
 *   not an instant — writing one would create the malformed marker `readMarker`
 *   refuses to read.
 */
function recordGenerationPass(artifactDir = DEFAULT_ARTIFACT_DIR, completedAt = new Date().toISOString()) {
  const marker = markerPath(artifactDir);
  if (!isInstant(completedAt)) {
    const err = new Error(
      `refusing to write ${marker}: completedAt is not an ISO-8601 instant: ${JSON.stringify(completedAt)}`,
    );
    err.code = 'MARKER_UNREADABLE';
    throw err;
  }
  fs.mkdirSync(artifactDir, { recursive: true });
  fs.writeFileSync(marker, `${JSON.stringify({ completedAt }, null, 2)}\n`);
  return marker;
}

/**
 * @param {string[]} argv
 */
function main(argv) {
  const [subcommand, artifactDir = DEFAULT_ARTIFACT_DIR, ...rest] = argv;
  if (rest.length > 0) {
    process.stderr.write(`unexpected argument: ${rest[0]}\n\n${USAGE}`);
    process.exit(EXIT.USAGE);
  }
  if (subcommand === 'record') {
    process.stdout.write(`RECORDED ${recordGenerationPass(artifactDir)}\n`);
    process.exit(EXIT.OK);
  }
  if (subcommand !== 'resolve') {
    process.stderr.write(`${subcommand ? `unknown subcommand: ${subcommand}` : 'missing subcommand'}\n\n${USAGE}`);
    process.exit(EXIT.USAGE);
  }
  let kind;
  try {
    kind = passKind(artifactDir);
  } catch (err) {
    process.stderr.write(`${err.message}\n`);
    process.exit(EXIT.MARKER_UNREADABLE);
  }
  process.stdout.write(`${kind}\n`);
  process.exit(EXIT.OK);
}

module.exports = {
  EXIT,
  DEFAULT_ARTIFACT_DIR,
  MARKER_FILE,
  isInstant,
  markerPath,
  readMarker,
  passKind,
  recordGenerationPass,
};

if (require.main === module) main(process.argv.slice(2));
