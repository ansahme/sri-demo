#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Resolve the target Camunda version for a project from run.config.yaml.
//
// `camunda-version` is captured at project initialization as the TO-BE runtime
// target: `8.8` | `8.9` | `8.10`, default `8.10`. /process-os-deployment uses it to pick
// the validation cluster and the c8ctl profile name (`Camunda<version>`);
// /process-os-test-suite warns if the CPT engine image differs.
//
// Usage:
//   node resolve-camunda-version.cjs [--verbose] [path/to/run.config.yaml]
//
// Prints the resolved version (e.g. `8.10`) to stdout and exits 0. When the config is
// absent, unparseable, or carries no `camunda-version` key, falls back to the default
// and still exits 0 (a missing/older config is not an error — the default is the
// documented behaviour). Exits 2 when the config names a version outside the supported
// set or an unquoted numeric one (so a typo can't silently target a non-existent
// cluster), and when the project's Node deps are missing — see resolve() below.
//
// The success path writes NOTHING to stderr, and that is load-bearing. Every
// caller captures stdout into a shell variable. The bash-only `2>/dev/null` those
// captures used has to be retranslated on native PowerShell, where the natural
// spelling is `2>&1` — which would fold a diagnostic line into the captured value
// and yield "resolve-camunda-version: 8.10 (…)\n8.10" instead of "8.10". A value
// that is only correct when every caller gets the redirect right is a design flaw,
// so the diagnostic is opt-in via `--verbose`. Machine-readable output goes to
// stdout only: a caller captures stdout, and on native Windows it cannot redirect
// the two streams apart.

const fs = require('fs');
const path = require('path');
// Sibling imports round-trip via '../..' so the bundler's closure sees the literal
// path; see the matching comment in read-run-config.cjs.
const yaml = require(path.join(__dirname, 'yaml.cjs'));
const { resolveKey } = require(path.join(__dirname, 'read-run-config.cjs'));
const { RUN_DEFAULTS } = require(path.join(__dirname, 'run-config-schema.cjs'));

// Taken from the schema, not restated: the generator writes that value into new
// configs, so a second literal here could drift from the files this module reads.
const DEFAULT_VERSION = RUN_DEFAULTS['camunda-version'];
const SUPPORTED = ['8.8', '8.9', '8.10'];

// A trailing-zero version like `8.10` MUST stay quoted in run.config.yaml — YAML's core
// schema parses a bare `8.10` as the float 8.1, silently dropping the digit. Once
// parsed, the JS number 8.1 is indistinguishable from a hand-written `8.1`, so we
// cannot guess which the author meant. Rather than coercing any numeric value to a
// string (which would mask exactly this truncation), reject it and tell the author to
// quote it. The generator emits it quoted via yaml.stringify; this only fires on a
// hand-edited config.
const UNQUOTED_NUMERIC_ERROR =
  'camunda-version must be quoted (e.g. "8.10") — an unquoted value is parsed as a ' +
  'YAML float, which silently truncates a trailing zero (8.10 -> 8.1) and cannot be ' +
  'told apart from a genuinely different version once parsed.';

// Missing ProcessOS Node deps are rethrown for main() to exit 2 on, rather than joining
// the "default is fine" paths above. It looks inconsistent with "a missing/older config
// is not an error", and is intentional: DEPS_MISSING means the project is broken, not
// unconfigured, so we cannot tell whether run.config.yaml pins 8.8. Defaulting to 8.10
// there would send /process-os-deployment at the wrong validation cluster and c8ctl
// profile, and make /process-os-test-suite compare the wrong engine image — silently, on
// a project that is explicitly configured otherwise. The sibling resolvers
// (resolve-target-sdk.cjs, resolve-bpmn-mode.cjs) draw the same line for the same reason.
function resolve(configPath) {
  if (!configPath || !fs.existsSync(configPath)) {
    return { version: DEFAULT_VERSION, source: 'default (no config)' };
  }
  let obj;
  try {
    obj = yaml.parse(fs.readFileSync(configPath, 'utf8')) || {};
  } catch (e) {
    if (e.code === 'DEPS_MISSING') throw e;
    return { version: DEFAULT_VERSION, source: 'default (unparseable config)' };
  }
  if (typeof obj['camunda-version'] === 'number') {
    return { version: null, source: 'error', error: UNQUOTED_NUMERIC_ERROR };
  }
  const r = resolveKey(obj, 'camunda-version');
  if (r.status === 'scalar') return { version: r.value, source: 'run.config.yaml' };
  return { version: DEFAULT_VERSION, source: 'default (key absent)' };
}

module.exports = { resolve, DEFAULT_VERSION, SUPPORTED, UNQUOTED_NUMERIC_ERROR };

if (require.main === module) {
  const argv = process.argv.slice(2);
  const verbose = argv.includes('--verbose');
  const configPath = argv.find((a) => a !== '--verbose') || 'run.config.yaml';
  let resolved;
  try {
    resolved = resolve(configPath);
  } catch (e) {
    if (e.code === 'DEPS_MISSING') {
      // Nothing on stdout — a caller interpolating stdout into a cluster/profile name
      // must get an empty value and a non-zero exit, never a guessed version.
      process.stderr.write(e.message + '\n');
      process.exit(2);
    }
    throw e;
  }
  const { version, source, error } = resolved;
  if (error) {
    process.stderr.write(`resolve-camunda-version: ${error} (${configPath})\n`);
    process.exit(2);
  }
  if (!SUPPORTED.includes(version)) {
    // An unsupported value IS an error, so stderr is the right stream and the
    // non-zero exit tells the caller not to use stdout at all.
    process.stderr.write(
      `resolve-camunda-version: unsupported camunda-version "${version}" ` +
        `(supported: ${SUPPORTED.join(', ')}). Fix ${configPath}.\n`,
    );
    process.exit(2);
  }
  if (verbose) process.stderr.write(`resolve-camunda-version: ${version} (${source})\n`);
  process.stdout.write(version + '\n');
}
