#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Parse a tier's BPMN directory and split the parser's JSONL into one file per
// phase, printing the phase stems.
//
// Replaces `PHASES=$(node bpmn-parse-elements.mts "$BPMN_DIR" | node -e '…')` —
// a `VAR=$(…)` capture wrapping a pipe into a multi-line inline JS payload, none
// of which survives native PowerShell 5.1. The payload also had to be re-read for
// every change to it; here the splitting logic has a file and a test.
//
// Usage:
//   node "scripts/split-phase-elements.cjs" <bpmn-dir> [--out <dir>]
//
//   --out   Where the per-phase splits land. Default `process-implementation/artifacts/.analyze-phase`.
//
// Writes `<out>/<stem>.bpmn.json` per phase and prints one stem per line — the
// canonical phase list the Phase 1 fan-out dispatches from.
//
// Exit codes:
//   0  at least one phase was parsed and split
//   2  usage error, the parser could not be started, the parser failed, or it
//      produced no records. An empty phase list is never a success here: the
//      caller would dispatch nothing and report Phase 1 done.

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const EXIT = { OK: 0, DID_NOT_RUN: 2 };

const DEFAULT_OUT = path.join('process-implementation/artifacts', '.analyze-phase');
const PARSER = path.join(__dirname, 'bpmn-parse-elements.mts');

const USAGE = 'usage: split-phase-elements.cjs <bpmn-dir> [--out <dir>]\n';

/**
 * Parse argv into options.
 *
 * @param {string[]} argv Arguments after the script path.
 * @returns {{bpmnDir: string, outDir: string}}
 * @throws {Error} On an unknown flag, a missing value, or no directory.
 */
function parseArgs(argv) {
  let outDir = DEFAULT_OUT;
  let bpmnDir = null;
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--out') {
      const value = argv[++i];
      if (value === undefined) throw new Error('--out requires a value');
      outDir = value;
    } else if (arg.startsWith('--')) {
      throw new Error(`unknown flag: ${arg}`);
    } else if (bpmnDir !== null) {
      throw new Error(`unexpected second directory: ${arg}`);
    } else {
      bpmnDir = arg;
    }
  }
  if (!bpmnDir) throw new Error('a BPMN directory is required');
  return { bpmnDir, outDir };
}

/**
 * Split one JSONL body into per-phase files.
 *
 * @param {string} jsonl The parser's stdout.
 * @param {string} outDir Destination directory (created if absent).
 * @returns {string[]} Phase stems, in the parser's order.
 * @throws {Error} On a line that is not valid JSON — a truncated or corrupted
 *   record must not be silently dropped from the phase list.
 */
function split(jsonl, outDir) {
  const lines = jsonl.trim().split('\n').filter(Boolean);

  // Parse every record before writing any of them. Writing as we go would leave
  // the files from lines 1..n-1 on disk when line n is corrupt, and a partial
  // split is indistinguishable from a complete one to the next step.
  const records = lines.map((line) => {
    let record;
    try {
      record = JSON.parse(line);
    } catch (err) {
      throw new Error(`bpmn-parse-elements.mts emitted an unparseable record: ${err.message}`);
    }
    return { line, stem: path.basename(record.file, '.bpmn') };
  });

  // No records means no phases; creating the directory would leave behind an
  // empty one that reads as a split that ran and found nothing to write.
  if (records.length === 0) return [];

  fs.mkdirSync(outDir, { recursive: true });
  for (const { line, stem } of records) {
    fs.writeFileSync(path.join(outDir, `${stem}.bpmn.json`), line);
  }
  return records.map((r) => r.stem);
}

/**
 * Run the parser over `bpmnDir` and split its output.
 *
 * @param {ReturnType<typeof parseArgs>} options
 * @param {object} [deps]
 * @param {typeof spawnSync} [deps.run] Injectable runner, for tests.
 * @returns {{lines: string[], exitCode: number}}
 */
function splitPhaseElements({ bpmnDir, outDir }, deps = {}) {
  const run = deps.run || spawnSync;
  const result = run(process.execPath, [PARSER, bpmnDir], { encoding: 'utf8' });

  // A parser that never launched produced no phases — distinct from a tier that
  // genuinely has none, and fatal either way at this point in the run.
  if (result.error || result.status === null) {
    return {
      lines: [
        `bpmn-parse-elements.mts could not be started: ${
          result.error ? result.error.message : 'no exit status'
        }`,
      ],
      exitCode: EXIT.DID_NOT_RUN,
    };
  }
  if (result.status !== 0) {
    return {
      lines: [
        `bpmn-parse-elements.mts failed (exit ${result.status}) — no phases were split`,
        (result.stderr || '').trim(),
      ].filter(Boolean),
      exitCode: EXIT.DID_NOT_RUN,
    };
  }

  let stems;
  try {
    stems = split(result.stdout || '', outDir);
  } catch (err) {
    return { lines: [err.message], exitCode: EXIT.DID_NOT_RUN };
  }
  if (stems.length === 0) {
    return {
      lines: [`no parseable BPMN in ${bpmnDir} — no phases to analyse`],
      exitCode: EXIT.DID_NOT_RUN,
    };
  }
  return { lines: stems, exitCode: EXIT.OK };
}

module.exports = { DEFAULT_OUT, EXIT, parseArgs, split, splitPhaseElements };

if (require.main === module) {
  let options;
  try {
    options = parseArgs(process.argv.slice(2));
  } catch (err) {
    process.stderr.write(`split-phase-elements.cjs: ${err.message}\n${USAGE}`);
    process.exit(EXIT.DID_NOT_RUN);
  }
  const { lines, exitCode } = splitPhaseElements(options);
  process.stdout.write(`${lines.join('\n')}\n`);
  process.exit(exitCode);
}
