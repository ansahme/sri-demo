#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Generate the mechanical parts of artifact-proposal.md from .manifest.json
// and the variable-disagreement list emitted by analyze-join.mts.
//
// Replaces the LLM step previously responsible for writing the full proposal
// (it was costing ~9 min in v3). Tables are templated; "Questions for Review"
// is auto-derived from medium/low-confidence flags + unresolved connector
// inputs + ungrounded gateway IDs. The orchestrator can do a focused Edit
// pass for narrative polish if it wants — but the file is complete on first
// write.
//
// Inputs (read from disk):
//   <root>/.manifest.json
//   <root>/.analyze-phase/_disagreements.json   (optional; treated as [] when absent)
//
// Output:
//   <root>/artifact-proposal.md
//
// Usage:
//   node scripts/analyze-proposal.cjs [<artifactRoot>]    (default: "process-implementation/artifacts")

'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = process.argv[2] || 'process-implementation/artifacts';
const MANIFEST_PATH = path.join(ROOT, '.manifest.json');
const DISAGREE_PATH = path.join(ROOT, '.analyze-phase', '_disagreements.json');
const PROPOSAL_PATH = path.join(ROOT, 'artifact-proposal.md');

if (!fs.existsSync(MANIFEST_PATH)) {
  console.error(`analyze-proposal: missing ${MANIFEST_PATH}`);
  console.error('  Run scripts/analyze-join.mts first to produce the manifest.');
  process.exit(2);
}

const manifest = JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf8'));
const disagreements = fs.existsSync(DISAGREE_PATH)
  ? JSON.parse(fs.readFileSync(DISAGREE_PATH, 'utf8'))
  : [];

const md = [];
const m = manifest.meta || {};

md.push('# Artifact Generation Proposal');
md.push('');
md.push('## Process');
md.push(`**Name:** ${m.processName || '_unspecified_'}`);
md.push(`**Package:** ${m.packageBase || '_unspecified_'}`);
md.push(`**Artifact dir:** ${m.artifactDir || 'process-implementation/artifacts/'}`);
md.push('');

md.push('## Proposed Structure');
md.push(`**Type:** ${manifest.structure.type === 'call-activities' ? 'call activities' : 'single process'}`);
md.push(`**Reasoning:** ${manifest.structure.reasoning || ''}`);
md.push('');
if (manifest.structure.type === 'call-activities' && manifest.structure.ioMapping) {
  md.push(`**Parent process:** main-${m.processSlug || 'process'}.bpmn`);
  for (const io of manifest.structure.ioMapping) {
    md.push(`  → CallActivity: ${io.from} → ${io.to} (handoff: ${io.vars.join(', ')})`);
  }
  md.push('');
}

md.push('## Service Tasks → Workers');
md.push('');
if (!manifest.workers || manifest.workers.length === 0) {
  md.push('_No worker entries — all service tasks are connector-bound or absent._');
} else {
  md.push('| Phase | Task | Job Type | Class | Inputs | Outputs | Errors |');
  md.push('|-------|------|----------|-------|--------|---------|--------|');
  for (const w of manifest.workers) {
    const ins = (w.inputVariables || []).map(v => `${v.name}:${v.type}${star(v.confidence)}`).join(', ');
    const outs = (w.outputVariables || []).map(v => `${v.name}:${v.type}${star(v.confidence)}`).join(', ');
    const errs = (w.errors || []).map(e => `${e.code}${star(e.confidence)}`).join(', ');
    md.push(`| ${w.phase} | ${w.elementName || ''} | ${w.jobType} | ${w.className} | ${ins} | ${outs} | ${errs} |`);
  }
}
md.push('');

md.push('## Business Rule Tasks → DMN Decisions');
md.push('');
if (!manifest.decisions || manifest.decisions.length === 0) {
  md.push('_No DMN decisions._');
} else {
  md.push('| Phase | Task | Decision ID | Inputs | Output Variable |');
  md.push('|-------|------|-------------|--------|-----------------|');
  for (const d of manifest.decisions) {
    const ins = (d.inputs || []).map(i => `${i.name}${star(i.confidence)}`).join(', ');
    md.push(`| ${d.phase} | ${d.taskName || d.elementName || d.taskId} | ${d.decisionId} | ${ins} | ${d.resultVariable} |`);
  }
}
md.push('');

md.push('## User Tasks → Forms');
md.push('');
if (!manifest.forms || manifest.forms.length === 0) {
  md.push('_No user task forms._');
} else {
  md.push('| Phase | Task | Form ID | Inferred Fields |');
  md.push('|-------|------|---------|-----------------|');
  for (const f of manifest.forms) {
    const fields = (f.fields || []).map(fl => `${fl.key || fl.name || fl.id}${star(fl.confidence)}`).join(', ');
    md.push(`| ${f.phase} | ${f.elementName || ''} | ${f.formId} | ${fields} |`);
  }
}
md.push('');

md.push('## Connector Bindings');
md.push('');
if (!manifest.connectorBindings || manifest.connectorBindings.length === 0) {
  md.push('_No connector bindings._');
} else {
  md.push('| Phase | Element | Template | Version | Unresolved Inputs |');
  md.push('|-------|---------|----------|---------|--------------------|');
  for (const b of manifest.connectorBindings) {
    const unres = (b.wiring && b.wiring.unresolvedInputs || [])
      .filter(u => !u.source)
      .map(u => u.target)
      .join(', ');
    md.push(`| ${b.phase} | ${b.elementName || b.elementId} | ${b.templateId || '_(none)_'} | ${b.templateVersion || ''} | ${unres || '_(all resolved)_'} |`);
  }
}
md.push('');

md.push('## Questions for Review');
md.push('');

// Subsection 1: variable type disagreements
md.push('### Variable type disagreements (cross-phase)');
md.push('');
let n = 1;
if (disagreements.length === 0) {
  md.push('_None._');
} else {
  for (const d of disagreements) {
    const detail = d.phases.map((p, i) => `phase \`${p}\` infers \`${d.types[i] || d.types[d.types.length - 1]}\``).join('; ');
    md.push(`${n}. Variable \`${d.name}\`: ${detail}. Which type should the manifest use?`);
    n++;
  }
}
md.push('');

// Subsection 2: per-element review questions
md.push('### Per-element review questions');
md.push('');
const questions = collectReviewQuestions(manifest);
if (questions.length === 0) {
  md.push('_None — all inferences high-confidence._');
} else {
  for (const q of questions) {
    md.push(`${n}. ${q}`);
    n++;
  }
}
md.push('');
md.push('If you have no corrections, reply "proceed" to start generation.');
md.push('');

fs.writeFileSync(PROPOSAL_PATH, md.join('\n'));
console.log(`analyze-proposal: wrote ${PROPOSAL_PATH}`);
console.log(`  variable disagreements: ${disagreements.length}`);
console.log(`  per-element review questions: ${questions.length}`);

// ── helpers ──────────────────────────────────────────────────────────────
function star(confidence) {
  return (confidence === 'medium' || confidence === 'low') ? '*' : '';
}

function collectReviewQuestions(manifest) {
  const out = [];
  for (const w of (manifest.workers || [])) {
    for (const v of (w.inputVariables || [])) {
      if (v.confidence && v.confidence !== 'high') {
        out.push(`Worker \`${w.className}\`: input variable \`${v.name}\` (\`${v.type}\`) — confidence ${v.confidence}; please confirm name and type.`);
      }
    }
    for (const v of (w.outputVariables || [])) {
      if (v.confidence && v.confidence !== 'high') {
        out.push(`Worker \`${w.className}\`: output variable \`${v.name}\` (\`${v.type}\`) — confidence ${v.confidence}; please confirm name and type.`);
      }
    }
    for (const e of (w.errors || [])) {
      if (e.confidence && e.confidence !== 'high') {
        out.push(`Worker \`${w.className}\`: error code \`${e.code}\` (source: ${e.source || 'inferred'}) — confidence ${e.confidence}.`);
      }
    }
  }
  for (const f of (manifest.forms || [])) {
    for (const fl of (f.fields || [])) {
      if (fl.confidence && fl.confidence !== 'high') {
        out.push(`Form \`${f.formId}\`: field \`${fl.key || fl.name || fl.id}\` (\`${fl.type}\`${fl.required ? ', required' : ''}) — confidence ${fl.confidence}; please confirm.`);
      }
    }
  }
  for (const d of (manifest.decisions || [])) {
    for (const i of (d.inputs || [])) {
      if (i.confidence && i.confidence !== 'high') {
        out.push(`Decision \`${d.decisionId}\`: input \`${i.name}\` (\`${i.type}\`) — confidence ${i.confidence}.`);
      }
    }
    if (!d.gatewayId && !(d.wiring && d.wiring.gatewayElementId)) {
      out.push(`Decision \`${d.decisionId}\`: no grounded gatewayId — does a gateway exist after \`${d.taskId}\`?`);
    }
  }
  for (const b of (manifest.connectorBindings || [])) {
    for (const u of ((b.wiring && b.wiring.unresolvedInputs) || [])) {
      if (!u.source) {
        out.push(`Connector \`${b.elementId}\` (${b.templateId || 'no template'}): input \`${u.target}\` has no source value — what FEEL expression or literal should drive it?`);
      }
    }
  }
  return out;
}
