#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Decide whether the connected cluster supports wait-state search
// (`c8ctl search ws`), which Camunda added in 8.10.
//
// Replaces an eight-line `c8ctl --json get topology | node -e "…"` payload that
// process-os-governance-job-activation used inline. That shape had two defects:
//
//   1. It read c8ctl's JSON over a shell pipe. On native PowerShell 5.1 the pipe
//      can carry a BOM preamble, so `JSON.parse` throws. This script runs c8ctl
//      itself, so no shell sits in the pipeline at all.
//   2. Every failure exited 1, and the skills read exit 1 as "cluster < 8.10". An
//      unreachable cluster, a missing c8ctl and an auth error all became a
//      confident, wrong capability decision. "I could not tell" is now its own
//      outcome.
//
// Usage:
//   node "c8ctl-wait-state-support.cjs" [--profile <name>]
//
// Prints exactly one word to stdout; any explanation goes to stderr, so the
// stdout token is safe to capture:
//   SUPPORTED      exit 0  — cluster >= 8.10, use `c8ctl search ws`
//   UNSUPPORTED    exit 1  — cluster < 8.10, use the documented fallback
//   UNDETERMINED   exit 2  — the check itself did not complete; the caller must
//                            say so rather than assume either answer
//
// c8ctl writes progress to stderr even on success, so stderr is captured and kept
// separate from stdout and never consulted for success — the exit code is the only
// success signal. See shared/references/c8ctl.md → Stream contract.

const { runShellCli } = require('./resolve-node-cli.cjs');
const { stripBOM } = require('./strip-bom.cjs');

/** The Camunda release that introduced wait-state search. */
const SUPPORTED_FROM = '8.10';

const [FLOOR_MAJOR, FLOOR_MINOR] = SUPPORTED_FROM.split('.').map(Number);

/**
 * Compare a version string against SUPPORTED_FROM.
 *
 * Compares major and minor as numbers. String comparison would put "8.9" above
 * "8.10", which is the wrong way round for every cluster in the 8.9 line.
 *
 * @param {string|undefined} raw A version, possibly embedded in other text.
 * @returns {number|null} Negative below the floor, 0 at it, positive above it;
 *   null when `raw` carries no recognisable version.
 */
function compareToFloor(raw) {
  const m = String(raw == null ? '' : raw).match(/(\d+)\.(\d+)/);
  if (!m) return null;
  const major = Number(m[1]);
  const minor = Number(m[2]);
  if (major !== FLOOR_MAJOR) return major - FLOOR_MAJOR;
  return minor - FLOOR_MINOR;
}

/**
 * @typedef {Object} Outcome
 * @property {'SUPPORTED'|'UNSUPPORTED'|'UNDETERMINED'} verdict Token printed to stdout.
 * @property {number} exitCode 0 supported, 1 unsupported, 2 undetermined.
 * @property {string} [reason] Why, for stderr. Only set for UNDETERMINED.
 */

/**
 * Turn a parsed topology response into a verdict.
 *
 * @param {Object|null} topology Parsed `c8ctl --json get topology` output.
 * @returns {Outcome}
 */
function decide(topology) {
  const version = topology && topology.gatewayVersion;
  const cmp = compareToFloor(version);
  if (cmp === null) {
    return {
      verdict: 'UNDETERMINED',
      exitCode: 2,
      reason: 'topology response carried no readable gatewayVersion',
    };
  }
  return cmp >= 0
    ? { verdict: 'SUPPORTED', exitCode: 0 }
    : { verdict: 'UNSUPPORTED', exitCode: 1 };
}

/**
 * Ask the cluster for its topology and decide.
 *
 * @param {Object} [opts]
 * @param {string|null} [opts.profile] c8ctl profile name, or null for the active one.
 * @param {function} [opts.run] Runner in runShellCli's shape; injected by tests.
 * @returns {Outcome}
 */
function checkWaitStateSupport(opts = {}) {
  const run = opts.run || runShellCli;
  const args = ['--json', 'get', 'topology'];
  if (opts.profile) args.push('--profile', opts.profile);

  // c8ctl installs as a global npm bin, so on Windows it exists only as
  // `c8ctl.cmd`. runShellCli is the reviewed wrapper that handles that and still
  // decides "not on PATH" itself rather than letting a shell absorb it.
  const r = run('c8ctl', args, { stdio: ['ignore', 'pipe', 'pipe'], encoding: 'utf8' });

  if (!r.launched) {
    return {
      verdict: 'UNDETERMINED',
      exitCode: 2,
      reason: `c8ctl did not run: ${(r.error && r.error.message) || 'unknown reason'}`,
    };
  }
  if (r.status !== 0) {
    return {
      verdict: 'UNDETERMINED',
      exitCode: 2,
      reason: `c8ctl exited ${r.status}: ${String(r.stderr || '').trim() || '(no output)'}`,
    };
  }

  const text = stripBOM(String(r.stdout || ''));
  let topology;
  try {
    topology = JSON.parse(text);
  } catch (err) {
    return {
      verdict: 'UNDETERMINED',
      exitCode: 2,
      reason: `c8ctl output was not JSON (${err.message}). Is \`c8ctl output json\` set?`,
    };
  }
  return decide(topology);
}

/**
 * @param {string[]} argv Arguments after the script name.
 * @returns {{profile: string|null}|null} null on a usage error.
 */
function parseArgs(argv) {
  let profile = null;
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] !== '--profile') return null;
    profile = argv[++i];
    if (profile === undefined) return null;
  }
  return { profile };
}

module.exports = { SUPPORTED_FROM, compareToFloor, decide, checkWaitStateSupport, parseArgs };

if (require.main === module) {
  const parsed = parseArgs(process.argv.slice(2));
  if (!parsed) {
    process.stderr.write('usage: c8ctl-wait-state-support.cjs [--profile <name>]\n');
    process.stdout.write('UNDETERMINED\n');
    process.exit(2);
  }
  const outcome = checkWaitStateSupport({ profile: parsed.profile });
  if (outcome.reason) process.stderr.write(`c8ctl-wait-state-support: ${outcome.reason}\n`);
  process.stdout.write(`${outcome.verdict}\n`);
  process.exit(outcome.exitCode);
}
