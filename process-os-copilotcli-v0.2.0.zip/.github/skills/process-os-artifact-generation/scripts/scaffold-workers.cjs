#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Scaffold a Camunda worker project by COPYING an engagement-blueprint
// (skills/process-os-artifact-generation/blueprints/<targetSdk>/) into the
// artifact root, applying package/name substitutions and the scaffold-vs-example
// split documented in job-worker-architecture.md.
//
// Replaces the prior Spring Initializr fetch+patch pipeline: no network, no
// tarball cache, no hand-patched pom / Application.java / application*.yaml —
// those now come verbatim from the blueprint.
//
// Pipeline:
//   1. Read manifest meta (packageBase, processSlug, processCamel required;
//      packageBase additionally has to be a real package name, not merely present
//      (isPackageName, from the run-config schema module);
//      targetSdk defaults to "java-spring-boot").
//   2. Select the blueprint dir: --blueprint-path <dir> overrides; else
//      <skillsRoot>/skills/process-os-artifact-generation/blueprints/<targetSdk>.
//      Only java-spring-boot, typescript and python are implemented; any other
//      SDK exits 2 ("not yet supported").
//   3a. java-spring-boot: copy the reusable scaffold (pom.xml, lombok.config,
//       application*.yaml, <ProcessCamel>Application.java, the three ArchUnit
//       tests) with substitutions applied; DROP the example domain
//       (clients/services/workers/demo-models/example-coupled config+exceptions,
//       demo tests, demo BPMN); create the empty package tree; then GENERATE
//       models/ProcessVariables.java from the manifest variable union.
//   3b. typescript: copy build manifests + src skeleton, minus the example
//       workers/services/clients, the demo model, the demo properties config,
//       the demo HTTP error class, all *.test.ts, the test/ dir, and the two
//       pnpm-only files; substitute the npm package name; apply post-copy
//       patches (linter snapshot exclusion, test-runner no-test tolerance,
//       main.ts deploy-on-start removal, packageManager removal, demo env-key
//       removal); replace app.ts with an empty worker registry; emit NO .java.
//       The worker layer itself is generate-workers-typescript.cjs's job.
//   3c. python: copy pyproject.toml + uv.lock + .python-version + .env.example
//       and the src/ skeleton, minus the example clients/services/workers, the
//       demo model, the demo properties config, the demo BPMN and every demo
//       test; substitute the distribution name in BOTH pyproject.toml and uv.lock
//       (a name in only one of them fails `uv sync --frozen`); apply post-copy
//       patches (demo env-key removal, main.py deploy-on-start removal); then
//       GENERATE models/process_variables.py from the manifest variable union and
//       app.py. app.py is generated rather than copied because the blueprint's own copy
//       imports the example domain this split drops.
//   4. Write `.gitattributes` into the artifact root so the scaffolded tree
//      normalizes to LF regardless of platform — independent of whether the
//      enclosing project ever got one via `c8 os install`. This is what lets
//      Spotless's default GIT_ATTRIBUTES_FAST_ALLSAME line-ending policy
//      normalize the Java sources it formats at process-sources with no
//      <lineEndings> override in the blueprint pom (verified: `spotless:apply`
//      honors a `.gitattributes` with no `.git/` directory present at all).
//
// All steps idempotent — re-running over a scaffolded tree overwrites files and
// re-creates dirs (recursive) without erroring or duplicating. `.gitattributes`
// is the one exception: re-running only appends whatever lines are still missing,
// so a project's own hand-added rules survive a re-scaffold instead of being clobbered.
//
// Usage:
//   node scripts/scaffold-workers.cjs <artifactRoot> [--blueprint-path <dir>] [--summary <path.json>]
//
// Defaults: artifactRoot = "process-implementation/artifacts".
//
// --summary <path.json> writes a machine-readable summary of the pinned
// dependency versions, read from the BLUEPRINT sources (java-spring-boot/pom.xml
// + .mvn/wrapper/maven-wrapper.properties + typescript/package.json) — the source
// of truth — plus the Camunda client map from versions.json. It covers everything
// a fresh machine must download to build and test a scaffolded project: project
// dependencies, Maven build PLUGINS, the Maven distribution the wrapper fetches,
// and the Node/pnpm toolchain floors the TS blueprint declares. Output is
// timestamp-free so it stays deterministic/diffable across runs.
//
// Exit codes: 0 success; 2 missing inputs / unsupported SDK; 3 copy/IO failure.

'use strict';

const fs = require('fs');
const path = require('path');
const { appendLines } = require(path.join(__dirname, 'append-gitignore.cjs'));
// The package-name grammar, declared once beside the `package-group` run-config key it
// constrains, so this check and the governance form's field validation cannot diverge.
const { isPackageName } = require(path.join(__dirname, 'run-config-schema.cjs'));
// The Python field-name conversion and type map, shared with the Python worker
// generator. Both write src/models/process_variables.py, so both derive field
// names from one rule.
const { toPyField, mapPyType, toPyPackageName } = require('./python-naming.cjs');
// Compares the blueprint's exact SDK pin against the major range versions.json
// declares for a cluster minor.
const { VERDICT, satisfies: satisfiesRange } = require('./python-version-spec.cjs');
// The TypeScript app.ts renderer, shared with the worker generator, so the
// scaffold's empty registry and the generated one satisfy the same contract.
const { renderApp } = require('./generate-workers-typescript-emit.cjs');

const SUPPORTED_SDKS = ['java-spring-boot', 'typescript', 'python'];
const BLUEPRINT_PKG = 'com.camunda.consulting.blueprint';
const BLUEPRINT_PKG_PATH = 'com/camunda/consulting/blueprint';

const GITATTRIBUTES_LINES = [
  '* text=auto eol=lf',
  '*.bpmn text eol=lf',
  '*.dmn text eol=lf',
  '*.form text eol=lf',
];

// The demo-only env keys the python scaffold drops from both env.py and
// .env.example. Every remaining reader of each is itself dropped by
// isPyExampleOrTest or removed by patchPyMain, so leaving them would ship config
// with no consumer. Declared here, with the other top constants, because the
// top-level dispatch below runs before a `const` further down the file is
// initialized (see GITATTRIBUTES_LINES for the same reason).
const PY_DEMO_ENV_KEYS = [
  'BLUEPRINT_RESULT_PREFIX',
  'BLUEPRINT_DEPLOY_ON_START',
  'EXTERNAL_API_A_BASE_URL',
  'EXTERNAL_API_B_BASE_URL',
];

// ── argv ──────────────────────────────────────────────────────────────────
const argv = process.argv.slice(2);
let ARTIFACT_ROOT = 'process-implementation/artifacts';
let BLUEPRINT_PATH = null;
let SUMMARY_PATH = null;
for (let i = 0; i < argv.length; i++) {
  if (argv[i] === '--blueprint-path' || argv[i] === '--summary') {
    const flag = argv[i];
    const val = argv[i + 1];
    // A value-taking flag must be followed by a real value, not EOL or another
    // flag — otherwise `--summary` at the end would silently write nothing and
    // `--summary --blueprint-path x` would swallow the next flag as the path.
    if (val === undefined || val.startsWith('-')) {
      console.error(`scaffold-workers: ${flag} requires a value`);
      process.exit(2);
    }
    if (flag === '--blueprint-path') BLUEPRINT_PATH = val; else SUMMARY_PATH = val;
    i++;
    continue;
  }
  if (!argv[i].startsWith('-')) ARTIFACT_ROOT = argv[i];
}

const MANIFEST_PATH = path.join(ARTIFACT_ROOT, '.manifest.json');
const SKILLS_ROOT = skillsRoot();
const VERSIONS_PATH = path.join(SKILLS_ROOT, 'skills', 'process-os-artifact-generation', 'versions.json');

if (!fs.existsSync(MANIFEST_PATH)) {
  console.error(`scaffold-workers: missing ${MANIFEST_PATH}`);
  process.exit(2);
}

const manifest = JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf8'));
const meta = manifest.meta || {};

const requiredMeta = ['packageBase', 'processSlug', 'processCamel'];
for (const k of requiredMeta) {
  if (!meta[k]) { console.error(`scaffold-workers: manifest.meta.${k} is required`); process.exit(2); }
}

// Present is not the same as usable. packageBase becomes a package declaration, a
// <groupId> and — via PACKAGE_PATH below — a directory chain, so a segment that is not an
// identifier scaffolds a whole tree and then fails at the build gate, far from the value
// that caused it.
//
// Both of its inputs can produce such a segment: the leading ones come from run.config.yaml's
// package-group, the last from processSlug (a process named for a year gives a slug, and so a
// segment, that starts with a digit). Name the offending segment rather than one input, so the
// reader is not sent to the wrong place.
if (!isPackageName(meta.packageBase)) {
  const bad = String(meta.packageBase).split('.').find((seg) => !isPackageName(seg));
  const shown = bad === '' ? '(empty)' : `'${bad}'`;
  console.error(
    `scaffold-workers: manifest.meta.packageBase '${meta.packageBase}' is not a package ` +
      `name — the segment ${shown} must start with a letter and hold only letters, digits ` +
      'and underscores. Its leading segments come from the run.config.yaml package-group key and ' +
      'its last from the process slug; fix whichever produced that segment.',
  );
  process.exit(2);
}

const targetSdk = meta.targetSdk || 'java-spring-boot';
if (!SUPPORTED_SDKS.includes(targetSdk)) {
  console.error(`scaffold-workers: target SDK '${targetSdk}' not yet supported`);
  process.exit(2);
}

// versions.json now holds ONLY the Camunda CLIENT version map (per-cluster-minor)
// substituted into the bundle pom (see resolveClientCamundaVersion). All other
// pinned versions (Spring Boot, Java, ArchUnit, …) come from the blueprint pom
// itself — that is the source of truth, and what the report line and
// --summary read. A missing/unreadable file is non-fatal — the pom then keeps
// the blueprint's own `<camunda.version>` pin.
let versions = {};
try { versions = JSON.parse(fs.readFileSync(VERSIONS_PATH, 'utf8')); } catch { /* non-fatal */ }

// Resolve the stable Camunda Java CLIENT version to pin into the pom, from the
// project's TO-BE cluster minor (manifest.meta.camundaClusterVersion, set by
// SKILL.md step 1.2 via resolve-camunda-version.cjs). null → leave the
// blueprint's pin untouched.
const CLIENT_CAMUNDA = resolveClientCamundaVersion(meta.camundaClusterVersion, versions.camunda);

// The camunda-orchestration-sdk range the Python blueprint is EXPECTED to pin for
// this project's cluster minor. Verified, never substituted — see
// versions.json's camundaPython comment and checkPythonSdkRange().
const PYTHON_SDK_RANGE = resolvePythonSdkRange(meta.camundaClusterVersion, versions.camundaPython);

const BLUEPRINT_DIR = BLUEPRINT_PATH
  || path.join(SKILLS_ROOT, 'skills', 'process-os-artifact-generation', 'blueprints', targetSdk);

if (!fs.existsSync(BLUEPRINT_DIR)) {
  console.error(`scaffold-workers: blueprint dir not found: ${BLUEPRINT_DIR}`);
  process.exit(2);
}

const PACKAGE_PATH = meta.packageBase.replace(/\./g, '/');

// The top-level package a generated Python project installs as, derived from
// meta.processSlug. Computed unconditionally (like PACKAGE_PATH above) because
// it is cheap and pure; only scaffoldPython() validates and uses it, so a
// processSlug that cannot convert never blocks a Java or TypeScript target.
const PY_PACKAGE = toPyPackageName(meta.processSlug);

try {
  if (targetSdk === 'java-spring-boot') {
    scaffoldJavaSpringBoot();
  } else if (targetSdk === 'typescript') {
    scaffoldTypescript();
  } else if (targetSdk === 'python') {
    scaffoldPython();
  }
  writeGitattributes(ARTIFACT_ROOT);
} catch (err) {
  console.error(`scaffold-workers: ${err.message}`);
  process.exit(3);
}

// Optional --summary <path>: emit the machine-readable dependency summary read
// from the blueprint sources. Independent of targetSdk (it summarizes both
// blueprints) and of any per-project substitution.
if (SUMMARY_PATH) {
  try {
    writeSummary(SUMMARY_PATH);
  } catch (err) {
    console.error(`scaffold-workers: ${err.message}`);
    process.exit(3);
  }
}

// ──────────────────────────────────────────────────────────────────────────
// java-spring-boot
// ──────────────────────────────────────────────────────────────────────────

function scaffoldJavaSpringBoot() {
  const PKG_DIR = path.join(ARTIFACT_ROOT, 'src', 'main', 'java', PACKAGE_PATH);
  const TEST_DIR = path.join(ARTIFACT_ROOT, 'src', 'test', 'java', PACKAGE_PATH);

  // 1. Reusable scaffold files copied verbatim (with substitutions).
  copyWithSubst(
    path.join(BLUEPRINT_DIR, 'pom.xml'),
    path.join(ARTIFACT_ROOT, 'pom.xml'),
    substituteJava,
  );
  copyWithSubst(
    path.join(BLUEPRINT_DIR, 'lombok.config'),
    path.join(ARTIFACT_ROOT, 'lombok.config'),
    substituteJava,
  );
  for (const rel of [
    'src/main/resources/application.yaml',
    'src/main/resources/application-local.yaml',
    'src/main/resources/application-saas.yaml',
    'src/test/resources/application.yaml',
  ]) {
    copyWithSubst(path.join(BLUEPRINT_DIR, rel), path.join(ARTIFACT_ROOT, rel), substituteJava);
  }

  // 1b. Maven wrapper — copied verbatim (no substitution) when the blueprint
  // ships the FULL set, so the scaffold builds standalone (`./mvnw`) without a
  // preinstalled Maven, pinning the Maven version from
  // .mvn/wrapper/maven-wrapper.properties. mvnw's exec bit is preserved by
  // copyFile. Optional, not required: run-maven.cjs and spring-worker-app.cjs
  // both fall back to an installed `mvn` on PATH when a scaffold carries no
  // wrapper, which is the blueprint's call to make, not this script's.
  // Treated as one atomic set, not per-file best-effort: run-maven.cjs's
  // wrapperIn() only checks for mvnw/mvnw.cmd, so a scaffold with the scripts but
  // not the properties file they read would make it prefer a wrapper that
  // cannot actually build.
  const WRAPPER_FILES = ['mvnw', 'mvnw.cmd', '.mvn/wrapper/maven-wrapper.properties'];
  if (WRAPPER_FILES.every((rel) => fs.existsSync(path.join(BLUEPRINT_DIR, rel)))) {
    for (const rel of WRAPPER_FILES) {
      copyVerbatim(path.join(BLUEPRINT_DIR, rel), path.join(ARTIFACT_ROOT, rel));
    }
  }

  // 2. <ProcessCamel>Application.java — relocated into the target package.
  copyWithSubst(
    path.join(BLUEPRINT_DIR, 'src/main/java', BLUEPRINT_PKG_PATH, 'BlueprintApplication.java'),
    path.join(PKG_DIR, `${meta.processCamel}Application.java`),
    substituteJava,
  );

  // 3. Generic layering tests — relocated into the target package's architecture/.
  for (const cls of ['LayerArchitectureTest', 'AnnotationUsageTest', 'StereotypeConventionTest']) {
    copyWithSubst(
      path.join(BLUEPRINT_DIR, 'src/test/java', BLUEPRINT_PKG_PATH, 'architecture', `${cls}.java`),
      path.join(TEST_DIR, 'architecture', `${cls}.java`),
      substituteJava,
    );
  }

  // 4. Empty package tree (example domain classes are intentionally NOT copied).
  //
  // Nothing clears the Java tree before a rerun. Scaffold only creates these
  // directories and recreates ProcessVariables.java below; a class for a job
  // type since removed from the manifest is not cleaned up here.
  for (const sub of ['workers', 'services', 'clients', 'models', 'config', 'config/properties', 'exceptions']) {
    fs.mkdirSync(path.join(PKG_DIR, sub), { recursive: true });
  }
  fs.mkdirSync(path.join(TEST_DIR, 'architecture'), { recursive: true });

  // 5. ProcessVariables.java generated from the manifest (overwrites any copy).
  writeProcessVariables(path.join(PKG_DIR, 'models', 'ProcessVariables.java'), meta, manifest);

  // ── Report ── versions sourced from the blueprint pom (source of truth);
  // the camunda line reports the resolved CLIENT pin when one applies.
  const bp = parseBlueprintPom(path.join(BLUEPRINT_DIR, 'pom.xml'));
  const camundaReport = CLIENT_CAMUNDA ? CLIENT_CAMUNDA.version
    : (bp.properties.camunda || '?');
  console.log(`scaffold-workers: ${ARTIFACT_ROOT}/ ready from java-spring-boot blueprint`);
  console.log(`  versions: boot=${bp.parent.version || '?'}, java=${bp.properties.java || '?'}, camunda=${camundaReport}, archunit=${bp.properties.archunit || '?'}`);
  if (CLIENT_CAMUNDA && CLIENT_CAMUNDA.lag) {
    console.log(`  note: cluster minor ${meta.camundaClusterVersion} has no GA Camunda Java client yet — pinning latest stable client ${CLIENT_CAMUNDA.version}`);
  }
  console.log(`  package tree under ${PKG_DIR}/`);
  console.log(`  ArchUnit tests under ${TEST_DIR}/architecture/`);
}

// substituteJava — package + coordinate + class-name substitutions on Java/pom/yaml text.
// Order: the longer dotted/slashed package strings first, then the exact pom
// coordinate lines, then the Application class-name prefix.
function substituteJava(text) {
  let out = text
    .split(BLUEPRINT_PKG).join(meta.packageBase)
    .split(BLUEPRINT_PKG_PATH).join(PACKAGE_PATH);
  out = out
    .replace('<groupId>com.camunda.consulting</groupId>', `<groupId>${meta.packageBase}</groupId>`)
    .replace('<artifactId>engagement-blueprint</artifactId>', `<artifactId>${meta.processSlug}</artifactId>`)
    .replace('<name>Camunda Consulting Blueprint Project</name>', `<name>${meta.processCamel}</name>`);
  out = out.split('BlueprintApplication').join(`${meta.processCamel}Application`);
  // Pin the resolved stable client version into the pom's `<camunda.version>`
  // (no-op on the other substituted files, which carry no such element).
  if (CLIENT_CAMUNDA) {
    out = out.replace(
      /<camunda\.version>[^<]*<\/camunda\.version>/,
      `<camunda.version>${CLIENT_CAMUNDA.version}</camunda.version>`,
    );
  }
  return out;
}

// ──────────────────────────────────────────────────────────────────────────
// typescript
// ──────────────────────────────────────────────────────────────────────────

function scaffoldTypescript() {
  // 1. Build manifests + tooling config, copied verbatim (npm name substituted).
  //
  // pnpm-lock.yaml and pnpm-workspace.yaml are deliberately absent. The
  // generated project's package manager is npm: `pnpm-workspace.yaml` carries
  // only pnpm's `allowBuilds` install-script allowlist, which npm has no
  // equivalent for, and `pnpm-lock.yaml`'s transitive pins are pnpm-specific and
  // cannot be carried forward. Excluding beats copying-then-deleting: the clean
  // step precedes the copy, so anything copied would reappear on every run.
  const manifests = [
    'package.json',
    'tsconfig.json',
    'tsconfig.build.json',
    'biome.json',
    'vitest.config.ts',
    '.dependency-cruiser.mjs',
  ];
  for (const rel of manifests) {
    const src = path.join(BLUEPRINT_DIR, rel);
    if (fs.existsSync(src)) copyWithSubst(src, path.join(ARTIFACT_ROOT, rel), substituteTs);
  }

  // 2. src/ skeleton minus the example domain + all tests.
  const srcRoot = path.join(BLUEPRINT_DIR, 'src');
  copyTree(srcRoot, path.join(ARTIFACT_ROOT, 'src'), (rel) => !isTsExampleOrTest(rel), substituteTs);

  // 3. Post-copy patches. The blueprint keeps sensible standalone-project
  //    defaults; these patches are demo-to-generated-project conversions, not
  //    upstream-sync protection, so they are applied here instead of editing
  //    the blueprint directly, following the same copy-then-overwrite pattern
  //    this script already uses for ProcessVariables.java.
  patchTsVitestConfig(path.join(ARTIFACT_ROOT, 'vitest.config.ts'));
  patchTsMain(path.join(ARTIFACT_ROOT, 'src', 'main.ts'));
  patchTsPackageJson(path.join(ARTIFACT_ROOT, 'package.json'));
  patchTsEnv(path.join(ARTIFACT_ROOT, 'src', 'config', 'env.ts'));
  // The blueprint's app.ts wires the dropped example domain; an empty registry
  // keeps the scaffold-only project typechecking until workers are generated.
  fs.writeFileSync(path.join(ARTIFACT_ROOT, 'src', 'app.ts'), renderApp([]));

  // The build gate's `npm install`/`npm run build` land node_modules/ and
  // dist/ inside the artifact root, which is committed project tree, so they
  // must not reach `git add`. gitignore syntax requires forward slashes
  // regardless of platform, so this doesn't go through path.join.
  const gitignoreRoot = ARTIFACT_ROOT.replace(/\\/g, '/');
  appendLines([`${gitignoreRoot}/node_modules/`, `${gitignoreRoot}/dist/`]);

  console.log(`scaffold-workers: ${ARTIFACT_ROOT}/ ready from typescript blueprint`);
  console.log('  package manager: npm (the blueprint pnpm pin and lockfile are not copied)');
  console.log('  next: node "scripts/generate-workers-typescript.cjs" ' + ARTIFACT_ROOT);
}

// Every patch below anchors on CONTENT, never on line numbers, and throws when
// an anchor is missing. A direct edit to the blueprint that reshapes one of
// these files then breaks the build instead of silently producing a stale
// patch. The throw is caught by the top-level try/catch and becomes exit 3.

/**
 * A generated project has no test files, while the blueprint's config
 * globs for them with no tolerance — so the blueprint's own test script would be
 * a guaranteed failure for a user who runs it.
 */
function patchTsVitestConfig(p) {
  const ANCHOR = '  test: {\n    projects: [';
  const text = fs.readFileSync(p, 'utf8');
  if (!text.includes(ANCHOR)) {
    throw new Error(`vitest.config.ts: anchor not found — the blueprint doesn't have the expected shape (${p})`);
  }
  if (/passWithNoTests/.test(text)) return; // idempotent
  fs.writeFileSync(p, text.replace(ANCHOR, '  test: {\n    passWithNoTests: true,\n    projects: ['));
}

/**
 * Remove deploy-on-start. Deploying resources belongs to
 * process-os-deployment; the generated Java application has no deploy-on-start
 * either; and the block's opt-in flag would crash at startup on a BPMN path the
 * generated bundle does not contain. The two imports that only served it go too,
 * because biome treats an unused import as an error.
 */
function patchTsMain(p) {
  const CUTS = [
    'import path from "node:path"\n',
    'const BPMN_PATH = path.resolve(import.meta.dirname, "..", "resources", "blueprint-process.bpmn")\n' +
      '\n' +
      'const deployBpmn = async (client: CamundaClient, log: Logger): Promise<void> => {\n' +
      '  log.info({ path: BPMN_PATH }, "deploying BPMN process")\n' +
      '  const { processes } = await client.deployResourcesFromFiles([BPMN_PATH])\n' +
      '  log.info({ processes }, "BPMN deployment succeeded")\n' +
      '}\n' +
      '\n',
    '  if (env.BLUEPRINT_DEPLOY_ON_START) {\n' +
      '    await deployBpmn(client, log)\n' +
      '  }\n' +
      '\n',
  ];
  const REPLACEMENTS = [
    [
      'import { type CamundaClient, createCamundaClient } from "@camunda8/orchestration-cluster-api"',
      'import { createCamundaClient } from "@camunda8/orchestration-cluster-api"',
    ],
  ];

  let text = fs.readFileSync(p, 'utf8');
  // Idempotent: a second run finds none of the anchors and must not throw.
  // Keyed on BPMN_PATH rather than BLUEPRINT_DEPLOY_ON_START: the latter
  // appears only inside the if-condition CUTS removes, so a direct edit to
  // just that line would also make BLUEPRINT_DEPLOY_ON_START vanish and get
  // misread as "already patched" instead of "anchor mismatch — throw".
  if (!text.includes('BPMN_PATH')) return;

  for (const cut of CUTS) {
    if (!text.includes(cut)) {
      throw new Error(
        `main.ts: deploy-on-start anchor not found — the blueprint doesn't have the expected shape (${p}):\n${cut.split('\n')[0]}`,
      );
    }
    text = text.replace(cut, '');
  }
  for (const [from, to] of REPLACEMENTS) {
    if (!text.includes(from)) {
      throw new Error(`main.ts: import anchor not found — the blueprint doesn't have the expected shape (${p}): ${from}`);
    }
    text = text.replace(from, to);
  }
  fs.writeFileSync(p, text);
}

/**
 * The generated project's package manager is npm, so the blueprint's
 * pnpm pin must not travel with it — corepack would otherwise be pulled into the
 * build gate's failure surface, and its one documented real-world failure mode
 * is a corporate proxy blocking its registry.npmjs.org fetch with HTTP 403.
 */
function patchTsPackageJson(p) {
  const text = fs.readFileSync(p, 'utf8');
  const pkg = JSON.parse(text);
  if (!('packageManager' in pkg)) {
    throw new Error(
      `package.json: no packageManager field to drop — the blueprint doesn't have it; ` +
        `re-check whether this patch is still needed (${p})`,
    );
  }
  delete pkg.packageManager;
  fs.writeFileSync(p, `${JSON.stringify(pkg, null, 2)}\n`);
}

/**
 * Drop the demo-only env keys. Every remaining reader of each is
 * itself excluded from the copy or removed by an earlier patch:
 * BLUEPRINT_RESULT_PREFIX's only reader is blueprint-properties.ts
 * (isTsExampleOrTest drops it), EXTERNAL_API_A/B_BASE_URL's only readers are
 * the dropped clients/services, and BLUEPRINT_DEPLOY_ON_START's only reader is
 * cut by patchTsMain. Left in place they are config with no consumer.
 */
function patchTsEnv(p) {
  const CONST_LINE = 'const DEFAULT_EXTERNAL_API_BASE_URL = "http://localhost:8089"\n\n';
  const SCHEMA_LINES =
    '  EXTERNAL_API_A_BASE_URL: z.url().default(DEFAULT_EXTERNAL_API_BASE_URL),\n' +
    '  EXTERNAL_API_B_BASE_URL: z.url().default(DEFAULT_EXTERNAL_API_BASE_URL),\n' +
    '  BLUEPRINT_RESULT_PREFIX: z.string().default("[DEMO]_"),\n' +
    '  BLUEPRINT_DEPLOY_ON_START: z.stringbool().default(false),\n';

  let text = fs.readFileSync(p, 'utf8');
  // Idempotent: a second run finds the const already gone and must not throw.
  if (!text.includes(CONST_LINE)) return;

  if (!text.includes(SCHEMA_LINES)) {
    throw new Error(`env.ts: demo-key schema anchor not found — the blueprint doesn't have the expected shape (${p})`);
  }
  text = text.replace(CONST_LINE, '').replace(SCHEMA_LINES, '');
  fs.writeFileSync(p, text);
}

// isTsExampleOrTest — src-relative (posix) paths to exclude from the TS copy.
//
// The two config/errors entries are dropped because every remaining importer of
// each is itself already dropped: blueprint-properties.ts is imported only by
// app.ts (regenerated from the manifest) and the dropped example services;
// external-api-error.ts only by the dropped services and clients.
function isTsExampleOrTest(rel) {
  if (rel.endsWith('.test.ts')) return true;
  if (rel === 'models/api-response.ts') return true;
  if (rel === 'config/blueprint-properties.ts') return true;
  if (rel === 'errors/external-api-error.ts') return true;
  if (rel.startsWith('clients/')) return true;
  if (rel.startsWith('services/')) return true;
  if (rel.startsWith('workers/task-')) return true;
  return false;
}

// substituteTs — namespace-only: the npm package name is the TS "namespace"
// analogue keyed on by the spec. Lower-level Blueprint* code identifiers
// (types, functions, env vars) are left intact on purpose — a token-level
// rename would break cross-file imports and yield invalid identifiers.
function substituteTs(text) {
  return text.split('engagement-blueprint').join(meta.processSlug);
}

// ──────────────────────────────────────────────────────────────────────────
// python
// ──────────────────────────────────────────────────────────────────────────

function scaffoldPython() {
  // A processSlug with no alphanumeric content yields no package name — the same
  // failure mode writePyProcessVariables rejects a variable name for. A silent
  // default here would let two generated bundles for two different customers
  // both install under the same package name, which is exactly the collision
  // PY_PACKAGE exists to prevent.
  if (!PY_PACKAGE) {
    throw new Error(
      `scaffold-workers: processSlug ${JSON.stringify(meta.processSlug)} yields no legal Python package name — rename the project slug`,
    );
  }

  // 1. Build manifests + toolchain pins.
  //
  // uv.lock carries the project's OWN distribution name alongside the resolved
  // dependency graph, so it goes through the same substitution as
  // pyproject.toml. Renaming one and not the other is not a cosmetic mismatch:
  // `uv sync --frozen` compares the manifest against the lock and fails when the
  // root package name disagrees, which would break the very first command a user
  // runs. The dependency pins inside the lock are untouched.
  copyWithSubst(path.join(BLUEPRINT_DIR, 'pyproject.toml'), path.join(ARTIFACT_ROOT, 'pyproject.toml'), substitutePyToml);
  copyWithSubst(path.join(BLUEPRINT_DIR, 'uv.lock'), path.join(ARTIFACT_ROOT, 'uv.lock'), substitutePython);
  // .python-version is the interpreter floor uv provisions against — no name in
  // it to substitute, and it must stay byte-identical to what the lock resolved
  // under.
  copyVerbatim(path.join(BLUEPRINT_DIR, '.python-version'), path.join(ARTIFACT_ROOT, '.python-version'));

  // 2. src/ skeleton minus the example domain, the demo tests and the demo BPMN,
  // copied under PY_PACKAGE — the blueprint's own `src` name is never itself
  // installed or distributed. substitutePython rewrites every `from src.`/
  // `from src import` inside the copied files to match.
  const srcRoot = path.join(BLUEPRINT_DIR, 'src');
  copyTree(
    srcRoot,
    path.join(ARTIFACT_ROOT, PY_PACKAGE),
    (rel) => !isPyBuildDetritus(rel) && !isPyExampleOrTest(rel),
    substitutePython,
  );

  // 2b. The architecture test travels with the scaffold: it shells out to
  // `lint-imports`, so it asserts the layering contracts in pyproject.toml
  // rather than anything about the example domain, and it is the one test that
  // stays meaningful in a project with no workers yet. Its two __init__.py files
  // come along because pytest needs the packages to import at all.
  for (const rel of ['tests/__init__.py', 'tests/architecture/__init__.py', 'tests/architecture/test_layers.py']) {
    copyWithSubst(path.join(BLUEPRINT_DIR, rel), path.join(ARTIFACT_ROOT, rel), substitutePython);
  }

  // 3. .env.example, with the demo-only keys stripped. Copied rather than
  //    written as `.env`: a real .env is the operator's, and the blueprint's own
  //    is gitignored, so it isn't part of the tracked blueprint tree either.
  writePyEnvExample(
    path.join(BLUEPRINT_DIR, '.env.example'),
    path.join(ARTIFACT_ROOT, '.env.example'),
  );

  // 4. Post-copy patches, same rationale as the TS ones: these are
  //    demo-to-generated-project conversions, not upstream-sync protection, so
  //    every change the generated project needs is applied here instead of
  //    editing the blueprint directly.
  patchPyEnv(path.join(ARTIFACT_ROOT, PY_PACKAGE, 'config', 'env.py'));
  patchPyMain(path.join(ARTIFACT_ROOT, PY_PACKAGE, 'main.py'));

  // 5. Generated files (overwrite whatever the copy left). Both are generated
  //    rather than copied because the blueprint's own originals are bound to the
  //    example domain: app.py imports the dropped clients/services/workers, and
  //    process_variables.py models the demo's variables, not this project's.
  writePyProcessVariables(path.join(ARTIFACT_ROOT, PY_PACKAGE, 'models', 'process_variables.py'), manifest);
  writePyApp(path.join(ARTIFACT_ROOT, PY_PACKAGE, 'app.py'), PY_PACKAGE);

  // uv materialises the environment into `.venv/` inside the artifact root, and
  // pytest/ruff/mypy/import-linter each leave a cache dir beside it. None are
  // ever versioned. gitignore syntax requires forward slashes regardless of
  // platform, so this doesn't go through path.join.
  const gitignoreRoot = ARTIFACT_ROOT.replace(/\\/g, '/');
  appendLines([
    `${gitignoreRoot}/.venv/`,
    `${gitignoreRoot}/.ruff_cache/`,
    `${gitignoreRoot}/.mypy_cache/`,
    `${gitignoreRoot}/.pytest_cache/`,
    `${gitignoreRoot}/.import_linter_cache/`,
    `${gitignoreRoot}/.coverage`,
    `${gitignoreRoot}/dist/`,
  ]);

  console.log(`scaffold-workers: ${ARTIFACT_ROOT}/ ready from python blueprint`);
  console.log(`  package manager: uv (pyproject.toml + uv.lock, installed with \`uv sync --frozen\`)`);
  checkPythonSdkRange(path.join(ARTIFACT_ROOT, 'pyproject.toml'));
  console.log(`  worker registry in ${PY_PACKAGE}/app.py is empty — add workers as they are wired`);
}

// resolvePythonSdkRange — the camunda-orchestration-sdk range expected for
// `clusterMinor`. Mirrors resolveClientCamundaVersion's shape so both maps read
// the same way, but the value is a RANGE and the caller verifies rather than
// substitutes. Returns `{ range, lag }` — `lag: true` when a specific minor was
// requested and the map has no entry for it — or null when there is no config.
function resolvePythonSdkRange(clusterMinor, pythonCfg) {
  if (!pythonCfg) return null;
  if (typeof pythonCfg === 'string') return { range: pythonCfg, lag: false };
  const def = pythonCfg.default;
  if (!def) return null;
  if (clusterMinor && pythonCfg[clusterMinor]) {
    return { range: pythonCfg[clusterMinor], lag: false };
  }
  return { range: def, lag: Boolean(clusterMinor) };
}

// checkPythonSdkRange — report, never rewrite. The blueprint's pin and its
// uv.lock are one unit: editing the pin here would leave a lockfile that no
// longer satisfies the manifest, and `uv sync --frozen` — the first command the
// build gate and every documented workflow runs — fails on exactly that. So a
// disagreement between what this project's cluster minor wants and what the
// blueprint pins is surfaced for a human to fix in the blueprint (re-pin, re-run
// `uv lock`, re-validate end to end), which is what versions.json's
// camundaPython comment describes.
//
// The comparison asks whether the pin SATISFIES the range, not whether the two
// strings agree. The blueprint pins one exact version so pyproject.toml and
// uv.lock stay reproducible together, while versions.json declares a major range,
// so string equality would report a mismatch on every run for a pin that is
// correct. A pin the comparator cannot parse is reported as unverified, never as a
// mismatch: sending an operator to re-pin a dependency this never compared is a
// wrong answer dressed as a finding.
function checkPythonSdkRange(pyprojectPath) {
  if (!PYTHON_SDK_RANGE) return;
  const text = fs.readFileSync(pyprojectPath, 'utf8');
  const pinned = text.match(/"camunda-orchestration-sdk([^"]*)"/)?.[1]?.trim() ?? null;
  if (pinned === null) {
    console.log('  note: pyproject.toml declares no camunda-orchestration-sdk dependency — cannot verify the SDK pin');
    return;
  }
  const cluster = meta.camundaClusterVersion || 'default';
  const verdict = satisfiesRange(pinned, PYTHON_SDK_RANGE.range);
  if (verdict === VERDICT.SATISFIED) {
    console.log(
      `  camunda-orchestration-sdk: ${pinned} (satisfies ${PYTHON_SDK_RANGE.range} for cluster ${cluster})`,
    );
  } else if (verdict === VERDICT.UNVERIFIABLE) {
    console.log(
      `  note: cannot compare blueprint pin camunda-orchestration-sdk${pinned} against the ` +
      `${PYTHON_SDK_RANGE.range} that cluster minor ${meta.camundaClusterVersion || '(unset)'} expects — ` +
      'the SDK pin is unverified, not confirmed',
    );
  } else {
    console.log(
      `  note: blueprint pins camunda-orchestration-sdk${pinned}, but cluster minor ` +
      `${meta.camundaClusterVersion || '(unset)'} expects ${PYTHON_SDK_RANGE.range} — ` +
      'left as-is on purpose: pyproject.toml and uv.lock must be re-pinned and re-locked together in the blueprint',
    );
  }
  // Reported whether or not the range matched. A cluster minor absent from the
  // map compares against `default`, which can agree with the blueprint pin by
  // coincidence — reporting only on mismatch would hide the fact that nothing
  // has actually been verified for that minor.
  if (PYTHON_SDK_RANGE.lag) {
    console.log(
      `  note: cluster minor ${meta.camundaClusterVersion} has no camunda-orchestration-sdk mapping yet — ` +
      'compared against the default range; add a key to versions.json once the SDK targets it',
    );
  }
}

// isPyBuildDetritus — paths that are never source, and so never travel with a
// scaffold. Separate from isPyExampleOrTest because this is not a
// scaffold-vs-example judgement: these files are byproducts of *running* the
// blueprint, and the blueprint tree gitignores them, so a clean checkout has
// none. A developer's working copy does, though — and the copy would otherwise
// ship `__pycache__` bytecode for the very example modules the split drops,
// which Python will happily import in preference to nothing. Filtering here
// keeps the scaffold identical whether or not the blueprint has been exercised
// locally.
//
// The Java and TS adapters need no equivalent: they enumerate their manifests by
// name, and their one tree copy has no compiled-output sibling directory.
function isPyBuildDetritus(rel) {
  const segments = rel.split('/');
  if (segments.includes('__pycache__')) return true;
  const base = segments[segments.length - 1];
  return base === '.DS_Store' || base.endsWith('.pyc') || base.endsWith('.pyo');
}

// isPyExampleOrTest — src-relative (posix) paths to exclude from the Python copy.
//
// `http_client.py` and `errors/external_api_error.py` are deliberately KEPT,
// which is where this diverges from isTsExampleOrTest. AppServices' `http_clients`
// field and main.py's shutdown loop both need a concrete client type, and the
// typed httpx wrapper is generic infrastructure rather than example domain — only
// the two API-specific clients that wrap it are. external_api_error.py comes
// along because http_client.py raises it.
//
// app.py and models/process_variables.py are excluded here and GENERATED in
// step 5 instead: copying them would drag in imports of the very files this
// filter drops.
function isPyExampleOrTest(rel) {
  if (rel === 'app.py') return true;
  if (rel === 'models/process_variables.py') return true;
  if (rel === 'models/api_response.py') return true;
  if (rel === 'config/blueprint_properties.py') return true;
  if (rel.startsWith('clients/external_api_')) return true;
  if (rel.startsWith('services/external_api_')) return true;
  if (rel.startsWith('workers/task_')) return true;
  return false;
}

// substitutePython — the distribution-name rename substituteTs also does, plus
// the import-package rename: `src`, matched on a word boundary so it never
// touches "resources" or similar, becomes PY_PACKAGE wherever it appears as an
// identifier — `from src.app import x`, `from src import main`, and the one
// backtick-quoted `` `src.config.env` `` doc mention alike. Applies to every
// copied .py file; pyproject.toml goes through substitutePyToml instead, since
// its own `src` occurrences are TOML values sitting beside ruff's unrelated
// `src` config key.
function substitutePython(text) {
  return text
    .split('engagement-blueprint').join(meta.processSlug)
    .replace(/\bsrc\b/g, PY_PACKAGE);
}

// substitutePyToml — pyproject.toml's `src` occurrences are exclusively quoted
// TOML string values (a Hatch/mypy `packages` entry, ruff's `known-first-party`
// and its own `src` array value, import-linter's `root_packages` and every
// contract's dotted `source_modules`/`forbidden_modules` entries) sitting
// beside `[tool.ruff] src = […]`, whose KEY is also spelled `src` but is ruff's
// own option name, not our package — a blind word-boundary replace would rename
// that key too and silently drop the setting. Each value is matched by its
// exact surrounding text instead.
function substitutePyToml(text) {
  return text
    .split('engagement-blueprint').join(meta.processSlug)
    .split('packages = ["src"]').join(`packages = ["${PY_PACKAGE}"]`)
    .split('--cov=src ').join(`--cov=${PY_PACKAGE} `)
    .split('src = ["src", "tests"]').join(`src = ["${PY_PACKAGE}", "tests"]`)
    .split('known-first-party = ["src"]').join(`known-first-party = ["${PY_PACKAGE}"]`)
    .split('root_packages = ["src"]').join(`root_packages = ["${PY_PACKAGE}"]`)
    .replace(/"src\./g, `"${PY_PACKAGE}.`);
}

// Every patch below anchors on CONTENT and throws when an anchor is missing, for
// the same reason the TS patches do. PY_DEMO_ENV_KEYS, which two of them read,
// is declared with the top constants: `const` does not hoist, and the top-level
// dispatch runs before this point in the file.

/** Drop the demo-only settings fields, and the section comments left empty by doing so. */
function patchPyEnv(p) {
  const ANCHORS = [
    '    # Blueprint properties\n' +
      '    BLUEPRINT_RESULT_PREFIX: str = "[DEMO]_"\n' +
      '    BLUEPRINT_DEPLOY_ON_START: bool = False\n',
    '\n    # External services\n' +
      '    EXTERNAL_API_A_BASE_URL: str = "http://localhost:8089"\n' +
      '    EXTERNAL_API_B_BASE_URL: str = "http://localhost:8089"\n',
  ];
  let text = fs.readFileSync(p, 'utf8');
  // Idempotent: a second run finds the keys already gone and must not throw.
  if (!PY_DEMO_ENV_KEYS.some((k) => text.includes(k))) return;
  for (const anchor of ANCHORS) {
    if (!text.includes(anchor)) {
      throw new Error(
        `env.py: demo-key anchor not found — the blueprint doesn't have the expected shape (${p}):\n${anchor.split('\n')[1] ?? anchor}`,
      );
    }
    text = text.replace(anchor, anchor === ANCHORS[0] ? '    # Logging\n' : '');
  }
  fs.writeFileSync(p, text);
}

/**
 * Remove deploy-on-start, matching patchTsMain. Deploying resources belongs to
 * process-os-deployment, the generated Java application has no deploy-on-start
 * either, and the block points at a demo BPMN the scaffold does not copy — so
 * leaving it would be an opt-in flag that crashes on a missing file. The
 * `pathlib` import goes too: it served only BPMN_PATH, and ruff's F401 makes an
 * unused import an error.
 */
function patchPyMain(p) {
  const CUTS = [
    'from pathlib import Path\n',
    // Ends one newline short of the next top-level def on purpose: the two
    // blank lines PEP 8 wants before it are the one this cut leaves plus the
    // one already above BPMN_PATH. Consuming both would leave a single blank
    // line and fail ruff's E302.
    'BPMN_PATH = Path(__file__).parent.parent / "resources" / "blueprint-process.bpmn"\n' +
      '\n' +
      '\n' +
      'async def deploy_bpmn(client: CamundaAsyncClient, log: logging.Logger) -> None:\n' +
      '    log.info("Deploying BPMN process: %s", BPMN_PATH)\n' +
      '    await client.deploy_resources_from_files([str(BPMN_PATH)])\n' +
      '    log.info("BPMN deployment succeeded")\n' +
      '\n',
    '        # Optional BPMN deployment\n' +
      '        if env.BLUEPRINT_DEPLOY_ON_START:\n' +
      '            await deploy_bpmn(client, log)\n' +
      '\n',
  ];

  let text = fs.readFileSync(p, 'utf8');
  // Idempotent, and keyed on BPMN_PATH for the same reason patchTsMain is: the
  // env flag appears only inside the block the last cut removes, so keying on it
  // would misread a direct blueprint edit as "already patched".
  if (!text.includes('BPMN_PATH')) return;

  for (const cut of CUTS) {
    if (!text.includes(cut)) {
      throw new Error(
        `main.py: deploy-on-start anchor not found — the blueprint doesn't have the expected shape (${p}):\n${cut.split('\n')[0]}`,
      );
    }
    text = text.replace(cut, '');
  }
  fs.writeFileSync(p, text);
}

/** Copy .env.example without the demo-only keys, their comments, or the gaps they leave. */
function writePyEnvExample(srcFile, destFile) {
  if (!fs.existsSync(srcFile)) throw new Error(`blueprint file missing: ${srcFile}`);
  const lines = fs.readFileSync(srcFile, 'utf8').split('\n');
  const DROP_COMMENTS = [
    '# Blueprint properties',
    '# Set to true to deploy resources/blueprint-process.bpmn on worker startup.',
    '# External services. Point these at your mock or real API endpoints.',
  ];
  const kept = [];
  for (const line of lines) {
    const trimmed = line.trim();
    if (PY_DEMO_ENV_KEYS.some((k) => trimmed.startsWith(`${k}=`) || trimmed.startsWith(`# ${k}=`))) continue;
    if (DROP_COMMENTS.includes(trimmed)) continue;
    // Collapse the runs of blank lines the drops leave behind.
    if (trimmed === '' && kept.length > 0 && kept[kept.length - 1].trim() === '') continue;
    kept.push(line);
  }
  fs.mkdirSync(path.dirname(destFile), { recursive: true });
  fs.writeFileSync(destFile, `${substitutePython(kept.join('\n')).replace(/\n+$/, '')}\n`);
}

// writePyProcessVariables — the Python counterpart of writeProcessVariables.
// Every field is optional because the union spans the whole process: a variable
// a later task produces is simply absent when an earlier worker validates.
// `extra="allow"` keeps a variable the manifest never declared from failing
// validation, matching the blueprint's own model.
//
// A field whose Python name differs from the manifest name carries a Pydantic
// alias, and the model sets `populate_by_name=True`. Without the alias the model
// reads neither a hyphenated nor a camelCase process variable: validating
// `{"case-id": "c1"}` leaves `case_id` as None and drops the value into the
// extras that `extra="allow"` permits. The alias is the whole reason the snake_case
// rename stays invisible to the process.
//
// The model is the manifest union or it is nothing: a manifest name this cannot
// represent faithfully fails the scaffold (exit 3) naming the variable, rather
// than emitting a model that silently covers fewer variables than the manifest
// declares. `python` has no worker generator, so nothing downstream would catch
// it, and a model missing a field validates happily — the value lands in the
// extras `extra="allow"` permits and the worker reads None.
function writePyProcessVariables(p, manifest) {
  const fields = new Map();
  for (const w of (manifest.workers || [])) {
    for (const v of [...(w.inputVariables || []), ...(w.outputVariables || [])]) {
      const source = String(v.name);
      const name = toPyField(v.name);
      // No alphanumeric content, so there is no identifier to derive.
      if (!name) {
        throw new Error(
          `process variable ${JSON.stringify(source)} yields no Python identifier: rename it in the manifest`,
        );
      }
      const pyType = mapPyType(v.type);
      const existing = fields.get(name);
      // One Python attribute carries one alias, so a second manifest name on the
      // same field would be reachable only under the first name's alias. Both are
      // real process variables and the process sends both; which one to keep is
      // the manifest author's decision, not this script's.
      if (existing && existing.source !== source) {
        throw new Error(
          `process variables ${JSON.stringify(existing.source)} and ${JSON.stringify(source)} both convert to the Python field `
          + `\`${name}\`: rename one in the manifest`,
        );
      }
      if (existing && existing.type !== pyType) {
        // The same variable declared with two types across workers: widen rather
        // than pick, so neither declaration is contradicted.
        fields.set(name, { type: 'object', source: existing.source });
      } else if (!existing) {
        fields.set(name, { type: pyType, source });
      }
    }
  }

  const fieldLines = [...fields.entries()].map(([n, { type, source }]) => (
    source === n
      ? `    ${n}: ${type} | None = None`
      : `    ${n}: ${type} | None = Field(default=None, alias=${JSON.stringify(source)})`
  ));
  const needsField = fieldLines.some((line) => line.includes('Field(default=None'));
  const body = [
    '"""Process variables, generated from the artifact manifest."""',
    '',
    'from __future__ import annotations',
    '',
    needsField
      ? 'from pydantic import BaseModel, ConfigDict, Field'
      : 'from pydantic import BaseModel, ConfigDict',
    '',
    '',
    'class ProcessVariables(BaseModel):',
    '    """Union of every process variable declared across the manifest\'s workers.',
    '',
    '    Every field is optional: the union spans the whole process, so a variable a later',
    '    task produces is absent when an earlier worker validates. `extra="allow"` keeps a',
    '    variable the manifest does not declare from failing validation. An alias preserves',
    '    the manifest name wherever the Python field name differs from it.',
    '    """',
    '',
    '    model_config = ConfigDict(extra="allow", populate_by_name=True)',
    '',
    ...(fieldLines.length
      ? fieldLines
      : ['    # No process variables declared in manifest. Add fields as workers are wired.']),
    '',
  ].join('\n');
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, body);
}

// writePyApp — the composition root.
//
// The blueprint's own app.py wires the example domain, so it cannot be copied. What it
// is replaced with is deliberately a working module rather than a stub with
// TODOs: main.py imports both functions and iterates `services.http_clients` on
// shutdown, so the scaffold only type-checks and starts if this file is real.
function writePyApp(p, pyPackage) {
  const body = `"""Composition root: build clients and services, then register workers.

Generated by scaffold-workers.cjs. Add clients, services and workers here as they
are wired. The application starts and serves /healthz and /readyz.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import logging

    from camunda_orchestration_sdk import CamundaAsyncClient

    from ${pyPackage}.clients.http_client import HttpClient
    from ${pyPackage}.config.env import Env
    from ${pyPackage}.shutdown import RegisteredWorkers


@dataclass
class AppServices:
    """Everything the workers need, plus the clients shutdown has to close.

    \`http_clients\` is what main.py's shutdown iterates, so every HttpClient built
    in compose_app belongs in it — otherwise its connection pool outlives the drain.
    """

    http_clients: list[HttpClient] = field(default_factory=list)


def compose_app(env: Env) -> AppServices:
    """Wire up all dependencies. No DI framework — explicit composition."""
    return AppServices()


def register_workers(
    client: CamundaAsyncClient,
    services: AppServices,
    log: logging.Logger,
) -> RegisteredWorkers:
    """Register all job workers, keyed by job type.

    Empty until worker generation lands. \`create_job_worker\` starts each worker, so
    the returned handles are the only way to stop one again: callers must keep them
    and drain them on shutdown (see shutdown.py).
    """
    return {}
`;
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, body);
}

// ──────────────────────────────────────────────────────────────────────────
// shared helpers
// ──────────────────────────────────────────────────────────────────────────

// resolveClientCamundaVersion — pick the stable Camunda Java CLIENT version to
// pin into the bundle pom. `clusterMinor` is the project's TO-BE cluster version
// (`8.8`|`8.9`|`8.10`, resolved by resolve-camunda-version.cjs); `camundaCfg` is
// `versions.camunda`. The bundle pins the client, which may lag the cluster minor
// (older-client/newer-cluster is a supported skew). Returns
// `{ version, lag }` — `lag: true` when the requested cluster minor has no GA
// client mapping (e.g. 8.10 today → falls back to the newest stable client).
// Returns null when no config is available (keep the blueprint's own pin).
function resolveClientCamundaVersion(clusterMinor, camundaCfg) {
  if (!camundaCfg) return null;
  if (typeof camundaCfg === 'string') return { version: camundaCfg, lag: false };
  const def = camundaCfg.default;
  if (!def) return null;
  if (clusterMinor && camundaCfg[clusterMinor]) {
    return { version: camundaCfg[clusterMinor], lag: false };
  }
  // Unknown/absent cluster minor → newest stable client. Flag the lag only when
  // a specific minor was requested but has no GA client mapping.
  return { version: def, lag: Boolean(clusterMinor) };
}

function skillsRoot() {
  // The script lives at <skillsRoot>/skills/process-os-artifact-generation/scripts/scaffold-workers.cjs.
  // In the source repo skillsRoot() is the repo root; once bundled it is the
  // agent's installed skills root (path varies by agent platform — never
  // hard-coded here, it is derived from __dirname).
  return path.resolve(__dirname, '..', '..', '..');
}

// ── blueprint dependency sources ─────────────────────────────────────────────

// parseBlueprintPom — extract the pinned coordinates from a blueprint pom.xml.
// Returns { parent, properties, dependencies, plugins }:
//   parent       — { groupId, artifactId, version } of the Spring Boot BOM.
//   properties   — a map of each <properties> entry with a trailing ".version"
//                  stripped to a friendly key (java.version → java,
//                  camunda.version → camunda). Non-version properties
//                  (e.g. cpt.coverage.min) keep their full name.
//   dependencies — the project's declared deps, as
//                  { groupId, artifactId, version|null, scope? }. Read with
//                  <dependencyManagement> stripped out first, so a pinned-version
//                  override declared there (which also uses a <dependencies> tag)
//                  is never mistaken for the project's real dependency list.
//                  `${x.version}` refs are resolved against `properties`; a
//                  BOM-managed dep with no <version> comes through as null.
//   plugins      — the declared <build><plugins> entries as
//                  { groupId, artifactId, version|null, dependencies? }. These are
//                  a separate download set from `dependencies`: Maven fetches them
//                  to *run* the build (`mvn test` needs surefire, jacoco, spotless,
//                  …), and they never appear in `dependency:list`. A plugin with no
//                  <version> is managed by the parent's <pluginManagement> → null,
//                  resolvable with `dependency:resolve-plugins`. `dependencies` is
//                  present only for plugins carrying their own (e.g. gmavenplus'
//                  groovy jars), which Maven downloads too.
function parseBlueprintPom(pomPath) {
  const xml = fs.readFileSync(pomPath, 'utf8');
  const matchOne = (block, tag) => block.match(new RegExp(`<${tag}>([^<]+)</${tag}>`))?.[1]?.trim() ?? null;

  const parentBlock = xml.match(/<parent>([\s\S]*?)<\/parent>/)?.[1] ?? '';
  const parent = {
    groupId: matchOne(parentBlock, 'groupId'),
    artifactId: matchOne(parentBlock, 'artifactId'),
    version: matchOne(parentBlock, 'version'),
  };

  const properties = {};
  const propsBlock = xml.match(/<properties>([\s\S]*?)<\/properties>/)?.[1] ?? '';
  const re = /<([\w.-]+)>([^<]*)<\/\1>/g;
  let m;
  while ((m = re.exec(propsBlock)) !== null) {
    properties[m[1].replace(/\.version$/, '')] = m[2].trim();
  }

  // `${x.version}` → the concrete pin from <properties>; anything else passes
  // through. Returns null for an absent version (BOM- / pluginManagement-managed).
  const resolveVersion = (raw) => {
    if (!raw) return null;
    if (!raw.startsWith('${')) return raw;
    const key = raw.slice(2, -1).replace(/\.version$/, '');
    return properties[key] ?? raw;
  };

  const parseDependencies = (block) =>
    [...block.matchAll(/<dependency>([\s\S]*?)<\/dependency>/g)].map((d) => {
      const b = d[1];
      const scope = matchOne(b, 'scope');
      const dep = {
        groupId: matchOne(b, 'groupId'),
        artifactId: matchOne(b, 'artifactId'),
        version: resolveVersion(matchOne(b, 'version')),
      };
      if (scope != null) dep.scope = scope;
      return dep;
    });

  // <dependencyManagement> nests its own <dependencies> tag, so it must be
  // removed before scanning for the project's real dependency list — otherwise
  // a management-only version override (e.g. a CVE pin) is matched instead.
  // `/g`: a pom can legally declare more than one <dependencyManagement> block
  // (e.g. profile-scoped), and Maven does not enforce canonical sibling order.
  const xmlWithoutDependencyManagement = xml.replace(/<dependencyManagement>[\s\S]*?<\/dependencyManagement>/g, '');
  const depsBlock = xmlWithoutDependencyManagement.match(/<dependencies>([\s\S]*?)<\/dependencies>/)?.[1] ?? '';
  const dependencies = parseDependencies(depsBlock);

  // <build> … <plugins>: greedy to the LAST closing tag so every declared plugin
  // is in scope; each <plugin> block is then matched non-greedily (plugins do not
  // nest). Read own coordinates from the block HEAD — everything before the first
  // <executions>/<configuration>/<dependencies> — so a nested groupId/version
  // (gmavenplus' groovy deps, the compiler plugin's annotationProcessorPaths) can
  // never be mistaken for the plugin's own.
  // <pluginManagement> nests its own <plugins> tag, so it must be removed first —
  // otherwise a management-only version pin (e.g. a CVE pin with no active build
  // binding) is matched as if it were a declared build plugin.
  const buildBlockWithoutPluginManagement = (xml.match(/<build>([\s\S]*)<\/build>/)?.[1] ?? '')
    .replace(/<pluginManagement>[\s\S]*?<\/pluginManagement>/g, '');
  const pluginsBlock = buildBlockWithoutPluginManagement.match(/<plugins>([\s\S]*)<\/plugins>/)?.[1] ?? '';
  const plugins = [...pluginsBlock.matchAll(/<plugin>([\s\S]*?)<\/plugin>/g)].map((p) => {
    const block = p[1];
    const head = block.split(/<(?:executions|configuration|dependencies)>/)[0];
    const plugin = {
      groupId: matchOne(head, 'groupId'),
      artifactId: matchOne(head, 'artifactId'),
      version: resolveVersion(matchOne(head, 'version')),
    };
    const own = block.match(/<dependencies>([\s\S]*?)<\/dependencies>/)?.[1];
    const pluginDeps = own ? parseDependencies(own) : [];
    if (pluginDeps.length > 0) plugin.dependencies = pluginDeps;
    return plugin;
  });

  return { parent, properties, dependencies, plugins };
}

// parseMavenWrapper — read the blueprint's `.mvn/wrapper/maven-wrapper.properties`
// (sibling of the pom), when the blueprint ships one. A scaffold that gets a
// wrapper copied has this URL as a real dependency of running the generated
// project's tests — a fresh machine downloads it to get Maven itself, and no
// pom parse would reveal it. Returns
// { wrapperVersion, distributionType, distributionUrl } (missing keys → null), or
// null when the blueprint carries no wrapper.
function parseMavenWrapper(pomPath) {
  const propsPath = path.join(path.dirname(pomPath), '.mvn', 'wrapper', 'maven-wrapper.properties');
  if (!fs.existsSync(propsPath)) return null;
  const props = {};
  for (const line of fs.readFileSync(propsPath, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([\w.-]+)\s*=\s*(.*)$/);
    if (m && !line.trimStart().startsWith('#')) props[m[1]] = m[2].trim();
  }
  return {
    wrapperVersion: props.wrapperVersion ?? null,
    distributionType: props.distributionType ?? null,
    distributionUrl: props.distributionUrl ?? null,
  };
}

// parsePyProject — extract the declared dependency ranges from a blueprint
// pyproject.toml. Returns { requiresPython, dependencies, devDependencies },
// each dependency as { name, version } where `version` is the RANGE as written
// (`>=9.0.0,<10.0.0`), or null for an unconstrained requirement.
//
// A hand-rolled reader rather than a TOML library: the repo ships no TOML
// dependency, this needs exactly three keys, and the two arrays it reads are
// flat lists of PEP 508 strings. It anchors on the table headers, so a
// pyproject that reshapes them yields empty lists rather than wrong ones — and
// the summary's own test asserts the real blueprint parses non-empty.
function parsePyProject(pyprojectPath) {
  const text = fs.readFileSync(pyprojectPath, 'utf8');

  // A table's body: everything after its header up to the next header at
  // column 0, or the end of the file when it is the last table. `[project]` must
  // not swallow `[project.optional-dependencies]`, hence the lookahead on any
  // bracketed line.
  //
  // End of input is `(?![\s\S])`, not `\z`: JavaScript has no `\z` escape, so a
  // RegExp containing one matches a literal `z` and stops the lazy body at the
  // first dependency name carrying one. `$` alone is a line boundary under the
  // `m` flag and would stop at the header's own newline.
  const table = (header) => {
    const re = new RegExp(`^\\[${header.replace(/[.[\]]/g, '\\$&')}\\]\\s*$([\\s\\S]*?)(?:(?=^\\[)|(?![\\s\\S]))`, 'm');
    return text.match(re)?.[1] ?? '';
  };

  // A `key = [ "a", "b" ]` array of PEP 508 requirement strings → { name, version }.
  const requirementArray = (block, key) => {
    const raw = block.match(new RegExp(`^${key}\\s*=\\s*\\[([\\s\\S]*?)\\]`, 'm'))?.[1];
    if (!raw) return [];
    return [...raw.matchAll(/"([^"]+)"/g)].map((m) => {
      const spec = m[1].trim();
      // Split the distribution name off its version specifier. Extras
      // (`pkg[extra]`) stay with the name — they change what is installed.
      const at = spec.search(/[<>=!~]/);
      return at === -1
        ? { name: spec, version: null }
        : { name: spec.slice(0, at).trim(), version: spec.slice(at).trim() };
    });
  };

  const project = table('project');
  return {
    requiresPython: project.match(/^requires-python\s*=\s*"([^"]+)"/m)?.[1] ?? null,
    dependencies: requirementArray(project, 'dependencies'),
    // The blueprint keeps its validation toolchain in `[dependency-groups] dev`
    // (a default group, so `uv sync` installs it with no extra flag) rather than
    // in `[project.optional-dependencies]`, which is not synced by default.
    devDependencies: requirementArray(table('dependency-groups'), 'dev'),
  };
}

// stripUnderscored — drop `_comment`-style keys from a plain object for a clean
// summary. Returns null unchanged.
function stripUnderscored(obj) {
  if (!obj || typeof obj !== 'object') return obj || null;
  const out = {};
  for (const [k, v] of Object.entries(obj)) if (!k.startsWith('_')) out[k] = v;
  return out;
}

// writeSummary — emit the timestamp-free dependency summary read from the
// blueprint sources (java-spring-boot/pom.xml + typescript/package.json +
// python/pyproject.toml) plus both version maps from versions.json. Every SDK
// carries a dependency LIST;
// the Java block also exposes parent, resolved properties, the build PLUGINS
// Maven must fetch to run the build, and the Maven wrapper's distribution URL.
// The TS block carries `engines` — the Node toolchain floor a machine needs
// before it can build the generated worker project at all. `packageManager`
// is reported as null: patchTsPackageJson drops the blueprint's pnpm pin from
// every generated project, which builds via plain npm and never invokes
// corepack, so the blueprint's own pin is not a floor of the generated
// project and would misreport what a machine actually needs to fetch.
// Timestamp-free on purpose: the blueprint files are ordinary tracked source, so
// identical inputs must yield identical bytes (diffable in CI, stable for
// emit-dep-snapshot).
function writeSummary(outPath) {
  const bpRoot = path.join(SKILLS_ROOT, 'skills', 'process-os-artifact-generation', 'blueprints');
  // Honor an explicit --blueprint-path for whichever SDK is actually being
  // scaffolded, so the summary reflects the real scaffolded project rather than
  // the default. The non-target SDK's block always uses the default
  // blueprint (there is only one override, and it applies to the active SDK).
  const javaDir = (targetSdk === 'java-spring-boot' && BLUEPRINT_PATH) ? BLUEPRINT_PATH : path.join(bpRoot, 'java-spring-boot');
  const tsDir = (targetSdk === 'typescript' && BLUEPRINT_PATH) ? BLUEPRINT_PATH : path.join(bpRoot, 'typescript');
  const pyDir = (targetSdk === 'python' && BLUEPRINT_PATH) ? BLUEPRINT_PATH : path.join(bpRoot, 'python');
  const javaPom = path.join(javaDir, 'pom.xml');
  const tsPkg = path.join(tsDir, 'package.json');
  const pyProject = path.join(pyDir, 'pyproject.toml');
  const rel = (p) => path.relative(SKILLS_ROOT, p).split(path.sep).join('/');
  const toList = (obj) => Object.entries(obj || {}).map(([name, version]) => ({ name, version }));

  // Every blueprint is part of the contract — a missing source is a real
  // error (bad bundle or bad --blueprint-path), not a reason to emit a partial
  // summary that makes downstream consumers fail later. Fail fast.
  if (!fs.existsSync(javaPom)) throw new Error(`summary: blueprint pom not found: ${javaPom}`);
  if (!fs.existsSync(tsPkg)) throw new Error(`summary: blueprint package.json not found: ${tsPkg}`);
  if (!fs.existsSync(pyProject)) throw new Error(`summary: blueprint pyproject.toml not found: ${pyProject}`);

  // The Camunda client map is a required section of the --summary contract.
  // The top-level versions.json read is non-fatal (scaffolding tolerates a
  // missing map — resolveClientCamundaVersion just keeps the blueprint pin), but
  // a summary must not silently ship `camundaClientMap: null`; fail fast instead.
  const camundaClientMap = stripUnderscored(versions.camunda);
  if (!camundaClientMap || Object.keys(camundaClientMap).length === 0) {
    throw new Error(`summary: no Camunda client map in ${VERSIONS_PATH} (required for --summary)`);
  }
  const camundaPythonSdkMap = stripUnderscored(versions.camundaPython);
  if (!camundaPythonSdkMap || Object.keys(camundaPythonSdkMap).length === 0) {
    throw new Error(`summary: no camunda-orchestration-sdk map in ${VERSIONS_PATH} (required for --summary)`);
  }

  const { parent, properties, dependencies, plugins } = parseBlueprintPom(javaPom);
  const pkg = JSON.parse(fs.readFileSync(tsPkg, 'utf8'));
  const py = parsePyProject(pyProject);
  const summary = {
    javaSpringBoot: {
      source: rel(javaPom),
      parent,
      properties,
      dependencies,
      plugins,
      mavenWrapper: parseMavenWrapper(javaPom),
    },
    typescript: {
      source: rel(tsPkg),
      engines: pkg.engines ?? {},
      // Always null: patchTsPackageJson drops this from every generated
      // project (see writeSummary's comment above), so the blueprint's raw
      // value is never a floor of the thing this summary describes.
      packageManager: null,
      dependencies: toList(pkg.dependencies),
      devDependencies: toList(pkg.devDependencies),
    },
    python: {
      source: rel(pyProject),
      // requiresPython is the interpreter floor uv provisions against, so it is
      // the first thing a fresh machine must fetch. The dependency lists are
      // RANGES, not resolved pins: uv.lock holds the resolution, and restating
      // it here would duplicate ~1400 lines that already ship verbatim with the
      // scaffold.
      ...py,
    },
    camundaClientMap,
    camundaPythonSdkMap,
  };

  const abs = path.resolve(outPath);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, JSON.stringify(summary, null, 2) + '\n');
  console.log(`scaffold-workers: wrote summary to ${outPath}`);
}

// copyWithSubst — read a text file, apply subst, write to dest (mkdir -p).
function copyWithSubst(srcFile, destFile, subst) {
  if (!fs.existsSync(srcFile)) throw new Error(`blueprint file missing: ${srcFile}`);
  const text = fs.readFileSync(srcFile, 'utf8');
  fs.mkdirSync(path.dirname(destFile), { recursive: true });
  fs.writeFileSync(destFile, subst ? subst(text) : text);
}

// copyVerbatim — byte-for-byte copy (mkdir -p), preserving file mode. Used for
// files that must not undergo text substitution (e.g. the Maven wrapper).
function copyVerbatim(srcFile, destFile) {
  if (!fs.existsSync(srcFile)) throw new Error(`blueprint file missing: ${srcFile}`);
  fs.mkdirSync(path.dirname(destFile), { recursive: true });
  fs.copyFileSync(srcFile, destFile);
  fs.chmodSync(destFile, fs.statSync(srcFile).mode);
}

// writeGitattributes — see step 4 in the pipeline doc above. GITATTRIBUTES_LINES
// (declared near the top constants, ahead of the top-level dispatch) mirrors the
// root `.gitattributes` recommended for a ProcessOS project: a catch-all LF rule
// plus the artifact-specific text formats (BPMN/DMN/form files land under the
// same artifact root from other generation phases, even though this script
// itself only emits Java/TS).

function gitattributesTokens(line) {
  return line.trim().split(/\s+/);
}

// A candidate line's glob counts as "already covered" only if some existing
// line for that same glob — column-aligned, reordered, or with extra
// attributes like `diff=bpmn-xml` — already sets every attribute the
// candidate requires (checked by token, not string equality). A bare glob
// match isn't enough: a hand-written `*.bpmn diff=bpmn-xml text` (no
// `eol=lf`) must NOT block appending the `eol=lf` this scaffold exists to
// enforce, so writeGitattributes doesn't silently skip normalization for
// that extension on every future run.
function isCovered(candidateLine, existingLines) {
  const [glob, ...requiredAttrs] = gitattributesTokens(candidateLine);
  return existingLines.some((existing) => {
    const tokens = gitattributesTokens(existing);
    return tokens[0] === glob && requiredAttrs.every((attr) => tokens.includes(attr));
  });
}

function writeGitattributes(artifactRoot) {
  const dest = path.join(artifactRoot, '.gitattributes');
  const exists = fs.existsSync(dest);
  const rawFileContent = exists ? fs.readFileSync(dest, 'utf8') : '';
  // Normalize CRLF before comparing/appending so a Windows-edited file doesn't
  // end up mixing line endings with the LF lines this function appends.
  const existingRaw = rawFileContent.replace(/\r\n/g, '\n');
  const existingLines = existingRaw.split('\n').map((l) => l.trim()).filter(Boolean);
  const missing = GITATTRIBUTES_LINES.filter((line) => !isCovered(line, existingLines));
  // Even when every pattern is already covered, an on-disk CRLF file still
  // needs rewriting to LF — the file's own encoding, not just its content,
  // is what this step normalizes.
  const needsCrlfNormalization = rawFileContent.includes('\r\n');
  if (exists && missing.length === 0 && !needsCrlfNormalization) return;

  fs.mkdirSync(artifactRoot, { recursive: true });
  const trimmedExisting = existingRaw.replace(/\n+$/, '');
  const missingBlock = missing.length ? `${missing.join('\n')}\n` : '';
  const body = trimmedExisting ? `${trimmedExisting}\n${missingBlock}` : missingBlock;
  fs.writeFileSync(dest, body);
}

// copyTree — recursively copy srcDir → destDir, keeping only paths for which
// keep(relPosix) is true, applying subst to each file's text.
function copyTree(srcDir, destDir, keep, subst) {
  if (!fs.existsSync(srcDir)) return;
  const walk = (dir) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const abs = path.join(dir, entry.name);
      const rel = path.relative(srcDir, abs).split(path.sep).join('/');
      if (entry.isDirectory()) { walk(abs); continue; }
      if (!keep(rel)) continue;
      copyWithSubst(abs, path.join(destDir, rel), subst);
    }
  };
  walk(srcDir);
}

// Sanitize a manifest variable name into a valid Java identifier. Nested FEEL
// context paths (e.g. "client.jurisdiction", "chProfile.status") and any other
// non-identifier characters are camelCase-flattened ("clientJurisdiction",
// "chProfileStatus") so ProcessVariables.java compiles. Names that collapse to
// the same identifier merge in the caller's Map (type disagreement → Object).
function toJavaField(name) {
  const parts = String(name == null ? '' : name).split(/[^A-Za-z0-9]+/).filter(Boolean);
  if (!parts.length) return null;
  let id = parts[0] + parts.slice(1).map((s) => s[0].toUpperCase() + s.slice(1)).join('');
  if (/^[0-9]/.test(id)) id = 'v' + id;
  return id;
}

function writeProcessVariables(p, meta, manifest) {
  // Union by name across every worker's input/output variables. On type
  // disagreement default to Object — the analyze-join script already flags
  // disagreements as review questions.
  const fields = new Map();
  for (const w of (manifest.workers || [])) {
    for (const v of [...(w.inputVariables || []), ...(w.outputVariables || [])]) {
      const name = toJavaField(v.name);
      if (!name) continue;
      const javaType = mapJavaType(v.type);
      if (fields.has(name) && fields.get(name) !== javaType) {
        fields.set(name, 'Object');
      } else if (!fields.has(name)) {
        fields.set(name, javaType);
      }
    }
  }

  const fieldLines = [...fields.entries()].map(([n, t]) => `    private ${t} ${n};`).join('\n');
  const hasFields = fields.size > 0;
  // With zero fields, Lombok's @AllArgsConstructor also emits a no-arg
  // constructor and collides with @NoArgsConstructor. @Builder on an empty
  // class is meaningless. Skip both until the manifest gains variables.
  const imports = [
    'import lombok.Getter;',
    'import lombok.NoArgsConstructor;',
    'import lombok.Setter;',
    'import lombok.ToString;',
  ];
  const annotations = ['@Getter', '@Setter', '@NoArgsConstructor', '@ToString'];
  if (hasFields) {
    imports.unshift('import lombok.AllArgsConstructor;');
    imports.splice(1, 0, 'import lombok.Builder;');
    annotations.splice(2, 0, '@Builder');
    annotations.splice(4, 0, '@AllArgsConstructor');
  }
  const body = [
    `package ${meta.packageBase}.models;`,
    '',
    ...imports,
    '',
    ...annotations,
    'public class ProcessVariables {',
    fieldLines || '    // No process variables declared in manifest. Add fields as workers are wired.',
    '}',
    '',
  ].join('\n');
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, body);
}

function mapJavaType(t) {
  const map = {
    'String': 'String', 'string': 'String',
    'Long': 'Long', 'long': 'Long', 'Integer': 'Integer', 'int': 'Integer',
    'Double': 'Double', 'double': 'Double', 'Float': 'Float', 'float': 'Float',
    'Boolean': 'Boolean', 'boolean': 'Boolean',
    'Number': 'Number',
  };
  return map[t] || 'Object';
}
