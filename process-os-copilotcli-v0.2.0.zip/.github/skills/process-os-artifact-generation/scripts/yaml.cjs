/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

/**
 * YAML wrapper — the ONLY file in the repo that require()s the `yaml` package.
 *
 * Resolves `yaml` by absolute path from the project's .camunda/node_modules.
 * `yaml` has zero transitive dependencies, so an absolute-path require is
 * self-sufficient — callers do NOT need to set NODE_PATH. That matters because the
 * repo's usual NODE_PATH="$(pwd)/..." prefix is bash-only syntax with no PowerShell
 * equivalent, and config reads happen in every gate check across ~10 skills.
 *
 * Centralising the dependency here makes a future library swap a one-file change.
 */

const fs = require('node:fs');
const path = require('node:path');

const YAML_DIR = path.join(process.cwd(), '.camunda', 'node_modules', 'yaml');

function load() {
  if (!fs.existsSync(YAML_DIR)) {
    const err = new Error(
      'ProcessOS Node deps missing at .camunda/node_modules. Run `c8 os install` (or `c8 os update`).'
    );
    err.code = 'DEPS_MISSING';
    throw err;
  }
  return require(YAML_DIR);
}

// Emission options applied to EVERY write, rather than passed per call site.
//
// `lineWidth: 0` disables line folding. At the default width the emitter breaks a long
// string across lines; the value survives (a fold is semantically a space) but the whole
// field re-flows on every edit, so changing one word in a paragraph produces a multi-line
// diff. Prose fields are wide by nature, which makes this the difference between a
// reviewable file and an unreviewable one.
//
// `blockQuote: 'literal'` writes a string that needs a multi-line form as a literal block
// (`|`) rather than a folded one (`>`), so what is on disk is what is in the value.
//
// Baked in rather than exposed as an argument so one emission style holds repo-wide and no
// caller can forget it. Verified non-breaking for the pre-existing caller: the RUN_DEFAULTS
// shape serialises byte-identically with and without these options — including
// `camunda-version: "8.10"`, which MUST stay quoted (bare 8.10 is the float 8.1).
const STRINGIFY_OPTIONS = { lineWidth: 0, blockQuote: 'literal' };

function parse(text) {
  return load().parse(text);
}

function stringify(obj) {
  return load().stringify(obj, STRINGIFY_OPTIONS);
}

/**
 * Emit `obj`, forcing the value of every field named in `proseFieldNames` to a literal
 * block scalar (`|-`) wherever it appears in the tree.
 *
 * Exists because a bare YAML scalar is TYPED, and free text is not. An answer of `no`
 * round-trips through this package as the string "no" (YAML 1.2), but PyYAML reads that
 * same file as boolean False (YAML 1.1), and `1.0`/`08` come back as numbers under both
 * revisions. A literal block is a string in 1.1 and 1.2 whatever it contains, so forcing
 * one closes the whole class — which no serializer option can do: `blockQuote` only
 * governs strings that ALREADY need a multi-line form, and a single-line `answer: no`
 * still emits bare.
 *
 * Values only. Forcing every scalar — keys included — emits the explicit-key `? |-` form,
 * which is valid YAML and unreadable. An empty string has no literal form and is left as
 * `""`, which parses back as a string under both revisions.
 *
 * Lives here, rather than in the caller, so `Document`/`visit` stay inside the one file
 * that require()s the package and a library swap remains a one-file change.
 *
 * @param {unknown} obj Value to emit.
 * @param {Iterable<string>} proseFieldNames Field names whose values are free text.
 * @returns {string} YAML text.
 */
function stringifyBlockLiteral(obj, proseFieldNames) {
  const YAML = load();
  const prose = new Set(proseFieldNames);
  const doc = new YAML.Document(obj);
  YAML.visit(doc, {
    Pair(_, pair) {
      const key = pair.key && pair.key.value;
      const value = pair.value;
      if (!prose.has(key) || !value || typeof value.value !== 'string') return;
      if (value.value === '') return;
      value.type = 'BLOCK_LITERAL';
    },
  });
  return doc.toString(STRINGIFY_OPTIONS);
}

module.exports = { parse, stringify, stringifyBlockLiteral, STRINGIFY_OPTIONS };
