#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// List what a reviewer put in an iteration's `feedback/`, dropping the scaffold.
//
// Usage:
//   node "list-feedback.cjs" <feedback-dir> [--json]
//
// Prints one entry name per line, sorted, or a JSON array with `--json`. Nothing
// is printed when the directory holds only its scaffold, so a caller counts lines
// (or array length) to decide whether there is anything to fold in.
//
// `README.md` is excluded: `iteration-dir.cjs` writes it when it creates the
// directory, to tell reviewers what to put there. It is never feedback content,
// and a caller that counted it would fold in an empty cycle on every iteration.
//
// A directory that does not exist lists as empty rather than failing — an
// iteration whose `feedback/` was never created holds no feedback, which is an
// answer. A directory that exists and cannot be read is not that state and exits
// 5, because reporting it as empty would silently skip a reviewer's material.
//
// Exit codes:
//   0  listed; the entries (if any) are on stdout.
//   2  usage error (missing or extra <feedback-dir>, unknown flag).
//   5  <feedback-dir> exists but could not be read.

const fs = require('fs');
const path = require('path');

const EXIT = { OK: 0, USAGE: 2, IO: 5 };

const SCAFFOLD = 'README.md';

const USAGE = 'Usage:\n  list-feedback.cjs <feedback-dir> [--json]\n';

/**
 * Entry names in a feedback directory, excluding the scaffold.
 *
 * @param {string} dir Path to the directory, `/`-joined or native, relative or absolute.
 *   Node's fs accepts forward slashes on every platform, so the path is normalised rather
 *   than rebuilt from its segments — rebuilding drops a leading separator, which turns an
 *   absolute POSIX path into a relative one and makes a populated directory list as empty.
 * @returns {string[]} Sorted names; empty when the directory does not exist.
 * @throws {Error} Tagged `.code = 'IO'` when the directory exists but cannot be read.
 */
function listFeedback(dir) {
  let names;
  try {
    names = fs.readdirSync(path.normalize(String(dir)));
  } catch (err) {
    if (err && err.code === 'ENOENT') return [];
    const wrapped = new Error(`cannot read ${dir}: ${err && err.message}`);
    wrapped.code = 'IO';
    throw wrapped;
  }
  return names.filter((n) => n !== SCAFFOLD).sort();
}

/**
 * @param {string[]} argv
 */
function main(argv) {
  let dir = null;
  let json = false;
  for (const arg of argv) {
    if (arg === '--json') json = true;
    else if (arg.startsWith('-')) {
      process.stderr.write(`unknown flag: ${arg}\n\n${USAGE}`);
      process.exit(EXIT.USAGE);
    } else if (dir === null) dir = arg;
    else {
      process.stderr.write(`unexpected argument: ${arg}\n\n${USAGE}`);
      process.exit(EXIT.USAGE);
    }
  }
  if (dir === null) {
    process.stderr.write(`missing <feedback-dir>\n\n${USAGE}`);
    process.exit(EXIT.USAGE);
  }

  let entries;
  try {
    entries = listFeedback(dir);
  } catch (err) {
    process.stderr.write(`${err.message}\n`);
    process.exit(EXIT.IO);
  }

  if (json) process.stdout.write(`${JSON.stringify(entries)}\n`);
  else if (entries.length > 0) process.stdout.write(`${entries.join('\n')}\n`);
  process.exit(EXIT.OK);
}

module.exports = { EXIT, SCAFFOLD, listFeedback };

if (require.main === module) main(process.argv.slice(2));
