#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Generate one DMN 1.3 file per entry in manifest.decisions[]. Pure
// templating — no LLM reasoning. Replaces the v3 generate-dmn agent
// (which spent 60-130 s doing exactly this with an LLM).
//
// XML mirrors the schema described in the prior generate-dmn.md sub-skill:
// <definitions/><decision/><decisionTable hitPolicy="UNIQUE"/> with
// <input> per decision.inputs[], <output> per decision.outputs[], and two
// stub rules carrying TODO entries.
//
// Usage:
//   node scripts/generate-dmn.cjs [<artifactRoot>]    (default: "process-implementation/artifacts")
//
// Reads:  <root>/.manifest.json
// Writes: <root>/src/main/resources/decisions/<decisionId>.dmn  (one per decision)

'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = process.argv[2] || 'process-implementation/artifacts';
const MANIFEST_PATH = path.join(ROOT, '.manifest.json');
const OUT_DIR = path.join(ROOT, 'src', 'main', 'resources', 'decisions');

if (!fs.existsSync(MANIFEST_PATH)) {
  console.error(`generate-dmn: missing ${MANIFEST_PATH}`);
  process.exit(2);
}

const manifest = JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf8'));
const decisions = manifest.decisions || [];

if (decisions.length === 0) {
  console.log('generate-dmn: no decisions in manifest — nothing to generate.');
  process.exit(0);
}

fs.mkdirSync(OUT_DIR, { recursive: true });

// Manifest type → DMN typeRef.
const TYPE_MAP = {
  'String': 'string',
  'string': 'string',
  'Double': 'double',
  'Float': 'double',
  'double': 'double',
  'float': 'double',
  'Long': 'integer',
  'Integer': 'integer',
  'int': 'integer',
  'Number': 'double',
  'number': 'double',
  'Boolean': 'boolean',
  'boolean': 'boolean',
};

function dmnType(t) {
  if (!t) return 'string';
  return TYPE_MAP[t] || 'string';
}

// DMN ids must be valid XML NCNames: alphanumerics + underscore + hyphen,
// must start with a letter or underscore. The generator avoids hyphens in
// element ids and converts hyphens to underscores for safety.
function safeId(s) {
  return String(s).replace(/[^A-Za-z0-9_-]/g, '_');
}

function titleCase(s) {
  if (!s) return '';
  return String(s).replace(/[_-]+/g, ' ').replace(/\b([a-z])/g, (m) => m.toUpperCase());
}

function xmlEscape(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

const writtenFiles = [];

for (const d of decisions) {
  const decisionId = d.decisionId;
  const decisionName = d.decisionName || decisionId;
  const inputs = d.inputs || [];
  // Decisions in the manifest may carry one or many outputs; default to one.
  const outputs = d.outputs && d.outputs.length ? d.outputs : [{ name: 'result', type: 'String' }];

  const idSafe = safeId(decisionId);
  const lines = [];
  lines.push('<?xml version="1.0" encoding="UTF-8"?>');
  lines.push('<definitions xmlns="https://www.omg.org/spec/DMN/20191111/MODEL/"');
  lines.push('             xmlns:dmndi="https://www.omg.org/spec/DMN/20191111/DMNDI/"');
  lines.push('             xmlns:dc="http://www.omg.org/spec/DMN/20180521/DC/"');
  lines.push(`             id="Definitions_${idSafe}"`);
  lines.push(`             name="${xmlEscape(decisionName)}"`);
  lines.push('             namespace="http://camunda.org/schema/1.0/dmn">');
  lines.push('');
  lines.push(`  <decision id="${decisionId}" name="${xmlEscape(decisionName)}">`);
  lines.push(`    <decisionTable id="dt_${idSafe}" hitPolicy="UNIQUE">`);
  lines.push('');

  for (const inp of inputs) {
    const safe = safeId(inp.name);
    const expr = inp.expression || inp.name;
    lines.push(`      <input id="in_${safe}" label="${xmlEscape(titleCase(inp.name))}">`);
    lines.push(`        <inputExpression id="inExpr_${safe}" typeRef="${dmnType(inp.type)}">`);
    lines.push(`          <text>${xmlEscape(expr)}</text>`);
    lines.push('        </inputExpression>');
    lines.push('      </input>');
  }

  for (const out of outputs) {
    const safe = safeId(out.name);
    lines.push(`      <output id="out_${safe}"`);
    lines.push(`              name="${xmlEscape(out.name)}"`);
    lines.push(`              label="${xmlEscape(titleCase(out.name))}"`);
    lines.push(`              typeRef="${dmnType(out.type)}" />`);
  }

  // One stub rule carrying a TODO marker; the user fills in the actual logic
  // (and adds more rows). Rule cells must hold a parseable FEEL expression even
  // in the stub: an empty <text></text> deploys as the empty FEEL expression ''
  // and is rejected by Zeebe ("failed to parse expression ''"), making a freshly
  // generated DMN undeployable. Use the DMN "any" unary-test `-` for input
  // entries and the literal `null` for output entries — both parse.
  //
  // Exactly ONE rule, not two: the table uses hitPolicy="UNIQUE", so two
  // catch-all (`-`) rows both match every input and the decision fails on
  // evaluation ("multiple values aren't allowed for UNIQUE hit policy") even
  // though it deploys. A single catch-all row matches once and evaluates to
  // null — deployable AND evaluable until the user replaces it.
  {
    const desc = `TODO: define condition from process docs — ${decisionName}`;
    lines.push(`      <rule id="rule_1">`);
    lines.push(`        <description>${xmlEscape(desc)}</description>`);
    for (const inp of inputs) {
      const safe = safeId(inp.name);
      lines.push(`        <inputEntry id="inEntry_1_${safe}">`);
      lines.push(`          <text>-</text>`);
      lines.push('        </inputEntry>');
    }
    for (const out of outputs) {
      const safe = safeId(out.name);
      lines.push(`        <outputEntry id="outEntry_1_${safe}">`);
      lines.push(`          <text>null</text>`);
      lines.push('        </outputEntry>');
    }
    lines.push('      </rule>');
  }

  lines.push('    </decisionTable>');
  lines.push('  </decision>');
  lines.push('');
  lines.push('  <dmndi:DMNDI>');
  lines.push('    <dmndi:DMNDiagram>');
  lines.push(`      <dmndi:DMNShape dmnElementRef="${decisionId}">`);
  lines.push('        <dc:Bounds height="80" width="180" x="160" y="100" />');
  lines.push('      </dmndi:DMNShape>');
  lines.push('    </dmndi:DMNDiagram>');
  lines.push('  </dmndi:DMNDI>');
  lines.push('</definitions>');

  // File path uses original decisionId (preserves hyphens for human readability).
  const fp = path.join(OUT_DIR, `${decisionId}.dmn`);
  fs.writeFileSync(fp, lines.join('\n') + '\n');
  writtenFiles.push(fp);
}

console.log(`generate-dmn: wrote ${writtenFiles.length} DMN file(s) to ${OUT_DIR}`);
for (const fp of writtenFiles) console.log(`  ${fp}`);
