#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Run uv commands in a Python project directory.
//
// A `( cd <dir> && uv sync && uv run mypy )` shell chain breaks on native Windows
// twice over: the `cd X && Y` subshell chain, and the `&&` chain itself, which is
// a parse error in PowerShell 5.1. The command literal stays `uv` and the shell
// decision belongs to `runShellCli`, which applies one on Windows only. "Is it on
// PATH" is settled first with `findOnPath` — pure Node, no shell — so a real
// absence stays distinguishable from a shell's own failure exit.
//
// There is no "skip when the toolchain is absent" path, and the reason differs
// from run-npm.cjs's. npm ships bundled with Node, so a missing npm means a broken
// Node install. uv ships with nothing. A missing uv is a stop here because
// selecting a Python target selects uv as the bundle's package manager: the
// generated pyproject.toml and uv.lock are a locked unit that only uv installs,
// so no other tool can run the gate. A gate that reported green on a
// machine where it never ran would describe a bundle nobody observed.
//
// run-maven.cjs does have a skip path, and that is not a precedent: a Node-only
// sandbox can legitimately lack a JDK while still being a valid place to generate
// a Java bundle. A Python bundle's own checks are not optional in the same way.
//
// The working directory of the calling process never changes. The project
// directory is passed to the child as its `cwd`, which is why a caller does not
// repeat uv's own `--directory` flag.
//
// Usage:
//   node "run-uv.cjs" <project-dir> <uv-arg>...
//
// uv's own output is inherited, and its exit code is this script's, so a caller
// gates on each command exactly as it would on the command line. Each gate
// command runs as its own invocation, because one chained call would collapse
// four separate verdicts into one.
//
// Exit codes:
//   0    uv succeeded
//   2    usage error, uv unavailable, or uv could not be started at all — in none
//        of those did anything run, so this is never a green gate
//   else uv's own exit code

const fs = require('fs');
const { findOnPath, runShellCli } = require('./resolve-node-cli.cjs');

const EXIT = { OK: 0, DID_NOT_RUN: 2 };

const USAGE = 'usage: run-uv.cjs <project-dir> <uv-arg>...\n';

/**
 * Run uv.
 *
 * @param {string} dir Project directory; becomes the child's cwd.
 * @param {string[]} args uv arguments, passed through verbatim.
 * @param {object} [deps]
 * @param {typeof runShellCli} [deps.runShell] Injectable runner, for tests.
 * @param {typeof findOnPath} [deps.onPath] Injectable PATH probe, for tests.
 * @returns {{status: number, message: string|null, command: string}}
 */
function runUv(dir, args, deps = {}) {
  const runShell = deps.runShell || runShellCli;
  const onPath = deps.onPath || findOnPath;

  if (!onPath('uv')) {
    return {
      status: EXIT.DID_NOT_RUN,
      message: `no uv on PATH — nothing ran in ${dir}. A python target installs its bundle with uv, so uv is a required toolchain rather than an optional one. Install it (https://docs.astral.sh/uv/) and run the gate again.`,
      command: 'uv',
    };
  }

  const result = runShell('uv', args, { cwd: dir, stdio: 'inherit' });
  if (!result.launched) {
    return {
      status: EXIT.DID_NOT_RUN,
      message: `uv could not be started: ${
        result.error ? result.error.message : 'no exit status'
      }`,
      command: 'uv',
    };
  }
  return { status: result.status, message: null, command: 'uv' };
}

module.exports = { EXIT, runUv };

if (require.main === module) {
  const [dir, ...args] = process.argv.slice(2);
  if (!dir || args.length === 0) {
    process.stderr.write(USAGE);
    process.exit(EXIT.DID_NOT_RUN);
  }
  if (!fs.existsSync(dir)) {
    process.stderr.write(`Project directory not found: ${dir}\n`);
    process.exit(EXIT.DID_NOT_RUN);
  }
  const { status, message } = runUv(dir, args);
  if (message) process.stderr.write(`${message}\n`);
  process.exit(status);
}
