#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Strip a leading UTF-8 BOM before JSON.parse, portably.
//
// PowerShell can prepend a byte-order mark when piping between two native
// commands (bash never does), and a BOM-prefixed string makes a bare
// JSON.parse throw. Every call site that reads a prior command's stdout via
// readFileSync(0, 'utf8') and parses it as JSON needs this — previously each
// one inlined its own `.replace(/^\uFEFF/, '')`; this centralizes it.
//
// Two ways to use it:
//
//   1. From a .cjs script, require the function the normal shared-script way:
//        const { stripBOM } = require(path.join(
//          __dirname, '../../..', 'strip-bom.cjs'));
//        const raw = stripBOM(fs.readFileSync(0, 'utf8'));
//
//   2. From SKILL.md/references/*.md prose, insert it as its own pipe stage
//      ahead of the `node -e` that parses the JSON — no inline regex, no
//      `require()` of a path that would need bundler-aware rewriting inside
//      an eval string:
//        prior-command | node "strip-bom.cjs" | node -e "
//        const o = JSON.parse(require('fs').readFileSync(0,'utf8'));
//        ...
//        "
//
// As a CLI, reads all of stdin, strips a leading BOM if present, and writes
// the result to stdout unchanged otherwise — safe to insert into any pipe
// that ends in a JSON.parse.

/**
 * @param {string} s Raw text, possibly BOM-prefixed.
 * @returns {string} The same text with a leading BOM removed, if present.
 */
function stripBOM(s) {
  return s.replace(/^\uFEFF/, '');
}

module.exports = { stripBOM };

if (require.main === module) {
  process.stdout.write(stripBOM(require('fs').readFileSync(0, 'utf8')));
}
