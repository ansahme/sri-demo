/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Single source of the Camunda Forms JSON shape (envelope + component) shared
// by every ProcessOS form generator. The artifact pipeline
// (skills/process-os-artifact-generation/scripts/generate-forms.cjs) builds its .form output
// through here, so the exporter/schema version and the component-building rules live in
// exactly one place.
//
// Exports:
//   EXPORTER_NAME, EXPORTER_VERSION, EXEC_PLATFORM, EXEC_PLATFORM_VERSION,
//   SCHEMA_VERSION  — Camunda Forms envelope constants
//   ALLOWED_TYPES   — Set of supported component types
//   titleCase(s)    — humanize a key into a default label
//   buildComponent(field, context?) -> component object
//   formEnvelope(id, components) -> full .form object
//   resetFieldIdState() -> clear the per-(scope,field) occurrence tracker (call once per
//                          top-level generation run)

const crypto = require('crypto');

// Generated ids/rows are deterministic: we hash a field identity (`key`/`name`/`id`/`label`/`text`
// plus `type`) within a scope, where top-level scope is the form id and nested scope is the
// parent's composite key. `occurrences` only disambiguates duplicates of the same
// `${scopeId}:${type}:${identity}` in one run, and `resetFieldIdState()` clears it once per
// top-level generation pass so unchanged input reproduces byte-identical output.
const occurrences = new Map();

function resetFieldIdState() {
  occurrences.clear();
}

// What identifies a field on its own terms, independent of where it sits in the array: the key it
// binds to, falling back to whatever else names it when a component has no key (e.g. a `text`
// view, identified by its content).
function fieldIdentity(field) {
  const candidate = field.key ?? field.name ?? field.id ?? field.label ?? field.text ?? '';
  return String(candidate);
}

// Short, deterministic, low-collision — not a checksum anyone verifies, just a stable
// discriminator derived from the field's own content rather than run order.
function shortHash(text) {
  return crypto.createHash('sha1').update(text).digest('hex').slice(0, 10);
}

// One occurrence number per (scope, field) pair, so a genuine duplicate (two fields sharing a key
// within the same scope) still gets distinct hashes while every unique-key field is unaffected.
// `scopeId` is the form id for a top-level field, or a parent-derived scope for a nested one (see
// `buildComponent`'s `context.scopeId`), so two children with the same key under different
// parents never share a tracking key.
function fieldOccurrence(scopeId, identity, type) {
  const trackingKey = stableCompositeBase(scopeId, type, identity);
  const n = occurrences.get(trackingKey) ?? 0;
  occurrences.set(trackingKey, n + 1);
  return n;
}

function stableCompositeBase(scopeId, type, identity) {
  return `${scopeId}:${type}:${identity}`;
}

function stableCompositeKey(scopeId, type, identity, occurrence) {
  const base = stableCompositeBase(scopeId, type, identity);
  return occurrence === 0 ? base : `${base}:${occurrence}`;
}

// Bump explicitly if the form-json-schema shape changes (process-os-forms-linting/schema.json).
const EXPORTER_NAME = 'Camunda Forms';
const EXPORTER_VERSION = '0.23.0';
const EXEC_PLATFORM = 'Camunda Cloud';
const EXEC_PLATFORM_VERSION = '8.9.0';
const SCHEMA_VERSION = 19;

const ALLOWED_TYPES = new Set([
  'textfield', 'textarea', 'number', 'datetime',
  'checkbox', 'select', 'taglist', 'radio',
  'dynamiclist', 'text',
]);

function titleCase(s) {
  if (!s) return '';
  return String(s)
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/[_-]+/g, ' ')
    .replace(/\b([a-z])/g, (m) => m.toUpperCase());
}

// Build a single Camunda Form component from a field descriptor.
//   { type, key|name|id, label?, required?, values?, componentId?, layout?, description?, defaultValue? }
// `type` falls back to textfield when not in ALLOWED_TYPES. `id`/`name` act as
// key fallbacks only (never emitted); a component `id` and `layout` are always emitted —
// `componentId` and `layout.columns` are kept as given when the caller supplies them (including
// an explicit `null` for `columns`, which is a valid form-json value distinct from "not
// specified" — single column, no explicit count), and generated (id) or defaulted (columns: null,
// one field per row) only for what the caller left out entirely. `layout.row` is different: an
// explicit `null` is treated the same as an absent row and always gets a freshly generated one,
// because some form-js renderers group every `row: null` component into a single shared row —
// only a non-null `row` string is a real caller-specified placement and is preserved as given.
// This matches what Desktop Modeler writes on every field and what `@bpmn-io/form-js-viewer`'s
// importer treats as the well-formed (non-legacy) shape. Key
// insertion order is fixed (type, layout, id, key, label, ...) so output is byte-stable across
// runs.
//
// `context.formId` scopes the generated id/row to the form this field belongs to — pass the
// manifest entry's own `formId` (or another stable per-form identifier) so two forms can never
// generate the same id for unrelated fields that happen to share a key.
//
// A `dynamiclist`/group field's `components` are normalized recursively through this same
// function, so nested fields also get a deterministic `id`/`layout.row` when they omit them, and
// keep an explicit `id`/`layout` exactly as given, same as a top-level field. Each child is scoped
// to its own parent (`context.scopeId` becomes the parent's composite key for its children, while
// `context.formId` is threaded through unchanged for any further nesting), so two children with
// the same key under different parents never generate the same id.
function buildComponent(field, context) {
  const type = ALLOWED_TYPES.has(field.type) ? field.type : 'textfield';
  const key = field.key || field.name || field.id;
  const label = field.label || titleCase(key || '');
  const layout = field.layout || {};

  const formId = (context && context.formId) || '';
  const scopeId = (context && context.scopeId) || formId;
  const identity = fieldIdentity(field);
  const occurrence = fieldOccurrence(scopeId, identity, type);
  const compositeKey = stableCompositeKey(scopeId, type, identity, occurrence);

  const c = { type };
  c.layout = {
    row: layout.row ?? `Row_${shortHash(`${compositeKey}:row`)}`,
    columns: layout.columns !== undefined ? layout.columns : null,
  };
  c.id = field.componentId ?? `Field_${shortHash(compositeKey)}`;
  // form-json schema constraints:
  //   `text` (text-view) — no key, no label (renders `text` FEEL expression instead)
  //   `dynamiclist`      — no key (the list binds via `path`), label allowed as group heading
  //   all other inputs   — key + label required
  if (type !== 'text' && type !== 'dynamiclist') c.key = key;
  if (type !== 'text') c.label = label;
  if (field.required) c.validate = { required: true };
  // select/taglist/radio: convert string values to { label, value } objects.
  if ((type === 'select' || type === 'taglist' || type === 'radio') && Array.isArray(field.values)) {
    c.values = field.values.map((v) =>
      typeof v === 'string' ? { label: titleCase(v.replace(/_/g, ' ')), value: v } : v
    );
  }
  if (field.description != null) c.description = field.description;
  if (field.defaultValue != null) c.defaultValue = field.defaultValue;
  // text component: content is emitted as `text`, not `label`.
  if (field.text != null) c.text = field.text;
  // dynamiclist / group: nested child components, each normalized through this same function and
  // scoped to this component's own composite key.
  if (Array.isArray(field.components)) {
    c.components = field.components.map((child) => buildComponent(child, { formId, scopeId: compositeKey }));
  }
  // dynamiclist path binding.
  if (field.path != null) c.path = field.path;
  // dynamiclist flags.
  if (field.isRepeating != null) c.isRepeating = field.isRepeating;
  if (field.allowAddRemove != null) c.allowAddRemove = field.allowAddRemove;
  // Readonly flag (e.g. question text in a dynamic list row).
  if (field.readonly != null) c.readonly = field.readonly;
  return c;
}

function formEnvelope(id, components) {
  return {
    id,
    exporter: { name: EXPORTER_NAME, version: EXPORTER_VERSION },
    executionPlatform: EXEC_PLATFORM,
    executionPlatformVersion: EXEC_PLATFORM_VERSION,
    schemaVersion: SCHEMA_VERSION,
    type: 'default',
    components,
  };
}

module.exports = {
  EXPORTER_NAME,
  EXPORTER_VERSION,
  EXEC_PLATFORM,
  EXEC_PLATFORM_VERSION,
  SCHEMA_VERSION,
  ALLOWED_TYPES,
  titleCase,
  buildComponent,
  formEnvelope,
  resetFieldIdState,
};
