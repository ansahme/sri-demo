#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Search file contents for a pattern — the portable replacement for `grep`.
//
// Usage:
//   node "search-files.mts" --pattern <regex> [--fixed]
//        [--ignore-case] [--only-matching] [--unique] [--count] [--quiet]
//        [--exclude <glob>]... <path>...
//
//   --pattern <p>     what to look for. A JavaScript regular expression, or a
//                     literal string with --fixed. Required.
//   --fixed           treat --pattern as a literal string (`grep -F`). Use it for
//                     anything with regex metacharacters. `[MANUAL-PENDING]` is a
//                     character class otherwise: it matches any ONE of those
//                     letters, and never the marker as written — hits everywhere
//                     the marker is not, and a miss where it is.
//   --ignore-case     match the CONTENT without regard to case (`grep -i`). Path
//                     matching is always case-sensitive.
//   --only-matching   print the matched substring rather than the whole line
//                     (`grep -o`). Every match on a line is printed, not just the
//                     first.
//   --unique          print each distinct matched value once, sorted, WITHOUT the
//                     `<path>:<line>:` prefix (`| sort -u`). A value found in
//                     three places is one value, and a prefix would defeat that.
//   --count           print how many matches were found instead of the matches.
//   --quiet           print nothing; the exit code is the whole answer (`grep -q`).
//
// A `<path>` is a file, a directory, or a glob in the `list-files.mts` dialect —
// `*`, `?`, `[...]` and a `**` segment that matches zero or more directories. A
// directory is searched recursively, so `artifacts/` means `grep -r`.
// `--exclude <glob>` drops matches the same way it does there, and prunes an
// excluded directory during the walk.
//
// Output is one `<path>:<line>:<text>` per match, paths always `/`-separated so
// they can be handed straight to a file-reading tool. Operands are searched in
// the order given, the files under one operand sorted, matches in file order.
//
// Exit codes — the same three states `grep` reports, and for the same reason:
//   0  at least one match.
//   1  the search ran and found nothing. An answer, not a failure.
//   2  the search could NOT run: a usage error, a named file that does not exist,
//      or a file that could not be read. Never collapsed into 1 — a search that
//      did not happen must not read as a clean tree.
//
// A glob that matches no file contributes nothing and is not an error, the same
// as `list-files.mts`. A path with no glob metacharacter is a name the caller
// meant literally, so its absence is exit 2: a mis-substituted `<TARGET>` would
// otherwise report "no matches" and pass every gate downstream.
import * as fs from 'node:fs';
import * as path from 'node:path';
import { pathToFileURL } from 'node:url';

import { list } from './list-files.mts';

const EXIT = { MATCH: 0, NO_MATCH: 1, ERROR: 2 };

const USAGE =
  'usage: search-files.mts --pattern <regex> [--fixed] [--ignore-case] ' +
  '[--only-matching] [--unique] [--count] [--quiet] [--exclude <glob>]... <path>...\n';

/** One matched line, or one matched substring under `--only-matching`. */
export interface Match {
  /** Project-relative, `/`-separated. */
  file: string;
  /** 1-based, as every editor and `grep -n` counts. */
  line: number;
  /** The whole line, or the matched substring. */
  text: string;
}

/** How to interpret `--pattern` and what to emit. */
export interface SearchOptions {
  fixed?: boolean;
  ignoreCase?: boolean;
  onlyMatching?: boolean;
  exclude?: string[];
}

/** True when the argument uses a glob metacharacter list-files.mts understands. */
const isGlob = (p: string): boolean => /[*?[]/.test(p);

/**
 * Escape a string so it matches itself inside a RegExp.
 *
 * @param s Literal text.
 * @returns Source safe to embed in a pattern.
 */
export function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Build the matcher for one search.
 *
 * Always global: `--only-matching` reports every occurrence on a line, not only
 * the first, which is what makes `grep -oE 'id="[^"]+"'` return every id in a
 * BPMN rather than one per line.
 *
 * @param pattern Regex source, or literal text when `fixed`.
 * @param options Interpretation flags.
 * @returns The compiled matcher.
 * @throws {SyntaxError} When the pattern is not a valid regular expression.
 */
export function compilePattern(pattern: string, options: SearchOptions = {}): RegExp {
  const source = options.fixed ? escapeRegExp(pattern) : pattern;
  return new RegExp(source, options.ignoreCase ? 'gi' : 'g');
}

/**
 * Resolve the `<path>` operands to the files to search.
 *
 * A directory expands to `<dir>/**`, so `grep -r <dir>` keeps its natural
 * spelling. A literal (non-glob) file name that does not exist is an error
 * rather than an empty result: it is a name the caller meant, and reporting zero
 * matches for a path that was never read is the "there but broken looks like an
 * answer" failure.
 *
 * @param operands The `<path>` arguments, in the order given.
 * @param options Only `exclude` is read.
 * @returns Project-relative, `/`-separated paths, duplicates removed.
 * @throws {Error} When a literal path does not exist.
 */
export function resolveTargets(operands: string[], options: SearchOptions = {}): string[] {
  const patterns: string[] = [];
  for (const operand of operands) {
    if (isGlob(operand)) {
      patterns.push(operand);
      continue;
    }
    // A trailing slash is how a caller spells "this is a directory"; strip it so
    // the stat and the joined glob both work.
    const bare = operand.replace(/[/\\]+$/, '');
    let stat: fs.Stats;
    try {
      stat = fs.statSync(bare);
    } catch {
      throw new Error(`no such file or directory: ${operand}`);
    }
    // `.` is the working directory, and `./**` would prefix every emitted path
    // with `./` — cosmetic here, but those paths are handed to a file-reading
    // tool, and `./x` vs `x` is two spellings of one file for anything that
    // compares them against another listing.
    if (!stat.isDirectory()) patterns.push(bare);
    else patterns.push(bare === '.' ? '**' : `${bare}/**`);
  }
  return list(patterns, { exclude: options.exclude });
}

/**
 * Search one file's contents.
 *
 * @param file Project-relative path, `/`-separated.
 * @param matcher A global RegExp; its lastIndex is reset per line.
 * @param options Only `onlyMatching` is read.
 * @returns Every match, in file order.
 * @throws {Error} When the file cannot be read.
 */
export function searchOne(file: string, matcher: RegExp, options: SearchOptions = {}): Match[] {
  const out: Match[] = [];
  // A CRLF file would otherwise leave a stray \r on the end of every emitted
  // line, and on a `$`-anchored pattern would stop it matching at all.
  const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i] as string;
    matcher.lastIndex = 0;
    if (options.onlyMatching) {
      for (const m of line.matchAll(matcher)) {
        // A zero-width match would loop forever on matchAll's own terms and
        // contributes no text; skip it rather than emitting empty rows.
        if (m[0] !== '') out.push({ file, line: i + 1, text: m[0] });
      }
    } else if (matcher.test(line)) {
      out.push({ file, line: i + 1, text: line });
    }
  }
  return out;
}

/**
 * Search every resolved target.
 *
 * @param operands The `<path>` arguments.
 * @param pattern Regex source, or literal text when `options.fixed`.
 * @param options Interpretation flags.
 * @returns Every match, files in the order given.
 * @throws {Error} When a path cannot be resolved or a file cannot be read.
 */
export function search(
  operands: string[],
  pattern: string,
  options: SearchOptions = {},
): Match[] {
  const matcher = compilePattern(pattern, options);
  const out: Match[] = [];
  for (const file of resolveTargets(operands, options)) {
    out.push(...searchOne(file, matcher, options));
  }
  return out;
}

/** Everything the CLI needs from argv. */
export interface ParsedArgs {
  pattern: string;
  paths: string[];
  count: boolean;
  quiet: boolean;
  unique: boolean;
  options: SearchOptions;
}

/**
 * Split argv into flags and path operands.
 *
 * @param argv Arguments after the script path.
 * @returns The parsed call, or null when the arguments do not form a valid one.
 */
export function parseArgs(argv: string[]): ParsedArgs | null {
  let pattern: string | null = null;
  let count = false;
  let quiet = false;
  let unique = false;
  let fixed = false;
  let ignoreCase = false;
  let onlyMatching = false;
  const exclude: string[] = [];
  const paths: string[] = [];

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i] as string;
    if (arg === '--fixed') fixed = true;
    else if (arg === '--ignore-case') ignoreCase = true;
    else if (arg === '--only-matching') onlyMatching = true;
    else if (arg === '--unique') unique = true;
    else if (arg === '--count') count = true;
    else if (arg === '--quiet') quiet = true;
    else if (arg === '--pattern') {
      const value = argv[++i];
      if (value === undefined) return null;
      pattern = value;
    } else if (arg === '--exclude') {
      const value = argv[++i];
      // A flag-shaped value means the glob was left out, the same way it does in
      // list-files.mts: `--exclude --quiet a.md` would exclude a file named
      // `--quiet` and drop the quiet flag, printing a listing and exiting 0. No
      // exclusion glob starts with `--`. `--pattern` deliberately does NOT get
      // this check — a pattern is arbitrary text, and `^--- ` is a real one.
      if (value === undefined || value.startsWith('--')) return null;
      exclude.push(value);
    } else if (arg.startsWith('--')) {
      // An unrecognised option is a usage error, never a path. Swallowed as one,
      // `--only-match` searches a file that does not exist and `--uniq` turns a
      // dedup into a missing-path error — each a wrong answer dressed as a result.
      return null;
    } else paths.push(arg);
  }

  if (pattern === null || paths.length === 0) return null;
  // The three output modes are mutually exclusive: each discards what the others
  // print, so a combination silently honours one and drops the rest.
  if ([count, quiet, unique].filter(Boolean).length > 1) return null;
  // `--unique` prints values, and a whole line is not a value: without
  // `--only-matching` it would just dedupe identical lines, which no caller wants
  // and which reads as a working extraction.
  if (unique && !onlyMatching) return null;
  return { pattern, paths, count, quiet, unique, options: { fixed, ignoreCase, onlyMatching, exclude } };
}

/**
 * The exit code is set rather than taken with `process.exit`, and the process is
 * left to end on its own. A write to a pipe is asynchronous, and `process.exit`
 * does not drain it — a listing long enough to matter is exactly the one that
 * gets truncated, and the caller reads a short answer as a complete one.
 *
 * @param argv Arguments after the script path.
 */
function main(argv: string[]): void {
  const parsed = parseArgs(argv);
  if (parsed === null) {
    process.stderr.write(USAGE);
    process.exitCode = EXIT.ERROR;
    return;
  }

  let matches: Match[];
  try {
    matches = search(parsed.paths, parsed.pattern, parsed.options);
  } catch (e) {
    process.stderr.write(`search-files: ${(e as Error).message}\n`);
    process.exitCode = EXIT.ERROR;
    return;
  }

  if (parsed.quiet) {
    // Nothing on stdout at all — the caller reads the exit code.
  } else if (parsed.count) {
    process.stdout.write(`${matches.length}\n`);
  } else if (parsed.unique) {
    const values = [...new Set(matches.map((m) => m.text))].sort();
    process.stdout.write(values.map((v) => `${v}\n`).join(''));
  } else {
    process.stdout.write(matches.map((m) => `${m.file}:${m.line}:${m.text}\n`).join(''));
  }
  process.exitCode = matches.length > 0 ? EXIT.MATCH : EXIT.NO_MATCH;
}

if (import.meta.url === pathToFileURL(process.argv[1] as string).href) main(process.argv.slice(2));
