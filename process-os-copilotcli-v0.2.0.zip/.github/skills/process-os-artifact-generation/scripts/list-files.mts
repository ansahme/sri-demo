#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// List the files matching one or more glob patterns, and optionally just count them.
//
// Usage:
//   node "list-files.mts" [--count] [--ignore-case] [--natural]
//                                        [--limit <n>] [--exclude <glob>]... <pattern>...
//
//   --count        print how many files matched instead of the matches themselves.
//   --exclude      drop matches this glob hits; repeatable. A glob with no `/`
//                  matches any single path segment, so `node_modules` prunes that
//                  directory wherever it sits and `*-brief.md` drops those files;
//                  a glob containing `/` matches the whole relative path. A
//                  trailing slash is ignored, so `node_modules/` means the same
//                  thing. Unlike .gitignore there is NO directory-only form:
//                  `build/*` and `build/*/` both drop the files under `build` as
//                  well as its subdirectories.
//   --ignore-case  match patterns and exclusions without regard to case.
//   --natural      order by embedded numbers rather than as text, so `round9` sorts
//                  before `round10` and the last line really is the newest. Replaces
//                  `sort -V`, whose flag Windows' sort.exe does not have. Cannot be
//                  combined with --limit — that is a usage error, since the cap keeps
//                  the HEAD of each group and the two together would return the
//                  oldest entries rather than the newest.
//   --limit <n>    print at most n matches in total, drawn round-robin across the
//                  patterns so an early one cannot starve a later one. Nothing in
//                  the output marks it as truncated, so a step passing one has to
//                  say so in its own prose. --count still reports the true total.
//
// A pattern is a project-relative path whose segments may use `*`, `?` and `[...]`.
// A `**` segment matches zero or more directories, so `**/*.bpmn` searches the whole
// tree. Only a pattern that needs it walks: one globbed in its last segment alone
// still resolves with a single readdir.
//
// Only files match. A directory named `notes.md` is not a `*.md` hit — the shell's
// `ls` counts it as one, which is wrong on every platform, not just Windows. A
// symlink pointing at a file IS a match, as it is for `ls` and `find`; a symlinked
// directory is never descended, the same choice `find` makes without -L.
//
// An excluded directory is pruned during the walk rather than filtered afterwards,
// so `--exclude node_modules` also means it is never read.
//
// Prints one match per line, sorted within each pattern, patterns in the order
// given, duplicates removed. Paths always use `/` so the output can be handed
// straight back to a file-reading tool on any platform.
//
// A missing directory or an unmatched pattern contributes nothing and is not an
// error. Always exits 0; exits 2 only on a usage error.
import * as fs from 'node:fs';
import { createRequire } from 'node:module';
import * as path from 'node:path';
import { pathToFileURL } from 'node:url';

// The file is ESM TypeScript, which cannot `require` a `.cjs` directly.
const require = createRequire(import.meta.url);
const { naturalCompare } = require('./natural-order.cjs') as {
  naturalCompare(a: string, b: string, ignoreCase?: boolean): number;
};

const EXIT = { OK: 0, USAGE: 2 };

const USAGE =
  'usage: list-files.mts [--count] [--ignore-case] [--natural] [--limit <n>] ' +
  '[--exclude <glob>]... <pattern>...\n';

/** Matching behaviour shared by every entry point. */
export interface ListOptions {
  /** Globs whose hits are dropped; see `--exclude`. */
  exclude?: string[];
  /** Match without regard to case. */
  ignoreCase?: boolean;
  /** Order by embedded numbers rather than as text; see `--natural`. */
  natural?: boolean;
}

/** Precompiled `--exclude` globs, split by how they are matched. */
export interface Excluder {
  /** Tested against every path segment. */
  segment: RegExp[];
  /** Tested against the whole relative path. */
  full: RegExp[];
}

/** True when the segment uses a glob metacharacter. */
const isGlob = (segment: string): boolean => /[*?[]/.test(segment) || segment === '**';

/**
 * @param options Matching behaviour for this call.
 * @returns The comparator Array#sort should use.
 */
const sorter = (options: ListOptions): ((a: string, b: string) => number) | undefined =>
  options.natural ? (a, b) => naturalCompare(a, b, options.ignoreCase) : undefined;

/**
 * Translate one glob segment into RegExp source, without anchors.
 *
 * @param glob Segment pattern using `*`, `?` and `[...]`.
 * @returns Source matching a whole path segment.
 */
function segmentSource(glob: string): string {
  let out = '';
  for (let i = 0; i < glob.length; i++) {
    const c = glob[i] as string;
    if (c === '*') out += '[^/]*';
    else if (c === '?') out += '[^/]';
    else if (c === '[') {
      const end = glob.indexOf(']', i + 1);
      if (end === -1) {
        out += '\\[';
      } else {
        // `[!abc]` is the shell's negation; RegExp spells it `[^abc]`.
        const body = glob.slice(i + 1, end).replace(/^!/, '^');
        out += `[${body}]`;
        i = end;
      }
    } else out += c.replace(/[.+^${}()|[\]\\]/g, '\\$&');
  }
  return out;
}

/**
 * Translate a glob segment into an anchored RegExp.
 *
 * @param glob Basename pattern using `*`, `?` and `[...]`.
 * @param flags RegExp flags, `'i'` to ignore case.
 * @returns Matches a whole filename.
 */
export function globToRegExp(glob: string, flags = ''): RegExp {
  return new RegExp(`^${segmentSource(glob)}$`, flags);
}

/**
 * Translate a multi-segment glob into an anchored RegExp over a whole path.
 *
 * A `**` segment matches zero or more directories, and consumes the separator
 * that would otherwise follow it, so a `**` between `data` and a `*.md` tail
 * matches `data/a.md` as well as `data/deep/a.md`.
 *
 * @param pattern Path pattern, `/`-separated.
 * @param flags RegExp flags, `'i'` to ignore case.
 * @returns Matches a whole relative path.
 */
export function globToPathRegExp(pattern: string, flags = ''): RegExp {
  const segments = pattern.replace(/\\/g, '/').split('/');
  let out = '';
  for (let i = 0; i < segments.length; i++) {
    const segment = segments[i] as string;
    const last = i === segments.length - 1;
    if (segment === '**') {
      out += last ? '.*' : '(?:[^/]+/)*';
      continue;
    }
    out += segmentSource(segment);
    if (!last) out += '/';
  }
  return new RegExp(`^${out}$`, flags);
}

/**
 * @param excludes Raw `--exclude` globs.
 * @param flags RegExp flags, `'i'` to ignore case.
 * @returns Compiled once so a walk does not rebuild them per entry.
 */
export function compileExcludes(excludes: string[], flags = ''): Excluder {
  const segment: RegExp[] = [];
  const full: RegExp[] = [];
  for (const raw of excludes) {
    // A caller may hand a backslash-separated glob (a Windows-shaped path
    // pasted into `--exclude`), and every path this walk produces is
    // forward-slashed — so without normalizing here, `sub\node_modules` would
    // never contain a `/` and would compile as a single literal segment that
    // matches nothing.
    const normalized = raw.replace(/\\/g, '/');
    // `node_modules/` is the natural way to write a directory, but as a path
    // glob it compiles to `^node_modules/$`, which no file path can match — the
    // exclude would prune nothing and the walk would descend anyway. A trailing
    // slash means the same directory, so drop it and match the segment.
    const glob = normalized.replace(/\/+$/, '');
    if (glob.includes('/')) {
      full.push(globToPathRegExp(glob, flags));
      // `node_modules/**` means everything under it, so the directory itself is
      // excluded too. Without this the walk still descends and reads the whole
      // subtree before filtering every file out of the result — correct, but it
      // reads `.git` object by object.
      const dirOnly = glob.replace(/\/\*\*$/, '');
      if (dirOnly !== glob) full.push(globToPathRegExp(dirOnly, flags));
    } else segment.push(globToRegExp(glob, flags));
  }
  return { segment, full };
}

/**
 * @param rel Relative path, `/`-separated.
 * @param excluder Compiled excludes.
 * @returns Whether any exclude glob claims this path.
 */
export function excluded(rel: string, excluder: Excluder): boolean {
  const parts = rel.split('/');
  if (excluder.segment.some((re) => parts.some((seg) => re.test(seg)))) return true;
  if (excluder.full.length === 0) return false;
  // A path glob is tested against every ANCESTOR as well as the path itself, so
  // `build/*` excludes `build/sub/deep.md` by way of the directory `build/sub`.
  // Testing only the full path would make the answer depend on whether the
  // pattern happened to need a tree walk: the walk prunes excluded directories,
  // while a single-readdir pattern would see the file alone and keep it.
  for (let i = parts.length; i > 0; i--) {
    const prefix = parts.slice(0, i).join('/');
    if (excluder.full.some((re) => re.test(prefix))) return true;
  }
  return false;
}

/**
 * Whether a directory entry counts as a file to list.
 *
 * A dirent's own type does not resolve symlinks, so a symlink to a `.md` would
 * not answer `isFile()` — but `ls *.md` and `find -name` both list one, and
 * dropping it would be a silent behaviour change from the shell being replaced.
 * A symlink is therefore followed to decide, which also settles a broken one
 * (stat throws) as not a file, matching `test -f`.
 *
 * @param rel Path to the entry, `/`-separated.
 * @param entry Its directory entry.
 * @returns Whether to list it.
 */
function isListableFile(rel: string, entry: fs.Dirent): boolean {
  if (entry.isFile()) return true;
  if (!entry.isSymbolicLink()) return false;
  try {
    return fs.statSync(rel).isFile();
  } catch {
    return false;
  }
}

/**
 * Collect every regular file under `root`, pruning excluded directories.
 *
 * @param root Directory to read, `''` meaning the working directory.
 * @param excluder Compiled excludes.
 * @param out Accumulator, appended in readdir order.
 */
function walk(root: string, excluder: Excluder, out: string[]): void {
  let entries: fs.Dirent[];
  try {
    entries = fs.readdirSync(root === '' ? '.' : root, { withFileTypes: true });
  } catch {
    return;
  }
  for (const entry of entries) {
    const rel = root === '' ? entry.name : `${root}/${entry.name}`;
    if (excluded(rel, excluder)) continue;
    // A symlinked directory reports isDirectory() false, so the walk never
    // descends one and cannot cycle — the same choice `find` makes without -L.
    if (entry.isDirectory()) walk(rel, excluder, out);
    else if (isListableFile(rel, entry)) out.push(rel);
  }
}

/**
 * Resolve one pattern against the working directory.
 *
 * @param pattern Project-relative path, globbable in any segment.
 * @param options Exclusions and case sensitivity.
 * @param cache Walk results keyed by root, shared across patterns of one call.
 * @returns Matching file paths, `/`-separated, sorted.
 */
export function listOne(
  pattern: string,
  options: ListOptions = {},
  cache?: Map<string, string[]>,
): string[] {
  const flags = options.ignoreCase ? 'i' : '';
  const excluder = compileExcludes(options.exclude ?? [], flags);
  const normalized = pattern.replace(/\\/g, '/');
  const segments = normalized.split('/');

  // A `**` needs the walk wherever it sits, including as the final segment —
  // `docs/**` means everything underneath. Only the last segment being an
  // ordinary glob keeps the single-readdir path, since `*` never crosses a `/`.
  const needsWalk = segments.some((s) => s === '**') || segments.slice(0, -1).some(isGlob);

  if (!needsWalk) {
    const slash = normalized.lastIndexOf('/');
    const dir = slash === -1 ? '.' : normalized.slice(0, slash);
    const base = normalized.slice(slash + 1);
    const prefix = slash === -1 ? '' : `${dir}/`;

    if (!isGlob(base)) {
      // A literal path contributes itself only when it is there AND is a file.
      let stat: fs.Stats;
      try {
        stat = fs.statSync(path.join(dir, base));
      } catch {
        return [];
      }
      const rel = prefix + base;
      return stat.isFile() && !excluded(rel, excluder) ? [rel] : [];
    }

    let entries: fs.Dirent[];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return [];
    }
    const re = globToRegExp(base, flags);
    return entries
      .filter((e) => re.test(e.name) && isListableFile(prefix + e.name, e))
      .map((e) => prefix + e.name)
      .filter((rel) => !excluded(rel, excluder))
      .sort(sorter(options));
  }

  // A globbed directory segment needs a walk. Start it at the deepest literal
  // prefix so `data/**/*.md` never reads anything outside `data/`.
  const globIndex = segments.findIndex(isGlob);
  const root = segments.slice(0, globIndex).join('/');
  // One walk per root serves every pattern rooted there — `**/a` plus `**/b`
  // reads the tree once, not twice. A cached walk was pruned with the excludes
  // in force when it ran, so those are part of the key: a caller reusing a cache
  // across two different exclude sets would otherwise silently get the first
  // set's pruning back.
  // JSON, not a delimiter-join: it cannot collide, and it keeps the key
  // readable — a separator picked to be glob-proof ends up invisible in the
  // source, which is its own hazard.
  const key = JSON.stringify([flags, options.exclude ?? [], root]);
  let found = cache?.get(key);
  if (found === undefined) {
    found = [];
    walk(root, excluder, found);
    cache?.set(key, found);
  }
  const re = globToPathRegExp(normalized, flags);
  return found.filter((rel) => re.test(rel)).sort(sorter(options));
}

/**
 * Resolve each pattern separately, dropping any match an earlier pattern claimed.
 *
 * @param patterns Patterns in the order given on the command line.
 * @param options Exclusions and case sensitivity.
 * @returns One result array per pattern, parallel to `patterns`.
 */
export function listGrouped(patterns: string[], options: ListOptions = {}): string[][] {
  const seen = new Set<string>();
  const cache = new Map<string, string[]>();
  return patterns.map((p) => {
    const fresh = listOne(p, options, cache).filter((m) => !seen.has(m));
    for (const m of fresh) seen.add(m);
    return fresh;
  });
}

/**
 * @param patterns Patterns in the order given on the command line.
 * @param options Exclusions and case sensitivity.
 * @returns Deduplicated matches across all patterns.
 */
export function list(patterns: string[], options: ListOptions = {}): string[] {
  return listGrouped(patterns, options).flat();
}

/**
 * Take up to `limit` matches, drawn round-robin across the patterns.
 *
 * A flat `slice(0, limit)` would spend the whole budget on the first pattern:
 * the landscape scan passes nine keyword patterns, and one matching 50+ files
 * would leave `*runbook*`, `*sop*` and the rest with nothing — whole categories
 * silently invisible. The `find … \( -iname A -o -iname B … \) | head -N` this
 * replaces evaluated every alternative per file, so its cap was spread too.
 *
 * @param groups Per-pattern matches, as returned by {@link listGrouped}.
 * @param limit Maximum number of matches to return.
 * @returns At most `limit` paths, grouped by pattern in the order given.
 */
export function capRoundRobin(groups: string[][], limit: number): string[] {
  const taken: string[][] = groups.map(() => []);
  let total = 0;
  const deepest = Math.max(0, ...groups.map((g) => g.length));
  for (let depth = 0; depth < deepest && total < limit; depth++) {
    for (let g = 0; g < groups.length && total < limit; g++) {
      const item = groups[g]?.[depth];
      if (item === undefined) continue;
      (taken[g] as string[]).push(item);
      total++;
    }
  }
  return taken.flat();
}

/**
 * Split argv into flags and patterns.
 *
 * @param argv Arguments after the script path.
 * @returns Parsed options, or null when the arguments do not form a valid call.
 */
export function parseArgs(
  argv: string[],
): { count: boolean; limit: number | null; patterns: string[]; options: ListOptions } | null {
  let count = false;
  let ignoreCase = false;
  let natural = false;
  let limit: number | null = null;
  const exclude: string[] = [];
  const patterns: string[] = [];

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i] as string;
    if (arg === '--count') count = true;
    else if (arg === '--ignore-case') ignoreCase = true;
    else if (arg === '--natural') natural = true;
    else if (arg === '--exclude') {
      const value = argv[++i];
      // A flag-shaped value means the glob was left out. Taken literally,
      // `--exclude --count "*.md"` excludes a file named `--count` and drops the
      // count, printing a listing instead — a wrong answer that exits 0. No
      // exclusion glob starts with `--`.
      if (value === undefined || value.startsWith('--')) return null;
      exclude.push(value);
    } else if (arg === '--limit') {
      const value = argv[++i];
      // At least 1: `--limit 0` would print nothing and exit 0, which reads as
      // "no files matched" rather than "you asked for none".
      if (value === undefined || !/^[1-9]\d*$/.test(value)) return null;
      limit = Number(value);
    } else if (arg.startsWith('--')) {
      // An unrecognised option is a usage error, never a pattern. Swallowed as
      // one, `--excludes node_modules` silently prunes nothing and reports a
      // whole dependency tree as the answer, and `--limit=2` silently caps
      // nothing — a wrong result that exits 0.
      return null;
    } else patterns.push(arg);
  }

  if (patterns.length === 0) return null;
  // Rejected rather than merely documented: the cap keeps the HEAD of each group,
  // so together these two return the OLDEST entries — the exact opposite of what
  // --natural is asked for — with nothing in the output to show it.
  if (natural && limit !== null) return null;
  return { count, limit, patterns, options: { exclude, ignoreCase, natural } };
}

function main(argv: string[]): void {
  const parsed = parseArgs(argv);
  if (parsed === null) {
    process.stderr.write(USAGE);
    process.exit(EXIT.USAGE);
  }
  const groups = listGrouped(parsed.patterns, parsed.options);
  const matches = groups.flat();
  const shown = parsed.limit === null ? matches : capRoundRobin(groups, parsed.limit);
  process.stdout.write(
    parsed.count ? `${matches.length}\n` : shown.map((m) => `${m}\n`).join(''),
  );
}

if (import.meta.url === pathToFileURL(process.argv[1] as string).href) main(process.argv.slice(2));
