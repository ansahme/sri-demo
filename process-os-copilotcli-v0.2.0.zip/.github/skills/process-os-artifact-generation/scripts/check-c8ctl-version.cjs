#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';
// Verify the installed c8ctl meets the ProcessOS minimum version.
//
// Runs `c8ctl --version` itself rather than depending on a caller to pipe it in.
// A `c8ctl --version 2>&1 | node …` shell pipe (the previous shape) merges c8ctl's
// stderr into the piped stream — and Windows PowerShell 5.1 turns ANY
// native-command stderr output into a terminating NativeCommandError, so a
// healthy version check could surface as exit 255 before this script ever ran.
// Capturing the two streams separately here removes that trap. It also fixes the
// sibling defect of spawning `c8ctl` as a bare, shell-less command: on Windows it
// installs only as `c8ctl.cmd`, which `runShellCli` — not a raw shell-less
// `spawnSync` of `c8ctl` — is what can actually exec.
// See shared/references/c8ctl.md → Stream contract.
//
// The two streams stay separate, but the version is read from stdout *or*
// stderr: when c8ctl's persisted output preference is JSON (`c8ctl output json`),
// c8ctl --version prints the version to stderr and leaves stdout empty, even
// though it still exits 0. Keying off stdout alone therefore reports a false
// alone therefore reported a false "Cannot parse c8ctl version" for an installed,
// compatible c8ctl. stdout is preferred; stderr is only consulted when stdout
// carries no version.
//
// MIN_C8CTL_VERSION below is the single source of truth for the floor — bump it here
// when the minimum changes; callers only pass their own name for the error message.
//
// Comparison is prerelease-aware: a build like 3.3.0-alpha.5 is always lower than
// its release counterpart 3.3.0, even though both share the same major.minor.patch.
//
// Usage:
//   node check-c8ctl-version.cjs <callerName>
//
// Exit codes: 0 ok, 1 too old, unparseable, or c8ctl could not be run at all.

const { runShellCli } = require('./resolve-node-cli.cjs');

const MIN_C8CTL_VERSION = '3.3.0';

function parseVersion(raw) {
  const m = String(raw).trim().match(/(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.]+))?/);
  if (!m) return null;
  const [, major, minor, patch, prerelease] = m;
  return { major: +major, minor: +minor, patch: +patch, prerelease: prerelease || null };
}

function compareVersions(a, b) {
  for (const key of ['major', 'minor', 'patch']) {
    if (a[key] !== b[key]) return a[key] - b[key];
  }
  if (a.prerelease === b.prerelease) return 0;
  if (a.prerelease === null) return 1;
  if (b.prerelease === null) return -1;
  return a.prerelease < b.prerelease ? -1 : 1;
}

/**
 * Run `c8ctl --version` and decide whether it meets MIN_C8CTL_VERSION.
 *
 * A call that never launched, exited non-zero, or printed no parseable version on
 * either stream is reported as its own failure message rather than merged with
 * "too old" — the caller only branches on ok/not-ok, but a human reading the
 * message should not have to guess whether c8ctl is missing or merely out of date.
 *
 * @param {string} callerName Name used in the "too old" message.
 * @param {Object} [deps]
 * @param {function} [deps.run] runShellCli-shaped runner; injected by tests.
 * @returns {{ok: true} | {ok: false, message: string}}
 */
function checkVersion(callerName, deps = {}) {
  const run = deps.run || runShellCli;
  const r = run('c8ctl', ['--version'], { stdio: ['ignore', 'pipe', 'pipe'], encoding: 'utf8' });

  if (!r.launched) {
    return {
      ok: false,
      message: `c8ctl could not be run — is it installed and on PATH? (${(r.error && r.error.message) || 'unknown reason'})`,
    };
  }
  if (r.status !== 0) {
    return {
      ok: false,
      message: `c8ctl --version exited ${r.status}: ${String(r.stderr || '').trim() || '(no output)'}`,
    };
  }

  const min = parseVersion(MIN_C8CTL_VERSION);
  const stdoutRaw = String(r.stdout || '').trim();
  const stderrRaw = String(r.stderr || '').trim();
  // Prefer stdout (text mode); fall back to stderr, where JSON mode emits the
  // version, only when stdout carries none.
  let rawOutput = stdoutRaw;
  let installed = parseVersion(stdoutRaw);
  if (!installed) {
    installed = parseVersion(stderrRaw);
    rawOutput = stderrRaw;
  }
  if (!installed) {
    return { ok: false, message: `Cannot parse c8ctl version: ${stdoutRaw || stderrRaw}` };
  }
  if (compareVersions(installed, min) < 0) {
    return {
      ok: false,
      message: `c8ctl >= ${MIN_C8CTL_VERSION} is required for ${callerName} (found ${rawOutput}).`,
    };
  }
  return { ok: true };
}

module.exports = { MIN_C8CTL_VERSION, parseVersion, compareVersions, checkVersion };

if (require.main === module) {
  const [callerName] = process.argv.slice(2);
  if (!callerName) {
    process.stderr.write('Usage: node check-c8ctl-version.cjs <callerName>\n');
    process.exit(1);
  }
  const result = checkVersion(callerName);
  if (!result.ok) {
    process.stderr.write(result.message + '\n');
    process.exit(1);
  }
}
