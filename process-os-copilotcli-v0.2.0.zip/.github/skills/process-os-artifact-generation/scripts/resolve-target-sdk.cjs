#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Resolve the artifact-generation target SDK (the blueprint selector).
//
// The value is a member of the closed enum of OFFICIAL Camunda client SDKs.
// `java-spring-boot`, `typescript` and `python` are implemented; `java`/`csharp`
// are reserved (accepted here, rejected as "not yet supported" by scaffold-workers.cjs).
// What each one can actually do is the capability table's answer, not this
// comment's — see scripts/sdk-capabilities.cjs. Any value outside the enum is
// rejected here.
//
// Resolution precedence (highest first):
//   1. --target-sdk <sdk>                                   explicit override
//   2. skillInput["process-os-artifact-generation"].targetSdk
//        from .camunda/job-input.json                       governance run
//   3. target-sdk in run.config.yaml                        standalone / file config
//   4. java-spring-boot                                     default
//
// A per-field null (a FEEL object literal serialises an unset source as null)
// is treated as "not provided" and falls through to the next tier.
//
// Usage: node resolve-target-sdk.cjs [--target-sdk <sdk>] [--job-input <path>] [--config <path>]
//   --config defaults to run.config.yaml.
// stdout: the resolved sdk. Exit 0 on success; 2 on an out-of-enum value or missing
// ProcessOS Node deps.

'use strict';

const fs = require('fs');
const path = require('path');
// Source imports of the shared readers; the bundler rewrites these to local sibling
// requires when it copies the peers into this skill's scripts/ dir.
const yaml = require(path.join(__dirname, 'yaml.cjs'));
const { resolveKey } = require(path.join(__dirname, 'read-run-config.cjs'));
const { RUN_DEFAULTS } = require(path.join(__dirname, 'run-config-schema.cjs'));

const OFFICIAL_SDKS = ['java-spring-boot', 'typescript', 'java', 'python', 'csharp'];
const SKILL_NAME = 'process-os-artifact-generation';
// Taken from the schema, not restated: the generator writes that value into new
// configs, so a second literal here could drift from the files this module reads.
const DEFAULT_SDK = RUN_DEFAULTS['target-sdk'];

const argv = process.argv.slice(2);
let explicit = null;
let jobInputPath = '.camunda/job-input.json';
let configPath = 'run.config.yaml';
for (let i = 0; i < argv.length; i++) {
  if (argv[i] === '--target-sdk') { explicit = argv[++i]; continue; }
  if (argv[i] === '--job-input') { jobInputPath = argv[++i]; continue; }
  if (argv[i] === '--config') { configPath = argv[++i]; continue; }
}

function fromJobInput(p) {
  let doc;
  try { doc = JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return null; }
  const si = doc && typeof doc === 'object' ? doc.skillInput : undefined;
  const cfg = si && typeof si === 'object' ? si[SKILL_NAME] : undefined;
  const v = cfg && typeof cfg === 'object' ? cfg.targetSdk : undefined;
  return v == null ? null : String(v).trim();
}

// resolveKey, not resolveWithDefault: this tier must report "the file did not say", so
// the caller's own DEFAULT_SDK fallback stays the single place the default is applied.
//
// A missing/unreadable file is "not configured" and falls through. Missing ProcessOS
// Node deps are NOT: the project is broken, not unconfigured, so we cannot tell whether
// run.config.yaml sets `typescript`. Falling back would scaffold the wrong SDK silently.
function fromConfig(p) {
  let text;
  try {
    text = fs.readFileSync(p, 'utf8');
  } catch {
    return null;
  }
  let obj;
  try {
    obj = yaml.parse(text) || {};
  } catch (e) {
    if (e.code === 'DEPS_MISSING') {
      process.stderr.write(e.message + '\n');
      process.exit(2);
    }
    return null;
  }
  const r = resolveKey(obj, 'target-sdk');
  return r.status === 'scalar' ? r.value.trim() : null;
}

const resolved =
  (explicit && explicit.trim()) ||
  fromJobInput(jobInputPath) ||
  fromConfig(configPath) ||
  DEFAULT_SDK;

if (!OFFICIAL_SDKS.includes(resolved)) {
  process.stderr.write(
    `resolve-target-sdk: '${resolved}' is not an official Camunda client SDK ` +
      `(one of: ${OFFICIAL_SDKS.join(', ')})\n`,
  );
  process.exit(2);
}

process.stdout.write(resolved);

module.exports = { OFFICIAL_SDKS, DEFAULT_SDK, fromJobInput, fromConfig };
