#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

/**
 * read-run-config.cjs — generic single-key reader over run.config.yaml.
 *
 * Usage: node read-run-config.cjs <key> | --list
 *   <key> is a top-level key or a dotted path (e.g. processDiscoveryGate.questions).
 *   --list prints every declared key with its type, effective value and source. The file
 *   itself records only decisions, so it is not an inventory of what can be set.
 *   Scalars print their value; list keys print one item per line.
 *
 * A key the file does not carry falls back to the schema default, so a project whose
 * run.config.yaml predates a newer ProcessOS knob still resolves that knob. Only a key
 * with no declared default (width, depth, bpmn-mode, source) reports absent.
 *
 * A missing or unparseable run.config.yaml stays a hard error rather than "everything is
 * default" — that distinction is what stops a broken project from looking configured.
 *
 * Exit codes:
 *   0  present  — value on stdout (from the file, or the schema default)
 *   1  absent   — nothing on stdout; no value in the file AND no schema default
 *   2  hard error — run.config.yaml missing/unparseable, or deps missing (stderr)
 *
 * Runs from the project WD; reads ./run.config.yaml.
 */

const fs = require('node:fs');
const path = require('node:path');
// Sibling imports spelled so the bundler's dependency-closure grep sees a literal
// <shared dir>/<file> path. This file already lives in that directory, so the requires
// round-trip via '../..' purely to put that literal in the text: it resolves correctly
// in source, and once copied as a peer into a consuming skill's scripts/ dir the
// bundler strips the up-nav to path.join(__dirname, 'yaml.cjs').
//
// Write that prefix ONLY inside these require() calls, where a real filename follows.
// The rewriter keys on <dir>/<name>.<ext>, so a bare prose mention of the directory
// survives into the bundled copy and trips bundler-compat.test.cjs.
const yaml = require(path.join(__dirname, 'yaml.cjs'));
const { RUN_DEFAULTS, RUN_SCHEMA, ALL_KEYS, canonicalizeKeys } = require(
  path.join(__dirname, 'run-config-schema.cjs'),
);

const CONFIG_FILE = 'run.config.yaml';

/**
 * Render every declared key with its type, effective value, and where that value came
 * from. This is how a reader discovers what can be set: the file itself carries only
 * decisions, so it is not an inventory of the available knobs and must not be read as one.
 *
 * @param {Record<string, unknown>} obj Parsed run.config.yaml, or {}.
 * @returns {string}
 */
function listKeys(obj) {
  const rows = ALL_KEYS.map((key) => {
    const inFile = resolveKey(obj, key);
    const entry = RUN_SCHEMA[key];
    const hasDefault = Object.hasOwn(entry, 'default');
    const render = (v) => (Array.isArray(v) || (v && typeof v === 'object') ? JSON.stringify(v) : String(v));
    let value;
    let source;
    if (inFile.status !== 'absent') {
      if (inFile.status === 'list') value = JSON.stringify(inFile.items);
      else if (inFile.status === 'map') value = render(inFile.value);
      else value = inFile.value;
      source = 'set';
    } else if (hasDefault) {
      value = render(entry.default);
      source = 'default';
    } else {
      value = '—';
      source = 'unset';
    }
    return { key, type: entry.type, value, source };
  });
  const w = (f, min) => Math.max(min, ...rows.map((r) => String(r[f]).length));
  const kw = w('key', 3);
  const tw = w('type', 4);
  const vw = w('value', 5);
  const lines = [
    `${'KEY'.padEnd(kw)}  ${'TYPE'.padEnd(tw)}  ${'VALUE'.padEnd(vw)}  SOURCE`,
    `${'-'.repeat(kw)}  ${'-'.repeat(tw)}  ${'-'.repeat(vw)}  ------`,
  ];
  for (const r of rows) {
    lines.push(`${r.key.padEnd(kw)}  ${r.type.padEnd(tw)}  ${String(r.value).padEnd(vw)}  ${r.source}`);
  }
  lines.push('');
  lines.push('set   value recorded in run.config.yaml');
  lines.push('default   not recorded; this is what a read resolves to');
  lines.push('unset   no value and no default — a consumer asks or hard-errors');
  lines.push('');
  lines.push('Change one: node "apply-run-config.cjs" --set <key>=<value>');
  return lines.join('\n');
}

function resolveKey(obj, key) {
  const parts = key.split('.');
  let cur = obj;
  for (const p of parts) {
    // Object.hasOwn, not `p in cur`: `in` matches inherited members, so a key spelled
    // `constructor` or `toString` would resolve against Object.prototype and report a
    // scalar the file never carried.
    if (cur == null || typeof cur !== 'object' || !Object.hasOwn(cur, p)) {
      return { status: 'absent' };
    }
    cur = cur[p];
  }
  if (cur == null) return { status: 'absent' };
  if (Array.isArray(cur)) return { status: 'list', items: cur.map((x) => String(x)) };
  // A map gets its own status rather than being folded into 'absent'. The single-key path
  // still cannot render one — a caller wanting a gate reads one of its leaves — but a
  // configured block IS set, and reporting it as absent makes --list render the schema
  // default as though the file had decided nothing.
  if (typeof cur === 'object') return { status: 'map', value: cur };
  return { status: 'scalar', value: String(cur) };
}

// The effective value: what the file says, else what the schema declares. resolveKey
// stays deliberately unaware of defaults so a caller can still tell "explicitly set"
// from "inherited" — the same dotted-path walker is simply run against the defaults.
function resolveWithDefault(obj, key) {
  const found = resolveKey(obj, key);
  if (found.status !== 'absent') return found;
  const fallback = resolveKey(RUN_DEFAULTS, key);
  return fallback.status === 'absent' ? fallback : { ...fallback, source: 'default' };
}

module.exports = { listKeys, resolveKey, resolveWithDefault };

if (require.main === module) {
  const key = process.argv[2];
  if (!key) {
    process.stderr.write('usage: read-run-config.cjs <key> | --list\n');
    process.exit(2);
  }
  if (!fs.existsSync(CONFIG_FILE)) {
    process.stderr.write(`${CONFIG_FILE} not found in ${process.cwd()}\n`);
    process.exit(2);
  }
  let obj;
  try {
    // Rewrite legacy key spellings before any lookup: a project that recorded a key under
    // its earlier spelling must resolve to that value, not to the schema default for the
    // new name.
    obj = canonicalizeKeys(yaml.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) || {});
  } catch (e) {
    // yaml.cjs throws DEPS_MISSING from inside parse(); surface it as-is rather than
    // misattributing it to a parse failure of a file we never got to read.
    if (e.code === 'DEPS_MISSING') {
      process.stderr.write(e.message + '\n');
      process.exit(2);
    }
    process.stderr.write(`Cannot parse ${CONFIG_FILE}: ${e.message}\n`);
    process.exit(2);
  }
  if (key === '--list') {
    process.stdout.write(listKeys(obj) + '\n');
    process.exit(0);
  }
  const r = resolveWithDefault(obj, key);
  // A map has no scalar rendering, so asking for a block key by name is unanswerable here
  // even when the file carries it; the answerable question is one of its leaves.
  if (r.status === 'absent' || r.status === 'map') process.exit(1);
  if (r.status === 'list') {
    for (const item of r.items) process.stdout.write(item + '\n');
    process.exit(0);
  }
  process.stdout.write(r.value + '\n');
  process.exit(0);
}
