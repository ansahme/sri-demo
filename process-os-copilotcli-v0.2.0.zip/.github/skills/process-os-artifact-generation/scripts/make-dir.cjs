#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Create each given directory, parents included, portably.
//
// Replaces the `mkdir -p X` idiom that skills used to prepare output trees.
// `-p` is a rejected flag on PowerShell 5.1's `mkdir`, so a native Windows agent
// had to improvise a translation every time.
//
// Usage:
//   node "make-dir.cjs" <path>...
//
// Prints one line per path, in the order given:
//   CREATED  artifacts/.analyze-phase
//   PRESENT  artifacts
//
// Relative paths resolve against the current working directory, which is the
// ProcessOS project root. Idempotent, like `mkdir -p`: an existing directory is
// reported PRESENT and left untouched, and exits 0 either way. Exits 2 on a
// usage error. An unexpected filesystem error (a plain file already occupies
// the path, permissions, no space) is left to throw — the caller sees a
// non-zero exit and the stack, rather than a silent no-op.

const fs = require('fs');

/**
 * Create one directory and any missing parent.
 *
 * @param {string} p Directory to create, absolute or project-relative.
 * @returns {'CREATED'|'PRESENT'} Whether this call is what brought it into being.
 */
function makeDir(p) {
  // mkdirSync returns the first path it created, or undefined when there was
  // nothing left to create — which is exactly the distinction we report.
  return fs.mkdirSync(p, { recursive: true }) === undefined ? 'PRESENT' : 'CREATED';
}

/**
 * Format one outcome line. Padded so a multi-path report stays column-aligned.
 *
 * @param {string} p Path as the caller wrote it.
 * @param {'CREATED'|'PRESENT'} outcome Result of the create.
 * @returns {string} Line without its trailing newline.
 */
function formatLine(p, outcome) {
  return `${outcome.padEnd(8)} ${p}`;
}

module.exports = { makeDir, formatLine };

if (require.main === module) {
  const paths = process.argv.slice(2);
  if (paths.length === 0) {
    process.stderr.write('usage: make-dir.cjs <path>...\n');
    process.exit(2);
  }
  for (const p of paths) {
    process.stdout.write(`${formatLine(p, makeDir(p))}\n`);
  }
}
