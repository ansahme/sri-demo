#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// The pure emitter for the Python worker layer: manifest data in, Python source
// text out. It touches no filesystem and reads no process state, so every rule
// below is exercised by a unit test rather than by a generated project.
//
// generate-workers-python.cjs owns the filesystem, the CLI and the exit codes.
// Nothing else in the skill imports this module's internals.
//
// Field names and the manifest type map come from python-naming.cjs, shared with
// the scaffolder, because both modules write src/models/process_variables.py.

const path = require('path');
const { toPyField, mapPyType } = require('./python-naming.cjs');

// Camunda's own name for the job stays untouched. Everything Python-side derives
// from it through the two stems below.
//
// The job-type conversion splits on non-alphanumeric runs only. It does not split
// a camel-case transition and it does not repair a digit-leading result, which is
// deliberate: `references/analyze-phase.md` derives a job type in kebab-case, so
// an out-of-shape job type means a hand-edited manifest, and a silent repair
// would invent a name the process never declares. The wrapper rejects such a
// manifest instead.
const UNKNOWN_TYPE = 'object';

// The blueprint's ruff config sets line-length = 120. E501 is inside the `E`
// rule set the blueprint selects, so an emitted line over this fails the gate on
// the generator's own output.
const MAX_LINE = 120;

/**
 * The lowercase snake_case stem of a job type, used for file names, the worker
 * factory, and the application field.
 *
 * @param {unknown} jobType
 * @returns {string}
 */
function snakeStem(jobType) {
  return String(jobType == null ? '' : jobType)
    .split(/[^A-Za-z0-9]+/)
    .filter(Boolean)
    .map((part) => part.toLowerCase())
    .join('_');
}

/**
 * The PascalCase stem of a job type, used for class and model names.
 *
 * Matches `pascal()` in analyze-join.mts, which is where the manifest's own
 * `className` comes from, so the two agree by construction.
 *
 * @param {unknown} jobType
 * @returns {string}
 */
function pascalStem(jobType) {
  return String(jobType == null ? '' : jobType)
    .split(/[^A-Za-z0-9]+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join('');
}

/**
 * Is `id` a legal Python identifier?
 *
 * One check covers the two ways the stem conversion produces an illegal one: a
 * job type with no alphanumeric content yields the empty string, and a
 * digit-leading job type such as `2fa-check` yields a digit-leading stem.
 *
 * @param {string} id
 * @returns {boolean}
 */
function isLegalStem(id) {
  return typeof id === 'string' && /^[A-Za-z_][A-Za-z0-9_]*$/.test(id);
}

/**
 * Merge one declared variable into a field map, widening a type disagreement to
 * `object` rather than choosing one side.
 *
 * Two manifest entries for one job type do not always agree on a variable's
 * type. Picking one would make the generated worker reject every job dispatched
 * from the entry that declared the other.
 *
 * @param {Map<string, object>} map
 * @param {string} sourceName the manifest variable name
 * @param {unknown} declaredType
 * @returns {object} the field record
 */
function mergeDeclaredType(map, sourceName, declaredType) {
  const pyType = mapPyType(declaredType);
  const field = toPyField(sourceName);
  const existing = map.get(sourceName);
  if (!existing) {
    const record = { source: sourceName, field, pyType, count: 0 };
    map.set(sourceName, record);
    return record;
  }
  if (existing.pyType !== pyType) existing.pyType = UNKNOWN_TYPE;
  return existing;
}

/**
 * Group manifest worker entries by unique job type.
 *
 * Camunda dispatches work by job type, so exactly one worker implementation may
 * subscribe to one job type. Several implementations is not implementable:
 * whichever polls first wins, non-deterministically. The manifest legitimately
 * carries several entries for one job type, because the same service task recurs
 * across process phases.
 *
 * An input is required only when every entry in the group declares it. A name
 * repeated inside one entry counts once, so `required` keeps meaning "declared by
 * every entry". An input present in some entries but not all would otherwise make
 * the worker's own validation reject every job dispatched from the entry that
 * omits it, which is a permanent failure rather than a gap that closes when
 * someone implements the service.
 *
 * Every output is optional, which is what lets the generated stub return an empty
 * output model.
 *
 * Groups come back in manifest first-appearance order, and fields in
 * first-appearance order within a group, so a rerun over an unchanged manifest
 * emits byte-identical text.
 *
 * @param {object[]} [workers] manifest.workers
 * @returns {object[]}
 */
function groupWorkers(workers) {
  const byJobType = new Map();
  for (const entry of workers || []) {
    const jobType = entry && entry.jobType;
    if (!jobType) continue;
    if (!byJobType.has(jobType)) {
      byJobType.set(jobType, {
        jobType,
        classNames: new Set(),
        snake: snakeStem(jobType),
        pascal: pascalStem(jobType),
        entryCount: 0,
        inputs: new Map(),
        outputs: new Map(),
        errorCodes: new Set(),
      });
    }
    const group = byJobType.get(jobType);
    group.entryCount += 1;
    if (entry.className) group.classNames.add(String(entry.className));

    const seenInEntry = new Set();
    for (const variable of entry.inputVariables || []) {
      if (!variable || !variable.name) continue;
      const field = mergeDeclaredType(group.inputs, String(variable.name), variable.type);
      if (seenInEntry.has(variable.name)) continue;
      seenInEntry.add(variable.name);
      field.count += 1;
    }
    for (const variable of entry.outputVariables || []) {
      if (!variable || !variable.name) continue;
      mergeDeclaredType(group.outputs, String(variable.name), variable.type);
    }
    for (const declared of entry.errors || []) {
      if (declared && declared.code) group.errorCodes.add(String(declared.code));
    }
  }

  return [...byJobType.values()].map((group) => ({
    jobType: group.jobType,
    // The group's own className when every entry that declares one agrees, and a
    // derived name when none does. validateGroups rejects a disagreement.
    className: group.classNames.size === 1
      ? [...group.classNames][0]
      : `${group.pascal.replace(/Worker$/, '')}Worker`,
    classNames: [...group.classNames],
    snake: group.snake,
    pascal: group.pascal,
    inputs: [...group.inputs.values()].map(({ source, field, pyType, count }) => ({
      source,
      field,
      pyType,
      required: count === group.entryCount,
    })),
    outputs: [...group.outputs.values()].map(({ source, field, pyType }) => ({ source, field, pyType })),
    errorCodes: [...group.errorCodes].sort(),
  }));
}

/**
 * Collect every reason to reject the manifest before the wrapper writes anything.
 *
 * Each list names the offending job type or variable name, so one run reports
 * every problem rather than the first one.
 *
 * @param {object[]} groups
 * @returns {{illegalStems: string[], stemCollisions: string[][], classNameConflicts: object[], variableProblems: object[]}}
 */
function validateGroups(groups) {
  const illegalStems = groups
    .filter((g) => !isLegalStem(g.snake) || !isLegalStem(g.pascal))
    .map((g) => g.jobType);

  // Both stems collide independently: pascalStem preserves inner case while
  // snakeStem lowercases, so `a-fA` and `a-Fa` differ as class names and agree as
  // file names. One worker emitted for two job types leaves the second job type
  // permanently without a subscriber, which surfaces as a stalled process
  // instance one step removed from its cause.
  const stemCollisions = [];
  for (const key of ['snake', 'pascal']) {
    const seen = new Map();
    for (const group of groups) {
      if (!seen.has(group[key])) seen.set(group[key], []);
      seen.get(group[key]).push(group.jobType);
    }
    for (const jobTypes of seen.values()) {
      if (jobTypes.length > 1 && !stemCollisions.some((c) => c.join(' ') === jobTypes.join(' '))) {
        stemCollisions.push(jobTypes);
      }
    }
  }

  const classNameConflicts = groups
    .filter((g) => g.classNames.length > 1)
    .map((g) => ({ jobType: g.jobType, classNames: [...g.classNames].sort() }));

  // A variable name that yields no Python field, and two distinct source names
  // that yield one field in the same model. One Python attribute cannot preserve
  // two source aliases, so the generator rejects the manifest rather than pick a
  // name the process never declares.
  const variableProblems = [];
  const checkModel = (model, fields) => {
    const byField = new Map();
    for (const f of fields) {
      if (f.field === null) {
        variableProblems.push({ model, reason: 'no-identifier', sources: [f.source] });
        continue;
      }
      if (!byField.has(f.field)) byField.set(f.field, []);
      byField.get(f.field).push(f.source);
    }
    for (const [field, sources] of byField) {
      if (sources.length > 1) variableProblems.push({ model, reason: 'collision', field, sources });
    }
  };
  const unionFields = [];
  for (const group of groups) {
    checkModel(`${group.pascal}Input`, group.inputs);
    checkModel(`${group.pascal}Output`, group.outputs);
    unionFields.push(...group.inputs, ...group.outputs);
  }
  // ProcessVariables spans every group, so a name unique inside each group can
  // still collide across groups. Deduplicate by source name first: the same
  // variable declared by two job types is one field, not a collision.
  const bySource = new Map();
  for (const f of unionFields) if (!bySource.has(f.source)) bySource.set(f.source, f);
  checkModel('ProcessVariables', [...bySource.values()]);

  return { illegalStems, stemCollisions, classNameConflicts, variableProblems };
}

// ── rendering ───────────────────────────────────────────────────────────────
//
// Every renderer returns text that already satisfies the blueprint's gate: ruff
// with E, W, F, I, UP, B, SIM and TCH selected, ruff format at 120 columns, mypy
// in strict mode, and the import-linter layer contracts. Three constraints are
// load-bearing and each one fails the gate when a renderer drops it:
//
//   - A handler returns Coroutine, not Awaitable. create_job_worker accepts
//     Coroutine[Any, Any, dict[str, Any] | JobCompletionRequest | None], and
//     Awaitable is a supertype of Coroutine, so mypy rejects an Awaitable handler
//     at the registration call in app.py.
//   - An import used only in an annotation belongs inside `if TYPE_CHECKING:`.
//     Ruff's TC001 and TC003 reject it at module scope and repair neither.
//   - A type alias that fits inside 120 columns occupies one line. ruff format
//     rewraps a split alias.

/**
 * One `from <source> import <names>` statement, wrapped the way ruff format wants
 * it.
 *
 * A statement that fits stays on one line, because ruff format collapses a split
 * one that has no trailing comma. A statement that does not fit explodes with a
 * trailing comma, which ruff format preserves. Both shapes are therefore stable
 * under `ruff format --check`.
 *
 * @param {string} source the module path
 * @param {string[]} names
 * @returns {string[]} one line, or the exploded form
 */
function renderImport(source, names) {
  const oneLine = `from ${source} import ${names.join(', ')}`;
  if (oneLine.length <= MAX_LINE) return [oneLine];
  return [`from ${source} import (`, ...names.map((n) => `    ${n},`), ')'];
}

/**
 * One Pydantic field line, with an alias when the Python name differs from the
 * manifest name.
 *
 * The alias is what keeps the snake_case rename invisible to the process: without
 * it the model reads neither a hyphenated nor a camel-case variable, and the value
 * lands in the extras instead of the field.
 *
 * @param {object} field
 * @param {boolean} required
 * @returns {string}
 */
function fieldLine(field, required) {
  const { field: name, source, pyType } = field;
  const aliased = name !== source;
  const annotation = required ? pyType : `${pyType} | None`;
  if (!aliased) {
    return required ? `    ${name}: ${annotation}` : `    ${name}: ${annotation} = None`;
  }
  const args = required
    ? `alias=${JSON.stringify(source)}`
    : `default=None, alias=${JSON.stringify(source)}`;
  const oneLine = `    ${name}: ${annotation} = Field(${args})`;
  if (oneLine.length <= MAX_LINE) return oneLine;
  // Past the line limit ruff format splits the call, and E501 rejects the long
  // form, so the emitter produces the split shape itself. A manifest variable
  // name beyond roughly 85 characters overflows even this shape, and the Phase-3
  // gate reports it rather than the generator writing something ruff rewrites.
  return [
    `    ${name}: ${annotation} = Field(`,
    `        ${args}`,
    '    )',
  ].join('\n');
}

function needsFieldImport(lines) {
  return lines.some((line) => line.includes('Field('));
}

/**
 * src/models/process_variables.py — the all-optional union over every variable in
 * every group, plus one input and one output model per group.
 *
 * The union model is what a caller reads when it needs the whole process scope.
 * A group's input model marks a field required only when every manifest entry for
 * that job type declares it. A group's output model forbids an extra field, so a
 * service cannot return a variable its task never declared, and every output stays
 * optional so the generated stub can return an empty model.
 *
 * @param {object[]} groups
 * @returns {string}
 */
function renderProcessVariables(groups) {
  const bySource = new Map();
  for (const group of groups) {
    for (const f of [...group.inputs, ...group.outputs]) {
      if (!bySource.has(f.source)) bySource.set(f.source, f);
      else if (bySource.get(f.source).pyType !== f.pyType) {
        bySource.set(f.source, { ...bySource.get(f.source), pyType: UNKNOWN_TYPE });
      }
    }
  }

  const blocks = [];
  const unionLines = [...bySource.values()].map((f) => fieldLine(f, false));
  blocks.push([
    'class ProcessVariables(BaseModel):',
    '    """Every process variable the manifest declares, across every job type.',
    '',
    '    Every field is optional: the union spans the whole process, so a variable a later',
    '    task produces is absent when an earlier worker validates. An alias preserves the',
    '    manifest name wherever the Python field name differs from it.',
    '    """',
    '',
    '    model_config = ConfigDict(extra="allow", populate_by_name=True)',
    ...(unionLines.length ? ['', ...unionLines] : []),
  ].join('\n'));

  for (const group of groups) {
    const inputLines = group.inputs.map((f) => fieldLine(f, f.required));
    blocks.push([
      `class ${group.pascal}Input(BaseModel):`,
      `    """The variables ${group.jobType} reads.`,
      '',
      '    A field is required only when every manifest entry for this job type declares it.',
      '    """',
      '',
      '    model_config = ConfigDict(extra="allow", populate_by_name=True)',
      ...(inputLines.length ? ['', ...inputLines] : []),
    ].join('\n'));

    const outputLines = group.outputs.map((f) => fieldLine(f, false));
    blocks.push([
      `class ${group.pascal}Output(BaseModel):`,
      `    """The variables ${group.jobType} writes.`,
      '',
      '    Every field is optional, so the generated service can return an empty model until',
      '    someone implements it. `extra="forbid"` keeps a service inside its declared contract.',
      '    """',
      '',
      '    model_config = ConfigDict(extra="forbid", populate_by_name=True)',
      ...(outputLines.length ? ['', ...outputLines] : []),
    ].join('\n'));
  }

  const allLines = blocks.join('\n').split('\n');
  const pydanticImport = needsFieldImport(allLines)
    ? 'from pydantic import BaseModel, ConfigDict, Field'
    : 'from pydantic import BaseModel, ConfigDict';

  return [
    '"""Process variable models, generated from the artifact manifest."""',
    '',
    'from __future__ import annotations',
    '',
    pydanticImport,
    '',
    '',
    blocks.join('\n\n\n'),
    '',
  ].join('\n');
}

/**
 * src/errors/service_error.py — the SDK-independent error a service raises to
 * report an expected business result.
 *
 * A service stays free of Camunda job-control behavior. The worker translates a
 * declared ServiceError into the SDK's JobError, so a service can never throw an
 * error code its own task does not declare.
 *
 * @returns {string}
 */
function renderServiceError() {
  return [
    '"""The error a service raises to report an expected business result."""',
    '',
    '',
    'class ServiceError(Exception):',
    '    """Carries a BPMN error code alongside its message.',
    '',
    '    A service raises this instead of an SDK error, which keeps Camunda job-control',
    '    behavior inside the worker module. The worker translates a declared code into a',
    '    BPMN error and re-raises anything else.',
    '    """',
    '',
    '    def __init__(self, code: str, message: str) -> None:',
    '        super().__init__(message)',
    '        self.code = code',
    '',
  ].join('\n');
}

/**
 * src/errors/bpmn_errors.py — the vocabulary of every BPMN error code the
 * manifest declares.
 *
 * Emitted only when some group declares a code. A module of unused constants
 * would otherwise ship for the common case, and the shipped fixture declares no
 * code for most of its job types.
 *
 * @param {string[]} codes sorted, deduplicated
 * @returns {string}
 */
function renderBpmnErrors(codes) {
  const entries = codes.map((c) => `    ${JSON.stringify(c)}: ${JSON.stringify(c)},`);
  // ruff format collapses a single-element subscript even when it carries a magic
  // trailing comma, so one code stays on one line and only two or more explode.
  const oneCodeLine = codes.length === 1 ? `type BpmnErrorCode = Literal[${JSON.stringify(codes[0])}]` : null;
  const aliasLines = oneCodeLine && oneCodeLine.length <= MAX_LINE
    ? [oneCodeLine]
    : ['type BpmnErrorCode = Literal[', ...codes.map((c) => `    ${JSON.stringify(c)},`), ']'];
  return [
    '"""The BPMN error codes the manifest declares, and nothing else."""',
    '',
    'from typing import Final, Literal',
    '',
    ...aliasLines,
    '',
    'BPMN_ERROR_CODES: Final[dict[BpmnErrorCode, BpmnErrorCode]] = {',
    ...entries,
    '}',
    '',
  ].join('\n');
}

/**
 * src/services/<snake>_service.py — the engagement seam.
 *
 * The stub imports its models and nothing else. It does not import ServiceError,
 * because a service that raises none would carry an unused import, and the
 * blueprint treats that as an error. The TODO comment names ServiceError so the
 * implementer knows what to add.
 *
 * @param {object} group
 * @returns {string}
 */
function renderService(group, pyPackage = 'src') {
  const errorGuidance = group.errorCodes.length
    ? [
      '        # Raise ServiceError with one of this task\'s declared BPMN error codes when the',
      `        # process should follow an error path: ${group.errorCodes.join(', ')}.`,
    ]
    : [];
  const sigOneLine = `    async def execute(self, _input_data: ${group.pascal}Input) -> ${group.pascal}Output:`;
  const signature = sigOneLine.length <= MAX_LINE
    ? [sigOneLine]
    : [
      '    async def execute(',
      `        self, _input_data: ${group.pascal}Input`,
      `    ) -> ${group.pascal}Output:`,
    ];
  return [
    `"""Business logic for the ${group.jobType} job type."""`,
    '',
    'from __future__ import annotations',
    '',
    ...renderImport(`${pyPackage}.models.process_variables`, [`${group.pascal}Input`, `${group.pascal}Output`]),
    '',
    '',
    `class ${group.pascal}Service:`,
    `    """Implements ${group.jobType}."""`,
    '',
    ...signature,
    '        # TODO: implement. Rename `_input_data` once the implementation reads it.',
    '        # Return the declared output variables on the returned model.',
    ...errorGuidance,
    `        return ${group.pascal}Output()`,
    '',
  ].join('\n');
}

/**
 * src/workers/<snake>_worker.py — the SDK boundary for one job type.
 *
 * The worker validates the job's variables, calls its service, serializes the
 * output under the manifest's own variable names, and translates a declared
 * ServiceError into a BPMN error. Logging happens here and never in the service.
 *
 * A worker whose job type declares no BPMN error omits the error imports and the
 * translation entirely, because the blueprint treats an unused import as an error.
 *
 * @param {object} group
 * @returns {string}
 */
function renderWorker(group, pyPackage = 'src') {
  const hasErrors = group.errorCodes.length > 0;
  const sdkNames = ['ConnectedJobContext', hasErrors ? 'JobError' : null, 'JobFailure', 'WorkerConfig'].filter(Boolean);
  const sdkImport = renderImport('camunda_orchestration_sdk', sdkNames);

  const firstPartyImports = [
    ...(hasErrors
      ? [
        ...renderImport(`${pyPackage}.errors.bpmn_errors`, ['BPMN_ERROR_CODES']),
        ...renderImport(`${pyPackage}.errors.service_error`, ['ServiceError']),
      ]
      : []),
    ...renderImport(`${pyPackage}.models.process_variables`, [`${group.pascal}Input`]),
    ...renderImport(`${pyPackage}.workers.worker_defaults`, ['WORKER_DEFAULTS']),
  ];

  const declaredCodes = hasErrors
    ? [
      '',
      'DECLARED_ERROR_CODES = frozenset(',
      '    {',
      ...group.errorCodes.map((c) => `        BPMN_ERROR_CODES[${JSON.stringify(c)}],`),
      '    }',
      ')',
    ]
    : [];

  const serviceCall = hasErrors
    ? [
      '        try:',
      '            output = await service.execute(input_data)',
      '        except ServiceError as error:',
      '            if error.code in DECLARED_ERROR_CODES:',
      '                log.warning(',
      `                    "${group.jobType} raised BPMN error %s: %s",`,
      '                    error.code,',
      '                    error,',
      '                )',
      '                raise JobError(error_code=error.code, message=str(error)) from error',
      '            raise',
    ]
    : ['        output = await service.execute(input_data)'];

  return [
    `"""The Camunda job worker for the ${group.jobType} job type."""`,
    '',
    'from __future__ import annotations',
    '',
    'from collections.abc import Callable, Coroutine',
    'from typing import TYPE_CHECKING, Any',
    '',
    ...sdkImport,
    'from pydantic import ValidationError',
    '',
    ...firstPartyImports,
    '',
    'if TYPE_CHECKING:',
    '    import logging',
    '',
    ...renderImport(`${pyPackage}.services.${group.snake}_service`, [`${group.pascal}Service`]).map((l) => `    ${l}`),
    '',
    'type WorkerHandler = Callable[[ConnectedJobContext], Coroutine[Any, Any, dict[str, Any]]]',
    ...declaredCodes,
    '',
    '',
    `def create_${group.snake}_worker(`,
    `    service: ${group.pascal}Service,`,
    '    log: logging.Logger,',
    ') -> tuple[WorkerConfig, WorkerHandler]:',
    `    """Build the config and handler that subscribe to ${group.jobType}."""`,
    '',
    '    async def handler(job: ConnectedJobContext) -> dict[str, Any]:',
    '        try:',
    `            input_data = ${group.pascal}Input.model_validate(job.variables.to_dict())`,
    '        except ValidationError as error:',
    '            raise JobFailure(',
    `                message=f"${group.jobType} received malformed input: {error}",`,
    '                retries=0,',
    '            ) from error',
    '',
    `        log.info("${group.jobType} received input: %s", input_data)`,
    '',
    ...serviceCall,
    '',
    '        return output.model_dump(by_alias=True, exclude_none=True)',
    '',
    '    config = WorkerConfig(',
    `        job_type=${JSON.stringify(group.jobType)},`,
    `        worker_name=${JSON.stringify(group.className)},`,
    '        **WORKER_DEFAULTS,',
    '    )',
    '    return config, handler',
    '',
  ].join('\n');
}

/**
 * src/app.py — the composition root and the single worker registry.
 *
 * The four exports main.py and shutdown.py consume stay in place: AppServices,
 * compose_app, RegisteredWorkers and register_workers. `http_clients` starts
 * empty, and engagement code that builds an HttpClient must add it there so
 * shutdown closes its connection pool.
 *
 * `execution_strategy="async"` is explicit rather than left to the SDK's `auto`
 * detection, which keeps every handler on ConnectedJobContext.
 *
 * @param {object[]} groups
 * @returns {string}
 */
function renderApp(groups, pyPackage = 'src') {
  const serviceImports = groups.flatMap(
    (g) => renderImport(`${pyPackage}.services.${g.snake}_service`, [`${g.pascal}Service`]),
  );
  const workerImports = groups.flatMap(
    (g) => renderImport(`${pyPackage}.workers.${g.snake}_worker`, [`create_${g.snake}_worker`]),
  );

  const serviceFields = groups.map((g) => `    ${g.snake}_service: ${g.pascal}Service`);
  // A call with no arguments occupies one line. ruff format collapses a split
  // empty argument list, so the two-line form fails `ruff format --check` on a
  // manifest that declares no job type.
  const compose = groups.length
    ? [
      '    return AppServices(',
      ...groups.map((g) => `        ${g.snake}_service=${g.pascal}Service(),`),
      '    )',
    ]
    : ['    return AppServices()'];

  const registerBody = groups.length
    ? [
      '    worker_factories = [',
      ...groups.flatMap((g) => {
        const oneLine = `        create_${g.snake}_worker(services.${g.snake}_service, log),`;
        if (oneLine.length <= MAX_LINE) return [oneLine];
        return [
          `        create_${g.snake}_worker(`,
          `            services.${g.snake}_service, log`,
          '        ),',
        ];
      }),
      '    ]',
      '',
      '    workers: RegisteredWorkers = {}',
      '    for config, handler in worker_factories:',
      '        workers[config.job_type] = client.create_job_worker(',
      '            config=config,',
      '            callback=handler,',
      '            execution_strategy="async",',
      '        )',
      '',
      '    return workers',
    ]
    : [
      '    # The manifest declares no job type, so no worker subscribes. The application',
      '    # still starts, serves its health endpoints, and shuts down cleanly.',
      '    return {}',
    ];

  return [
    '"""Composition root: build the services, then register one worker per job type.',
    '',
    'Generated from the artifact manifest. Add clients and their wiring here, and put',
    'every HttpClient into `http_clients` so shutdown closes its connection pool.',
    '"""',
    '',
    'from __future__ import annotations',
    '',
    'from dataclasses import dataclass, field',
    'from typing import TYPE_CHECKING',
    '',
    ...(groups.length ? [...serviceImports, ...workerImports, ''] : []),
    'if TYPE_CHECKING:',
    '    import logging',
    '',
    '    from camunda_orchestration_sdk import CamundaAsyncClient',
    '',
    `    from ${pyPackage}.clients.http_client import HttpClient`,
    `    from ${pyPackage}.config.env import Env`,
    `    from ${pyPackage}.shutdown import RegisteredWorkers`,
    '',
    '',
    '@dataclass',
    'class AppServices:',
    '    """Every service the workers need, plus the clients shutdown has to close."""',
    '',
    ...serviceFields,
    '    http_clients: list[HttpClient] = field(default_factory=list)',
    '',
    '',
    'def compose_app(env: Env) -> AppServices:',
    '    """Wire up the dependencies. No DI framework — explicit composition."""',
    ...compose,
    '',
    '',
    'def register_workers(',
    '    client: CamundaAsyncClient,',
    '    services: AppServices,',
    '    log: logging.Logger,',
    ') -> RegisteredWorkers:',
    '    """Register one worker per manifest job type, keyed by job type."""',
    ...registerBody,
    '',
  ].join('\n');
}

/**
 * The complete set of files the generator writes, as relative paths and text.
 *
 * The wrapper owns where they land and what it removes first. Returning the whole
 * plan keeps the emitter free of filesystem knowledge and lets a test assert the
 * exact file set.
 *
 * @param {object[]} groups
 * @param {string} [pyPackage] the top-level package name — both the emitted
 *   files' import statements and their own paths land under it. Defaults to
 *   `src`, the blueprint's own name, so a caller that does not care which
 *   package it is (most of this file's own tests) needs no change.
 * @returns {Array<{path: string, text: string}>}
 */
function renderAll(groups, pyPackage = 'src') {
  const allCodes = [...new Set(groups.flatMap((g) => g.errorCodes))].sort();
  const files = [
    { path: path.join(pyPackage, 'models', 'process_variables.py'), text: renderProcessVariables(groups) },
    { path: path.join(pyPackage, 'errors', 'service_error.py'), text: renderServiceError() },
  ];
  if (allCodes.length) {
    files.push({ path: path.join(pyPackage, 'errors', 'bpmn_errors.py'), text: renderBpmnErrors(allCodes) });
  }
  for (const group of groups) {
    files.push({ path: path.join(pyPackage, 'services', `${group.snake}_service.py`), text: renderService(group, pyPackage) });
  }
  for (const group of groups) {
    files.push({ path: path.join(pyPackage, 'workers', `${group.snake}_worker.py`), text: renderWorker(group, pyPackage) });
  }
  files.push({ path: path.join(pyPackage, 'app.py'), text: renderApp(groups, pyPackage) });
  return files;
}

module.exports = {
  UNKNOWN_TYPE,
  snakeStem,
  pascalStem,
  isLegalStem,
  mergeDeclaredType,
  groupWorkers,
  validateGroups,
  renderImport,
  fieldLine,
  renderProcessVariables,
  renderServiceError,
  renderBpmnErrors,
  renderService,
  renderWorker,
  renderApp,
  renderAll,
};
