#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Report whether each given path exists, portably.
//
// Replaces the `test -f X && echo "EXISTS" || echo "NOT FOUND"` idiom that skills
// used for existence probes. That spelling needs three constructs PowerShell 5.1
// does not have — `test`, `&&` and `||` — so a native Windows agent had to
// improvise a translation every time.
//
// Usage:
//   node "path-exists.cjs" [--dir] <path>...
//
//   --dir   require a directory (the `test -d` case). Default is a regular file,
//           matching `test -f`: a directory does NOT satisfy a file probe.
//
// Prints one line per path, in the order given:
//   EXISTS     .camunda/governance.json
//   NOT FOUND  transformation.config.md
//
// Relative paths resolve against the current working directory, which is the
// ProcessOS project root. Always exits 0 — "absent" is an answer, not an error;
// a caller reads the verdict from stdout. Exits 2 only on a usage error.

const fs = require('fs');

/**
 * Test one path.
 *
 * @param {string} p Path to check, absolute or project-relative.
 * @param {boolean} wantDir Require a directory instead of a regular file.
 * @returns {boolean} Whether the path exists as the requested kind.
 */
function check(p, wantDir) {
  let stat;
  try {
    // statSync follows symlinks, which is what `test -f` / `test -d` do too.
    stat = fs.statSync(p);
  } catch {
    return false;
  }
  return wantDir ? stat.isDirectory() : stat.isFile();
}

/**
 * @param {string[]} argv Arguments after the script name.
 * @returns {{wantDir: boolean, paths: string[]}}
 */
function parseArgs(argv) {
  const wantDir = argv.includes('--dir');
  return { wantDir, paths: argv.filter((a) => a !== '--dir') };
}

/**
 * Format one verdict line. Padded so a multi-path report stays column-aligned.
 *
 * @param {string} p Path as the caller wrote it.
 * @param {boolean} exists Verdict.
 * @returns {string} Line without its trailing newline.
 */
function formatLine(p, exists) {
  return `${(exists ? 'EXISTS' : 'NOT FOUND').padEnd(10)} ${p}`;
}

module.exports = { check, parseArgs, formatLine };

if (require.main === module) {
  const { wantDir, paths } = parseArgs(process.argv.slice(2));
  if (paths.length === 0) {
    process.stderr.write('usage: path-exists.cjs [--dir] <path>...\n');
    process.exit(2);
  }
  for (const p of paths) {
    process.stdout.write(`${formatLine(p, check(p, wantDir))}\n`);
  }
}
