#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Resolve, list, open and close the per-iteration output directories a review
// phase writes under its phase directory: `<phase-dir>/iteration-<N>/`, each
// holding an `artifacts/` (this iteration's generated documents) and a
// `feedback/` (what a reviewer sends back).
//
// Usage:
//   node "iteration-dir.cjs" current <phase-dir> [--complete] [--artifacts | --feedback] [--json]
//   node "iteration-dir.cjs" list    <phase-dir> [--json]
//   node "iteration-dir.cjs" open    <phase-dir> [--seed] [--json]
//   node "iteration-dir.cjs" close   <phase-dir>
//
// current   Prints the highest iteration. `--complete` picks the highest one
//           with no in-progress marker instead. `--artifacts`/`--feedback`
//           print that entry's artifacts/feedback path instead of its own
//           directory; the two flags are mutually exclusive, and neither
//           combines with `--json`.
// list      Prints every iteration, lowest first, one per line.
// open      Prints the iteration to write into: the existing highest one if
//           it is still in progress (creating nothing, but restoring an
//           `artifacts/` or `feedback/` that went missing), otherwise a freshly
//           created next one. `--seed` copies the previous iteration's
//           `artifacts/` forward into the new one — only meaningful when a new
//           iteration is actually being created.
// close     Clears the in-progress marker from the highest iteration and
//           prints it. A no-op, still exit 0, if it already had none.
//
// Default output is the bare directory path (or, for `current --artifacts` /
// `--feedback`, that sub-path). `--json` prints the entry object instead — an
// array of them for `list`. Every printed path and every `--json` string field
// uses `/`, on every platform.
//
// Exit codes:
//   0  success.
//   2  usage error (bad flags, missing <phase-dir>, unknown command).
//   3  nothing to report — no iteration exists (or, under `--complete`, none
//      without an in-progress marker). Nothing is written to stdout or stderr.
//   4  a child of <phase-dir> named like an iteration directory does not
//      actually match `ITERATION_DIR_RE` (e.g. `iteration-0`, `iteration-007`,
//      `iteration-x`). Nothing is created.
//   5  <phase-dir> exists but is not a directory, a create/copy/rename/write
//      failed, or checking <phase-dir> itself failed for a reason other than
//      it not existing (e.g. a permission error or a symlink loop).
//   6  `--seed` was given but there is no previous iteration, or the previous
//      iteration has no `artifacts/` to copy forward. Nothing is created.
//
// A child of <phase-dir> whose name starts with `.` is ignored entirely — that
// is how the `.iteration-<N>.partial/` staging directory `open --seed` uses
// stays invisible to every other command while a seed copy is in flight.

const fs = require('fs');
const path = require('path');

const EXIT = { OK: 0, USAGE: 2, NONE: 3, MALFORMED: 4, IO: 5, NO_SEED_SOURCE: 6 };
const ITERATION_DIR_RE = /^iteration-([1-9]\d*)$/;
const MARKER = '.in-progress';
const MAX_CREATE_ATTEMPTS = 5;

const FEEDBACK_README = `# Feedback on this iteration

Put feedback on this iteration's documents here. Anything a reviewer sends belongs in
this directory:

- a returned answers workbook or Markdown file (exported from \`../artifacts/review-questions.yaml\`)
- reviewer notes from email, chat, or a workshop
- marked-up exports, PDFs, transcripts, screenshots
- a hand-edited \`.bpmn\`, as a file of its own

**Commit what you add.** The next run of this phase reads this directory, folds what it
finds into the next iteration's documents, and leaves this iteration untouched.

Do not edit anything under \`../artifacts/\` — those documents are this iteration's
record, and the next run regenerates them from what it finds here.
`;

const USAGE =
  'usage:\n' +
  '  iteration-dir.cjs current <phase-dir> [--complete] [--artifacts | --feedback] [--json]\n' +
  '  iteration-dir.cjs list    <phase-dir> [--json]\n' +
  '  iteration-dir.cjs open    <phase-dir> [--seed] [--json]\n' +
  '  iteration-dir.cjs close   <phase-dir>\n';

/**
 * Tag an error with one of the codes {@link EXIT} names, other than `OK` or
 * `USAGE` — both are decided before any of this module's functions run.
 *
 * @param {string} message
 * @param {'MALFORMED'|'NO_SEED_SOURCE'} code
 * @returns {Error}
 */
function taggedError(message, code) {
  const err = new Error(message);
  err.code = code;
  return err;
}

/**
 * @param {string} p A path built with `path.join`/`path.resolve`.
 * @returns {string} The same path, `/`-separated.
 */
function toPosix(p) {
  return p.split(path.sep).join('/');
}

/**
 * @param {string} nativeDir The iteration directory, in the platform's own
 *   separator.
 * @param {number} iteration
 * @param {boolean} inProgress
 * @returns {{dir: string, artifacts: string, feedback: string, iteration: number, inProgress: boolean}}
 */
function toPublicEntry(nativeDir, iteration, inProgress) {
  return {
    dir: toPosix(nativeDir),
    artifacts: toPosix(path.join(nativeDir, 'artifacts')),
    feedback: toPosix(path.join(nativeDir, 'feedback')),
    iteration,
    inProgress,
  };
}

/**
 * Read the direct children of `phaseDir` that are iteration directories,
 * ascending by their captured number.
 *
 * @param {string} phaseDir
 * @returns {{nativeDir: string, iteration: number, inProgress: boolean}[]}
 * @throws {Error} Untagged when `phaseDir` exists but is not a directory, or
 *   `fs.statSync` fails for a reason other than the path not existing — e.g. a
 *   permission error or a symlink loop (both map to `EXIT.IO`); tagged
 *   `MALFORMED` when a child's name starts with `iteration-` but does not
 *   match {@link ITERATION_DIR_RE}.
 */
function scan(phaseDir) {
  let stat;
  try {
    stat = fs.statSync(phaseDir);
  } catch (err) {
    if (err.code === 'ENOENT') return [];
    throw err;
  }
  if (!stat.isDirectory()) {
    throw new Error(`${phaseDir} exists but is not a directory`);
  }

  const entries = [];
  for (const child of fs.readdirSync(phaseDir, { withFileTypes: true })) {
    // A dot-prefixed child (the seed staging directory, or anything else) is
    // never an iteration entry and never a naming error either.
    if (child.name.startsWith('.')) continue;
    if (!child.name.startsWith('iteration-')) continue;
    const match = ITERATION_DIR_RE.exec(child.name);
    if (!match) {
      throw taggedError(
        `"${child.name}" under ${phaseDir} looks like an iteration directory, ` +
          `but its name does not match ${ITERATION_DIR_RE}`,
        'MALFORMED',
      );
    }
    if (!child.isDirectory()) continue;
    const nativeDir = path.join(phaseDir, child.name);
    entries.push({
      nativeDir,
      iteration: Number(match[1]),
      inProgress: fs.existsSync(path.join(nativeDir, MARKER)),
    });
  }
  entries.sort((a, b) => a.iteration - b.iteration);
  return entries;
}

/**
 * @param {string} dir The iteration directory to write the marker into.
 */
function writeMarker(dir) {
  fs.writeFileSync(path.join(dir, MARKER), `opened ${new Date().toISOString()}\n`);
}

/**
 * Recursively copy a file, symlink or directory tree.
 *
 * @param {string} src
 * @param {string} dest
 */
function copyTree(src, dest) {
  const stat = fs.lstatSync(src);
  if (stat.isDirectory()) {
    fs.mkdirSync(dest, { recursive: true });
    for (const name of fs.readdirSync(src)) {
      copyTree(path.join(src, name), path.join(dest, name));
    }
  } else if (stat.isSymbolicLink()) {
    fs.symlinkSync(fs.readlinkSync(src), dest);
  } else {
    fs.copyFileSync(src, dest);
  }
}

/**
 * Ensure a highest entry that is still in progress has both its scaffold
 * directories, without touching anything that is already there — in
 * particular, never rewriting `MARKER`.
 *
 * @param {string} dir The iteration directory.
 */
function restoreScaffold(dir) {
  fs.mkdirSync(path.join(dir, 'artifacts'), { recursive: true });
  fs.mkdirSync(path.join(dir, 'feedback'), { recursive: true });
  const readme = path.join(dir, 'feedback', 'README.md');
  if (!fs.existsSync(readme)) fs.writeFileSync(readme, FEEDBACK_README);
}

/**
 * Create a new iteration directory: `iteration-<N>/`, its `artifacts/` populated by
 * `populateArtifacts`, `feedback/README.md`, and `MARKER`.
 *
 * Built in a `.iteration-<N>.partial/` staging directory — removing a stale one from an
 * interrupted previous attempt first — then moved into place with a single
 * `renameSync`. The staging step is what makes the entry atomic: an `iteration-<N>/`
 * that exists always already carries its scaffold and its marker. Created in place
 * instead, it is visible without `MARKER` for as long as the scaffold writes take, and a
 * reader that looks in that window classifies it as a *completed* iteration — so an
 * interrupted create would leave the next `open` advancing past a directory holding
 * nothing.
 *
 * The number is reserved by the rename, not by a prior `mkdirSync`: a racing process
 * either loses `existsSync` below or fails the rename, and retries with a recomputed
 * number. Capped so a pathological filesystem cannot spin forever.
 *
 * @param {string} phaseDir
 * @param {(artifactsDir: string) => void} populateArtifacts Creates and fills `artifacts/`.
 * @returns {{nativeDir: string, iteration: number}}
 */
function createEntry(phaseDir, populateArtifacts) {
  fs.mkdirSync(phaseDir, { recursive: true });
  for (let attempt = 0; attempt < MAX_CREATE_ATTEMPTS; attempt++) {
    const entries = scan(phaseDir);
    const iteration = entries.length === 0 ? 1 : entries[entries.length - 1].iteration + 1;
    const nativeDir = path.join(phaseDir, `iteration-${iteration}`);
    // Lost a race with another process for this number: recompute and retry
    // rather than rename over — or into — whatever is there.
    if (fs.existsSync(nativeDir)) continue;

    const partialDir = path.join(phaseDir, `.iteration-${iteration}.partial`);
    fs.rmSync(partialDir, { recursive: true, force: true });
    fs.mkdirSync(partialDir, { recursive: true });
    populateArtifacts(path.join(partialDir, 'artifacts'));
    fs.mkdirSync(path.join(partialDir, 'feedback'));
    fs.writeFileSync(path.join(partialDir, 'feedback', 'README.md'), FEEDBACK_README);
    writeMarker(partialDir);

    try {
      fs.renameSync(partialDir, nativeDir);
    } catch {
      continue;
    }
    return { nativeDir, iteration };
  }
  throw new Error(
    `could not reserve a new iteration directory under ${phaseDir} after ${MAX_CREATE_ATTEMPTS} attempts`,
  );
}

/**
 * Create a fresh iteration directory with an empty `artifacts/`.
 *
 * @param {string} phaseDir
 * @returns {{nativeDir: string, iteration: number}}
 */
function createFreshEntry(phaseDir) {
  return createEntry(phaseDir, (artifactsDir) => fs.mkdirSync(artifactsDir));
}

/**
 * Create a new iteration directory seeded from the previous one's `artifacts/`.
 *
 * @param {string} phaseDir
 * @param {string} previousArtifactsDir
 * @returns {{nativeDir: string, iteration: number}}
 */
function createSeededEntry(phaseDir, previousArtifactsDir) {
  return createEntry(phaseDir, (artifactsDir) => copyTree(previousArtifactsDir, artifactsDir));
}

/**
 * @param {string} phaseDir
 * @returns {{dir: string, artifacts: string, feedback: string, iteration: number, inProgress: boolean}[]}
 *   Every iteration under `phaseDir`, lowest first.
 */
function listIterations(phaseDir) {
  return scan(phaseDir).map((e) => toPublicEntry(e.nativeDir, e.iteration, e.inProgress));
}

/**
 * @param {string} phaseDir
 * @param {{complete?: boolean}} [options] `complete`: pick the highest entry
 *   with no in-progress marker instead of the highest overall.
 * @returns {{dir: string, artifacts: string, feedback: string, iteration: number, inProgress: boolean}|null}
 *   `null` when there is no such entry.
 */
function currentIteration(phaseDir, { complete = false } = {}) {
  const entries = scan(phaseDir);
  if (entries.length === 0) return null;
  if (!complete) {
    const top = entries[entries.length - 1];
    return toPublicEntry(top.nativeDir, top.iteration, top.inProgress);
  }
  for (let i = entries.length - 1; i >= 0; i--) {
    if (!entries[i].inProgress) return toPublicEntry(entries[i].nativeDir, entries[i].iteration, false);
  }
  return null;
}

/**
 * @param {string} phaseDir
 * @param {{seed?: boolean}} [options] `seed`: when a new iteration is created,
 *   copy the previous one's `artifacts/` into it. Ignored when the highest
 *   iteration is still in progress — nothing is created in that case, so there
 *   is nothing to seed.
 * @returns {{dir: string, artifacts: string, feedback: string, iteration: number, inProgress: boolean, created: boolean, seeded: boolean}}
 *   The iteration to write into.
 * @throws {Error} Tagged `NO_SEED_SOURCE` when `seed` is set and there is no
 *   previous iteration, or the previous iteration has no `artifacts/` at all.
 */
function openIteration(phaseDir, { seed = false } = {}) {
  const entries = scan(phaseDir);

  if (entries.length === 0) {
    if (seed) throw taggedError(`no previous iteration to seed from under ${phaseDir}`, 'NO_SEED_SOURCE');
    const created = createFreshEntry(phaseDir);
    return { ...toPublicEntry(created.nativeDir, created.iteration, true), created: true, seeded: false };
  }

  const highest = entries[entries.length - 1];
  if (highest.inProgress) {
    restoreScaffold(highest.nativeDir);
    return { ...toPublicEntry(highest.nativeDir, highest.iteration, true), created: false, seeded: false };
  }

  if (seed) {
    const previousArtifacts = path.join(highest.nativeDir, 'artifacts');
    if (!fs.existsSync(previousArtifacts)) {
      throw taggedError(
        `no artifacts/ under ${toPosix(highest.nativeDir)} to seed the next iteration from`,
        'NO_SEED_SOURCE',
      );
    }
    const created = createSeededEntry(phaseDir, previousArtifacts);
    return { ...toPublicEntry(created.nativeDir, created.iteration, true), created: true, seeded: true };
  }

  const created = createFreshEntry(phaseDir);
  return { ...toPublicEntry(created.nativeDir, created.iteration, true), created: true, seeded: false };
}

/**
 * Clear the in-progress marker from the highest iteration, if it has one.
 *
 * @param {string} phaseDir
 * @returns {{dir: string, artifacts: string, feedback: string, iteration: number, inProgress: boolean}|null}
 *   `null` when there is no iteration at all.
 */
function closeIteration(phaseDir) {
  const entries = scan(phaseDir);
  if (entries.length === 0) return null;
  const highest = entries[entries.length - 1];
  if (highest.inProgress) fs.rmSync(path.join(highest.nativeDir, MARKER), { force: true });
  return toPublicEntry(highest.nativeDir, highest.iteration, false);
}

/**
 * Parse a path against a phase directory, resolving which iteration, section
 * (`artifacts` or `feedback`) and remaining path it names.
 *
 * @param {string} phaseDir
 * @param {string} p Either separator is accepted.
 * @returns {{iteration: number, section: string, rest: string}|null} `null`
 *   when `p` is not under `phaseDir`, the segment right after `phaseDir` is
 *   not a valid iteration directory name, or nothing follows the section
 *   segment.
 */
function parseIterationPath(phaseDir, p) {
  const segments = (s) => s.replace(/\\/g, '/').split('/').filter((seg) => seg.length > 0);
  const base = segments(phaseDir);
  const full = segments(p);
  if (full.length < base.length) return null;
  for (let i = 0; i < base.length; i++) {
    if (full[i] !== base[i]) return null;
  }
  const rest = full.slice(base.length);
  if (rest.length < 3) return null;
  const match = ITERATION_DIR_RE.exec(rest[0]);
  if (!match) return null;
  return { iteration: Number(match[1]), section: rest[1], rest: rest.slice(2).join('/') };
}

/**
 * @param {string[]} argv Arguments after the command name.
 * @returns {{command: string, phaseDir: string, complete: boolean, artifacts: boolean,
 *   feedback: boolean, json: boolean, seed: boolean}|null} `null` on any usage error.
 */
function parseCli(argv) {
  const command = argv[0];
  if (!['current', 'list', 'open', 'close'].includes(command)) return null;

  let phaseDir;
  let complete = false;
  let artifacts = false;
  let feedback = false;
  let json = false;
  let seed = false;
  for (const arg of argv.slice(1)) {
    if (arg === '--complete') complete = true;
    else if (arg === '--artifacts') artifacts = true;
    else if (arg === '--feedback') feedback = true;
    else if (arg === '--json') json = true;
    else if (arg === '--seed') seed = true;
    else if (arg.startsWith('--')) return null;
    else if (phaseDir === undefined) phaseDir = arg;
    else return null;
  }
  if (phaseDir === undefined) return null;

  const allowedByCommand = {
    current: new Set(['complete', 'artifacts', 'feedback', 'json']),
    list: new Set(['json']),
    open: new Set(['seed', 'json']),
    close: new Set(),
  };
  const used = [];
  if (complete) used.push('complete');
  if (artifacts) used.push('artifacts');
  if (feedback) used.push('feedback');
  if (json) used.push('json');
  if (seed) used.push('seed');
  if (used.some((flag) => !allowedByCommand[command].has(flag))) return null;

  if (artifacts && feedback) return null;
  if ((artifacts || feedback) && json) return null;

  return { command, phaseDir, complete, artifacts, feedback, json, seed };
}

/**
 * @param {{dir: string, artifacts: string, feedback: string, iteration: number, inProgress: boolean}} entry
 * @param {{artifacts: boolean, feedback: boolean, json: boolean}} parsed
 */
function printCurrentResult(entry, parsed) {
  if (parsed.json) process.stdout.write(`${JSON.stringify(entry, null, 2)}\n`);
  else if (parsed.artifacts) process.stdout.write(`${entry.artifacts}\n`);
  else if (parsed.feedback) process.stdout.write(`${entry.feedback}\n`);
  else process.stdout.write(`${entry.dir}\n`);
}

/**
 * @param {string[]} argv `process.argv.slice(2)`.
 */
function main(argv) {
  const parsed = parseCli(argv);
  if (parsed === null) {
    process.stderr.write(USAGE);
    process.exit(EXIT.USAGE);
  }

  try {
    if (parsed.command === 'current') {
      const entry = currentIteration(parsed.phaseDir, { complete: parsed.complete });
      if (entry === null) process.exit(EXIT.NONE);
      printCurrentResult(entry, parsed);
      process.exit(EXIT.OK);
    } else if (parsed.command === 'list') {
      const entries = listIterations(parsed.phaseDir);
      if (entries.length === 0) process.exit(EXIT.NONE);
      if (parsed.json) process.stdout.write(`${JSON.stringify(entries, null, 2)}\n`);
      else process.stdout.write(entries.map((e) => `${e.dir}\n`).join(''));
      process.exit(EXIT.OK);
    } else if (parsed.command === 'open') {
      const entry = openIteration(parsed.phaseDir, { seed: parsed.seed });
      if (parsed.json) process.stdout.write(`${JSON.stringify(entry, null, 2)}\n`);
      else process.stdout.write(`${entry.dir}\n`);
      process.exit(EXIT.OK);
    } else {
      const entry = closeIteration(parsed.phaseDir);
      if (entry === null) process.exit(EXIT.NONE);
      process.stdout.write(`${entry.dir}\n`);
      process.exit(EXIT.OK);
    }
  } catch (err) {
    if (err.code === 'MALFORMED') {
      process.stderr.write(`${err.message}\n`);
      process.exit(EXIT.MALFORMED);
    }
    if (err.code === 'NO_SEED_SOURCE') {
      process.stderr.write(`${err.message}\n`);
      process.exit(EXIT.NO_SEED_SOURCE);
    }
    process.stderr.write(`${err.message}\n`);
    process.exit(EXIT.IO);
  }
}

module.exports = {
  EXIT,
  ITERATION_DIR_RE,
  MARKER,
  FEEDBACK_README,
  listIterations,
  currentIteration,
  openIteration,
  closeIteration,
  parseIterationPath,
};

if (require.main === module) main(process.argv.slice(2));
