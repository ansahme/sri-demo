#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

'use strict';

// Records what a `process-transformation` iteration's `artifacts/` directory can no longer say
// through its own path: which tier the run generated, which BPMN modeling mode it used, and
// when. One tier per iteration means the iteration number alone does not answer "which tier is
// this" — `iteration.yaml`, written here, is that answer, read back by anything that needs to
// know without re-deriving it from the artifacts themselves.
//
// Usage:
//   node "iteration-manifest.cjs" write <artifacts-dir> --phase <p> --iteration <N> --tier <t> [--bpmn-mode <m>] [--generated <YYYY-MM-DD>]
//   node "iteration-manifest.cjs" read  <artifacts-dir> [--key <k>]
//
// write   Creates <artifacts-dir> if needed and writes iteration.yaml inside it, in the field
//         order FIELD_ORDER declares. --phase, --iteration and --tier are required; --bpmn-mode
//         and --generated are recorded only when given.
// read    Prints the parsed manifest as JSON, or, with --key, the bare value of that one field.
//
// Exit codes:
//   0  success. write: written, nothing on stdout. read: the object (JSON), or the --key
//      value, on stdout.
//   2  usage error (bad flags, a missing <artifacts-dir>, an unknown command, a non-numeric
//      --iteration) or ProcessOS Node deps missing. Nothing on stdout.
//   3  read only: <artifacts-dir> has no iteration.yaml. Nothing on stdout.
//   4  read only: iteration.yaml is present but not valid YAML, not a map, or --key names a
//      field it does not carry — "there but broken" is not the same state as "not there", so it
//      gets its own code rather than folding into MISSING. Nothing on stdout.

const fs = require('node:fs');
const path = require('node:path');
// Sibling import spelled so the bundler's dependency-closure grep sees a literal
// <shared dir>/<file> path. This file already lives in that directory, so the requires
// round-trip via '../..' purely to put that literal in the text: it resolves correctly
// in source, and once copied as a peer into a consuming skill's scripts/ dir the
// bundler strips the up-nav to path.join(__dirname, 'yaml.cjs').
//
// Write that prefix ONLY inside these require() calls, where a real filename follows.
// The rewriter keys on <dir>/<name>.<ext>, so a bare prose mention of the directory
// survives into the bundled copy and trips bundler-compat.test.cjs.
const yaml = require(path.join(__dirname, 'yaml.cjs'));

const EXIT = { OK: 0, USAGE: 2, MISSING: 3, INVALID: 4 };
const FILE = 'iteration.yaml';
// Written in this order so the file is stable across runs and reads the way a human scans it.
const FIELD_ORDER = ['phase', 'iteration', 'tier', 'bpmn-mode', 'generated'];
const FLAGS = { '--phase': 'phase', '--iteration': 'iteration', '--tier': 'tier', '--bpmn-mode': 'bpmn-mode', '--generated': 'generated' };

const USAGE =
  'usage:\n' +
  '  iteration-manifest.cjs write <artifacts-dir> --phase <p> --iteration <N> --tier <t> [--bpmn-mode <m>] [--generated <YYYY-MM-DD>]\n' +
  '  iteration-manifest.cjs read  <artifacts-dir> [--key <k>]\n';

/**
 * Tag an error with one of {@link EXIT}'s names, other than `OK` or `USAGE` — both are decided
 * before any of this module's functions run.
 *
 * @param {string} message
 * @param {'MISSING'|'INVALID'} code
 * @returns {Error}
 */
function taggedError(message, code) {
  const err = new Error(message);
  err.code = code;
  return err;
}

/**
 * @param {string} artifactsDir
 * @param {Record<string, string|number>} fields Any subset of {@link FIELD_ORDER}'s names;
 *   fields not given are omitted from the file rather than written as empty.
 */
function writeManifest(artifactsDir, fields) {
  fs.mkdirSync(artifactsDir, { recursive: true });
  const obj = {};
  for (const key of FIELD_ORDER) {
    if (Object.hasOwn(fields, key) && fields[key] !== undefined) obj[key] = fields[key];
  }
  fs.writeFileSync(path.join(artifactsDir, FILE), yaml.stringify(obj));
}

/**
 * @param {string} artifactsDir
 * @returns {Record<string, unknown>} The parsed manifest.
 * @throws {Error} Tagged `MISSING` when <artifactsDir>/iteration.yaml does not exist; tagged
 *   `INVALID` when it exists but does not parse as YAML or does not parse to a plain map;
 *   untagged (propagated as-is) when `yaml.cjs` reports `DEPS_MISSING` — that is a broken
 *   project, not a broken or missing manifest, so it is never folded into either.
 */
function readManifest(artifactsDir) {
  const file = path.join(artifactsDir, FILE);
  let txt;
  try {
    txt = fs.readFileSync(file, 'utf8');
  } catch (err) {
    if (err.code === 'ENOENT') throw taggedError(`no ${FILE} under ${artifactsDir}`, 'MISSING');
    throw err;
  }
  let obj;
  try {
    obj = yaml.parse(txt);
  } catch (err) {
    if (err.code === 'DEPS_MISSING') throw err;
    throw taggedError(`${file} is not valid YAML: ${err.message}`, 'INVALID');
  }
  if (obj === null || typeof obj !== 'object' || Array.isArray(obj)) {
    throw taggedError(`${file} does not parse to a YAML map`, 'INVALID');
  }
  return obj;
}

/**
 * @param {string[]} argv Arguments after `write`.
 * @returns {{artifactsDir: string, fields: Record<string, string|number>}|null} `null` on any
 *   usage error: an unknown flag, a flag with no value, a missing <artifacts-dir>, a missing
 *   --phase/--iteration/--tier, or a non-numeric --iteration.
 */
function parseWriteArgs(argv) {
  let artifactsDir;
  const fields = {};
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (Object.hasOwn(FLAGS, arg)) {
      const value = argv[i + 1];
      if (value === undefined) return null;
      fields[FLAGS[arg]] = value;
      i++;
    } else if (arg.startsWith('--')) {
      return null;
    } else if (artifactsDir === undefined) {
      artifactsDir = arg;
    } else {
      return null;
    }
  }
  if (artifactsDir === undefined) return null;
  if (!fields.phase || !fields.tier || fields.iteration === undefined) return null;
  const iterationNum = Number(fields.iteration);
  if (!Number.isInteger(iterationNum)) return null;
  fields.iteration = iterationNum;
  return { artifactsDir, fields };
}

/**
 * @param {string[]} argv Arguments after `read`.
 * @returns {{artifactsDir: string, key: string|undefined}|null} `null` on any usage error: an
 *   unknown flag, `--key` with no value, or a missing <artifacts-dir>.
 */
function parseReadArgs(argv) {
  let artifactsDir;
  let key;
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === '--key') {
      const value = argv[i + 1];
      if (value === undefined) return null;
      key = value;
      i++;
    } else if (arg.startsWith('--')) {
      return null;
    } else if (artifactsDir === undefined) {
      artifactsDir = arg;
    } else {
      return null;
    }
  }
  if (artifactsDir === undefined) return null;
  return { artifactsDir, key };
}

/**
 * @param {string[]} argv `process.argv.slice(2)`.
 */
function main(argv) {
  const [cmd, ...rest] = argv;

  if (cmd === 'write') {
    const parsed = parseWriteArgs(rest);
    if (parsed === null) {
      process.stderr.write(USAGE);
      process.exit(EXIT.USAGE);
    }
    try {
      writeManifest(parsed.artifactsDir, parsed.fields);
    } catch (err) {
      if (err.code === 'DEPS_MISSING') {
        process.stderr.write(`${err.message}\n`);
        process.exit(EXIT.USAGE);
      }
      throw err;
    }
    process.exit(EXIT.OK);
  }

  if (cmd === 'read') {
    const parsed = parseReadArgs(rest);
    if (parsed === null) {
      process.stderr.write(USAGE);
      process.exit(EXIT.USAGE);
    }
    let obj;
    try {
      obj = readManifest(parsed.artifactsDir);
    } catch (err) {
      if (err.code === 'DEPS_MISSING') {
        process.stderr.write(`${err.message}\n`);
        process.exit(EXIT.USAGE);
      }
      if (err.code === 'MISSING') {
        process.stderr.write(`${err.message}\n`);
        process.exit(EXIT.MISSING);
      }
      if (err.code === 'INVALID') {
        process.stderr.write(`${err.message}\n`);
        process.exit(EXIT.INVALID);
      }
      throw err;
    }
    if (parsed.key !== undefined) {
      if (!Object.hasOwn(obj, parsed.key)) {
        process.stderr.write(`${FILE} has no field '${parsed.key}'\n`);
        process.exit(EXIT.INVALID);
      }
      process.stdout.write(`${obj[parsed.key]}\n`);
      process.exit(EXIT.OK);
    }
    process.stdout.write(`${JSON.stringify(obj, null, 2)}\n`);
    process.exit(EXIT.OK);
  }

  process.stderr.write(USAGE);
  process.exit(EXIT.USAGE);
}

module.exports = { EXIT, FILE, readManifest, writeManifest };

if (require.main === module) main(process.argv.slice(2));
