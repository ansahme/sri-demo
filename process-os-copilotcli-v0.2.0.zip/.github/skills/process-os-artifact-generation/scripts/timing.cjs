#!/usr/bin/env node
/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

// Tiny timing helper for skill subagents (process-os-bpmn-generation, process-os-artifact-generation, …).
//
// Usage:
//   node scripts/timing.cjs [--dir <path>] event <basename> <event-name>   → appends event w/ epoch-ms ts
//   node scripts/timing.cjs [--dir <path>] end   <basename>                → marks the file complete
//   node scripts/timing.cjs [--dir <path>] aggregate                       → reads all files, prints table + writes _summary.json
//
// `--dir` overrides the versioned timing directory for one invocation — the
// portable alternative to the `TIMING_DIR=<path> node timing.cjs …` env-var
// prefix, which PowerShell 5.1 cannot parse. The TIMING_DIR env var still works
// as a fallback for existing callers.
//
// The first `event` call for a basename creates the file and seeds `start_ms`.
// All writes are append-only to the in-memory record; the file is rewritten atomically.
// Concurrent subagents each touch their own file (basename is unique per phase) so no locking is needed.

const fs = require('fs');
const path = require('path');

/**
 * Pull a `--dir <path>` flag out of argv, returning it alongside the
 * remaining arguments untouched.
 *
 * A trailing `--dir` with nothing after it is a usage error, not a silently
 * empty value — otherwise the next real argument (the subcommand, or a
 * basename) would be swallowed as the directory instead.
 *
 * @param {string[]} argv
 * @returns {{dir: string|null, rest: string[]}}
 */
function parseArgs(argv) {
  let dir = null;
  const rest = [];
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--dir') {
      if (i + 1 >= argv.length) {
        console.error('usage: timing.cjs [--dir <path>] {event|end|aggregate|list} ...');
        process.exit(2);
      }
      dir = argv[++i];
    } else {
      rest.push(argv[i]);
    }
  }
  return { dir, rest };
}

const { dir: dirFlag, rest: cmdArgs } = parseArgs(process.argv.slice(2));

// Read on every call so each invocation in a fresh shell can pass the
// directory explicitly (`--dir <path>`, or the legacy `TIMING_DIR=<path>`
// env-var prefix). Falls back to `.camunda/timing/` when neither is set —
// preserves the pre-versioning behavior used by older callers and the test
// suite's default cases.
function timingDir() {
  const dir = dirFlag || process.env.TIMING_DIR;
  return dir ? path.resolve(dir) : path.join(process.cwd(), '.camunda', 'timing');
}

function ensureDir() {
  fs.mkdirSync(timingDir(), { recursive: true });
}

function fileFor(basename) {
  return path.join(timingDir(), `${basename}.json`);
}

function load(basename) {
  const fp = fileFor(basename);
  if (!fs.existsSync(fp)) return null;
  return JSON.parse(fs.readFileSync(fp, 'utf8'));
}

function save(basename, data) {
  fs.writeFileSync(fileFor(basename), JSON.stringify(data, null, 2));
}

function nowMs() {
  return Date.now();
}

function isoNow() {
  return new Date().toISOString();
}

function cmdEvent(basename, name) {
  if (!basename || !name) {
    console.error('usage: timing.cjs event <basename> <event-name>');
    process.exit(2);
  }
  ensureDir();
  let rec = load(basename);
  const ts = nowMs();
  if (!rec) {
    rec = { basename, start_ms: ts, start_iso: isoNow(), events: [] };
  }
  rec.events.push({ name, ts_ms: ts, dt_ms: ts - rec.start_ms });
  save(basename, rec);
}

function cmdEnd(basename) {
  if (!basename) {
    console.error('usage: timing.cjs end <basename>');
    process.exit(2);
  }
  const rec = load(basename);
  if (!rec) {
    console.error(`no timing record for ${basename}`);
    process.exit(2);
  }
  rec.end_ms = nowMs();
  rec.end_iso = isoNow();
  rec.duration_ms = rec.end_ms - rec.start_ms;
  rec.counters = countEvents(rec.events);
  save(basename, rec);
}

function countEvents(events) {
  const c = {};
  for (const e of events) c[e.name] = (c[e.name] || 0) + 1;
  return c;
}

function cmdAggregate() {
  const dir = timingDir();
  if (!fs.existsSync(dir)) {
    console.log('no timing data');
    return;
  }
  const files = fs.readdirSync(dir)
    .filter(f => f.endsWith('.json') && f !== '_summary.json')
    .sort();
  const records = files.map(f => JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')));

  const rows = records.map(r => {
    const c = r.counters || countEvents(r.events || []);
    return {
      basename: r.basename,
      duration_s: r.duration_ms ? +(r.duration_ms / 1000).toFixed(1) : null,
      mcp: c.mcp || 0,
      connector_resolved: c.connector_resolved || 0,
      http: c.http || 0,
      lint_runs: c.lint_run || 0,
      lint_fixes: c.lint_fix || 0,
      // start_count > 1 indicates the subagent restarted Step 1 mid-flight —
      // first attempt's events are interleaved with the second attempt and
      // the recorded duration spans both. Real generation cost is whatever
      // ran after the LAST `start` event. Surfaced as a warning below.
      start_count: c.start || 0,
    };
  });

  const totals = rows.reduce((acc, r) => ({
    duration_s: (acc.duration_s || 0) + (r.duration_s || 0),
    mcp: acc.mcp + r.mcp,
    connector_resolved: acc.connector_resolved + r.connector_resolved,
    http: acc.http + r.http,
    lint_runs: acc.lint_runs + r.lint_runs,
    lint_fixes: acc.lint_fixes + r.lint_fixes,
  }), { duration_s: 0, mcp: 0, connector_resolved: 0, http: 0, lint_runs: 0, lint_fixes: 0 });

  const anomalies = rows.filter(r => r.start_count > 1);

  const summary = { generated_iso: isoNow(), files: rows, totals, anomalies: anomalies.map(r => ({ basename: r.basename, start_count: r.start_count })) };
  fs.writeFileSync(path.join(dir, '_summary.json'), JSON.stringify(summary, null, 2));

  const pad = (s, n) => String(s).padEnd(n);
  console.log('Timing — per-file breakdown');
  console.log(pad('basename', 40), pad('dur(s)', 8), pad('mcp', 5), pad('cnct', 5), pad('http', 5), pad('lint', 5), pad('fixes', 6));
  for (const r of rows) {
    const flag = r.start_count > 1 ? `  ⚠ start×${r.start_count} (subagent restarted)` : '';
    console.log(
      pad(r.basename, 40),
      pad(r.duration_s ?? '—', 8),
      pad(r.mcp, 5),
      pad(r.connector_resolved, 5),
      pad(r.http, 5),
      pad(r.lint_runs, 5),
      pad(r.lint_fixes, 6) + flag,
    );
  }
  console.log(pad('TOTAL', 40), pad(totals.duration_s.toFixed(1), 8), pad(totals.mcp, 5), pad(totals.connector_resolved, 5), pad(totals.http, 5), pad(totals.lint_runs, 5), pad(totals.lint_fixes, 6));

  if (anomalies.length) {
    console.log('');
    console.log(`⚠ ${anomalies.length} file(s) emitted multiple \`start\` events — the subagent restarted Step 1 mid-flight.`);
    console.log('  Recorded duration over-counts (spans both attempts); recorded events are interleaved.');
    for (const a of anomalies) console.log(`  - ${a.basename}: ${a.start_count} starts`);
  }

  console.log(`\nwritten: ${path.join(dir, '_summary.json')}`);
}

// `list` enumerates every run directory under .camunda/timing/ and prints one
// row per run. Unlike the other commands, it always operates on the
// project-default parent (`.camunda/timing/`) and ignores TIMING_DIR — the
// override is for per-run scoping; introspection happens at the project level.
//
// A run directory is labelled one of two ways, and both are listed. A phase
// that saves a versioned snapshot names its run after that version — `v<N>`,
// optionally suffixed (process-os-bpmn-generation's per-tier
// `-incremental`/`-radical`/`-moonshot` for parallel transformation-tier runs).
// A phase with no snapshot to pair a version with names its run after its own
// start timestamp instead — `<epoch-ms>-artifact`. RUN_DIR matches both, so
// neither renders as a missing row; anything else under `.camunda/timing/` is
// not a run and is skipped.
const RUN_DIR = /^(v)?(\d+)(?:[-.]|$)/;

function cmdList() {
  const root = path.join(process.cwd(), '.camunda', 'timing');
  if (!fs.existsSync(root)) {
    console.log('no timing data');
    return;
  }
  // The two label spaces are not comparable as numbers — `v2` is not before or
  // after `1758…` in any meaningful sense — so each is ordered within itself
  // and the versioned ones come first.
  const versions = fs.readdirSync(root, { withFileTypes: true })
    .filter(e => e.isDirectory() && RUN_DIR.test(e.name))
    .map(e => {
      const [, versioned, digits] = e.name.match(RUN_DIR);
      return { name: e.name, versioned: Boolean(versioned), n: Number(digits) };
    })
    .sort((a, b) => (a.versioned === b.versioned ? a.n - b.n : (a.versioned ? -1 : 1)))
    .map(e => e.name);

  if (versions.length === 0) {
    console.log('no timing runs recorded (run /process-os-bpmn-generation or /process-os-artifact-generation to populate)');
    return;
  }

  const rows = versions.map(v => {
    const summaryPath = path.join(root, v, '_summary.json');
    if (!fs.existsSync(summaryPath)) {
      return { version: v, missing: true };
    }
    const s = JSON.parse(fs.readFileSync(summaryPath, 'utf8'));
    return {
      version: v,
      generated: s.generated_iso ? s.generated_iso.replace('T', ' ').slice(0, 16) : '—',
      files: s.files ? s.files.length : 0,
      duration_s: s.totals ? s.totals.duration_s : 0,
      mcp: s.totals ? s.totals.mcp : 0,
      connector_resolved: s.totals ? s.totals.connector_resolved : 0,
      http: s.totals ? s.totals.http : 0,
      lint_runs: s.totals ? s.totals.lint_runs : 0,
      lint_fixes: s.totals ? s.totals.lint_fixes : 0,
    };
  });

  const pad = (s, n) => String(s).padEnd(n);
  console.log('Timing — runs');
  console.log(
    pad('run', 24),
    pad('generated', 18),
    pad('files', 6),
    pad('dur(s)', 9),
    pad('mcp', 5),
    pad('cnct', 5),
    pad('http', 5),
    pad('lint', 5),
    pad('fixes', 6),
  );
  for (const r of rows) {
    if (r.missing) {
      console.log(pad(r.version, 24), '(no _summary.json — run still in progress or aggregate not run)');
      continue;
    }
    console.log(
      pad(r.version, 24),
      pad(r.generated, 18),
      pad(r.files, 6),
      pad(r.duration_s.toFixed(1), 9),
      pad(r.mcp, 5),
      pad(r.connector_resolved, 5),
      pad(r.http, 5),
      pad(r.lint_runs, 5),
      pad(r.lint_fixes, 6),
    );
  }
}

const [cmd, ...args] = cmdArgs;
switch (cmd) {
  case 'event': cmdEvent(args[0], args[1]); break;
  case 'end': cmdEnd(args[0]); break;
  case 'aggregate': cmdAggregate(); break;
  case 'list': cmdList(); break;
  default:
    console.error('usage: timing.cjs {event|end|aggregate|list} ...');
    process.exit(2);
}
