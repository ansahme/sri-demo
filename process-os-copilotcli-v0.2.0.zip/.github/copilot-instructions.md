This is a ProcessOS project repository. It contains the full memory and output artifacts of a ProcessOS process re-engineering project, driven by the ProcessOS skill harness.

## Reference hygiene

- Prompts, skills, agents, and scripts must not reference other PRs or commits.
- A referenced `.md` file must not point back to its parent `SKILL.md`.

## Orientation questions

Answer orientation questions ("What is this", "What can I do here", "How do I get started") from `README.md` and `.camunda/state.md` — never by reading skill directory listings. Point the user to `/process-os-governance-start` to begin or resume the governance workflow.
Skill availability can change independently of this file, so it is not a reliable source for "What can I do here".

## Naming conventions

In prose, always write **ProcessOS** — never "Process OS" (no space), never "POS".

In code and paths, follow the context's casing convention:

| Context | Form |
|---------|------|
| Prose | `ProcessOS` |
| Snake_case | `process_os` |
| Kebab-case (file paths) | `process-os` |
| CamelCase | `processOS` |
| PascalCase | `ProcessOS` |
| SCREAMING_SNAKE_CASE | `PROCESS_OS` |

## Working directory

Every agent session opens from the **project root** — the folder containing `.camunda/`. This is the working directory for all shell commands.

- **Never `cd` away from the project root.** Use absolute paths or a subshell `( cd <dir> && … )` when a command requires a different directory.
- **Trust `process.cwd()`** in Node.js — it is the project root. Scripts do not search upward for it.
- **Pass paths as arguments** when a script operates on a specific file. Relative paths in arguments resolve against the project root.
- **Scripts always run from the project root.** When a skill instructs you to run a script, invoke it from the project root — never `cd` into a skill directory first.
- **Skill-internal paths (`references/`, `scripts/`) are harness-managed.** Never construct, navigate, or manipulate paths inside skill directories. Your only job is to run the script the skill tells you to run.
- **Scripts only touch project files.** Scripts read and write things within the project root (`.camunda/`, `process-discovery/`, etc.). If a script appears to need a path outside the project root, that is a bug in the skill.

## Key files

| File | Purpose |
|------|---------|
| `.camunda/governance.json` | Governance run state — cluster connection, process instance key, active job. Local to each developer, gitignored |
| `.camunda/audit.md` | Append-only audit log of all skill runs |
| `.camunda/memory.md` | Decision journal — synthesized choices per phase |
| `process-scope.md` | Business scope + identity (process name, description, organization, KPIs, data sources) |
| `run.config.yaml` | Technical run config (mode, specialists, research round limits, gates) |

## Governance process

ProcessOS drives an engagement through a deployed Camunda BPMN process (`process-os-governance`), not through ad-hoc skill calls. 
The process encodes the full re-engineering lifecycle — scope, discover, transform, implement — as service tasks; each task activates a job that routes to the skill responsible for that phase.
Governance skills read and write `.camunda/governance.json` to track the cluster connection, the running process instance, and the currently active job.

The governance process is authoritative for lifecycle and phase state. Filesystem lifecycle records, including `.camunda/state.md`, `.camunda/audit.md`, and README summaries, are illustrative only; do not gate or branch on their status values.

Look out for:

- **`governance.json` is per-developer, not shared.** It is gitignored; if it's missing or `instance-key` is `null`, run `/process-os-governance-start` before anything else.
- **One job is active at a time.** `active-job-key` names the currently held job; complete it via `/process-os-governance-job-completion` before activating the next one.
- **A locked job blocks other workers.** If a job appears stuck, `/process-os-governance-job-update --timeout 1` frees it for reactivation.

## Nested skill calls don't end your turn

Many skills invoke other skills partway through their own procedure (directly, or through a
dispatched agent). When you invoke a nested skill this way, you are still executing the
**calling** skill's procedure — the nested skill's own completion summary ("X complete", a final
status line, a Step-N recap) is *that skill's* completion, not yours. Track which skill's
instructions you are currently following, and treat a nested skill returning as a normal step
result, not a stopping point: immediately continue with the calling skill's next instruction.
Only stop where the calling skill's own text says to — an explicit gate, an error it tells you to
stop on, or its actual final step.

This is a real, observed failure mode: agents running a long multi-phase skill have stopped
responding right after a nested skill call returned and they'd written that nested skill's
completion summary, abandoning the outer skill mid-procedure with no error and no resource limit
hit. A skill's own "continue to the next phase" reminder is not reliably sufficient on its own —
keep this general awareness active across every nested skill call, not just the ones a skill's
text happens to call out.

## Autonomy model

Skills operate in one of two modes, set via `mode` in `run.config.yaml`:

| Mode | Behavior |
|------|---------|
| `interactive` | Propose each action and pause at every review gate for user approval (default) |
| `unattended` | Auto-accept all recommendations and chain phases automatically |

**Merge to main and production deployment always require explicit human confirmation, regardless of mode.**

**`unattended` covers a skill's own review and recommendation gates only — never a Tasklist user task
in the governance process.** Those tasks (`Define next * iteration`, `Review * assets`, and any other
SME sign-off or decision task) are human decisions: complete one only when the user has explicitly
instructed you to complete that specific task.
